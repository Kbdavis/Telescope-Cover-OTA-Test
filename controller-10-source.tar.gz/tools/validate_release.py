#!/usr/bin/env python3
"""Offline release regression gate. Never opens serial ports or contacts hardware."""
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]


def run(*args):
    subprocess.run(list(args), cwd=ROOT, check=True)


def main():
    run(sys.executable, '-m', 'unittest', 'discover', '-s', 'tests/tools', '-p', '*_test.py')
    run('node', '--test', 'tests/web/installer_test.mjs')
    run('node', '--test', 'tests/web/release_metadata_test.cjs')
    run('node', '--test', 'tests/web/release_discovery_test.cjs')
    run('node', '--test', 'tests/web/update_retry_ui_test.cjs')
    run('node', '--test', 'tests/web/bench_auto_session_test.cjs')
    run('node', '--test', 'tests/web/controller_update_transfer_test.cjs')
    run('node', '--test', 'tests/web/page_startup_test.cjs')
    run('node', '--test', 'tests/web/release_signing_test.cjs')
    run('node', '--test', 'tests/web/release_signature_interop_test.cjs')
    for test in ('firmware_version_test', 'diagnostics_download_test', 'manual_stow_override_test', 'manual_torque_test', 'travel_model_test'):
        run('node', f'tests/web/{test}.cjs')
    with tempfile.TemporaryDirectory(prefix='telescope-host-tests-') as directory:
        for name, flags, sources in (
            ('bounded-http', ['-Itests/host/http_shim'], ['tests/host/bounded_web_server_test.cpp']),
            ('http-parser', [], ['tests/host/http_request_test.cpp']),
            ('browser-controller-driver', ['-Itests/host','-DCOVER_MULTITURN','-DCOVER_BROWSER_OTA'], ['tests/host/browser_controller_driver_test.cpp','src/servo_controller.cpp']),
            ('browser-ota-protocol', [], ['tests/host/browser_ota_protocol_test.cpp']),
            ('bench-ota-protocol', [], ['tests/host/bench_ota_protocol_test.cpp']),
            ('controller', ['-Itests/host'], ['tests/host/cover_controller_test.cpp', 'src/cover_controller.cpp']),
            ('worker', ['-Itests/host/diagnostics_shim'], ['tests/host/maintenance_integration_test.cpp', 'src/cover_controller.cpp', 'src/emergency_shutdown.cpp', 'src/alpaca_client.cpp']),
            ('multiturn', ['-Itests/host', '-DCOVER_REFERENCE_PROBE', '-DCOVER_MULTITURN_PROBE', '-DCOVER_MULTITURN_STARTUP'], ['tests/host/multiturn_driver_test.cpp', 'src/servo_controller.cpp']),
            ('multiturn-usb', ['-Itests/host', '-DCOVER_MULTITURN_USB'], ['tests/host/multiturn_driver_test.cpp', 'src/servo_controller.cpp']),
            ('multiturn-usb-worker', ['-Itests/host/diagnostics_shim', '-DCOVER_MULTITURN_USB'], ['tests/host/maintenance_integration_test.cpp', 'src/cover_controller.cpp', 'src/emergency_shutdown.cpp', 'src/alpaca_client.cpp']),
            ('update-profile-evidence', ['-Itests/host', '-DCOVER_MULTITURN'], ['tests/host/update_profile_evidence_test.cpp']),
            ('readonly-web-driver', ['-Itests/host', '-DCOVER_MULTITURN', '-DCOVER_WEB_READ_ONLY', '-DCOVER_SERVO_READ_ONLY'], ['tests/host/read_only_driver_test.cpp', 'src/servo_controller.cpp']),
        ):
            binary = str(Path(directory) / name)
            run('c++', '-std=c++17', '-Wall', '-Wextra', '-Werror', '-Isrc', *flags, *sources, '-o', binary)
            run(binary)
    print('Offline release gates passed. Browser/USB hardware acceptance is separate.')


if __name__ == '__main__':
    main()
