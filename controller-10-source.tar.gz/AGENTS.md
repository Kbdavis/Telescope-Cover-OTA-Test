# AGENTS.md

# Telescope Cover / Mini-Observatory Controller

## 1. Project mission

This project is an automated outdoor telescope-cover / mini-observatory for a **ZWO Seestar S30 Pro**.

The system is intended to:

- protect the telescope from rain, dust, dew, and weather when unattended;
- open and close remotely;
- provide repeatable, positively verified OPEN and CLOSED states;
- expose a telescope-cover-specific web UI;
- use a Waveshare ESP32 servo controller and ST3215 serial-bus servo;
- support configurable motion speed, acceleration, positions, and safety limits;
- report useful servo and enclosure telemetry;
- add rain, temperature/humidity, open/closed sensing, and later telescope-state integration;
- eventually support unattended operation with conservative fail-safe behavior.

**Safety, reliability, weather protection, and recovery from faults are more important than speed.**

This is not a generic servo demo. All implementation choices should be made around protecting an outdoor telescope.

## Open-source release and video documentation

This will be a **completely open-source project, covering both software and hardware**. Plan releases so others can build, understand, modify, and contribute to the project.

Release deliverables should include firmware source, editable hardware/mechanical design files, printable parts, a bill of materials, wiring information, and written build/setup instructions. Include appropriate open-source licensing for software and hardware; do not assume that publishing files alone establishes a license.

At least **two YouTube videos** are planned:

1. **Project overview:** explain the purpose, demonstrate operation, introduce the hardware and software, and describe the released design's capabilities and limitations.
2. **Build instructions:** walk through parts, printing, assembly, wiring, firmware installation, configuration, calibration, and initial operating checks.

Keep written documentation and video instructions aligned with the hardware revision and firmware release they demonstrate. Clearly document any requirement to stow the telescope before closing for the applicable cover design.

---

# 2. Current software-development approach

Preferred stack:

- **VS Code**
- **PlatformIO**
- **Arduino framework for ESP32** for the first implementation
- Codex for substantial project work
- ESP-IDF may be considered later if there is a concrete need for lower-level networking, RTOS/task control, watchdog behavior, or production hardening

Do not migrate to ESP-IDF merely for sophistication. The first goal is to produce a clean, modular, reliable controller using Arduino-on-ESP32 under PlatformIO.

Recommended project layout:

```text
telescope-cover/
├── AGENTS.md
├── platformio.ini
├── src/
│   ├── main.cpp
│   ├── servo_controller.cpp
│   ├── servo_controller.h
│   ├── cover_controller.cpp
│   ├── cover_controller.h
│   ├── web_server.cpp
│   ├── web_server.h
│   ├── settings.cpp
│   ├── settings.h
│   ├── sensors.cpp
│   └── sensors.h
├── include/
├── data/
│   └── index.html
└── docs/
    ├── ARCHITECTURE.md
    ├── HARDWARE.md
    ├── SERVO.md
    ├── SAFETY.md
    └── MECHANICAL.md
```

Keep servo-driver code, cover-state logic, sensor logic, settings persistence, and web UI separate.

---

# 3. Primary electronics

## ESP32 controller

Current board:

**Waveshare Servo Driver with ESP32**

Observed chip:

```text
ESP32-D0WD-V3
revision v3.1
40 MHz crystal
Wi-Fi + Bluetooth
dual core
```

On the current Mac development machine the USB serial port has appeared as:

```text
/dev/cu.usbserial-0001
```

A tested firmware fork exposed a mode displayed on the OLED as:

```text
MODE: SF
```

This means **Serial Forwarding**.

The Mac-to-ESP32 forwarding connection has been successfully used at:

```text
115200 baud
```

The servo bus behind the ESP32 is separate.

Do not assume 1,000,000 baud for the Mac-to-ESP32 serial-forwarding interface.

---

# 4. Primary servo

Servo:

**Waveshare / Feetech ST3215 serial-bus servo**

Current servo ID:

```text
1
```

Python SDK ping has identified model:

```text
777
```

Observed bench supply:

```text
~12.2–12.3 V
```

Observed idle temperature during testing:

```text
~37–38 °C
```

The servo is mechanically difficult to back-drive even with torque released because of its reduction gearing. That alone is not evidence of a fault.

---

# 5. ST3215 position system

The ST3215 uses a 12-bit absolute-position range.

Normal position domain:

```text
0 .. 4095
```

Nominal center:

```text
2047 / 2048
```

This represents approximately one full 360-degree absolute-position revolution.

Normal position-servo mode:

```text
Operating mode register 33 = 0
```

Continuous/wheel/motor mode is not the normal cover-control mode.

The application should operate in absolute position mode unless an explicit future design requires something else.

---

# 6. ST3215 registers currently relevant

Important register addresses used during successful testing:

```text
ID                      5
Baud index               6
Minimum angle            9
Maximum angle           11
Phase/config            18
P gain                  21
D gain                  22
I gain                  23
Angular resolution      30
Position offset         31
Operating mode          33
Torque enable           40
Acceleration            41
Goal position           42
Goal speed              46
Torque limit            48
EEPROM lock             55
Present position        56
Present speed           58
Present load            60
Voltage                 62
Temperature             63
Moving flag             66
Current                 69
```

Treat EEPROM/register writes as hazardous configuration changes.

Do not casually write persistent servo configuration during routine operation.

---

# 7. Known-good ST3215 configuration

The servo has been experimentally restored to a working configuration.

Known-good values:

```text
Phase/config register 18 = 0
Angular resolution       = 1
Position offset          = 0
Operating mode           = 0
Minimum angle            = 0
Maximum angle            = 4095
```

Observed normal PID values:

```text
P gain = 32
D gain = 32
I gain = 0
```

Before any normal enclosure movement, the controller should validate the critical mode/range configuration.

At minimum verify:

```text
mode == 0
min_angle == 0
max_angle == 4095
phase/config == 0 and offset == 0 (legacy profile)
```

If these are wrong, do not move the cover automatically.

Commissioned exception (2026-10-27): the new ST3215 with firmware 3/9, phase
12 and offset 85 passed a supervised small bidirectional test and retained those
settings across an external power cycle. Accept this alternative only when all
40 documented identity/configuration bytes match `src/servo_factory_profile.h`.
Mode 0, limits 0–4095 and resolution 1 remain required. No servo EEPROM is
rewritten to select a profile. Higher-speed and loaded-cover behavior remain
unvalidated; begin calibration at speed 100 and acceleration 10.

Boundary test (2026-10-28): on this exact factory profile, a supervised unloaded
4050 → 54 absolute goal at speed 100 / acceleration 10 moved in the decreasing
(long-path) direction. The controller faulted and released torque near 4029.
Do not enable rollover merely by wrapping goal arithmetic; this profile has not
passed boundary commissioning. Preserve the trace and require a separately
approved/validated reference or motion approach before enabling crossing.

Approved fixed-reference commissioning (2026-10-28): with the detached shaft
clear, offset registers 31–32 were written 85 → 1328 (`30 05`) while EEPROM
lock 55 remained 1. Stationary feedback shifted exactly −1243; supervised
2807 → 2905 → 2807 moves crossed the former boundary successfully at speed
100 / acceleration 10. Restoration to 85 recovered the full factory snapshot.
The validated `web_control_reference_dev` build is installed on cover-dev.local;
it prepares this exact locked reference, checks all 40 bytes and lock 1, and
stores calibration reference basis in schema v5. CLOSED 2386 becomes 1143;
OPEN 100 becomes 2953. Actual new raw 4095/0 crossing remains disabled. Never
use offset-85 coordinates under offset 1328. No EEPROM unlock was performed;
external servo power-cycle retention is not yet physically verified. See
`docs/SERVO_REFERENCE_COMMISSIONING.md` for measured evidence and limitations.

Reference regression (2026-10-29, supersedes operational approval above): the
detached servo moved 3192 → 3220 when commanded to hold 3192 at offset 1328.
The user approved restoration of only registers 31–32 to factory 85 (`55 00`),
with lock 55 kept at 1. All 40 factory bytes matched; the repeated bounded hold
stayed stationary at 3923. Offset 1328 is no longer qualified. Do not deploy
`web_control_reference_dev` or reapply 1328 automatically. Keep saved
offset-1328 calibration as review evidence, never active offset-85 coordinates.
Raw boundary crossing and full loaded travel remain unvalidated. See
`docs/SERVO_REFERENCE_COMMISSIONING.md` for the comparison evidence.
Normal `web_control_dev` ELF `48b0e6f…` is installed by completed recovery OTA;
it leaves offset 85 in place, retains old calibration only for review, and
requires fresh teaching before normal OPEN/CLOSE. Torque was left OFF.
Subsequent user OPEN test at factory offset 85 also failed: requested
3923 → 3823, actual increasing to 3947, with the correct goal stored and exact
factory bytes matching. The direction guard stopped and confirmed torque OFF.
A passing stationary hold is not evidence that moving commands are repaired;
both references remain unqualified for moving the cover. Do not infer that a
new offset, reversed button labels or relaxed direction checks fixes this.
After the user cold-power-cycled the servo connector for ten seconds, its goal,
speed and acceleration registers reset to zero. Stationary Recheck confirmed
the factory profile at offset 85 and torque OFF. One supervised OPEN step then
moved in the correct decreasing direction, 3946 → 3939 for target 3936, with
59 successful reads and no direction fault. It stayed three counts short of the
two-count fine-jog band, so the external three-second test limit sent Stop.
Torque OFF was confirmed. Root cause, reverse motion and full travel remain
unvalidated; do not treat this as a qualified repair or reconnect automatically.
Follow-up browser movement after that reset completed a 100-count CLOSE request
3941 → 4041, settling at 4040 with five stable samples and no failed/rejected
reads. The agent's proposed ten-count CLOSE test aborted before movement because
the browser had changed its starting position. Both short unloaded directions
now have evidence, but root cause, full travel and loaded-cover behavior remain
unvalidated. Position 4040 is near raw 4095; arrange mechanical travel away from
the boundary before reattaching and teaching. No further CLOSE was commanded.

Assembly orientation (user-confirmed 2026-10-29, supersedes 2026-10-28): the
servo was mechanically reoriented. Decreasing servo position now moves toward
OPEN; increasing moves toward CLOSED. New teaching uses direction -1
automatically; do not ask which button opens the mechanism. Manual and teaching
buttons use this assembly direction. Preserve saved calibration until an explicit
teaching/save operation replaces it; a saved +1 calibration requires review and
fresh teaching before normal OPEN/CLOSE. Do not reverse servo EEPROM settings.

Rollover retest (2026-10-29): after cold reset, the user approved an unloaded
crossing test. Wrapped goal 4041 → 45 again drove backward, to 4017; safety
stopped it and confirmed torque OFF. Normal development firmware was restored
by OTA. A separate `web_control_multiturn_probe` was then explicitly approved,
installed and applied: exact RAM changes are max angle 11–12 = 0 and
phase 18 = 28 (full-angle feedback), retaining mode 0, offset 85 and lock 1.
It uses signed continuous native goals with modulo-4096 application display,
bounded 100-count moves and existing supervision. One unloaded positive crossing
passed: display 4016 → target 20, final 19, native target 4116 / final 4115,
five stable samples, no failed/rejected reads or new fault, torque OFF. Exact
probe bytes and lock 1 were verified. Final probe ELF `132539eb…` is installed
with a 100-count limit enforced before torque enable and in the UI. Native
feedback/profile survived that ESP32-only OTA restart; external servo power-cycle
retention, reverse crossing and loaded/full travel remain unvalidated. No EEPROM
unlock or calibration save occurred. Do not install factory-only normal firmware
while this profile is active; restore/verify factory configuration first or use
firmware that understands native multi-turn feedback. No automatic apply occurs
at startup. See `docs/MULTITURN_COMMISSIONING.md` for exact approval and evidence.


---

# 8. Critical Waveshare firmware incompatibility discovered during testing

The older Waveshare web servo interface and/or code path can corrupt ST3215 configuration by applying assumptions intended for SC-series servos.

Observed corrupted values:

```text
Minimum angle = 5120
Maximum angle = 60163
```

These values reappeared after returning to the Waveshare-style web interface.

When corrupted:

- position commands stop behaving normally;
- the servo may remain fixed despite accepted commands;
- reported position values can become nonsensical;
- the web UI may behave as though the servo were a 0–1023 / 180-degree servo;
- later motion tests may appear to run continuously or otherwise misbehave.

Another previously observed modified state was:

```text
Phase/config = 12
Position offset = 85
```

Later observation (2026-10-27): a separate servo, confirmed by the user to be
brand-new and never configured, also reported phase 12 and offset 85, with
mode 0, limits 0–4095, and resolution 1. Those two values alone therefore do
not establish configuration corruption. Preserve this distinction from the
invalid angle limits above. The phase-0/offset-0 profile remains the project's
previously motion-tested configuration; accepting another profile requires
explicit commissioning and validation, not an automatic EEPROM rewrite.

Restoring:

```text
Phase/config = 0
Position offset = 0
Minimum angle = 0
Maximum angle = 4095
Mode = 0
```

restored correct closed-loop servo behavior.

## Mandatory implementation rule

**Do not reuse Waveshare SC-servo configuration code.**

This project should be ST3215-specific unless deliberate multi-family support is later designed and tested.

Never copy SC-style range assumptions into ST3215 configuration.

Do not use the old Waveshare web UI for servo-mode setup in the finished controller.

---

# 9. Proven ST3215 behavior after repair/reset

After restoring EEPROM/configuration, bench tests successfully demonstrated:

- servo ping;
- correct position feedback;
- voltage readback;
- temperature readback;
- load readback;
- current readback;
- torque enable;
- torque release;
- absolute position mode;
- bidirectional moves;
- speed control;
- acceleration control;
- accurate target settling.

Successful test examples over about 1000 encoder counts:

```text
speed 400  -> about 1.89 s
speed 800  -> about 1.35 s
speed 1600 -> about 0.98 s
speed 600  -> about 1.90 s with gentler acceleration
```

The motion profile clearly shows acceleration and deceleration.

Settling has been within only a few encoder counts of target.

---

# 10. Serial-forwarding behavior and read reliability

The ESP32 serial-forwarding path occasionally produces transient communication failures.

Observed communication failures include:

```text
result = -6
result = -7
```

These have occurred even when the servo itself is otherwise functioning correctly.

There have also been isolated bogus position reads, including a sudden `0` value in the middle of a smooth move.

Therefore:

- reject any register value if the communication result indicates failure;
- retry failed reads;
- never treat a failed read's returned value as valid;
- do not declare runaway motion from one anomalous sample;
- require multiple consistent samples before declaring a motion-direction fault;
- keep telemetry polling conservative;
- position should be polled more frequently than secondary telemetry;
- load/current/temperature/voltage can be polled less often.

The final controller should be robust to temporary serial-forwarding failures.

---

# 11. Motion-safety philosophy

The cover mechanism can damage the telescope if motion is incorrect.

Before movement:

1. confirm servo communication;
2. confirm expected servo ID;
3. confirm valid position feedback;
4. confirm position mode;
5. confirm ST3215 min/max limits;
6. confirm valid phase/config;
7. confirm requested target is inside configured mechanical limits;
8. confirm enclosure state allows the requested move;
9. check relevant limit/rain/interlock sensors.

During movement:

- track position;
- track elapsed time;
- confirm position converges toward the target;
- tolerate isolated failed reads;
- stop on repeated valid wrong-direction movement;
- stop on timeout;
- stop on sensor contradiction;
- stop on excessive or sustained load/current if thresholds are later established;
- stop if rain/safety logic requires a different action.

On unexplained failure:

```text
Torque OFF
Cover state = FAULT
```

Do not automatically resume an interrupted movement after an unexplained fault.

---

# 12. Cover state machine

Do not implement Open/Close web buttons as direct servo writes.

Use a proper state machine.

Core states:

```text
UNKNOWN
CLOSED
OPENING
OPEN
CLOSING
STOPPED
FAULT
```

Likely future states:

```text
CALIBRATING
WAITING_FOR_TELESCOPE_PARK
RAIN_CLOSING
MANUAL
```

Core commands:

```text
OPEN
CLOSE
STOP
```

The web layer should issue high-level cover commands.

Only the cover-control layer should decide how to move the servo.

---

# 13. Intended normal web interface

The final UI should be telescope-cover-specific.

Minimum useful display:

```text
Telescope Cover

State: CLOSED / OPEN / OPENING / CLOSING / STOPPED / FAULT
Servo position
Servo voltage
Servo temperature
Servo load
Servo current
Wi-Fi status
Open sensor state
Closed sensor state
Rain sensor state

[ OPEN ]
[ CLOSE ]
[ STOP ]
```

Settings should include:

```text
Open position
Closed position
Opening speed
Closing speed
Acceleration
Movement timeout
```

Later settings may include:

```text
Rain behavior
Auto-close behavior
Telescope park integration
Sensor enable/disable
Network setup
OTA settings
```

Do not expose raw EEPROM writes on the normal UI.

---

# 14. Calibration UI

Provide a separate protected calibration section.

Useful controls:

```text
Jog +
Jog -
Stop
Torque release
Torque enable
Read current position
Set current position as CLOSED
Set current position as OPEN
Set speed
Set acceleration
Test OPEN
Test CLOSE
```

Calibration should operate on application settings first.

Persistent servo EEPROM should not be modified except when deliberately repairing/configuring the servo.

---

# 15. Persistent settings

Use ESP32 Preferences / NVS for application settings.

Likely settings:

```text
open_position
closed_position
open_speed
close_speed
acceleration
movement_timeout
wifi_ssid
wifi_password
fallback_ap_enabled
rain_behavior
sensor_enable_flags
```

Validate every loaded value.

Do not silently accept invalid or uninitialized values.

The raw servo domain is:

```text
0 .. 4095
```

The actual mechanical open/closed positions should be inside that domain with margin from the absolute ends.

---

# 16. Networking

Preferred deployment:

- normal **STA mode** on the home Wi-Fi network;
- fallback **AP mode** for setup/recovery;
- AP+STA may be used when helpful.

The controller should not become unusable simply because the normal Wi-Fi network is unavailable.

Future remote sensor communication via ESP-NOW has been discussed, but is not required for the first controller.

---

# 17. Planned sensors

High-priority future sensors:

- CLOSED position/limit sensor;
- OPEN position/limit sensor;
- rain sensor;
- temperature/humidity sensor.

Possible additional signals:

- enclosure interior temperature;
- enclosure humidity;
- external weather sensor;
- servo current/load fault detection;
- camera-based visual verification.

Physical open/closed sensors should ultimately be considered more authoritative about the cover mechanism than servo position alone.

The servo encoder proves the servo shaft position, not necessarily the actual cover position.

---

# 18. Telescope integration

Target telescope:

**ZWO Seestar S30 Pro**

The long-term close sequence should eventually be capable of checking that the telescope is safely parked/stowed before the cover closes.

Conceptual future close flow:

```text
request telescope park/stow
wait for confirmed safe telescope state
confirm enclosure path clear
close cover
confirm closed sensor
```

Do not rely permanently on a fixed timer if telescope state can be queried.

Seestar network/API integration has been considered for later development. Treat it as a future subsystem, not a dependency of the first working cover controller.

---

# 19. Outdoor operation

The final system is intended for outdoor unattended use.

Design for:

- rain;
- dust;
- dew;
- condensation;
- temperature swings;
- network failure;
- power loss;
- controller restart;
- servo stall;
- partial movement;
- sensor failure;
- telescope not being safely parked;
- unexpected obstruction.

The Seestar itself should not be treated as weatherproof simply because its optics are stowed.

The enclosure should provide real rain exclusion and ventilation rather than relying on the telescope's own shell.

---

# 20. Overall mechanical concept

The active mechanical concept is a circular 3D-printed weather cover and base.

The design has evolved repeatedly, so dimensions in this file are historical/reference values unless the current CAD establishes otherwise.

Important explored sizes include:

```text
cover/base diameter ~300 mm
cover height ~180–250 mm
base height ~80 mm in one assembly study
```

Another later working cover size:

```text
diameter ~225 mm
cover height ~160 mm
```

Do not assume one revision is final without checking the current CAD.

---

# 21. Seestar physical envelope

A prior assembly study used approximately:

```text
S30 Pro envelope:
210 mm high
140 mm wide
80 mm deep
```

One 300 mm cover study left about 41 mm roof clearance in the closed arrangement.

Earlier discussion also considered the telescope's rotating sweep and the need for adequate internal diameter if the telescope is not perfectly stowed.

Mechanical clearance must be validated against the real S30 Pro and any cable/tripod/wedge configuration actually used.

---

# 22. Base geometry and weather interface

Base concept:

- circular;
- often split into four printable quarters;
- raised rim/lip;
- approximately 45-degree angled seating surface;
- perimeter water barrier;
- base wall somewhat stronger/thicker than cover wall.

The cover should seat onto the angled top of the base wall.

A key design correction from earlier iterations:

**the cover is intended to rest on the 45-degree seating surface, not simply overlap down the outside of the base wall as a loose sleeve.**

Quarter-to-quarter sealing and water paths matter.

Tongue-and-groove, micro-groove, and seam-channel concepts have been explored.

---

# 23. 3D-printing constraints

Primary printer:

**Bambu Lab X1C**

Build volume is approximately:

```text
256 x 256 x 256 mm
```

Large circular components therefore need to be split into sections.

Common concept:

- cover in four quarters;
- base in four quarters.

Prototype print guidance previously discussed:

```text
0.20 mm layers for smaller mechanical prototypes
5–6 walls for loaded cradle parts
6 top/bottom layers for cradle
40–50% infill for cradle prototypes
```

For tall large enclosure walls, 0.28 mm layers were considered as a reasonable way to reduce print time.

Materials discussed:

- PLA for quick prototypes;
- PETG for fit/mechanical prototypes;
- ASA as a candidate for final outdoor parts.

Outdoor UV/weather durability matters for final material selection.

---

# 24. Servo cradle

The ST3215 is mounted in an external weather-resistant cradle on or near the lower base.

A prior split-cradle revision used approximately:

```text
overall: ~64 W x 54 D x 58 H mm
lower tray to joint: ~44 mm
top cap: ~14 mm
walls: ~3–4 mm
floor: ~6 mm
roof: ~6 mm
split horn opening: ~22 mm
```

One design used four M3 x 20 screws and captive hardware for the cap while the servo remained separately fixed.

Another earlier prototype used M4 base bolts on approximately 50 x 38 mm centers.

Later simplification explored removing internal printed support tabs/posts and instead using holes through the shell aligned with the servo mounting points, long screws, and fender washers.

Treat all cradle dimensions as design-history references unless current CAD confirms them.

The final cradle must address:

- rain exclusion;
- horn/shaft opening;
- cable penetration;
- water drainage;
- servo removal/serviceability;
- mechanical load transfer into the base.

---

# 25. Servo horn / arm interface

The servo uses a circular metal horn.

Reference arm-interface dimensions from earlier designs:

```text
horn/boss diameter ~20 mm
four mounting holes
M3 clearance ~3.2 mm
bolt circle ~14 mm PCD
center access hole ~6.5 mm
boss projection ~5 mm
```

The arm bottom was designed with a circular plate matching the servo horn.

Do not assume these are final production dimensions without checking the actual horn/CAD.

---

# 26. Arm geometry

The arm concept evolved substantially.

The most important current ideas are:

- servo mounted externally low on the base;
- servo is intended to act as the primary rotating hinge/actuator;
- the horn attaches to a rigid arm;
- arm rises generally vertically;
- a short 90-degree section reaches toward the cover;
- cover interaction/attachment is around the cover mid-height in several designs;
- the geometry should pull the cover back and away rather than simply rotate it into the telescope.

Earlier drawing references included approximately:

```text
arm height ~140 mm
reach ~80 mm
thickness ~10 mm
limb width ~20 mm
```

These are reference values only.

---

# 27. Critical servo orientation

One major correction in earlier design work was the servo orientation.

The servo was effectively twisted/rotated about 90 degrees relative to earlier sketches so the circular horn plane and arm motion produce a useful pull that lifts the cover **back and away**.

Do not casually redesign the axis orientation.

The servo itself is intended to be the hinge/rotating actuator in the present concept.

---

# 28. Adjustable arm attachment

The user wants to empirically determine the most effective mechanical attachment point.

A prior design idea used multiple candidate attachment locations around the cover so the mechanism could be tested at different heights/locations.

The goal is to find the configuration that:

- minimizes servo load;
- provides adequate lift;
- clears the telescope;
- maintains stable open positioning;
- closes reliably;
- avoids excessive bending loads.

Software should support easy calibration of open and closed positions while this mechanical geometry is still changing.

---

# 29. Cover retention and hinge concerns

Several arm-to-cover concepts have been explored, including:

- rigid attachment;
- contact/resting geometry;
- quick-attach concepts;
- mid-height attachment.

Positive cover retention is not yet fully proven.

Before unattended operation, the mechanical design must establish:

- how the cover is positively lifted;
- how it is retained while open;
- what prevents wind from shifting it;
- what prevents the cover from falling;
- what happens on power loss;
- what happens if the servo releases;
- whether the arm or cover can collide with the telescope.

Do not treat an unvalidated friction-only contact as safe for final unattended use.

---

# 30. Cover weight / wall thickness history

One later cover revision was approximately:

```text
225 mm diameter
160 mm high
```

Prior estimates suggested:

```text
5 mm shell -> roughly 0.9 kg class
10 mm shell -> roughly 1.7+ kg class
3–4 mm shell -> roughly 0.55–0.75 kg class
```

This motivated reducing the cover wall thickness and reinforcing only loaded regions.

General mechanical preference:

- keep the moving cover light;
- reinforce hinge/servo/arm attachment zones locally;
- avoid making the whole cover thick merely for strength.

---

# 31. Torque/load development philosophy

The servo geometry and cover attachment are still being optimized.

Do not hard-code assumptions about final lever arm or cover mass.

The software should make it easy to:

- change open position;
- change closed position;
- change speed;
- change acceleration;
- inspect load/current during a move;
- record peak load/current if practical.

The final mechanical geometry should be tuned empirically with the real cover attached.

---

# 32. Load telemetry

The ST3215 raw load value should not be displayed as though it were a directly calibrated torque reading.

Raw load values include direction/sign encoding and need correct decoding.

Until calibrated, label load as a relative/estimated value.

Do not claim a specific physical torque from raw load counts.

---

# 33. Startup behavior

Recommended boot sequence:

1. initialize logging;
2. load and validate Preferences/NVS settings;
3. initialize servo communication;
4. read servo identity/configuration;
5. validate critical ST3215 settings;
6. initialize sensors;
7. establish network connection;
8. determine cover state from physical sensors if available;
9. if state cannot be trusted, enter `UNKNOWN`;
10. do not move automatically unless safety logic explicitly requires it and enough state is known.

Never assume CLOSED merely because the last stored state was CLOSED.

---

# 34. Power-loss / reboot philosophy

A reboot can occur at any physical cover position.

After reboot:

- do not trust the previous state variable;
- read physical limit sensors if installed;
- read servo position;
- reconcile the two;
- if they disagree, enter `UNKNOWN` or `FAULT`;
- require explicit recovery/calibration if necessary.

The final unattended controller should have a deterministic recovery strategy for partial movement.

---

# 35. Rain-response behavior

Rain handling is expected to become a primary safety feature.

Likely priority:

```text
RAIN > normal user convenience
```

However, the controller must not blindly slam the cover closed onto an unstowed telescope.

Future logic should coordinate:

```text
rain detected
request telescope park
confirm safe state
close cover
confirm closed limit
```

If telescope state cannot be confirmed, the system should report a high-priority fault and follow the explicitly designed safety policy.

Do not invent an automatic destructive fallback.

---

# 36. OTA and remote maintenance

OTA firmware update support is desirable once basic functionality is stable.

OTA should not be the first feature implemented.

Before enabling unattended OTA:

- require authenticated/local-network access as appropriate;
- ensure interrupted update recovery is safe;
- avoid performing updates during enclosure motion;
- preserve settings across updates;
- document recovery flashing over USB.

---

Owner update-UX decision (2026-11-12): automatically obtain controller update
authorization from its own home-LAN webpage. Do not require users to type a USB
console key, pair a browser or save a credential. The bench implementation uses
a fresh boot-scoped token from a same-origin session endpoint. Keep explicit
install confirmation, Host/Origin/boot/transaction checks and signed image/hash
verification. This trusted-LAN policy grants update access to visitors who can
open that controller page; it is not independent per-user authentication. Never
expose the offline firmware signing key. Servo/motion maintenance safeguards and
production qualification remain separate requirements.

---

# 37. Logging

Useful logs:

- boot reason;
- firmware version;
- Wi-Fi status;
- servo configuration validation;
- requested commands;
- movement start/end;
- starting/target/final position;
- elapsed movement time;
- peak current/load;
- sensor state transitions;
- rain events;
- faults;
- recovery attempts.

Keep logs concise enough for embedded use.

---

# 38. Recommended implementation milestones

## Milestone 1 — clean servo driver

Implement:

- ping/read ID;
- position read;
- torque on/off;
- position command;
- speed;
- acceleration;
- voltage/temp/current/load reads;
- robust retry logic;
- critical configuration validation.

No web control required yet.

## Milestone 2 — cover controller

Implement:

- OPEN/CLOSE/STOP;
- state machine;
- configurable open/closed positions;
- timeout;
- wrong-direction detection;
- fault state.

## Milestone 3 — web UI

Implement:

- status page;
- Open/Close/Stop;
- telemetry;
- settings;
- calibration page.

## Milestone 4 — physical sensors

Add:

- OPEN sensor;
- CLOSED sensor;
- temperature/humidity;
- rain sensor.

## Milestone 5 — weather/safety automation

Add:

- rain-driven closure policy;
- sensor fault handling;
- restart recovery.

## Milestone 6 — Seestar integration

Add:

- telescope state query;
- park/stow request;
- wait-for-safe-state logic;
- coordinated close.

## Milestone 7 — hardening

Add:

- OTA;
- watchdog behavior;
- more complete logging;
- long-duration unattended testing;
- power-loss testing;
- obstruction testing.

---

# 39. Coding principles

Prefer:

- simple explicit state machines;
- clear enums;
- bounded retries;
- timeouts using `millis()` rather than blocking delays in production code;
- separation between hardware driver and business logic;
- defensive validation;
- fail-safe defaults;
- descriptive logs;
- testable components.

Avoid:

- long blocking loops in the final firmware;
- hidden EEPROM writes;
- direct servo access from HTML/web route handlers;
- magic numbers scattered throughout the code;
- assuming successful serial writes imply physical motion;
- assuming servo position alone proves cover position;
- copying Waveshare SC-servo code into ST3215 control paths.

---

# 40. Non-negotiable safety invariants

The following should be treated as project invariants:

1. **Never write SC-servo limits into the ST3215.**
2. **Never move automatically if critical servo configuration is invalid.**
3. **Never trust a failed serial read.**
4. **Never declare runaway motion from one bad telemetry sample.**
5. **Never treat servo shaft position as the only proof that the cover is physically open or closed once limit sensors exist.**
6. **Never close onto a telescope known to be in an unsafe orientation.**
7. **Never allow normal web routes to write arbitrary servo EEPROM.**
8. **On unexplained motion fault, stop movement and enter FAULT.**
9. **Preserve a local/manual recovery path.**
10. **The final system must be mechanically validated before unattended weather protection is trusted.**

---

# 41. Current project status

What has been proven:

- ESP32 board can be flashed from macOS;
- USB serial forwarding works;
- Python ST3215 SDK communication works;
- servo ID/model detection works;
- ST3215 configuration corruption was identified;
- known-good configuration was restored;
- bidirectional closed-loop motion works;
- speed control works;
- acceleration works;
- telemetry reads work with occasional transient bridge errors.

What is not yet proven:

- final PlatformIO firmware;
- final web UI;
- final arm geometry;
- final cover dimensions;
- final cradle geometry;
- full real-cover load;
- rain sensor choice/integration;
- physical open/closed sensors;
- unattended reliability;
- Seestar coordinated parking;
- long-term weather sealing;
- wind-load behavior;
- power-loss recovery.

---

# 42. Guidance for Codex / future agents

For Autodesk Fusion access, read [docs/FUSION_MCP.md](docs/FUSION_MCP.md).
It records the working local MCP endpoint, session handshake, sandbox-access
requirements, read-only inspection, editing/export workflow, and known pitfalls.
Check Fusion's built-in local server before concluding that missing agent tools
or plugins mean Fusion is unavailable.

When editing this project:

- read this file before making architectural changes;
- preserve the ST3215-specific safety constraints;
- do not reintroduce Waveshare SC assumptions;
- favor small, testable changes;
- keep hardware control behind a dedicated driver/controller layer;
- update relevant docs when hardware assumptions change;
- if current CAD contradicts historical dimensions in this file, current CAD wins;
- if real bench measurements contradict a theoretical assumption, preserve the measured behavior and document it;
- do not silently change EEPROM configuration;
- before programming the servo, show the exact proposed register changes and
  wait for the user's approval (explicit user instruction, 2026-10-27);
- for the next controller update, try OTA first as requested on 2026-10-27;
  check actual receiver availability and maintenance eligibility, and report
  any blocker before falling back to USB; do not bypass OTA admission checks;
- developer OTA supports recovery updates while faulted or uncalibrated
  (explicit user request, 2026-10-29). New receivers advertise
  `development-recovery`: require idle motion, fresh verified torque OFF,
  stable raw 0–4095 feedback, model 777, authentication and maintenance locks;
  calibration, its saved range and critical configuration readiness do not gate
  firmware recovery. No implicit torque release or servo configuration writes.
  Older receivers keep their actual policy until bootstrapped; production keeps
  CLOSED admission. Do not fabricate calibration or bypass installed admission.
- do not broaden scope into unrelated observatory features unless requested;
- prioritize getting a reliable telescope-cover controller working before adding advanced integrations.

