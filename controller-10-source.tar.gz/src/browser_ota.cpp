#ifdef COVER_BROWSER_OTA
#include "browser_ota.h"
#include "ota_service.h"
#include "browser_ota_protocol.h"
#include "browser_generated.h"
#include "bounded_web_server.h"
#include "web_control.h"
#include "diagnostics.h"
#include "firmware_version.h"
#include "network_setup.h"
#include "settings.h"
#include "release_signature.h"
#include <WiFi.h>
#include <Preferences.h>
#include <esp_ota_ops.h>
#include <mbedtls/sha256.h>
#include <atomic>
namespace cover { namespace {
BoundedWebServer* web=nullptr;
portMUX_TYPE mux=portMUX_INITIALIZER_UNLOCKED;
enum class Phase {Idle,Preparing,Receiving,Verified,Committing,Rebooting,Failed,Cancelled};
enum class Op {Start,Chunk,Finish};
struct BrowserCommand {Op op=Op::Start;BrowserManifest manifest;uint32_t offset=0,generation=0;uint16_t size=0;uint8_t data[kBrowserChunk]={};};
QueueHandle_t queue=nullptr;TaskHandle_t workerHandle=nullptr;
Phase phase=Phase::Idle;const char* reason="none";uint32_t consumed=0,total=0;
char transaction[33]={},sessionToken[65]={},ackTransaction[33]={};uint32_t ackEnd=0;
std::atomic<bool> cancelled{false};
const char* phaseName(Phase p){switch(p){case Phase::Idle:return "idle";case Phase::Preparing:return "preparing";case Phase::Receiving:return "receiving";case Phase::Verified:return "verified";case Phase::Committing:return "committing";case Phase::Rebooting:return "rebooting";case Phase::Failed:return "failed";default:return "cancelled";}}
bool busy(Phase p){return p==Phase::Preparing||p==Phase::Receiving||p==Phase::Verified||p==Phase::Committing||p==Phase::Rebooting;}
void setPhase(Phase p,const char* why="none"){portENTER_CRITICAL(&mux);phase=p;reason=why;portEXIT_CRITICAL(&mux);diagnosticEvent("BROWSER OTA phase=%s reason=%s",phaseName(p),why);}
bool allowed(){return queue&&otaBrowserAccepted()&&WiFi.getMode()==WIFI_STA&&WiFi.status()==WL_CONNECTED;}
bool ownPage(bool session=false){
 const String host=WiFi.localIP().toString(),origin=web->header("Origin");
 const bool originOk=session?(origin.length()==0||origin=="http://"+host):origin=="http://"+host;
 if(!allowed()||networkPortalRequest(*web)||web->hostHeader()!=host||!originOk){web->send(403,"text/plain","Use the controller's home-network page");return false;}
 if(session){if(web->header("X-Update-Session")!="1"){web->send(403,"text/plain","Session request required");return false;}return true;}
 const String key=web->header("X-Update-Key");
 if(web->header("X-Update-Boot")!=diagnosticsBootId()||key.length()!=64||!otaEqual(reinterpret_cast<const uint8_t*>(key.c_str()),reinterpret_cast<const uint8_t*>(sessionToken),64)){
  web->send(403,"text/plain","Controller restarted; refresh the page");return false;
 }
 return true;
}
// Hash exact persistent application + calibration bytes, including absent keys.
// No decoded credentials or settings leave the device. Never migrates settings.
bool settingsHash(uint8_t hash[32]){
 mbedtls_sha256_context sha;mbedtls_sha256_init(&sha);bool ok=mbedtls_sha256_starts_ret(&sha,0)==0;
 for(const char* name:{"cover-app","cover-cal"}){
  Preferences p;uint8_t bytes[382];
  if(!p.begin(name,false)){ok=false;break;}
  const bool present=p.isKey("v1");const size_t n=present?p.getBytesLength("v1"):0;
  const uint8_t tag=present?1:0;
  ok=ok&&n<=sizeof(bytes)&&(!present||(n>0&&p.getBytes("v1",bytes,n)==n));p.end();
  if(!ok)break;
  ok=mbedtls_sha256_update_ret(&sha,&tag,1)==0&&mbedtls_sha256_update_ret(&sha,bytes,n)==0;
 }
 ok=ok&&mbedtls_sha256_finish_ret(&sha,hash)==0;mbedtls_sha256_free(&sha);return ok;
}
bool checkpointSettings(const uint8_t target[32]){uint8_t hash[32],check[32],savedTarget[32];if(!settingsHash(hash))return false;Preferences p;if(!p.begin("browser-ota",false))return false;
 const bool ok=p.putBytes("target",target,32)==32&&p.getBytes("target",savedTarget,32)==32&&otaEqual(target,savedTarget,32)&&p.putBytes("settings",hash,32)==32&&p.getBytes("settings",check,32)==32&&otaEqual(hash,check,32);p.end();return ok;}
bool responseReady(){
 Phase p;uint32_t bytes;portENTER_CRITICAL(&mux);p=phase;bytes=consumed;portEXIT_CRITICAL(&mux);
 if(p!=Phase::Receiving||cancelled||strcmp(transaction,ackTransaction)||bytes>ackEnd){web->send(409,"text/plain","Write unconfirmed; inspect update outcome");return true;}
 if(bytes!=ackEnd)return false;
 web->sendHeader("Cache-Control","no-store");web->send(200,"application/json",String("{\"transaction\":\"")+ackTransaction+"\",\"received\":"+String(bytes)+"}");return true;
}
void worker(void*){
 for(;;){
  noteTaskStack(DiagnosticTask::Ota);BrowserCommand command;
  if(xQueueReceive(queue,&command,pdMS_TO_TICKS(20))!=pdTRUE)continue;
  if(command.op!=Op::Start)continue;
  const BrowserManifest manifest=command.manifest;
  OtaMaintenanceRequirements requirements;requirements.closedCover=true;requirements.startupAccepted=otaBrowserAccepted();
  // Retain the existing conservative development budgets pending full-load qualification.
  requirements.minimumInternalHeap=98304;requirements.minimumLargestBlock=65536;
  const auto lease=requestOtaMaintenance(requirements,command.generation);
  const auto* running=esp_ota_get_running_partition();const auto* target=esp_ota_get_next_update_partition(nullptr);
  esp_ota_handle_t handle=0;bool live=false,selected=false,entered=false;const char* failure="admission";
  auto clear=[&](){return lease&&maintenanceReady(lease)&&!cancelled.load()&&allowed();};
  uint32_t received=0;mbedtls_sha256_context sha;mbedtls_sha256_init(&sha);
  OtaRecord record;record.size=manifest.size;memcpy(record.source,manifest.source,32);memcpy(record.target,manifest.target,32);memcpy(record.sha256,manifest.sha,32);otaUnhex(transaction,32,record.transaction);
  record.sourceSlot=running?running->address:0;record.targetSlot=target?target->address:0;
  do{
   if(!lease||!running||!target||target==running||target->size!=kOtaSlotBytes||!browserSourceAllowed(manifest,COVER_BROWSER_BUILD,esp_ota_get_app_description()->app_elf_sha256))break;
   const uint32_t waitAt=millis();while(!maintenanceReady(lease)&&uint32_t(millis()-waitAt)<3000&&!cancelled){if(maintenanceStatus().phase==MaintenancePhase::Revoked)break;vTaskDelay(pdMS_TO_TICKS(5));}
   if(!clear())break;
   if(mbedtls_sha256_starts_ret(&sha,0)){failure="digest_init";break;}
   setPhase(Phase::Receiving);const uint32_t started=millis();uint32_t lastData=started;bool finished=false;
   while(clear()&&uint32_t(millis()-started)<600000&&uint32_t(millis()-lastData)<10000){
    noteTaskStack(DiagnosticTask::Ota);
    if(xQueueReceive(queue,&command,pdMS_TO_TICKS(20))!=pdTRUE)continue;
    if(!clear()){failure="maintenance_clearance_lost";break;}
    if(command.op==Op::Finish){finished=received==manifest.size;break;}
    if(command.op!=Op::Chunk||command.offset!=received||!command.size||command.size>manifest.size-received){failure="chunk_offset_or_length";break;}
    if(!live){
     if(!browserPrefixValid(command.data,command.size,manifest)){failure="wrong_controller_image";break;}
     if(esp_ota_begin(target,OTA_WITH_SEQUENTIAL_WRITES,&handle)!=ESP_OK){failure="flash_begin";break;}live=true;
    }
    if(!clear()||esp_ota_write(handle,command.data,command.size)!=ESP_OK||mbedtls_sha256_update_ret(&sha,command.data,command.size)){failure="flash_write_or_clearance";break;}
    received+=command.size;lastData=millis();portENTER_CRITICAL(&mux);consumed=received;portEXIT_CRITICAL(&mux);
   }
   if(!finished||!clear()){failure="cancelled_clearance_or_timeout";break;}
   uint8_t hash[32];if(!live||mbedtls_sha256_finish_ret(&sha,hash)||!otaEqual(hash,manifest.sha,32)){failure="image_hash";break;}
   const auto end=esp_ota_end(handle);live=false;if(end!=ESP_OK){failure="image_validation";break;}
   setPhase(Phase::Verified);if(!clear()||!checkpointSettings(manifest.target)){failure="settings_checkpoint";break;}
   struct Commit {
    decltype(clear)& ready;MaintenanceLease lease;const esp_partition_t* target;bool& entered;
    bool clearance(){return ready();}bool cancelled(){return cover::cancelled.load();}
    bool persist(OtaRecord& r){return otaBrowserSaveRecord(r);}
    bool enterCommit(){if(cover::cancelled.load()||!beginOtaCommit(lease))return false;entered=true;setPhase(Phase::Committing);return true;}
    bool selectBoot(){return esp_ota_set_boot_partition(target)==ESP_OK;}
   } commit{clear,lease,target,entered};
   if(!commitOtaImage(commit,record)){failure=entered?"activation_unconfirmed":"commit_rejected";break;}
   selected=true;record.activationConfirmed=true;setPhase(Phase::Rebooting,otaBrowserSaveRecord(record)?"none":"activation_unconfirmed");
   vTaskDelay(pdMS_TO_TICKS(1000));ESP.restart();
  }while(false);
  if(live)esp_ota_abort(handle);
  mbedtls_sha256_free(&sha);
  if(selected){setPhase(Phase::Failed,"restart_failed");for(;;)vTaskDelay(pdMS_TO_TICKS(1000));}
  setPhase(cancelled?Phase::Cancelled:Phase::Failed,failure);
  if(entered){record.outcome=OtaOutcome::Unconfirmed;otaBrowserSaveRecord(record);}
  // Admission failure must not overwrite an earlier successful handoff.
  if(lease){confirmMaintenanceCleanup(lease);requestMaintenanceRelease(lease);while(sameLease(maintenanceStatus().lease,lease))vTaskDelay(pdMS_TO_TICKS(10));}
 }
}
} // namespace
bool browserOtaSettingsMatch(){uint8_t saved[32],actual[32],target[32];Preferences p;if(!p.begin("browser-ota",false))return false;
 if(!p.isKey("target")){p.end();return true;} // First bootstrap through the existing desktop receiver.
 if(p.getBytes("target",target,32)!=32){p.end();return false;}
 if(!otaEqual(target,esp_ota_get_app_description()->app_elf_sha256,32)){p.end();return true;}
 const bool ok=p.getBytesLength("settings")==32&&p.getBytes("settings",saved,32)==32;p.end();return ok&&settingsHash(actual)&&otaEqual(saved,actual,32);}
void beginBrowserOta(){uint8_t token[32];esp_fill_random(token,sizeof(token));otaHex(token,32,sessionToken);
 queue=xQueueCreate(1,sizeof(BrowserCommand));if(queue&&xTaskCreatePinnedToCore(worker,"browser-ota",8192,nullptr,1,&workerHandle,0)!=pdPASS){vQueueDelete(queue);queue=nullptr;}}
bool browserOtaReady(){return queue&&workerHandle;}
String browserOtaStatusJson(){Phase p;const char* why;uint32_t bytes,size;portENTER_CRITICAL(&mux);p=phase;why=reason;bytes=consumed;size=total;portEXIT_CRITICAL(&mux);
 return String("{\"protocol\":\"browser-signed-v1\",\"build\":")+String(COVER_BROWSER_BUILD)+",\"version\":\""+COVER_VERSION+"\",\"available\":"+(allowed()?"true":"false")+",\"startup\":\""+(otaBrowserAccepted()?"accepted":"checking")+"\",\"phase\":\""+phaseName(p)+"\",\"reason\":\""+why+"\",\"transaction\":\""+transaction+"\",\"received\":"+String(bytes)+",\"total\":"+String(size)+",\"active\":"+(busy(p)?"true":"false")+",\"chunk_bytes\":768,\"chunk_ack\":\"consumed-offset-v1\",\"boot_id\":\""+diagnosticsBootId()+"\",\"firmware_id\":\""+firmwareId()+"\",\"generation\":"+String(maintenanceStatus().controlGeneration)+",\"settings_preserved\":"+(browserOtaSettingsMatch()?"true":"false")+",\"handoff\":"+otaStatusJson()+"}";
}
void registerBrowserOtaRoutes(BoundedWebServer& server){web=&server;
 server.on("/api/update/status",HTTP_GET,[]{web->sendHeader("Cache-Control","no-store");web->send(200,"application/json",browserOtaStatusJson());});
 server.on("/api/update/session",HTTP_GET,[]{if(!ownPage(true))return;web->sendHeader("Cache-Control","no-store");web->send(200,"application/json",String("{\"boot\":\"")+diagnosticsBootId()+"\",\"update_token\":\""+sessionToken+"\"}");});
 server.on("/api/update/start",HTTP_POST,[]{
  if(!ownPage())return;
  if(!betaAcknowledged()||web->arg("confirm")!="install"){web->send(400,"text/plain","Explicit install confirmation and beta acceptance required");return;}
  Phase p;portENTER_CRITICAL(&mux);p=phase;portEXIT_CRITICAL(&mux);if(busy(p)||maintenanceStatus().locked()){web->send(409,"text/plain","Maintenance already active");return;}
  BrowserCommand c;const String text=web->arg("manifest"),signature=web->arg("signature"),generation=web->arg("generation");uint8_t sig[64];
  c.generation=maintenanceStatus().controlGeneration;
  if(generation!=String(c.generation)||!parseBrowserManifest(text.c_str(),text.length(),c.manifest)||!browserSourceAllowed(c.manifest,COVER_BROWSER_BUILD,esp_ota_get_app_description()->app_elf_sha256)||signature.length()!=128||!otaUnhex(signature.c_str(),128,sig)||!verifyReleaseP256(reinterpret_cast<const uint8_t*>(text.c_str()),text.length(),sig,browserPublicPoint)){
   web->send(400,"text/plain","Signed controller manifest invalid or source changed");return;
  }
  uint8_t tx[16];esp_fill_random(tx,16);otaHex(tx,16,transaction);cancelled=false;portENTER_CRITICAL(&mux);consumed=0;total=c.manifest.size;portEXIT_CRITICAL(&mux);setPhase(Phase::Preparing);
  if(xQueueSend(queue,&c,0)!=pdTRUE){setPhase(Phase::Failed,"queue_busy");web->send(409,"text/plain","Worker busy");return;}web->send(202,"text/plain",transaction);
 });
 server.on("/api/update/chunk",HTTP_POST,[]{
  if(!ownPage())return;
  Phase p;uint32_t offset,size;portENTER_CRITICAL(&mux);p=phase;offset=consumed;size=total;portEXIT_CRITICAL(&mux);
  const String data=web->arg("data");BrowserCommand c;c.op=Op::Chunk;c.offset=offset;
  if(p!=Phase::Receiving||web->arg("transaction")!=transaction||web->arg("offset")!=String(offset)||!data.length()||data.length()%2||data.length()>2*kBrowserChunk||data.length()/2>size-offset||(offset==0&&data.length()/2<kOtaPrefixBytes)||!otaUnhex(data.c_str(),data.length(),c.data)){
   web->send(409,"text/plain","Wrong transaction, offset or chunk");return;
  }
  c.size=data.length()/2;if(xQueueSend(queue,&c,0)!=pdTRUE){web->send(409,"text/plain","Worker backpressure");return;}
  memcpy(ackTransaction,transaction,sizeof(ackTransaction));ackEnd=offset+c.size;web->deferResponse(responseReady);
 });
 server.on("/api/update/finish",HTTP_POST,[]{if(!ownPage())return;
  Phase p;uint32_t bytes,size;portENTER_CRITICAL(&mux);p=phase;bytes=consumed;size=total;portEXIT_CRITICAL(&mux);
  if(p!=Phase::Receiving||web->arg("transaction")!=transaction||bytes!=size){web->send(409,"text/plain","Incomplete transaction");return;}
  BrowserCommand c;c.op=Op::Finish;if(xQueueSend(queue,&c,0)!=pdTRUE){web->send(409,"text/plain","Worker busy");return;}web->send(202,"text/plain","verifying");
 });
 server.on("/api/update/cancel",HTTP_POST,[]{if(!ownPage())return;portENTER_CRITICAL(&mux);const bool ok=busy(phase)&&phase!=Phase::Committing&&phase!=Phase::Rebooting&&web->arg("transaction")==transaction;if(ok)cancelled=true;portEXIT_CRITICAL(&mux);web->send(ok?202:409,"text/plain",ok?"Cancelling":"No cancellable transaction");});
}
}
#endif
