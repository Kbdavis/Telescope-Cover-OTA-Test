#ifdef COVER_WEB_CONTROL
#include "ota_service.h"
#include "browser_ota.h"
#include "ota_auth.h"
#include "ota_memory_probe.h"
#include "web_control.h"
#include "diagnostics.h"
#include "network_setup.h"
#include "settings.h"
#ifdef COVER_OTA_FLASH_PROBE
#include "ota_flash_probe.h"
#endif
#ifdef COVER_OTA_RESOURCE_PROBE
#include "ota_resource_probe.h"
#endif
#include <WebServer.h>
#include <WiFiUdp.h>
#include <Preferences.h>
#include <esp_ota_ops.h>
#include <soc/rtc_wdt.h>
#include <mbedtls/md.h>
#include <mbedtls/md5.h>
#include <mbedtls/sha256.h>
#include <lwip/sockets.h>
#include <atomic>
#include <memory>
#ifdef COVER_OTA_DEVELOPMENT
#if defined(COVER_OTA_FLASH_PROBE) || defined(COVER_OTA_RESOURCE_PROBE) || defined(COVER_USB_MEMORY_PROBE) || defined(COVER_OTA_COMPILE_TEST) || defined(COVER_SETTLE_SAMPLES)
#error Development OTA cannot be combined with a probe/test profile
#endif
#if __has_include("ota_dev_local.h")
#include "ota_dev_local.h"
#else
#error Run tools/ota_dev_setup.py before building web_control_dev
#endif
#elif !defined(COVER_BROWSER_OTA) && !defined(COVER_MULTITURN_USB) && !defined(COVER_WEB_READ_ONLY) && __has_include("ota_local.h")
#include "ota_local.h"
#endif
#ifdef COVER_OTA_FLASH_PROBE
#if __has_include("ota_flash_probe_local.h")
#include "ota_flash_probe_local.h"
#endif
#ifndef COVER_OTA_PROBE_SECRET
#define COVER_OTA_PROBE_SECRET ""
#endif
#ifndef COVER_OTA_PROBE_MIN_HEAP
#define COVER_OTA_PROBE_MIN_HEAP 0
#endif
#ifndef COVER_OTA_PROBE_MIN_BLOCK
#define COVER_OTA_PROBE_MIN_BLOCK 0
#endif
#if defined(COVER_OTA_RESOURCE_PROBE)
#error Select one OTA experiment only
#endif
#endif
#ifndef COVER_OTA_SECRET
#define COVER_OTA_SECRET ""
#endif
#ifndef COVER_OTA_RECEIVER_ENABLED
#define COVER_OTA_RECEIVER_ENABLED 0
#endif
#ifndef COVER_OTA_MIN_INTERNAL_HEAP
#define COVER_OTA_MIN_INTERNAL_HEAP 0
#endif
#ifndef COVER_OTA_MIN_LARGEST_BLOCK
#define COVER_OTA_MIN_LARGEST_BLOCK 0
#endif
#ifdef COVER_MULTITURN_USB
static_assert(!COVER_OTA_RECEIVER_ENABLED && sizeof(COVER_OTA_SECRET)==1,
 "Production multi-turn USB must not enable an OTA receiver or embed its credential");
#endif
#ifdef COVER_WEB_READ_ONLY
static_assert(!COVER_OTA_RECEIVER_ENABLED && sizeof(COVER_OTA_SECRET)==1,
 "Read-only web preview must not enable OTA or embed a credential");
#endif
#ifdef COVER_OTA_DEVELOPMENT
static_assert(COVER_OTA_RECEIVER_ENABLED && sizeof(COVER_OTA_SECRET)-1>=32 && sizeof(COVER_OTA_SECRET)-1<=128,
 "Development OTA requires an enabled receiver and 32..128-byte local credential");
static_assert(COVER_OTA_MIN_INTERNAL_HEAP>0 && COVER_OTA_MIN_LARGEST_BLOCK>0,
 "Development OTA requires explicit memory guards");
static const char coverOtaDevMarker[]="TCOTA-DEV-LOCAL-1";
#endif

// Arduino calls this before setup(). A reset during a pending first boot must
// reach the rollback-enabled bootloader instead of accepting an untested image.
extern "C" bool verifyRollbackLater(){
 rtc_wdt_protect_off();rtc_wdt_set_stage(RTC_WDT_STAGE0,RTC_WDT_STAGE_ACTION_RESET_RTC);
 rtc_wdt_set_time(RTC_WDT_STAGE0,45000);rtc_wdt_enable();rtc_wdt_protect_on();return true;
}
namespace cover {
extern const uint8_t coverOtaDescriptor[64] __attribute__((section(".rodata_custom_desc"),used,aligned(4)))={
 'T','C','O','T','A','0','0','1',
 't','e','l','e','s','c','o','p','e','-','c','o','v','e','r',0,
#if defined(COVER_SETTLE_SAMPLES) || defined(COVER_OTA_COMPILE_TEST) || defined(COVER_OTA_RESOURCE_PROBE) || defined(COVER_OTA_FLASH_PROBE) || defined(COVER_USB_MEMORY_PROBE) || defined(COVER_WEB_READ_ONLY)
 't','e','s','t','_','p','r','o','f','i','l','e',0,0,0,0,
#elif defined(COVER_MULTITURN_USB)
 'm','u','l','t','i','t','u','r','n','_','u','s','b',0,0,0,
#else
 'w','e','b','_','c','o','n','t','r','o','l',0,0,0,0,0,
#endif
 1,0,5,0,1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
bool otaSha256(const void* data,size_t n,uint8_t out[32]){return mbedtls_sha256_ret(static_cast<const uint8_t*>(data),n,out,0)==0;}
bool otaMd5(const void* data,size_t n,uint8_t out[16]){return mbedtls_md5_ret(static_cast<const uint8_t*>(data),n,out)==0;}
bool otaHmac(const uint8_t* key,size_t keySize,const void* data,size_t n,uint8_t out[32]){
 return mbedtls_md_hmac(mbedtls_md_info_from_type(MBEDTLS_MD_SHA256),key,keySize,static_cast<const uint8_t*>(data),n,out)==0;
}
namespace {
enum class Phase { Unavailable,Idle,Preparing,Armed,Authenticating,Connecting,Receiving,Verified,Committing,Rebooting,Failed,Cancelled };
const char* phaseName(Phase p){switch(p){case Phase::Idle:return "idle";case Phase::Preparing:return "preparing";case Phase::Armed:return "armed";
 case Phase::Authenticating:return "authenticating";case Phase::Connecting:return "connecting";case Phase::Receiving:return "receiving";
 case Phase::Verified:return "verified";case Phase::Committing:return "committing";case Phase::Rebooting:return "rebooting";
 case Phase::Failed:return "failed";case Phase::Cancelled:return "cancelled";default:return "unavailable";}}
portMUX_TYPE otaMux=portMUX_INITIALIZER_UNLOCKED;
Phase phase=Phase::Unavailable;const char* reason="release_gate";
bool active=false,queued=false,webReady=false,configured=false,startupPending=false,commitStarted=false;
std::atomic<bool> accepted{false},startupFinished{false};
bool journalPresent=false,journalReadable=false,workerCreated=false;
std::atomic<bool> cancelRequested{false};
const char* startup="checking";
uint32_t startupAt=0,peer=0,received=0;
OtaManifest pendingManifest;OtaRecord lastRecord;char transactionHex[33]={};
OtaChallenge challenge;
#ifdef COVER_OTA_FLASH_PROBE
const char* secret=COVER_OTA_PROBE_SECRET;
bool probeConfigured=false,probeAttempted=false,probeVerified=false;
OtaRecord probeRecord;
#else
const char* secret=COVER_OTA_SECRET;
#endif
void setPhase(Phase value,const char* why="none"){
 portENTER_CRITICAL(&otaMux);phase=value;reason=why;portEXIT_CRITICAL(&otaMux);
 diagnosticEvent("OTA phase=%s reason=%s",phaseName(value),why);
}
void randomHex(char* out){uint8_t bytes[16];esp_fill_random(bytes,sizeof(bytes));otaHex(bytes,sizeof(bytes),out);}
bool saveRecord(const OtaRecord& record){
 uint8_t bytes[kOtaRecordBytes],check[kOtaRecordBytes];encodeOtaRecord(record,bytes);
 Preferences prefs;if(!prefs.begin("cover-ota",false))return false;
 bool ok=prefs.putBytes("v1",bytes,sizeof(bytes))==sizeof(bytes) && prefs.getBytesLength("v1")==sizeof(bytes) &&
  prefs.getBytes("v1",check,sizeof(check))==sizeof(check) && !memcmp(bytes,check,sizeof(bytes));prefs.end();
 if(ok){portENTER_CRITICAL(&otaMux);lastRecord=record;journalPresent=true;portEXIT_CRITICAL(&otaMux);}return ok;
}
bool loadRecord(){
 Preferences prefs;if(!prefs.begin("cover-ota",false))return false;
 if(!prefs.isKey("v1")){prefs.end();return true;}
 uint8_t bytes[kOtaRecordBytes];bool ok=prefs.getBytesLength("v1")==sizeof(bytes) && prefs.getBytes("v1",bytes,sizeof(bytes))==sizeof(bytes);
 prefs.end();if(!ok || !decodeOtaRecord(bytes,sizeof(bytes),lastRecord))return false;journalPresent=true;return true;
}
void disableStartupWatchdog(){rtc_wdt_protect_off();rtc_wdt_disable();rtc_wdt_protect_on();}
bool pinnedLayout(){
 struct Expected {uint8_t type,subtype;uint32_t address,size;const char* label;};
 const Expected expected[]={{1,2,0x9000,0x5000,"nvs"},{1,0,0xe000,0x2000,"otadata"},{0,0x10,0x10000,0x140000,"app0"},
  {0,0x11,0x150000,0x140000,"app1"},{1,0x82,0x290000,0x160000,"spiffs"},{1,3,0x3f0000,0x10000,"coredump"}};
 for(const auto& e:expected){const auto* p=esp_partition_find_first(esp_partition_type_t(e.type),esp_partition_subtype_t(e.subtype),e.label);
  if(!p || p->address!=e.address || p->size!=e.size || p->encrypted)return false;}
 unsigned count=0;auto it=esp_partition_find(ESP_PARTITION_TYPE_ANY,ESP_PARTITION_SUBTYPE_ANY,nullptr);
 while(it){++count;it=esp_partition_next(it);}return count==6;
}
bool currentAccepted(){return accepted && startupFinished;}
bool receiverAllowed(){
#if defined(COVER_OTA_RESOURCE_PROBE) || defined(COVER_OTA_FLASH_PROBE) || defined(COVER_USB_MEMORY_PROBE)
 return false; // Unconditional even if a local config accidentally enables OTA.
#else
 return configured && currentAccepted() && WiFi.getMode()==WIFI_STA && WiFi.status()==WL_CONNECTED;
#endif
}
#ifdef COVER_OTA_FLASH_PROBE
bool probeControlAllowed(){return probeConfigured && workerCreated && currentAccepted() && WiFi.getMode()==WIFI_STA && WiFi.status()==WL_CONNECTED;}
#endif
#ifdef COVER_OTA_RESOURCE_PROBE
bool probeSafe(uint32_t epoch){
 if(!epoch || diagnosticsMetricsEpoch()!=epoch || !currentAccepted() || WiFi.getMode()!=WIFI_STA || WiFi.status()!=WL_CONNECTED)return false;
 const auto s=webStatus();return s.ready && s.calibrated && !s.dirty && !s.moving && !s.holding && s.torqueValid && !s.torque && !maintenanceStatus().locked();
}
// No network socket, SDK flash API or journal operation is reachable here.
// Use the production stream validator with a digest-only sink, not Flash.
bool probeResources(uint32_t epoch,uint8_t* buffer){
 DiagnosticsWork work(epoch);if(!work || !probeSafe(epoch))return false;
 const auto manifest=otaProbeManifest();
 struct DigestSink {
  uint32_t epoch;const OtaManifest& manifest;mbedtls_sha256_context sha;mbedtls_md5_context md5;
  DigestSink(uint32_t e,const OtaManifest& m):epoch(e),manifest(m){mbedtls_sha256_init(&sha);mbedtls_md5_init(&md5);}
  ~DigestSink(){mbedtls_sha256_free(&sha);mbedtls_md5_free(&md5);}
  bool clearance(){return probeSafe(epoch);}
  bool begin(){return mbedtls_sha256_starts_ret(&sha,0)==0 && mbedtls_md5_starts_ret(&md5)==0;}
  bool write(const uint8_t* data,size_t n){return mbedtls_sha256_update_ret(&sha,data,n)==0 && mbedtls_md5_update_ret(&md5,data,n)==0;}
  bool finish(){uint8_t sh[32],md[16];return mbedtls_sha256_finish_ret(&sha,sh)==0 && mbedtls_md5_finish_ret(&md5,md)==0 && otaEqual(sh,manifest.sha256,32) && otaEqual(md,manifest.md5,16);}
 } sink(epoch,manifest);
 OtaImageStream<DigestSink> stream(manifest,sink);
 for(uint32_t offset=0;offset<manifest.size;offset+=1024){
  if(!probeSafe(epoch))return false;
  if(!otaProbeBlock(offset,buffer,1024) || !stream.consume(buffer,1024))return false;
  noteTaskStack(DiagnosticTask::Ota);vTaskDelay(pdMS_TO_TICKS(1));
 }
 const bool ok=stream.finish();noteTaskStack(DiagnosticTask::Ota);return ok;
}
#endif
// MSG_DONTWAIT avoids WiFiClient::write's ten-second retry path. Every caller
// checks clearance between chunks; ACK/result writes have a separate deadline.
bool sendBounded(WiFiClient& client,const char* text){
 size_t used=0,n=strlen(text);uint32_t start=millis();
 while(used<n && uint32_t(millis()-start)<200){int r=::send(client.fd(),text+used,n-used,MSG_DONTWAIT);
  if(r>0)used+=r;else if(r<0 && errno!=EAGAIN && errno!=EWOULDBLOCK && errno!=EINTR)return false;
  else vTaskDelay(pdMS_TO_TICKS(1));}
 return used==n;
}
// Exactly one owner task touches UDP, TCP, NVS transaction checkpoints and
// esp_ota_* transfer APIs. HTTP can enqueue/cancel and read snapshots only.
void __attribute__((unused)) receiverWorker(void*){
 WiFiUDP udp;WiFiClient client;uint8_t buffer[1024];
#ifdef COVER_OTA_RESOURCE_PROBE
 OtaProbeSchedule probeSchedule;uint32_t probeCycles=0;
#endif
 for(;;){
  noteTaskStack(DiagnosticTask::Ota);
#ifdef COVER_OTA_RESOURCE_PROBE
  const uint32_t epoch=diagnosticsMetricsEpoch();
  if(probeSchedule.due(millis(),epoch,probeSafe(epoch))){
   DiagnosticsWork work(epoch);
   if(work){const bool ok=probeResources(epoch,buffer);
    if(probeSafe(epoch)){
     if(!ok)setPhase(Phase::Unavailable,"resource_probe_failed");
     diagnosticLog("OTA RESOURCE probe cycle=%lu bytes=%lu result=%s epoch=%lu scope=synthetic-no-flash-no-network",(unsigned long)++probeCycles,(unsigned long)kOtaProbeBytes,ok?"ok":"failed",(unsigned long)epoch);}}
  }
  vTaskDelay(pdMS_TO_TICKS(20));continue; // Cannot dequeue or enter real transfer.
#endif
  bool take=false;OtaManifest manifest;uint32_t host=0;
  portENTER_CRITICAL(&otaMux);if(queued){manifest=pendingManifest;host=peer;queued=false;take=true;}portEXIT_CRITICAL(&otaMux);
  if(!take){vTaskDelay(pdMS_TO_TICKS(20));continue;}
  otaMemoryTransfer(true);
  OtaMaintenanceRequirements requirements;requirements.recovery=manifest.developmentRecovery;
  requirements.closedCover=!(manifest.developmentStationary||manifest.developmentRecovery);requirements.startupAccepted=currentAccepted();
  requirements.minimumInternalHeap=COVER_OTA_MIN_INTERNAL_HEAP;requirements.minimumLargestBlock=COVER_OTA_MIN_LARGEST_BLOCK;
#ifdef COVER_OTA_FLASH_PROBE
  requirements.minimumInternalHeap=COVER_OTA_PROBE_MIN_HEAP;requirements.minimumLargestBlock=COVER_OTA_PROBE_MIN_BLOCK;
#endif
  const MaintenanceLease lease=requestOtaMaintenance(requirements,manifest.controlGeneration);
  const esp_partition_t* target=esp_ota_get_next_update_partition(nullptr);const auto* running=esp_ota_get_running_partition();
  esp_ota_handle_t handle=0;bool handleLive=false,selected=false,commitEntered=false;const char* failure="admission";
#ifdef COVER_OTA_FLASH_PROBE
  bool verifiedWithoutActivation=false;
#endif
  OtaRecord record;record.size=manifest.size;memcpy(record.target,manifest.elf,32);memcpy(record.sha256,manifest.sha256,32);
  memcpy(record.source,esp_ota_get_app_description()->app_elf_sha256,32);
  portENTER_CRITICAL(&otaMux);otaUnhex(transactionHex,32,record.transaction);portEXIT_CRITICAL(&otaMux);
  record.sourceSlot=running?running->address:0;record.targetSlot=target?target->address:0;
  auto clear=[&](){return lease && maintenanceReady(lease) && !cancelRequested.load();};
  mbedtls_sha256_context sha;mbedtls_md5_context md5;mbedtls_sha256_init(&sha);mbedtls_md5_init(&md5);
  do{
   if(!lease || !target || !running || target==running || !otaSlot(target->address) || !otaSlot(running->address) || target->size!=kOtaSlotBytes || running->size!=kOtaSlotBytes)break;
#ifdef COVER_OTA_FLASH_PROBE
   // Protect any existing candidate/fallback. The host additionally archives
   // and verifies the ENTIRE target slot before this one-shot experiment.
   const auto* boot=esp_ota_get_boot_partition();uint8_t header[kOtaPrefixBytes];
   if(!boot || esp_partition_read(target,0,header,sizeof(header))!=ESP_OK ||
      !otaProbeTargetAllowed(running->address,boot->address,target->address,running->size,target->size,header,sizeof(header))){failure="probe_slot_guard_or_not_erased";break;}
#endif
   uint32_t at=millis();while(!maintenanceReady(lease) && uint32_t(millis()-at)<3000 && !cancelRequested.load()){
    if(maintenanceStatus().phase==MaintenancePhase::Revoked)break;
    vTaskDelay(pdMS_TO_TICKS(5));}
   if(!clear())break;
   if(!udp.begin(3232)){failure="udp_bind";break;}
   setPhase(Phase::Armed);at=millis();uint32_t authAt=0;uint16_t callbackPort=0,udpPort=0;char nonce[33]={};bool authenticated=false;
   while(clear() && uint32_t(millis()-at)<60000){
    noteTaskStack(DiagnosticTask::Ota);vTaskDelay(pdMS_TO_TICKS(1));if(callbackPort && uint32_t(millis()-authAt)>5000)break;
    int count=udp.parsePacket();if(!count){vTaskDelay(pdMS_TO_TICKS(5));continue;}
    if(count>127 || uint32_t(udp.remoteIP())!=host){while(udp.available())udp.read();continue;}
    char packet[128]={};int len=udp.read(packet,count);if(len!=count || memchr(packet,0,len))continue;
    if(!callbackPort){
     OtaInvitation invitation;if(!parseOtaInvitation(packet,len,invitation) || invitation.size!=manifest.size || !otaEqual(invitation.md5,manifest.md5,16))continue;
     callbackPort=invitation.port;udpPort=udp.remotePort();authAt=millis();randomHex(nonce);setPhase(Phase::Authenticating);
     udp.beginPacket(IPAddress(host),udpPort);udp.printf("AUTH %s",nonce);udp.endPacket();
    }else{
     if(udp.remotePort()!=udpPort)continue;
     char cnonce[33]={};uint8_t digest[16],supplied[16];if(!parseOtaTransferAuth(packet,len,cnonce,supplied))break;
     char passwordHash[33],expectedText[100];if(!otaMd5(secret,strlen(secret),digest))break;otaHex(digest,16,passwordHash);
     snprintf(expectedText,sizeof(expectedText),"%s:%s:%s",passwordHash,nonce,cnonce);if(!otaMd5(expectedText,strlen(expectedText),digest))break;
     if(!otaEqual(digest,supplied,16)){failure="transfer_auth";break;}
     udp.beginPacket(IPAddress(host),udpPort);udp.print("OK");udp.endPacket();authenticated=true;break;
    }
   }
   if(!authenticated || !clear()){failure="arming_or_auth";break;}udp.stop();setPhase(Phase::Connecting);
   if(!client.connect(IPAddress(host),callbackPort,300)||!clear()){failure="tcp_connect";break;}
   otaMemoryBoundary(OtaMemoryStage::TcpConnected);
   setPhase(Phase::Receiving);uint32_t start=millis(),lastData=start;bool transportOk=true;
   if(mbedtls_sha256_starts_ret(&sha,0) || mbedtls_md5_starts_ret(&md5)){failure="digest_init";break;}
   struct Flash {
    decltype(clear)& ready;const OtaManifest& manifest;const esp_partition_t* target;
    esp_ota_handle_t& handle;bool& live;mbedtls_sha256_context& sha;mbedtls_md5_context& md5;
    bool clearance(){return ready();}
    bool begin(){otaMemoryBoundary(OtaMemoryStage::BeginBefore);
     live=esp_ota_begin(target,OTA_WITH_SEQUENTIAL_WRITES,&handle)==ESP_OK;
     otaMemoryBoundary(OtaMemoryStage::BeginAfter);return live;}
    bool write(const uint8_t* data,size_t n){otaMemoryBoundary(OtaMemoryStage::WriteBefore,n);
     const auto result=esp_ota_write(handle,data,n);otaMemoryBoundary(OtaMemoryStage::WriteAfter,n);
     if(result!=ESP_OK)return false;
     return mbedtls_sha256_update_ret(&sha,data,n)==0 && mbedtls_md5_update_ret(&md5,data,n)==0;}
    bool finish(){uint8_t sh[32],md[16];
     if(mbedtls_sha256_finish_ret(&sha,sh)||mbedtls_md5_finish_ret(&md5,md)||!otaEqual(sh,manifest.sha256,32)||!otaEqual(md,manifest.md5,16))return false;
     otaMemoryBoundary(OtaMemoryStage::EndBefore);
     const auto result=esp_ota_end(handle);live=false;otaMemoryBoundary(OtaMemoryStage::EndAfter);return result==ESP_OK;}
   } flash{clear,manifest,target,handle,handleLive,sha,md5};
   OtaImageStream<Flash> stream(manifest,flash);size_t acknowledged=0;
   while(stream.received()<manifest.size && clear() && uint32_t(millis()-start)<180000 && uint32_t(millis()-lastData)<3000){
    noteTaskStack(DiagnosticTask::Ota);
    int available=client.available();if(!available){if(!client.connected())break;vTaskDelay(pdMS_TO_TICKS(2));continue;}
    size_t want=size_t(available);const size_t boundary=otaAckEnd(acknowledged,manifest.size);
    if(want>boundary-stream.received())want=boundary-stream.received();
    int got=client.read(buffer,want);if(got<=0)continue;lastData=millis();
    if(!stream.consume(buffer,got)){transportOk=false;failure="image_metadata_or_flash";break;}
    portENTER_CRITICAL(&otaMux);received=stream.received();portEXIT_CRITICAL(&otaMux);
    // One decimal ACK per sender block, regardless of TCP fragmentation.
    // Espota has no delimiter: ACKing every partial read is ambiguous.
    if(stream.received()==boundary){char ack[16];snprintf(ack,sizeof(ack),"%u",unsigned(boundary-acknowledged));
     if(!sendBounded(client,ack)){transportOk=false;failure="tcp_ack";break;}acknowledged=boundary;}
   }
   if(!transportOk)break; // Preserve the specific transport/image failure.
   if(!clear()){failure="maintenance_clearance_lost";break;}
   if(!stream.finish()){failure="transfer_incomplete_or_invalid";break;}
   setPhase(Phase::Verified);
#ifdef COVER_OTA_FLASH_PROBE
   // No Commit backend, boot selection, journal checkpoint or reboot is
   // compiled into this transfer branch. NOACT cannot be mistaken for OK.
   const auto* stillSelected=esp_ota_get_boot_partition();
   if(!stillSelected || !otaProbeSelectionUnchanged(running->address,stillSelected->address)){failure="probe_selection_changed";break;}
   portENTER_CRITICAL(&otaMux);probeRecord=record;probeVerified=true;portEXIT_CRITICAL(&otaMux);
   verifiedWithoutActivation=true;setPhase(Phase::Verified,"probe_verified_not_activated");
   sendBounded(client,"NOACT");
#else
   struct Commit {
    decltype(clear)& ready;MaintenanceLease lease;const esp_partition_t* target;bool& entered;
    bool clearance(){return ready();}bool cancelled(){return cancelRequested.load();}bool persist(OtaRecord& r){return saveRecord(r);}
    bool enterCommit(){portENTER_CRITICAL(&otaMux);const bool ok=!cancelRequested.load()&&beginOtaCommit(lease);
     if(ok){entered=true;commitStarted=true;phase=Phase::Committing;}portEXIT_CRITICAL(&otaMux);return ok;}
    bool selectBoot(){return esp_ota_set_boot_partition(target)==ESP_OK;}
   } commit{clear,lease,target,commitEntered};
   if(!commitOtaImage(commit,record)){failure=commitEntered?"activation_unconfirmed":"commit_rejected";break;}
   selected=true;record.activationConfirmed=true;
   // A stale INVALID/ABORTED marker for a previously used target slot is not
   // proof this transaction ever selected it. Preserve positive selection
   // evidence; a power cut before this checkpoint remains UNCONFIRMED.
   const bool selectionRecorded=saveRecord(record);setPhase(Phase::Rebooting,selectionRecorded?"none":"activation_unconfirmed");
   if(selectionRecorded)sendBounded(client,"OK");
   client.stop();vTaskDelay(pdMS_TO_TICKS(50));diagnosticWiFiAction("ota-reboot");ESP.restart();
#endif
  }while(false);
  otaMemoryFinish(); // Freeze before SDK abort, release and host cleanup reads.
  // No OTA API is called by HTTP or the servo worker, including cancellation.
  if(handleLive)esp_ota_abort(handle);
  client.stop();udp.stop();mbedtls_sha256_free(&sha);mbedtls_md5_free(&md5);
  if(selected){setPhase(Phase::Failed,"restart_failed");for(;;)vTaskDelay(pdMS_TO_TICKS(1000));}
  const bool cancelled=cancelRequested.load();
#ifdef COVER_OTA_FLASH_PROBE
  (void)commitEntered;
  if(!verifiedWithoutActivation)setPhase(cancelled?Phase::Cancelled:Phase::Failed,failure);
#else
  setPhase(cancelled?Phase::Cancelled:Phase::Failed,failure);
  if(commitEntered){record.outcome=OtaOutcome::Unconfirmed;saveRecord(record);} // Selection may have reached flash.
  else if(lease && otaSlot(record.sourceSlot) && otaSlot(record.targetSlot) && record.sourceSlot!=record.targetSlot){
   record.outcome=cancelled?OtaOutcome::Cancelled:OtaOutcome::Failed;saveRecord(record);
  }
#endif
  if(lease){confirmMaintenanceCleanup(lease);requestMaintenanceRelease(lease);
   while(sameLease(maintenanceStatus().lease,lease))vTaskDelay(pdMS_TO_TICKS(10));}
  portENTER_CRITICAL(&otaMux);active=false;portEXIT_CRITICAL(&otaMux);
  otaMemoryTransfer(false);
 }
}
bool authenticate(WebServer& web,const char* route,const char* tx,const String& body){
 bool allowed=receiverAllowed();
#ifdef COVER_OTA_FLASH_PROBE
 allowed=probeControlAllowed() && (!strcmp(route,"/api/ota/probe/prepare") || !strcmp(route,"/api/ota/probe/cancel"));
#endif
 if(!allowed || !otaControlBodyValid(web.clientContentLength(),body.length(),web.header("Content-Type").equalsIgnoreCase("text/plain")) || networkPortalRequest(web))return false;
 const String nonce=web.header("X-Ota-Nonce"),mac=web.header("X-Ota-Mac");uint8_t provided[32],expected[32];
 if(!challenge.consume(uint32_t(web.client().remoteIP()),millis(),nonce.c_str()) || mac.length()!=64 || !otaUnhex(mac.c_str(),64,provided))return false;
 return otaControlMac(secret,"POST",route,diagnosticsBootId(),nonce.c_str(),tx,body.c_str(),body.length(),expected) && otaEqual(provided,expected,32);
}
}
bool otaPinnedLayout(){return pinnedLayout();}
void beginOtaStartup(){
 // A volatile read also retains this section under the linker's garbage
 // collection; `used` alone only prevents compiler removal.
 const volatile uint8_t* descriptor=coverOtaDescriptor;
 startupAt=millis();journalReadable=pinnedLayout() && loadRecord() && descriptor[0]=='T';
#ifdef COVER_OTA_DEVELOPMENT
 // Retain the development marker in the validated image for the local CLI.
 const volatile char* developmentMarker=coverOtaDevMarker;
 journalReadable=journalReadable && developmentMarker[0]=='T';
#endif
 esp_ota_img_states_t state=ESP_OTA_IMG_UNDEFINED;const auto* running=esp_ota_get_running_partition();
 startupPending=running && esp_ota_get_state_partition(running,&state)==ESP_OK && state==ESP_OTA_IMG_PENDING_VERIFY;
 const bool handoff=journalPresent && otaNeedsReconciliation(lastRecord.outcome);
 const bool otaSoftwareStartup=(startupPending||handoff) && esp_reset_reason()==ESP_RST_SW;
 const bool inspectServoOnly=
#ifdef COVER_BROWSER_OTA
 true;
#else
 otaStartupRequiresInspection(startupPending,handoff,journalReadable);
#endif
#ifdef COVER_OTA_DEVELOPMENT
 beginStartupValidation(startupPending||handoff,false,otaSoftwareStartup,inspectServoOnly);
#else
 beginStartupValidation(startupPending||handoff,otaSoftwareStartup,false,inspectServoOnly);
#endif
#ifdef COVER_BROWSER_OTA
 beginBrowserOta();
#endif
 configured=COVER_OTA_RECEIVER_ENABLED && strlen(secret)>=32 && strlen(secret)<=128 && COVER_OTA_MIN_INTERNAL_HEAP && COVER_OTA_MIN_LARGEST_BLOCK;
#ifndef CONFIG_BOOTLOADER_APP_ROLLBACK_ENABLE
 configured=false;
#endif
#if defined(COVER_USB_MEMORY_PROBE) && !defined(COVER_OTA_USB_MEMORY_PROBE)
 configured=false; // Baseline never creates the OTA task, even with local config.
#elif defined(COVER_OTA_FLASH_PROBE)
 configured=false;
 probeConfigured=strlen(secret)>=32 && strlen(secret)<=128 && COVER_OTA_PROBE_MIN_HEAP && COVER_OTA_PROBE_MIN_BLOCK;
 if(probeConfigured){workerCreated=xTaskCreatePinnedToCore(receiverWorker,"ota",8192,nullptr,1,nullptr,0)==pdPASS;if(!workerCreated)probeConfigured=false;}
#elif defined(COVER_OTA_RESOURCE_PROBE)
 configured=false; // This USB test has no OTA credential/reserve requirements.
 workerCreated=xTaskCreatePinnedToCore(receiverWorker,"ota",8192,nullptr,1,nullptr,0)==pdPASS;
#else
 if(configured){workerCreated=xTaskCreatePinnedToCore(receiverWorker,"ota",8192,nullptr,1,nullptr,0)==pdPASS;if(!workerCreated)configured=false;}
#endif
}
void pollOtaStartup(){
 if(startupFinished)return;
 const uint32_t now=millis();static uint32_t lastPoll=0;if(uint32_t(now-lastPoll)<100)return;lastPoll=now;ApplicationSettings settings;
 const auto loaded=loadApplicationSettings(settings);
 const bool localRecovery=(WiFi.status()==WL_CONNECTED && uint32_t(WiFi.localIP())) || ((WiFi.getMode()&WIFI_AP) && uint32_t(WiFi.softAPIP()));
 OtaStartupHealth health;health.settingsReadable=loaded!=SettingsLoad::Unavailable;health.journalReadable=journalReadable;
 health.servicesReady=webReady;health.workersAlive=diagnosticsStartupHealthy(now);health.localRecovery=localRecovery;health.receiverReady=!configured||workerCreated;
#ifdef COVER_OTA_RESOURCE_PROBE
 health.receiverReady=workerCreated;
#endif
#ifdef COVER_OTA_FLASH_PROBE
 health.receiverReady=!probeConfigured||workerCreated;
#endif
#ifdef COVER_BROWSER_OTA
 health.receiverReady=browserOtaReady();
 if(startupPending && !browserOtaSettingsMatch())health.settingsReadable=false;
#endif
 const auto action=otaStartupAction(uint32_t(now-startupAt),health);if(action==OtaStartupAction::Wait)return;
 bool success=action==OtaStartupAction::Accept;const auto* running=esp_ota_get_running_partition();const auto* selected=esp_ota_get_boot_partition();
 if(!running || !selected || running->address!=selected->address)success=false;
 if(journalPresent && otaNeedsReconciliation(lastRecord.outcome)){
  const auto* invalid=esp_ota_get_last_invalid_partition();esp_app_desc_t desc{};
  bool invalidTarget=invalid && invalid->address==lastRecord.targetSlot && esp_ota_get_partition_description(invalid,&desc)==ESP_OK && otaEqual(desc.app_elf_sha256,lastRecord.target,32);
  OtaRecord record=lastRecord;record.reset=esp_reset_reason();
  record.outcome=reconcileOtaRecord(record,running?running->address:0,esp_ota_get_app_description()->app_elf_sha256,invalidTarget,false);
  if(record.outcome==OtaOutcome::BootCheck)record.activationConfirmed=true;
  // A pending candidate must match the durable handoff; unrelated pending
  // images and corrupted records never receive successful transaction verdicts.
  if(startupPending && record.outcome!=OtaOutcome::BootCheck)success=false;
  if(!saveRecord(record))success=false;
 }
 if(success){
  esp_ota_img_states_t state=ESP_OTA_IMG_UNDEFINED;const auto status=esp_ota_get_state_partition(running,&state);
  // Seed the USB bootstrap's current slot in otadata before any first transfer.
  if(status==ESP_ERR_NOT_FOUND && esp_ota_set_boot_partition(running)!=ESP_OK)success=false;
  if(success && state!=ESP_OTA_IMG_VALID && esp_ota_mark_app_valid_cancel_rollback()!=ESP_OK)success=false;
  if(success && journalPresent && lastRecord.outcome==OtaOutcome::BootCheck){OtaRecord record=lastRecord;record.outcome=OtaOutcome::Complete;if(!saveRecord(record))success=false;}
 }
 if(!success && startupPending && esp_ota_check_rollback_is_possible()){
  diagnosticEvent(DebugLevel::Error,"OTA startup health failed; requesting rollback");esp_ota_mark_app_invalid_rollback_and_reboot();
 }
 startupFinished=true;accepted=success;startup=success?"accepted":"recovery_required";
 finishStartupValidation(success);disableStartupWatchdog();
 setPhase(configured&&success?Phase::Idle:Phase::Unavailable,success?(configured?"none":"release_gate"):"startup_health");
#ifdef COVER_OTA_RESOURCE_PROBE
 if(success)setPhase(Phase::Unavailable,"resource_probe_no_admission");
#endif
#ifdef COVER_OTA_FLASH_PROBE
 if(success)setPhase(Phase::Unavailable,probeConfigured?"flash_probe_ready":"flash_probe_unconfigured");
#endif
 diagnosticEvent("OTA startup=%s",startup);
}
String otaStatusJson(){
 Phase p;const char* why;uint32_t bytes;char tx[33];bool busy;OtaRecord record;bool hasRecord;
 portENTER_CRITICAL(&otaMux);p=phase;why=reason;bytes=received;memcpy(tx,transactionHex,sizeof(tx));busy=active;record=lastRecord;hasRecord=journalPresent;portEXIT_CRITICAL(&otaMux);
 String durable="null";
 String experiment;
#ifdef COVER_OTA_FLASH_PROBE
 OtaRecord testRecord;bool testAttempted,testVerified;
 portENTER_CRITICAL(&otaMux);testRecord=probeRecord;testAttempted=probeAttempted;testVerified=probeVerified;portEXIT_CRITICAL(&otaMux);
 char targetId[65],binary[65];otaHex(testRecord.target,32,targetId);otaHex(testRecord.sha256,32,binary);
 experiment=String(",\"probe\":{\"mode\":\"inactive_flash_no_activation\",\"available\":")+(probeControlAllowed()&&!testAttempted?"true":"false")+
  ",\"attempted\":"+(testAttempted?"true":"false")+",\"verified\":"+(testVerified?"true":"false")+
  ",\"source_slot\":"+testRecord.sourceSlot+",\"target_slot\":"+testRecord.targetSlot+",\"target_firmware\":\""+targetId+"\",\"sha256\":\""+binary+"\"}";
#endif
 if(hasRecord){char id[33],source[65],target[65];otaHex(record.transaction,16,id);otaHex(record.source,32,source);otaHex(record.target,32,target);
  durable=String("{\"schema\":1,\"transaction\":\"")+id+"\",\"outcome\":\""+otaOutcomeName(record.outcome)+"\",\"source_firmware\":\""+source+
   "\",\"target_firmware\":\""+target+"\",\"source_slot\":"+record.sourceSlot+",\"target_slot\":"+record.targetSlot+
   ",\"selection_confirmed\":"+(record.activationConfirmed?"true":"false")+"}";
 }
 return String("{\"available\":")+(receiverAllowed()?"true":"false")+",\"phase\":\""+phaseName(p)+"\",\"reason\":\""+why+
#ifdef COVER_OTA_DEVELOPMENT
  "\",\"development\":true,\"admission_policy\":\"development-recovery\",\"startup\":\""+startup+
#else
  "\",\"startup\":\""+startup+
#endif
  "\",\"transaction\":\""+tx+"\",\"received\":"+bytes+",\"active\":"+(busy?"true":"false")+
  ",\"outcome\":\""+(hasRecord?otaOutcomeName(record.outcome):"none")+"\",\"last_update\":"+durable+experiment+",\"boot_id\":\""+diagnosticsBootId()+"\",\"firmware_id\":\""+firmwareId()+"\"}";
}
void registerOtaRoutes(WebServer& web){
 const char* challengePath="/api/ota/challenge";const char* preparePath="/api/ota/prepare";const char* cancelPath="/api/ota/cancel";
#ifdef COVER_OTA_FLASH_PROBE
 challengePath="/api/ota/probe/challenge";preparePath="/api/ota/probe/prepare";cancelPath="/api/ota/probe/cancel";
 web.on("/api/ota/challenge",HTTP_GET,[&web]{web.send(503,"text/plain","OTA unavailable");});
 for(const char* path:{"/api/ota/prepare","/api/ota/cancel"})web.on(path,HTTP_POST,[&web]{web.send(403,"text/plain","Production OTA unavailable");});
#endif
#ifdef COVER_OTA_MEMORY_PROBE
 web.on("/api/ota/probe/memory",HTTP_GET,[&web]{
  portENTER_CRITICAL(&otaMux);const bool finished=probeAttempted&&!active;portEXIT_CRITICAL(&otaMux);
  if(!probeControlAllowed() || networkPortalRequest(web) || !finished){web.send(409,"text/plain","Completed test required");return;}
  std::unique_ptr<OtaMemoryEvidence> snapshot(new(std::nothrow) OtaMemoryEvidence);
  if(!snapshot){web.send(503,"text/plain","Memory evidence unavailable");return;}
  if(!otaMemorySnapshot(*snapshot)){web.send(409,"text/plain","Test active");return;}
  String json;if(!json.reserve(6144)){web.send(503,"text/plain","Memory evidence unavailable");return;}
  json="{\"schema\":1,\"scope\":\"boundary_samples\",\"epoch\":";json+=snapshot->epoch;
  json+=",\"storage_bytes\":";json+=sizeof(OtaMemoryEvidence);json+=",\"boot_id\":\"";json+=diagnosticsBootId();json+="\",\"rows\":[";
  static const char* names[]={"request_arena","request_released","status_start","status_built","status_sent",
   "tcp_connected","begin_before","begin_after","write_before","write_after","end_before","end_after"};
  static_assert(sizeof(names)/sizeof(names[0])==kOtaMemoryStages,"Name every boundary");
  bool comma=false;char row[224];
  for(unsigned owner=0;owner<2;++owner)for(unsigned i=0;i<kOtaMemoryStages;++i){
   const auto& r=snapshot->rows[owner][i];if(!r.count)continue;
   const int n=snprintf(row,sizeof(row),"%s{\"stage\":\"%s\",\"ota_active\":%s,\"count\":%lu,\"min_free\":%lu,\"min_block\":%lu,\"at_ms\":%lu,\"max_bytes\":%lu}",
    comma?",":"",names[i],owner?"true":"false",(unsigned long)r.count,(unsigned long)r.minimumFree,
    (unsigned long)r.minimumBlock,(unsigned long)r.at,(unsigned long)r.maximumBytes);
   if(n<=0 || size_t(n)>=sizeof(row) || !json.concat(row,n)){web.send(503,"text/plain","Memory evidence unavailable");return;}comma=true;
  }
  if(!json.concat("]}")){web.send(503,"text/plain","Memory evidence unavailable");return;}
  web.sendHeader("Cache-Control","no-store");web.send(200,"application/json",json);
 });
#endif
 web.on(challengePath,HTTP_GET,[&web]{
  bool allowed=receiverAllowed();
#ifdef COVER_OTA_FLASH_PROBE
  allowed=probeControlAllowed();
#endif
  if(!allowed||networkPortalRequest(web)){web.send(503,"text/plain","OTA unavailable");return;}
  char nonce[33];randomHex(nonce);if(!challenge.issue(uint32_t(web.client().remoteIP()),millis(),nonce)){web.send(429,"text/plain","Retry later");return;}
  web.sendHeader("Cache-Control","no-store");web.send(200,"application/json",String("{\"schema\":1,\"boot_id\":\"")+diagnosticsBootId()+"\",\"nonce\":\""+nonce+"\",\"expires_ms\":10000}");
 });
 web.on(preparePath,HTTP_POST,[&web,preparePath]{
  const String body=web.arg("plain");OtaManifest manifest;
  if(!authenticate(web,preparePath,"",body)){web.send(403,"text/plain","OTA authentication unavailable or rejected");return;}
  if(!parseOtaManifest(body.c_str(),body.length(),manifest)){web.send(400,"text/plain","Invalid production manifest or OFF confirmation");return;}
  char tx[33];randomHex(tx);const uint32_t host=uint32_t(web.client().remoteIP());
  portENTER_CRITICAL(&otaMux);bool ok=!active && !maintenanceStatus().locked();
#ifdef COVER_OTA_FLASH_PROBE
  ok=reserveOtaProbe(active,maintenanceStatus().locked(),probeAttempted);
#endif
  if(ok){pendingManifest=manifest;peer=host;memcpy(transactionHex,tx,sizeof(tx));received=0;cancelRequested.store(false);commitStarted=false;active=true;queued=true;phase=Phase::Preparing;reason="none";}
  portEXIT_CRITICAL(&otaMux);web.send(ok?202:409,"application/json",otaStatusJson());
 });
 web.on(cancelPath,HTTP_POST,[&web,cancelPath]{
  const String body=web.arg("plain");char tx[33]={};
  if(body.length()!=45 || !body.startsWith("transaction=") || body[44]!='\n'){web.send(400,"text/plain","Invalid cancellation");return;}
  memcpy(tx,body.c_str()+12,32);uint8_t parsed[16];if(!otaUnhex(tx,32,parsed)){web.send(400,"text/plain","Invalid transaction");return;}
  if(!authenticate(web,cancelPath,tx,body)){web.send(403,"text/plain","OTA authentication unavailable or rejected");return;}
  portENTER_CRITICAL(&otaMux);bool ok=active && !strcmp(tx,transactionHex) && !commitStarted;if(ok)cancelRequested.store(true);portEXIT_CRITICAL(&otaMux);
  web.send(ok?202:409,"text/plain",ok?"Cancellation pending transport cleanup":"Transaction absent or cancellation too late");
 });
}
#ifdef COVER_BROWSER_OTA
bool otaBrowserAccepted(){return currentAccepted();}
bool otaBrowserSaveRecord(const OtaRecord& record){return saveRecord(record);}
#endif
void otaWebServiceReady(bool listening){webReady=listening;}
}
#endif
