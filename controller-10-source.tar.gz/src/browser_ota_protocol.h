#pragma once
#include "ota_protocol.h"
namespace cover {
constexpr size_t kBrowserChunk=768;
struct BrowserManifest {uint32_t sourceBuild=0,targetBuild=0,size=0;uint8_t source[32]={},target[32]={},sha[32]={};};
inline bool parseBrowserManifest(const char* text,size_t size,BrowserManifest& result){
 if(!text || size>768 || !size || memchr(text,0,size))return false;
 const char* p=text;const char* end=p+size;
 auto literal=[&](const char* value){const size_t n=strlen(value);if(size_t(end-p)<n || memcmp(p,value,n))return false;p+=n;return true;};
 auto number=[&](uint32_t& v){if(p==end || *p<'1' || *p>'9')return false;uint64_t n=0;
  while(p<end && *p>='0' && *p<='9'){n=n*10+*p++-'0';if(n>UINT32_MAX)return false;}
  if(p==end || *p++!='\n')return false;
  v=uint32_t(n);return true;};
 auto hex=[&](uint8_t* v){if(end-p<65 || !otaUnhex(p,64,v))return false;p+=64;return *p++=='\n';};
 BrowserManifest m;
 if(!literal("product=telescope-cover\nprotocol=browser-signed-v1\nlayout=cover-4mb-v1\nmotion=native-multiturn-v1\nstartup=inspect-only-v1\nsettings=preserve-cover-v1\nsource_build=") ||
  !number(m.sourceBuild) || !literal("source_elf=") || !hex(m.source) || !literal("target_build=") || !number(m.targetBuild) ||
  !literal("target_elf=") || !hex(m.target) || !literal("size=") || !number(m.size) || !literal("sha256=") || !hex(m.sha) || p!=end ||
  m.sourceBuild>=m.targetBuild || m.targetBuild>9999 || m.size<kOtaPrefixBytes || m.size>kOtaSlotBytes)return false;
 result=m;return true;
}
inline bool browserSourceAllowed(const BrowserManifest& m,uint32_t build,const uint8_t* elf){return m.sourceBuild==build && otaEqual(m.source,elf,32);}
inline bool browserPrefixValid(const uint8_t* p,size_t n,const BrowserManifest& m){
 OtaManifest image;image.size=m.size;memcpy(image.elf,m.target,32);
 return otaPrefixValid(p,n,image);
}
}
