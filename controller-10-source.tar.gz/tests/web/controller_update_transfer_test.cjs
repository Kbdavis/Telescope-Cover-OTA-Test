const {test}=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),vm=require('node:vm');
function page({fault=null,legacy=false,bench=false}={}){
 const nodes=new Map(),calls=[];const prefix=bench?'':'ota-';
 const node=id=>{if(!nodes.has(id))nodes.set(id,{textContent:'',disabled:false,checked:false,value:0,innerHTML:''});return nodes.get(id);};
 const source='a'.repeat(64),target='b'.repeat(64),tx='d'.repeat(32),image=new Uint8Array(2001);image.set(Buffer.from(target,'hex'),176);
 const state=bench?{profile:'bench-ota-v1',servo_operations:false,accepted:true,version:'0.1.0-beta.6',build:6,elf:source,boot:'boot-6',nonce:'nonce-6',phase:'idle'}:{protocol:'browser-signed-v1',version:'0.1.0-beta.6',build:6,firmware_id:source,boot_id:'boot-6',startup:'accepted',available:true,generation:1,phase:'idle'};
 if(!legacy)Object.assign(state,{chunk_bytes:768,chunk_ack:'consumed-offset-v1'});
 const canonical=bench?'product=telescope-cover-ota-bench\nprotocol=1\nlayout=cover-4mb-v1\nsettings=preserve-cover-app-v1\n':'product=telescope-cover\nprotocol=browser-signed-v1\nlayout=cover-4mb-v1\nmotion=native-multiturn-v1\nstartup=inspect-only-v1\nsettings=preserve-cover-v1\n';
 const release={build:7,tag:'v0.1.0-beta.7',application:(bench?'bench-':'controller-')+'7.bin',manifest:canonical+'source_build=6\nsource_elf='+source+'\ntarget_build=7\ntarget_elf='+target+'\nsize='+image.length+'\nsha256='+'c'.repeat(64)+'\n',signature:'e'.repeat(128)};
 const fetch=async(url,options={})=>{
  const body=options.body?Object.fromEntries(options.body):null;calls.push({url,body});
  if(url.endsWith('/status'))return new Response(JSON.stringify(state));
  if(url.endsWith('/session'))return new Response(JSON.stringify({boot:'boot-6',nonce:'nonce-6',update_token:'f'.repeat(64)}));
  if(url.startsWith('https://api.github.com/'))return new Response(JSON.stringify([{tag_name:release.tag,draft:false,prerelease:true,published_at:'2026-11-12T20:00:00Z'}]));
  if(url.includes('index.json'))return new Response(JSON.stringify({schema:bench?'telescope-cover-bench-catalog/1':'telescope-cover-controller-catalog/1',releases:[release]}));
  if(url.endsWith('.bin'))return new Response(image);
  if(url.endsWith('/start')){state.phase='receiving';state.transaction=tx;return new Response(tx,{status:202});}
  if(url.endsWith('/chunk')){
   const offset=Number(body.offset),size=body.data.length/2;
   assert.equal(offset,state.received||0);state.received=offset+size;
   if(fault==='http')return new Response('Worker failed',{status:409});
   if(fault==='lost')throw Error('Lost acknowledgement');
   return new Response(legacy?'queued':JSON.stringify({transaction:fault==='stale'?'0'.repeat(32):tx,received:state.received+(fault==='offset'?1:0)}));
  }
  if(url.endsWith('/finish')){
   state.version='0.1.0-beta.7';state.build=7;state.phase='idle';state.settings_preserved=true;
   if(bench)Object.assign(state,{elf:target,boot:'boot-7',outcome:'complete',journal_transaction:tx,journal_target:target});
   else Object.assign(state,{firmware_id:target,boot_id:'boot-7',handoff:{outcome:'complete',last_update:{transaction:tx,target_firmware:target}}});
   return new Response('verifying',{status:202});
  }
  if(url.endsWith('/cancel'))return new Response('cancelling',{status:202});
  throw Error('Unexpected request '+url);
 };
 const context={document:{getElementById:node,hidden:false,addEventListener(){}},window:{localStorage:{getItem(){return null;},setItem(){}},addEventListener(){},coverAPI:{async boot(){}}},location:{host:'192.168.1.135',href:'http://192.168.1.135/'},fetch,Response,TextDecoder,Uint8Array,URL,URLSearchParams,AbortSignal,Date,Math,Number,performance,setTimeout:fn=>setTimeout(fn,0),setInterval(){}};
 vm.runInNewContext(fs.readFileSync(bench?'data/bench/app.js':'data/ui/controller_updates.js','utf8'),context);
 if(!bench)context.window.CoverSignedUpdates.init();
 return {calls,node:id=>node(id==='header-update'&&!bench?'firmware-header-update':prefix+id),context};
}
async function ready(p){for(let i=0;i<100;i++){if(p.node('available').textContent.includes('Update available'))return;await new Promise(r=>setTimeout(r,2));}throw Error('Discovery did not settle: '+p.node('discovery').textContent);}
for(const bench of [false,true]){
 test((bench?'bench':'complete controller')+' fast path uses 768-byte POST acknowledgements with no per-chunk GET',async()=>{
  const p=page({bench});await ready(p);p.node('confirm').checked=true;p.node('confirm').onchange();await p.node('install').onclick();
  assert.match(p.node('operation').textContent,/successfully/);
  const chunks=p.calls.filter(c=>c.url.endsWith('/chunk'));assert.deepEqual(chunks.map(c=>c.body.data.length/2),[768,768,465]);
  const first=p.calls.indexOf(chunks[0]),last=p.calls.indexOf(chunks.at(-1));assert.equal(p.calls.slice(first,last+1).filter(c=>c.url.endsWith('/status')).length,0);
  assert.equal(p.calls.filter(c=>c.url.endsWith('/finish')).length,1);
  assert.equal(p.context.window.coverFirmwareUpdateActive||false,false);
 });
 for(const fault of ['stale','offset','http','lost'])test((bench?'bench':'controller')+' stops without replay or activation after '+fault+' acknowledgement',async()=>{
  const p=page({bench,fault});await ready(p);p.node('confirm').checked=true;p.node('confirm').onchange();await p.node('install').onclick();
  assert.match(p.node('operation').textContent,/Update stopped/);assert.equal(p.calls.filter(c=>c.url.endsWith('/chunk')).length,1);assert.equal(p.calls.filter(c=>c.url.endsWith('/finish')).length,0);assert.equal(p.calls.filter(c=>c.url.endsWith('/cancel')).length,1);
 });
}
test('new bench client negotiates 384-byte chunks and progress GETs with an older receiver',async()=>{
 const p=page({bench:true,legacy:true});await ready(p);p.node('confirm').checked=true;p.node('confirm').onchange();await p.node('install').onclick();assert.match(p.node('operation').textContent,/successfully/);
 const chunks=p.calls.filter(c=>c.url.endsWith('/chunk'));assert.equal(chunks.length,6);assert.equal(chunks[0].body.data.length/2,384);
 const first=p.calls.indexOf(chunks[0]),last=p.calls.indexOf(chunks.at(-1));assert.equal(p.calls.slice(first,last+2).filter(c=>c.url.endsWith('/status')).length,6);
});
