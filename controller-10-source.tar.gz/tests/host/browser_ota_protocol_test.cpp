#include "browser_ota_protocol.h"
#include "http_request.h"
#include <cassert>
#include <string>
#include <cstdio>
using namespace cover;
int main(){
 const std::string canonical="product=telescope-cover\nprotocol=browser-signed-v1\nlayout=cover-4mb-v1\nmotion=native-multiturn-v1\nstartup=inspect-only-v1\nsettings=preserve-cover-v1\nsource_build=1\nsource_elf="+std::string(64,'1')+"\ntarget_build=2\ntarget_elf="+std::string(64,'2')+"\nsize=1000000\nsha256="+std::string(64,'3')+"\n";
 auto parse=[](const std::string& s){BrowserManifest m;return parseBrowserManifest(s.data(),s.size(),m);};
 BrowserManifest m;assert(parseBrowserManifest(canonical.data(),canonical.size(),m));assert(m.size==1000000 && m.sourceBuild==1 && m.targetBuild==2);
 assert(browserSourceAllowed(m,1,m.source));assert(!browserSourceAllowed(m,2,m.source));assert(!browserSourceAllowed(m,1,m.target));
 for(const auto& change:{std::pair<std::string,std::string>{"source_build=1","source_build=01"},{"target_build=2","target_build=1"},{"target_build=2","target_build=10000"},{"size=1000000","size=1310721"},{"size=1000000","size=42949672960"},{"sha256=3","sha256=G"},{"protocol=browser-signed-v1","protocol=1"},{"product=telescope-cover","product=telescope-cover-ota-bench"},{"inspect-only-v1","restore-profile-v1"}}){auto s=canonical;const auto at=s.find(change.first);assert(at!=std::string::npos);s.replace(at,change.first.size(),change.second);assert(!parse(s));}
 assert(!parse(canonical+"extra=1\n"));assert(!parse(canonical.substr(0,canonical.size()-1)));assert(!parse(canonical+std::string(1,'\0')));
 uint8_t p[352]={};p[0]=0xe9;p[1]=1;p[2]=2;p[3]=0x20;p[23]=1;otaPut32(p+28,320);otaPut32(p+32,0xabcd5432);memcpy(p+176,m.target,32);const uint8_t descriptor[64]={'T','C','O','T','A','0','0','1','t','e','l','e','s','c','o','p','e','-','c','o','v','e','r',0,'w','e','b','_','c','o','n','t','r','o','l',0,0,0,0,0,1,0,5,0,1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
 memcpy(p+288,descriptor,64);assert(browserPrefixValid(p,sizeof(p),m));p[288]^=1;assert(!browserPrefixValid(p,sizeof(p),m));p[288]^=1;p[176]^=1;assert(!browserPrefixValid(p,sizeof(p),m));
 // The full encoded chunk, transaction and maximum canonical offset stay inside
 // the existing HTTP body arena, without increasing any parser limit.
 const std::string body="transaction="+std::string(32,'a')+"&offset=1310719&data="+std::string(kBrowserChunk*2,'f');
 assert(body.size()<=HttpRequest::kBody);
 HttpRequest request(0);const std::string wire="POST /api/update/chunk HTTP/1.1\r\nHost: cover\r\nContent-Type: application/x-www-form-urlencoded\r\nContent-Length: "+std::to_string(body.size())+"\r\n\r\n"+body;
 for(char c:wire)request.feed(c,1);
 assert(request.ready&&!request.error&&request.length==body.size());
 puts("Complete-controller manifest namespace, source pinning, signed policy, image prefix and 768-byte bounded form passed");
}
