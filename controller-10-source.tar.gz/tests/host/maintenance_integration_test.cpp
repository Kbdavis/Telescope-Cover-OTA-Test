#define COVER_WEB_CONTROL
#include "../../src/web_control.cpp"
#include "telescope_arm.h"
#include <functional>
using namespace cover;
namespace {
bool servoTorque=false,servoConfig=true,logStorage=true;
uint16_t servoPosition=500;unsigned moves=0,releases=0;
ServoError modelError=ServoError::None,positionError=ServoError::None,torqueError=ServoError::None,telemetryError=ServoError::None;
ServoError configurationReadError=ServoError::None;
bool calibrationPresent=true,calibrationNeedsReview=false,circularFixture=false;
unsigned inspectionCalls=0;bool inspectionFails=false;
alpaca::Snapshot scopeSnapshot;
struct EndWorker {};
}
#ifdef COVER_REFERENCE_PROBE
static unsigned referenceProbeCalls=0;
ServoResult cover::ServoController::probeLockedReference(bool restore,ReferenceProbeEvidence& e){
 ++referenceProbeCalls;e=ReferenceProbeEvidence{};e.writeAttempted=e.lockConfirmed=e.beforeValid=e.afterValid=true;
 e.positionBeforeValid=e.positionAfterValid=true;e.positionBefore=servoPosition;
 servoPosition=wrapPosition(int(servoPosition)+(restore?1243:-1243));e.positionAfter=servoPosition;return {};
}
#endif
namespace cover {
#ifdef COVER_MULTITURN_STARTUP
static bool startupSetupFails=false;
static unsigned startupSetupCalls=0;
ServoResult ServoController::prepareMultiTurnStartup(ReferenceProbeEvidence&){
 ++startupSetupCalls;return startupSetupFails?ServoResult{ServoError::InvalidConfiguration}:ServoResult{};
}
#endif
#ifdef COVER_MULTITURN_PROBE
ServoResult ServoController::configureLockedMultiTurn(bool,ReferenceProbeEvidence& e){
 ++referenceProbeCalls;e=ReferenceProbeEvidence{};e.writeAttempted=e.lockConfirmed=e.beforeValid=e.afterValid=true;
 e.positionBeforeValid=e.positionAfterValid=true;e.positionBefore=e.positionAfter=servoPosition;return {};
}
#endif
#ifdef COVER_FIXED_REFERENCE
ServoResult ServoController::prepareFixedReference(){return {};}
#endif
ServoResult ServoController::readModel(uint16_t& out){if(modelError!=ServoError::None)return {modelError};out=777;return {};}
ServoResult ServoController::validateConfiguration(){rolloverSupported_=circularFixture;return servoConfig?ServoResult{}:ServoResult{ServoError::InvalidConfiguration};}
ServoResult ServoController::validateConfiguration(ServoConfiguration& out){
 if(configurationReadError!=ServoError::None)return {configurationReadError};
 out=ServoConfiguration{};out.id=1;out.maximum=4095;out.resolution=1;
 if(!servoConfig){out.phase=12;out.offset=85;}
 return validateConfiguration();
}
ServoResult ServoController::readTorque(bool& out){if(torqueError!=ServoError::None)return {torqueError};out=servoTorque;return {};}
ServoResult ServoController::readPosition(uint16_t& out){if(positionError!=ServoError::None)return {positionError};out=servoPosition;return {};}
ServoResult ServoController::readTelemetry(ServoTelemetry& out){if(telemetryError!=ServoError::None)return {telemetryError};out.position=servoPosition;return {};}
ServoResult ServoController::readGoal(ServoGoalReadback& out){out=ServoGoalReadback{};return {};}
ServoResult ServoController::releaseTorque(){++releases;servoTorque=false;return {};}
ServoResult ServoController::enableTorque(){servoTorque=true;return {};}
ServoResult ServoController::moveAcrossBoundary(uint16_t target,uint16_t speed,uint8_t acc,const TravelArc& arc){return circularFixture&&arc.endpointStartAllowed(servoPosition)?moveTo(target,speed,acc,0,4095):ServoResult{ServoError::InvalidConfiguration};}
#ifdef COVER_MULTITURN
ServoResult ServoController::inspectMultiTurnStartup(){++inspectionCalls;return inspectionFails?ServoResult{ServoError::InvalidConfiguration}:ServoResult{};}
ServoResult ServoController::moveCalibratedEndpoint(uint16_t target,uint16_t speed,uint8_t acceleration,const TravelArc& arc){return ServoMotion::moveCalibratedEndpoint(target,speed,acceleration,arc);}
#endif
ServoResult ServoController::moveTo(uint16_t goal,uint16_t,uint8_t,uint16_t,uint16_t){++moves;servoPosition=goal;return {};}
SettingsLoad loadCalibration(Calibration& out){if(!calibrationPresent)return SettingsLoad::Missing;out.minimum=400;out.maximum=600;out.closed=500;out.open=400;out.hasClosed=out.hasOpen=true;out.openingDirection=-1;out.travelCounts=100;out.profile.timeoutMs=10000;if(circularFixture){out.minimum=0;out.maximum=4095;out.closed=397;out.open=2704;out.travelCounts=1789;out.circular=true;out.profile.timeoutMs=26000;}if(calibrationNeedsReview){out.minimum=0;out.maximum=4095;out.closed=4000;out.open=100;out.openingDirection=1;return SettingsLoad::ReviewRequired;}return SettingsLoad::Loaded;}
SettingsLoad loadApplicationSettings(ApplicationSettings& out){out.disableTorqueAfterMove=true;return SettingsLoad::Loaded;}
bool saveCalibration(const Calibration&){return true;}
bool validCalibration(const Calibration&){return true;}
bool validMotionProfile(const MotionProfile&){return true;}
alpaca::Snapshot alpacaStatus(){return scopeSnapshot;}
alpaca::StowStatus alpacaStowStatus(){return {};}
ArmStatus telescopeArmStatus(){return {};}
ShutdownNative shutdownNativeStatus(){return {};}
ShutdownReply shutdownNativeReply(){return {};}
void diagnosticEvent(const char*,...){}
void diagnosticEvent(DebugLevel,const char*,...){}
void diagnosticLog(const char*,...){}
void noteRetainedFault(const char*,uint32_t,uint32_t){}
void debugLog(const char*,...){}
void debugLog(DebugLevel,const char*,...){}
void noteMotionLoop(){}
bool debugLogAvailable(){return logStorage;}
}
void runWorker(unsigned ticks,std::function<void(unsigned)> action,bool powered=false,bool otaStartup=false,uint16_t initialPosition=500,bool connected=true,bool calibrated=true,bool ambiguous=false,bool setupFails=false,bool circular=false,bool inspectOnly=false){
 inspectOtaServoStartup=inspectOnly;inspectionCalls=0;inspectionFails=setupFails;
 circularFixture=circular;
#ifdef COVER_MULTITURN_STARTUP
 startupSetupFails=setupFails;startupSetupCalls=0;
#else
 (void)setupFails;
#endif
 calibrationNeedsReview=ambiguous;
 modelError=positionError=torqueError=telemetryError=connected?ServoError::None:ServoError::Timeout;calibrationPresent=calibrated;
 configurationReadError=ServoError::None;
 scopeSnapshot=alpaca::Snapshot{};
 fakeNow=100;servoTorque=powered;closedOtaStartup=otaStartup;servoConfig=true;logStorage=true;servoPosition=initialPosition;moves=releases=0;
 maintenance=MaintenanceArbiter{};shared=WebStatus{};startupAccepted=true;fakeQueue.entries.clear();
 stopRequested=rebootRequested=rebootRetain=maintenanceStaOnly=false;
 emergencyReserved=emergencyStart=emergencyFinish=emergencyCancelled=false;maintenanceWorkers=0;retainedRebootMarker=0;
 unsigned count=0;
 fakeTaskDelay=[&](unsigned ms){if(ms!=5)return;action(++count);if(count>=ticks)throw EndWorker{};};
 beginWebControl();
 try{worker(nullptr);}catch(const EndWorker&){}
 fakeTaskDelay=nullptr;
}
OtaMaintenanceRequirements requirements(){
 OtaMaintenanceRequirements out;out.closedCover=out.startupAccepted=true;out.minimumInternalHeap=1000;out.minimumLargestBlock=1000;return out;
}
int main(){
 // Near-arc startup permits an explicit inward endpoint request without
 // classifying the cover CLOSED or automatically commanding movement.
 for(uint16_t position:{uint16_t(412),uint16_t(422),uint16_t(423)}){
  runWorker(3,[&](unsigned tick){
   if(tick==1){
    assert(!moves&&!servoTorque&&!strcmp(webStatus().state,"UNKNOWN"));
    assert(webStatus().ready==(position<=422));
    assert(submitWebCommand(WebCommandType::Open,1,0,0,1,false,100,MotionProfile{},1));
   }
   if(tick==2)assert(moves==(position<=422?1u:0u));
  },false,false,position,true,true,false,false,true);
 }
 // Manual hold survives settling and another same-owner step without release.
 // A different client cannot take it over; explicit Stop still releases it.
 runWorker(130,[&](unsigned tick){
  if(tick==1)assert(submitWebCommand(WebCommandType::ManualJogPlus,1,0,0,1,true,10,MotionProfile{},1));
  if(tick==60){assert(webStatus().holding&&servoTorque&&moves==1);assert(submitWebCommand(WebCommandType::ManualJogPlus,2,0,0,2,true,10,MotionProfile{},1));}
  if(tick==61){assert(webStatus().holding&&servoTorque&&moves==1);assert(submitWebCommand(WebCommandType::ManualJogPlus,1,0,0,3,true,10,MotionProfile{},1));}
  if(tick==120){assert(webStatus().holding&&servoTorque&&moves==2);assert(submitWebCommand(WebCommandType::Stop,1));}
  if(tick==121)assert(!servoTorque&&!webStatus().holding);
 });
 // Missing stow telemetry blocks ordinary Close, but a single explicit manual
 // confirmation can close. Fresh unsafe evidence blocks/interrupts that path.
 for(bool override:{false,true}){
  runWorker(3,[&](unsigned tick){
   if(tick==1){scopeSnapshot.enabled=true;assert(submitWebCommand(override?WebCommandType::CloseManualStow:WebCommandType::CloseStowed,1,0,0,1,false,100,MotionProfile{},1));}
   if(tick==2){assert(moves==(override?1u:0u));if(override){scopeSnapshot.valid=scopeSnapshot.connected=true;scopeSnapshot.atHome=false;scopeSnapshot.sampledAt=fakeNow;}}
   if(tick==3&&override){assert(!webStatus().moving && !strcmp(webStatus().state,"FAULT"));assert(!servoTorque && releases>0);}
  },false,false,400);
 }
 for(unsigned unsafe=0;unsafe<3;++unsafe){
  runWorker(3,[&](unsigned tick){
   if(tick==1){
    scopeSnapshot.enabled=scopeSnapshot.valid=scopeSnapshot.connected=true;scopeSnapshot.sampledAt=fakeNow;
    scopeSnapshot.atHome=unsafe!=0;scopeSnapshot.slewing=unsafe==1;scopeSnapshot.tracking=unsafe==2;
    assert(submitWebCommand(WebCommandType::CloseManualStow,1,0,0,1,false,100,MotionProfile{},1));
   }
   if(tick>=2)assert(!moves && !webStatus().commandOk);
  },false,false,400);
 }
 // Settings do not depend on OPEN/CLOSED, saved calibration or fault labels.
 MaintenanceLease settingsLease;
 for(uint16_t initial:{uint16_t(400),uint16_t(450),uint16_t(500)})for(bool calibrated:{false,true}){
  runWorker(3,[&](unsigned tick){
   if(tick==1){settingsLease=requestNetworkMaintenance(1);assert(settingsLease);}
   if(tick==2){assert(networkMaintenanceReady(settingsLease));assert(!moves&&!releases);}
  },false,false,initial,true,calibrated);
 }
#ifdef COVER_MULTITURN_STARTUP
 // Update and rollback startup must bypass RAM preparation, including when
 // inspection fails. No motion or implicit torque change makes it eligible.
 for(bool fail:{false,true})runWorker(3,[&](unsigned){
  assert(inspectionCalls==1 && startupSetupCalls==0);
  assert(webStatus().ready==!fail);
  assert(moves==0 && releases==0);
 },false,false,500,true,true,false,fail,false,true);
 runWorker(3,[&](unsigned){
  assert(startupSetupCalls==1 && webStatus().ready);
  assert(moves==0 && releases==0);
 });
 runWorker(3,[&](unsigned){
  assert(startupSetupCalls==1 && !webStatus().ready && !webStatus().manualReady);
  assert(strstr(webStatus().fault,"RAM servo setup blocked"));
  assert(moves==0 && releases==0);
 },false,false,500,true,true,false,true);
#endif
 // A controller fault freezes its ring before later idle reads, recovery and
 // another operation can replace live telemetry/history.
 runWorker(100,[&](unsigned tick){
  if(tick==1)assert(submitWebCommand(WebCommandType::ManualJogPlus,1,0,0,1,false,10,MotionProfile{},1));
  if(tick==4)servoPosition=5000;
  if(tick==40){
   ServoSupportSnapshot snapshot;copyServoSupport(snapshot);
   assert(snapshot.faultRevision==1 && snapshot.fault.traceAvailable && snapshot.fault.limitSamples==3);
   assert(snapshot.frozenTrace.target==510 && snapshot.frozenTrace.rejectedReads==3);
   servoPosition=500;assert(submitWebCommand(WebCommandType::Recover,1,0,0,2,false,10,MotionProfile{},1));
  }
  if(tick==45)assert(submitWebCommand(WebCommandType::ManualJogPlus,1,0,0,3,false,10,MotionProfile{},1));
  if(tick==60){
   ServoSupportSnapshot snapshot;copyServoSupport(snapshot);
   assert(snapshot.faultRevision==1 && snapshot.frozenTrace.operation==1 && snapshot.frozenTrace.rejectedReads==3);
   assert(webStatus().motionTrace.operation==2);
  }
 });
 MaintenanceLease network;
 runWorker(5,[&](unsigned tick){
  if(tick==1){
   assert(webStatus().ready);
   assert(submitWebCommand(WebCommandType::ManualJogPlus,1,0,0,1,false,10,MotionProfile{},1));
   network=requestNetworkMaintenance(1);assert(network);
  }
  if(tick==2){
   assert(!moves && networkMaintenanceReady(network));assert(!networkMaintenanceReady());
   for(auto type:{WebCommandType::JogPlus,WebCommandType::JogMinus,WebCommandType::ManualJogPlus,WebCommandType::ManualJogMinus,
       WebCommandType::Heartbeat,WebCommandType::Recover,WebCommandType::CaptureOpen,WebCommandType::CaptureClosed,
       WebCommandType::SetLimits,WebCommandType::SaveCalibration,WebCommandType::Open,WebCommandType::Close,
       WebCommandType::TorqueTest,WebCommandType::CloseStowed,WebCommandType::SetProfile,WebCommandType::DiscardCalibration})
    assert(!submitWebCommand(type,1,0,0,2,false,10,MotionProfile{},maintenanceStatus().controlGeneration));
   assert(!submitWebCommand(WebCommandType::ManualJogPlus,1,0,0,2,false,10,MotionProfile{},1));
   assert(!endNetworkMaintenance());assert(endNetworkMaintenance(network));
  }
  if(tick==3){
   assert(!maintenanceStatus().locked());assert(!controlRequestAllowed(1));
   assert(submitWebCommand(WebCommandType::ManualJogPlus,1,0,0,3,false,10,MotionProfile{},maintenanceStatus().controlGeneration));
  }
  if(tick==4){assert(moves==1);assert(submitWebCommand(WebCommandType::Stop,999));}
  if(tick==5)assert(!servoTorque && releases>0);
 });
 MaintenanceLease ota;
 runWorker(5,[&](unsigned tick){
  if(tick==1){
   noteMaintenanceNetwork(true);registerMaintenanceWorker(kMaintenanceAlpacaWorker,true);
   auto invalid=requirements();invalid.startupAccepted=false;assert(!requestOtaMaintenance(invalid,1));
   invalid=requirements();invalid.minimumInternalHeap=0;assert(!requestOtaMaintenance(invalid,1));
   ota=requestOtaMaintenance(requirements(),1);assert(ota);
  }
  if(tick==2){assert(maintenanceStatus().phase==MaintenancePhase::Pending);acknowledgeMaintenancePause(ota,kMaintenanceAlpacaWorker);fakeNow+=500;}
  if(tick==3){
   assert(maintenanceReady(ota));assert(!moves && !releases);
   assert(!networkMaintenanceReady(ota));assert(!endNetworkMaintenance(ota));
   assert(!submitAutomaticStop(1,1));assert(maintenanceReady(ota));
   assert(!endNetworkMaintenance(network));assert(!confirmMaintenanceCleanup(network));
   noteMaintenanceNetwork(false);assert(!maintenanceMayExposeAp());assert(maintenanceStatus().phase==MaintenancePhase::Revoked);
   assert(submitWebCommand(WebCommandType::Stop,999));
   assert(confirmMaintenanceCleanup(ota));assert(maintenanceMayExposeAp());assert(requestMaintenanceRelease(ota));fakeNow+=500;
  }
  if(tick==4){assert(!maintenanceStatus().locked());assert(!servoTorque && releases>0);}
 });
 runWorker(3,[&](unsigned tick){
  if(tick==1){noteMaintenanceNetwork(true);ota=requestOtaMaintenance(requirements(),1);assert(ota);assert(submitAutomaticStop(1,1));}
  if(tick==2){assert(maintenanceStatus().phase==MaintenancePhase::Revoked);assert(!maintenanceReady(ota));}
 });
 runWorker(4,[&](unsigned tick){
  if(tick==1){noteMaintenanceNetwork(true);ota=requestOtaMaintenance(requirements(),1);assert(ota);servoConfig=false;}
  if(tick==2){assert(maintenanceStatus().phase==MaintenancePhase::Revoked);assert(confirmMaintenanceCleanup(ota));assert(requestMaintenanceRelease(ota));fakeNow+=500;}
  if(tick==3){assert(maintenanceStatus().locked());servoConfig=true;fakeNow+=500;}
  if(tick==4)assert(!maintenanceStatus().locked());
 });
 runWorker(3,[&](unsigned tick){
  if(tick==1){noteMaintenanceNetwork(true);ota=requestOtaMaintenance(requirements(),1);assert(ota);}
  if(tick==2){assert(maintenanceReady(ota));fakeNow+=1600;assert(!maintenanceReady(ota));}
  if(tick==3){assert(maintenanceStatus().phase==MaintenancePhase::Revoked);assert(maintenanceStatus().reason==MaintenanceReason::Timeout);}
 });
 runWorker(3,[&](unsigned tick){
  if(tick==1){
   beginStartupValidation(true);assert(!controlRequestAllowed(1));assert(!heartbeatRequestAllowed(1));
   assert(!submitWebCommand(WebCommandType::ManualJogPlus,1,0,0,1,false,10,MotionProfile{},1));
   assert(!requestNetworkMaintenance(1));assert(!requestRebootMaintenance(false,1,1));
   assert(!requestEmergencyShutdown(emergencyStopEpoch()));
   noteMaintenanceNetwork(true);assert(!requestOtaMaintenance(requirements(),1));assert(submitWebCommand(WebCommandType::Stop,1));
  }
  if(tick==2){finishStartupValidation(true);assert(controlRequestAllowed(maintenanceStatus().controlGeneration));assert(!servoTorque);}
 });
 runWorker(3,[&](unsigned tick){
  if(tick==1){noteMaintenanceNetwork(true);ota=requestOtaMaintenance(requirements(),1);assert(ota);assert(!beginOtaCommit(ota));}
  if(tick==2){assert(maintenanceReady(ota));assert(beginOtaCommit(ota));assert(!beginOtaCommit(ota));
   assert(submitWebCommand(WebCommandType::Stop,1));assert(!beginOtaCommit(ota));assert(maintenanceStatus().committing);}
 });
 for(bool powered:{false,true}){
  runWorker(3,[&](unsigned tick){
   if(tick==1){assert(webStatus().ready);assert(!strcmp(webStatus().state,"CLOSED"));noteMaintenanceNetwork(true);ota=requestOtaMaintenance(requirements(),1);assert(ota);}
   if(tick==2){assert(maintenanceReady(ota));assert(servoTorque==powered);assert(!moves && !releases);servoPosition=520;fakeNow+=500;}
   if(tick==3){assert(!maintenanceReady(ota));assert(maintenanceStatus().phase==MaintenancePhase::Revoked);}
  },powered,true);
 }
 for(uint16_t position:{uint16_t(450),uint16_t(400)}){
  runWorker(1,[&](unsigned){assert(!webStatus().ready);assert(!moves && !releases);},true,true,position);
  runWorker(1,[&](unsigned){noteMaintenanceNetwork(true);assert(!requestOtaMaintenance(requirements(),1));},false,false,position);
 }
 runWorker(1,[&](unsigned){assert(!webStatus().ready);assert(!moves && !releases);},true,false);
#ifdef COVER_OTA_DEVELOPMENT
 // Recovery can replace an uncalibrated, faulted controller with invalid
 // configuration, using fresh OFF/stationary evidence rather than calibration.
 unsigned faultReleases=0;
 runWorker(6,[&](unsigned tick){
  if(tick==1)assert(submitWebCommand(WebCommandType::TorqueTest,1,0,0,1,false,10,MotionProfile{},1));
  if(tick==2)fakeNow+=800;
  if(tick==3){
   assert(!strcmp(webStatus().state,"FAULT") && !webStatus().calibrated && !webStatus().ready);
   faultReleases=releases;servoConfig=false;noteMaintenanceNetwork(true);
   auto r=requirements();r.closedCover=false;r.recovery=true;ota=requestOtaMaintenance(r,1);assert(ota);
  }
  if(tick==4){assert(maintenanceReady(ota));assert(!moves&&releases==faultReleases);servoTorque=true;fakeNow+=500;}
  if(tick==5){assert(!maintenanceReady(ota)&&maintenanceStatus().phase==MaintenancePhase::Revoked);servoTorque=false;
   assert(confirmMaintenanceCleanup(ota));assert(requestMaintenanceRelease(ota));fakeNow+=500;}
  if(tick==6){assert(!maintenanceStatus().locked());assert(!moves&&releases==faultReleases);}
 },false,false,3000,true,false);
 // Development OTA leases work at OPEN and interior positions, without goals.
 for(uint16_t position:{uint16_t(450),uint16_t(400)}){
  runWorker(3,[&](unsigned tick){
   if(tick==1){noteMaintenanceNetwork(true);auto r=requirements();r.closedCover=false;ota=requestOtaMaintenance(r,1);assert(ota);}
   if(tick==2){assert(maintenanceReady(ota));assert(!submitWebCommand(WebCommandType::JogPlus,1));servoPosition=650;fakeNow+=500;}
   if(tick==3)assert(!maintenanceReady(ota)&&maintenanceStatus().phase==MaintenancePhase::Revoked);
   assert(!moves&&!releases);
  },false,false,position);
 }
#endif
 // Settings saves accept stationary torque ON/OFF; continued drift revokes clearance.
 for(bool powered:{false,true}){
  runWorker(3,[&](unsigned tick){
   if(tick==1){network=requestNetworkMaintenance(1);assert(network);}
   if(tick==2){assert(networkMaintenanceReady(network));assert(servoTorque==powered && !moves && !releases);servoPosition=520;fakeNow+=500;}
   if(tick==3){assert(!networkMaintenanceReady(network));assert(maintenanceStatus().phase==MaintenancePhase::Revoked);}
  },powered,true);
 }
 for(uint16_t position:{uint16_t(550),uint16_t(600)}){
  runWorker(2,[&](unsigned tick){
   if(tick==1){network=requestNetworkMaintenance(1);assert(network);}
   if(tick==2){assert(networkMaintenanceReady(network));assert(!moves && !releases);}
  },false,false,position);
 }
 // Fresh board: three distinct failed poll cycles, no physical-disconnection flag.
 runWorker(6,[&](unsigned tick){
  const auto status=webStatus();
  if(tick<3)assert(!status.settingsOfflineAllowed);
  if(tick==3){assert(status.settingsOfflineAllowed && !status.ready && !status.calibrated);network=requestNetworkMaintenance(1);assert(network);}
  if(tick==4){
   assert(networkMaintenanceReady(network));assert(!moves && !releases);
   noteMaintenanceNetwork(true);assert(!requestOtaMaintenance(requirements(),maintenanceStatus().controlGeneration));
   assert(!submitWebCommand(WebCommandType::Open,1,0,0,1,false,10,MotionProfile{},maintenanceStatus().controlGeneration));
   // Even partial feedback immediately revokes offline clearance.
   torqueError=ServoError::None;
  }
  if(tick==5){assert(!status.settingsOfflineAllowed);assert(!networkMaintenanceReady(network));assert(maintenanceStatus().phase==MaintenancePhase::Revoked);}
  fakeNow+=500;
 },false,false,500,false,false);
 // A previously initialized OPEN controller also permits settings after sustained loss.
 runWorker(6,[&](unsigned tick){
  if(tick==1){assert(webStatus().ready);modelError=positionError=torqueError=telemetryError=ServoError::Timeout;}
  if(tick==2 || tick==3)assert(!webStatus().settingsOfflineAllowed);
  if(tick==4){assert(webStatus().settingsOfflineAllowed);network=requestNetworkMaintenance(1);assert(network);}
  if(tick==5){assert(networkMaintenanceReady(network));assert(!moves && !releases);assert(submitWebCommand(WebCommandType::Stop,1));}
  if(tick==6)assert(maintenanceStatus().phase==MaintenancePhase::Revoked);
  fakeNow+=500;
 },false,false,600);
 // Offline clearance itself never authorizes an actuator command, even without a lease.
 runWorker(5,[&](unsigned tick){
  if(tick==1)modelError=positionError=torqueError=telemetryError=ServoError::Timeout;
  if(tick==4){
   assert(webStatus().settingsOfflineAllowed);
   assert(submitWebCommand(WebCommandType::ManualJogPlus,1,0,0,7,false,10,MotionProfile{},1));
  }
  if(tick==5){
   assert(webStatus().commandId==7 && !webStatus().commandOk);
   assert(strstr(webStatus().notice,"controller settings recovery only"));
   assert(!moves && !releases);
  }
  fakeNow+=tick==4?5:500;
 },false,false,600);
 // Active movement and supervised holding never acquire settings clearance.
 for(bool holding:{false,true}){
  runWorker(3,[&](unsigned tick){
   if(tick==1)assert(submitWebCommand(holding?WebCommandType::TorqueTest:WebCommandType::ManualJogPlus,1,0,0,1,false,10,MotionProfile{},1));
   if(tick==2){
    assert(holding?webStatus().holding:webStatus().moving);
    modelError=positionError=torqueError=telemetryError=ServoError::Timeout;
   }
   if(tick>=2){
    assert(!webStatus().settingsOfflineAllowed);
    const auto lease=requestNetworkMaintenance(1);
    if(webStatus().moving || webStatus().holding)assert(!lease);
    else assert(!networkMaintenanceReady(lease)); // A communication fault may already have stopped the operation.
   }
   fakeNow+=100;
  });
 }
 // A recovered transient outage permits stationary settings without claiming offline recovery.
 runWorker(5,[&](unsigned tick){
  assert(!webStatus().settingsOfflineAllowed);
  if(tick==1)modelError=positionError=torqueError=telemetryError=ServoError::Timeout;
  if(tick==2)modelError=positionError=torqueError=telemetryError=ServoError::None;
  if(tick==3){network=requestNetworkMaintenance(1);assert(network);}
  if(tick>=4)assert(networkMaintenanceReady(network));
  fakeNow+=500;
 },false,false,600);
 // Error replies and a successful model probe prove the servo still responds.
 for(bool modelResponds:{false,true}){
  runWorker(5,[&](unsigned tick){
   if(tick==1){
    modelError=modelResponds?ServoError::None:ServoError::Timeout;
    positionError=torqueError=modelResponds?ServoError::Timeout:ServoError::DeviceError;
   }
   if(tick==3){network=requestNetworkMaintenance(1);assert(network);}
   if(tick>=4){assert(!networkMaintenanceReady(network));assert(!webStatus().settingsOfflineAllowed);}
   assert(!moves && !releases);fakeNow+=500;
  },false,false,600,false);
 }
 // Startup recheck gathers its own evidence without requiring previously valid feedback.
 runWorker(6,[&](unsigned tick){
  const auto status=webStatus();
  if(tick==2){
   assert(!status.commandOk && !status.ready && !status.calibrationOnly);
   modelError=positionError=torqueError=telemetryError=ServoError::None;
  }
  if(tick==2)servoTorque=true;
  if(tick==3){assert(!status.commandOk && !status.calibrationOnly);assert(strstr(status.fault,"torque is ON"));servoTorque=false;servoConfig=false;}
  if(tick==4){assert(!status.commandOk && !status.ready && !status.calibrationOnly);
   assert(strcmp(status.fault,"ST3215 factory profile mismatch; inspect USB diagnostics")==0);configurationReadError=ServoError::Timeout;}
  if(tick==5){
   assert(!status.commandOk && !status.ready && !status.calibrationOnly);
   assert(strcmp(status.fault,"Cannot read ST3215 configuration; check servo communication")==0);
   configurationReadError=ServoError::None;servoConfig=true;
  }
  if(tick==6){
   assert(status.commandOk && status.calibrationOnly && !status.ready && status.manualReady);
  }
  if(tick<6)assert(submitWebCommand(WebCommandType::Recover,1,0,0,tick,false,10,MotionProfile{},1));
  assert(!moves && !releases);fakeNow+=5;
 },false,false,500,false,false);
 // Ambiguous legacy calibration is retained as evidence, never active motion
 // permission. Explicit range application permits teaching only; no automatic move.
 runWorker(3,[&](unsigned tick){
  const auto status=webStatus();
  assert(status.calibrationReview&&!status.calibrated&&status.saved.closed==4000&&status.saved.open==100);
  assert(!status.draft.hasOpen&&!status.draft.openingDirection);
  if(tick==1)assert(submitWebCommand(WebCommandType::Open,1,0,0,1,false,10,MotionProfile{},1));
  if(tick==2){assert(!status.commandOk);assert(submitWebCommand(WebCommandType::SetLimits,1,450,550,2,false,10,MotionProfile{},1));}
  if(tick==3)assert(status.ready&&status.dirty&&status.commandOk);
  assert(!moves&&!releases);fakeNow+=5;
 },false,false,500,true,true,true);
 // Changing direction and capturing application zero never writes a goal or
 // energizes torque; OPEN must follow the explicitly taught negative path.
 runWorker(5,[&](unsigned tick){
  const auto status=webStatus();
  if(tick==1)assert(submitWebCommand(WebCommandType::SetDirection,1,0,0,1,false,10,MotionProfile{},1,-1));
  if(tick==2){assert(status.draft.openingDirection==-1&&!status.draft.hasOpen);assert(submitWebCommand(WebCommandType::CaptureClosed,1,0,0,2,false,10,MotionProfile{},1));}
  if(tick==3){assert(status.draft.closed==500&&!status.draft.hasOpen);servoPosition=530;assert(submitWebCommand(WebCommandType::CaptureOpen,1,0,0,3,false,10,MotionProfile{},1));}
  if(tick==4){assert(!status.commandOk&&!status.draft.hasOpen);servoPosition=470;assert(submitWebCommand(WebCommandType::CaptureOpen,1,0,0,4,false,10,MotionProfile{},1));}
  if(tick==5)assert(status.commandOk&&status.draft.open==470&&status.draft.travelCounts==30);
  assert(!moves&&!releases&&!servoTorque);fakeNow+=5;
 });
 // Begin teaching validates the servo but never moves or clears a fault.
 // The reversed assembly opens with decreasing counts, without a direction command.
 runWorker(6,[&](unsigned tick){
  const auto status=webStatus();
  if(tick==1)assert(submitWebCommand(WebCommandType::BeginTeaching,1,0,0,1,false,10,MotionProfile{},1));
  if(tick==2){assert(status.teaching&&status.ready&&status.draft.circular&&status.draft.minimum==0&&status.draft.maximum==4095);assert(submitWebCommand(WebCommandType::CaptureClosed,1,0,0,2,false,10,MotionProfile{},1));}
  if(tick==3){assert(status.draft.closed==2386&&status.draft.openingDirection==-1);}
  if(tick==4){servoPosition=576;assert(submitWebCommand(WebCommandType::CaptureOpen,1,0,0,4,false,10,MotionProfile{},1));}
  if(tick==5){assert(status.commandOk&&status.draft.travelCounts==1810&&status.draft.open==576);assert(submitWebCommand(WebCommandType::SaveCalibration,1,0,0,5,false,10,MotionProfile{},1));}
  if(tick==6)assert(status.calibrated&&!status.dirty&&!status.teaching&&status.saved.circular);
  assert(!moves&&!releases&&!servoTorque);fakeNow+=5;
 },false,false,2386);
#ifdef COVER_REFERENCE_PROBE
 referenceProbeCalls=0;
 runWorker(8,[&](unsigned tick){
  const auto status=webStatus();
  if(tick==1)assert(submitWebCommand(WebCommandType::BeginTeaching,1,0,0,1,false,10,MotionProfile{},1));
  if(tick==2)assert(submitWebCommand(WebCommandType::ProbeReference,1,0,0,2,false,10,MotionProfile{},1));
  if(tick==3){
   assert(status.referenceProbe.writeAttempted&&!status.calibrated&&!status.ready&&status.dirty);
   assert(!strcmp(status.state,"FAULT")&&status.saved.closed==500&&status.saved.open==400&&referenceProbeCalls==1);
   assert(submitWebCommand(WebCommandType::ProbeReference,1,0,0,3,false,10,MotionProfile{},1));
  }
  if(tick==4){assert(referenceProbeCalls==1&&!status.commandOk);assert(submitWebCommand(WebCommandType::RestoreReference,1,0,0,4,false,10,MotionProfile{},1));}
  if(tick==5){assert(referenceProbeCalls==2&&status.commandOk&&!strcmp(status.state,"FAULT"));assert(submitWebCommand(WebCommandType::Recover,1,0,0,5,false,10,MotionProfile{},1));}
  if(tick==6){assert(status.ready&&!status.calibrated&&!strcmp(status.state,"UNKNOWN"));assert(submitWebCommand(WebCommandType::BeginTeaching,1,0,0,6,false,10,MotionProfile{},1));}
  if(tick==7)assert(submitWebCommand(WebCommandType::CaptureClosed,1,0,0,7,false,10,MotionProfile{},1));
  if(tick==8)assert(status.draft.closed==500&&!status.draft.hasOpen&&!status.calibrated);
  assert(!moves&&!servoTorque);fakeNow+=5;
 });
#endif
 // An explicitly retained CLOSED zero is copied only at stable saved CLOSED,
 // and opening the new draft never energizes the actuator.
 runWorker(2,[&](unsigned tick){
  if(tick==1)assert(submitWebCommand(WebCommandType::BeginTeaching,1,0,0,1,false,10,MotionProfile{},1,0,true));
  if(tick==2){const auto status=webStatus();assert(status.commandOk&&status.teaching&&status.draft.hasClosed&&status.draft.closed==500&&!status.draft.hasOpen&&status.draft.openingDirection==-1);}
  assert(!moves&&!servoTorque);fakeNow+=5;
 });
 runWorker(2,[&](unsigned tick){
  if(tick==1)assert(submitWebCommand(WebCommandType::BeginTeaching,1,0,0,1,false,10,MotionProfile{},1,0,true));
  if(tick==2){const auto status=webStatus();assert(!status.commandOk&&!status.teaching&&!status.dirty);}
  assert(!moves&&!servoTorque);fakeNow+=5;
 },false,false,530);
 // Fine tune resumes teaching with both endpoints preserved and no movement.
 runWorker(3,[&](unsigned tick){
  if(tick==1)assert(submitWebCommand(WebCommandType::BeginTeaching,1,0,0,1,false,10,MotionProfile{},1,0,false,true));
  if(tick==2){const auto status=webStatus();assert(status.commandOk&&status.teaching&&status.dirty);
   assert(status.draft.hasClosed&&status.draft.hasOpen&&status.draft.closed==500&&status.draft.open==400);
   assert(status.saved.closed==500&&status.saved.open==400);assert(!moves&&!servoTorque);}
  fakeNow+=5;
 });
 // Updating CLOSED retains OPEN and rejects an invalid replacement atomically.
 runWorker(6,[&](unsigned tick){
  const auto status=webStatus();
  if(tick==1)assert(submitWebCommand(WebCommandType::BeginTeaching,1,0,0,1,false,10,MotionProfile{},1,0,false,true));
  if(tick==2){servoPosition=510;assert(submitWebCommand(WebCommandType::CaptureClosed,1,0,0,2,false,10,MotionProfile{},1));}
  if(tick==3){assert(status.commandOk&&status.draft.closed==510&&status.draft.hasOpen&&status.draft.open==400&&status.draft.travelCounts==110);
   servoPosition=350;assert(submitWebCommand(WebCommandType::CaptureClosed,1,0,0,3,false,10,MotionProfile{},1));}
  if(tick==4){assert(!status.commandOk&&status.draft.closed==510&&status.draft.open==400&&status.draft.travelCounts==110);
   servoPosition=390;assert(submitWebCommand(WebCommandType::CaptureOpen,1,0,0,4,false,10,MotionProfile{},1));}
  if(tick==5){assert(status.commandOk&&status.draft.closed==510&&status.draft.open==390&&status.draft.travelCounts==120);
   assert(status.saved.closed==500&&status.saved.open==400);assert(!moves&&!servoTorque);}
  fakeNow+=5;
 });
 // Retaining OPEN also recomputes a zero-crossing arc correctly.
 runWorker(6,[&](unsigned tick){
  const auto status=webStatus();
  if(tick==1)assert(submitWebCommand(WebCommandType::BeginTeaching,1,0,0,1,false,10,MotionProfile{},1));
  if(tick==2){servoPosition=200;assert(submitWebCommand(WebCommandType::CaptureClosed,1,0,0,2,false,10,MotionProfile{},1));}
  if(tick==3){servoPosition=4000;assert(submitWebCommand(WebCommandType::CaptureOpen,1,0,0,3,false,10,MotionProfile{},1));}
  if(tick==4){assert(status.commandOk&&status.draft.travelCounts==296);servoPosition=210;assert(submitWebCommand(WebCommandType::CaptureClosed,1,0,0,4,false,10,MotionProfile{},1));}
  if(tick==5){assert(status.commandOk&&status.draft.closed==210&&status.draft.open==4000&&status.draft.travelCounts==306);assert(!moves&&!servoTorque);}
  fakeNow+=5;
 });
 // Updated public jog choices reject the retired one-count command and accept
 // a 500-count step inside the supervised teaching domain.
 runWorker(5,[&](unsigned tick){
  const auto status=webStatus();
  if(tick==1)assert(submitWebCommand(WebCommandType::BeginTeaching,1,0,0,1,false,10,MotionProfile{},1));
  if(tick==2)assert(submitWebCommand(WebCommandType::JogPlus,1,0,0,2,false,1,MotionProfile{},1));
  if(tick==3){assert(!status.commandOk&&!moves);assert(submitWebCommand(WebCommandType::JogPlus,1,0,0,3,false,500,MotionProfile{},1));}
  if(tick==4){
assert(status.commandOk&&moves==1&&status.target==1000&&status.jogStepLimit==500);
   assert(submitWebCommand(WebCommandType::Stop,1));}
  if(tick==5)assert(!servoTorque&&moves==
1
  );
  fakeNow+=5;
 });
 std::puts("Actual servo-worker integration: maintenance, offline settings, motion exclusion and checked startup recovery passed");
}
