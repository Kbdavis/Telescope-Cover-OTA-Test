// Device-independent installer policy; shared with offline regression tests.
export const sha256=async bytes=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),b=>b.toString(16).padStart(2,'0')).join('');
const hash=/^[a-f0-9]{64}$/;
export function validateManifest(m){
 if(m?.schema!==1 || m.name!=='Telescope Cover' || m.profile!=='web_control_multiturn_usb' ||
  !/^\d+\.\d+\.\d+(?:-(?:alpha|beta|rc)\.[1-9]\d*)?$/.test(m.version) ||
  !/^[a-f0-9]{40}$/.test(m.commit) || m.chipFamily!=='ESP32' || m.flash_size!=='4MB' ||
  m.flash_size_bytes!==4194304 || m.flash_mode!=='dio' || m.flash_freq!=='40m')throw Error('Unsupported firmware manifest');
 const i=m.image,p=m.partition;
 if(i?.path!=='factory.bin' || i.offset!==0 || !Number.isInteger(i.size) || i.size<65536 || i.size>0x150000 ||
  !hash.test(i.sha256) || !/^[a-f0-9]{32}$/.test(i.md5) || p?.offset!==0x8000 || p.size!==0xc00 ||
  p.path!=='partitions.bin' || !hash.test(p.sha256))throw Error('Invalid complete installation image');
 const required=['bootloader','partitions','boot_selection','application'];
 if(!Array.isArray(m.components) || m.components.length!==4)throw Error('Incomplete first-install manifest');
 const offsets={bootloader:0x1000,partitions:0x8000,boot_selection:0xe000,application:0x10000};
 let end=0;
 for(const role of required){
  const list=m.components.filter(c=>c.role===role),c=list[0];
  if(list.length!==1 || c.offset!==offsets[role] || !Number.isInteger(c.size) || c.size<=0 ||
   c.offset<end || c.offset+c.size>i.size || !hash.test(c.sha256))throw Error('Missing or overlapping boot components');
  if(role==='partitions' && (c.size!==p.size || c.sha256!==p.sha256))throw Error('Partition manifest mismatch');
  if(role==='application' && (c.size>0x140000 || c.offset+c.size!==i.size))throw Error('Application exceeds pinned slot');
  end=c.offset+c.size;
 }
 return m;
}
export async function validateAssets(m,image,partition){
 validateManifest(m);
 if(!(image instanceof Uint8Array) || image.length!==m.image.size || await sha256(image)!==m.image.sha256)throw Error('Installation image SHA-256 mismatch');
 if(!(partition instanceof Uint8Array) || partition.length!==m.partition.size || await sha256(partition)!==m.partition.sha256)throw Error('Partition file SHA-256 mismatch');
 for(const c of m.components)if(await sha256(image.slice(c.offset,c.offset+c.size))!==c.sha256)throw Error('Boot component hash mismatch');
}
export async function classifyPartition(data,m){
 if(!(data instanceof Uint8Array) || data.length!==m.partition.size)throw Error('Could not read the complete partition table; nothing will be erased');
 if(data.every(b=>b===255))return 'blank-table';
 return await sha256(data)===m.partition.sha256?'compatible':'unrecognized';
}
export class InstallSession {
 constructor(loader,manifest,image,partition){this.loader=loader;this.manifest=manifest;this.image=image;this.partition=partition;this.phase='new';}
 async inspect(){
  if(this.phase!=='new')throw Error('Reconnect before inspecting again');
  this.phase='inspecting';
  try{
   await validateAssets(this.manifest,this.image,this.partition);
   if(this.loader.chip?.CHIP_NAME!=='ESP32' || await this.loader.detectFlashSize()!=='4MB')throw Error('Only the supported ESP32 with 4 MB flash is allowed');
   this.observed=await this.loader.readFlash(this.manifest.partition.offset,this.manifest.partition.size);
   const status=await classifyPartition(this.observed,this.manifest);
   this.observedHash=await sha256(this.observed);this.phase='inspected';return status;
  }catch(error){this.phase='failed';throw error;}
 }
 cancel(){if(this.phase==='inspected')this.phase='cancelled';}
 async install({eraseConfirmed=false,boardConfirmed=false,mechanismDetached=false,progress=()=>{}}={}){
  if(this.phase!=='inspected' || !eraseConfirmed || !boardConfirmed || !mechanismDetached)throw Error('Explicit erase, board and detached-mechanism confirmations are required');
  this.phase='checking';
  try{
   // Fresh read on this same connection prevents stale inspection admission.
   if(this.loader.chip?.CHIP_NAME!=='ESP32' || await this.loader.detectFlashSize()!=='4MB')throw Error('Connected device changed');
   const table=await this.loader.readFlash(this.manifest.partition.offset,this.manifest.partition.size);
   await classifyPartition(table,this.manifest);
   if(await sha256(table)!==this.observedHash)throw Error('Partition table changed; reconnect and inspect again');
   await validateAssets(this.manifest,this.image,this.partition);
   this.phase='erasing';progress('Erasing settings and firmware…');await this.loader.eraseFlash();
   this.phase='writing';
   // Keep the exact image headers; its flash settings were validated at packaging.
   await this.loader.writeFlash({fileArray:[{data:this.image,address:0}],flashMode:'keep',flashFreq:'keep',flashSize:'4MB',eraseAll:false,compress:true,
    reportProgress:(_index,written,total)=>progress(`Writing ${Math.round(100*written/total)}%`)});
   this.phase='verifying';progress('Verifying written image…');
   if((await this.loader.flashMd5sum(0,this.image.length)).toLowerCase()!==this.manifest.image.md5)throw Error('Written image verification failed; keep servo power disconnected and use USB recovery');
   this.phase='verified';await this.loader.after('hard_reset');this.phase='restarted';
   return {verified:true,startupConfirmed:false};
  }catch(error){this.phase='failed';throw error;}
 }
}
