import {InstallSession,validateAssets} from './core.mjs';
const $=id=>document.getElementById(id),status=message=>$('status').textContent=message;
const log=message=>{$('log').textContent=($('log').textContent+message+'\n').slice(-24000);};
let manifest,image,partition,loader,transport,session,busy=false;
const fetchBytes=async path=>{const r=await fetch(path,{cache:'no-store'});if(!r.ok)throw Error(`Could not load ${path}`);return new Uint8Array(await r.arrayBuffer());};
function ready(){ $('connect').disabled=busy||!!session||!manifest||!$('board').checked||!$('detached').checked;$('disconnect').disabled=busy||!session; }
async function disconnect(){try{await transport?.disconnect();}catch(error){log(`USB disconnect: ${error.message}`);}finally{session=null;loader=null;transport=null;ready();}}
window.addEventListener('beforeunload',event=>{if(busy){event.preventDefault();event.returnValue='';}});
for(const id of ['board','detached'])$(id).onchange=ready;
async function prepare(){
 if(!window.isSecureContext||!navigator.serial){status('Use desktop Chrome or Edge on HTTPS, or localhost for a local preview.');return;}
 try{
  const bytes=await fetchBytes('manifest.json');manifest=JSON.parse(new TextDecoder().decode(bytes));
  // Fixed paths; untrusted manifest values never become fetch URLs.
  [image,partition]=await Promise.all([fetchBytes('factory.bin'),fetchBytes('partitions.bin')]);
  await validateAssets(manifest,image,partition);
  $('release').textContent=`Firmware ${manifest.version} · source ${manifest.commit.slice(0,7)}`;
  status('Ready to connect. No flash changes occur until you explicitly confirm erase and install.');ready();
 }catch(error){manifest=null;status(`Installer unavailable: ${error.message}`);}
}
$('connect').onclick=async()=>{
 if(busy||session||!manifest||!$('board').checked||!$('detached').checked)return;
 busy=true;ready();$('next').hidden=true;
 try{
  const port=await navigator.serial.requestPort();
  const {ESPLoader,Transport}=await import('https://unpkg.com/esptool-js@0.7.1/bundle.js');
  transport=new Transport(port,true);loader=new ESPLoader({transport,baudrate:115200,terminal:{clean(){},write:log,writeLine:log}});
  status('Connecting and reading partition layout…');await loader.main();
  session=new InstallSession(loader,manifest,image,partition);const layout=await session.inspect();
  $('layout').textContent=layout==='compatible'?'The existing partition table matches this release.':layout==='blank-table'?'The partition table area is blank. Other flash contents may still exist.':'This controller needs a different storage layout. Its existing table is incompatible or unrecognized.';
  $('confirm').showModal();$('cancel').focus();status('Connected. Review the installation confirmation.');
 }catch(error){status(`Connection or inspection failed: ${error.message}`);await disconnect();}
 finally{busy=false;ready();}
};
async function cancel(){if(busy)return;session?.cancel();$('confirm').close();await disconnect();status('Cancelled. No flash erase or write was performed. Connection may have reset the controller.');}
$('cancel').onclick=cancel;$('confirm').addEventListener('cancel',event=>{event.preventDefault();cancel();});
$('disconnect').onclick=async()=>{await disconnect();status('Disconnected.');};
$('install').onclick=async()=>{
 if(busy||session?.phase!=='inspected')return;
 if(!$('board').checked||!$('detached').checked){await cancel();return;}
 busy=true;ready();$('install').disabled=true;$('cancel').disabled=true;
 $('confirm').close();
 try{
  await session.install({eraseConfirmed:true,boardConfirmed:$('board').checked,mechanismDetached:$('detached').checked,progress:status});
  status('Flash verified. Restart requested; startup and servo validation still need confirmation.');$('next').hidden=false;
 }catch(error){status(`Installation incomplete: ${error.message}. Keep external servo power disconnected; follow USB recovery.`);}
 finally{await disconnect();busy=false;$('install').disabled=false;$('cancel').disabled=false;ready();}
};
prepare();
