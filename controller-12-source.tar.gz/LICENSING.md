# Project licensing

Copyright (c) 2026 Kirk Davis for original project material. Existing contributor
and third-party copyright notices remain in effect. The following scope rules
apply to material authored for Telescope Cover; third-party exceptions take
precedence over directory defaults.

| Material | License | Coverage |
| --- | --- | --- |
| Software | [MIT](LICENSE) | Original firmware in `src/`, headers in `include/`, code and web UI in `data/` and `installer/`, tools, tests, build configuration and workflows; original CAD-generation/validation scripts are also software |
| Hardware designs | [CERN-OHL-S-2.0](LICENSES/CERN-OHL-S-2.0.txt) | Original mechanical/electrical designs, editable CAD, printable exports, drawings, and design parameters, including original design content in CAD-generation scripts |
| Documentation and media | [CC BY 4.0](LICENSES/CC-BY-4.0.txt) | Original prose, guides, BOMs, diagrams, project photos and illustrations in this repository, including README/AGENTS files, Markdown documents within code/CAD directories, and generated manual HTML/PDF files |

A CAD-generation script's program code is MIT; the original hardware design it
expresses and its generated design files are CERN-OHL-S-2.0. Design drawings are
hardware source; explanatory documentation diagrams are CC BY 4.0. Files with
explicit third-party terms keep those terms. These project grants cover only
rights held by the project authors, including original contributions to mixed
files; they do not relicense imported components.

For CC BY attribution, credit Kirk Davis / Telescope Cover, link to
https://github.com/Kbdavis/Telescope-Cover and the license, retain supplied
notices, and identify modifications. Preserve any other supplied creator credits.
The project repository is the Source Location for original hardware designs;
when distributing a particular revision, identify its exact commit/tag and
provide the Complete Source required by CERN-OHL-S-2.0. Repository visibility
and availability must be resolved before relying on that URL for distribution.

## Third-party exceptions and release review

- `tests/vendor/cjson/` keeps its upstream MIT license and copyright notices.
- The embedded pIqaD font keeps SIL OFL 1.1; see
  [font copyright and full license](docs/licenses/klingon-font.txt).
- Manufacturer models, drawings, archives and images, including references in
  `cad/servo_cradle/manufacturer/` and `cad/controller_case_v1/source/`, are not
  granted a project license. Project-authored scripts/prose in those directories
  follow the table above. CAD assemblies, screenshots and exports that contain
  imported reference geometry require review too; location outside a reference
  directory does not establish redistribution rights.
- Third-party software, libraries, assets and license texts retain their own
  terms. See [the dependency inventory](THIRD_PARTY_NOTICES.md).

Before making the GitHub repository public, review all tracked files and history
for third-party redistribution rights, especially manufacturer references and
assemblies containing them. An attachment allowlist does not remove these files
from GitHub's automatic source archives. Permission, removal from the public
release source, or another documented redistribution basis is still required.
Do not assume that a publicly downloadable reference has an open-source license.

## License text provenance

MIT follows the [OSI text](https://opensource.org/license/mit), with the project
copyright notice. The unmodified CERN text is from the
[SPDX license-text mirror](https://github.com/spdx/license-list-data/blob/main/text/CERN-OHL-S-2.0.txt),
identifier confirmed against [CERN's license variants](https://cern-ohl.web.cern.ch/).
CC BY 4.0 is the [Creative Commons legal text](https://creativecommons.org/licenses/by/4.0/legalcode.txt).

The selected project licenses do not establish dependency clearance, hardware
qualification, or a published release. Include applicable license texts and
notices with each distribution; the multi-turn candidate packager includes this scope document, project license
texts and font notices. Framework/browser dependency clearance remains pending.
