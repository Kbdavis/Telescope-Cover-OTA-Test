import contextlib
import hashlib
import io
import os
from pathlib import Path
import struct
import sys
import tempfile
import unittest
from unittest.mock import Mock,patch
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'tools'))
from ota_dev_setup import provision,header_for
from ota_upload import Artifact,DevelopmentUploader,DEVELOPMENT_MARKER,WorkflowError,load_secret,upload_development,main
from ota_upload_test import HttpFixture,TransferFixture,ARTIFACT,SECRET,TX,completion
from ota_manifest_test import image_fixture,elf_fixture
from firmware_build_test import partition_table
from ota_manifest import manifest_for_build


def dev_artifact():
    data=bytearray(image_fixture()[:352]+DEVELOPMENT_MARKER)
    struct.pack_into('<I',data,28,len(data)-32)
    checksum=0xef
    for byte in data[32:]:checksum^=byte
    end=(len(data)//16+1)*16-1;data+=b'\0'*(end-len(data))+bytes([checksum])
    return Artifact(bytes(data)+hashlib.sha256(data).digest())


class DevelopmentTest(unittest.TestCase):
    def test_release_validator_excludes_development_while_explicit_local_build_allows_it(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);elf=elf_fixture();image=bytearray(dev_artifact().image)
            image[176:208]=hashlib.sha256(elf).digest();checksum=0xef
            for byte in image[32:32+struct.unpack_from('<I',image,28)[0]]:checksum^=byte
            image[-33]=checksum;image[-32:]=hashlib.sha256(image[:-32]).digest()
            (root/'firmware.bin').write_bytes(image);(root/'firmware.elf').write_bytes(elf)
            (root/'partitions.bin').write_bytes(partition_table())
            with self.assertRaisesRegex(ValueError,'excluded from production'):
                manifest_for_build(root)
            self.assertEqual(manifest_for_build(root,allow_development=True)['elf'],hashlib.sha256(elf).hexdigest())
    def test_provision_is_private_and_idempotent_without_printing_or_rotating_secret(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);(root/'include').mkdir()
            with contextlib.redirect_stdout(io.StringIO()) as output:self.assertTrue(provision(root))
            secret=load_secret(root/'.ota-dev/secret');header=root/'include/ota_dev_local.h'
            self.assertEqual(header.read_text(),header_for(secret))
            self.assertEqual(header.stat().st_mode&0o777,0o600)
            self.assertEqual((root/'.ota-dev').stat().st_mode&0o777,0o700)
            self.assertFalse(provision(root));self.assertEqual(load_secret(root/'.ota-dev/secret'),secret)
            self.assertNotIn(secret.decode(),output.getvalue())
    def test_mismatched_header_and_shared_secret_are_not_overwritten(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);(root/'include').mkdir();provision(root)
            header=root/'include/ota_dev_local.h';header.write_text('DO NOT OVERWRITE\n')
            with self.assertRaises(WorkflowError):provision(root)
            self.assertEqual(header.read_text(),'DO NOT OVERWRITE\n')
            header.write_text(header_for(load_secret(root/'.ota-dev/secret')))
            (root/'.ota-dev/secret').chmod(0o644)
            with self.assertRaises(WorkflowError):provision(root)
    def test_symlinked_private_directory_is_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);(root/'include').mkdir();(root/'other').mkdir();(root/'.ota-dev').symlink_to(root/'other',target_is_directory=True)
            with self.assertRaises(WorkflowError):provision(root)
            self.assertFalse((root/'other/secret').exists())
    def test_dev_controller_and_matching_durable_boot_required(self):
        http=HttpFixture();http.status['ota']['development']=True;http.states[-1]['development']=True
        result=DevelopmentUploader(http,TransferFixture(),clock=http.clock,sleep=http.clock.sleep).run(ARTIFACT,SECRET,closed_cover=True)
        self.assertEqual(result.outcome,'COMPLETE')
        http=HttpFixture()
        with self.assertRaisesRegex(WorkflowError,'bootstrap'):
            DevelopmentUploader(http,TransferFixture(),clock=http.clock,sleep=http.clock.sleep).run(ARTIFACT,SECRET,closed_cover=True)
        self.assertEqual([x[1] for x in http.calls],['/api/status'])
    def test_stationary_dev_upload_has_no_closed_confirmation_or_position_requirement(self):
        for state in ['OPEN', 'STOPPED', 'UNKNOWN']:
            http=HttpFixture();http.status['ota'].update(development=True,admission_policy='development-stationary')
            http.status['state']=state;http.states[-1]['development']=True
            result=DevelopmentUploader(http,TransferFixture(),clock=http.clock,sleep=http.clock.sleep).run(ARTIFACT,SECRET)
            self.assertEqual(result.outcome,'COMPLETE')
            prepare=next(c[2] for c in http.calls if c[1]=='/api/ota/prepare')
            self.assertIn(b'policy=development-stationary\n',prepare)
        for field,value in [('moving',True),('holding',True),('torque',None),('dirty',True),('ready',False),('state','FAULT')]:
            http=HttpFixture();http.status['ota'].update(development=True,admission_policy='development-stationary')
            http.status[field]=value
            with self.subTest(field=field),self.assertRaises(WorkflowError):
                DevelopmentUploader(http,TransferFixture(),clock=http.clock,sleep=http.clock.sleep).run(ARTIFACT,SECRET)
            self.assertEqual([c[1] for c in http.calls],['/api/status'])

    def test_recovery_dev_upload_accepts_faulted_uncalibrated_dirty_controller(self):
        http=HttpFixture();http.status['ota'].update(development=True,admission_policy='development-recovery')
        http.status.update(state='FAULT',dirty=True,ready=False,calibrated=False,holding=False)
        http.states[-1]['development']=True
        result=DevelopmentUploader(http,TransferFixture(),clock=http.clock,sleep=http.clock.sleep).run(ARTIFACT,SECRET)
        self.assertEqual(result.outcome,'COMPLETE')
        prepare=next(c[2] for c in http.calls if c[1]=='/api/ota/prepare')
        self.assertIn(b'policy=development-recovery\n',prepare)
        for field,value in [('moving',True),('holding',True),('holding',None),('torque',True),('torque',None),('age_ms',1001)]:
            http=HttpFixture();http.status['ota'].update(development=True,admission_policy='development-recovery')
            http.status.update(state='FAULT',dirty=True,ready=False,calibrated=False,holding=False)
            http.status[field]=value
            with self.subTest(field=field,value=value),self.assertRaises(WorkflowError):
                DevelopmentUploader(http,TransferFixture(),clock=http.clock,sleep=http.clock.sleep).run(ARTIFACT,SECRET)
            self.assertEqual([c[1] for c in http.calls],['/api/status'])

    def test_non_development_target_cannot_be_confirmed_by_dev_client(self):
        state=completion()
        self.assertIsNone(DevelopmentUploader.verdict(state,TX,'a'*64,'33'*32,'1'*32))
        state['development']=True
        self.assertEqual(DevelopmentUploader.verdict(state,TX,'a'*64,'33'*32,'1'*32),'COMPLETE')

    def test_recovery_receiver_preserves_clean_calibrated_powered_update_path(self):
        http=HttpFixture();http.status['ota'].update(development=True,admission_policy='development-recovery')
        http.status.update(torque=True,holding=False);http.states[-1]['development']=True
        result=DevelopmentUploader(http,TransferFixture(),clock=http.clock,sleep=http.clock.sleep).run(ARTIFACT,SECRET)
        self.assertEqual(result.outcome,'COMPLETE')
        prepare=next(c[2] for c in http.calls if c[1]=='/api/ota/prepare')
        self.assertIn(b'policy=development-stationary\n',prepare)
    def test_support_flag_and_dev_artifact_checked_before_secret_or_network(self):
        with patch('ota_upload.Artifact.load',return_value=ARTIFACT) as artifact,patch('ota_upload.load_secret') as secret,patch('ota_upload.socket.socket') as network:
            with self.assertRaisesRegex(WorkflowError,'web_control_dev'):upload_development('build','192.168.1.2','secret',closed_cover=True)
            secret.assert_not_called();network.assert_not_called()
    def test_live_entry_uses_existing_authenticated_uploader_and_pinned_route(self):
        route=Mock();route.getsockname.return_value=('192.168.1.3',1234)
        factory=Mock();factory.return_value.__enter__=Mock(return_value=route);factory.return_value.__exit__=Mock(return_value=False)
        engine=Mock();engine.run.return_value=Mock(outcome='COMPLETE',transaction=TX)
        with patch('ota_upload.Artifact.load',return_value=dev_artifact()),patch('ota_upload.load_secret',return_value=SECRET),patch('ota_upload.socket.socket',factory),patch('ota_upload.DevelopmentUploader',return_value=engine),patch('ota_upload.LocalHttp') as http,patch('ota_upload.EspotaTransfer') as transfer:
            result=upload_development('build','192.168.1.2','private-secret',closed_cover=True)
        self.assertEqual(result.outcome,'COMPLETE');route.connect.assert_called_once_with(('192.168.1.2',80))
        http.assert_called_once_with('192.168.1.2','192.168.1.3');transfer.assert_called_once_with('192.168.1.2','192.168.1.3')
        self.assertTrue(engine.run.call_args.kwargs['closed_cover'])
    def test_cli_requires_explicit_host_and_support_before_access(self):
        for args in [['upload-dev','missing'],['upload-dev','missing','--closed-cover']]:
            with patch('ota_upload.Artifact.load') as artifact,contextlib.redirect_stderr(io.StringIO()),self.assertRaises(SystemExit):main(args)
            artifact.assert_not_called()
    def test_cli_emits_only_verdict_and_transaction(self):
        result=Mock(outcome='COMPLETE',transaction=TX)
        with patch('ota_upload.upload_development',return_value=result),contextlib.redirect_stdout(io.StringIO()) as output:
            main(['upload-dev','build','--host','192.168.1.2','--closed-cover'])
        self.assertIn('COMPLETE',output.getvalue());self.assertNotIn(SECRET.decode(),output.getvalue())


if __name__=='__main__':unittest.main()
