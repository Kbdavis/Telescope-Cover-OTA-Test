from pathlib import Path
import sys
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'tools'))
from probe_usb_http import check_state,compare
from ota_upload import WorkflowError
from summarize_usb_memory_test import fixture

def state():
    return dict(ready=True,moving=False,torque=False,dirty=False,calibrated=True,uptime_ms=20000,
                maintenance=dict(locked=False),resources=dict(state='off',viewers=0),
                ota=dict(firmware_id='a'*64,boot_id='b'*32,startup='accepted',available=False,active=False))

class HttpMemoryTest(unittest.TestCase):
    def test_drop_and_recovery_are_reported_without_leak_claim(self):
        text=fixture().replace('http=0 status_http=0','http=20 status_http=20')
        lines=[]
        for line in text.splitlines():
            if ' USBMEM heap ' in line and 20000<=int(line[1:line.index(']')])<=40000:
                line=line.replace('internal_free=160000','internal_free=130000')
            lines.append(line)
        result=compare('\n'.join(lines),[dict(uptime_ms=t) for t in range(20000,40000,1000)],20,140)
        self.assertTrue(result['controlled_client_only']);self.assertEqual(result['before_median_free'],160000)
        self.assertEqual(result['load_minimum_sampled_free'],130000);self.assertEqual(result['median_recovered_change'],0)
    def test_other_traffic_is_not_called_isolated(self):
        result=compare(fixture(22),[dict(uptime_ms=20000)],20,140)
        self.assertFalse(result['controlled_client_only'])
    def test_changed_boot_torque_metrics_and_missing_uptime_rejected(self):
        self.assertEqual(check_state(state(),'a'*64),'b'*32)
        cases=[]
        for key,value in [('ready',False),('moving',True),('torque',True),('dirty',True),('uptime_ms',None)]:
            s=state();s[key]=value;cases.append(s)
        s=state();s['resources']['state']='active';cases.append(s)
        for s in cases:
            with self.assertRaises(WorkflowError):check_state(s,'a'*64)
        with self.assertRaises(WorkflowError):check_state(state(),'a'*64,'c'*32)
    def test_short_recovery_and_no_responses_are_not_complete(self):
        for responses,quiet in [([],140),([dict(uptime_ms=20000)],120)]:
            with self.assertRaises(WorkflowError):compare(fixture(),responses,1,quiet)

if __name__=='__main__':unittest.main()
