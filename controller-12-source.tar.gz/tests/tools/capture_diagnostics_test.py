import contextlib
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('capture', Path(__file__).resolve().parents[2] / 'tools/capture_diagnostics.py')
capture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(capture)


class CaptureTests(unittest.TestCase):
    def test_capture_preserves_panic_redacts_password_and_archives_build(self):
        class FakeSerial:
            in_waiting = 64
            def __init__(self, **kwargs):
                self.chunks = iter([b'BOOT\nSETUP AP: password=secret address=1.2.3.4\nGuru Med', b'itation Error\nBacktrace: 0x40081234:0x3ffb0000\n'])
            def open(self):
                assert self.dtr is False and self.rts is False
            def close(self):
                pass
            def read(self, count):
                try:
                    return next(self.chunks)
                except StopIteration:
                    raise KeyboardInterrupt
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            build = root / 'build'
            build.mkdir()
            for name in ('firmware.elf', 'firmware.bin'):
                (build / name).write_bytes(name.encode())
            args = ['capture', '--build-dir', str(build), '--output', str(root / 'logs')]
            serial = types.SimpleNamespace(Serial=FakeSerial, SerialException=OSError)
            with patch.object(sys, 'argv', args), patch.dict(sys.modules, serial=serial), contextlib.redirect_stdout(io.StringIO()):
                capture.main()
            folder = next((root / 'logs').iterdir())
            text = (folder / 'serial.log').read_text()
            self.assertIn('Guru Meditation Error', text)
            self.assertIn('Backtrace: 0x40081234:0x3ffb0000', text)
            self.assertNotIn('secret', text)
            self.assertIn('password=[redacted]', text)
            manifest = json.loads((folder / 'manifest.json').read_text())
            self.assertEqual(manifest['artifacts_sha256']['firmware.elf'], hashlib.sha256(b'firmware.elf').hexdigest())
            self.assertEqual((folder / 'firmware.bin').read_bytes(), b'firmware.bin')


if __name__ == '__main__':
    unittest.main()
