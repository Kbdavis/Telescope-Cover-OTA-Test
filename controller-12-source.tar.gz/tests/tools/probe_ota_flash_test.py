import copy
from pathlib import Path
import sys
import unittest
from unittest.mock import patch,Mock
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'tools'))
from ota_manifest import control_mac
from ota_manifest_test import image_fixture
from ota_upload import Artifact,WorkflowError
from probe_ota_flash import FlashProbe,Observer as RealObserver,MODE,PREFIX,check_state,validate_slot_backup,verified_result

SECRET=b'PUBLIC-TEST-CANARY-DO-NOT-DEPLOY-0123456789';SOURCE='a'*64;BOOT='b'*32;TX='c'*32
ARTIFACT=Artifact(image_fixture())

class Http:
    def __init__(self):self.stage='idle';self.metrics=False;self.calls=[];self.lose_subscribe=False;self.listener=None;self.corrupt=False
    def state(self):
        manifest=ARTIFACT.manifest;done=self.stage=='verified'
        return dict(ready=True,calibrated=True,dirty=False,moving=False,torque=False,uptime_ms=1000,control_generation=7,
                    maintenance=dict(locked=self.stage in ('armed','receiving')),
                    resources=dict(state='active' if self.metrics else 'off',viewers=int(self.metrics),available=self.metrics,epoch=int(self.metrics),
                                   internal_free_heap_bytes=150000,internal_min_free_heap_bytes=130000,internal_largest_free_block_bytes=100000,
                                   task_stacks=dict(ota=dict(min_free_bytes=2000,sample_age_ms=0))),
                    ota=dict(available=False,startup='accepted',firmware_id=SOURCE,boot_id=BOOT,active=self.stage in ('armed','receiving'),
                             phase=self.stage,reason='probe_verified_not_activated' if done else 'flash_probe_ready',transaction=TX,
                             received=manifest['size'] if done else 0,
                             probe=dict(mode=MODE,available=self.stage=='idle',attempted=self.stage!='idle',verified=done,
                                        source_slot=0x10000,target_slot=0x150000,target_firmware=manifest['elf'],sha256='f'*64 if self.corrupt else manifest['sha256'])))
    def request(self,method,path,body=None,headers=None):
        self.calls.append((method,path,body,headers))
        if path=='/api/status':return 200,self.state()
        if path=='/api/session':return 200,dict(boot_id=BOOT,beta_accepted=True,setup_only=False,token='SESSION-CANARY')
        if path==PREFIX+'/memory':
            assert self.metrics and self.stage not in ('armed','receiving')
            return 200,dict(schema=1,scope='boundary_samples',boot_id=BOOT,epoch=1,storage_bytes=484,
                            rows=[dict(stage='write_before',ota_active=True,count=3,min_free=130000,min_block=100000,at_ms=2000,max_bytes=1024)])
        if path.startswith('/api/diagnostics/metrics/'):
            assert headers['X-Cover-Token']=='SESSION-CANARY'
            if path.endswith('/subscribe'):
                self.metrics=True
                if self.lose_subscribe:raise WorkflowError('lost response')
            if path.endswith('/unsubscribe'):self.metrics=False
            return 200,dict(accepted=True)
        if path==PREFIX+'/challenge':return 200,dict(schema=1,boot_id=BOOT,nonce='1'*32,expires_ms=10000)
        if path in (PREFIX+'/prepare',PREFIX+'/cancel'):
            tx=TX if path.endswith('/cancel') else ''
            assert headers['X-Ota-Mac']==control_mac(SECRET,'POST',path,BOOT,'1'*32,tx,body)
            if path.endswith('/prepare'):
                assert self.listener.open;self.stage='armed'
                return 202,self.state()['ota']
            self.stage='cancelled';return 202,None
        raise AssertionError('Unexpected endpoint')

class Sender:
    def __init__(self,http):self.http=http;http.listener=self;self.open=False;self.progress=None;self.fail=False
    def __enter__(self):self.open=True;return self
    def __exit__(self,*_):self.open=False
    def send(self,artifact,secret):
        assert secret==SECRET and artifact.image==ARTIFACT.image and self.open
        self.http.stage='receiving'
        self.progress(1,1)
        if self.fail:raise WorkflowError('transport lost')
        self.http.stage='verified'

class Observer:
    def __init__(self,http,source,boot,viewer,record):self.http=http;self.error=False;self.samples=[];self.record=record;self.closed=False
    def start(self):
        self.samples.append(self.http.state()['resources']);self.record('status',self.http.state())
    @property
    def latest(self):return self.http.state()
    def close(self):self.closed=True
    def progress(self,*_):pass

class ProbeTest(unittest.TestCase):
    def test_passive_usb_never_opens_metrics_session_or_posts_metrics(self):
        http=Http();sender=Sender(http)
        with patch('probe_ota_flash.Observer',Observer),patch('probe_ota_flash.time.sleep',lambda _:None):
            result=FlashProbe(http,sender,SOURCE,SECRET,passive_usb=True).run(ARTIFACT,supported_cover_off=True)
        self.assertEqual(result['outcome'],'VERIFIED_NOT_ACTIVATED')
        self.assertEqual(result['measurement'],'passive_usb')
        self.assertFalse(http.metrics)
        self.assertFalse(any('/metrics/' in p or p=='/api/session' for _,p,*_ in http.calls))
        self.assertNotIn('internal_free_heap_bytes',result)
    def test_passive_failure_still_cancels_without_metrics(self):
        http=Http();sender=Sender(http);sender.fail=True
        with patch('probe_ota_flash.Observer',Observer),patch('probe_ota_flash.time.sleep',lambda _:None):
            with self.assertRaises(WorkflowError):
                FlashProbe(http,sender,SOURCE,SECRET,passive_usb=True).run(ARTIFACT,supported_cover_off=True)
        self.assertEqual(http.stage,'cancelled');self.assertFalse(http.metrics)
    def test_passive_observer_requires_metrics_off_and_does_not_renew(self):
        for enabled in (False,True):
            http=Http();http.metrics=enabled
            observer=RealObserver(http,SOURCE,BOOT,None,lambda *_:None)
            observer.stop=Mock();observer.stop.is_set.side_effect=[False,True]
            observer.run()
            self.assertEqual(observer.error,enabled)
            self.assertEqual([p for _,p,*_ in http.calls],['/api/status'])
    def test_passive_cannot_request_metrics_boundary_evidence(self):
        with self.assertRaises(WorkflowError):
            FlashProbe(Http(),None,SOURCE,SECRET,passive_usb=True,memory_evidence=True)
    def run_probe(self,http,sender=None):
        sender=sender or Sender(http);records=[];probe=FlashProbe(http,sender,SOURCE,SECRET,lambda k,s:records.append((k,s)))
        with patch('probe_ota_flash.Observer',Observer),patch('probe_ota_flash.time.sleep',lambda _:None):
            result=probe.run(ARTIFACT,supported_cover_off=True)
        return result,records,probe
    def test_success_is_never_complete_and_only_probe_or_metrics_posts(self):
        http=Http();result,records,probe=self.run_probe(http)
        self.assertEqual(result['outcome'],'VERIFIED_NOT_ACTIVATED');self.assertFalse(http.metrics)
        self.assertEqual(probe.secret,b'');self.assertNotIn(SECRET.decode(),repr(result)+repr(records))
        self.assertNotIn('SESSION-CANARY',repr(result)+repr(records))
        posts=[p for m,p,*_ in http.calls if m=='POST']
        self.assertTrue(all(p.startswith('/api/diagnostics/metrics/') or p==PREFIX+'/prepare' for p in posts))
        self.assertFalse(any(p in ('/api/ota/prepare','/api/ota/cancel') for _,p,*_ in http.calls))
    def test_sender_failure_cancels_original_transaction_and_metrics(self):
        http=Http();sender=Sender(http);sender.fail=True
        records=[]
        with patch('probe_ota_flash.Observer',Observer),patch('probe_ota_flash.time.sleep',lambda _:None):
            with self.assertRaises(WorkflowError):
                FlashProbe(http,sender,SOURCE,SECRET,lambda k,s:records.append((k,s))).run(ARTIFACT,supported_cover_off=True)
        self.assertFalse(http.metrics);self.assertEqual(http.stage,'cancelled');self.assertFalse(sender.open)
        self.assertIn(('failure',dict(category='WorkflowError',reason='transport lost')),records)
        self.assertNotIn(SECRET.decode(),repr(records));self.assertNotIn('SESSION-CANARY',repr(records))
    def test_lost_metrics_subscribe_response_still_unsubscribes(self):
        http=Http();http.lose_subscribe=True
        with self.assertRaises(WorkflowError):self.run_probe(http)
        self.assertFalse(http.metrics)
        self.assertFalse(any(p==PREFIX+'/prepare' for _,p,*_ in http.calls))
    def test_memory_collected_after_success_and_before_metrics_close(self):
        http=Http();sender=Sender(http);records=[]
        with patch('probe_ota_flash.Observer',Observer),patch('probe_ota_flash.time.sleep',lambda _:None):
            result=FlashProbe(http,sender,SOURCE,SECRET,lambda k,s:records.append((k,s)),memory_evidence=True).run(ARTIFACT,supported_cover_off=True)
        self.assertEqual(result['memory_boundaries']['rows'][0]['min_free'],130000)
        self.assertTrue(any(k=='memory_boundaries' for k,_ in records));self.assertFalse(http.metrics)
    def test_memory_collected_after_failed_transfer_cancellation(self):
        http=Http();sender=Sender(http);sender.fail=True;records=[]
        with patch('probe_ota_flash.Observer',Observer),patch('probe_ota_flash.time.sleep',lambda _:None):
            with self.assertRaises(WorkflowError):
                FlashProbe(http,sender,SOURCE,SECRET,lambda k,s:records.append((k,s)),memory_evidence=True).run(ARTIFACT,supported_cover_off=True)
        self.assertTrue(any(k=='memory_boundaries' for k,_ in records));self.assertFalse(http.metrics)
    def test_memory_report_rejects_wrong_boot_or_duplicate_rows(self):
        http=Http();http.stage='verified';http.metrics=True;probe=FlashProbe(http,Sender(http),SOURCE,SECRET);probe.boot=BOOT
        _,good=http.request('GET',PREFIX+'/memory')
        probe.memory_epoch=1
        for bad in (dict(good,boot_id='d'*32),dict(good,rows=good['rows']*2),dict(good,epoch=0),dict(good,epoch=2),
                    dict(good,rows=[dict(good['rows'][0],stage={})])):
            with patch.object(http,'request',return_value=(200,bad)):
                with self.assertRaises(WorkflowError):probe.capture_memory()
        self.assertIsNone(probe.memory)
    def test_backup_must_be_entirely_erased_and_exact_size(self):
        self.assertEqual(len(validate_slot_backup(b'\xff'*0x140000)),64)
        for value in (b'',b'\xff'*0x13ffff,b'\xff'*0x140000+b'\xff',b'\0'+b'\xff'*0x13ffff):
            with self.assertRaises(WorkflowError):validate_slot_backup(value)
    def test_changed_boot_or_enabled_production_admission_rejected(self):
        s=Http().state();s['ota']['available']=True
        with self.assertRaises(WorkflowError):check_state(s,SOURCE)
        s=Http().state()
        with self.assertRaises(WorkflowError):check_state(s,SOURCE,'d'*32)
    def test_final_evidence_checks_slot_identity_hash_cleanup_and_boot(self):
        http=Http();http.stage='verified';s=http.state()
        self.assertTrue(verified_result(s,TX,ARTIFACT.manifest,SOURCE,BOOT))
        for section,key,value in [('ota','transaction','e'*32),('ota','active',True),('probe','target_slot',0x10000),('probe','sha256','e'*64),('probe','target_firmware',SOURCE),('probe','verified',False),('maintenance','locked',True)]:
            bad=copy.deepcopy(s)
            (bad['ota']['probe'] if section=='probe' else bad[section])[key]=value
            self.assertFalse(verified_result(bad,TX,ARTIFACT.manifest,SOURCE,BOOT))

if __name__=='__main__':unittest.main()
