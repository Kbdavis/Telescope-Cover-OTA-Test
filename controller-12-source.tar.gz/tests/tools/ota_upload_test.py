import contextlib
import copy
import hashlib
import hmac
import io
import json
from pathlib import Path
import socket
import struct
import subprocess
import sys
import tempfile
import threading
import unittest
from unittest.mock import patch
from http.server import BaseHTTPRequestHandler, HTTPServer

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'tools'))
from ota_manifest import control_mac
from ota_manifest_test import image_fixture
from ota_upload import Artifact, EspotaTransfer, LocalHttp, Result, Uploader, WorkflowError, load_secret

SECRET = b'CANARY-OTA-private-credential-0123456789'
BOOT, NEW_BOOT, TX = '1' * 32, '2' * 32, '4' * 32
SOURCE, TARGET = 'a' * 64, '33' * 32
def transfer_image():
    image = bytearray(image_fixture()[:352] + b'fragmented payload' * 150)
    struct.pack_into('<I', image, 28, len(image) - 32)
    checksum = 0xEF
    for byte in image[32:]:
        checksum ^= byte
    checksum_at = (len(image) // 16 + 1) * 16 - 1
    image += b'\0' * (checksum_at - len(image)) + bytes([checksum])
    return bytes(image) + hashlib.sha256(image).digest()


ARTIFACT = Artifact(transfer_image())


def snapshot(phase='idle', active=False):
    return dict(available=True, startup='accepted', active=active, phase=phase,
                boot_id=BOOT, firmware_id=SOURCE, transaction='', last_update=None)


def completion(outcome='complete'):
    return dict(snapshot(), boot_id=NEW_BOOT, firmware_id=TARGET if outcome == 'complete' else SOURCE,
                last_update=dict(schema=1, transaction=TX, outcome=outcome,
                                 source_firmware=SOURCE, target_firmware=TARGET,
                                 source_slot=0x10000, target_slot=0x150000, selection_confirmed=True))


class Clock:
    now = 0
    def __call__(self):
        return self.now
    def sleep(self, duration):
        self.now += duration


class HttpFixture:
    def __init__(self):
        self.calls = []
        self.status = dict(ota=snapshot(), state="CLOSED", moving=False, torque=False, dirty=False,
                           ready=True, calibrated=True, age_ms=100, control_generation=7)
        self.states = [dict(snapshot('armed', True), transaction=TX), completion()]
        self.challenge_boot = BOOT
        self.challenge_count = 0
        self.rate_limit = 0
        self.lose_prepare = False
        self.prepare_code = 202
        self.poll_times = []
        self.clock = Clock()

    def request(self, method, route, body=None, headers=None):
        self.calls.append((method, route, body, headers))
        if route == '/api/status':
            return 200, copy.deepcopy(self.status)
        if route == '/api/ota/challenge':
            self.challenge_count += 1
            if self.rate_limit:
                self.rate_limit -= 1
                return 429, None
            return 200, dict(schema=1, boot_id=self.challenge_boot, nonce=f'{self.challenge_count:032x}', expires_ms=10000)
        if method == 'POST':
            tx = TX if route.endswith('cancel') else ''
            expected = control_mac(SECRET, 'POST', route, BOOT, headers['X-Ota-Nonce'], tx, body)
            assert hmac.compare_digest(headers['X-Ota-Mac'], expected)
            assert int(headers['Content-Length']) == len(body) <= 640
            assert headers['Content-Type'] == 'text/plain'
            assert SECRET not in body
            if self.lose_prepare:
                raise WorkflowError('HTTP unavailable')
            return self.prepare_code, dict(snapshot('preparing', True), transaction=TX)
        if route == '/api/ota/status':
            self.poll_times.append(self.clock())
            state = self.states.pop(0) if len(self.states) > 1 else self.states[0]
            if isinstance(state, Exception):
                raise state
            return 200, copy.deepcopy(state)
        raise AssertionError('Unexpected request')


class TransferFixture:
    def __init__(self, failure=False):
        self.open = False
        self.sent = False
        self.failure = failure
    def __enter__(self):
        self.open = True
        return self
    def __exit__(self, *_):
        self.open = False
    def send(self, artifact, secret):
        assert self.open and secret == SECRET
        assert artifact.image == ARTIFACT.image
        self.sent = True
        if self.failure:
            raise WorkflowError('Lost final acknowledgement')


class WorkflowTest(unittest.TestCase):
    def run_engine(self, http=None, transfer=None):
        http = http or HttpFixture()
        transfer = transfer or TransferFixture()
        engine = Uploader(http, transfer, clock=http.clock, sleep=http.clock.sleep)
        return engine.run(ARTIFACT, SECRET, closed_cover=True)

    def test_complete_requires_durable_matching_reboot(self):
        http = HttpFixture()
        http.rate_limit = 1
        self.assertEqual(self.run_engine(http), Result('COMPLETE', TX))
        self.assertGreaterEqual(http.clock(), 1)
        for first, second in zip(http.poll_times, http.poll_times[1:]):
            self.assertGreaterEqual(second - first, 1)
        allowed = {'/api/status', '/api/ota/challenge', '/api/ota/prepare', '/api/ota/status', '/api/ota/cancel'}
        self.assertTrue(all(call[1] in allowed for call in http.calls))
        prepare = next(call[2] for call in http.calls if call[1].endswith('prepare'))
        self.assertIn(b'control_generation=7\n', prepare)
        self.assertIn(b'policy=closed-cover\n', prepare)

    def test_closed_torque_on_allowed(self):
        http = HttpFixture()
        http.status["torque"] = True
        self.assertEqual(self.run_engine(http).outcome, "COMPLETE")

    def test_admission_requires_explicit_safe_stationary_state(self):
        for field, value in [('moving', True), ('torque', None), ('state', 'OPEN'), ('state', 'CLOSING'), ('state', 'UNKNOWN'), ('state', None), ('dirty', True),
                             ('ready', False), ('calibrated', False), ('age_ms', 1001), ('age_ms', None)]:
            http = HttpFixture()
            http.status[field] = value
            with self.subTest(field=field, value=value), self.assertRaises(WorkflowError):
                self.run_engine(http)
            self.assertEqual([c[1] for c in http.calls], ['/api/status'])
        for field, value in [('available', False), ('startup', 'checking'), ('active', True), ('firmware_id', TARGET)]:
            http = HttpFixture()
            http.status['ota'][field] = value
            with self.assertRaises(WorkflowError):
                self.run_engine(http)
        http = HttpFixture()
        engine = Uploader(http, TransferFixture())
        with self.assertRaises(WorkflowError):
            engine.run(ARTIFACT, SECRET)
        self.assertFalse(http.calls)

    def test_invalid_image_or_mutable_image_never_contacts_device(self):
        http = HttpFixture()
        engine = Uploader(http, TransferFixture())
        with self.assertRaises(ValueError):
            engine.run(Artifact(b'broken'), SECRET, closed_cover=True)
        with self.assertRaises(WorkflowError):
            Artifact(bytearray(ARTIFACT.image))
        self.assertFalse(http.calls)

    def test_stale_challenge_does_not_post(self):
        http = HttpFixture()
        http.challenge_boot = NEW_BOOT
        self.assertEqual(self.run_engine(http).outcome, 'UNCONFIRMED')
        self.assertFalse(any(c[0] == 'POST' for c in http.calls))

    def test_rate_limit_has_finite_retries(self):
        http = HttpFixture()
        http.rate_limit = 100
        self.assertEqual(self.run_engine(http).outcome, 'UNCONFIRMED')
        self.assertEqual(http.challenge_count, 3)

    def test_lost_prepare_response_is_ambiguous(self):
        http = HttpFixture()
        http.lose_prepare = True
        self.assertEqual(self.run_engine(http), Result('UNCONFIRMED'))
        self.assertFalse(any(c[1].endswith('cancel') for c in http.calls))

    def test_explicit_prepare_rejection_is_not_ambiguous(self):
        for code in (400, 403, 409, 503):
            http, transfer = HttpFixture(), TransferFixture()
            http.prepare_code = code
            self.assertEqual(self.run_engine(http, transfer), Result('REJECTED'))
            self.assertFalse(transfer.sent)

    def test_malformed_control_generation_never_posts(self):
        for value in (None, True, '7', 0, 0xFFFFFFFF):
            http = HttpFixture()
            http.status['control_generation'] = value
            with self.assertRaises(WorkflowError):
                self.run_engine(http)
            self.assertFalse(any(c[0] == 'POST' for c in http.calls))

    def test_transfer_ok_alone_is_not_complete(self):
        http = HttpFixture()
        http.states = [dict(snapshot('armed', True), transaction=TX), snapshot('rebooting', True)]
        self.assertEqual(self.run_engine(http), Result('UNCONFIRMED', TX))
        self.assertGreaterEqual(http.clock(), 60)

    def test_preparation_timeout_cancels_only_original_transaction(self):
        http, transport = HttpFixture(), TransferFixture()
        http.states = [dict(snapshot('preparing', True), transaction=TX)]
        self.assertEqual(self.run_engine(http, transport), Result('UNCONFIRMED', TX))
        self.assertFalse(transport.sent)
        self.assertEqual(sum(c[1].endswith('cancel') for c in http.calls), 1)

    def test_boot_change_before_armed_never_transfers_or_cancels_new_boot(self):
        http, transport = HttpFixture(), TransferFixture()
        http.states = [dict(snapshot('armed', True), boot_id=NEW_BOOT, transaction=TX)]
        self.assertEqual(self.run_engine(http, transport).outcome, 'UNCONFIRMED')
        self.assertFalse(transport.sent)
        self.assertFalse(any(c[1].endswith('cancel') for c in http.calls))

    def test_reboot_disconnect_recovers_without_resending_image(self):
        http, transport = HttpFixture(), TransferFixture()
        http.states.insert(1, WorkflowError('Device rebooting'))
        self.assertEqual(self.run_engine(http, transport), Result('COMPLETE', TX))
        self.assertTrue(transport.sent)
        self.assertEqual(sum(c[1].endswith('prepare') for c in http.calls), 1)

    def test_final_ack_loss_can_still_reconcile_complete(self):
        http = HttpFixture()
        http.states.insert(1, dict(snapshot('committing', True), transaction=TX))
        self.assertEqual(self.run_engine(http, TransferFixture(True)), Result('COMPLETE', TX))
        self.assertFalse(any(c[1].endswith('cancel') for c in http.calls))

    def test_cancel_signed_and_waits_for_cleanup(self):
        http = HttpFixture()
        http.states = [dict(snapshot('armed', True), transaction=TX),
                       dict(snapshot('receiving', True), transaction=TX),
                       dict(snapshot('receiving', True), transaction=TX),
                       dict(snapshot('cancelled', False), transaction=TX)]
        self.assertEqual(self.run_engine(http, TransferFixture(True)), Result('CANCELLED', TX))
        calls = [c for c in http.calls if c[1].endswith('cancel')]
        self.assertEqual(len(calls), 1)
        self.assertEqual(calls[0][2], f'transaction={TX}\n'.encode())
        self.assertEqual(len(http.poll_times), 4)

    def test_rollback_and_unconfirmed_are_distinct(self):
        http = HttpFixture()
        http.states[-1] = completion('rolled_back')
        self.assertEqual(self.run_engine(http).outcome, 'ROLLED_BACK')
        http = HttpFixture()
        http.states[-1] = completion('unconfirmed')
        self.assertEqual(self.run_engine(http).outcome, 'UNCONFIRMED')

    def test_stale_or_mismatched_journal_cannot_report_success(self):
        for where, key, value in [('root', 'firmware_id', SOURCE), ('root', 'boot_id', BOOT),
                                  ('root', 'startup', 'checking'), ('record', 'transaction', 'f' * 32),
                                  ('record', 'source_firmware', 'f' * 64), ('record', 'target_firmware', SOURCE),
                                  ('record', 'target_slot', 0x10000), ('record', 'selection_confirmed', False)]:
            state = completion()
            (state if where == 'root' else state['last_update'])[key] = value
            with self.subTest(key=key):
                self.assertIsNone(Uploader.verdict(state, TX, SOURCE, TARGET, BOOT))

    def test_listener_closes_and_output_contains_no_secret(self):
        http, transfer = HttpFixture(), TransferFixture(True)
        http.states[-1] = WorkflowError('unavailable')
        output = io.StringIO()
        with contextlib.redirect_stdout(output), contextlib.redirect_stderr(output):
            self.assertEqual(self.run_engine(http, transfer).outcome, 'UNCONFIRMED')
        self.assertFalse(transfer.open)
        self.assertEqual(output.getvalue(), '')
        self.assertNotIn(SECRET.decode(), repr(ARTIFACT))

    def test_frozen_bytes_survive_disk_change_and_race_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'firmware.bin'
            path.write_bytes(ARTIFACT.image)
            with patch('ota_upload.manifest_for_build', return_value=ARTIFACT.manifest):
                selected = Artifact.load(directory)
            path.write_bytes(b'replaced')
            self.assertEqual(selected.image, ARTIFACT.image)
            path.write_bytes(ARTIFACT.image)
            with patch('ota_upload.manifest_for_build', return_value=dict(ARTIFACT.manifest, sha256='f' * 64)):
                with self.assertRaises(WorkflowError):
                    Artifact.load(directory)

    def test_cli_upload_rejected_before_artifact_or_network_access(self):
        result = subprocess.run([sys.executable, str(ROOT / 'tools/ota_upload.py'), 'upload', '/does/not/exist'],
                                capture_output=True, text=True)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('OTA upload is disabled', result.stderr)
        self.assertNotIn('Traceback', result.stderr)
        self.assertNotIn(SECRET.decode(), result.stderr + result.stdout)

    def test_private_secret_file_permissions_symlinks_and_validation(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'private-key'
            path.write_bytes(SECRET + b'\n')
            path.chmod(0o600)
            self.assertEqual(load_secret(path), SECRET)
            link = Path(directory) / 'link'
            link.symlink_to(path)
            with self.assertRaises(WorkflowError):
                load_secret(link)
            path.chmod(0o644)
            with self.assertRaises(WorkflowError):
                load_secret(path)
            path.chmod(0o600)
            for invalid in (b'short', b'x' * 130, SECRET + b'\r\n', b' ' * 32):
                path.write_bytes(invalid)
                with self.assertRaises(WorkflowError):
                    load_secret(path)


class SocketTransferTest(unittest.TestCase):
    def exchange(self, bad_ack=False, final_ok=True, wire_result=b'OK', sender_result=b'OK'):
        errors = []
        captured = bytearray()
        udp = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        udp.bind(('127.0.0.1', 0))
        udp.settimeout(5)
        port = udp.getsockname()[1]
        def receiver():
            try:
                invite, peer = udp.recvfrom(128)
                command, callback, size, md5 = invite.decode().split()
                self.assertEqual(command, '0')
                self.assertEqual(int(size), len(ARTIFACT.image))
                self.assertEqual(md5, ARTIFACT.manifest['md5'])
                nonce = '9' * 32
                udp.sendto(f'AUTH {nonce}'.encode(), peer)
                auth, second_peer = udp.recvfrom(128)
                self.assertEqual(peer, second_peer)
                command, cnonce, response = auth.decode().split()
                self.assertEqual(command, '200')
                self.assertEqual(response, hashlib.md5(f'{hashlib.md5(SECRET).hexdigest()}:{nonce}:{cnonce}'.encode()).hexdigest())
                udp.sendto(b'OK', peer)
                with socket.create_connection((peer[0], int(callback)), timeout=3) as client:
                    while len(captured) < int(size):
                        # Deliberately split image reads and ASCII ACK writes.
                        chunk = client.recv(min(37, 1024 - len(captured) % 1024, int(size) - len(captured)))
                        if not chunk:
                            break
                        captured.extend(chunk)
                        if len(captured) % 1024 == 0 or len(captured) == int(size):
                            count = len(captured) % 1024 or 1024
                            ack = str(count).encode()
                            if bad_ack:
                                ack = b'0' * len(ack)
                            client.sendall(ack[:1])
                            # Coalesce final ACK suffix + OK, as TCP is permitted to do.
                            client.sendall(ack[1:] + ((wire_result if final_ok else b'NO') if len(captured) == int(size) else b''))
                            if bad_ack:
                                break
            except BaseException as error:
                errors.append(error)
            finally:
                udp.close()
        thread = threading.Thread(target=receiver, daemon=True)
        thread.start()
        try:
            progress = []
            with EspotaTransfer('127.0.0.1', '127.0.0.1', port, lambda sent, total: progress.append((sent, total)), final_result=sender_result) as transport:
                transport.send(ARTIFACT, SECRET)
        finally:
            thread.join(6)
            self.assertFalse(thread.is_alive())
            if errors:
                raise errors[0]
        self.assertEqual(bytes(captured), ARTIFACT.image)
        self.assertEqual(progress[-1], (len(ARTIFACT.image), len(ARTIFACT.image)))
        self.assertEqual(len(progress), (len(ARTIFACT.image) + 1023) // 1024)

    def test_actual_udp_auth_and_fragmented_tcp_ack(self):
        self.exchange()

    def test_nonactivation_ack_is_distinct_from_production_ok(self):
        self.exchange(wire_result=b'NOACT',sender_result=b'NOACT')
        with self.assertRaises(WorkflowError):self.exchange(wire_result=b'NOACT')

    def test_wrong_ack_or_final_result_rejected(self):
        with self.assertRaises(WorkflowError):
            self.exchange(bad_ack=True)
        with self.assertRaises(WorkflowError):
            self.exchange(final_ok=False)


class HttpTransportTest(unittest.TestCase):
    def test_no_redirect_or_remote_error_echo(self):
        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                self.send_response(302 if self.path == '/redirect' else 403)
                self.send_header('Location', 'http://192.0.2.1/')
                self.end_headers()
                self.wfile.write(SECRET)
            def log_message(self, *_):
                pass
        server = HTTPServer(('127.0.0.1', 0), Handler)
        worker = threading.Thread(target=server.serve_forever, daemon=True)
        worker.start()
        try:
            http = LocalHttp('127.0.0.1', '127.0.0.1', server.server_port)
            self.assertEqual(http.request('GET', '/redirect'), (302, None))
            self.assertEqual(http.request('GET', '/error'), (403, None))
        finally:
            server.shutdown()
            server.server_close()
            worker.join()


if __name__ == '__main__':
    unittest.main()
