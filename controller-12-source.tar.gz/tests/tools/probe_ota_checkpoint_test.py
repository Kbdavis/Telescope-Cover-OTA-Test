import copy
from pathlib import Path
import sys,tempfile,unittest
from unittest.mock import Mock,patch
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'tools'))
from probe_ota_checkpoint import make_checkpoint_source,verify_checkpoint,verify_recovery,CheckpointTransfer,REASON
from ota_upload import WorkflowError
SOURCE='a'*64;TARGET='b'*64;BOOT='1'*32;TX='2'*32

def checkpoint():
 return dict(firmware_id=SOURCE,ready=True,calibrated=True,dirty=False,holding=False,moving=False,torque=False,
  resources=dict(boot_id=BOOT,state='off',viewers=0),maintenance=dict(owner='ota',phase='ready',locked=True),
  ota=dict(boot_id=BOOT,startup='accepted',transaction=TX,phase='verified',reason=REASON,received=1045600,active=True,
   last_update=dict(schema=1,transaction=TX,outcome='activation_intent',selection_confirmed=False,
    source_firmware=SOURCE,target_firmware=TARGET,source_slot=0x10000,target_slot=0x150000)))

class CheckpointTest(unittest.TestCase):
 def test_checkpoint_requires_durable_intent_identity_verified_image_and_off(self):
  s=checkpoint();verify_checkpoint(s,BOOT,TX,SOURCE,TARGET,1045600)
  for section,key,value in [('ota','phase','receiving'),('ota','received',65536),('ota','boot_id','3'*32),('record','outcome','failed'),('record','transaction','3'*32),('record','selection_confirmed',True),('record','target_slot',0x10000),('root','torque',True),('maintenance','phase','committing')]:
   bad=copy.deepcopy(s);dest=bad if section=='root' else bad['ota']['last_update'] if section=='record' else bad[section];dest[key]=value
   with self.assertRaises(WorkflowError):verify_checkpoint(bad,BOOT,TX,SOURCE,TARGET,1045600)
 def test_only_isolated_snapshot_is_changed_and_barrier_never_permits_selection(self):
  original=(ROOT/'src/ota_service.cpp').read_bytes()
  with tempfile.TemporaryDirectory() as tmp:
   dst=Path(tmp)/'src';make_checkpoint_source(ROOT/'src',dst)
   text=(dst/'ota_service.cpp').read_text();self.assertIn(REASON,text)
   self.assertIn('while(uint32_t(millis()-started)<90000)',text)
   self.assertIn('return false; // Test barrier never permits selection',text)
   self.assertEqual((ROOT/'src/ota_service.cpp').read_bytes(),original)
   with self.assertRaises(ValueError):make_checkpoint_source(ROOT/'src',dst)
  for dst in [ROOT/'src',ROOT/'src/private',ROOT]:
   with self.assertRaises(ValueError):make_checkpoint_source(ROOT/'src',dst)
 def test_callback_waits_for_checkpoint_before_cue_and_suppression(self):
  records=[];sender=CheckpointTransfer('192.168.1.2','192.168.1.3',lambda k,d:records.append((k,d)),SOURCE,TARGET)
  sender.owner=Mock(boot=BOOT,transaction=TX);sender.owner.get.side_effect=[checkpoint(),WorkflowError('offline')]
  with patch('probe_ota_checkpoint.time.sleep'),patch('builtins.print'),self.assertRaisesRegex(WorkflowError,'interruption'):
   sender.after_ack(1045600,1045600)
  self.assertTrue(sender.injected);self.assertFalse(sender.window_expired);self.assertTrue(sender.network_lost)
  self.assertEqual([k for k,_ in records],['power_cut_cue','network_unreachable_after_cue'])
 def test_partial_ack_never_cues_and_wrong_checkpoint_never_arms(self):
  sender=CheckpointTransfer('192.168.1.2','192.168.1.3',Mock(),SOURCE,TARGET);sender.owner=Mock(boot=BOOT,transaction=TX)
  sender.after_ack(65536,1045600);sender.owner.get.assert_not_called();self.assertFalse(sender.injected)
  bad=checkpoint();bad['ota']['last_update']['selection_confirmed']=True;sender.owner.get.return_value=bad
  with self.assertRaises(WorkflowError):sender.after_ack(1045600,1045600)
  self.assertFalse(sender.injected)
 def test_recovery_requires_honest_unconfirmed_matching_intent_without_selection(self):
  before=checkpoint();after=copy.deepcopy(before);after['resources']['boot_id']='3'*32
  after.update(reset_reason='POWERON',fault='',maintenance=dict(locked=False))
  after['ota'].update(active=False);after['ota']['last_update']['outcome']='unconfirmed'
  verify_recovery(before,after,TX,TARGET)
  for section,key,value in [('record','outcome','rolled_back'),('record','selection_confirmed',True),('record','transaction','4'*32),('root','reset_reason','SOFTWARE'),('resources','boot_id',BOOT),('root','torque',True)]:
   bad=copy.deepcopy(after);dest=bad if section=='root' else bad['ota']['last_update'] if section=='record' else bad[section];dest[key]=value
   with self.assertRaises(WorkflowError):verify_recovery(before,bad,TX,TARGET)

if __name__=='__main__':unittest.main()
