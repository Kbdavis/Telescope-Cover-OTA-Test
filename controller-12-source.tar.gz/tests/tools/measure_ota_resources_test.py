import importlib.util
from pathlib import Path
import sys
import unittest
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'tools'))
from measure_ota_resources import Measurement
from ota_upload import WorkflowError


class Clock:
    now=0
    def __call__(self):return self.now
    def sleep(self,n):self.now+=n


class Http:
    def __init__(self,probe=True):
        self.clock=Clock();self.active=False;self.calls=[];self.probe=probe;self.break_boot=False
        self.initial_viewers=0;self.lost_subscribe=False;self.debug_busy=False;self.missing_ota=False
    def request(self,method,route,body=None,headers=None):
        self.calls.append((method,route,body,headers))
        if route=='/api/status':
            tasks={'web':dict(min_free_bytes=2500,sample_age_ms=100),'cover':dict(min_free_bytes=2200,sample_age_ms=100),'alpaca':None}
            if self.probe and not self.missing_ota:tasks['ota']=dict(min_free_bytes=3300,sample_age_ms=100)
            resource=dict(state='active' if self.active else 'off',viewers=1 if self.active else self.initial_viewers,
                          available=self.active,internal_free_heap_bytes=180000,internal_min_free_heap_bytes=165000,
                          internal_largest_free_block_bytes=90000,debug_log_capacity=20,debug_log_available=True,task_stacks=tasks)
            return 200,dict(ota=dict(firmware_id='a'*64,startup='accepted',available=False,boot_id='new' if self.break_boot and self.clock.now>10 else 'boot',reason='resource_probe_no_admission' if self.probe else 'release_gate'),
                            resources=resource,moving=False,torque=False,dirty=False,calibrated=True,ready=True,
                            maintenance=dict(locked=False),uptime_ms=int(self.clock.now*1000)+1000)
        if route=='/api/session':return 200,dict(token='CANARY-SESSION-PRIVATE',boot_id='boot',setup_only=False,beta_accepted=True)
        if route=='/api/alpaca/status':return 200,dict(enabled=False)
        if route=='/api/debug?after=0':return (503,None) if self.debug_busy else (200,dict(capacity=20,entries=[]))
        if route.startswith('/api/diagnostics/metrics/'):
            assert headers['X-Cover-Token']=='CANARY-SESSION-PRIVATE'
            action=route.rsplit('/',1)[-1]
            if action=='subscribe':
                self.active=True
                if self.lost_subscribe:raise WorkflowError('Lost subscribe response')
            elif action=='unsubscribe':self.active=False
            return 200,dict(accepted=True)
        raise AssertionError('Unexpected endpoint')


class MeasureTest(unittest.TestCase):
    def measure(self,http,records=None):
        records=records if records is not None else []
        tool=Measurement(http,'a'*64,http.probe,clock=http.clock,sleep=http.clock.sleep,
                         record=lambda phase,data:records.append((phase,data)))
        return tool,records
    def test_success_only_metrics_posts_and_secret_not_archived(self):
        http=Http();tool,records=self.measure(http);summary=tool.run(20,5)
        self.assertEqual(summary['stack_min_free_bytes']['ota'],3300)
        self.assertEqual(summary['metrics_cleanup'],'off');self.assertFalse(http.active)
        self.assertEqual(tool.token,'')
        self.assertNotIn('CANARY-SESSION-PRIVATE',repr(records)+repr(summary))
        self.assertTrue(all(route.startswith('/api/diagnostics/metrics/') for method,route,*_ in http.calls if method=='POST'))
        phases=[phase for phase,_ in records]
        self.assertIn('off_before',phases);self.assertIn('off_after',phases)
        self.assertGreaterEqual(sum(phase=='active' for phase in phases),20)
    def test_lost_subscribe_still_cleans_up(self):
        http=Http();http.lost_subscribe=True;tool,_=self.measure(http)
        with self.assertRaises(WorkflowError):tool.run(20,5)
        self.assertFalse(http.active);self.assertEqual(tool.token,'')
        self.assertTrue(any(route.endswith('/unsubscribe') for _,route,*_ in http.calls))
    def test_reboot_stops_measurement_and_cleans_up(self):
        http=Http();http.break_boot=True;tool,_=self.measure(http)
        with self.assertRaises(WorkflowError):tool.run(20,5)
        self.assertFalse(http.active)
    def test_other_viewer_never_gets_cancelled(self):
        http=Http();http.initial_viewers=1;tool,_=self.measure(http)
        with self.assertRaises(WorkflowError):tool.run(20,5)
        self.assertFalse(any(method=='POST' for method,*_ in http.calls))
    def test_probe_scope_required_and_ota_stack_required(self):
        http=Http(False);tool,_=self.measure(http);tool.probe=True
        with self.assertRaises(WorkflowError):tool.run(20,5)
        http=Http();http.missing_ota=True;tool,_=self.measure(http)
        with self.assertRaises(WorkflowError):tool.run(20,5)
        self.assertFalse(http.active)
    def test_production_has_no_ota_worker_and_busy_logs_are_allowed(self):
        http=Http(False);http.debug_busy=True;tool,_=self.measure(http)
        summary=tool.run(20,5)
        self.assertNotIn('ota',summary['stack_min_free_bytes']);self.assertFalse(summary['resource_probe'])
    def test_wrong_image_never_subscribes(self):
        http=Http();tool,_=self.measure(http);tool.expected='b'*64
        with self.assertRaises(WorkflowError):tool.run(20,5)
        self.assertFalse(any(method=='POST' for method,*_ in http.calls))


if __name__=='__main__':unittest.main()
