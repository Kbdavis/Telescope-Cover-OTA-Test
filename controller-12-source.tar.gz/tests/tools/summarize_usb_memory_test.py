from pathlib import Path
import sys
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'tools'))
from summarize_usb_memory import summarize

def fixture(http=0,duration=180000):
    lines=[]
    for at in range(1000,duration,1000):
        lines.append(f'[{at}] USBMEM heap internal_free=160000 internal_min=150000 internal_block=110000 dma_free=130000 dma_block=100000 queue=0 queue_peak_sampled=2 dropped=0 truncated=0 http={http} status_http=0')
        lines.append(f'[{at}] USBMEM allocation hook=1 failures=0 metadata_lost=0 sequence=0 requested=0 caps=0x0')
    lines.extend(['[5000] USBMEM stack task=cover min_free=1104 age_ms=0',
                  '[25000] WIFI LINK bssid=aa:bb:cc:dd:ee:ff channel=6 rssi=-80',
                  '[30000] WIFI LINK bssid=aa:bb:cc:dd:ee:ff channel=6 rssi=-81',
                  '[40000] WIFI LINK bssid=00:11:22:33:44:55 channel=6 rssi=-75',
                  '[45000] DEBUG [warn] WIFI DISCONNECT reason=200 name=BEACON_TIMEOUT',
                  f'[{duration}] USBMEM end duration_ms={duration} failures=0 hook=1 http={http} status_http=0'])
    return '\n'.join(lines)

class SummaryTest(unittest.TestCase):
    def test_complete_quiet_baseline_and_wifi_timeline(self):
        s=summarize(fixture());self.assertTrue(s['browser_quiet']);self.assertEqual(s['failures'],0)
        self.assertEqual(s['settled_first_ten_median_free'],s['settled_last_ten_median_free'])
        self.assertEqual(s['settled_rssi_range'],[-81,-75]);self.assertEqual(len(s['bssid_changes']),1)
        self.assertEqual(s['disconnects'][0]['reason'],200);self.assertEqual(s['stack_min_free_bytes']['cover'],1104)
    def test_extra_requests_are_reported_as_contamination(self):self.assertFalse(summarize(fixture(3))['browser_quiet'])
    def test_missing_end_and_failed_hook_are_not_complete(self):
        for text in (fixture().rsplit('\n',1)[0],fixture().replace('hook=1','hook=0')):
            with self.assertRaises(ValueError):summarize(text)
    def test_collection_after_end_is_rejected(self):
        with self.assertRaises(ValueError):summarize(fixture()+'\n[181000] USBMEM stack task=web min_free=1000 age_ms=0')
        body,end=fixture().rsplit('\n',1)
        with self.assertRaises(ValueError):summarize(body+'\n'+fixture().splitlines()[0]+'\n'+end)
    def test_manual_window_must_be_explicit(self):
        text=fixture(duration=600000)
        with self.assertRaises(ValueError):summarize(text)
        self.assertEqual(summarize(text,expected_duration_ms=600000)['duration_ms'],600000)

if __name__=='__main__':unittest.main()
