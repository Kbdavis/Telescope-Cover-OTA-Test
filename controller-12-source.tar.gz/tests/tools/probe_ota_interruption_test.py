import copy
from pathlib import Path
import sys
import unittest
from unittest.mock import Mock,patch
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'tools'))
from ota_upload import Uploader,WorkflowError
from probe_ota_interruption import FaultTransfer,FaultUploader,verify_fault_cleanup,wait_cleanup

SOURCE='a'*64;TARGET='b'*64;BOOT='1'*32;TX='2'*32

class Owner:
    boot=BOOT;transaction=TX
    def get(self,path):
        assert path=='/api/ota/status'
        return dict(boot_id=BOOT,transaction=TX,phase='receiving',active=True,received=65536)
    def signed(self,path,body,secret,boot,transaction):
        assert path=='/api/ota/cancel' and body==('transaction='+TX+'\n').encode()
        assert secret==b'PUBLIC-TEST-CANARY' and boot==BOOT and transaction==TX
        return 202,None
    def poll(self):return dict(boot_id=BOOT,transaction=TX,phase='cancelled',active=False)

def cleanup():
    return dict(firmware_id=SOURCE,ota=dict(boot_id=BOOT,phase='failed',outcome='failed',active=False,received=65536,
        last_update=dict(transaction=TX,source_firmware=SOURCE,target_firmware=TARGET,source_slot=0x10000,
                         target_slot=0x150000,selection_confirmed=False)))

class FaultTest(unittest.TestCase):
    def test_terminal_record_does_not_skip_maintenance_cleanup(self):
        with patch('probe_ota_interruption.safe_status',side_effect=[WorkflowError('locked'),{'ota':{'active':True}},{'ota':{'active':False}}]) as check,patch('probe_ota_interruption.time.sleep'):
            result=wait_cleanup(Mock(),SOURCE,Mock())
        self.assertFalse(result['ota']['active']);self.assertEqual(check.call_count,3)
    def sender(self,mode):
        records=[];sender=FaultTransfer('192.168.1.2','192.168.1.3',Mock(),mode,lambda k,d:records.append((k,d)))
        sender.owner=Owner();sender.secret=b'PUBLIC-TEST-CANARY';return sender,records
    def test_drop_after_ack_is_one_injection_without_signed_cancel(self):
        sender,records=self.sender('drop');sender.owner.signed=Mock(side_effect=AssertionError('Unexpected cancel'))
        sender.after_ack(64512,1000000);self.assertFalse(sender.injected)
        with self.assertRaisesRegex(WorkflowError,'Deliberate'):sender.after_ack(65536,1000000)
        self.assertTrue(sender.injected);sender.after_ack(66560,1000000)
        self.assertEqual([k for k,_ in records],['inject']);sender.owner.signed.assert_not_called()
    def test_cancel_finishes_while_callback_keeps_socket_open(self):
        sender,records=self.sender('cancel')
        with self.assertRaisesRegex(WorkflowError,'Deliberate'):sender.after_ack(65536,1000000)
        self.assertEqual([k for k,_ in records],['inject','cancel_accepted','cancelled_while_socket_open'])
        self.assertNotIn('PUBLIC-TEST-CANARY',repr(records))
    def test_stop_requires_epoch_cleanup_while_socket_open(self):
        sender,records=self.sender('stop');sender.owner.explicit_stop=Mock()
        before=dict(ota=dict(boot_id=BOOT,transaction=TX,active=True),moving=False,torque=False,emergency=dict(stop_epoch=4))
        after=copy.deepcopy(before);after['ota'].update(active=False,phase='failed',reason='maintenance_clearance_lost')
        after.update(maintenance=dict(locked=False),emergency=dict(stop_epoch=5))
        sender.owner.get=Mock(side_effect=[Owner().get('/api/ota/status'),before,after])
        with self.assertRaisesRegex(WorkflowError,'Deliberate'):sender.after_ack(65536,1000000)
        sender.owner.explicit_stop.assert_called_once()
        self.assertEqual([k for k,_ in records],['inject','stop_accepted','stopped_while_socket_open'])
    def test_stop_waits_for_maintenance_release_after_terminal_phase(self):
        sender,records=self.sender('stop');sender.owner.explicit_stop=Mock()
        before=dict(ota=dict(boot_id=BOOT,transaction=TX),moving=False,torque=False,emergency=dict(stop_epoch=4))
        after=copy.deepcopy(before);after['ota'].update(active=False,phase='failed',reason='maintenance_clearance_lost')
        after.update(maintenance=dict(locked=False),emergency=dict(stop_epoch=5))
        locked=copy.deepcopy(after);locked['maintenance']['locked']=True
        sender.owner.get=Mock(side_effect=[Owner().get('/api/ota/status'),before,locked,after])
        with patch('probe_ota_interruption.time.sleep'),self.assertRaisesRegex(WorkflowError,'Deliberate'):
            sender.after_ack(65536,1000000)
        self.assertEqual(sender.owner.get.call_count,4)
        self.assertEqual(records[-1][0],'stopped_while_socket_open')
    def test_stop_does_not_accept_unrelated_failure_or_missing_epoch(self):
        for epoch,reason in [(4,'maintenance_clearance_lost'),(5,'transfer_incomplete_or_invalid')]:
            sender,records=self.sender('stop');sender.owner.explicit_stop=Mock()
            before=dict(ota=dict(boot_id=BOOT,transaction=TX),moving=False,torque=False,emergency=dict(stop_epoch=4))
            after=copy.deepcopy(before);after['ota'].update(active=False,phase='failed',reason=reason)
            after.update(maintenance=dict(locked=False),emergency=dict(stop_epoch=epoch))
            sender.owner.get=Mock(side_effect=[Owner().get('/api/ota/status'),before,after])
            with self.assertRaisesRegex(WorkflowError,'Stop cleanup'):sender.after_ack(65536,1000000)
            self.assertNotIn('stopped_while_socket_open',[k for k,_ in records])
    def test_explicit_stop_uses_session_but_does_not_record_token(self):
        sender,records=self.sender('stop');uploader=FaultUploader(Mock(),sender,Mock())
        uploader.boot=BOOT;uploader.get=Mock(return_value=dict(boot_id=BOOT,token='PUBLIC-SESSION-CANARY'))
        connection=Mock();connection.getresponse.return_value.status=202;connection.getresponse.return_value.read.return_value=b'queued'
        with patch('probe_ota_interruption.http.client.HTTPConnection',return_value=connection):uploader.explicit_stop()
        args,kwargs=connection.request.call_args
        self.assertEqual(args,('POST','/api/stop'));self.assertEqual(kwargs['headers']['X-Cover-Token'],'PUBLIC-SESSION-CANARY')
        self.assertEqual(kwargs['body'],b'');connection.close.assert_called_once()
        self.assertNotIn('PUBLIC-SESSION-CANARY',repr(records))
        uploader.get.return_value['boot_id']='3'*32
        with self.assertRaisesRegex(WorkflowError,'session changed'):uploader.explicit_stop()
    def test_cancel_failure_never_claims_receiver_cleanup(self):
        sender,records=self.sender('cancel');sender.owner.poll=lambda:dict(boot_id=BOOT,transaction=TX,phase='failed',active=False)
        with self.assertRaisesRegex(WorkflowError,'did not cancel'):sender.after_ack(65536,1000000)
        self.assertNotIn('cancelled_while_socket_open',[k for k,_ in records])
    def test_changed_midstream_identity_and_boundary_rejected(self):
        sender,_=self.sender('drop');sender.owner.get=lambda _:dict(boot_id='3'*32,transaction=TX,phase='receiving',active=True,received=65536)
        with self.assertRaises(WorkflowError):sender.after_ack(65536,1000000)
        self.assertFalse(sender.injected)
        sender,_=self.sender('drop')
        with self.assertRaises(WorkflowError):sender.after_ack(66560,1000000)
        self.assertFalse(sender.injected)
    def test_complete_mode_does_not_inject_and_bad_configuration_rejected(self):
        sender,records=self.sender('complete');sender.after_ack(65536,1000000);self.assertFalse(sender.injected);self.assertFalse(records)
        for mode,limit in [('unknown',65536),('drop',0),('cancel',65535)]:
            with self.assertRaises(ValueError):FaultTransfer('192.168.1.2','192.168.1.3',Mock(),mode,Mock(),limit)
    def test_only_deliberate_injections_suppress_normal_uploader_cleanup(self):
        sender,_=self.sender('drop');uploader=FaultUploader(Mock(),sender,Mock())
        with patch.object(Uploader,'cancel_before_commit') as fallback:
            uploader.cancel_before_commit(TX,b'key',BOOT);fallback.assert_called_once()
            fallback.reset_mock();sender.injected=True;uploader.cancel_before_commit(TX,b'key',BOOT);fallback.assert_not_called()
    def test_cleanup_requires_same_boot_unselected_matching_record(self):
        s=cleanup();verify_fault_cleanup(s,SOURCE,TARGET,BOOT,TX,'FAILED')
        for section,key,value in [('ota','boot_id','3'*32),('ota','active',True),('ota','received',0),
                                  ('record','selection_confirmed',True),('record','transaction','3'*32),('record','source_slot',0x150000)]:
            bad=copy.deepcopy(s);(bad['ota']['last_update'] if section=='record' else bad['ota'])[key]=value
            with self.assertRaises(WorkflowError):verify_fault_cleanup(bad,SOURCE,TARGET,BOOT,TX,'FAILED')

if __name__=='__main__':unittest.main()
