import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
from urllib.error import HTTPError

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'tools'))
import capture_wifi_diagnostics as wifi


def batch(after=0, boot='boot1', epoch=0, sequences=None, **changes):
    sequences = [after + 1] if sequences is None else sequences
    value = dict(schema_version=1, boot_id=boot, firmware='a' * 64, sequence_epoch=epoch,
                 oldest_sequence=sequences[0] if sequences else 0, newest_sequence=sequences[-1] if sequences else after,
                 next_after=sequences[-1] if sequences else after, capacity=1000, available=True,
                 cursor_reset=False, gap=False, more=False, metrics_active=False, loss={},
                 entries=[dict(sequence=n, ms=n*10, level='info', message='EVENT safe', truncated=False) for n in sequences])
    value.update(changes)
    return value


class FakeHTTP:
    base = 'http://local-fixture'

    def __init__(self, batches):
        self.batches = iter(batches)
        self.calls = []
        self.ota = dict(available=False, phase='unavailable')
        self.status = dict(firmware_id='a' * 64, uptime_ms=1000, resources=dict(boot_id='boot1', available=True))

    def get(self, path, query=None):
        self.calls.append((path, query))
        if path == 'ota/status':
            return self.ota
        if path == 'status':
            return self.status
        assert path == 'debug'
        return next(self.batches)


class WifiCaptureTests(unittest.TestCase):
    def test_cursor_gaps_reboot_rollover_and_artifact_identity(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            http = FakeHTTP([batch(sequences=[4, 5]), batch(after=5, sequences=[6]),
                             batch(boot='boot2', cursor_reset=True), batch(boot='boot2', epoch=1, cursor_reset=True)])
            capture = wifi.Capture(root, http, {'firmware.elf': 'b' * 64})
            capture.step(0)
            self.assertEqual(capture.after, 5)
            self.assertFalse(capture.manifest['last_device']['matches_selected_elf'])
            capture.step(1)
            self.assertEqual(http.calls[-1], ('debug', dict(after=5, boot_id='boot1', sequence_epoch=0)))
            capture.step(2)
            capture.step(3)
            capture.close()
            lines = [json.loads(line) for line in (root / 'events.jsonl').read_text().splitlines()]
            self.assertTrue(any(line['kind']=='gap' and line['expected_sequence']==1 and line['next_sequence']==4 for line in lines))
            self.assertEqual([line['sequence'] for line in lines if line['kind']=='event'], [4, 5, 6, 1, 1])
            self.assertEqual(json.loads((root / 'cursor.json').read_text()), dict(boot_id='boot2', sequence_epoch=1, after=1))
            self.assertFalse(any(path == 'status' for path, _ in http.calls))  # OFF capture never fetches resources.

    def test_metrics_snapshot_and_boot_race(self):
        with tempfile.TemporaryDirectory() as folder:
            http = FakeHTTP([batch(metrics_active=True), batch(after=1, metrics_active=True), batch(after=2, metrics_active=True)])
            capture = wifi.Capture(Path(folder), http)
            capture.step(0)
            capture.step(1)
            http.status['resources']['boot_id'] = 'boot2'
            capture.step(5)
            capture.close()
            lines = [json.loads(line) for line in (Path(folder) / 'events.jsonl').read_text().splitlines()]
            self.assertEqual(sum(line['kind']=='snapshot' for line in lines), 1)
            self.assertTrue(any(line.get('reason')=='boot_changed_between_requests' for line in lines))
            self.assertEqual(sum(path=='status' for path, _ in http.calls), 2)
            self.assertTrue(all(path in ('status', 'debug', 'ota/status') for path, _ in http.calls))

    def test_transfer_pauses_bulk_and_uses_one_status_per_second(self):
        with tempfile.TemporaryDirectory() as folder:
            http = FakeHTTP([])
            http.ota = dict(available=True, phase='receiving')
            capture = wifi.Capture(Path(folder), http)
            for second in range(4):
                capture.step(second)
            capture.close()
            self.assertEqual([path for path, _ in http.calls], ['ota/status'] * 4)

    def test_active_transaction_pauses_bulk_even_with_admission_closed(self):
        with tempfile.TemporaryDirectory() as folder:
            http=FakeHTTP([]);http.ota=dict(available=False,active=True,phase='receiving')
            capture=wifi.Capture(Path(folder),http)
            for second in range(3):capture.step(second)
            capture.close()
            self.assertEqual([path for path,_ in http.calls],['ota/status']*3)

    def test_resume_matching_and_modified_archives(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / 'firmware.elf').write_bytes(b'local elf')
            digest = hashlib.sha256(b'local elf').hexdigest()
            http = FakeHTTP([])
            capture = wifi.Capture(root, http, {'firmware.elf': digest})
            capture.observe(batch(firmware=digest))
            self.assertTrue(capture.manifest['last_device']['matches_selected_elf'])
            capture.close()
            resumed = wifi.Capture(root, http, resume=True)
            self.assertEqual(resumed.after, 1)
            resumed.close()
            (root / 'firmware.elf').write_bytes(b'changed')
            with self.assertRaises(ValueError):
                wifi.Capture(root, http, resume=True)

    def test_resume_rejects_different_controller(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            capture = wifi.Capture(root, FakeHTTP([]));capture.close()
            other = FakeHTTP([]);other.base = 'http://other'
            with self.assertRaises(ValueError):
                wifi.Capture(root, other, resume=True)

    def test_redaction_and_unavailable_ring(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            capture = wifi.Capture(root, FakeHTTP([]))
            capture.record('snapshot', token='canary1', password='canary2', details='password="canary three" token=canary4 Authorization: Bearer canary5')
            capture.record('event', details='wifi_password=canary6 seestar_secret=canary7 api_key=canary8')
            capture.observe(batch(sequences=[], available=False))
            capture.close()
            text = (root / 'events.jsonl').read_text()
            self.assertNotIn('canary', text)
            self.assertIn('unavailable', text)
            self.assertIsNone(capture.manifest['last_device']['matches_selected_elf'])

    def test_request_allowlist_bounds_and_headers(self):
        http = wifi.ReadOnlyHTTP('127.0.0.1:8097')
        class Opener:
            def open(self, request, **kwargs):
                self.request, self.kwargs = request, kwargs
                return io.BytesIO(b'{}')
        opener = http.opener = Opener()
        http.get('debug', dict(after=1, boot_id='public', sequence_epoch=0))
        self.assertEqual(opener.request.get_method(), 'GET')
        self.assertIsNone(opener.request.data)
        self.assertEqual(dict(opener.request.header_items()), {'Accept': 'application/json'})
        self.assertLessEqual(opener.kwargs['timeout'], 1.2)
        for path in ('session', 'stop', 'diagnostics/metrics/subscribe', '../status', 'controller/reboot'):
            with self.assertRaises(ValueError):
                http.get(path)
        opener.open = lambda *a, **k: io.BytesIO(b' ' * 4097)
        with self.assertRaises(ValueError):
            http.get('debug')
        opener.open = lambda *a, **k: io.BytesIO(b'{"invalid":NaN}')
        with self.assertRaises(ValueError):
            http.get('debug')

    def test_busy_retry_and_backoff_are_bounded(self):
        class Failed:
            calls = 0
            records = []
            closed = False
            def step(self, now):
                self.calls += 1
                if self.calls==1:raise wifi.Busy(100)
                raise OSError('token=canary')
            def record(self, kind, **fields):self.records.append((kind, fields))
            def close(self):self.closed = True
        now = [0];sleeps = []
        def sleep(seconds):now[0] += seconds;sleeps.append(seconds)
        capture = Failed()
        wifi.run(capture, 140, clock=lambda:now[0], sleep=sleep)
        self.assertTrue(capture.closed)
        self.assertEqual(sleeps[:7], [30, 1, 2, 4, 8, 16, 30])
        self.assertLessEqual(max(sleeps), 30)
        self.assertNotIn('canary', str(capture.records))
        error = HTTPError('http://fixture', 503, 'busy', {'Retry-After': '99'}, io.BytesIO())
        http = wifi.ReadOnlyHTTP('fixture')
        with patch.object(http.opener, 'open', side_effect=error), self.assertRaises(wifi.Busy) as result:
            http.get('debug')
        self.assertEqual(result.exception.seconds, 30)

    def test_invalid_hosts_and_protocol_batches(self):
        for host in ('http://user:secret@host', 'http://host/path', 'http://host/?password=x', 'ftp://host', 'http://host:99999'):
            with self.assertRaises(ValueError):wifi.origin(host)
        for change in (dict(schema_version=2), dict(next_after=2), dict(entries=[{}]), dict(available=1), dict(boot_id='')):
            with self.assertRaises(ValueError):wifi.validate_batch(batch(**change))

    def test_successful_reconnect_is_marked_without_commands(self):
        class Recovery:
            calls = 0
            records = []
            def step(self, now):
                self.calls += 1
                if self.calls==1:raise OSError('offline')
            def record(self, kind, **fields):self.records.append(kind)
            def close(self):pass
        now = [0]
        def sleep(seconds):now[0] += seconds
        capture = Recovery()
        wifi.run(capture, 3, clock=lambda:now[0], sleep=sleep)
        self.assertEqual(capture.records, ['gap', 'reconnected'])

    def test_cpp_response_is_valid_json_and_obeys_limits(self):
        root = Path(__file__).resolve().parents[2]
        with tempfile.TemporaryDirectory() as folder:
            executable = str(Path(folder) / 'response_test')
            subprocess.run(['c++', '-std=c++11', '-Wall', '-Wextra', '-Werror', '-Isrc',
                            'tests/host/debug_response_test.cpp', '-o', executable], cwd=root, check=True)
            result = subprocess.run([executable], check=True, capture_output=True, text=True)
            batches = [wifi.validate_batch(json.loads(line)) for line in result.stdout.splitlines()]
            self.assertEqual(len(batches[0]['entries']), 16)
            self.assertLess(len(batches[1]['entries']), 16)
            self.assertEqual(batches[2]['sequence_epoch'], 1)
            self.assertTrue(batches[2]['cursor_reset'])
            for line in result.stdout.splitlines():self.assertLessEqual(len(line.encode()), 4096)


if __name__ == '__main__':
    unittest.main()
