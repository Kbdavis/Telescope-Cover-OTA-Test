import contextlib
import hashlib
import importlib.util
import io
from pathlib import Path
import runpy
import struct
import subprocess
import sys
import tempfile
import types
import unittest
from unittest.mock import Mock, patch


ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location("check_firmware", ROOT / "tools/check_firmware.py")
firmware = importlib.util.module_from_spec(spec)
spec.loader.exec_module(firmware)


def partition_table(records=firmware.EXPECTED_PARTITIONS):
    data = b"".join(struct.pack("<HBBII16sI", 0x50AA, kind, subtype, offset, size,
                               label.encode(), flags)
                    for label, kind, subtype, offset, size, flags in records)
    data += b"\xeb\xeb" + b"\xff" * 14 + hashlib.md5(data).digest()
    return data.ljust(0xC00, b"\xff")


class FirmwareBuildTests(unittest.TestCase):
    def test_both_slots_fit_and_actual_binary_length_includes_padding(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "partitions.bin").write_bytes(partition_table())
            binary = root / "firmware.bin"
            binary.write_bytes(b"x" * 0x140000)
            self.assertEqual(firmware.check_firmware(root), (0x140000, 0x140000))
            with binary.open("ab") as stream:
                stream.write(b"x")
            with self.assertRaisesRegex(ValueError, "both OTA slots"):
                firmware.check_firmware(root)
            binary.write_bytes(b"")
            with self.assertRaisesRegex(ValueError, "both OTA slots"):
                firmware.check_firmware(root)

    def test_changed_nvs_or_either_slot_fails_even_with_valid_checksum(self):
        for label in ("nvs", "app0", "app1"):
            records = list(firmware.EXPECTED_PARTITIONS)
            index = next(i for i, record in enumerate(records) if record[0] == label)
            record = list(records[index])
            record[4] -= 0x1000
            records[index] = tuple(record)
            with self.subTest(label=label), self.assertRaisesRegex(ValueError, "pinned"):
                firmware.validate_partitions(partition_table(records))

    def test_missing_partition_or_changed_flags_fails(self):
        with self.assertRaisesRegex(ValueError, "pinned"):
            firmware.validate_partitions(partition_table(firmware.EXPECTED_PARTITIONS[:-1]))
        records = list(firmware.EXPECTED_PARTITIONS)
        records[0] = (*records[0][:-1], 1)
        with self.assertRaisesRegex(ValueError, "pinned"):
            firmware.validate_partitions(partition_table(records))

    def test_corrupt_and_truncated_partition_tables_fail(self):
        data = bytearray(partition_table())
        data[8] ^= 1
        with self.assertRaisesRegex(ValueError, "checksum mismatch"):
            firmware.validate_partitions(data)
        for data in (b"", partition_table()[:-1], b"\xff" * 32):
            with self.subTest(length=len(data)), self.assertRaises(ValueError):
                firmware.validate_partitions(data)

    def test_records_after_checksum_fail(self):
        data = bytearray(partition_table())
        data[224] = 0
        with self.assertRaisesRegex(ValueError, "after partition table checksum"):
            firmware.validate_partitions(data)

    def test_report_uses_binary_size_and_both_slot_capacity(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "partitions.bin").write_bytes(partition_table())
            (root / "firmware.bin").write_bytes(b"x" * 1000)
            with contextlib.redirect_stdout(io.StringIO()) as output:
                firmware.report_firmware(root)
            self.assertIn("1,000 bytes", output.getvalue())
            self.assertIn("headroom: 1,309,720 bytes", output.getvalue())

    def test_ota_upload_hook_rejects_before_registering_any_actions(self):
        class GuardError(Exception):
            pass

        for target in ("upload", "uploadfs", "uploadfsota", "program", "erase", "__test", "__debug"):
            env = Mock()
            env.subst.side_effect = lambda value: "web_control_ota" if value == "$PIOENV" else str(ROOT)
            modules = {"SCons": types.ModuleType("SCons"),
                       "SCons.Errors": types.SimpleNamespace(UserError=GuardError),
                       "SCons.Script": types.SimpleNamespace(COMMAND_LINE_TARGETS=["nobuild", target])}
            with self.subTest(target=target), patch.dict(sys.modules, modules), patch.object(sys, "path", sys.path[:]):
                with self.assertRaisesRegex(GuardError, "OTA upload is disabled"):
                    runpy.run_path(str(ROOT / "tools/firmware_build.py"),
                                   init_globals={"env": env, "Import": lambda name: None})
                env.AddPreAction.assert_not_called()
                env.AddPostAction.assert_not_called()
                env.Depends.assert_not_called()

    def test_local_build_and_usb_environment_are_not_blocked(self):
        self.assertFalse(firmware.upload_blocked("web_control_ota", ["buildprog"]))
        self.assertFalse(firmware.upload_blocked("web_control_usb", ["upload"]))

    def test_nobuild_usb_upload_rejected_before_actions(self):
        class GuardError(Exception):
            pass
        env = Mock()
        env.subst.side_effect = lambda value: 'web_control_usb' if value == '$PIOENV' else str(ROOT)
        modules = {'SCons': types.ModuleType('SCons'),
                   'SCons.Errors': types.SimpleNamespace(UserError=GuardError),
                   'SCons.Script': types.SimpleNamespace(COMMAND_LINE_TARGETS=['nobuild', 'upload'])}
        with patch.dict(sys.modules, modules), patch.object(sys, 'path', sys.path[:]):
            with self.assertRaisesRegex(GuardError, 'Application-only nobuild'):
                runpy.run_path(str(ROOT / 'tools/firmware_build.py'), init_globals={'env': env, 'Import': lambda name: None})
        env.AddPreAction.assert_not_called()
        env.AddPostAction.assert_not_called()

    def test_fallback_upload_command_always_refuses_without_artifacts(self):
        result = subprocess.run([sys.executable, str(ROOT / "tools/check_firmware.py"), "--deny-upload"],
                                capture_output=True, text=True)
        self.assertEqual(result.returncode, 1)
        self.assertIn("OTA upload is disabled", result.stderr)


if __name__ == "__main__":
    unittest.main()
