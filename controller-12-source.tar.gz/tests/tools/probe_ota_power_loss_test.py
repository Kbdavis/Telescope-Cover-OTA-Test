import copy
from pathlib import Path
import sys
import unittest
from unittest.mock import Mock,patch
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'tools'))
from ota_upload import WorkflowError,EspotaTransfer
from probe_ota_power_loss import PowerCutTransfer,ManualPowerUploader,verify_recovered_status,CUE_BYTES,CAP_BYTES,NetworkOnlyMonitor

BOOT='1'*32;TX='2'*32

def before():
 return dict(firmware_id='a'*64,resources=dict(boot_id=BOOT,state='off',viewers=0),reset_reason='POWERON',ready=True,calibrated=True,
  moving=False,torque=False,dirty=False,fault='',maintenance=dict(locked=False),ota=dict(startup='accepted',active=False,last_update=dict(transaction='3'*32,outcome='rolled_back')),
  minimum=450,maximum=2500,open=1500,closed=490,saved_minimum=450,saved_maximum=2500,saved_profile=dict(open_speed=100))

class PowerTest(unittest.TestCase):
 def sender(self):
  records=[];sender=PowerCutTransfer('192.168.1.2','192.168.1.3',Mock(),lambda k,d:records.append((k,d)))
  sender.owner=Mock(boot=BOOT,transaction=TX)
  s=before();s['ota'].update(boot_id=BOOT,transaction=TX,phase='receiving',active=True,received=CUE_BYTES)
  sender.owner.get.return_value=s
  return sender,records
 def test_network_only_monitor_never_opens_serial_or_arms_reset(self):
  monitor=NetworkOnlyMonitor()
  with patch('probe_ota_power_loss.UsbMonitor',side_effect=AssertionError('USB must remain unplugged')):
   monitor.start();monitor.progress();monitor.close()
  self.assertFalse(monitor.error);self.assertFalse(monitor.gate.fired)
 def test_cue_requires_receiving_identity_and_off(self):
  for key,value in [('boot_id','4'*32),('transaction','4'*32),('active',False),('received',0),('phase','failed')]:
   sender,_=self.sender();sender.owner.get.return_value['ota'][key]=value
   with self.assertRaises(WorkflowError):sender.after_ack(CUE_BYTES,1045600)
   self.assertFalse(sender.injected)
 def test_pacing_keeps_sending_and_hard_cap_prevents_activation(self):
  sender,records=self.sender()
  with patch('probe_ota_power_loss.time.sleep') as sleep,patch('builtins.print'):
   sender.after_ack(CUE_BYTES,1045600)
   self.assertTrue(sender.injected);sleep.assert_called_once_with(.08)
   with self.assertRaisesRegex(WorkflowError,'cap'):sender.after_ack(CAP_BYTES,1045600)
  self.assertTrue(sender.window_expired);self.assertEqual([k for k,_ in records],['ack_progress','power_cut_cue','ack_progress','window_expired'])
 def test_usb_loss_after_cue_does_not_end_wifi_transfer_itself(self):
  sender,_=self.sender()
  with patch('probe_ota_power_loss.time.sleep'),patch('builtins.print'):sender.after_ack(CUE_BYTES,1045600)
  sender.monitor.progress.side_effect=WorkflowError('USB gone')
  with patch('probe_ota_power_loss.time.sleep'):sender.after_ack(CUE_BYTES+1024,1045600)
  self.assertEqual(sender.last_ack,CUE_BYTES+1024)
 def test_payload_cap_and_transport_evidence(self):
  sender,_=self.sender()
  with self.assertRaises(WorkflowError):sender.send(Mock(image=b'x'*CAP_BYTES),b'key')
  sender.injected=True
  with patch.object(EspotaTransfer,'send',side_effect=WorkflowError('TCP gone')):
   with self.assertRaises(WorkflowError):sender.send(Mock(image=b'x'*(CAP_BYTES+1)),b'key')
  self.assertTrue(sender.transport_interrupted)
  sender.window_expired=True
  with patch.object(EspotaTransfer,'send',side_effect=WorkflowError('cap')):
   with self.assertRaises(WorkflowError):sender.send(Mock(image=b'x'*(CAP_BYTES+1)),b'key')
  self.assertFalse(sender.transport_interrupted)
 def test_expected_disconnect_cleanup_has_required_mode_and_never_cancels(self):
  sender,records=self.sender();sender.injected=True;http=Mock();u=ManualPowerUploader(http,sender,lambda k,d:records.append((k,d)))
  u.cancel_before_commit(TX,b'key',BOOT)
  http.request.assert_not_called()
  self.assertEqual(records[-1],('automatic_cancel_suppressed',dict(mode='manual_power_loss',transaction=TX)))
 def test_unrelated_history_never_becomes_transaction_verdict(self):
  sender,_=self.sender();u=ManualPowerUploader(Mock(),sender,Mock())
  self.assertEqual(u.reconcile(TX,'a'*64,'b'*64,BOOT).outcome,'UNCONFIRMED')
 def test_matching_failed_journal_is_honest_but_not_uncheckpointed_power_loss(self):
  initial=before();recovered=copy.deepcopy(initial);recovered['resources']['boot_id']='4'*32
  record=dict(transaction=TX,outcome='failed',source_firmware='a'*64,target_firmware='b'*64,source_slot=0x10000,target_slot=0x150000,selection_confirmed=False)
  recovered['ota']['last_update']=record
  self.assertEqual(verify_recovered_status(initial,recovered,TX,'b'*64),'matching_failure_persisted_before_power_off')
  for key,value in [('outcome','complete'),('selection_confirmed',True),('target_firmware','c'*64),('source_slot',0x150000)]:
   bad=copy.deepcopy(recovered);bad['ota']['last_update'][key]=value
   with self.assertRaises(WorkflowError):verify_recovered_status(initial,bad,TX,'b'*64)
 def test_recovery_requires_new_poweron_boot_same_settings_and_historical_record(self):
  initial=before();recovered=copy.deepcopy(initial);recovered['resources']['boot_id']='4'*32
  verify_recovered_status(initial,recovered,TX)
  for section,key,value in [('root','torque',True),('root','reset_reason','SOFTWARE'),('root','closed',491),('resources','boot_id',BOOT),('ota','startup','checking'),('ota','last_update',dict(transaction=TX,outcome='complete'))]:
   bad=copy.deepcopy(recovered);(bad if section=='root' else bad[section])[key]=value
   with self.assertRaises(WorkflowError):verify_recovered_status(initial,bad,TX)

if __name__=='__main__':unittest.main()
