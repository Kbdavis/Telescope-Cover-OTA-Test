from pathlib import Path
import copy
import sys
import tempfile
import unittest
from unittest.mock import Mock,patch
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'tools'))
from probe_ota_watchdog import make_hang_source,verify_watchdog_evidence,WatchdogUploader
from ota_upload import WorkflowError,Uploader
SOURCE='a'*64;TARGET='b'*64;TX='2'*32;BOOT='1'*32

def status():
 return dict(firmware_id=SOURCE,ota=dict(boot_id='3'*32,startup='accepted',last_update=dict(transaction=TX,
  outcome='rolled_back',source_firmware=SOURCE,target_firmware=TARGET,source_slot=0x10000,
  target_slot=0x150000,selection_confirmed=True)))

def serial(stage='before_setup'):
 return ('OTA TEST HANG stage='+stage+' elf='+TARGET+'\n'
         'rst:0x10 (RTCWDT_RTC_RESET),boot:0x13\nBOOT reset=WDT elf_sha256='+SOURCE+'\nOTA startup=accepted\n')

class WatchdogTest(unittest.TestCase):
 def test_requires_real_watchdog_marker_and_matching_recovery(self):
  for stage in ['before_setup','setup']:
   proof=verify_watchdog_evidence(serial(stage),stage,TARGET,SOURCE,TX,status(),BOOT)
   self.assertEqual(proof['outcome'],'ROLLED_BACK');self.assertFalse(proof['host_reset_injected'])
 def test_missing_wrong_repeated_marker_and_host_reset_rejected(self):
  raw=serial()
  for text in [raw.replace(TARGET,'c'*64),raw+raw,raw.replace('RTCWDT_RTC_RESET','SW_CPU_RESET'),raw+'HOST INJECT early reset',raw+'HOST early-reset armed',raw.replace('rst:0x10','OTA startup=accepted\nrst:0x10')]:
   with self.assertRaises(WorkflowError):verify_watchdog_evidence(text,'before_setup',TARGET,SOURCE,TX,status(),BOOT)
 def test_durable_record_and_boot_identity_required(self):
  for k,v in [('transaction','4'*32),('outcome','complete'),('source_slot',0x150000),('selection_confirmed',False),('target_firmware','c'*64)]:
   s=status();s['ota']['last_update'][k]=v
   with self.assertRaises(WorkflowError):verify_watchdog_evidence(serial(),'before_setup',TARGET,SOURCE,TX,s,BOOT)
  s=status();s['ota']['boot_id']=BOOT
  with self.assertRaises(WorkflowError):verify_watchdog_evidence(serial(),'before_setup',TARGET,SOURCE,TX,s,BOOT)
 def test_source_snapshot_is_isolated_and_live_source_unchanged(self):
  for stage in ['before_setup','setup']:
   with tempfile.TemporaryDirectory() as tmp:
    dst=Path(tmp)/'snapshot';service=(ROOT/'src/ota_service.cpp').read_bytes();main=(ROOT/'src/main.cpp').read_bytes()
    make_hang_source(ROOT/'src',dst,stage)
    self.assertEqual((ROOT/'src/ota_service.cpp').read_bytes(),service);self.assertEqual((ROOT/'src/main.cpp').read_bytes(),main)
    injected=(dst/('ota_service.cpp' if stage=='before_setup' else 'main.cpp')).read_text()
    self.assertIn('OTA TEST HANG stage='+stage,injected);self.assertIn('for(;;)vTaskDelay',injected)
    with self.assertRaises(ValueError):make_hang_source(ROOT/'src',dst,stage)
 def test_in_place_nested_and_unknown_injection_rejected(self):
  for dst,stage in [(ROOT/'src','before_setup'),(ROOT/'src/private','before_setup'),(ROOT,'before_setup'),(Path('/tmp/unused'),'unknown')]:
   with self.assertRaises(ValueError):make_hang_source(ROOT/'src',dst,stage)
 def test_reconciliation_waits_for_watchdog_without_reset_or_repeat(self):
  uploader=WatchdogUploader(Mock(),Mock())
  with patch.object(Uploader,'reconcile',return_value=Mock()) as reconcile:
   uploader.reconcile(TX,SOURCE,TARGET,BOOT)
  self.assertEqual(reconcile.call_args.args[-1],90)

if __name__=='__main__':unittest.main()
