import copy
import hashlib
import json
from pathlib import Path
import struct
import sys
import tempfile
import unittest
import zipfile
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'tools'))
from version_info import generate, version_info
from package_release import read_inputs, assemble, PACKAGE_NOTICES
from firmware_build_test import partition_table
from publish_pipeline_prerelease import verify_candidate


class VersionTest(unittest.TestCase):
    def test_source_identity_and_release_validation(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / 'VERSION').write_text('0.1.0\n')
            provenance = root / '.release-source.json'
            for dirty in (True, False):
                provenance.write_text(json.dumps(dict(commit='a' * 40, dirty=dirty)))
                dev = version_info(root, 'web_control_dev', {})
                self.assertEqual(dev['version'], '0.1.0-dev+aaaaaaa' + ('.dirty' if dirty else ''))
                if dirty:
                    with self.assertRaises(ValueError):
                        version_info(root, 'web_control_multiturn_usb', {'TELESCOPE_RELEASE_VERSION': '0.1.0-beta.1'})
            for profile in ('web_control_usb', 'web_control_multiturn_startup', 'web_control_multiturn_probe', 'web_control_dev'):
                with self.subTest(profile=profile), self.assertRaises(ValueError):
                    version_info(root, profile, {'TELESCOPE_RELEASE_VERSION': '0.1.0-beta.1'})
            for value in ('0.2.0', '0.1.0-beta.0', '0.1.0\";x', 'v0.1.0'):
                with self.subTest(value=value), self.assertRaises(ValueError):
                    version_info(root, 'web_control_multiturn_usb', {'TELESCOPE_RELEASE_VERSION': value})
            with self.assertRaises(ValueError):
                version_info(root, 'web_control_dev', {'TELESCOPE_RELEASE_VERSION': '0.1.0-beta.1'})
            release = version_info(root, 'web_control_multiturn_usb', {'TELESCOPE_RELEASE_VERSION': '0.1.0-beta.1'})
            self.assertTrue(release['release'])
            with patch.dict('os.environ', {'TELESCOPE_RELEASE_VERSION': ''}):
                generate(root, root / 'build', 'web_control_multiturn_usb')
                first = (root / 'build/generated_version.h').read_bytes()
                generate(root, root / 'build', 'web_control_multiturn_usb')
                self.assertEqual(first, (root / 'build/generated_version.h').read_bytes())


class InputsTest(unittest.TestCase):
    def fixture(self, root):
        components = []
        for filename, offset, data in [('bootloader.bin', 0x1000, b'boot'), ('partitions.bin', 0x8000, partition_table()),
                                      ('boot_app0.bin', 0xe000, b'selection'), ('firmware.bin', 0x10000, b'app')]:
            path = root / filename
            path.write_bytes(data)
            components.append(dict(offset=offset, path=str(path)))
        spec = dict(chip='ESP32', flash_mode='dio', flash_freq='40m', flash_size='4MB', components=components, esptool=str(root / 'bootloader.bin'))
        return spec

    def test_exact_boot_components_required(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            spec = self.fixture(root)
            config = root / 'install-inputs.json'
            config.write_text(json.dumps(spec))
            self.assertEqual(len(read_inputs(root)[1]), 4)
            for mutate in ('missing', 'duplicate', 'overlap', 'wrong-chip', 'wrong-flash', 'credential'):
                changed = copy.deepcopy(spec)
                if mutate == 'missing':
                    changed['components'].pop(0)
                elif mutate == 'duplicate':
                    changed['components'].append(changed['components'][0])
                elif mutate == 'overlap':
                    changed['components'][0]['offset'] = 0x8000
                elif mutate == 'wrong-chip':
                    changed['chip'] = 'ESP32-S3'
                elif mutate == 'wrong-flash':
                    changed['flash_size'] = '8MB'
                else:
                    (root / 'bootloader.bin').write_bytes(b'TCOTA-DEV-LOCAL-1')
                config.write_text(json.dumps(changed))
                with self.subTest(mutate=mutate), self.assertRaises(ValueError):
                    read_inputs(root)

    def test_packaging_rejects_development_identity(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / 'version.json').write_text(json.dumps(dict(release=False, dirty=True, profile='web_control_dev')))
            with patch('package_release.manifest_for_build', return_value={'profile': 'multiturn_usb'}), self.assertRaisesRegex(ValueError, 'clean, versioned'):
                assemble(root, root, root / 'output')

    def test_rejects_wrong_binary_profile_and_missing_notices(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            identity=dict(release=True, dirty=False, profile='web_control_multiturn_usb')
            (root/'version.json').write_text(json.dumps(identity))
            for profile in ('web_control', 'test_profile'):
                with patch('package_release.manifest_for_build', return_value={'profile': profile}), self.assertRaisesRegex(ValueError, 'descriptor'):
                    assemble(root,root,root/'output')
            with patch('package_release.manifest_for_build', return_value={'profile': 'multiturn_usb'}), self.assertRaisesRegex(ValueError, 'Missing required license'):
                assemble(root,root,root/'output')
            self.assertFalse((root/'output').exists())

    def test_package_allowlist_checksums_and_complete_image(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            spec = self.fixture(root)
            spec['packages'] = {'test-tool': '1'}
            (root / 'install-inputs.json').write_text(json.dumps(spec))
            identity = dict(release=True, dirty=False, profile='web_control_multiturn_usb',
                            version='0.1.0-beta.1', commit='a'*40, built_at='2026-11-11T00:00:00Z')
            (root / 'version.json').write_text(json.dumps(identity))
            (root / 'firmware.bin').write_bytes(json.dumps(identity, sort_keys=True, separators=(',', ':')).encode())
            (root / 'installer').mkdir()
            (root / 'docs').mkdir()
            for name in ('index.html', 'style.css', 'app.mjs', 'core.mjs'):
                (root / 'installer' / name).write_text('test')
            (root / 'docs/INSTALLATION.md').write_text('Standalone guide')
            (root / 'docs/RELEASE_NOTES_TEMPLATE.md').write_text('<VERSION> <COMMIT>')
            for name in PACKAGE_NOTICES:
                path=root/name;path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes((ROOT/name).read_bytes())
            # These must not get into the end-user package.
            (root / 'wifi_local.h').write_text('private-value')
            (root / 'firmware.elf').write_text('private-debug')
            def merge(command, **_):
                destination = Path(command[command.index('--output')+1])
                entries = spec['components']
                merged = bytearray(b'\xff' * max(c['offset']+len(Path(c['path']).read_bytes()) for c in entries))
                for c in entries:
                    data = Path(c['path']).read_bytes()
                    merged[c['offset']:c['offset']+len(data)] = data
                destination.write_bytes(merged)
            output = root / 'output'
            with patch('package_release.manifest_for_build', return_value={'profile': 'multiturn_usb'}), \
                 patch('package_release.subprocess.run', side_effect=merge), \
                 patch('package_release.subprocess.check_output', return_value='PlatformIO test'):
                record = assemble(root, root, output)
            self.assertFalse(record['publication_allowed'])
            self.assertEqual(record['licensing'], 'dependency-review-required')
            expected = {'factory.bin','partitions.bin','manifest.json','esp-web-tools-manifest.json',
                        'index.html','style.css','app.mjs','core.mjs','INSTALLATION.md',
                        'RELEASE_NOTES.md','LICENSE_STATUS.md','release.json','SHA256SUMS'} | set(PACKAGE_NOTICES)
            self.assertEqual({p.relative_to(output).as_posix() for p in output.rglob('*') if p.is_file()}, expected)
            for line in (output / 'SHA256SUMS').read_text().splitlines():
                digest, name = line.split('  ')
                self.assertEqual(hashlib.sha256((output / name).read_bytes()).hexdigest(), digest)
            pipeline_output=root/'pipeline-output'
            with patch('package_release.manifest_for_build', return_value={'profile': 'multiturn_usb'}), \
                 patch('package_release.subprocess.run', side_effect=merge), \
                 patch('package_release.subprocess.check_output', return_value='PlatformIO test'):
                pipeline=assemble(root,root,pipeline_output,pipeline_test=True)
            self.assertEqual(pipeline['hardware_acceptance'],'not-performed')
            self.assertEqual(pipeline['browser_acceptance'],'not-performed')
            self.assertTrue(pipeline['private_pipeline_publication_allowed'])
            self.assertFalse(pipeline['publication_allowed'])
            self.assertIn('NOT HARDWARE TESTED',(pipeline_output/'PIPELINE_TEST.md').read_text())
            self.assertFalse(record['private_pipeline_publication_allowed'])
            archive=Path(str(pipeline_output)+'.zip')
            with zipfile.ZipFile(archive,'w') as zipped:
                for file in pipeline_output.rglob('*'):
                    if file.is_file(): zipped.write(file,file.relative_to(pipeline_output).as_posix())
            Path(str(archive)+'.sha256').write_text(f'{hashlib.sha256(archive.read_bytes()).hexdigest()}  {archive.name}\n')
            with patch('publish_pipeline_prerelease.inspect_image', return_value={'profile':'multiturn_usb'}):
                verify_candidate(pipeline_output,identity['version'],identity['commit'])
                with self.assertRaisesRegex(ValueError,'metadata mismatch'):
                    verify_candidate(pipeline_output,identity['version'],'b'*40)
                (pipeline_output/'factory.bin').write_bytes(b'corrupt')
                with self.assertRaisesRegex(ValueError,'checksum mismatch'):
                    verify_candidate(pipeline_output,identity['version'],identity['commit'])
            with self.assertRaisesRegex(ValueError,'prerelease version'):
                verify_candidate(output,'0.1.0',identity['commit'])
            manifest = json.loads((output / 'manifest.json').read_text())
            self.assertEqual(len(manifest['components']), 4)
            self.assertEqual(manifest['image']['offset'], 0)


if __name__ == '__main__':
    unittest.main()
