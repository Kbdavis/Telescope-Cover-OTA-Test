from pathlib import Path
import sys
import unittest
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'tools'))
from probe_ota_activation import ResetGate

class ResetGateTest(unittest.TestCase):
    def test_unarmed_wrong_image_and_missing_ack_never_reset(self):
        g=ResetGate();g.observe('BOOT reset=SOFTWARE elf_sha256='+'a'*64,1);self.assertFalse(g.take(1))
        g.arm('a'*64);g.observe('OTA phase=rebooting',2)
        g.observe('BOOT reset=SOFTWARE elf_sha256='+'b'*64,2.1);g.ack=True;self.assertFalse(g.take(2.2))
        g.ack=False;g.observe('BOOT reset=SOFTWARE elf_sha256='+'a'*64,2.2);self.assertFalse(g.take(2.3))
        g.ack=True;self.assertTrue(g.take(2.4));self.assertFalse(g.take(2.5))
    def test_no_reboot_event_stale_window_and_accepted_boot_do_not_reset(self):
        for kind in ('missing','stale','accepted'):
            g=ResetGate();g.arm('a'*64);g.ack=True
            if kind!='missing':g.observe('OTA phase=rebooting',1)
            g.observe('BOOT reset=SOFTWARE elf_sha256='+'a'*64,1.2)
            if kind=='accepted':g.observe('OTA startup=accepted',1.3)
            self.assertFalse(g.take(4 if kind=='stale' else 1.4))
    def test_ack_before_or_after_boot_and_rearm(self):
        g=ResetGate()
        for before in (True,False):
            g.arm('a'*64);g.ack=before;g.observe('OTA phase=rebooting',1)
            g.observe('BOOT reset=SOFTWARE elf_sha256='+'a'*64,1.1);g.ack=True
            self.assertTrue(g.take(1.2));self.assertFalse(g.take(1.3))

if __name__=='__main__':unittest.main()
