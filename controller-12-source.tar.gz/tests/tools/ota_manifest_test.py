import hashlib
import importlib.util
from pathlib import Path
import struct
import sys
import unittest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "tools"))
from ota_manifest import DESCRIPTOR, MULTITURN_USB_DESCRIPTOR, control_mac, inspect_image, prepare_body, strong_startup_hook


def image_fixture():
    image = bytearray(352)
    image[:4] = b"\xe9\x01\x02\x20"
    image[23] = 1
    struct.pack_into("<II", image, 24, 0x3F400020, 320)
    struct.pack_into("<I", image, 32, 0xABCD5432)
    image[176:208] = b"\x33" * 32
    image[288:352] = DESCRIPTOR
    checksum = 0xEF
    for byte in image[32:]:
        checksum ^= byte
    image += b"\0" * 15 + bytes([checksum])
    image += hashlib.sha256(image).digest()
    return bytes(image)


def elf_fixture(binding=1, name=b"verifyRollbackLater"):
    names = b"\0" + name + b"\0"
    elf = bytearray(52 + 3 * 40)
    elf[:6] = b"\x7fELF\x01\x01"
    struct.pack_into("<I", elf, 32, 52)
    struct.pack_into("<HH", elf, 46, 40, 3)
    struct.pack_into("<10I", elf, 92, 0, 3, 0, 0, len(elf), len(names), 0, 0, 1, 0)
    struct.pack_into("<10I", elf, 132, 0, 2, 0, 0, len(elf) + len(names), 32, 1, 0, 4, 16)
    return bytes(elf) + names + b"\0" * 16 + struct.pack("<IIIBBH", 1, 0x400D0000, 4, binding << 4 | 2, 0, 1)


class OtaManifestTest(unittest.TestCase):
    def test_image_integrity_and_all_metadata(self):
        image = image_fixture()
        manifest = inspect_image(image)
        self.assertEqual(manifest["elf"], "33" * 32)
        self.assertEqual(manifest["sha256"], hashlib.sha256(image).hexdigest())
        for offset in (0, 1, 2, 3, 12, 23, 28, 32, 176, 288, 296, 312, 328, 330, 332, 336, len(image) - 1):
            bad = bytearray(image)
            bad[offset] ^= 0x80
            with self.subTest(offset=offset), self.assertRaises(ValueError):
                inspect_image(bad)
        for bad in (image[:-1], image + b"x", b"", b"\0" * 352):
            with self.assertRaises(ValueError):
                inspect_image(bad)

    def test_descriptor_not_just_outer_image_checksum(self):
        image = bytearray(image_fixture())
        image[330] = 6  # Unsupported settings schema, with repaired native checksum/hash.
        checksum = 0xEF
        for byte in image[32:352]:
            checksum ^= byte
        image[367] = checksum
        image[368:] = hashlib.sha256(image[:368]).digest()
        with self.assertRaisesRegex(ValueError, "descriptor"):
            inspect_image(image)

    def test_compile_profile_is_never_labeled_production(self):
        image = bytearray(image_fixture())
        image[312:328] = b"test_profile".ljust(16, b"\0")
        checksum = 0xEF
        for byte in image[32:352]:
            checksum ^= byte
        image[367] = checksum
        image[368:] = hashlib.sha256(image[:368]).digest()
        with self.assertRaisesRegex(ValueError, "descriptor"):
            inspect_image(image)
        self.assertEqual(inspect_image(image, allow_test_profile=True)["profile"], "test_profile")

    def test_multiturn_usb_requires_explicit_validation_and_keeps_other_guards(self):
        image = bytearray(image_fixture())
        image[288:352] = MULTITURN_USB_DESCRIPTOR
        checksum = 0xEF
        for byte in image[32:352]:
            checksum ^= byte
        image[367] = checksum
        image[368:] = hashlib.sha256(image[:368]).digest()
        with self.assertRaisesRegex(ValueError, 'descriptor'):
            inspect_image(image)
        with self.assertRaisesRegex(ValueError, 'descriptor'):
            inspect_image(image, allow_test_profile=True)
        self.assertEqual(inspect_image(image, allow_multiturn_usb=True)['profile'], 'multiturn_usb')
        image[-1] ^= 1
        with self.assertRaisesRegex(ValueError, 'hash'):
            inspect_image(image, allow_multiturn_usb=True)

    def test_strong_c_hook_required(self):
        self.assertTrue(strong_startup_hook(elf_fixture()))
        self.assertFalse(strong_startup_hook(elf_fixture(binding=2)))
        self.assertFalse(strong_startup_hook(elf_fixture(name=b"_Z19verifyRollbackLaterv")))
        self.assertFalse(strong_startup_hook(b""))
        self.assertFalse(strong_startup_hook(elf_fixture()[:100]))

    def test_shared_cpp_hmac_vector_and_exact_body(self):
        manifest = dict(product="telescope-cover", profile="web_control", protocol=1, settings=5,
                        handoff=1, size=1024, sha256="1" * 64, md5="2" * 32, elf="3" * 64)
        body = prepare_body(manifest, 1)
        args = (b"0123456789abcdef0123456789abcdef", "POST", "/api/ota/prepare", "boot",
                "0123456789abcdef0123456789abcdef", "")
        expected = "6094c27fd163c2e0491c5430b1037cacb8ffac57ad05c7d44a3c8153adc9640c"
        self.assertEqual(control_mac(*args, body), expected)
        self.assertNotEqual(control_mac(*args, body + b"\n"), expected)
        self.assertNotIn(args[0], body)
        for value in (0, True, 0xFFFFFFFF, None, '1', 1.0):
            with self.assertRaises(ValueError):
                prepare_body(manifest, value)


if __name__ == "__main__":
    unittest.main()
