#pragma once
#include <cassert>
#include <cstdarg>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>
#include <functional>
#include <cstdlib>
#include "../Arduino.h"
#define IRAM_ATTR
inline uint32_t fakeNow=100;
inline unsigned heapCalls=0,stackCalls=0,timerStarts=0,timerStops=0;
inline unsigned failureHeapCalls=0;
inline bool timerRunning=false,stopFails=false;
inline unsigned long millis(){return fakeNow;}
using portMUX_TYPE=int;
#define portMUX_INITIALIZER_UNLOCKED 0
#define portENTER_CRITICAL(mux) ((void)(mux))
#define portEXIT_CRITICAL(mux) ((void)(mux))
struct FakeSerial {
 std::string output;
 size_t write(const uint8_t* data,size_t size){output.append(reinterpret_cast<const char*>(data),size);return size;}
 template<class... Args> void printf(const char*,Args...){}
 void println(const char*){}
};
inline FakeSerial Serial;
struct FakeBus:Stream {
 void begin(unsigned,int,int,int){}
 int available() override{return 0;}int read() override{return -1;}
 size_t write(const uint8_t*,size_t count) override{return count;}
};
inline FakeBus Serial1;
constexpr int SERIAL_8N1=0;
inline void yield(){}
#define RTC_NOINIT_ATTR
struct FakeESP {unsigned getFreeHeap(){return 100000;}unsigned getMinFreeHeap(){return 90000;}};
inline FakeESP ESP;
struct IPAddress {explicit IPAddress(uint32_t){}std::string toString(){return "127.0.0.1";}};
struct EventConnection {uint8_t bssid[6]={};int reason=1,rssi=-60,channel=1,authmode=0,old_mode=0,new_mode=1;};
struct EventIP {struct {struct {uint32_t addr=0;} ip,gw,netmask;} ip_info;bool ip_changed=false;};
struct WiFiEventInfo_t {EventConnection wifi_sta_disconnected,wifi_sta_connected,wifi_sta_authmode_change;EventIP got_ip;};
using WiFiEvent_t=int;
enum {ARDUINO_EVENT_WIFI_STA_DISCONNECTED,ARDUINO_EVENT_WIFI_STA_CONNECTED,ARDUINO_EVENT_WIFI_STA_AUTHMODE_CHANGE,ARDUINO_EVENT_WIFI_STA_GOT_IP};
struct FakeWiFi {
 std::function<void(WiFiEvent_t,WiFiEventInfo_t)> eventCallback;
 int status(){return 3;}int RSSI(){return -60;}int getMode(){return 1;}
 bool getSleep(){return false;}bool getAutoReconnect(){return true;}
 const char* eventName(int){return "event";}const char* disconnectReasonName(int){return "reason";}
 template<class Callback> void onEvent(Callback callback){eventCallback=callback;}
};
inline FakeWiFi WiFi;
using esp_err_t=int;using wifi_err_reason_t=int;
constexpr int ESP_OK=0,ESP_INTR_FLAG_IRAM=1;
struct wifi_ap_record_t {uint8_t bssid[6]={};int rssi=-60;unsigned primary=1;};
inline esp_err_t esp_wifi_sta_get_ap_info(wifi_ap_record_t*){return ESP_OK;}
enum {ESP_RST_POWERON,ESP_RST_EXT,ESP_RST_SW,ESP_RST_PANIC,ESP_RST_INT_WDT,ESP_RST_TASK_WDT,ESP_RST_WDT,ESP_RST_DEEPSLEEP,ESP_RST_BROWNOUT,ESP_RST_SDIO,ESP_RST_UNKNOWN};
inline int esp_reset_reason(){return ESP_RST_POWERON;}
inline uint32_t esp_random(){static uint32_t value=10;return ++value;}
struct esp_app_desc_t {uint8_t app_elf_sha256[32]={};};
inline const esp_app_desc_t* esp_ota_get_app_description(){static esp_app_desc_t app;return &app;}
struct multi_heap_info_t {uint32_t total_free_bytes=100000,minimum_free_bytes=90000,largest_free_block=80000;};
constexpr unsigned MALLOC_CAP_INTERNAL=1,MALLOC_CAP_8BIT=2,MALLOC_CAP_DMA=4;
inline void heap_caps_get_info(multi_heap_info_t*,unsigned){++heapCalls;}
inline unsigned heap_caps_get_largest_free_block(unsigned){++failureHeapCalls;return 80000;}
using esp_alloc_failed_hook_t=void(*)(size_t,uint32_t,const char*);
inline esp_alloc_failed_hook_t fakeAllocationHook=nullptr;
inline int heap_caps_register_failed_alloc_callback(esp_alloc_failed_hook_t hook){fakeAllocationHook=hook;return ESP_OK;}
struct FakeQueue {size_t size=0;unsigned capacity=24;std::vector<std::vector<char>> entries;};
inline FakeQueue fakeQueue;
using QueueHandle_t=FakeQueue*;using TaskHandle_t=void*;
constexpr int pdTRUE=1,pdPASS=1;
inline unsigned pdMS_TO_TICKS(unsigned value){return value;}
inline QueueHandle_t xQueueCreate(unsigned capacity,size_t size){fakeQueue.size=size;fakeQueue.capacity=capacity;return &fakeQueue;}
inline int xQueueSend(QueueHandle_t queue,const void* entry,unsigned timeout){
 assert(timeout==0);if(queue->entries.size()>=queue->capacity)return 0;
 queue->entries.emplace_back(static_cast<const char*>(entry),static_cast<const char*>(entry)+queue->size);return pdTRUE;
}
inline int xQueueReceive(QueueHandle_t queue,void* output,unsigned){
 if(queue->entries.empty())return 0;
 memcpy(output,queue->entries.front().data(),queue->size);queue->entries.erase(queue->entries.begin());return pdTRUE;
}
inline void xQueueReset(QueueHandle_t queue){queue->entries.clear();}
inline unsigned uxQueueMessagesWaiting(QueueHandle_t queue){return queue->entries.size();}
inline std::function<void(unsigned)> fakeTaskDelay;
inline void vTaskDelay(unsigned ms){fakeNow+=ms;if(fakeTaskDelay)fakeTaskDelay(ms);}
inline int xTaskCreatePinnedToCore(void(*)(void*),const char*,unsigned,void*,unsigned,void*,unsigned){return pdPASS;}
inline TaskHandle_t xTaskGetIdleTaskHandleForCPU(unsigned core){return reinterpret_cast<void*>(uintptr_t(core+1));}
inline TaskHandle_t xTaskGetCurrentTaskHandleForCPU(unsigned core){return xTaskGetIdleTaskHandleForCPU(core);}
inline uint32_t uxTaskGetStackHighWaterMark(void*){++stackCalls;return 1800;}
enum {TIMER_GROUP_1,TIMER_1,TIMER_COUNT_UP,TIMER_PAUSE,TIMER_ALARM_EN,TIMER_AUTORELOAD_EN,TIMER_INTR_LEVEL};
struct timer_config_t {int divider=0,counter_dir=0,counter_en=0,alarm_en=0,auto_reload=0,intr_type=0;};
inline esp_err_t timer_init(int,int,timer_config_t*){return ESP_OK;}
inline esp_err_t timer_set_counter_value(int,int,uint64_t){return ESP_OK;}
inline esp_err_t timer_set_alarm_value(int,int,uint64_t){return ESP_OK;}
inline esp_err_t timer_isr_callback_add(int,int,bool(*)(void*),void*,int){return ESP_OK;}
inline esp_err_t timer_start(int,int){++timerStarts;timerRunning=true;return ESP_OK;}
inline esp_err_t timer_pause(int,int){if(stopFails)return -1;timerRunning=false;return ESP_OK;}
inline esp_err_t timer_disable_intr(int,int){return ESP_OK;}
inline esp_err_t timer_isr_callback_remove(int,int){return ESP_OK;}
inline esp_err_t timer_deinit(int,int){++timerStops;return ESP_OK;}
