#include "bench_ota_protocol.h"
#include <cassert>
#include <string>
#include <cstdio>
using namespace cover;
int main(){
 const std::string canonical="product=telescope-cover-ota-bench\nprotocol=1\nlayout=cover-4mb-v1\nsettings=preserve-cover-app-v1\nsource_build=1\nsource_elf="+std::string(64,'1')+"\ntarget_build=2\ntarget_elf="+std::string(64,'2')+"\nsize=1000000\nsha256="+std::string(64,'3')+"\n";
 auto parse=[](const std::string& s){BenchManifest m;return parseBenchManifest(s.data(),s.size(),m);};
 BenchManifest m;assert(parseBenchManifest(canonical.data(),canonical.size(),m));assert(m.size==1000000 && m.sourceBuild==1 && m.targetBuild==2);
 assert(benchSourceAllowed(m,1,m.source));assert(!benchSourceAllowed(m,2,m.source));assert(!benchSourceAllowed(m,1,m.target));
 for(const auto& change:{std::pair<std::string,std::string>{"source_build=1","source_build=01"},{"target_build=2","target_build=1"},{"target_build=2","target_build=10000"},{"size=1000000","size=1310721"},{"size=1000000","size=42949672960"},{"sha256=3","sha256=G"},{"protocol=1","protocol=2"},{"telescope-cover-ota-bench","telescope-cover"}}){auto s=canonical;const auto at=s.find(change.first);assert(at!=std::string::npos);s.replace(at,change.first.size(),change.second);assert(!parse(s));}
 assert(!parse(canonical+"extra=1\n"));assert(!parse(canonical.substr(0,canonical.size()-1)));assert(!parse(canonical+std::string(1,'\0')));
 uint8_t p[352]={};p[0]=0xe9;p[1]=1;p[2]=2;p[3]=0x20;p[23]=1;otaPut32(p+28,320);otaPut32(p+32,0xabcd5432);memcpy(p+176,m.target,32);memcpy(p+288,"TCBENCHOTA01",12);otaPut32(p+304,2);
 assert(benchPrefixValid(p,sizeof(p),m));p[288]^=1;assert(!benchPrefixValid(p,sizeof(p),m));p[288]^=1;p[304]=1;assert(!benchPrefixValid(p,sizeof(p),m));p[304]=2;p[176]^=1;assert(!benchPrefixValid(p,sizeof(p),m));
 puts("Bench manifest/source/image namespace, canonical bounds and prefix rejection passed");
}
