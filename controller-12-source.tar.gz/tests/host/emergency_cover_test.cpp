#include "emergency_shutdown.h"
#include "cover_controller.h"
#include <cassert>
#include <cstdio>
using namespace cover;
static uint32_t clockMs=100;
unsigned long millis(){return clockMs;}void yield(){}
struct Servo:ServoMotion {
 uint16_t position=2000,target=0;bool torque=false;unsigned moves=0;
 ServoResult validateConfiguration()override{return {};}
 ServoResult readPosition(uint16_t& p)override{p=position;return {};}
 ServoResult readTorque(bool& t)override{t=torque;return {};}
 ServoResult releaseTorque()override{torque=false;return {};}
 ServoResult enableTorque()override{torque=true;return {};}
 ServoResult moveTo(uint16_t p,uint16_t,uint8_t,uint16_t,uint16_t)override{target=p;++moves;return {};}
};
struct Rig {
 Servo servo;CoverController cover{servo};EmergencyShutdown shutdown;ShutdownEvidence e;bool closing=false;
 Rig(){clockMs=100;MotionSettings settings;settings.disableTorqueAfterMove=true; // Legacy shutdown requires released torque.
settings.minimum=500;settings.maximum=2500;
  assert(cover.initializeStationary(settings,600,2000));
  e.scope.enabled=e.scope.valid=e.scope.connected=e.scope.canFindHome=true;
  e.native.operation=1;e.native.valid=e.native.imagingIdle=e.native.cameraIdle=e.native.planIdle=true;
  refresh();assert(shutdown.start(clockMs,e));
 }
 void refresh(){
  e.coverReady=cover.state()!=State::Fault;e.coverStationary=!cover.moving()&&!cover.holding();
  e.coverOpen=cover.state()==State::Open;e.coverClosed=cover.state()==State::Closed;e.coverMoving=cover.moving();
  e.torqueOff=!servo.torque&&cover.torqueOffConfirmed();e.positionFresh=e.calibrationClean=true;
  e.scope.sampledAt=e.native.sampledAt=clockMs;++e.scope.sequence;++e.native.sequence;
 }
 void step(uint32_t now){clockMs=now;refresh();shutdown.tick(now,e);
  if(shutdown.status().phase==ShutdownPhase::Closing&&!closing&&!e.coverClosed){assert(shutdown.closePermitted(now,e));assert(cover.moveEndpoint(600,false,true));closing=true;}
  cover.tick(closing&&shutdown.closePermitted(now,e),e.scope.stowedCandidate(now));
 }
 void reachClosing(){
  e.reply={1,200,ShutdownAction::StopCapture,true,true,{}};step(200);step(300);step(400);assert(servo.moves==0);
  e.reply={1,500,ShutdownAction::Park,true,true,{}};step(500);assert(servo.moves==0);
  e.native.closed=e.scope.atHome=true;e.scope.consecutiveStowed=2;step(600);assert(servo.moves==0);step(700);
  assert(servo.moves==1&&servo.torque&&cover.state()==State::Closing);
 }
};
int main(){
 Rig ok;ok.reachClosing();assert(ok.shutdown.status().phase!=ShutdownPhase::Complete);
 ok.servo.position=600;for(int i=0;i<8;++i)ok.step(750+50*i);
 assert(ok.cover.state()==State::Closed&&!ok.servo.torque&&ok.shutdown.status().phase==ShutdownPhase::Complete);
 Rig capture;capture.reachClosing();capture.e.native.imagingIdle=false;capture.step(750);
 assert(capture.shutdown.status().phase==ShutdownPhase::Fault&&capture.cover.state()==State::Fault&&!capture.servo.torque);
 Rig disconnected;disconnected.reachClosing();disconnected.e.native.valid=false;disconnected.step(750);
 assert(disconnected.cover.state()==State::Fault&&!disconnected.servo.torque);
 Rig stop;stop.reachClosing();stop.shutdown.cancel(710);stop.cover.stop();stop.step(750);
 assert(stop.shutdown.status().phase==ShutdownPhase::Cancelled&&!stop.servo.torque&&stop.servo.moves==1);
 // The real cover driver stays stationary throughout telemetry recovery. Only
 // separately confirmed stow after recovery can issue its single close move.
 Rig recovery;recovery.e.reply={1,200,ShutdownAction::StopCapture,true,true,{}};recovery.step(200);
 recovery.e.scope.error=alpaca::Error::Timeout;recovery.e.scope.valid=false;recovery.step(300);
 assert(recovery.shutdown.status().recovering&&recovery.servo.moves==0&&!recovery.servo.torque);
 recovery.e.scope.error=alpaca::Error::None;recovery.e.scope.valid=true;recovery.step(400);recovery.step(500);
 assert(!recovery.shutdown.status().recovering&&recovery.servo.moves==0);
 recovery.step(600);recovery.step(700);assert(recovery.shutdown.status().phase==ShutdownPhase::Stowing);
 recovery.e.reply={1,800,ShutdownAction::Park,true,true,{}};recovery.step(800);
 recovery.e.native.closed=recovery.e.scope.atHome=true;recovery.e.scope.consecutiveStowed=2;recovery.step(900);recovery.step(1000);
 assert(recovery.servo.moves==1&&recovery.servo.torque);
 recovery.e.scope.valid=false;recovery.e.scope.error=alpaca::Error::Timeout;recovery.step(1050);
 assert(recovery.shutdown.status().phase==ShutdownPhase::Fault&&!recovery.shutdown.status().recovering&&recovery.cover.state()==State::Fault&&!recovery.servo.torque);
 puts("Emergency/cover integration: no early servo motion, closed+torque-off completion, and real controller fault/release on lost clearance passed");
}
