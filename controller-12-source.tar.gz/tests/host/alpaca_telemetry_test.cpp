#include "alpaca_telemetry.h"
#include <assert.h>
#include <stdio.h>
using namespace cover::alpaca;
struct Fake:Transport {
 bool cameraConnected=true,heaterConnected=true,identity=true,connectSucceeds=true;Error error=Error::None;unsigned gets=0,puts=0,heaterReads=0;
 unsigned cameraPuts=0,heaterPuts=0;
 Reply get(Property p,uint32_t tx) override {assert(tx);++gets;Reply r;r.error=error;r.number=p==Property::Altitude?-89.8:0;return r;}
 Reply getMetric(Metric p,uint32_t tx) override {
  assert(tx);++gets;Reply r;r.error=error;
  switch(p){
  case Metric::CameraConnected:r.value=cameraConnected;break;
  case Metric::HeaterConnected:r.value=heaterConnected;break;
  case Metric::CameraState:r.number=0;break;
  case Metric::CameraTemperature:r.number=25.5;break;
  case Metric::HeaterCount:r.number=1;break;
  case Metric::HeaterIdentity:r.value=identity;break;
  case Metric::HeaterState:++heaterReads;r.value=false;break;
  }return r;
 }
 Reply connectAuxiliary(Auxiliary device,uint32_t) override{
  ++puts;
  if(device==Auxiliary::Camera){++cameraPuts;if(connectSucceeds)cameraConnected=true;}
  else {++heaterPuts;if(connectSucceeds)heaterConnected=true;}
  return {};
 }
};
void run(TelemetryClient& client,Fake& f,uint32_t start,bool connect,unsigned steps=24){
 for(unsigned i=0;i<steps;++i){unsigned calls=f.gets+f.puts;client.step(start+i*100,connect);assert(f.gets+f.puts==calls+1);}
}
int main(){
 Fake f;TelemetryClient c(f);run(c,f,100,false);auto s=c.status();
 assert(s.altitude.valid && s.altitude.value==-89.8 && s.azimuth.valid && s.azimuth.value==0);
 assert(s.cameraState.valid && s.cameraState.value==0 && s.cameraTemperature.value==25.5);
 assert(s.heater.valid && s.heater.value==0 && f.puts==0); // Off is a valid reading, not unknown.
 assert(!s.heater.fresh(s.heater.at+60001));
 f.error=Error::Timeout;run(c,f,3000,false);
 assert(!c.status().heater.valid && !c.status().cameraTemperature.valid);
 assert(c.status().altitude.hasValue&&c.status().altitude.value==s.altitude.value&&c.status().altitude.at==s.altitude.at);
 assert(!c.status().altitude.fresh(6000)); // Retained display data never becomes fresh on error.
 Fake disconnected;disconnected.cameraConnected=disconnected.heaterConnected=false;TelemetryClient ro(disconnected);run(ro,disconnected,0,false);
 assert(disconnected.puts==0 && !ro.status().cameraState.valid);
 TelemetryClient automatic(disconnected);run(automatic,disconnected,4000,true,40);
 assert(disconnected.puts==2 && disconnected.cameraPuts==1 && disconnected.heaterPuts==1);
 assert(automatic.status().cameraTemperature.valid && automatic.status().heater.valid);
 // Each independent session is restored after a later restart, without writing
 // to healthy sessions or treating the connect acknowledgment as a sample.
 disconnected.cameraConnected=disconnected.heaterConnected=false;run(automatic,disconnected,20000,true,40);
 assert(disconnected.cameraPuts==2 && disconnected.heaterPuts==2 && automatic.status().heater.valid);
 run(automatic,disconnected,30000,true,40);assert(disconnected.puts==4);
 Fake refused;refused.cameraConnected=refused.heaterConnected=false;refused.connectSucceeds=false;
 TelemetryClient retry(refused);run(retry,refused,0,true,100);
 assert(refused.cameraPuts==1 && refused.heaterPuts==1);
 assert(!retry.status().cameraState.valid && !retry.status().heater.valid);
 run(retry,refused,10000,true,100);assert(refused.cameraPuts==2 && refused.heaterPuts==2);
 Fake unknown;unknown.identity=false;TelemetryClient wrongSwitch(unknown);run(wrongSwitch,unknown,0,true);
 assert(unknown.heaterReads==0 && !wrongSwitch.status().heater.valid && wrongSwitch.status().heater.error==Error::Unsupported);
 Fake failed;failed.cameraConnected=failed.heaterConnected=false;failed.error=Error::Timeout;TelemetryClient fail(failed);run(fail,failed,0,true);
 assert(failed.puts==0);
 puts("Optional telemetry: independent samples, stale/error invalidation, exact heater identity, read-only and connection guards passed");
}
