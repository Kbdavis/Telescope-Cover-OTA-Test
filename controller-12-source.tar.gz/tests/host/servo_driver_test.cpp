#include "servo_controller.h"
#ifdef COVER_FACTORY_MOTION_BENCH
#include "factory_motion_bench.h"
#endif
#include <assert.h>
#include <deque>
#include <vector>
#include <stdio.h>
using namespace cover;
static unsigned long clockMs;
unsigned long millis() { return clockMs; }
void yield() { ++clockMs; }
#include "servo_test_bus.h"

int main() {
  // Read-only control-register evidence preserves raw values and never stages
  // a command. A failed read leaves caller output and cached evidence intact.
  {Bus b;ServoController s(b);ServoGoalReadback goal;goal.positionRaw=123;
   ServoDiagnostics d;s.copyDiagnostics(d);assert(!d.goalValid);
   b.registers[41]=10;b.registers[42]=0xc7;b.registers[43]=9;
   b.registers[44]=0x34;b.registers[45]=0x12;b.registers[46]=100;
   b.registers[48]=0xe8;b.registers[49]=3;
   assert(s.readGoal(goal));assert(goal.positionRaw==2503 && goal.register44Raw==0x1234 && goal.speedRaw==100 && goal.acceleration==10);
   assert(goal.torqueLimitRaw==1000);
   s.copyDiagnostics(d);assert(d.goalValid && d.goal.positionRaw==2503);
   b.status=8;assert(!s.readGoal(goal));assert(goal.positionRaw==2503);
   s.copyDiagnostics(d);assert(d.goalValid && d.goal.positionRaw==2503);
   for(const auto& packet:b.writes)assert(packet[4]==2 && packet[5]==41);
  }
  // Diagnostics are passive: a recovered checksum retry remains visible, while
  // later valid samples and failed reads cannot fabricate/erase observations.
  {Bus b;ServoController s(b);ServoDiagnostics d;s.copyDiagnostics(d);
   assert(!d.positionValid && !d.hasSuccess && !d.validationAttempted);
   b.corruptReplies=1;uint16_t p=123;assert(s.readPosition(p));s.copyDiagnostics(d);
   assert(d.exchanges==2 && d.failedExchanges==1 && d.failedReads==0 && d.retries==1);
   assert(d.positionValid && d.position==2048 && d.lastFailure.error==ServoError::InvalidPacket);
   auto writes=b.writes.size();s.copyDiagnostics(d);assert(b.writes.size()==writes);
   clockMs=100;b.silent=true;assert(!s.readPosition(p));s.copyDiagnostics(d);
   assert(d.position==2048 && d.positionAt==0 && d.failedReads==1 && d.retries==3);
   assert(d.failureAddress==56 && d.lastFailure.error==ServoError::Timeout);
   b.silent=false;assert(s.validateConfiguration());s.copyDiagnostics(d);assert(d.validationPassed && d.configurationRead);
   b.registers[33]=1;assert(!s.validateConfiguration());s.copyDiagnostics(d);
   assert(!d.validationPassed && d.validationResult.error==ServoError::InvalidConfiguration && d.configuration.mode==1);
   b.silent=true;assert(!s.validateConfiguration());s.copyDiagnostics(d);
   assert(d.configuration.mode==1 && d.validationResult.error==ServoError::Timeout);
  }
  Bus bus; ServoController servo(bus);
  assert(bus.writes.empty());
  assert(servo.ping());
  uint16_t position = 123;
  bus.corruptReplies = 1;
  size_t before = bus.writes.size();
  assert(servo.readPosition(position) && position == 2048);
  assert(bus.writes.size() == before + 2);
  bus.corruptReplies = 3; position = 123;
  assert(!servo.readPosition(position) && position == 123);
  bus.silent = true; before = bus.writes.size();
  assert(servo.readPosition(position).error == ServoError::Timeout);
  assert(position == 123 && bus.writes.size() == before + 3);
  bus.silent = false; bus.status = 4;
  auto result = servo.readPosition(position);
  assert(result.error == ServoError::DeviceError && result.deviceStatus == 4 && position == 123);
  assert(servo.lastResult().deviceStatus==4);
  bus.status=8;assert(!servo.readPosition(position));assert(position==123);
  assert(strstr(servoFaultReason(servo.lastResult(),"read failed"),"cycle servo power"));
  bus.status = 0;
  assert(servo.validateConfiguration());
  assert(servo.lastResult()); // A successful exchange clears the current error, not diagnostic history.
  uint8_t snapshot[40]={};before=bus.writes.size();
  assert(servo.readConfigurationSnapshot(snapshot));
  for(unsigned i=0;i<40;++i)assert(snapshot[i]==bus.registers[i]);
  assert(bus.writes.size()==before+2);
  for(size_t i=before;i<bus.writes.size();++i)assert(bus.writes[i][4]==2);
  for(auto& byte:snapshot)byte=0xa5;
  bus.silentAddress=29;
  assert(servo.readConfigurationSnapshot(snapshot).error==ServoError::Timeout);
  for(auto byte:snapshot)assert(byte==0xa5);
  bus.silentAddress=-1;
  ServoConfiguration observed;
  bus.registers[18]=12;bus.registers[31]=85;before=bus.writes.size();
  assert(servo.validateConfiguration(observed).error==ServoError::InvalidConfiguration);
  assert(observed.phase==12 && observed.offset==85 && observed.maximum==4095);
  assert(bus.writes.size()==before+3 && bus.writes.back()[4]==2);
  bus.silent=true;
  assert(servo.validateConfiguration(observed).error==ServoError::Timeout);
  assert(observed.phase==12 && observed.offset==85); // No fabricated values on a failed read.
  bus.silent=false;bus.registers[18]=0;bus.registers[31]=0;
  bus.registers[33] = 1; before = bus.writes.size();
  assert(servo.moveTo(2100,400,10,100,3900).error == ServoError::InvalidConfiguration);
  for (size_t i = before; i < bus.writes.size(); ++i) assert(bus.writes[i][4] != 3);
  bus.registers[33] = 0;
  before = bus.writes.size();
  assert(!servo.moveTo(4000,400,10,100,3900));
  assert(!servo.moveTo(2100,0,10,100,3900));
  assert(bus.writes.size() == before);
  bus.registers[40] = 0;
  assert(servo.moveTo(2100,400,10,100,3900).error == ServoError::TorqueDisabled);
  before=bus.writes.size();bus.positionOutlier=true;
  assert(servo.enableTorque().error==ServoError::InvalidPosition);
  for(size_t i=before;i<bus.writes.size();++i)assert(bus.writes[i][4]!=3);
  assert(servo.enableTorque());
  auto goal = bus.writes[bus.writes.size()-2];
  assert(goal[4] == 3 && goal[5] == 41 && goal[7] == 0 && goal[8] == 8);
  assert(bus.writes.back()[5] == 40 && bus.writes.back()[6] == 1);
  bus.registers[40] = 1;
  assert(servo.moveTo(2100,400,10,100,3900));
  goal = bus.writes.back();
  assert(goal[5] == 41 && goal[6] == 10 && goal[7] == 52 && goal[8] == 8);
  assert(goal[9] == 0 && goal[10] == 0 && goal[11] == 144 && goal[12] == 1);
  // Boundary crossing and half-turn goals are rejected without any write,
  // even with valid mode/limits/torque and a short modular endpoint distance.
  for(const auto& pair : {std::pair<uint16_t,uint16_t>{4000,100},{100,4000},{0,2048}}){
    bus.registers[56]=pair.first&255;bus.registers[57]=pair.first>>8;
    const auto first=bus.writes.size();
    assert(servo.moveTo(pair.second,100,10,0,4095).error==ServoError::InvalidPosition);
    for(size_t i=first;i<bus.writes.size();++i)assert(bus.writes[i][4]!=3);
  }
  bus.registers[56]=0;bus.registers[57]=8;
  bus.registers[60] = 25; bus.registers[61] = 4;
  bus.registers[69] = 12; bus.registers[70] = 128;
  bus.registers[67]=0xc7;bus.registers[68]=9;
  ServoTelemetry telemetry;
  assert(servo.readTelemetry(telemetry));
  assert(telemetry.relativeLoad == -25 && telemetry.currentRaw == -12);
  assert(telemetry.targetPositionRaw==2503);
  bus.registers[57] = 128;
  assert(servo.readTelemetry(telemetry).error == ServoError::InvalidPosition);
  assert(telemetry.position == 2048);
  bus.corruptReplies = 1; before = bus.writes.size();
  assert(!servo.releaseTorque());
  assert(bus.writes.size() == before + 1); // Never retry an uncertain write.
  assert(servo.releaseTorque());
  for (const auto& packet : bus.writes)
    if (packet[4] == 3) assert(packet[5] == 40 || packet[5] == 41);
  Bus factoryBus;
  const uint8_t baseline[40] = {
    3,9,0,9,3,1,0,0,1,0,0,255,15,70,140,40,232,3,12,44,
    47,32,32,0,16,0,1,1,54,1,1,85,0,0,20,200,80,10,200,200
  };
  for(unsigned i=0;i<40;++i)factoryBus.registers[i]=baseline[i];
  ServoController factory(factoryBus);
  ServoController normal(factoryBus);
  assert(factory.validateConfiguration());
  assert(normal.validateConfiguration()); // Exact commissioned profile accepted.
  for(unsigned i=0;i<40;++i){
    factoryBus.registers[i]^=1;
    size_t first=factoryBus.writes.size();
    assert(!factory.enableTorque());
    assert(!factory.moveTo(2068,100,10,2018,2078));
    for(size_t j=first;j<factoryBus.writes.size();++j)
      assert(factoryBus.writes[j][4]!=3);
    factoryBus.registers[i]^=1;
  }
  factoryBus.silentAddress=29;
  assert(!factory.enableTorque());
  factoryBus.silentAddress=-1;
  factoryBus.registers[40]=0;
  assert(factory.enableTorque()); // Virtual profile validation also in driver.
  factoryBus.registers[40]=1;
  assert(factory.moveTo(2068,100,10,2018,2078));
  // Feetech SMS_STS::WritePosEx interoperability fixture for the real failed
  // 3923 -> 3823 OPEN step (speed 100, ACC 10). A decreasing absolute target
  // uses the ordinary positive speed, not a wheel-mode direction-bit command.
  // SDK: github.com/ftservo/FTServo_Arduino/blob/main/src/SMS_STS.cpp
  factoryBus.registers[56]=0x53;factoryBus.registers[57]=0x0f; // 3923
  assert(factory.moveTo(3823,100,10,0,4095));
  const std::vector<uint8_t> vendorOpenPacket={0xff,0xff,0x01,0x0a,0x03,0x29,0x0a,0xef,0x0e,0x00,0x00,0x64,0x00,0x5d};
  assert(factoryBus.writes.back()==vendorOpenPacket);
  TravelArc boundary;boundary.closedRaw=4090;boundary.direction=1;boundary.length=10;
  boundary.minimumRaw=0;boundary.maximumRaw=4095;boundary.circular=true;
  factoryBus.registers[56]=250;factoryBus.registers[57]=15;
  const auto crossingStart=factoryBus.writes.size();
#ifdef COVER_ROLLOVER_BENCH
  assert(factory.rolloverSupported());
  assert(factory.moveAcrossBoundary(4,100,10,boundary));
  assert(factoryBus.writes.back()[5]==41 && factoryBus.writes.back()[7]==4 && factoryBus.writes.back()[8]==0);
  assert(!factory.moveAcrossBoundary(4,101,10,boundary));
  assert(!factory.moveAcrossBoundary(4,100,11,boundary));
  boundary.length=196;boundary.closedRaw=4000;factoryBus.registers[56]=160;
  assert(!factory.moveAcrossBoundary(100,100,10,boundary));
#else
  assert(!factory.rolloverSupported());
  assert(!factory.moveAcrossBoundary(4,100,10,boundary));
  for(size_t i=crossingStart;i<factoryBus.writes.size();++i)assert(factoryBus.writes[i][4]!=3);
#endif
  (void)crossingStart;
  for(unsigned i=0;i<40;++i)assert(factoryBus.registers[i]==baseline[i]);
  assert(factory.releaseTorque());
  for(const auto& packet:factoryBus.writes)
    if(packet[4]==3)assert(packet[5]==40 || packet[5]==41);
#ifdef COVER_REFERENCE_PROBE
  Bus referenceBus;for(unsigned i=0;i<40;++i)referenceBus.registers[i]=baseline[i];
  referenceBus.registers[40]=0;referenceBus.registers[55]=1;
  referenceBus.registers[56]=0xd9;referenceBus.registers[57]=0x0f; // 4057
  referenceBus.simulateReference=true;ServoController reference(referenceBus);ReferenceProbeEvidence evidence;
  for(unsigned i=0;i<40;++i){
    referenceBus.registers[i]^=1;const auto first=referenceBus.writes.size();
    assert(!reference.probeLockedReference(false,evidence)&&!evidence.writeAttempted);
    for(size_t j=first;j<referenceBus.writes.size();++j)assert(referenceBus.writes[j][4]!=3);
    referenceBus.registers[i]^=1;
  }
  referenceBus.registers[55]=0;assert(!reference.probeLockedReference(false,evidence)&&!evidence.writeAttempted);
  referenceBus.registers[55]=1;referenceBus.registers[40]=1;
  assert(!reference.probeLockedReference(false,evidence)&&!evidence.writeAttempted);
  referenceBus.registers[40]=0;referenceBus.positionOutlier=true;
  assert(!reference.probeLockedReference(false,evidence)&&!evidence.writeAttempted);
  referenceBus.ignoreReference=true;
  assert(!reference.probeLockedReference(false,evidence)&&evidence.writeAttempted&&evidence.lockConfirmed);
  assert(referenceBus.registers[31]==85&&referenceBus.registers[32]==0);
  referenceBus.ignoreReference=false;
  assert(reference.probeLockedReference(false,evidence));
  assert(evidence.positionBefore==4057&&evidence.positionAfter==2814&&evidence.positionAfterValid);
  assert(reference.validateConfiguration());
  assert(referenceBus.registers[31]==0x30&&referenceBus.registers[32]==0x05&&referenceBus.registers[55]==1);
  assert(reference.probeLockedReference(true,evidence));
  assert(evidence.positionBefore==2814&&evidence.positionAfter==4057);
  assert(reference.validateConfiguration());
  referenceBus.reverseReference=true;
  assert(!reference.probeLockedReference(false,evidence)&&evidence.writeAttempted);
  assert(referenceBus.registers[55]==1&&referenceBus.registers[40]==0);
  for(const auto& packet:referenceBus.writes)if(packet[4]==3)assert(packet[5]==31 && packet.size()==9);
#endif
  puts("Servo driver offline checks passed");
}
