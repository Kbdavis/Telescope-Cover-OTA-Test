#include "telescope_arm.h"
#include <cassert>
#include <cstdio>
#include <cstring>
using namespace cover;
ArmEvidence safe(uint32_t now,bool home=true,uint32_t sequence=1){
 ArmEvidence e;e.coverOpen=e.cameraIdle=e.maintenance=true;e.scope.enabled=e.scope.valid=e.scope.connected=true;
 e.scope.atHome=home;e.scope.sampledAt=now;e.scope.sequence=sequence;e.altitudeValid=true;e.altitudeAt=now;e.altitude=0;return e;
}
int main(){
 ArmOperation arm;auto e=safe(100);
 for(int guard=0;guard<7;++guard){auto bad=e;
  if(guard==0)bad.coverOpen=false;if(guard==1)bad.cameraIdle=false;if(guard==2)bad.scope.valid=false;
  if(guard==3)bad.scope.slewing=true;if(guard==4)bad.scope.tracking=true;if(guard==5)bad.scope.connected=false;if(guard==6)bad.scope.atHome=false;
  assert(!arm.start(true,100,bad));
 }
 assert(arm.start(true,100,e));assert(!arm.start(false,100,e));
 e.maintenance=false;assert(!arm.readyToSend(110,e));e.maintenance=true;assert(arm.readyToSend(110,e));
 arm.sent(120,true);assert(arm.status().locked);arm.step(130,e);assert(arm.status().locked); // pre-command sample
 e=safe(200,false,2);e.scope.slewing=true;arm.step(200,e);assert(arm.status().phase==ArmPhase::Waiting);
 e=safe(300,false,3);e.altitude=-45;arm.step(300,e);assert(arm.status().locked); // not home doesn't prove open
 e=safe(400,false,4);arm.step(400,e);arm.step(410,e);assert(arm.status().locked); // same sample not two confirmations
 e.scope.valid=false;arm.step(450,e);assert(arm.status().locked); // ordinary partial sweep must not erase confirmation
 e=safe(500,false,5);arm.step(500,e);assert(arm.status().phase==ArmPhase::Complete&&!arm.status().locked);
 assert(arm.start(false,600,safe(600,false)));arm.sent(610,true);
 e=safe(700,true,6);e.scope.slewing=true;arm.step(700,e);assert(arm.status().locked); // early home
 e=safe(800,true,7);arm.step(800,e);e=safe(900,true,8);arm.step(900,e);assert(!arm.status().locked);
 ArmOperation lost;assert(lost.start(true,100,safe(100)));lost.sent(120,false);
 assert(lost.status().phase==ArmPhase::Unknown&&lost.status().locked&&!lost.readyToSend(121,safe(121)));
 e=safe(200);e.scope.slewing=true;assert(!lost.finish(200,e));assert(lost.finish(210,safe(210)));
 ArmOperation timeout;assert(timeout.start(false,100,safe(100,false)));timeout.sent(120,true);
 timeout.step(60120,safe(60120,false));assert(timeout.status().phase==ArmPhase::Unknown&&timeout.status().locked);
 ArmOperation stale;assert(stale.start(true,100,safe(100)));stale.sent(120,true);e=safe(100);
 stale.step(5200,e);assert(stale.status().phase==ArmPhase::Unknown);
 ArmOperation partial;assert(partial.start(true,100,safe(100)));partial.sent(120,true);
 e=safe(200);e.scope.valid=false;partial.step(200,e);assert(partial.status().phase==ArmPhase::Waiting); // partial normal polling sweep
 e=safe(300);e.coverOpen=false;partial.step(300,e);assert(partial.status().phase==ArmPhase::Unknown);
 ArmOperation wrap;assert(wrap.start(false,0xffffff00,safe(0xffffff00,false)));wrap.sent(0xffffff10,true);
 wrap.step(10,safe(10,true,2));wrap.step(100,safe(100,true,3));assert(!wrap.status().locked);
 // Reproduce a physically completed lift outside the horizon tolerance.
 ArmOperation horizon;assert(horizon.start(true,100,safe(100)));horizon.sent(120,true);
 e=safe(200,false,2);e.altitude=4.64;horizon.step(200,e);
 e=safe(300,false,3);e.altitude=4.64;horizon.step(300,e);assert(horizon.status().locked);
 e=safe(60120,false,4);e.altitude=4.64;horizon.step(60120,e);
 assert(horizon.status().phase==ArmPhase::Unknown);
 assert(strstr(horizon.status().reason,"Lift verification timed out"));
 // A stopped cover near OPEN may be inspected, then separately commanded to stow.
 e=safe(60200,false,5);e.coverOpen=false;e.coverStoppedOpen=true;
 assert(!armStationary(60200,e));assert(armStationary(60200,e,true));
 assert(horizon.finish(60200,e));assert(!horizon.status().locked);
 assert(horizon.status().phase==ArmPhase::Idle);assert(!horizon.readyToSend(60200,e));
 auto home=e;home.scope.atHome=true;assert(!horizon.start(true,60200,home));
 assert(horizon.start(false,60200,e));assert(horizon.readyToSend(60200,e));horizon.sent(60210,true);
 e.scope.atHome=true;e.scope.sampledAt=60300;e.scope.sequence=6;horizon.step(60300,e);
 e.scope.sampledAt=60400;e.scope.sequence=7;horizon.step(60400,e);assert(!horizon.status().locked);
 // Every recovery guard remains authoritative; rejection leaves the lock latched.
 for(int guard=0;guard<8;++guard){ArmOperation op;op.reject(true);auto bad=e;
  bad.scope.sampledAt=60500;
  switch(guard){case 0:bad.coverStoppedOpen=false;break;case 1:bad.cameraIdle=false;break;
   case 2:bad.scope.valid=false;break;case 3:bad.scope.connected=false;break;
   case 4:bad.scope.slewing=true;break;case 5:bad.scope.tracking=true;break;
   case 6:bad.maintenance=false;break;case 7:bad.scope.sampledAt=1;break;}
  assert(!op.finish(60500,bad));assert(op.status().locked);
 }
 // Losing near-open feedback during the recovered stow still latches inspection.
 ArmOperation drift;e=safe(70000,false);e.coverOpen=false;e.coverStoppedOpen=true;
 assert(drift.start(false,70000,e));drift.sent(70010,true);e.coverStoppedOpen=false;
 drift.step(70020,e);assert(drift.status().phase==ArmPhase::Unknown);
 assert(!strcmp(drift.status().reason,"Open cover evidence lost"));
 puts("Arm controls: preflight, worker lock, fresh post-command completion, early home, horizon, timeout, uncertain outcome and wraparound passed");
}
