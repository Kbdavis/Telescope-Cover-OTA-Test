#include "settings.h"
#include <vector>
#include <assert.h>
#include <stdio.h>
#include <Preferences.h>
std::vector<uint8_t> storedPreferences;
bool preferencesAvailable=true,preferencesWriteFails=false;
using namespace cover;
int main(){
 assert(kAssemblyOpeningDirection==-1);
 {Calibration old;old.openingDirection=1;assert(!calibrationMatchesAssembly(old));
  old.openingDirection=-1;assert(calibrationMatchesAssembly(old));}
 {Calibration c;c.minimum=100;c.maximum=1000;c.closed=500;c.hasOpen=c.hasClosed=true;
  c.openingDirection=1;c.open=520;c.travelCounts=20;assert(!validCalibration(c));c.open=521;c.travelCounts=21;assert(validCalibration(c));}

 // Migration must preserve legacy limits/endpoints and conservative live speeds.
 uint16_t legacy[8]={0xca11,1,400,3600,600,2000,3,0};uint16_t sum=0x5a39;
 for(unsigned i=0;i<7;++i)sum=uint16_t((sum*31U)^legacy[i]);legacy[7]=sum;
 storedPreferences.assign(reinterpret_cast<uint8_t*>(legacy),reinterpret_cast<uint8_t*>(legacy)+sizeof(legacy));
 Calibration migrated;assert(loadCalibration(migrated)==SettingsLoad::Loaded);
 assert(migrated.closed==600 && migrated.open==2000 && migrated.profile.openSpeed==100 && migrated.profile.closeSpeed==100 && migrated.profile.timeoutMs==5000);
 migrated.profile.openSpeed=600;migrated.profile.closeSpeed=400;migrated.profile.jogSpeed=50;migrated.profile.timeoutMs=15000;
 assert(saveCalibration(migrated));Calibration roundTrip;assert(loadCalibration(roundTrip)==SettingsLoad::Loaded);
 assert(roundTrip.profile.openSpeed==600 && roundTrip.profile.closeSpeed==400 && roundTrip.profile.jogSpeed==50 && roundTrip.profile.timeoutMs==15000);
 migrated.profile.jogSpeed=101;assert(!saveCalibration(migrated));migrated.profile.jogSpeed=100;
 migrated.profile.acceleration=101;assert(!saveCalibration(migrated));migrated.profile.acceleration=10;
 migrated.profile.timeoutMs=499;assert(!saveCalibration(migrated));
 // Both legacy layouts migrate without writes; long/rollover-looking paths
 // retain raw evidence but require deliberate review, never shortest-path remapping.
 for(unsigned version:{1U,2U})for(int direction:{-1,1}){
  const uint16_t closed=direction>0?100:4000,opened=direction>0?200:3900;
  uint16_t record[13]={0xca11,uint16_t(version),0,4095,closed,opened,3,100,100,100,10,5000,0};
  const size_t count=version==1?8:13;uint16_t hash=0x5a39;
  for(size_t i=0;i<count-1;++i)hash=uint16_t((hash*31U)^record[i]);record[count-1]=hash;
  storedPreferences.assign(reinterpret_cast<uint8_t*>(record),reinterpret_cast<uint8_t*>(record)+2*count);
  const auto before=storedPreferences;Calibration copy;
  assert(loadCalibration(copy)==SettingsLoad::Loaded && copy.openingDirection==direction && copy.travelCounts==100);
  assert(storedPreferences==before);
  copy.openingDirection=-direction;assert(!saveCalibration(copy));
  record[4]=4000;record[5]=100;hash=0x5a39;
  for(size_t i=0;i<count-1;++i)hash=uint16_t((hash*31U)^record[i]);record[count-1]=hash;
  storedPreferences.assign(reinterpret_cast<uint8_t*>(record),reinterpret_cast<uint8_t*>(record)+2*count);
  const auto ambiguous=storedPreferences;
  assert(loadCalibration(copy)==SettingsLoad::ReviewRequired && copy.closed==4000 && copy.open==100);
  assert(storedPreferences==ambiguous && !saveCalibration(copy));
 }
 storedPreferences.clear();
 Calibration out;out.open=2050;
 assert(loadCalibration(out)==SettingsLoad::Missing && out.open==2050);
 Calibration c;assert(!validCalibration(c));c.open=2060;c.closed=2030;c.hasOpen=c.hasClosed=true;c.openingDirection=1;c.travelCounts=30;
 assert(validCalibration(c) && saveCalibration(c));assert(loadCalibration(out)==SettingsLoad::Loaded && out.open==2060 && out.closed==2030);
 c.open=2035;assert(!saveCalibration(c));assert(loadCalibration(out)==SettingsLoad::Loaded && out.open==2060);
 c.open=2060;c.minimum=3000;assert(!saveCalibration(c));c.minimum=2015;c.maximum=2050;assert(!saveCalibration(c));
 c.maximum=2075;preferencesWriteFails=true;c.open=2070;assert(!saveCalibration(c));preferencesWriteFails=false;
 assert(loadCalibration(out)==SettingsLoad::Loaded && out.open==2060);
 storedPreferences[3]^=1;assert(loadCalibration(out)==SettingsLoad::Invalid && out.open==2060);
 storedPreferences.resize(3);assert(loadCalibration(out)==SettingsLoad::Invalid);
 c.minimum=0;c.maximum=4095;c.closed=100;c.open=2000;c.travelCounts=1900;
 assert(validCalibration(c) && saveCalibration(c));assert(loadCalibration(out)==SettingsLoad::Loaded && out.minimum==0 && out.maximum==4095);
 for(int direction:{1,-1}){
  Calibration circular=c;circular.circular=true;circular.openingDirection=direction;
  circular.closed=direction>0?2386:100;circular.open=direction>0?100:2386;circular.travelCounts=1810;
  assert(validCalibration(circular)&&saveCalibration(circular));
  Calibration loaded;assert(loadCalibration(loaded)==SettingsLoad::Loaded&&loaded.circular);
  assert(loaded.closed==circular.closed&&loaded.open==circular.open&&loaded.travelCounts==1810);
  assert(!calibrationArc(loaded).contains(1000));
 }
 assert(saveCalibration(c));
 c.maximum=4096;assert(!saveCalibration(c));c.maximum=4095;
 preferencesAvailable=false;assert(loadCalibration(out)==SettingsLoad::Unavailable && !saveCalibration(c));
 preferencesAvailable=true;
 ApplicationSettings app, loaded;assert(!app.enableDebugTab);
 assert(loadApplicationSettings(loaded)==SettingsLoad::Missing);
 assert(validApplicationSettings(app) && saveApplicationSettings(app));
 assert(loadApplicationSettings(loaded)==SettingsLoad::Loaded && !loaded.wifiConfigured);
 assert(loadCalibration(out)==SettingsLoad::Loaded && out.open==2000);
 app.enableDebugTab=true;assert(saveApplicationSettings(app));assert(loadApplicationSettings(loaded)==SettingsLoad::Loaded && loaded.enableDebugTab);
 app.enableDebugTab=false;assert(saveApplicationSettings(app));
 app.wifiConfigured=true;assert(!saveApplicationSettings(app));
 strcpy(app.ssid,"Example network");strcpy(app.password,"example-password");
 app.alpacaEnabled=true;assert(!saveApplicationSettings(app));
 strcpy(app.alpacaHost,"192.168.1.131");
 assert(saveApplicationSettings(app));
 assert(loadApplicationSettings(loaded)==SettingsLoad::Loaded && loaded.wifiConfigured && loaded.alpacaEnabled);
 assert(strcmp(loaded.password,"example-password")==0);
 assert(loaded.alpacaReadOnly && !loaded.disableTorqueAfterMove);
 app.disableTorqueAfterMove=true;assert(saveApplicationSettings(app));
 assert(loadApplicationSettings(loaded)==SettingsLoad::Loaded && loaded.disableTorqueAfterMove);
 app.disableTorqueAfterMove=false;assert(saveApplicationSettings(app));
 assert(loadApplicationSettings(loaded)==SettingsLoad::Loaded && !loaded.disableTorqueAfterMove);
 app.alpacaReadOnly=false;assert(saveApplicationSettings(app));
 assert(loadApplicationSettings(loaded)==SettingsLoad::Loaded && !loaded.alpacaReadOnly);
 app.stowTimeoutSeconds=0;assert(!saveApplicationSettings(app));app.stowTimeoutSeconds=60;
 memset(app.ssid,'x',sizeof(app.ssid));assert(!saveApplicationSettings(app));
 app=loaded;strcpy(app.password,"short");assert(!saveApplicationSettings(app));
 app=loaded;memset(app.password,'a',64);app.password[64]=0;assert(saveApplicationSettings(app));
 app.password[0]='z';assert(!saveApplicationSettings(app));
 preferencesWriteFails=true;assert(!saveApplicationSettings(loaded));preferencesWriteFails=false;
 assert(loadApplicationSettings(app)==SettingsLoad::Loaded && app.password[0]=='a');
 Preferences raw;raw.begin("cover-app",false);
 std::vector<uint8_t> bytes(raw.getBytesLength("v1"));raw.getBytes("v1",bytes.data(),bytes.size());
 bytes[10]^=1;raw.putBytes("v1",bytes.data(),bytes.size());
 assert(loadApplicationSettings(loaded)==SettingsLoad::Invalid && strcmp(loaded.ssid,"Example network")==0);
 assert(loadCalibration(out)==SettingsLoad::Loaded && out.open==2000);
 raw.putBytes("v1",bytes.data(),3);assert(loadApplicationSettings(loaded)==SettingsLoad::Invalid);
 preferencesAvailable=false;assert(loadApplicationSettings(loaded)==SettingsLoad::Unavailable && !saveApplicationSettings(app));
 preferencesAvailable=true;
 ApplicationSettings named;strcpy(named.mdnsName,"garden-cover");
 assert(saveApplicationSettings(named));assert(loadApplicationSettings(loaded)==SettingsLoad::Loaded && strcmp(loaded.mdnsName,"garden-cover")==0);
 for(const char* bad:{"", "-cover", "cover-", "cover.local", "cover name", "Cover"}){
  strcpy(named.mdnsName,bad);assert(!saveApplicationSettings(named));
 }
 // Time settings round-trip and v5 migration preserve all existing fields.
 ApplicationSettings timed;strcpy(timed.mdnsName,"garden-cover");timed.ntpEnabled=true;timed.enableDebugTab=true;
 strcpy(timed.ntpServer,"time.nist.gov");strcpy(timed.timeZone,"EST5EDT,M3.2.0/2,M11.1.0/2");
 assert(saveApplicationSettings(timed));assert(loadApplicationSettings(loaded)==SettingsLoad::Loaded);
 assert(loaded.ntpEnabled && !strcmp(loaded.ntpServer,timed.ntpServer) && !strcmp(loaded.timeZone,timed.timeZone));
 raw.begin("cover-app",false);bytes.resize(raw.getBytesLength("v1"));raw.getBytes("v1",bytes.data(),bytes.size());
 bytes.resize(253);bytes[2]=5;uint32_t v5hash=2166136261UL;
 for(size_t i=0;i<249;++i)v5hash=(v5hash^bytes[i])*16777619UL;
 for(unsigned i=0;i<4;++i)bytes[249+i]=v5hash>>(8*i);
 raw.putBytes("v1",bytes.data(),bytes.size());
 assert(loadApplicationSettings(loaded)==SettingsLoad::Loaded && loaded.enableDebugTab && !loaded.ntpEnabled);
 assert(!strcmp(loaded.ntpServer,"pool.ntp.org") && !strcmp(loaded.timeZone,"MST7"));
 strcpy(timed.timeZone,"America/Phoenix");assert(!saveApplicationSettings(timed));
 strcpy(timed.timeZone,"MST7");strcpy(timed.ntpServer,"http://pool.ntp.org");assert(!saveApplicationSettings(timed));
 // v4 migration keeps torque preference and defaults the debug tab off.
 loaded.disableTorqueAfterMove=true;loaded.enableDebugTab=true;assert(saveApplicationSettings(loaded));
 raw.begin("cover-app",false);bytes.resize(raw.getBytesLength("v1"));raw.getBytes("v1",bytes.data(),bytes.size());
 bytes.resize(252);bytes[2]=4;uint32_t v4hash=2166136261UL;
 for(size_t i=0;i<248;++i)v4hash=(v4hash^bytes[i])*16777619UL;
 for(unsigned i=0;i<4;++i)bytes[248+i]=v4hash>>(8*i);
 raw.putBytes("v1",bytes.data(),bytes.size());
 assert(loadApplicationSettings(loaded)==SettingsLoad::Loaded && loaded.disableTorqueAfterMove && !loaded.enableDebugTab);
 // v3 records preserve the connection mode and default to retained endpoint torque.
 loaded.disableTorqueAfterMove=true;assert(saveApplicationSettings(loaded));
 raw.begin("cover-app",false);bytes.resize(raw.getBytesLength("v1"));raw.getBytes("v1",bytes.data(),bytes.size());
 bytes.resize(251);bytes[2]=3;uint32_t v3hash=2166136261UL;
 for(size_t i=0;i<247;++i)v3hash=(v3hash^bytes[i])*16777619UL;
 for(unsigned i=0;i<4;++i)bytes[247+i]=v3hash>>(8*i);
 raw.putBytes("v1",bytes.data(),bytes.size());
 assert(loadApplicationSettings(loaded)==SettingsLoad::Loaded && !loaded.disableTorqueAfterMove);
 // v2 records retain their hostname and GET-only behavior.
 loaded.alpacaReadOnly=false;assert(saveApplicationSettings(loaded));
 raw.begin("cover-app",false);bytes.resize(raw.getBytesLength("v1"));raw.getBytes("v1",bytes.data(),bytes.size());
 bytes.resize(250);bytes[2]=2;uint32_t v2hash=2166136261UL;
 for(size_t i=0;i<246;++i)v2hash=(v2hash^bytes[i])*16777619UL;
 for(unsigned i=0;i<4;++i)bytes[246+i]=v2hash>>(8*i);
 raw.putBytes("v1",bytes.data(),bytes.size());
 assert(loadApplicationSettings(loaded)==SettingsLoad::Loaded && loaded.alpacaReadOnly && strcmp(loaded.mdnsName,"garden-cover")==0);
 // Existing v1 records must preserve Wi-Fi and acquire the default hostname.
 loaded.wifiConfigured=true;strcpy(loaded.ssid,"Example");assert(saveApplicationSettings(loaded));
 raw.begin("cover-app",false);bytes.resize(raw.getBytesLength("v1"));raw.getBytes("v1",bytes.data(),bytes.size());
 bytes.resize(218);bytes[2]=1;uint32_t hash=2166136261UL;
 for(size_t i=0;i<214;++i)hash=(hash^bytes[i])*16777619UL;
 for(unsigned i=0;i<4;++i)bytes[214+i]=hash>>(8*i);
 raw.putBytes("v1",bytes.data(),bytes.size());
 assert(loadApplicationSettings(loaded)==SettingsLoad::Loaded && strcmp(loaded.mdnsName,"cover")==0 && loaded.wifiConfigured && strcmp(loaded.ssid,"Example")==0);
 assert(loaded.alpacaReadOnly && !loaded.disableTorqueAfterMove);
 app.disableTorqueAfterMove=true;assert(saveApplicationSettings(app));
 assert(loadApplicationSettings(loaded)==SettingsLoad::Loaded && loaded.disableTorqueAfterMove);
 app.disableTorqueAfterMove=false;assert(saveApplicationSettings(app));
 assert(loadApplicationSettings(loaded)==SettingsLoad::Loaded && !loaded.disableTorqueAfterMove);
 // Acceptance persists independently of normal settings saves and calibration.
 assert(!betaNoticeAccepted());
 preferencesWriteFails=true;assert(!acceptBetaNotice());preferencesWriteFails=false;
 assert(acceptBetaNotice() && betaNoticeAccepted());
 assert(saveApplicationSettings(loaded) && betaNoticeAccepted());
 preferencesWriteFails=true;assert(acceptBetaNotice()); // Accepted: no flash rewrite.
 assert(!resetApplicationSettingsPreservingCalibration() && betaNoticeAccepted());
 preferencesWriteFails=false;
 assert(resetApplicationSettingsPreservingCalibration());
 assert(!betaNoticeAccepted());
 assert(loadApplicationSettings(loaded)==SettingsLoad::Loaded);
 assert(!loaded.wifiConfigured && !loaded.ssid[0] && !loaded.password[0] && !loaded.alpacaEnabled && !loaded.alpacaHost[0]);
 assert(loaded.alpacaReadOnly && !loaded.disableTorqueAfterMove);
 app.disableTorqueAfterMove=true;assert(saveApplicationSettings(app));
 assert(loadApplicationSettings(loaded)==SettingsLoad::Loaded && loaded.disableTorqueAfterMove);
 app.disableTorqueAfterMove=false;assert(saveApplicationSettings(app));
 assert(loadApplicationSettings(loaded)==SettingsLoad::Loaded && !loaded.disableTorqueAfterMove);
 assert(loadCalibration(out)==SettingsLoad::Loaded && out.open==2000 && out.closed==100 && out.minimum==0 && out.maximum==4095);
 preferencesWriteFails=true;assert(!resetApplicationSettingsPreservingCalibration());preferencesWriteFails=false;
 assert(loadCalibration(out)==SettingsLoad::Loaded && out.open==2000);
 // Calibration-only deletion must leave application preferences intact.
 ApplicationSettings retained;retained.wifiConfigured=true;strcpy(retained.ssid,"Keep network");strcpy(retained.mdnsName,"garden-cover");assert(saveApplicationSettings(retained));
 preferencesWriteFails=true;assert(!clearCalibration());preferencesWriteFails=false;
 assert(loadCalibration(out)==SettingsLoad::Loaded && out.open==2000);
 assert(acceptBetaNotice());
 assert(clearCalibration());assert(loadCalibration(out)==SettingsLoad::Missing);
 assert(betaNoticeAccepted());
 preferencesAvailable=false;assert(!betaNoticeAccepted() && !acceptBetaNotice());preferencesAvailable=true;
 Preferences notice;notice.begin("cover-beta",false);const uint8_t invalid[]={1,2};notice.putBytes("accepted",invalid,sizeof(invalid));assert(!betaNoticeAccepted());
 assert(loadApplicationSettings(loaded)==SettingsLoad::Loaded && loaded.wifiConfigured && strcmp(loaded.ssid,"Keep network")==0 && strcmp(loaded.mdnsName,"garden-cover")==0);
 assert(clearCalibration()); // Already cleared is a successful no-op.
 preferencesAvailable=false;assert(!clearCalibration());preferencesAvailable=true;
 puts("Application settings validation, isolation, corruption and persistence checks passed");
 puts("Calibration validation and persistence checks passed");
}
