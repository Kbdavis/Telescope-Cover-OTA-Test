#define COVER_WEB_CONTROL
#include "../../src/time_sync.cpp"
#include "time_settings.h"
#include <cassert>
#include <cstdio>
using namespace cover;
int main(){
 ApplicationSettings settings;
 assert(!settings.ntpEnabled && !strcmp(settings.ntpServer,"pool.ntp.org") && !strcmp(settings.timeZone,"MST7"));
 beginTimeSync(settings);
 for(unsigned i=0;i<100000;++i)pollTimeSync(true);
 assert(timeClientStarts==0 && !lastTimeSync() && !logEpochSeconds());
 settings.ntpEnabled=true;beginTimeSync(settings);
 for(unsigned i=0;i<100000;++i)pollTimeSync(false);
 assert(timeClientStarts==0);
 pollTimeSync(true);assert(timeClientStarts==1 && configuredServer=="pool.ntp.org" && configuredZone=="MST7");
 // Unreachable server: no callback ever arrives. Polling always returns, never
 // starts another client, and logs remain explicitly unsynchronized.
 for(unsigned i=0;i<100000;++i)pollTimeSync(i%2);
 assert(timeClientStarts==1 && !logEpochSeconds());
 timeval sample{};sample.tv_sec=1;syncCallback(&sample);assert(!lastTimeSync());
 sample.tv_sec=1767225600;syncCallback(&sample);
 assert(lastTimeSync()==1767225600 && logEpochSeconds()>1704067200);
 pollTimeSync(false);assert(logEpochSeconds()>1704067200); // Holdover offline.
 char stamp[kLocalTimestampSize];formatLocalTimestamp(0,stamp,sizeof(stamp));assert(!stamp[0]);
 formatLocalTimestamp(1767225600,stamp,sizeof(stamp));assert(!strcmp(stamp,"2025-12-31T17:00:00-0700"));
 setenv("TZ","EST5EDT,M3.2.0/2,M11.1.0/2",1);tzset();
 formatLocalTimestamp(1767225600,stamp,sizeof(stamp));assert(!strcmp(stamp,"2025-12-31T19:00:00-0500"));
 formatLocalTimestamp(1751328000,stamp,sizeof(stamp));assert(!strcmp(stamp,"2025-06-30T20:00:00-0400"));
 for(const char* zone:{"MST7","UTC0","EST5EDT,M3.2.0/2,M11.1.0/2","CET-1CEST,M3.5.0,M10.5.0/3","<+0545>-5:45","GMT0BST,M3.5.0/1,M10.5.0","STD0DST,J60/1,J300/2"})assert(validTimeZone(zone,strlen(zone)+1));
 for(const char* zone:{"","America/Phoenix","garbage","UTC","UTC99","UTC0junk","EST5EDT","EST5EDT,","EST5EDT,M13.2.0,M11.1.0","EST5EDT,M3.0.0,M11.1.0","EST5EDT,M3.2.7,M11.1.0","EST5EDT,M3.2.0/2:60,M11.1.0","MST7\n","EST5EDT,M3.2.0,M11.1.0/2x"})assert(!validTimeZone(zone,strlen(zone)+1));
 for(const char* host:{"pool.ntp.org","time.nist.gov","192.168.1.1","local-server"})assert(validTimeServer(host,strlen(host)+1));
 for(const char* host:{"","https://pool.ntp.org","pool.ntp.org:123","bad host","bad..host","-bad.host","bad-.host"})assert(!validTimeServer(host,strlen(host)+1));
 char unterminated[64];memset(unterminated,'a',sizeof(unterminated));
 assert(!validTimeZone(unterminated,sizeof(unterminated)) && !validTimeServer(unterminated,sizeof(unterminated)));
 puts("time sync tests passed");
}
