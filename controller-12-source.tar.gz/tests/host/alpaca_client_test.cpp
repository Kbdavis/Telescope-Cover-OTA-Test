#include "alpaca_client.h"
#include <assert.h>
#include <stdio.h>
#include <cstring>
#include <initializer_list>
using namespace cover::alpaca;
struct Fake:Transport {
 bool connected=true,home=true,slew=false,tracking=false,capable=true;
 Error error=Error::None;uint32_t elapsed=0,requests=0,lastTransaction=0;
 unsigned connects=0;Error connectError=Error::None;
 Reply connectSession(uint32_t tx) override {assert(tx && tx!=lastTransaction);lastTransaction=tx;++connects;Reply r;r.error=connectError;return r;}
 Reply get(Property p,uint32_t tx) override {
  assert(tx && tx!=lastTransaction);lastTransaction=tx;++requests;
  Reply r;r.error=error;r.elapsedMs=elapsed;
  switch(p){case Property::Connected:r.value=connected;break;case Property::CanFindHome:r.value=capable;break;
  case Property::AtHome:r.value=home;break;case Property::Slewing:r.value=slew;break;case Property::Tracking:r.value=tracking;break;case Property::Altitude:case Property::Azimuth:assert(false && "Display telemetry must stay outside the safety sweep");break;}
  return r;
 }
};
void cycle(Client& c,uint32_t start,uint32_t spacing=100){for(unsigned i=0;i<6;++i)c.step(start+i*spacing);}
int main(){
 Fake t;Client c(t);c.step(0);assert(t.requests==0);
 c.enable(true);cycle(c,0);assert(c.status(500).valid && !c.status(500).stowedCandidate(500));
 cycle(c,1500);assert(c.status(2000).stowedCandidate(2000));
 assert(!c.status(6501).valid); // Age measured from oldest sample, not publication.
 c.step(3000);c.step(3100);c.step(3200);t.slew=true;c.step(3300);
 assert(!c.status(3300).stowedCandidate(3300)); // Contradiction revokes immediately.
 c.step(3400);c.step(3500);assert(c.status(3500).slewing);
 t.connected=false;c.step(4500);assert(!c.status(4500).valid && c.status(4500).error==Error::Offline);
 auto count=t.requests;c.step(4501);assert(t.requests==count); // Failure backoff.
 t.connected=true;t.slew=false;cycle(c,7500);assert(!c.status(8000).stowedCandidate(8000));
 cycle(c,9000);assert(c.status(9500).stowedCandidate(9500));
 t.error=Error::Protocol;c.step(10500);assert(!c.status(10500).valid);
 t.error=Error::None;t.elapsed=500;cycle(c,14000,600);assert(!c.status(17500).valid); // Slow sweep cannot grant freshness.
 t.elapsed=0;c.enable(false);count=t.requests;c.step(20000);assert(t.requests==count);
 // Millisecond wraparound must not bypass age checks.
 c.enable(true);cycle(c,0xffffff00U);assert(c.status(244).valid);
 assert(!c.status(5000).valid);
 // A stable raised/tracking/slewing telescope is connected, even though it
 // cannot grant stow clearance. Every intermediate poll must stay usable for
 // emergency shutdown rather than periodically reporting a false disconnect.
 for(unsigned mode=0;mode<4;++mode){
  Fake f;f.home=mode!=0;f.tracking=mode==1;f.slew=mode==2;f.capable=mode!=3;
  Client a(f);a.enable(true);cycle(a,0);
  for(uint32_t start:{1500U,3000U})for(unsigned stage=0;stage<6;++stage){
   const uint32_t now=start+100*stage;a.step(now);const auto s=a.status(now);
   assert(s.valid&&s.connected&&s.error==Error::None&&!s.stowedCandidate(now));
  }
 }
 // Each newly unsafe observation still revokes old clearance immediately,
 // before completion of the sweep, and recovery needs two fresh stowed sweeps.
 for(unsigned mode=0;mode<4;++mode){
  Fake f;Client a(f);a.enable(true);cycle(a,0);cycle(a,1500);
  assert(a.status(2000).stowedCandidate(2000));
  if(mode==0)f.capable=false;if(mode==1)f.home=false;if(mode==2)f.slew=true;if(mode==3)f.tracking=true;
  const unsigned changedStage=mode+1;
  for(unsigned stage=0;stage<6;++stage){
   const uint32_t now=3000+100*stage;a.step(now);
   if(stage>=changedStage&&stage<5)assert(!a.status(now).valid&&!a.status(now).stowedCandidate(now));
  }
  assert(a.status(3500).valid&&!a.status(3500).stowedCandidate(3500));
  f.capable=f.home=true;f.slew=f.tracking=false;
  cycle(a,4500);assert(!a.status(5000).stowedCandidate(5000));
  cycle(a,6000);assert(a.status(6500).stowedCandidate(6500));
 }
 // GET-only mode never connects, even after a valid disconnected response.
 {Fake f;f.connected=false;Client a(f);a.enable(true);a.step(0);a.step(3000);assert(f.connects==0 && a.status(3000).readOnly);}
 // Connection is a separate bounded step; PUT success alone never grants clearance.
 {Fake f;f.connected=false;Client a(f);a.enable(true,true);a.step(0);assert(f.connects==0);
  a.step(99);assert(f.connects==0);a.step(100);assert(f.connects==1 && !a.status(100).valid);
  for(uint32_t at:{200U,3200U,6200U,9200U})a.step(at);
  assert(f.connects==1);a.step(12200);a.step(12300);assert(f.connects==2);
  f.connected=true;cycle(a,12400);assert(a.status(12900).valid && !a.status(12900).stowedCandidate(12900));
  cycle(a,13900);assert(a.status(14400).stowedCandidate(14400) && !a.status(14400).readOnly);}
 // Do not issue writes when GET failed; disabling also cancels a pending connection.
 {Fake f;f.connected=false;f.error=Error::Timeout;Client a(f);a.enable(true,true);a.step(0);a.step(3000);assert(f.connects==0);
  f.error=Error::None;a.step(6000);a.enable(false,true);a.step(6100);assert(f.connects==0);}
 // Lost PUT response: re-read before deciding whether a retry is necessary.
 {Fake f;f.connected=false;f.connectError=Error::Timeout;Client a(f);a.enable(true,true);a.step(0);a.step(100);
  assert(a.status(100).error==Error::Timeout);f.connected=true;cycle(a,3100);assert(f.connects==1 && a.status(3600).valid);}
 // Telescope restart after previously verified stow: network failures revoke
 // clearance, but only a successful Connected=false GET can schedule recovery.
 {Fake f;Client a(f);a.enable(true,true);cycle(a,0);cycle(a,1500);
  assert(a.status(2000).stowedCandidate(2000)&&f.connects==0);
  f.error=Error::Timeout;a.step(3000);assert(!a.status(3000).valid&&f.connects==0);
  f.error=Error::None;f.connected=false;a.step(6000);assert(f.connects==0&&!a.optionalWindow(6000,750));
  a.step(6100);assert(f.connects==1&&!a.status(6100).stowedCandidate(6100));
  f.connected=true;cycle(a,6200);assert(a.status(6700).valid&&!a.status(6700).stowedCandidate(6700));
  cycle(a,7700);assert(a.status(8200).stowedCandidate(8200));
  cycle(a,9200);assert(f.connects==1); // No periodic writes to a healthy session.
  // A second restart while the reconnect cooldown is active cannot flood PUTs.
  f.connected=false;a.step(10700);a.step(13700);assert(f.connects==1);
  a.step(16700);a.step(16800);assert(f.connects==2&&!a.status(16800).valid);
 }
 // Every unsuccessful GET class (even with a false value) remains in read retry.
 for(auto error:{Error::Offline,Error::Timeout,Error::Http,Error::Oversized,Error::Protocol,Error::Unsupported,Error::Driver}){
  Fake f;f.connected=false;f.error=error;Client a(f);a.enable(true,true);
  for(uint32_t now=0;now<20000;now+=100)a.step(now);
  assert(f.connects==0&&!a.status(20000).valid);
 }
 // Connection scheduling/backoff works across millis wraparound.
 {Fake f;f.connected=false;Client a(f);a.enable(true,true);a.step(0xffffffd0U);a.step(52);assert(f.connects==1);
  a.step(152);a.step(3152);assert(f.connects==1);}
 // Failure metadata identifies the exact request and survives until a good sweep.
 {Fake f;Client a(f);a.enable(true);a.step(0);a.step(100);f.error=Error::Timeout;f.elapsed=1200;a.step(200);
  auto s=a.status(1400);assert(!strcmp(s.failure.request,"athome")&&s.failure.transaction==3&&s.failure.elapsedMs==1200&&s.failure.at==1400);
  f.error=Error::None;f.elapsed=0;cycle(a,4400);assert(a.status(4900).valid&&!strcmp(a.status(4900).failure.request,"none"));
  assert(!strcmp(a.status(9401).failure.request,"status_age"));}
 {Fake f;f.elapsed=500;Client a(f);a.enable(true);cycle(a,0,600);auto s=a.status(3500);
  assert(!s.valid&&!strcmp(s.failure.request,"status_sweep")&&s.failure.elapsedMs==3500);}
 // Optional requests fit only in the idle gap, never within a sweep or recovery.
 {Fake f;Client a(f);a.enable(true);assert(!a.optionalWindow(0,750));cycle(a,0);
  assert(a.optionalWindow(500,750));assert(!a.optionalWindow(751,750));
  a.step(1500);assert(!a.optionalWindow(1500,750));
  f.error=Error::Timeout;a.step(1600);assert(!a.optionalWindow(1600,750));}
 // One quick read-only retry, then bounded backoff; a full sweep resets it.
 {Fake f;f.error=Error::Timeout;Client a(f);a.enable(true);a.step(0);
  a.step(299);assert(f.requests==1);a.step(300);assert(f.requests==2);
  a.step(1299);assert(f.requests==2);a.step(1300);assert(f.requests==3);
  a.step(4299);assert(f.requests==3);f.error=Error::None;cycle(a,4300);
  assert(a.status(4800).valid&&!a.status(4800).stowedCandidate(4800));
  cycle(a,5800);assert(a.status(6300).stowedCandidate(6300));
  f.error=Error::Timeout;a.step(7300);auto n=f.requests;a.step(7600);assert(f.requests==n+1);assert(f.connects==0);}
 {Fake f;Client a(f);a.enable(true);cycle(a,0xfffffe00U);assert(a.optionalWindow(0xfffffff4U,750));assert(!a.optionalWindow(300,750));}
 puts("Alpaca polling: disabled, freshness, repetition, contradiction, disconnect, backoff, latency and wraparound passed");
}
