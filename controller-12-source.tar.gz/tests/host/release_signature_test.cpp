#include "release_signature.h"
#include "ota_protocol.h"
#include "release_signature_vector.h"
#include <openssl/evp.h>
#include <openssl/ecdsa.h>
#include <openssl/x509.h>
#include <cassert>
#include <cstdio>
#include <vector>
// Independent host backend; the target mbedTLS backend is separately compiled
// by PlatformIO. This test does not claim execution on ESP32 hardware.
namespace cover {
unsigned signatureChecks=0;
bool verifyReleaseP256(const uint8_t* payload,size_t n,const uint8_t* signature,const uint8_t* point){
 ++signatureChecks;
 const uint8_t prefix[]={0x30,0x59,0x30,0x13,0x06,0x07,0x2a,0x86,0x48,0xce,0x3d,0x02,0x01,
  0x06,0x08,0x2a,0x86,0x48,0xce,0x3d,0x03,0x01,0x07,0x03,0x42,0x00};
 std::vector<uint8_t> der(prefix,prefix+sizeof(prefix));der.insert(der.end(),point,point+65);
 const unsigned char* cursor=der.data();EVP_PKEY* key=d2i_PUBKEY(nullptr,&cursor,der.size());
 if(!key)return false;
 ECDSA_SIG* sig=ECDSA_SIG_new();assert(sig);
 BIGNUM* r=BN_bin2bn(signature,32,nullptr);BIGNUM* s=BN_bin2bn(signature+32,32,nullptr);
 assert(r && s && ECDSA_SIG_set0(sig,r,s)==1);
 const int bytes=i2d_ECDSA_SIG(sig,nullptr);assert(bytes>0);std::vector<uint8_t> encoded(bytes);
 unsigned char* out=encoded.data();assert(i2d_ECDSA_SIG(sig,&out)==bytes);
 EVP_MD_CTX* context=EVP_MD_CTX_new();assert(context);
 const bool valid=EVP_DigestVerifyInit(context,nullptr,EVP_sha256(),nullptr,key)==1 &&
  EVP_DigestVerify(context,encoded.data(),encoded.size(),payload,n)==1;
 EVP_MD_CTX_free(context);ECDSA_SIG_free(sig);EVP_PKEY_free(key);return valid;
}
}
using namespace cover;
int main(){
 for(bool pending:{false,true})for(bool handoff:{false,true})for(bool readable:{false,true})
  assert(otaStartupRequiresInspection(pending,handoff,readable)==(pending||handoff||!readable));
 ReleasePublicKey keys[2];keys[0].id="test-only";memcpy(keys[0].point,publicPoint,sizeof(publicPoint));
 const auto verify=[&](const uint8_t* p,size_t n,const uint8_t* sig,size_t sigSize,const char* id,size_t idSize,size_t count=1){
  return verifyReleaseSignature(p,n,sig,sigSize,id,idSize,keys,count);
 };
 assert(verify(payload,sizeof(payload),signature,sizeof(signature),"test-only",9)==ReleaseSignatureResult::Verified);
 auto changed=std::vector<uint8_t>(payload,payload+sizeof(payload));changed.back()^=1;
 assert(verify(changed.data(),changed.size(),signature,64,"test-only",9)==ReleaseSignatureResult::BadSignature);
 uint8_t corrupt[64];memcpy(corrupt,signature,64);corrupt[0]^=1;
 assert(verify(payload,sizeof(payload),corrupt,64,"test-only",9)==ReleaseSignatureResult::BadSignature);
 const unsigned checks=signatureChecks;
 for(size_t size:{size_t(0),size_t(4097)})assert(verify(payload,size,signature,64,"test-only",9)==ReleaseSignatureResult::InvalidInput);
 for(size_t size:{size_t(0),size_t(63),size_t(65)})assert(verify(payload,sizeof(payload),signature,size,"test-only",9)==ReleaseSignatureResult::InvalidInput);
 assert(verify(nullptr,1,signature,64,"test-only",9)==ReleaseSignatureResult::InvalidInput);
 assert(verify(payload,sizeof(payload),nullptr,64,"test-only",9)==ReleaseSignatureResult::InvalidInput);
 assert(verify(payload,sizeof(payload),signature,64,"test-only\n",10)==ReleaseSignatureResult::InvalidInput);
 assert(verify(payload,sizeof(payload),signature,64,"other",5)==ReleaseSignatureResult::UnknownKey);
 assert(verify(payload,sizeof(payload),signature,64,"test-only",9,0)==ReleaseSignatureResult::UnknownKey);
 keys[0].revoked=true;assert(verify(payload,sizeof(payload),signature,64,"test-only",9)==ReleaseSignatureResult::RevokedKey);keys[0].revoked=false;
 keys[1]=keys[0];assert(verify(payload,sizeof(payload),signature,64,"test-only",9,2)==ReleaseSignatureResult::InvalidTrust);
 keys[1].id="another-id";assert(verify(payload,sizeof(payload),signature,64,"test-only",9,2)==ReleaseSignatureResult::InvalidTrust);
 keys[0].point[0]=0;assert(verify(payload,sizeof(payload),signature,64,"test-only",9)==ReleaseSignatureResult::InvalidTrust);
 assert(signatureChecks==checks); // Rejected input never invokes crypto.
 puts("Cross-language release signature, bounded trust and rejection tests passed");
}
