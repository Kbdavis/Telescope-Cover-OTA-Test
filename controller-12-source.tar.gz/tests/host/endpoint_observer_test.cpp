#include "endpoint_observer.h"
#include <assert.h>
#include <stdio.h>
using namespace cover;
int main(){
 EndpointObserver o;EndpointChange e;
 assert(!o.observe(State::Open,true,1000,e));
 assert(!o.observe(State::Open,true,1000,e));
 assert(!o.observe(State::Open,false,0,e));
 assert(!o.observe(State::Open,true,5000,e));
 assert(o.observe(State::Open,true,1002,e));assert(e.previous==1000 && e.position==1002);
 assert(o.observe(State::Open,true,1000,e)); // Return motion remains visible.
 assert(!o.observe(State::Closing,true,800,e));
 assert(!o.observe(State::Closed,true,500,e)); // A new endpoint establishes a new baseline.
 assert(o.observe(State::Closed,true,499,e));assert(e.state==State::Closed && e.previous==500);
 assert(!o.observe(State::Fault,false,0,e));assert(!o.observe(State::Closed,true,501,e));
 puts("Endpoint observer: changes, failed reads, range rejection and state resets passed");
}
