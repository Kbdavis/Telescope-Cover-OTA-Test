#include "metrics_session.h"
#include <cassert>
#include <cstdio>
using namespace cover;
struct Backend {
 unsigned starts=0,stops=0,samples=0,clears=0;
 bool startOk=true,stopOk=true,quiet=true;
 bool start(){++starts;return startOk;}
 bool stop(){++stops;return stopOk;}
 bool quiescent(){return quiet;}
 void clear(){++clears;}
 void sample(uint32_t){++samples;}
};
int main(){
 MetricsLeases leases;
 assert(leases.viewers()==0);
 assert(!leases.renew(100,1,1));
 assert(leases.subscribe(100,1,1,100));
 assert(leases.subscribe(100,2,1,100));
 assert(leases.viewers()==2);
 assert(leases.unsubscribe(200,1,1));assert(leases.viewers()==1);
 assert(!leases.subscribe(201,1,1,200)); // Closed generation cannot restart.
 assert(leases.subscribe(202,1,2,200));
 assert(leases.unsubscribe(203,1,1));assert(leases.viewers()==2);
 assert(!leases.renew(204,1,1));
 assert(leases.unsubscribe(205,3,1)); // Close overtakes a pending start.
 assert(!leases.subscribe(206,3,1,200));
 assert(leases.subscribe(207,4,1,200));
 assert(!leases.subscribe(208,5,1,200)); // Four fixed slots including tombstones.
 leases.expire(5300);assert(leases.viewers()==0);
 assert(!leases.renew(5301,1,2));
 assert(!leases.subscribe(5301,1,2,5300)); // Expiry cannot be renewed via retry.
 assert(leases.subscribe(5302,1,3,5300));
 assert(!leases.subscribe(5302,2,2,100)); // Old controller time rejected.
 leases.expire(11000);
 assert(leases.subscribe(16000,5,1,16000)); // Slots can eventually be reused.
 assert(!leases.subscribe(16001,3,1,200)); // Ancient start after tombstone reuse.
 MetricsLeases wrap;
 assert(wrap.subscribe(UINT32_MAX-100,1,1,UINT32_MAX-100));
 wrap.expire(4800);assert(wrap.viewers()==1);
 wrap.expire(4900);assert(wrap.viewers()==0);
 MetricsCollector collector;Backend backend;
 for(unsigned i=0;i<100;++i)collector.poll(false,i,backend);
 assert(collector.phase()==MetricsPhase::Off);
 assert(!backend.starts && !backend.stops && !backend.samples && !backend.clears);
 collector.poll(true,100,backend);assert(collector.phase()==MetricsPhase::Active);
 assert(backend.starts==1 && backend.samples==1);
 collector.poll(true,200,backend);assert(backend.starts==1 && backend.samples==2);
 backend.stopOk=false;collector.poll(false,300,backend);
 assert(collector.phase()==MetricsPhase::Stopping && !backend.clears);
 backend.stopOk=true;backend.quiet=false;collector.poll(false,400,backend);
 assert(collector.phase()==MetricsPhase::Stopping && !backend.clears);
 backend.quiet=true;collector.poll(false,500,backend);
 assert(collector.phase()==MetricsPhase::Off && backend.clears==1);
 collector.poll(false,600,backend);assert(backend.samples==2 && backend.clears==1);
 collector.poll(true,700,backend);assert(backend.starts==2);
 collector.poll(false,800,backend);assert(backend.clears==2);
 backend.startOk=false;collector.poll(true,900,backend);
 assert(collector.phase()==MetricsPhase::Unavailable && backend.clears==3);
 collector.poll(true,1000,backend);assert(backend.starts==3); // No retry loop.
 collector.poll(false,1100,backend);assert(collector.phase()==MetricsPhase::Off);
 backend.startOk=true;collector.poll(true,1200,backend);assert(backend.starts==4);
 std::puts("Metrics leases and collector: OFF, multiple viewers, races, expiry, wrap and cleanup passed");
}
