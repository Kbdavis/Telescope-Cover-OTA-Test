#define COVER_WEB_CONTROL
#define COVER_OTA_FLASH_PROBE
#define COVER_OTA_MEMORY_PROBE
#include "../../src/ota_memory_probe.cpp"
#include <cassert>
#include <cstdio>
namespace cover {
uint32_t testEpoch=0;unsigned readers=0;bool acquire=true;
uint32_t diagnosticsMetricsEpoch(){return testEpoch;}
bool beginDiagnosticsWork(uint32_t epoch){if(!acquire || !epoch || epoch!=testEpoch)return false;++readers;return true;}
void endDiagnosticsWork(){assert(readers);--readers;}
}
using namespace cover;
int main(){
 OtaMemoryEvidence out;
 otaMemoryBoundary(OtaMemoryStage::StatusStart);assert(heapCalls==0 && readers==0);
 testEpoch=1;acquire=false;otaMemoryBoundary(OtaMemoryStage::StatusStart);assert(heapCalls==0 && readers==0);
 acquire=true;otaMemoryBoundary(OtaMemoryStage::StatusBuilt,3000);
 assert(heapCalls==1 && readers==0 && otaMemorySnapshot(out) && out.epoch==1);
 const auto status=static_cast<unsigned>(OtaMemoryStage::StatusBuilt);
 assert(out.rows[0][status].maximumBytes==3000);
 otaMemoryTransfer(true);otaMemoryBoundary(OtaMemoryStage::WriteBefore,1024);
 assert(heapCalls==2 && readers==0 && !otaMemorySnapshot(out));
 otaMemoryTransfer(false);assert(otaMemorySnapshot(out));
 assert(out.rows[1][static_cast<unsigned>(OtaMemoryStage::WriteBefore)].count==1);
 otaMemoryFinish();otaMemoryBoundary(OtaMemoryStage::StatusSent,4000);
 assert(heapCalls==2 && readers==0 && otaMemorySnapshot(out));
 assert(out.rows[0][static_cast<unsigned>(OtaMemoryStage::StatusSent)].count==0);
 testEpoch=0;otaMemoryBoundary(OtaMemoryStage::StatusSent);assert(heapCalls==2 && readers==0);
 assert(otaMemorySnapshot(out) && out.epoch==1); // Frozen evidence survives OFF.
 testEpoch=2;otaMemoryBoundary(OtaMemoryStage::StatusStart);
 assert(heapCalls==3 && otaMemorySnapshot(out) && out.epoch==2 && out.rows[0][status].count==0);
 puts("Actual OTA memory recorder: OFF/denied/frozen means no scans, RAII cleanup, report rejection and epoch isolation passed");
}
