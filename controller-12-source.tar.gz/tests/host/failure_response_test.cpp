#include "failure_response.h"
#include <cassert>
#include <cstdio>
using namespace cover;
int main(){
 FailureSummaryRecord r{};r.version=1;r.boots=2;
 char data[kFailureResponseBytes+2];data[kFailureResponseBytes+1]='X';
 auto n=writeFailureSummary(data,r,"boot","SOFTWARE");assert(n && strstr(data,"\"wifi\":null") && strstr(data,"\"fault\":null"));
 r.wifi.present=1;r.wifi.active=1;r.wifi.rssi=-80;r.wifi.retries=3;r.wifi.retryResult=-1;
 strcpy(r.wifi.context.boot,"previous");memset(r.wifi.context.firmware,'f',64);
 r.fault.present=1;r.fault.position=UINT32_MAX;r.fault.target=1234;
 memset(r.fault.message,1,79);r.fault.message[0]='"';r.fault.message[1]='\\';
 memset(r.fault.context.firmware,'a',64);memset(r.fault.context.boot,'b',32);
 memset(r.wifi.localAction,1,31);
 n=writeFailureSummary(data,r,"boot","PANIC");assert(n && n<=kFailureResponseBytes);
 assert(strstr(data,"\"same_boot\":false") && strstr(data,"\"outage_ms\":null"));
 assert(strstr(data,"\"position\":null") && strstr(data,"\\u0001") && strstr(data,"\"retry_result\":-1"));
 assert(data[kFailureResponseBytes+1]=='X');
 puts("Retained JSON: empty, previous boot, signed result, unknown position, escaping and bounded worst-case message passed");
}
