#pragma once
#include <chrono>
#include <thread>
inline void vTaskDelay(unsigned ms){std::this_thread::sleep_for(std::chrono::milliseconds(ms));}
inline void vTaskDelete(void*){}
inline int xTaskCreatePinnedToCore(void (*)(void*),const char*,unsigned,void*,unsigned,void*,unsigned){return 0;}
