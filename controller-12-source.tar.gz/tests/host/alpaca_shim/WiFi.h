#pragma once
// Host-only POSIX adapter: exercises the real firmware HTTP/parser code.
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <chrono>
#include <thread>
inline unsigned long millis(){static auto start=std::chrono::steady_clock::now();return uint32_t(std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now()-start).count());}
struct IPAddress {in_addr addr{};bool fromString(const char* s){return inet_pton(AF_INET,s,&addr)==1;}};
constexpr int WL_CONNECTED=3;
struct HostWiFi {int state=WL_CONNECTED;int status(){return state;}};
inline HostWiFi WiFi;
class WiFiClient {
 int socket_=-1;
 public:
 ~WiFiClient(){stop();}
 void setTimeout(unsigned){}
 bool connect(IPAddress ip,uint16_t port,int timeout){
  socket_=::socket(AF_INET,SOCK_STREAM,0);if(socket_<0)return false;
  fcntl(socket_,F_SETFL,O_NONBLOCK);
  sockaddr_in address{};address.sin_family=AF_INET;address.sin_addr=ip.addr;address.sin_port=htons(port);
  int r=::connect(socket_,reinterpret_cast<sockaddr*>(&address),sizeof(address));
  if(r==0)return true;if(errno!=EINPROGRESS){stop();return false;}
  fd_set set;FD_ZERO(&set);FD_SET(socket_,&set);timeval t{timeout/1000,(timeout%1000)*1000};
  r=select(socket_+1,nullptr,&set,nullptr,&t);int error=0;socklen_t length=sizeof(error);
  if(r>0 && getsockopt(socket_,SOL_SOCKET,SO_ERROR,&error,&length)==0 && !error)return true;
  stop();return false;
 }
 int fd(){return socket_;}
 int available(){int n=0;if(socket_>=0)ioctl(socket_,FIONREAD,&n);return n;}
 int read(){unsigned char c;return recv(socket_,&c,1,MSG_DONTWAIT)==1?c:-1;}
 bool connected(){char c;int n=recv(socket_,&c,1,MSG_PEEK|MSG_DONTWAIT);return n>0 || (n<0 && (errno==EAGAIN || errno==EWOULDBLOCK));}
 void stop(){if(socket_>=0){close(socket_);socket_=-1;}}
};
