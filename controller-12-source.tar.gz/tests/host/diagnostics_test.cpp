#define COVER_WEB_CONTROL
#include "../../src/diagnostics.cpp"
#include "debug_response.h"
#include <cassert>
namespace cover { uint32_t testEpoch=0; uint32_t logEpochSeconds(){return testEpoch;} }
using namespace cover;
int main(){
 testEpoch=0;
 beginDiagnostics();assert(debugLogAvailable());
 assert(!diagnosticsStartupHealthy(fakeNow));
 loggerAt.store(fakeNow);motionAt.store(fakeNow);assert(diagnosticsStartupHealthy(fakeNow));
 assert(!diagnosticsStartupHealthy(fakeNow+1501));loggerAt.store(0);motionAt.store(0);
 auto window=debugLogWindow();assert(window.newest==1); // BOOT shared once; BUILD is serial-only.
 DebugEntry entry;assert(nextDebugEntry(0,entry));assert(entry.epoch==0);assert(strstr(entry.message,"BOOT reset=POWERON elf_sha256="));
 assert(!entry.truncated);assert(fakeQueue.entries.size()==2);
 Entry serial;memcpy(&serial,fakeQueue.entries[0].data(),sizeof(serial));
 assert(strstr(serial.message,entry.message));
 const auto sequence=window.newest;
 debugLog("EVENT one");diagnosticEvent(DebugLevel::Warn,"FAULT one");
 window=debugLogWindow();assert(window.newest==sequence+2);assert(fakeQueue.entries.size()==4);
 diagnosticLog("TRACE only");assert(debugLogWindow().newest==window.newest);
 char large[400];memset(large,'x',sizeof(large)-1);large[399]=0;
 debugLog("%s",large);assert(nextDebugEntry(window.newest,entry));
 assert(entry.truncated && strlen(entry.message)==111 && strcmp(entry.message+108,"...")==0);
 assert(debugLogWindow().truncated==1);
 for(unsigned i=0;i<kDebugCapacity+5;++i)diagnosticEvent("EVENT %u",i);
 window=debugLogWindow();assert(window.newest-window.oldest==kDebugCapacity-1 && window.overwrites>0 && window.serialDropped>0);
 assert(fakeQueue.entries.size()==24); // Full serial queue never blocks or loses the RAM event.
 auto* ring=debugEntries;debugEntries=nullptr;fakeQueue.entries.clear();
 diagnosticEvent("FALLBACK serial");assert(fakeQueue.entries.size()==1 && !debugLogWindow().available);
 debugEntries=ring;
 DebugBuffer rollover(UINT32_MAX-1);debugEntries=&rollover;
 diagnosticEvent("ROLLOVER last");const auto oldWindow=debugLogWindow();
 diagnosticEvent("ROLLOVER first");
 assert(!nextDebugEntryInWindow(0,oldWindow.sequenceEpoch,entry));
 assert(nextDebugEntryInWindow(0,oldWindow.sequenceEpoch+1,entry) && entry.sequence==1);
 debugEntries=ring;
 // Exercise the actual diagnostics implementation, with counted platform calls.
 assert(!diagnosticsMetricsEpoch());
 for(unsigned i=0;i<100;++i){pollMetrics();runtimeDiagnostics();noteTaskStack(DiagnosticTask::Web);noteTaskStack(DiagnosticTask::Ota);}
 assert(!heapCalls && !stackCalls && !timerStarts);
 assert(requestMetrics(MetricsRequest::Subscribe,1,1,fakeNow));pollMetrics();
 assert(timerRunning && heapCalls==1);
 noteTaskStack(DiagnosticTask::Web);assert(stackCalls==1);
 assert(diagnosticsMetricsEpoch());noteTaskStack(DiagnosticTask::Ota);assert(stackCalls==2);
 assert(strcmp(diagnosticTaskName(DiagnosticTask::Ota),"ota")==0);
 const uint32_t workEpoch=diagnosticsMetricsEpoch();
 assert(!beginDiagnosticsWork(workEpoch+1));assert(!beginDiagnosticsWork(0));
 assert(requestMetrics(MetricsRequest::Subscribe,2,1,fakeNow));
 assert(requestMetrics(MetricsRequest::Unsubscribe,1,1));pollMetrics();assert(timerRunning);
 assert(requestMetrics(MetricsRequest::Unsubscribe,2,1));stopFails=true;pollMetrics();
 assert(runtimeDiagnostics().phase==MetricsPhase::Stopping);
 assert(beginDiagnosticsWork(workEpoch)==false); // Last unsubscribe revoked the epoch.
 stopFails=false;pollMetrics();assert(!timerRunning && runtimeDiagnostics().phase==MetricsPhase::Off);
 const unsigned heaps=heapCalls,stacks=stackCalls,starts=timerStarts;
 assert(!diagnosticsMetricsEpoch());
 for(unsigned i=0;i<100;++i){pollMetrics();runtimeDiagnostics();noteTaskStack(DiagnosticTask::Web);noteTaskStack(DiagnosticTask::Ota);}
 assert(heaps==heapCalls && stacks==stackCalls && starts==timerStarts);
 assert(requestMetrics(MetricsRequest::Subscribe,3,1,fakeNow));pollMetrics();
 {
  DiagnosticsWork inFlight(diagnosticsMetricsEpoch());assert(inFlight);
  assert(requestMetrics(MetricsRequest::Unsubscribe,3,1));pollMetrics();
  assert(runtimeDiagnostics().phase==MetricsPhase::Stopping && !diagnosticsMetricsEpoch());
 }
 pollMetrics();assert(runtimeDiagnostics().phase==MetricsPhase::Off);
 // A renewal after expiry cannot revive the old baseline, even before owner polling.
 assert(requestMetrics(MetricsRequest::Subscribe,1,2,fakeNow));pollMetrics();
 const uint32_t oldEpoch=metricsEpoch.load();fakeNow+=5000;
 assert(requestMetrics(MetricsRequest::Subscribe,1,3,fakeNow));assert(!metricsEpoch.load());
 pollMetrics();pollMetrics();assert(metricsEpoch.load()!=oldEpoch);
 assert(requestMetrics(MetricsRequest::Unsubscribe,1,3));pollMetrics();assert(!timerRunning);
 const unsigned retainedHeaps=heapCalls,retainedStacks=stackCalls,retainedStarts=timerStarts;
 const unsigned firstFailureHeaps=failureHeapCalls;
 noteRetainedFault("Servo timeout",500,1500);
 auto retained=retainedFailureSummary();assert(retained.fault.present && retained.fault.position==500);
 assert(retained.fault.context.freeHeap==100000 && !diagnosticsMetricsEpoch());
 assert(retained.fault.context.largestBlock==80000 && retained.fault.context.largestAvailable);
 assert(failureHeapCalls==firstFailureHeaps+1);
 noteFailureRetry(12295,40000);retained=retainedFailureSummary();
 assert(retained.wifi.present && retained.wifi.retries==1 && retained.fault.present);
 const unsigned afterFirstRetry=failureHeapCalls;
 noteFailureRetry(12295,80000);assert(failureHeapCalls==afterFirstRetry);
 assert(retainedHeaps==heapCalls && retainedStacks==stackCalls && retainedStarts==timerStarts);
 WiFiEventInfo_t info{};fakeNow=20000;
 WiFi.eventCallback(ARDUINO_EVENT_WIFI_STA_GOT_IP,info);
 diagnosticWiFiAction("controller-reboot");
 const auto beforePlanned=retainedFailureSummary().sequence;
 info.wifi_sta_disconnected.reason=8;
 WiFi.eventCallback(ARDUINO_EVENT_WIFI_STA_DISCONNECTED,info);
 assert(retainedFailureSummary().sequence==beforePlanned); // Planned restart cannot replace evidence.
 fakeNow+=6000;
 WiFi.eventCallback(ARDUINO_EVENT_WIFI_STA_GOT_IP,info);
 WiFi.eventCallback(ARDUINO_EVENT_WIFI_STA_DISCONNECTED,info);
 retained=retainedFailureSummary();assert(retained.wifi.firstReason==8 && retained.wifi.active);
 const auto firstAt=retained.wifi.context.at;
 const unsigned afterFirstDisconnect=failureHeapCalls;
 fakeNow+=1000;info.wifi_sta_disconnected.reason=2;
 WiFi.eventCallback(ARDUINO_EVENT_WIFI_STA_DISCONNECTED,info);
 assert(retainedFailureSummary().wifi.context.at==firstAt && retainedFailureSummary().wifi.lastReason==2);
 assert(failureHeapCalls==afterFirstDisconnect); // No heap scan for each repeated notification.
 fakeNow+=1000;WiFi.eventCallback(ARDUINO_EVENT_WIFI_STA_GOT_IP,info);
 assert(!retainedFailureSummary().wifi.active && retainedFailureSummary().wifi.outageMs==2000);
 assert(retainedHeaps==heapCalls && retainedStacks==stackCalls && retainedStarts==timerStarts);
 std::puts("Shared publisher and retained evidence: bounded sinks, truncation, fault/retry capture and actual OFF collection gates passed");
 testEpoch=1767225600;diagnosticEvent("Timestamp capture");
 auto latest=debugLogWindow();assert(nextDebugEntry(latest.newest-1,entry));
 testEpoch=1767229200;assert(entry.epoch==1767225600); // Event time, not drain time.
}
