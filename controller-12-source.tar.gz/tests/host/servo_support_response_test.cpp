#include "servo_support_response.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
using namespace cover;
unsigned long millis(){return 0;}
void yield(){}
int main(){
 assert(!strcmp(dispositionName(PositionDisposition::TargetOvershoot),"target_overshoot"));
 ServoSupportSnapshot s;char response[kServoSupportResponseBytes+2];response[kServoSupportResponseBytes+1]='!';
 assert(writeServoSupport(response,s,"boot","firmware"));
 assert(strstr(response,"\"fault\":null"));assert(strstr(response,"\"model\":null"));
 assert(strstr(response,"\"position\":null"));puts(response);
 assert(strstr(response,"\"goal_readback\":null"));
 s.available=true;s.sampledAt=UINT32_MAX;s.faultRevision=1;s.fault.traceAvailable=true;s.fault.at=UINT32_MAX;
 s.fault.stateBefore=State::Closing;s.fault.positionKnown=true;s.fault.acceptedPosition=2048;
 memset(s.fault.reason,1,sizeof(s.fault.reason)-1);
 auto& d=s.current;d.exchanges=d.failedExchanges=d.failedReads=d.retries=d.rejectedPositions=UINT32_MAX;
 d.hasSuccess=d.hasFailure=d.positionValid=d.torqueValid=d.telemetryValid=d.modelValid=true;
 d.lastSuccessAt=d.lastFailureAt=d.positionAt=d.torqueAt=d.telemetryAt=UINT32_MAX-10;
 d.position=4095;d.model=777;d.lastFailure={ServoError::DeviceError,255};d.failureInstruction=2;d.failureAddress=56;
 d.telemetry.relativeLoad=-1023;d.telemetry.currentRaw=-32767;
 d.telemetry.targetPositionRaw=2503;d.goalValid=true;d.goalAt=UINT32_MAX-10;
 d.goal.positionRaw=2503;d.goal.register44Raw=0;d.goal.speedRaw=100;d.goal.acceleration=10;d.goal.torqueLimitRaw=1000;
 d.configurationRead=d.validationAttempted=d.snapshotValid=d.lockValid=true;
 d.validationResult={ServoError::InvalidConfiguration};d.configuration.maximum=4095;d.lock=1;
 memset(d.snapshot,255,sizeof(d.snapshot));s.fault.servo=d;
 auto& t=s.frozenTrace;t.count=MotionTrace::capacity;t.next=17;t.startedAt=10;t.startPosition=2048;
 t.target=2837;t.speed=100;t.acceleration=10;t.timeoutMs=25000;t.validReads=99;t.failedReads=3;t.rejectedReads=2;
 for(unsigned i=0;i<MotionTrace::capacity;++i){auto& v=t.samples[i];v.elapsedMs=UINT32_MAX-i;v.position=4095;v.valid=i!=17;v.disposition=PositionDisposition::AwayFromTarget;}
 auto size=writeServoSupport(response,s,"boot","firmware");assert(size && size<=kServoSupportResponseBytes);
 assert(response[kServoSupportResponseBytes+1]=='!');assert(strstr(response,"\"position\":null"));
 assert(strstr(response,"\"relative_load\":-1023"));assert(strstr(response,"\"age_ms\":10"));puts(response);
 assert(strstr(response,"\"register_42_position_raw\":2503"));assert(strstr(response,"\"register_67_target_raw\":2503"));
 assert(strstr(response,"\"register_48_torque_limit_raw\":1000"));
 printf("\n");
 fprintf(stderr,"Servo support: bounded JSON, absent evidence, rejection semantics, signed telemetry; storage=%zu driver_cache=%zu fault=%zu trace=%zu controller=%zu\n",sizeof(s),sizeof(ServoDiagnostics),sizeof(MotionFaultEvidence),sizeof(MotionTrace),sizeof(CoverController));
}
