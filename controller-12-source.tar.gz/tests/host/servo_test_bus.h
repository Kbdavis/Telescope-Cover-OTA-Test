#pragma once
#include <deque>
#include <vector>
#include <assert.h>
class Bus : public Stream {
 public:
  uint8_t registers[80] = {};
  std::deque<uint8_t> input;
  std::vector<std::vector<uint8_t>> writes;
  int corruptReplies = 0;
  bool silent = false, positionOutlier = false;
#if defined(COVER_REFERENCE_PROBE) || defined(COVER_FIXED_REFERENCE)
  bool simulateReference=false,ignoreReference=false,reverseReference=false;
#endif
  int silentAddress = -1;
  uint8_t status = 0;
  Bus() {
    registers[5] = 1; registers[11] = 255; registers[12] = 15;
    registers[30] = 1; registers[40] = 1;
    registers[56] = 0; registers[57] = 8;
  }
  int available() override { return input.size(); }
  int read() override {
    if (input.empty()) return -1;
    int value = input.front(); input.pop_front(); return value;
  }
  size_t write(const uint8_t* p, size_t count) override {
    writes.emplace_back(p, p + count);
    uint8_t checksum = 0;
    for (size_t i = 2; i < count; ++i) checksum += p[i];
    assert(checksum == 255);
    if (silent) return count;
    if(p[4]==2 && p[5]==silentAddress)return count;
#if defined(COVER_REFERENCE_PROBE) || defined(COVER_FIXED_REFERENCE)
    if(simulateReference && p[4]==3 && p[5]==31 && !ignoreReference){
      const int old=registers[31]+256*registers[32],next=p[6]+256*p[7];
      const int current=registers[56]+256*registers[57];
      const int feedback=cover::wrapPosition(current+(reverseReference?1:-1)*(next-old));
      registers[31]=p[6];registers[32]=p[7];registers[56]=feedback&255;registers[57]=feedback>>8;
    }
#endif
    const uint8_t size = p[4] == 2 ? p[6] : 0;
    std::vector<uint8_t> response = {255,255,1,static_cast<uint8_t>(size + 2),status};
    for (unsigned i = 0; i < size; ++i) response.push_back(registers[p[5] + i]);
    if(p[4]==2 && p[5]==56 && size==2 && positionOutlier){response[5]=response[6]=0;positionOutlier=false;}
    checksum = 0;
    for (size_t i = 2; i < response.size(); ++i) checksum += response[i];
    response.push_back(static_cast<uint8_t>(~checksum));
    if (corruptReplies > 0) { --corruptReplies; response.back() ^= 1; }
    input.insert(input.end(), response.begin(), response.end());
    return count;
  }
};
