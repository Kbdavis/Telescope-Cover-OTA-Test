#include "ota_memory_probe.h"
#include <cassert>
#include <cstdio>
using namespace cover;
int main(){
 OtaMemoryEvidence e;
 assert(!e.record(0,0,OtaMemoryStage::StatusBuilt,false,100,80,1,20));
 assert(!e.record(1,2,OtaMemoryStage::StatusBuilt,false,100,80,1,20));
 assert(e.epoch==0);
 assert(e.record(1,1,OtaMemoryStage::StatusBuilt,false,100,80,1,20));
 assert(e.record(1,1,OtaMemoryStage::StatusBuilt,false,90,85,2,30));
 const auto i=static_cast<unsigned>(OtaMemoryStage::StatusBuilt);
 assert(e.rows[0][i].count==2 && e.rows[0][i].minimumFree==90 && e.rows[0][i].minimumBlock==80);
 assert(e.rows[0][i].at==2 && e.rows[0][i].maximumBytes==30);
 assert(e.record(1,1,OtaMemoryStage::StatusBuilt,true,70,60,3,10));
 assert(e.rows[1][i].count==1 && e.rows[0][i].count==2);
 e.rows[1][i].count=UINT32_MAX;
 assert(e.record(1,1,OtaMemoryStage::StatusBuilt,true,75,65,4,15));
 assert(e.rows[1][i].count==UINT32_MAX && e.rows[1][i].at==3);
 assert(e.record(2,2,OtaMemoryStage::BeginBefore,true,60,50,5,0));
 assert(e.epoch==2 && e.rows[0][i].count==0 && e.rows[1][i].count==0);
 assert(!e.record(1,2,OtaMemoryStage::WriteAfter,true,1,1,6,0));
 assert(e.epoch==2 && e.rows[1][static_cast<unsigned>(OtaMemoryStage::BeginBefore)].minimumFree==60);
 assert(!e.record(2,2,OtaMemoryStage::Count,false,1,1,1,1));
 assert(!e.record(2,0,OtaMemoryStage::WriteBefore,true,1,1,1,1));
 // Production entry points compile to no-ops without any runtime dependency.
 otaMemoryBoundary(OtaMemoryStage::StatusStart);otaMemoryTransfer(true);
 puts("OTA memory boundaries: OFF/stale epoch rejection, epoch reset, ownership split, minima and saturation passed");
}
