#include "seestar_power.h"
#include "telescope_arm.h"
#include <cJSON.h>
#include <cassert>
#include <cstring>
#include <string>
#include <cstdio>
using namespace cover;
std::string reply(const std::string& power,const std::string& model="Seestar S30 Pro",int code=0,int id=3){
 return "{\"id\":"+std::to_string(id)+",\"code\":"+std::to_string(code)+",\"result\":{\"device\":{\"product_model\":\""+model+"\"},\"pi_status\":"+power+"}}";
}
bool parse(const std::string& json,SeestarPower& out,uint32_t now=100){
 auto root=parseSeestarFrame(json.data(),json.size());bool ok=parseSeestarPower(root,3,now,out);cJSON_Delete(root);return ok;
}
int main(){
 SeestarPower out;
 const auto good=reply("{\"battery_capacity\":44,\"charger_status\":\"Discharging\",\"charge_online\":false,\"battery_temp\":23,\"battery_overtemp\":false}");
 assert(parse(good,out));assert(out.valid&&out.batteryPercent==44&&out.externalPowerValid&&!out.externalPower);
 assert(out.batteryTemperatureValid&&out.batteryTemperature==23&&out.batteryOvertempValid&&!out.batteryOvertemp);
 assert(strcmp(out.chargingState,"Discharging")==0&&out.fresh(60100)&&!out.fresh(60101));
 assert(parse(reply("{\"battery_capacity\":0,\"battery_temp\":0,\"charge_online\":true,\"charger_status\":\"Charging\",\"battery_overtemp\":true}"),out));
 assert(out.batteryPercent==0&&out.batteryTemperature==0&&out.externalPower&&out.batteryOvertemp);
 assert(parse(reply("{\"battery_capacity\":100}"),out));assert(out.batteryPercent==100&&!out.externalPowerValid&&!out.batteryTemperatureValid&&!out.chargingState[0]);
 assert(!parse(reply("{\"battery_capacity\":101,\"charge_online\":1,\"battery_temp\":\"23\",\"battery_overtemp\":0,\"charger_status\":\"bogus\"}"),out));
 assert(!parse(reply("{\"battery_capacity\":-1}"),out));assert(!parse(reply("{\"battery_capacity\":44.5}"),out));
 assert(!parse(reply("{\"battery_capacity\":44}","Other telescope"),out));
 assert(!parse(reply("{\"battery_capacity\":44}","Seestar S30 Pro",1),out));
 assert(!parse(reply("{\"battery_capacity\":44}","Seestar S30 Pro",0,4),out));
 assert(!parse("{}",out)&&!out.valid);
 assert(!parse(good+" trailing",out));assert(!parse(good.substr(0,good.size()-1),out));
 assert(!parse(reply("{\"battery_capacity\":44,\"battery_capacity\":99}"),out));
 assert(!parse(std::string("{\"a\":")+std::string(13,'[')+"0"+std::string(13,']')+"}",out));
 assert(!parse(std::string(8193,' '),out));
 auto embedded=good;embedded.insert(1,1,'\0');assert(!parse(embedded,out));
 assert(parse(good+"\r\n",out,0xfffffff0));assert(out.fresh(20));assert(!out.fresh(60000));
 // Authentication success is the envelope code, even when result contains an object.
 const char* auth="{\"id\":2,\"code\":0,\"result\":{\"key_envelope\":{}}}";
 auto root=parseSeestarFrame(auth,strlen(auth));assert(seestarReplyOk(root,2));assert(!seestarReplyOk(root,1));cJSON_Delete(root);
 // Losing the native connection preserves the original sample age, retries
 // promptly, and recovers without a reboot or any arm command.
 {
  PowerMonitor monitor;SeestarPower reading,missing;
  assert(monitor.due(0,false));assert(parse(good,reading,100));monitor.record(100,reading);
  assert(!monitor.due(30099,false)&&monitor.due(30100,false));
  monitor.record(30100,missing);
  assert(monitor.status().retrying&&monitor.status().sampledAt==100);
  assert(!monitor.due(35099,false)&&monitor.due(35100,false));
  monitor.record(35100,missing);monitor.record(60101,missing);
  assert(!monitor.status().fresh(60101)); // Failed retries never make old data fresh.
  assert(monitor.due(65101,false));assert(parse(good,reading,65101));monitor.record(65101,reading);
  assert(monitor.status().fresh(65101)&&!monitor.status().retrying);
  assert(!monitor.due(95100,false)&&monitor.due(95101,false));
 }
 // Regression: the inspection lock survives, but no longer starves battery
 // polling after active arm work ends. Resume immediately, even before 30 s.
 {
  PowerMonitor monitor;SeestarPower reading;assert(parse(good,reading));monitor.record(100,reading);
  ArmStatus arm;arm.phase=ArmPhase::Waiting;arm.locked=true;
  assert(!monitor.due(200,arm.active())&&monitor.status().paused);
  arm.phase=ArmPhase::Unknown;
  assert(monitor.due(300,arm.active())&&!monitor.status().paused&&arm.locked);
  assert(parse(good,reading,300));monitor.record(300,reading);
  assert(!monitor.due(30299,arm.active())&&monitor.due(30300,arm.active()));
  assert(arm.locked&&arm.phase==ArmPhase::Unknown);
 }
 {PowerMonitor monitor;SeestarPower missing;monitor.record(0xfffffff0U,missing);
  assert(!monitor.due(4983,false)&&monitor.due(4984,false));}
 puts("Seestar power: identity, reply IDs/errors, field validation, absent values, malformed frames and freshness passed");
 puts("Power monitoring: retry, recovery, expiry, active-arm pause, inspection-lock monitoring and wraparound passed");
}
