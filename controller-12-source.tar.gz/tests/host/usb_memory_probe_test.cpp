#define COVER_WEB_CONTROL
#define COVER_USB_MEMORY_PROBE
#include "../../src/usb_memory_probe.cpp"
#include <cassert>
#include <cstdio>
namespace cover {
const char* diagnosticTaskName(DiagnosticTask task){return task==DiagnosticTask::Web?"web":"other";}
}
using namespace cover;
int main(){
 beginUsbMemoryProbe();assert(fakeAllocationHook && hook && failures.enabled);
 fakeAllocationHook(2048,3,"heap_caps_malloc");assert(failures.count==1 && Serial.output.empty());
 noteUsbMemoryHttp("/api/status");noteUsbMemoryHttp("/api/other");
 noteUsbMemoryStack(DiagnosticTask::Web);assert(stackCalls==1);
 pollUsbMemoryProbe(2,0,0);assert(heapCalls==2);
 assert(Serial.output.find("hook=1 failures=1")!=std::string::npos);
 assert(Serial.output.find("http=2 status_http=1")!=std::string::npos);
 fakeNow+=999;pollUsbMemoryProbe(5,0,0);assert(heapCalls==2);
 ++fakeNow;pollUsbMemoryProbe(1,0,0);assert(heapCalls==4 && queuePeak==5);
 noteUsbMemoryStack(DiagnosticTask::Web);assert(stackCalls==1);
 fakeNow=started+5000;noteUsbMemoryStack(DiagnosticTask::Web);assert(stackCalls==2);
 fakeNow=started+kUsbWindowMs;noteUsbMemoryStack(DiagnosticTask::Web);noteUsbMemoryHttp("/api/status");
 assert(stackCalls==2 && requests==2);
 pollUsbMemoryProbe(0,0,0);assert(finished && !failures.enabled && heapCalls==4);
 const auto bytes=Serial.output.size();
 fakeAllocationHook(99,9,"heap_caps_malloc");pollUsbMemoryProbe(3,0,0);
 assert(failures.count==1 && Serial.output.size()==bytes && heapCalls==4);
 assert(Serial.output.find("USBMEM end duration_ms="+std::to_string(kUsbWindowMs)+" failures=1 hook=1 http=2 status_http=1")!=std::string::npos);
 puts("Actual USB recorder: hook without output, bounded cadence, HTTP/stack counts, queue observations and timed OFF passed");
}
