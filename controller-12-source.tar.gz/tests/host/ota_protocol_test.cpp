#include "ota_auth.h"
#include "ota_resource_probe.h"
#include "ota_flash_probe.h"
#include <openssl/evp.h>
#include <openssl/hmac.h>
#include <cassert>
#include <cstdio>
#include <string>
#include <vector>
namespace cover {
bool cryptoFail=false;
bool otaSha256(const void* p,size_t n,uint8_t out[32]){unsigned size=0;return !cryptoFail && EVP_Digest(p,n,out,&size,EVP_sha256(),nullptr)==1 && size==32;}
bool otaMd5(const void* p,size_t n,uint8_t out[16]){unsigned size=0;return !cryptoFail && EVP_Digest(p,n,out,&size,EVP_md5(),nullptr)==1 && size==16;}
bool otaHmac(const uint8_t* k,size_t ks,const void* p,size_t n,uint8_t out[32]){unsigned size=0;return !cryptoFail && HMAC(EVP_sha256(),k,ks,static_cast<const uint8_t*>(p),n,out,&size) && size==32;}
}
using namespace cover;
struct Backend {
 bool safe=true,cancel=false,intentOk=true,cutoverOk=true,selectionOk=true,stopAfterPersist=false;
 unsigned writes=0,selections=0;bool entered=false;
 bool clearance(){return safe;}bool cancelled(){return cancel;}
 bool persist(OtaRecord& r){assert(r.outcome==OtaOutcome::Intent);++writes;if(stopAfterPersist)safe=false;return intentOk;}
 bool enterCommit(){if(!safe||cancel||!cutoverOk)return false;entered=true;return true;}
 bool selectBoot(){assert(entered&&writes);++selections;return selectionOk;}
};
struct FlashBackend {
 const OtaManifest& manifest;bool safe=true,beginOk=true,writeOk=true,finishOk=true;
 unsigned begins=0,finishes=0;std::vector<uint8_t> bytes;
 explicit FlashBackend(const OtaManifest& m):manifest(m){}
 bool clearance(){return safe;}
 bool begin(){++begins;return beginOk;}
 bool write(const uint8_t* p,size_t n){if(!writeOk)return false;bytes.insert(bytes.end(),p,p+n);return true;}
 bool finish(){++finishes;uint8_t sha[32],md5[16];otaSha256(bytes.data(),bytes.size(),sha);otaMd5(bytes.data(),bytes.size(),md5);
  return finishOk && otaEqual(sha,manifest.sha256,32) && otaEqual(md5,manifest.md5,16);}
};
int main(){
 uint8_t blankProbe[kOtaPrefixBytes];memset(blankProbe,0xff,sizeof(blankProbe));
 assert(otaProbeTargetAllowed(0x10000,0x10000,0x150000,kOtaSlotBytes,kOtaSlotBytes,blankProbe,sizeof(blankProbe)));
 assert(!otaProbeTargetAllowed(0x10000,0x150000,0x150000,kOtaSlotBytes,kOtaSlotBytes,blankProbe,sizeof(blankProbe)));
 assert(!otaProbeTargetAllowed(0x150000,0x150000,0x10000,kOtaSlotBytes,kOtaSlotBytes,blankProbe,sizeof(blankProbe)));
 assert(!otaProbeTargetAllowed(0x10000,0x10000,0x10000,kOtaSlotBytes,kOtaSlotBytes,blankProbe,sizeof(blankProbe)));
 assert(!otaProbeTargetAllowed(0x10000,0x10000,0x150000,kOtaSlotBytes,kOtaSlotBytes-1,blankProbe,sizeof(blankProbe)));
 blankProbe[351]=0;assert(!otaProbeTargetAllowed(0x10000,0x10000,0x150000,kOtaSlotBytes,kOtaSlotBytes,blankProbe,sizeof(blankProbe)));
 bool attempted=false;assert(!reserveOtaProbe(true,false,attempted)&&!attempted);assert(!reserveOtaProbe(false,true,attempted)&&!attempted);
 assert(reserveOtaProbe(false,false,attempted)&&attempted);assert(!reserveOtaProbe(false,false,attempted));
 assert(otaProbeSelectionUnchanged(0x10000,0x10000));assert(!otaProbeSelectionUnchanged(0x10000,0x150000));
 OtaProbeSchedule schedule;
 assert(!schedule.due(0,0,true));assert(!schedule.due(0,1,false));
 assert(schedule.due(0,1,true));assert(!schedule.due(4999,1,true));assert(schedule.due(5000,1,true));
 assert(!schedule.due(10000,0,true));assert(!schedule.due(10000,2,false));assert(schedule.due(10000,2,true));
 OtaProbeSchedule wrap;assert(wrap.due(UINT32_MAX-100,1,true));assert(!wrap.due(4898,1,true));assert(wrap.due(4899,1,true));
 const auto probeManifest=otaProbeManifest();FlashBackend probeSink(probeManifest);OtaImageStream<FlashBackend> probe(probeManifest,probeSink);uint8_t probeBlock[1024];
 assert(!otaProbeBlock(0,probeBlock,351));assert(!otaProbeBlock(kOtaProbeBytes,probeBlock,1));
 for(uint32_t i=0;i<kOtaProbeBytes;i+=sizeof(probeBlock)){assert(otaProbeBlock(i,probeBlock,sizeof(probeBlock)));assert(probe.consume(probeBlock,sizeof(probeBlock)));}
 assert(probe.finish() && probeSink.bytes.size()==kOtaProbeBytes && probeSink.begins==1);
 for(size_t total:{size_t(400),size_t(1024),size_t(2500)}){
  size_t received=0,acknowledged=0;unsigned acks=0;
  while(received<total){const size_t end=otaAckEnd(acknowledged,total);
   received+=std::min(size_t(37),end-received);
   if(received==end){acknowledged=end;++acks;}
  }
  assert(acknowledged==total && acks==(total+1023)/1024);
 }
 assert(otaControlBodyValid(640,640,true));assert(!otaControlBodyValid(641,641,true));
 assert(!otaControlBodyValid(500,400,true));assert(!otaControlBodyValid(-1,0,true));assert(!otaControlBodyValid(10,10,false));
 assert(otaCrc(reinterpret_cast<const uint8_t*>("123456789"),9)==0xcbf43926);
 OtaStartupHealth health;health.settingsReadable=health.journalReadable=health.servicesReady=health.workersAlive=health.localRecovery=health.receiverReady=true;
 assert(otaStartupAction(3999,health)==OtaStartupAction::Wait);assert(otaStartupAction(4000,health)==OtaStartupAction::Accept);
 for(unsigned failure=0;failure<6;++failure){auto bad=health;
  switch(failure){case 0:bad.settingsReadable=false;break;case 1:bad.journalReadable=false;break;case 2:bad.servicesReady=false;break;
   case 3:bad.workersAlive=false;break;case 4:bad.localRecovery=false;break;case 5:bad.receiverReady=false;break;}
  assert(otaStartupAction(29999,bad)==OtaStartupAction::Wait);assert(otaStartupAction(30000,bad)==OtaStartupAction::Recover);
 }
 OtaInvitation invitation;const std::string invite="0 3232 1024 "+std::string(32,'1')+"\n";
 assert(parseOtaInvitation(invite.data(),invite.size(),invitation) && invitation.port==3232 && invitation.size==1024);
 for(const auto& bad:{std::string("1")+invite.substr(1),invite+"x",std::string("0 -1 1024 ")+std::string(32,'1')+"\n",std::string("0 65536 1024 ")+std::string(32,'1')+"\n",std::string("0 3232 42949672960 ")+std::string(32,'1')+"\n"})assert(!parseOtaInvitation(bad.data(),bad.size(),invitation));
 const std::string auth="200 "+std::string(32,'a')+" "+std::string(32,'b')+"\n";char cnonce[33];uint8_t authResponse[16];
 assert(parseOtaTransferAuth(auth.data(),auth.size(),cnonce,authResponse));assert(authResponse[0]==0xbb);
 assert(!parseOtaTransferAuth(auth.data(),auth.size()-1,cnonce,authResponse));
 const std::string body="product=telescope-cover\nprofile=web_control\nprotocol=1\nsettings=5\nhandoff=1\nsize=1024\nsha256="+std::string(64,'1')+
  "\nmd5="+std::string(32,'2')+"\nelf="+std::string(64,'3')+"\npolicy=closed-cover\ncontrol_generation=1\n";
 OtaManifest manifest;assert(parseOtaManifest(body.data(),body.size(),manifest));assert(manifest.size==1024 && manifest.sha256[0]==0x11);
 for(const auto& bad:{body+"size=1024\n",body+"x",std::string("\0",1)+body,body.substr(1),body.substr(0,body.size()-1)})assert(!parseOtaManifest(bad.data(),bad.size(),manifest));
 for(const auto& pair:{std::make_pair("size=1024","size=01024"),{"size=1024","size=1310721"},{"size=1024","size=42949672960"},
  {"size=1024","size=351"},{"protocol=1","protocol=2"},{"settings=5","settings=6"},{"handoff=1","handoff=0"},
  {"closed-cover","retain-torque"},{"closed-cover","supported-cover-off"},{"control_generation=1","control_generation=0"}}){
  std::string bad=body;bad.replace(bad.find(pair.first),strlen(pair.first),pair.second);assert(!parseOtaManifest(bad.data(),bad.size(),manifest));
 }
 std::string devBody=body;devBody.replace(devBody.find("closed-cover"),strlen("closed-cover"),"development-stationary");
 std::string recoveryBody=body;recoveryBody.replace(recoveryBody.find("closed-cover"),strlen("closed-cover"),"development-recovery");
#ifdef COVER_OTA_DEVELOPMENT
 assert(parseOtaManifest(devBody.data(),devBody.size(),manifest)&&manifest.developmentStationary);
 assert(parseOtaManifest(recoveryBody.data(),recoveryBody.size(),manifest)&&manifest.developmentRecovery&&!manifest.developmentStationary);
#else
 assert(!parseOtaManifest(devBody.data(),devBody.size(),manifest));
 assert(!parseOtaManifest(recoveryBody.data(),recoveryBody.size(),manifest));
#endif
 assert(parseOtaManifest(body.data(),body.size(),manifest)&&!manifest.developmentStationary&&!manifest.developmentRecovery);
 uint8_t prefix[kOtaPrefixBytes]={};prefix[0]=0xe9;prefix[1]=5;prefix[2]=2;prefix[3]=0x20;prefix[23]=1;otaPut32(prefix+28,320);otaPut32(prefix+32,0xabcd5432);memcpy(prefix+176,manifest.elf,32);
 memcpy(prefix+288,"TCOTA001",8);memcpy(prefix+296,"telescope-cover",15);memcpy(prefix+312,"web_control",11);prefix[328]=1;prefix[330]=5;prefix[332]=1;prefix[336]=1;
 assert(otaPrefixValid(prefix,sizeof(prefix),manifest));assert(!otaPrefixValid(prefix,sizeof(prefix)-1,manifest));
 for(unsigned offset:{0U,1U,2U,3U,12U,23U,32U,176U,288U,296U,312U,328U,330U,332U,336U}){
  uint8_t old=prefix[offset];prefix[offset]^=0x80;assert(!otaPrefixValid(prefix,sizeof(prefix),manifest));prefix[offset]=old;
 }
 std::vector<uint8_t> image(1024);memcpy(image.data(),prefix,sizeof(prefix));
 otaSha256(image.data(),image.size(),manifest.sha256);otaMd5(image.data(),image.size(),manifest.md5);
 for(size_t chunk:{size_t(1),size_t(31),size_t(351),size_t(352),size_t(1024)}){
  FlashBackend flash{manifest};OtaImageStream<FlashBackend> stream(manifest,flash);size_t at=0;
  while(at<image.size()){size_t n=std::min(chunk,image.size()-at);assert(stream.consume(image.data()+at,n));at+=n;
   if(at<kOtaPrefixBytes)assert(!flash.begins);}
  assert(stream.finish());assert(flash.begins==1 && flash.finishes==1 && flash.bytes==image);assert(!stream.finish());
 }
 for(unsigned failure=0;failure<7;++failure){
  FlashBackend flash{manifest};OtaImageStream<FlashBackend> stream(manifest,flash);
  switch(failure){case 0:flash.safe=false;break;case 1:flash.beginOk=false;break;case 2:flash.writeOk=false;break;case 3:flash.finishOk=false;break;default:break;}
  auto corrupted=image;if(failure==4)corrupted[288]^=1;if(failure==5)corrupted.back()^=1;
  if(failure==6){assert(stream.consume(image.data(),351));assert(!stream.finish());assert(!flash.begins);continue;}
  const bool consumed=stream.consume(corrupted.data(),corrupted.size());
  if(failure<=2 || failure==4)assert(!consumed);else assert(consumed&&!stream.finish());
  if(failure==0 || failure==4)assert(!flash.begins);
 }
 {FlashBackend flash{manifest};OtaImageStream<FlashBackend> stream(manifest,flash);
  assert(stream.consume(image.data(),352));flash.safe=false;assert(!stream.consume(image.data()+352,672));assert(!stream.finish());}
 OtaRecord record;record.transaction[0]=1;record.source[0]=2;record.target[0]=3;record.sourceSlot=0x10000;record.targetSlot=0x150000;record.size=1024;
 uint8_t bytes[kOtaRecordBytes];encodeOtaRecord(record,bytes);OtaRecord decoded;assert(decodeOtaRecord(bytes,sizeof(bytes),decoded));
 for(size_t n=0;n<sizeof(bytes);++n)assert(!decodeOtaRecord(bytes,n,decoded));
 for(unsigned i=0;i<sizeof(bytes);++i){bytes[i]^=1;assert(!decodeOtaRecord(bytes,sizeof(bytes),decoded));bytes[i]^=1;}
 assert(reconcileOtaRecord(record,record.targetSlot,record.target,false,false)==OtaOutcome::BootCheck);
 assert(reconcileOtaRecord(record,record.targetSlot,record.target,false,true)==OtaOutcome::Complete);
 assert(reconcileOtaRecord(record,record.sourceSlot,record.source,false,true)==OtaOutcome::Unconfirmed);
 // Old invalid-slot metadata survives an aborted transfer. It cannot prove
 // rollback until this transaction's selection/first boot was recorded.
 assert(reconcileOtaRecord(record,record.sourceSlot,record.source,true,true)==OtaOutcome::Unconfirmed);
 record.activationConfirmed=true;encodeOtaRecord(record,bytes);assert(decodeOtaRecord(bytes,sizeof(bytes),decoded)&&decoded.activationConfirmed);
 assert(reconcileOtaRecord(record,record.sourceSlot,record.source,true,true)==OtaOutcome::RolledBack);
 assert(otaNeedsReconciliation(OtaOutcome::Unconfirmed));assert(!otaNeedsReconciliation(OtaOutcome::Failed));assert(!otaNeedsReconciliation(OtaOutcome::Complete));
 uint8_t unknown[32]={};assert(reconcileOtaRecord(record,record.sourceSlot,unknown,true,true)==OtaOutcome::Unconfirmed);
 for(unsigned failure=0;failure<7;++failure){Backend b;
  switch(failure){case 0:b.safe=false;break;case 1:b.cancel=true;break;case 2:b.intentOk=false;break;case 3:b.cutoverOk=false;break;case 4:b.stopAfterPersist=true;break;case 5:b.selectionOk=false;break;default:break;}
  const bool success=commitOtaImage(b,record);assert(success==(failure==6));if(failure<5)assert(!b.selections);if(failure==5)assert(b.entered&&b.selections==1);
 }
 OtaChallenge challenge;const char* nonce="0123456789abcdef0123456789abcdef";
 assert(challenge.issue(1,100,nonce));assert(!challenge.issue(1,101,nonce));assert(!challenge.consume(2,102,nonce));
 assert(challenge.consume(1,103,nonce));assert(!challenge.consume(1,104,nonce));assert(challenge.issue(1,1100,nonce));assert(!challenge.consume(1,11101,nonce));
 assert(challenge.issue(1,UINT32_MAX-10,nonce));assert(challenge.consume(1,10,nonce));
 uint8_t mac[32],other[32];const char* fixture="0123456789abcdef0123456789abcdef";
 assert(otaControlMac(fixture,"POST","/api/ota/prepare","boot",nonce,"",body.data(),body.size(),mac));
 assert(otaControlMac(fixture,"POST","/api/ota/cancel","boot",nonce,"",body.data(),body.size(),other));assert(!otaEqual(mac,other,32));
 char hex[65];otaHex(mac,32,hex);assert(!strcmp(hex,"6094c27fd163c2e0491c5430b1037cacb8ffac57ad05c7d44a3c8153adc9640c"));printf("control_mac=%s\n",hex);
 cryptoFail=true;assert(!otaControlMac(fixture,"POST","/api/ota/prepare","boot",nonce,"",body.data(),body.size(),mac));cryptoFail=false;
 puts("OTA canonical manifest, image prefix, journal corruption/torn writes, reconciliation, commit failures and replay tests passed");
}
