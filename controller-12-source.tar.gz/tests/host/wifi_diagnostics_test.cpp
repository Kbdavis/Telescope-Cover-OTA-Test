#include "wifi_diagnostics.h"
#include <cassert>
#include <cstdio>
using namespace cover;
int main(){
 WiFiDiagnosticTracker t;
 assert(!t.data.connected && !t.data.hasDisconnect && !t.data.hasRssi);
 t.signal(-60);assert(!t.data.hasRssi);
 t.gotIP(100);t.gotIP(110);assert(t.data.reconnects==0);
 t.signal(-65);t.signal(-80);t.signal(-50);t.signal(0);
 assert(t.data.minimumRssi==-80 && t.data.rssi==-50);
 t.disconnected(1000,200);t.disconnected(1200,201);
 assert(t.data.disconnects==2 && !t.data.rssiValid && t.data.reason==201);
 assert(t.outageMs(1500)==500);t.gotIP(2000);t.gotIP(2100);
 assert(t.data.reconnects==1 && t.data.lastOutageMs==1000 && t.outageMs(2200)==0);
 t.request(false,false,25);t.request(true,true,1200);t.request(true,false,80);
 assert(t.data.requests==3 && t.data.failures==2 && t.data.timeouts==1);
 assert(t.data.lastRequestMs==80 && t.data.maxRequestMs==1200);
 t.disconnected(UINT32_MAX-10,200);t.gotIP(9);assert(t.data.lastOutageMs==20);
 t.data.disconnects=UINT32_MAX;t.disconnected(10,2);assert(t.data.disconnects==UINT32_MAX);
 puts("Wi-Fi metrics: initial connection, duplicate events, outage, rollover, RSSI and request counts passed");
}
