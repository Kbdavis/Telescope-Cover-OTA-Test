#include "emergency_shutdown.h"
#include <cassert>
#include <cstdio>
#include <cstring>
#include <initializer_list>
using namespace cover;
static ShutdownEvidence sample(uint32_t now,uint32_t sequence,bool home=false){
 ShutdownEvidence e;e.coverReady=e.coverStationary=e.coverOpen=e.torqueOff=e.positionFresh=e.calibrationClean=true;
 e.scope.enabled=e.scope.valid=e.scope.connected=e.scope.canFindHome=true;
 e.scope.sampledAt=now;e.scope.sequence=sequence;e.scope.atHome=home;e.scope.consecutiveStowed=home?2:0;
 e.native.operation=1;e.native.sequence=sequence;e.native.sampledAt=now;e.native.valid=true;
 e.native.imagingIdle=e.native.cameraIdle=e.native.planIdle=true;e.native.closed=home;return e;
}
static void ack(EmergencyShutdown& op,uint32_t now,ShutdownAction action){
 auto e=sample(now,now);e.reply={1,now,action,true,true,{}};op.tick(now,e);
}
static void phase(EmergencyShutdown& op,int index){
 assert(op.start(100,sample(100,1)));
 if(index>=1)ack(op,200,ShutdownAction::StopCapture);
 if(index>=2){op.tick(300,sample(300,3));op.tick(400,sample(400,4));}
 if(index>=3)ack(op,500,ShutdownAction::Park);
 assert(int(op.status().phase)==index+1);
}
static ShutdownEvidence lost(uint32_t now){auto e=sample(now,now);e.scope.valid=false;e.scope.error=alpaca::Error::Timeout;
 e.scope.failure={"tracking",27,1200,now};return e;}
int main(){
 // Recovery at every telescope phase, with no action re-dispatch or early close.
 for(int p=0;p<4;++p){
  EmergencyShutdown op;phase(op,p);const auto before=op.status();op.tick(600,lost(600));
  auto s=op.status();assert(s.recovering&&s.active()&&s.phase==before.phase&&!s.commandReady());
  assert(!op.closePermitted(600,sample(600,6))&&s.phaseAt==before.phaseAt&&s.startedAt==before.startedAt);
  assert(s.diagnostic.phase==before.phase&&s.diagnostic.detail.transaction==27&&s.diagnostic.detail.elapsedMs==1200);
  assert(!strcmp(s.diagnostic.detail.request,"tracking"));
  auto e=sample(700,7);if(s.action()!=ShutdownAction::None)e.reply={1,650,s.action(),true,true,{}};
  op.tick(700,e);op.tick(701,e);assert(op.status().recovering); // Duplicates cannot recover.
  e.scope.sequence=e.native.sequence=8;e.scope.sampledAt=e.native.sampledAt=800;op.tick(800,e);
  assert(!op.status().recovering&&op.status().recoveries==1);
  assert(op.status().phase!=ShutdownPhase::Closing);
  if(p==1||p==3){ // Recovery evidence alone cannot also count as two idle/stow samples.
   assert(op.status().phase==before.phase);op.tick(900,sample(900,9,p==3));assert(op.status().phase==before.phase);
   op.tick(1000,sample(1000,10,p==3));assert(op.status().phase==(p==1?ShutdownPhase::Stowing:ShutdownPhase::Closing));
  }
 }
 // Both interfaces must be fresh, post-loss, distinct, consistent, and agree.
 for(int bad=0;bad<9;++bad){EmergencyShutdown op;phase(op,1);op.tick(600,lost(600));op.tick(700,sample(700,7));
  auto e=sample(800,8);
  switch(bad){case 0:e.scope.valid=false;break;case 1:e.native.valid=false;break;case 2:e.native.operation=2;break;
   case 3:e.scope.atHome=true;break;case 4:e.scope.slewing=true;break;case 5:e.native.tracking=true;break;
   case 6:e.scope.canFindHome=false;break;case 7:e.scope.sampledAt=500;break;case 8:e.native.cameraIdle=false;break;}
  op.tick(800,e);assert(op.status().recovering);
  op.tick(900,sample(900,9));assert(op.status().recovering);
  op.tick(1000,sample(1000,10));assert(!op.status().recovering);
 }
 // The outage clock cannot be extended by one good sample followed by another loss.
 {EmergencyShutdown op;phase(op,1);op.tick(600,lost(600));op.tick(1000,sample(1000,10));op.tick(1100,lost(1100));
  op.tick(15599,lost(15599));assert(op.status().recovering);op.tick(15600,lost(15600));
  assert(op.status().phase==ShutdownPhase::Fault&&op.status().locked());
  assert(op.status().diagnostic.at==600);op.tick(15700,sample(15700,12));assert(op.status().phase==ShutdownPhase::Fault);}
 // Original command and verification deadlines remain authoritative during recovery.
 for(int p=0;p<4;++p){EmergencyShutdown op;phase(op,p);auto s=op.status();
  const uint32_t deadline=s.phaseAt+((p==0||p==2)?15000:p==1?30000:60000);
  op.tick(deadline-100,lost(deadline-100));op.tick(deadline+1,lost(deadline+1));assert(op.status().phase==ShutdownPhase::Fault);}
 // Lost/late command ACK faults immediately, even during telemetry recovery.
 for(bool late:{false,true}){EmergencyShutdown op;phase(op,2);op.tick(600,lost(600));auto e=lost(700);
  e.reply={1,late?16000U:650U,ShutdownAction::Park,true,late,{"scope_park","timeout",0,25,6000}};
  op.tick(700,e);assert(op.status().phase==ShutdownPhase::Fault);
  assert(!strcmp(op.status().diagnostic.detail.error,late?"late":"timeout"));}
 // Stop cancels recovery; late ACK and good readings never resume the operation.
 {EmergencyShutdown op;phase(op,2);op.tick(600,lost(600));op.cancel(650);ack(op,700,ShutdownAction::Park);
  op.tick(800,sample(800,8,true));assert(op.status().phase==ShutdownPhase::Cancelled);}
 // No recovery with partial cover, moving cover, torque on, lost feedback/calibration, or disabled monitoring.
 for(int unsafe=0;unsafe<6;++unsafe){EmergencyShutdown op;phase(op,1);auto e=lost(600);
  switch(unsafe){case 0:e.coverOpen=false;break;case 1:e.coverStationary=false;break;case 2:e.torqueOff=false;break;
   case 3:e.positionFresh=false;break;case 4:e.calibrationClean=false;break;case 5:e.scope.enabled=false;break;}
  op.tick(600,e);assert(op.status().phase==ShutdownPhase::Fault&&!op.status().recovering);}
 // Native verification failures retain the failing read instead of a generic timeout.
 {EmergencyShutdown op;phase(op,1);auto e=sample(30201,9);e.native.valid=false;e.native.detail={"get_camera_state","timeout",0,11,5900};
  op.tick(30201,e);assert(op.status().phase==ShutdownPhase::Fault);assert(!strcmp(op.status().diagnostic.detail.request,"get_camera_state"));}
 // Wrap-safe recovery and timeout.
 for(bool recover:{false,true}){EmergencyShutdown op;const uint32_t base=0xfffffe00U;
  assert(op.start(base,sample(base,1)));ack(op,base+100,ShutdownAction::StopCapture);op.tick(base+200,lost(base+200));
  if(recover){op.tick(100,sample(100,2));op.tick(200,sample(200,3));assert(!op.status().recovering&&op.status().phase==ShutdownPhase::VerifyingIdle);}
  else {op.tick(base+15200,lost(base+15200));assert(op.status().phase==ShutdownPhase::Fault);}}
 // Actual worker dispatch policy: only pre-write deferrals may be retried.
 for(auto result:{ShutdownResult::Acknowledged,ShutdownResult::Failed}){
  ShutdownDispatch dispatch;ShutdownStatus s;s.operation=1;s.phase=ShutdownPhase::StoppingCapture;
  assert(dispatch.ready(100,s));dispatch.complete(100,s.action(),ShutdownResult::Deferred);
  assert(!dispatch.ready(1099,s)&&dispatch.ready(1100,s));s.recovering=true;assert(!dispatch.ready(1200,s));
  s.recovering=false;dispatch.complete(1200,s.action(),result);assert(!dispatch.ready(9999,s));
  s.phase=ShutdownPhase::Stowing;assert(dispatch.ready(10000,s));dispatch.complete(10000,s.action(),result);
  s.recovering=true;assert(!dispatch.ready(11000,s));s.recovering=false;assert(!dispatch.ready(12000,s));
  s.phase=ShutdownPhase::StoppingCapture;assert(!dispatch.ready(13000,s));++s.operation;assert(dispatch.ready(13000,s));
 }
 {ShutdownDispatch d;ShutdownStatus s;s.operation=1;s.phase=ShutdownPhase::Stowing;
  assert(d.ready(0xffffff00U,s));d.complete(0xffffff00U,s.action(),ShutdownResult::Deferred);assert(!d.ready(743,s)&&d.ready(744,s));}
 puts("Emergency recovery: all telescope phases, repeated fresh evidence, bounded deadlines, no duplicate commands, diagnostics, Stop and wraparound passed");
}
