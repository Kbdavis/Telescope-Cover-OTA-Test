#include "alpaca_client.h"
#include "emergency_shutdown.h"
#include <cassert>
#include <cstdio>
using namespace cover;
struct Telescope:alpaca::Transport {
 bool home=false,slewing=false,tracking=false;
 alpaca::Error error=alpaca::Error::None;
 alpaca::Reply get(alpaca::Property property,uint32_t) override {
  alpaca::Reply r;r.error=error;
  switch(property){
   case alpaca::Property::Connected:case alpaca::Property::CanFindHome:r.value=true;break;
   case alpaca::Property::AtHome:r.value=home;break;
   case alpaca::Property::Slewing:r.value=slewing;break;
   case alpaca::Property::Tracking:r.value=tracking;break;
   default:assert(false);
  }
  return r;
 }
};
ShutdownEvidence evidence(const alpaca::Snapshot& scope){
 ShutdownEvidence e;e.coverReady=e.coverStationary=e.coverOpen=e.torqueOff=e.positionFresh=e.calibrationClean=true;
 e.scope=scope;return e;
}
int main(){
 // Use the real poller between completed sweeps: this was the live rejection
 // window, even when both interfaces and cover preflight were available.
 for(unsigned activity=0;activity<4;++activity){
  Telescope telescope;telescope.slewing=activity&1;telescope.tracking=activity&2;
  alpaca::Client client(telescope);client.enable(true);
  for(unsigned stage=0;stage<6;++stage)client.step(stage*100);
  for(unsigned sweep=0;sweep<3;++sweep)for(unsigned stage=0;stage<6;++stage){
   const uint32_t now=1500+sweep*1500+stage*100;client.step(now);
   const auto snapshot=client.status(now);auto e=evidence(snapshot);
   assert(snapshot.fresh(now)&&snapshot.connected&&snapshot.canFindHome);
   EmergencyShutdown shutdown;assert(shutdown.start(now,e));
   assert(shutdown.status().action()==ShutdownAction::StopCapture);
   assert(!snapshot.stowedCandidate(now)&&!shutdown.closePermitted(now,e));
  }
  telescope.error=alpaca::Error::Timeout;client.step(6000);
  EmergencyShutdown disconnected;assert(!disconnected.start(6000,evidence(client.status(6000))));
 }
 // A genuine safe-to-unsafe change must still block entry until a complete
 // fresh sweep arrives, and revoke previously verified stow immediately.
 Telescope telescope;telescope.home=true;alpaca::Client client(telescope);client.enable(true);
 for(unsigned sweep=0;sweep<2;++sweep)for(unsigned stage=0;stage<6;++stage)client.step(sweep*1500+stage*100);
 assert(client.status(2000).stowedCandidate(2000));
 telescope.home=false;client.step(3000);client.step(3100);client.step(3200);
 EmergencyShutdown changing;assert(!changing.start(3200,evidence(client.status(3200))));
 assert(!client.status(3200).stowedCandidate(3200));
 // A real timed-out poll, its three-second backoff and two complete new
 // sweeps recover within the window, without sending capture-stop twice.
 Telescope recoveringScope;alpaca::Client poller(recoveringScope);poller.enable(true);
 for(unsigned sweep=0;sweep<2;++sweep)for(unsigned stage=0;stage<6;++stage)poller.step(sweep*1500+stage*100);
 EmergencyShutdown operation;auto current=evidence(poller.status(2000));assert(operation.start(2000,current));
 current.reply={1,2010,ShutdownAction::StopCapture,true,true,{}};operation.tick(2010,current);
 ShutdownDispatch dispatch;ShutdownStatus command;command.operation=1;command.phase=ShutdownPhase::StoppingCapture;
 assert(dispatch.ready(2000,command));dispatch.complete(2010,command.action(),ShutdownResult::Acknowledged);
 for(uint32_t now=2100;now<=11100;now+=100){
  recoveringScope.error=now==3000?alpaca::Error::Timeout:alpaca::Error::None;poller.step(now);
  current=evidence(poller.status(now));current.native.operation=1;current.native.sequence=now;current.native.sampledAt=now;
  current.native.valid=current.native.imagingIdle=current.native.cameraIdle=current.native.planIdle=true;
  operation.tick(now,current);
  if(now>=3000&&now<8000)assert(operation.status().recovering);
  if(now<11000)assert(!dispatch.ready(now,operation.status()));
  assert(operation.status().phase!=ShutdownPhase::Fault&&!operation.closePermitted(now,current));
 }
 assert(operation.status().recoveries==1&&!operation.status().recovering&&operation.status().phase==ShutdownPhase::Stowing);
 assert(dispatch.ready(11100,operation.status()));
 puts("Emergency/Alpaca integration: raised/tracking/slewing entry across every polling stage, lost-status rejection and immediate stow revocation passed");
}
