#include "servo_controller.h"
#include "servo_test_bus.h"
#include <stdio.h>
using namespace cover;
static unsigned long now=0;
unsigned long millis(){return now;}
void yield(){++now;}
const uint8_t baseline[40]={3,9,0,9,3,1,0,0,1,0,0,255,15,70,140,40,232,3,12,44,47,32,32,0,16,0,1,1,54,1,1,85,0,0,20,200,80,10,200,200};
void factory(Bus& b){for(unsigned n=0;n<40;++n)b.registers[n]=baseline[n];b.registers[55]=1;b.registers[40]=0;b.registers[56]=0xd9;b.registers[57]=15;b.simulateReference=true;}
unsigned offsetWrites(const Bus& b){unsigned n=0;for(const auto& p:b.writes)if(p[4]==3){assert(p[5]==31);++n;}return n;}
int main(){
 Bus b;factory(b);ServoController servo(b);
 assert(!servo.validateConfiguration()); // Never move in the old coordinate basis.
 assert(servo.prepareFixedReference());assert(offsetWrites(b)==1);
 assert(servo.validateConfiguration());assert(b.registers[56]+256*b.registers[57]==2814);
 assert(servo.prepareFixedReference()&&offsetWrites(b)==1); // No extra write or stale goal on restart.
 for(unsigned n=0;n<40;++n){b.registers[n]^=1;assert(!servo.prepareFixedReference());assert(!servo.validateConfiguration());assert(offsetWrites(b)==1);b.registers[n]^=1;}
 b.registers[55]=0;assert(!servo.prepareFixedReference()&&!servo.validateConfiguration());b.registers[55]=1;
 // External servo reset: reject goals until the approved reference is re-established.
 b.registers[31]=85;b.registers[32]=0;b.registers[56]=0xd9;b.registers[57]=15;b.registers[40]=1;
 assert(!servo.validateConfiguration());assert(!servo.moveTo(2900,100,10,0,4095));assert(offsetWrites(b)==1);
 assert(!servo.prepareFixedReference()&&offsetWrites(b)==1); // Cannot shift an energized servo.
 b.registers[40]=0;assert(servo.prepareFixedReference()&&offsetWrites(b)==2);assert(servo.validateConfiguration());
 Bus ignored;factory(ignored);ignored.ignoreReference=true;ServoController refusing(ignored);
 assert(!refusing.prepareFixedReference()&&!refusing.validateConfiguration()&&offsetWrites(ignored)==1);
 assert(ignored.registers[55]==1&&ignored.registers[31]==85&&ignored.registers[32]==0);
 Bus legacy;factory(legacy);legacy.registers[18]=0;legacy.registers[31]=0;ServoController foreign(legacy);
 assert(!foreign.prepareFixedReference()&&!foreign.validateConfiguration()&&offsetWrites(legacy)==0);
 puts("Approved fixed-reference driver: exact profiles, RAM-only writes, lock/torque gates, idempotence and servo-reset exclusion passed");
}
