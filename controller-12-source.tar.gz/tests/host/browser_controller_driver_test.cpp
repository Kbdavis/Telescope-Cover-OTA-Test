#include "servo_controller.h"
#include "servo_test_bus.h"
#include <cstring>
#include <cstdio>
using namespace cover;
static unsigned long now=0;
unsigned long millis(){return now;}
void yield(){++now;}
const uint8_t factory[40]={3,9,0,9,3,1,0,0,1,0,0,255,15,70,140,40,232,3,12,44,47,32,32,0,16,0,1,1,54,1,1,85,0,0,20,200,80,10,200,200};
int main(){
 Bus native;memcpy(native.registers,factory,40);native.registers[11]=native.registers[12]=0;native.registers[18]=28;native.registers[55]=1;native.registers[40]=0;native.registers[56]=21;native.registers[57]=16;
 ServoController servo(native);uint16_t position=0;assert(servo.validateConfiguration());assert(servo.readPosition(position)&&position==21);
 for(const auto& p:native.writes)assert(p[4]==1||p[4]==2);
 assert(servo.enableTorque());assert(servo.releaseTorque());
 for(const auto& p:native.writes)if(p[4]==3)assert(p[5]>=40&&p[5]<55);
 Bus cold;memcpy(cold.registers,factory,40);cold.registers[55]=1;cold.registers[40]=0;cold.registers[56]=100;
 uint8_t before[80];memcpy(before,cold.registers,80);ServoController factoryServo(cold);
 assert(!factoryServo.validateConfiguration());assert(!factoryServo.enableTorque());assert(!factoryServo.moveTo(200,100,10,0,4095));
 assert(!memcmp(before,cold.registers,80));for(const auto& p:cold.writes)assert(p[4]==1||p[4]==2);
 puts("Complete browser controller driver: native operation remains available; factory profile rejected without any configuration, goal or torque writes");
}
