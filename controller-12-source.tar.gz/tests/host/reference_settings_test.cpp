#include "settings.h"
#include <Preferences.h>
#include <vector>
#include <assert.h>
#include <stdio.h>
using namespace cover;
std::vector<uint8_t> storedPreferences;
bool preferencesAvailable=true,preferencesWriteFails=false;
void record(unsigned version,bool circular=false,uint16_t reference=85){
 uint16_t words[17]={0xca11,uint16_t(version),2015,4000,2386,3464,3,100,100,100,10,17000,1,1078,0,reference,0};
 if(circular){words[2]=0;words[3]=4095;words[5]=100;words[13]=1810;words[14]=1;}
 unsigned count=version==3?15:version==4?16:17;
 uint16_t hash=0x5a39;for(unsigned n=0;n<count-1;++n)hash=uint16_t(hash*31U^words[n]);words[count-1]=hash;
 storedPreferences.assign(reinterpret_cast<uint8_t*>(words),reinterpret_cast<uint8_t*>(words)+2*count);
}
int main(){
#ifdef COVER_FIXED_REFERENCE
 for(unsigned version:{3U,4U,5U}){
  record(version);const auto original=storedPreferences;Calibration c;
  assert(loadCalibration(c)==SettingsLoad::Loaded&&storedPreferences==original);
  assert(c.referenceOffset==1328&&c.closed==1143&&c.open==2221&&c.minimum==772&&c.maximum==2757);
  assert(c.profile.timeoutMs==17000&&c.travelCounts==1078&&c.openingDirection==1);
  assert(convertCalibrationReference(c,1328)&&c.closed==1143);
  assert(saveCalibration(c)&&storedPreferences.size()==34);
  Calibration again;assert(loadCalibration(again)==SettingsLoad::Loaded&&again.closed==1143&&again.open==2221&&again.referenceOffset==1328);
 }
 record(4,true);Calibration circular;
 assert(loadCalibration(circular)==SettingsLoad::Loaded&&circular.circular&&circular.closed==1143&&circular.open==2953&&circular.travelCounts==1810);
 assert(saveCalibration(circular));Calibration again;assert(loadCalibration(again)==SettingsLoad::Loaded&&again.open==2953);
 // A linear allowed interval that would cross the new zero is never widened.
 Calibration unsafe;unsafe.minimum=0;unsafe.maximum=4095;unsafe.closed=2386;unsafe.open=3464;unsafe.hasClosed=unsafe.hasOpen=true;unsafe.openingDirection=1;unsafe.travelCounts=1078;unsafe.referenceOffset=85;
 const auto original=unsafe;assert(!convertCalibrationReference(unsafe,1328)&&unsafe.closed==original.closed&&unsafe.referenceOffset==85);
 puts("Fixed-reference settings: explicit basis, atomic legacy migration, no double shift, circular travel and rejected widening passed");
#else
 record(5,false,1328);Calibration c;
 assert(loadCalibration(c)==SettingsLoad::ReviewRequired&&c.referenceOffset==1328);
 assert(!saveCalibration(c));
 puts("Baseline firmware rejects foreign reference coordinates for movement/save");
#endif
 record(5,false,42);Calibration invalid;assert(loadCalibration(invalid)==SettingsLoad::Invalid);
}
