#pragma once
#include <stddef.h>
#include <stdint.h>
#include <string.h>
#include <vector>
#include <map>
#include <string>
extern std::vector<uint8_t> storedPreferences;
extern bool preferencesAvailable, preferencesWriteFails;
class Preferences {
 std::string space;
 std::vector<uint8_t>& record(){
  static std::map<std::string,std::vector<uint8_t>> records;
  return space=="cover-cal"?storedPreferences:records[space];
 }
 public:
 bool begin(const char* name,bool){space=name;return preferencesAvailable;}
 void end(){}
 bool remove(const char*){if(preferencesWriteFails)return false;record().clear();return true;}
 bool isKey(const char*){return !record().empty();}
 size_t getBytesLength(const char*){return record().size();}
 size_t getBytes(const char*,void* out,size_t size){if(size!=record().size())return 0;memcpy(out,record().data(),size);return size;}
 size_t putBytes(const char*,const void* data,size_t size){if(preferencesWriteFails)return 0;const auto* p=static_cast<const uint8_t*>(data);record().assign(p,p+size);return size;}
};
