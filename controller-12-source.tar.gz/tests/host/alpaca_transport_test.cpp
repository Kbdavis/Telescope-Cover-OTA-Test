#define COVER_WEB_CONTROL
#include "../../src/alpaca_transport.cpp"
#include <assert.h>
#include <signal.h>
#include <string>
#include <vector>
namespace cover {
SettingsLoad loadApplicationSettings(ApplicationSettings&){return SettingsLoad::Missing;}
void diagnosticLog(const char*,...){}
void noteAlpacaRequest(bool,bool,uint32_t){}
void diagnosticEvent(DebugLevel,const char*,...){}
void noteTaskStack(DiagnosticTask){}
void registerMaintenanceWorker(uint8_t,bool){}
MaintenanceLease otaMaintenanceForWorker(){return {};}
void acknowledgeMaintenancePause(MaintenanceLease,uint8_t){}
}
using namespace cover;
using alpaca::Error;
std::string json(const std::string& value="true",int error=0,int tx=7){return "{\"Value\":"+value+",\"ClientTransactionID\":"+std::to_string(tx)+",\"ServerTransactionID\":1,\"ErrorNumber\":"+std::to_string(error)+",\"ErrorMessage\":\"\"}";}
std::string http(const std::string& body){return "HTTP/1.0 200 OK\r\nContent-Length: "+std::to_string(body.size())+"\r\n\r\n"+body;}
// Extra probes cover the fixed S30 Pro telemetry paths and their logical sessions.
enum Probe { Default=-1,CameraConnected,CameraState,CameraTemperature,HeaterConnected,HeaterCount,HeaterIdentity,HeaterState,Azimuth,ConnectCamera,ConnectHeater };
alpaca::Reply fixture(const std::string& response,unsigned delay=0,bool trickle=false,unsigned holdOpen=0,bool put=false,bool altitude=false,bool connect=false,Probe probe=Default,uint32_t budget=1200){
 int listener=socket(AF_INET,SOCK_STREAM,0);assert(listener>=0);sockaddr_in address{};address.sin_family=AF_INET;address.sin_addr.s_addr=htonl(INADDR_LOOPBACK);
 assert(bind(listener,reinterpret_cast<sockaddr*>(&address),sizeof(address))==0);assert(listen(listener,1)==0);
 socklen_t length=sizeof(address);assert(getsockname(listener,reinterpret_cast<sockaddr*>(&address),&length)==0);
 std::thread server([&]{int peer=accept(listener,nullptr,nullptr);assert(peer>=0);std::string request;char c;
  while(request.find("\r\n\r\n")==std::string::npos && recv(peer,&c,1,0)==1)request+=c;
  const bool auxiliary=probe==ConnectCamera || probe==ConnectHeater;
  if(put || connect || auxiliary){
   const char* family=probe==ConnectCamera?"camera":probe==ConnectHeater?"switch":"telescope";
   assert(request.find(std::string("PUT /api/v1/")+family+"/0/"+((connect||auxiliary)?"connected":"findhome")+" HTTP/1.0")==0);
   assert(request.find("Content-Type: application/x-www-form-urlencoded")!=std::string::npos);
   const std::string form=std::string("ClientID=731&ClientTransactionID=7")+((connect||auxiliary)?"&Connected=true":"");
   assert(request.find("Content-Length: "+std::to_string(form.size())+"\r\n")!=std::string::npos);
   std::string body;while(body.size()<form.size() && recv(peer,&c,1,0)==1)body+=c;
   assert(body==form);
  }else {
   const char* paths[]={"camera/0/connected","camera/0/camerastate","camera/0/ccdtemperature","switch/0/connected","switch/0/maxswitch","switch/0/getswitchname","switch/0/getswitch","telescope/0/azimuth"};
   const std::string path=probe==Default?(altitude?"telescope/0/altitude":"telescope/0/athome"):paths[probe];
   assert(request.find("GET /api/v1/"+path+"?ClientID=731&ClientTransactionID=7"+((probe==HeaterIdentity||probe==HeaterState)?"&Id=0":"")+" HTTP/1.0")==0);
  }
  if(delay)std::this_thread::sleep_for(std::chrono::milliseconds(delay));
  size_t sent=0;while(sent<response.size()){
   auto n=send(peer,response.data()+sent,trickle?1:response.size()-sent,0);if(n<=0)break;sent+=n;
   if(trickle)std::this_thread::sleep_for(std::chrono::milliseconds(30));
  }if(holdOpen)std::this_thread::sleep_for(std::chrono::milliseconds(holdOpen));close(peer);
 });
 ApplicationSettings config;strcpy(config.alpacaHost,"127.0.0.1");config.alpacaPort=ntohs(address.sin_port);
 HttpTransport transport(config,budget);alpaca::Reply reply;
 if(probe==ConnectCamera || probe==ConnectHeater)reply=transport.connectAuxiliary(probe==ConnectCamera?alpaca::Auxiliary::Camera:alpaca::Auxiliary::Heater,7);
 else if(probe==Azimuth)reply=transport.get(alpaca::Property::Azimuth,7);
 else if(probe!=Default)reply=transport.getMetric(static_cast<alpaca::Metric>(probe),7);
 else reply=connect?transport.connectSession(7):put?transport.findHome(7):transport.get(altitude?alpaca::Property::Altitude:alpaca::Property::AtHome,7);
 server.join();close(listener);return reply;
}
int main(int argc,char** argv){signal(SIGPIPE,SIG_IGN);
 if(argc==2 && strcmp(argv[1],"--live-telemetry-read-only")==0){
  ApplicationSettings config;strcpy(config.alpacaHost,"192.168.1.131");config.alpacaPort=32323;
  HttpTransport transport(config);uint32_t tx=100;bool valid=true;
  for(auto property:{alpaca::Property::Altitude,alpaca::Property::Azimuth}){
   const auto r=transport.get(property,++tx);valid=valid&&r.error==Error::None;
   printf("GET %s: error=%s number=%.2f\n",alpaca::propertyName(property),alpaca::errorName(r.error),r.number);
  }
  for(auto metric:{alpaca::Metric::CameraConnected,alpaca::Metric::CameraState,alpaca::Metric::CameraTemperature,alpaca::Metric::HeaterConnected,alpaca::Metric::HeaterCount,alpaca::Metric::HeaterIdentity,alpaca::Metric::HeaterState}){
   const auto r=transport.getMetric(metric,++tx);valid=valid&&r.error==Error::None;
   printf("GET metric %d: error=%s number=%.2f boolean=%d\n",int(metric),alpaca::errorName(r.error),r.number,r.value);
  }
  return valid?0:1;
 }
 if(argc==2 && strcmp(argv[1],"--live-read-only")==0){
  ApplicationSettings config;strcpy(config.alpacaHost,"192.168.1.131");config.alpacaPort=32323;
  HttpTransport transport(config);alpaca::Client client(transport);client.enable(true);
  uint32_t start=millis();
  while(millis()-start<12000){
   client.step(millis());auto state=client.status(millis());
   if(state.sequence>=2){printf("Live GET-only: valid=%d connected=%d home=%d slewing=%d tracking=%d confirmations=%u error=%s\n",state.valid,state.connected,state.atHome,state.slewing,state.tracking,state.consecutiveStowed,alpaca::errorName(state.error));return state.valid?0:1;}
   std::this_thread::sleep_for(std::chrono::milliseconds(25));
  }
  auto failed=client.status(millis());printf("Live poll incomplete: sequence=%lu error=%s driver=%ld\n",(unsigned long)failed.sequence,alpaca::errorName(failed.error),(long)failed.driverError);return 1;
 }

 auto optionalTimeout=fixture(http(json()),900,false,0,false,false,false,Default,700);
 assert(optionalTimeout.error==Error::Timeout && optionalTimeout.elapsedMs<850);
 const std::string putReply="{\"ClientTransactionID\":7,\"ServerTransactionID\":1,\"ErrorNumber\":0,\"ErrorMessage\":\"\"}";
 auto metric=[](Probe p,const std::string& value){return fixture(http(json(value)),0,false,0,false,false,false,p);};
 assert(metric(CameraConnected,"true").value);
 assert(metric(HeaterConnected,"true").value);
 assert(metric(CameraState,"0").error==Error::None);
 assert(metric(CameraState,"2").number==2);
 assert(metric(CameraTemperature,"25.5").number==25.5);
 assert(metric(HeaterCount,"1").number==1);
 assert(metric(HeaterIdentity,"\"Dew heater\"").value);
 assert(metric(HeaterIdentity,"\"Unknown output\"").error==Error::Unsupported);
 auto heater=metric(HeaterState,"false");assert(heater.error==Error::None && !heater.value);
 assert(metric(Azimuth,"359.9").number==359.9);
 for(const auto* bad:{"-1","6","2.5","null","true"})assert(metric(CameraState,bad).error==Error::Protocol);
 for(const auto* bad:{"-274","151","null","\"25\""})assert(metric(CameraTemperature,bad).error==Error::Protocol);
 for(const auto* bad:{"-1","361","null"})assert(metric(Azimuth,bad).error==Error::Protocol);
 assert(metric(HeaterState,"0").error==Error::Protocol);
 // Logical connection is the only permitted write; verify the exact form on
 // each supported device. A successful PUT need not contain a Value field.
 assert(fixture(http(putReply),0,false,0,false,false,true).error==Error::None);
 assert(fixture(http(putReply),0,false,0,false,false,false,ConnectCamera).error==Error::None);
 assert(fixture(http(putReply),0,false,0,false,false,false,ConnectHeater).error==Error::None);
 assert(fixture(http(json("false",1031)),0,false,0,false,false,true).error==Error::Driver);
 assert(fixture(http(json("true",0,8)),0,false,0,false,false,true).error==Error::Protocol);
 assert(fixture(http(putReply),1400,false,0,false,false,true).error==Error::Timeout);
 // Legacy telescope movement stays blocked before opening a socket.
 ApplicationSettings monitoring;HttpTransport readOnly(monitoring);
 assert(readOnly.findHome(7).error==Error::Unsupported);
 assert(!requestAlpacaStow());
 assert(fixture(http(json("-89.8")),0,false,0,false,true).number==-89.8);
 assert(fixture(http(json("45.5")),0,false,0,false,true).number==45.5);
 for(const auto* bad:{"91","-91","null","true","\"30\""})assert(fixture(http(json(bad)),0,false,0,false,true).error==Error::Protocol);
 assert(fixture(http(json("0",1024)),0,false,0,false,true).error==Error::Unsupported);
 assert(fixture(http(json())).value);
 assert(fixture("HTTP/1.1 200 OK\r\nConnection: close\r\n\r\n"+json()).value);
 assert(fixture("HTTP/1.0 200 OK\r\n\r\n"+json()).value);
 assert(fixture("HTTP/1.1 200 OK\r\n\r\n"+json()).error==Error::Protocol);
 assert(fixture("HTTP/1.1 200 OK\r\nConnection: close\r\n\r\n"+std::string(2049,'x')).error==Error::Oversized);
 auto noClose=fixture("HTTP/1.1 200 OK\r\nConnection: close\r\n\r\n"+json(),0,false,1400);assert(noClose.error==Error::Timeout && noClose.elapsedMs<1350);
 auto no=fixture(http(json("false")));assert(no.error==Error::None && !no.value);
 assert(fixture(http(json("0"))).error==Error::Protocol);
 assert(fixture(http(json("null"))).error==Error::Protocol);
 assert(fixture(http(json("\"true\""))).error==Error::Protocol);
 assert(fixture(http(json("true",0,8))).error==Error::Protocol);
 assert(fixture(http(json("false",1024))).error==Error::Unsupported);
 auto driver=fixture(http(json("false",1031)));assert(driver.error==Error::Driver && driver.driverError==1031);
 assert(fixture("HTTP/1.0 503 unavailable\r\nContent-Length: 2\r\n\r\n{}").error==Error::Http);
 assert(fixture("HTTP/1.0 302 Found\r\nLocation: http://example.invalid/\r\n\r\n").error==Error::Http);
 assert(fixture("HTTP/1.0 200 OK\r\n\r\n{}").error==Error::Protocol);
 assert(fixture("HTTP/1.0 200 OK\r\nContent-Length: 9000\r\n\r\n").error==Error::Oversized);
 assert(fixture("HTTP/1.0 200 OK\r\nContent-Length: 2\r\nContent-Length: 2\r\n\r\n{}").error==Error::Protocol);
 assert(fixture("HTTP/1.0 200 OK\r\nTransfer-Encoding: chunked\r\nContent-Length: 2\r\n\r\n{}").error==Error::Protocol);
 assert(fixture("HTTP/1.0 200 OK\r\nContent-Length: 100\r\n\r\n{}").error==Error::Timeout);
 assert(fixture("HTTP/1.0 200 OK\r\nX: "+std::string(1030,'a')).error==Error::Oversized);
 assert(fixture(http("{broken")).error==Error::Protocol);
 auto duplicate=json();duplicate.insert(1,"\"Value\":false,");assert(fixture(http(duplicate)).error==Error::Protocol);
 assert(fixture(http(std::string(17,'[') )).error==Error::Protocol);
 auto slow=fixture(http(json()),1400);assert(slow.error==Error::Timeout && slow.elapsedMs<1350);
 auto trickle=fixture(http(json()),0,true);assert(trickle.error==Error::Timeout && trickle.elapsedMs<1350);
 auto embedded=json()+std::string(1,'\0')+"junk";assert(fixture(http(embedded)).error==Error::Protocol);
 WiFi.state=0;ApplicationSettings config;HttpTransport transport(config);assert(transport.get(alpaca::Property::AtHome,7).error==Error::Offline);
 assert(transport.connectSession(7).error==Error::Offline);
 assert(transport.connectAuxiliary(alpaca::Auxiliary::Camera,7).error==Error::Offline);WiFi.state=WL_CONNECTED;
 puts("Production Alpaca HTTP transport: success, errors, malformed/oversized/truncated responses, duplicate fields, deadlines, disconnects passed");
}
