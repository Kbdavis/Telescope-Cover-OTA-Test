#include "debug_buffer.h"
#include <assert.h>
#include <stdio.h>
using namespace cover;
int main(){
 DebugBuffer repeat;DebugEntry status,other,result;
 std::strcpy(status.message,"ALPACA connection available error=none");status.at=1;repeat.append(status);
 std::strcpy(other.message,"Cover closed completed");repeat.append(other);
 for(unsigned i=2;i<1000;++i){status.at=i;repeat.append(status);}
 assert(repeat.window().newest==2 && repeat.window().overwrites==0);
 assert(repeat.next(0,result) && result.sequence==1 && result.at==999);
 assert(repeat.next(1,result) && !std::strcmp(result.message,other.message));
 assert(!repeat.next(2,result));
 std::strcpy(status.message,"ALPACA connection unavailable error=timeout");repeat.append(status);
 std::strcpy(status.message,"ALPACA connection available error=none");repeat.append(status);
 assert(repeat.window().newest==4); // Recovery stays visible after a failure.
 status.level=DebugLevel::Warn;repeat.append(status);assert(repeat.window().newest==5);
 status.truncated=true;repeat.append(status);repeat.append(status);assert(repeat.window().newest==7);
 for(unsigned i=0;i<kDebugCapacity;++i)repeat.append(other);
 status.truncated=false;repeat.append(status);assert(repeat.window().newest==8+kDebugCapacity);
 DebugBuffer buffer;DebugEntry entry,out;
 assert(!buffer.next(0,out));
 for(unsigned i=1;i<=kDebugCapacity+5;++i){entry.at=i;entry.level=i%2?DebugLevel::Error:DebugLevel::Warn;buffer.append(entry);}
 uint32_t cursor=0;unsigned count=0;
 while(buffer.next(cursor,out)){assert(out.sequence==count+6);assert(out.at==out.sequence);assert(out.level==(out.sequence%2?DebugLevel::Error:DebugLevel::Warn));cursor=out.sequence;++count;}
 assert(count==kDebugCapacity);assert(!buffer.next(UINT32_MAX,out));
 printf("Debug buffer retains the latest %u messages, timestamps and levels\n",kDebugCapacity);
}
