#define COVER_DEBUG_LOG_CAPACITY 1000 // Exercise transport bounds with a large retained history.
#include "debug_buffer.h"
#include "debug_response.h"
#include <cassert>
#include <cstdio>
#include <cstring>
#include <initializer_list>
#include <cstdlib>
using namespace cover;
int main(){
 uint32_t value=1;
 assert(debugCursor("4294967295",value) && value==UINT32_MAX);
 for(const char* text:{"", "-1", "1x", "4294967296", "00000000000"})assert(!debugCursor(text,value));
 DebugBuffer buffer;DebugEntry entry;
 for(unsigned i=0;i<1005;++i){entry.at=i;strcpy(entry.message,"quote\" slash\\ line\n");buffer.append(entry);}
 auto window=buffer.window();assert(window.oldest==6 && window.newest==1005 && window.overwrites==5);
 DebugEnvelope env;env.window=window;env.bootId="boot";env.firmware="elf";
 char output[kDebugResponseBytes+2];output[kDebugResponseBytes+1]='!';
 size_t size=writeDebugResponse(output,env,[&](uint32_t after,DebugEntry& out){return buffer.next(after,out);});
 assert(size<=4096 && output[4097]=='!');
 assert(strstr(output,"\"next_after\":21") && strstr(output,"\"gap\":true"));
 assert(strstr(output,"quote\\\" slash\\\\ line\\n")==nullptr); // Controls use JSON Unicode escaping.
 assert(strstr(output,"quote\\\" slash\\\\ line\\u000a"));
 assert(strstr(output,"\"local_time\":null"));
 std::puts(output); // Parsed by the Python contract tests, not just string assertions.
 setenv("TZ","MST7",1);tzset();
 DebugBuffer escaped;entry.epoch=1767225600;
 memset(entry.message,1,111);entry.message[111]=0;
 for(unsigned i=0;i<16;++i)escaped.append(entry);
 env.window=escaped.window();
 size=writeDebugResponse(output,env,[&](uint32_t after,DebugEntry& out){return escaped.next(after,out);});
 assert(size<=4096 && strstr(output,"\"more\":true"));
 assert(strstr(output,"\"local_time\":\"2025-12-31T17:00:00-0700\""));
 const auto* next=strstr(output,"\"next_after\":");assert(next);
 const unsigned returned=std::strtoul(next+13,nullptr,10);assert(returned>0 && returned<16);
 std::puts(output);
 DebugBuffer rollover(UINT32_MAX-1);rollover.append(entry);assert(rollover.window().newest==UINT32_MAX);
 rollover.append(entry);window=rollover.window();
 assert(window.oldest==1 && window.newest==1 && window.sequenceEpoch==1 && window.overwrites==1);
 assert(rollover.next(0,entry) && entry.sequence==1);
 env.window=window;env.after=UINT32_MAX;env.reset=true;
 writeDebugResponse(output,env,[&](uint32_t after,DebugEntry& out){return rollover.next(after,out);});
 assert(strstr(output,"\"cursor_reset\":true") && strstr(output,"\"next_after\":1"));
 std::puts(output);
 DebugReadBudget budget;assert(budget.take(0));assert(budget.take(1));assert(!budget.take(999));assert(budget.take(1000));
 assert(budget.take(UINT32_MAX));assert(budget.take(1));assert(!budget.take(2));assert(budget.take(1001));
}
