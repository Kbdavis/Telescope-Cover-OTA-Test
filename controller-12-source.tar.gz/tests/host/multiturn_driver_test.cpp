#include "servo_controller.h"
#include "servo_factory_profile.h"
#include "servo_test_bus.h"
#include <stdio.h>
#include <type_traits>
using namespace cover;
static unsigned long now=0;
unsigned long millis(){return now;}
void yield(){++now;}
const uint8_t factory[40]={3,9,0,9,3,1,0,0,1,0,0,255,15,70,140,40,232,3,12,44,47,32,32,0,16,0,1,1,54,1,1,85,0,0,20,200,80,10,200,200};
struct ProbeBus:Bus {
 int lostAck=-1;bool ignoreConfig=false;
 size_t write(const uint8_t* p,size_t n) override {
  if(p[4]==3){
   if(!ignoreConfig || (p[5]!=11 && p[5]!=18))
    for(unsigned i=6;i<n-1;++i)registers[p[5]+i-6]=p[i];
   if(p[5]==lostAck){writes.emplace_back(p,p+n);return n;}
  }
  return Bus::write(p,n);
 }
 void position(int value){const unsigned encoded=value<0?unsigned(-value)|0x8000:unsigned(value);registers[56]=encoded;registers[57]=encoded>>8;}
 unsigned written(unsigned address)const{unsigned count=0;for(const auto& p:writes)if(p[4]==3 && p[5]==address)++count;return count;}
 ProbeBus(){for(unsigned i=0;i<40;++i)registers[i]=factory[i];registers[55]=1;registers[40]=0;position(4017);}
};
TravelArc arc(int start,int direction,int length=100){TravelArc a;a.closedRaw=start;a.direction=direction;a.length=length;a.minimumRaw=0;a.maximumRaw=4095;a.circular=true;return a;}
unsigned goal(const ProbeBus& b){for(auto i=b.writes.rbegin();i!=b.writes.rend();++i)if((*i)[4]==3 && (*i)[5]==41)return (*i)[7]+256*(*i)[8];assert(false);return 0;}
#ifdef COVER_MULTITURN_STARTUP
void startupChecks(){
 // Cold startup restores only the two approved RAM fields. Calibration and
 // operational registers remain untouched, and repeated setup is read-only.
 {ProbeBus b;b.position(25);ServoController s(b);ReferenceProbeEvidence e;
  assert(s.prepareMultiTurnStartup(e));assert(e.writeAttempted && e.positionBefore==25 && e.positionAfter==25);
  assert(s.rolloverSupported());assert(b.written(11)==1 && b.written(18)==1);
  assert(s.prepareMultiTurnStartup(e));assert(b.written(11)==1 && b.written(18)==1);
  for(const auto& p:b.writes)if(p[4]==3)assert(p[5]==11 || p[5]==18);
  assert(b.registers[40]==0 && b.registers[55]==1 && b.registers[31]==85);
  // A servo-only reset cannot silently re-enable ordinary single-turn motion.
  b.registers[11]=255;b.registers[12]=15;b.registers[18]=12;
  assert(!s.validateConfiguration());assert(!s.prepareMultiTurnStartup(e));
  assert(!s.enableTorque());assert(!s.rolloverSupported());
  assert(b.written(11)==1 && b.written(18)==1 && !b.written(40));
  // A fresh controller boot can establish the profile again while OFF.
  ServoController rebooted(b);assert(rebooted.prepareMultiTurnStartup(e));
  assert(b.written(11)==2 && b.written(18)==2);
 }
 // Warm startup must preserve the native turn, including negative feedback.
 for(int native:{4117,-95})for(bool energized:{false,true}){
  ProbeBus b;b.registers[11]=b.registers[12]=0;b.registers[18]=28;
  b.registers[40]=energized;b.position(native);ServoController s(b);ReferenceProbeEvidence e;
  assert(s.prepareMultiTurnStartup(e));assert(!e.writeAttempted && s.rolloverSupported());
  uint16_t raw=0;assert(s.readPosition(raw) && raw==wrapPosition(native));
  for(const auto& p:b.writes)assert(p[4]!=3);
  b.registers[11]=255;b.registers[12]=15;b.registers[18]=12;b.position(wrapPosition(native));
  assert(!s.validateConfiguration() && !s.enableTorque());
 }
 // Unknown identity/configuration, unlocked EEPROM, torque ON, motion or
 // missing replies must never cause a configuration write.
 for(unsigned failure=0;failure<9;++failure){
  ProbeBus b;
  if(failure==0)b.registers[3]=0;
  if(failure==1)b.registers[21]^=1;
  if(failure==2)b.registers[55]=0;
  if(failure==3)b.registers[40]=1;
  if(failure==4)b.registers[66]=1;
  if(failure==5)b.registers[58]=1;
  if(failure==6)b.silentAddress=56;
  if(failure==7)b.registers[11]=b.registers[12]=0; // Partial profile.
  if(failure==8)b.positionOutlier=true;
  ServoController s(b);ReferenceProbeEvidence e;assert(!s.prepareMultiTurnStartup(e));
  assert(!e.writeAttempted);for(const auto& p:b.writes)assert(p[4]!=3);
 }
 // An ignored write or lost acknowledgement is latched even when the final
 // bytes happen to be correct. Neither recheck nor torque enable can bypass it.
 for(int failure:{-1,11,18}){
  ProbeBus b;b.ignoreConfig=failure==-1;b.lostAck=failure;
  ServoController s(b);ReferenceProbeEvidence e;
  assert(!s.prepareMultiTurnStartup(e) && e.writeAttempted);
  const auto packets=b.writes.size();
  assert(!s.prepareMultiTurnStartup(e) && !s.validateConfiguration() && !s.enableTorque());
  assert(b.writes.size()==packets);assert(!b.written(40));
 }
 struct ShiftBus:ProbeBus {
  bool jump=false;
  size_t write(const uint8_t* p,size_t n)override{
   if(p[4]==3 && p[5]==18 && jump)position(4017+4096);
   return ProbeBus::write(p,n);
  }
 };
 {ShiftBus b;b.jump=true;ServoController s(b);ReferenceProbeEvidence e;
  assert(!s.prepareMultiTurnStartup(e));assert(!s.validateConfiguration() && !s.enableTorque());
 }
 struct DriftBus:ProbeBus {
  unsigned samples=0;
  size_t write(const uint8_t* p,size_t n)override{
   if(p[4]==2 && p[5]==56 && ++samples==2)position(4025);
   return ProbeBus::write(p,n);
  }
 };
 {DriftBus b;ServoController s(b);ReferenceProbeEvidence e;
  assert(!s.prepareMultiTurnStartup(e) && !e.writeAttempted);
  assert(!b.written(11) && !b.written(18));
 }
}
#endif
#ifdef COVER_MULTITURN_USB
// These operator configuration APIs must be absent from the production driver.
template<class T,class=void>struct HasProbe:std::false_type{};
template<class T>struct HasProbe<T,std::void_t<decltype(&T::probeLockedMultiTurn)>>:std::true_type{};
template<class T,class=void>struct HasReference:std::false_type{};
template<class T>struct HasReference<T,std::void_t<decltype(&T::probeLockedReference)>>:std::true_type{};
static_assert(!HasProbe<ServoController>::value && !HasReference<ServoController>::value,
 "Production USB must not expose commissioning configuration APIs");
#endif
int main(){
 // Read-only update startup accepts exact native feedback on either turn and
 // rejects factory, partial, moving, energized and unreadable hardware.
 for(int native:{4117,-95}){
  ProbeBus bus;bus.registers[11]=bus.registers[12]=0;bus.registers[18]=28;bus.position(native);
  ServoController driver(bus);assert(driver.inspectMultiTurnStartup());
  uint16_t wrapped=0;assert(driver.readPosition(wrapped)&&wrapped==wrapPosition(native));
  for(const auto& packet:bus.writes)assert(packet[4]!=3);
#ifdef COVER_MULTITURN_STARTUP
  ReferenceProbeEvidence evidence;assert(!driver.prepareMultiTurnStartup(evidence));
#endif
  bus.registers[11]=255;bus.registers[12]=15;bus.registers[18]=12;
  assert(!driver.inspectMultiTurnStartup() && !driver.validateConfiguration() && !driver.enableTorque());
  for(const auto& packet:bus.writes)assert(packet[4]!=3);
 }
 for(unsigned failure=0;failure<8;++failure){
  ProbeBus bus;bus.registers[11]=bus.registers[12]=0;bus.registers[18]=28;
  if(failure==0){bus.registers[11]=255;bus.registers[12]=15;bus.registers[18]=12;}
  if(failure==1)bus.registers[18]=12;
  if(failure==2)bus.registers[55]=0;
  if(failure==3)bus.registers[21]^=1;
  if(failure==4)bus.registers[40]=1;
  if(failure==5)bus.registers[66]=1;
  if(failure==6)bus.registers[58]=1;
  if(failure==7)bus.silentAddress=56;
  ServoController driver(bus);assert(!driver.inspectMultiTurnStartup());
#ifdef COVER_MULTITURN_STARTUP
  ReferenceProbeEvidence evidence;assert(!driver.prepareMultiTurnStartup(evidence));
#endif
  for(const auto& packet:bus.writes)assert(packet[4]!=3);
 }
#ifdef COVER_MULTITURN_USB
 startupChecks();
 // Exercise signed crossing and hold staging through startup only. No probe API.
 for(int direction:{-1,1}){
  ProbeBus bus;bus.position(direction>0?4017:5);ServoController driver(bus);ReferenceProbeEvidence e;
  assert(driver.prepareMultiTurnStartup(e));assert(driver.enableTorque());
  const int start=direction>0?4017:5, target=start+direction*100;
  assert(driver.moveAcrossBoundary(wrapPosition(target),100,10,arc(start,direction)));
  assert(goal(bus)==unsigned(target<0?(-target)|0x8000:target));
  bus.position(target);uint16_t wrapped=0;assert(driver.readPosition(wrapped) && wrapped==wrapPosition(target));
  assert(driver.releaseTorque());assert(driver.enableTorque());
  assert(goal(bus)==unsigned(target<0?(-target)|0x8000:target));
  assert(!driver.moveAcrossBoundary(wrapPosition(start),101,10,arc(start,direction)));
  assert(!driver.moveAcrossBoundary(wrapPosition(start),100,11,arc(start,direction)));
  assert(!bus.written(31) && !bus.written(55));
 }
 puts("Production multi-turn USB startup, profile-loss rejection and signed motion checks passed");
#else
 {ProbeBus b;b.position(4071);ServoController s(b);ReferenceProbeEvidence e;assert(s.probeLockedMultiTurn(false,e));assert(s.enableTorque());
  const auto count=b.written(41);assert(!s.moveCalibratedEndpoint(2040,100,10,arc(0,1,2040)));assert(b.written(41)==count);
 }
 // Continuous endpoint goals also admit small inward starts beyond the arc.
 for(int direction:{-1,1})for(bool nearOpen:{false,true})for(int extra:{15,25,26}){
  ProbeBus bus;ServoController driver(bus);ReferenceProbeEvidence e;
  const auto taught=arc(397,direction,1789);
  const int native=397+direction*(nearOpen?1789+extra:-extra);
  const int destination=397+direction*(nearOpen?0:1789);
  bus.position(wrapPosition(native));assert(driver.probeLockedMultiTurn(false,e));
  // Apply starts on turn zero; use the continuous target nearest this native
  // starting point, rather than assuming the wrapped destination is a goal.
  const int start=wrapPosition(native),targetNative=start+(destination-native);
  assert(driver.enableTorque());const auto count=bus.written(41);
  assert(bool(driver.moveCalibratedEndpoint(wrapPosition(destination),100,10,taught))==(extra<=25));
  if(extra<=25)assert(goal(bus)==unsigned(targetNative<0?(-targetNative)|0x8000:targetNative));
  else assert(bus.written(41)==count);
 }
#ifdef COVER_MULTITURN_STARTUP
 startupChecks();
#endif
 for(int direction:{-1,1}){ProbeBus bus;bus.position(direction>0?3900:200);ServoController driver(bus);ReferenceProbeEvidence evidence;
  assert(driver.probeLockedMultiTurn(false,evidence));assert(driver.enableTorque());
  const int start=direction>0?3900:200;const int native=start+direction*500;
  assert(driver.moveAcrossBoundary(wrapPosition(native),100,10,arc(start,direction,500)));
  assert(goal(bus)==unsigned(native<0?(-native)|0x8000:native));
  assert(!driver.moveAcrossBoundary(wrapPosition(start+direction*501),100,10,arc(start,direction,501)));
 }
 // Saved 885-count arc: CLOSE crosses zero, OPEN returns on the same turn.
 {ProbeBus bus;bus.position(3528);ServoController driver(bus);ReferenceProbeEvidence evidence;
  assert(driver.probeLockedMultiTurn(false,evidence));assert(driver.enableTorque());
  assert(driver.maximumJogStep()==500);
  assert(driver.moveTo(3028,100,10,0,4095));assert(goal(bus)==3028);
  assert(driver.moveAcrossBoundary(4028,100,10,arc(3528,1,500)));assert(goal(bus)==4028);
  const auto taught=arc(317,-1,885);
  const auto before=bus.written(41);
  assert(!driver.moveAcrossBoundary(317,100,10,taught));
  assert(!driver.moveTo(2900,100,10,0,4095)); // Ordinary goals remain capped.
  assert(!driver.moveCalibratedEndpoint(300,100,10,taught)); // Not an endpoint.
  assert(!driver.moveCalibratedEndpoint(317,101,10,taught));
  assert(!driver.moveCalibratedEndpoint(317,100,11,taught));
  assert(bus.written(41)==before);
  assert(driver.moveCalibratedEndpoint(317,100,10,taught));assert(goal(bus)==4413);
  bus.position(4413);
  assert(driver.moveCalibratedEndpoint(3528,100,10,taught));assert(goal(bus)==3528);
  bus.position(3500);assert(!driver.moveCalibratedEndpoint(317,100,10,taught)); // Outside taught arc.
  bus.position(3528);assert(driver.releaseTorque());
  assert(!driver.moveCalibratedEndpoint(317,100,10,taught));
 }
 for(unsigned i=0;i<40;++i){ProbeBus b;b.registers[i]^=1;ServoController s(b);ReferenceProbeEvidence e;
  assert(!s.probeLockedMultiTurn(false,e) && !e.writeAttempted && !b.written(11) && !b.written(18));}
 for(unsigned failure=0;failure<3;++failure){ProbeBus b;ServoController s(b);ReferenceProbeEvidence e;
  if(failure==0){b.registers[55]=0;}
  if(failure==1){b.registers[40]=1;}
  if(failure==2){b.positionOutlier=true;}
  assert(!s.probeLockedMultiTurn(false,e) && !e.writeAttempted);}
 {ProbeBus b;b.ignoreConfig=true;ServoController s(b);ReferenceProbeEvidence e;
  assert(!s.probeLockedMultiTurn(false,e));assert(e.writeAttempted && b.written(11)==1 && b.written(18)==1);}
 for(int missing:{11,18}){ProbeBus b;b.lostAck=missing;ServoController s(b);ReferenceProbeEvidence e;
  assert(!s.probeLockedMultiTurn(false,e) && e.writeAttempted);assert(b.written(missing)==1);
  b.lostAck=-1;assert(s.probeLockedMultiTurn(true,e));assert(matchesCommissionedFactoryProfile(e.after));assert(b.registers[55]==1);}
 ProbeBus b;ServoController s(b);ReferenceProbeEvidence e;
 assert(s.probeLockedMultiTurn(false,e));assert(e.lockConfirmed && e.positionBefore==4017 && e.positionAfter==4017);
 assert(matchesMultiTurnProbeProfile(e.after));assert(s.validateConfiguration() && s.rolloverSupported());
 assert(b.registers[33]==0 && b.registers[31]==85 && b.registers[55]==1 && !b.written(55));
 assert(s.enableTorque());assert(goal(b)==4017);
 assert(s.moveAcrossBoundary(21,100,10,arc(4017,1)));assert(goal(b)==4117); // Continuous target, not raw 21.
 b.position(4117);uint16_t raw=0;assert(s.readPosition(raw)&&raw==21);
 b.position(21);assert(!s.readPosition(raw));b.position(4117); // Same display angle, wrong native turn.
 assert(s.releaseTorque());assert(s.enableTorque());assert(goal(b)==4117); // No full-turn jump after release.
 assert(s.moveAcrossBoundary(4017,100,10,arc(4017,1)));assert(goal(b)==4017);
 // Independent fresh negative-boundary session; no unobserved full-turn jump.
 ProbeBus negative;negative.position(5);ServoController reverse(negative);ReferenceProbeEvidence ne;
 assert(reverse.probeLockedMultiTurn(false,ne));assert(reverse.validateConfiguration());assert(reverse.enableTorque());
 assert(reverse.moveAcrossBoundary(4001,100,10,arc(5,-1)));assert(goal(negative)==(0x8000|95));
 negative.position(-95);assert(reverse.readPosition(raw)&&raw==4001);
 assert(reverse.releaseTorque());assert(reverse.enableTorque());assert(goal(negative)==(0x8000|95));
 assert(reverse.moveAcrossBoundary(5,100,10,arc(5,-1)));assert(goal(negative)==5);
 b.position(4117);ServoTelemetry t;assert(s.readTelemetry(t)&&t.position==21);
 assert(!s.moveAcrossBoundary(4017,101,10,arc(4017,1)));
 assert(!s.moveAcrossBoundary(4017,100,11,arc(4017,1)));
 b.position(8192);assert(!s.readPosition(raw));
 b.position(4117);assert(s.releaseTorque()); // Factory restore reverts feedback to the single-turn coordinate.
 b.position(21);assert(s.probeLockedMultiTurn(true,e));
 assert(matchesCommissionedFactoryProfile(e.after) && !s.rolloverSupported());
 b.position(4117);assert(!s.readPosition(raw)); // Extended reads forbidden again after restore.
 for(const auto& p:b.writes)if(p[4]==3)assert(p[5]==11 || p[5]==18 || p[5]==40 || p[5]==41);
 puts("Multi-turn commissioning: exact profiles, locked fixed writes/rollback, signed continuous goals, normalized feedback and hold-after-release passed");
#endif
}
