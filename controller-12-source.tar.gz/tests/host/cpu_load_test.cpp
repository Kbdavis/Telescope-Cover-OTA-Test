#include "cpu_load.h"
#include <assert.h>
#include <stdio.h>
using namespace cover;
int main(){
 CpuLoadTracker tracker;CpuLoadSample result;uint32_t idle[2]={0,0};
 assert(!tracker.update(0,0,idle,result));assert(!result.available);
 idle[0]=100;idle[1]=50;assert(!tracker.update(500,100,idle,result));
 idle[0]=200;idle[1]=100;assert(tracker.update(1000,200,idle,result));
 assert(result.available && result.busyPermille[0]==0 && result.busyPermille[1]==500);
 assert(result.windowMs==1000 && result.sampledAt==1000);
 // A busy core and an idle core are 50% average, not a hidden 100% combined load.
 idle[1]=300;assert(tracker.update(2000,400,idle,result));
 assert(result.available && result.busyPermille[0]==1000 && result.busyPermille[1]==0);
 assert((result.busyPermille[0]+result.busyPermille[1])/2==500);
 // A stopped timer and a delayed sampler never masquerade as healthy 0% load.
 assert(tracker.update(3000,400,idle,result) && !result.available);
 idle[0]+=1200;idle[1]+=1200;
 assert(tracker.update(9000,1600,idle,result) && !result.available);
 idle[0]+=200;idle[1]+=200;
 assert(tracker.update(10000,1800,idle,result) && result.available);
 // Counter rollover and uptime rollover use interval deltas.
 CpuLoadTracker wrap;idle[0]=UINT32_MAX-100;idle[1]=UINT32_MAX-100;
 assert(!wrap.update(UINT32_MAX-500,UINT32_MAX-100,idle,result));
 idle[0]+=200;idle[1]+=100;
 assert(wrap.update(499,99,idle,result) && result.available);
 assert(result.windowMs==1000 && result.busyPermille[0]==0 && result.busyPermille[1]==500);
 // Snapshot store ordering can add one idle observation; larger inconsistencies fail.
 CpuLoadTracker edge;idle[0]=idle[1]=0;edge.update(0,0,idle,result);
 idle[0]=201;idle[1]=0;edge.update(1000,200,idle,result);
 assert(result.available && result.busyPermille[0]==0 && result.busyPermille[1]==1000);
 idle[0]=404;edge.update(2000,400,idle,result);assert(!result.available);
 puts("CPU load intervals, both cores, warmup, missing samples, recovery and rollover passed");
}
