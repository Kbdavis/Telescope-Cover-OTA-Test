#include "failure_summary.h"
#include <cassert>
#include <cstdio>
using namespace cover;
FailureContext context(const char* boot,uint32_t at){
 FailureContext c{};memset(c.firmware,'a',64);strncpy(c.boot,boot,32);
 c.at=at;c.freeHeap=170000;c.minimumHeap=150000;return c;
}
int main(){
 FailureSummarySlot slots[2]{};FailureSummaryStore store(slots);store.begin(false,1);
 auto first=context("boot-a",UINT32_MAX-9);uint8_t bssid[]={1,2,3,4,5,6};
 assert(store.snapshot().boots==1 && !store.snapshot().wifi.present);
 store.fault(first,"Servo timeout",500,1500);
 store.disconnect(first,8,-80,bssid);store.retry("boot-a",2,12295,40000);
 store.disconnect(context("boot-a",3),2,-85,bssid);
 auto s=store.snapshot();assert(s.wifi.context.at==first.at && s.wifi.firstReason==8 && s.wifi.lastReason==2);
 assert(s.wifi.disconnects==2 && s.wifi.retries==1 && s.wifi.retryResult==12295);
 assert(s.fault.present && strcmp(s.fault.message,"Servo timeout")==0);
 store.recovered("boot-a",10);s=store.snapshot();assert(!s.wifi.active && s.wifi.outageMs==20);
 // A new store models reconstruction after a warm reset; records keep origin IDs.
 FailureSummaryStore rebooted(slots);rebooted.begin(true,3);
 s=rebooted.snapshot();assert(s.boots==2 && s.reset==3 && s.fault.present && s.wifi.retries==1);
 rebooted.recovered("boot-b",100);assert(rebooted.snapshot().wifi.outageMs==20);
 rebooted.retry("boot-b",200,0,80000);assert(rebooted.snapshot().wifi.retries==1);
 rebooted.disconnect(context("boot-b",1000),200,-76,bssid);
 s=rebooted.snapshot();assert(s.wifi.retries==0 && s.wifi.active && s.wifi.firstReason==200);
 assert(s.fault.context.at==first.at); // WiFi cannot overwrite a cover fault.
 // Simulate a reset halfway through a commit to the inactive slot.
 int latest=int32_t(slots[1].record.sequence-slots[0].record.sequence)>0?1:0;
 const auto seq=slots[latest].record.sequence;
 slots[1-latest].committed=0;slots[1-latest].record=slots[latest].record;
 slots[1-latest].record.sequence=seq+1;
 FailureSummaryStore torn(slots);torn.begin(true,4);
 assert(torn.snapshot().sequence==seq+1 && torn.snapshot().wifi.firstReason==200);
 // Corruption and incompatible layouts are rejected; cold boot clears all data.
 slots[0].checksum^=1;slots[1].checksum^=1;
 FailureSummaryStore corrupt(slots);corrupt.begin(true,5);
 assert(corrupt.snapshot().boots==1 && !corrupt.snapshot().fault.present);
 corrupt.fault(context("c",5),"fault",UINT32_MAX,UINT32_MAX);
 FailureSummaryStore cold(slots);cold.begin(false,1);assert(!cold.snapshot().fault.present);
 for(auto& slot:slots){slot.record.version=99;slot.checksum=FailureSummaryStore::checksum(slot.record);}
 FailureSummaryStore upgraded(slots);upgraded.begin(true,3);assert(upgraded.snapshot().boots==1);
 upgraded.fault(context("boot-c",30),"Recorded before sequence wrap",1,2);
 for(unsigned i=0;i<2;++i){slots[i].record.sequence=UINT32_MAX-1+i;slots[i].checksum=FailureSummaryStore::checksum(slots[i].record);}
 FailureSummaryStore wrapped(slots);wrapped.begin(true,3);
 assert(wrapped.snapshot().sequence==1 && wrapped.snapshot().fault.present);
 FailureSummaryStore afterWrap(slots);afterWrap.begin(true,3);assert(afterWrap.snapshot().sequence==2);
 // Runtime reads also validate CRC before exposing bounded strings to JSON.
 latest=int32_t(slots[1].record.sequence-slots[0].record.sequence)>0?1:0;
 const auto previousSequence=slots[1-latest].record.sequence;
 slots[latest].checksum^=1;assert(afterWrap.snapshot().sequence==previousSequence);
 afterWrap.fault(context("d",50),"New fault after corruption",3,4);
 assert(strcmp(afterWrap.snapshot().fault.message,"New fault after corruption")==0);
 printf("Retained failures: independent records, retry/recovery, rollover, warm/cold boot, torn writes and corruption passed (%zu RTC bytes)\n",sizeof(slots));
}
