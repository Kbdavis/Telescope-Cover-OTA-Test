#include "cover_controller.h"
#include <string.h>
#include "alpaca_client.h"
#include <assert.h>
#include <stdio.h>
#include <initializer_list>
using namespace cover;
static uint32_t now;
unsigned long millis() { return now; }
void yield() {}
struct Fake : ServoMotion {
 uint16_t p=2045, goal=0; bool torque=false, valid=true, failRead=false, failRelease=false, failMove=false;
 int moves=0,releases=0,enables=0;bool unstable=false;uint16_t stepLimit=500;
 uint16_t maximumJogStep() const override {return stepLimit;}
 uint8_t deviceStatus=0;uint16_t minimum=0,maximum=0;
 ServoResult lastResult() const override {return deviceStatus?ServoResult{ServoError::DeviceError,deviceStatus}:ServoResult{};}
 ServoResult validateConfiguration() override {if(deviceStatus)return lastResult(); return valid ? ServoResult{} : ServoResult{ServoError::InvalidConfiguration}; }
 ServoResult readPosition(uint16_t& out) override {if(deviceStatus)return lastResult(); if(failRead)return {ServoError::Timeout}; out=p;if(unstable)p+=10; return {}; }
 ServoResult readTorque(bool& out) override {if(deviceStatus)return lastResult();out=torque; return {};}
 ServoResult releaseTorque() override {++releases;if(deviceStatus)return lastResult();if(failRelease)return {ServoError::Timeout}; torque=false; return {};}
 ServoResult enableTorque() override {++enables;torque=true;return {};}
 ServoResult moveTo(uint16_t g,uint16_t,uint8_t,uint16_t lo,uint16_t hi) override {++moves;goal=g;minimum=lo;maximum=hi;return failMove?ServoResult{ServoError::Timeout}:ServoResult{};}
 void copyDiagnostics(ServoDiagnostics& out) const override {out=ServoDiagnostics{};out.torqueValid=true;out.torque=torque;out.failedReads=failRead?3:0;}
};
MotionSettings settings() { MotionSettings s; s.disableTorqueAfterMove=true; s.minimum=2000;s.maximum=2100;return s; }
void poll(CoverController& c,int n=1,bool safe=true) {for(int i=0;i<n;++i){now+=50;c.tick(safe);}}
int main(){
 // Manual torque retention holds between owner-supervised steps. Opting out
 // still releases; supervision loss and explicit Stop always release.
 for(bool retain:{false,true}){
  now=0;Fake f;CoverController c(f);assert(c.configure(settings()));
  assert(c.manualJog(10,true,retain));f.p=f.goal;poll(c,5);
  assert(c.state()==(retain?State::Holding:State::Stopped));assert(f.torque==retain);
  if(retain){const int releases=f.releases;assert(c.manualJog(10,true,true));assert(f.releases==releases);
   f.p=f.goal;poll(c,5);assert(c.holding()&&f.torque);poll(c,1,false);assert(!f.torque&&c.state()==State::Fault);}
 }
 {now=0;Fake f;CoverController c(f);assert(c.configure(settings()));assert(c.manualJog(10,true,true));f.p=f.goal;poll(c,5);c.stop();assert(!f.torque&&c.state()==State::Stopped);}
 struct RecoveryServo:Fake {
  bool rolloverSupported() const override{return true;}
  ServoResult moveCalibratedEndpoint(uint16_t g,uint16_t,uint8_t,const TravelArc& a)override{
   assert(a.endpointStartAllowed(p));goal=g;++moves;return {};
  }
 };
 // Recover inward from up to 25 counts beyond either endpoint, including
 // endpoints at zero. Do not widen jogging, settling or later motion bounds.
 for(int direction:{-1,1})for(int closed:{0,397,4095})for(bool nearOpen:{false,true})for(int extra:{15,25,26}){
  now=0;RecoveryServo f;CoverController c(f);auto s=settings();s.minimum=0;s.maximum=4095;s.timeoutMs=26000;
  s.hasTravelArc=true;s.arc.closedRaw=closed;s.arc.direction=direction;s.arc.length=1789;s.arc.circular=true;s.arc.maximumRaw=4095;
  f.p=wrapPosition(closed+direction*(nearOpen?1789+extra:-extra));assert(c.configure(s));c.stop();
  assert(!c.jog(direction*10,true));const auto enables=f.enables;
  const auto target=nearOpen?closed:s.arc.rawTarget(s.arc.length);
  assert(c.moveEndpoint(target,!nearOpen,true)==(extra<=25));
  if(extra>25){assert(f.enables==enables&&!f.moves);assert(strstr(c.moveRejection(),"25-count"));continue;}
  assert(f.goal==target);poll(c);assert(c.moving());
  f.p=s.arc.rawTarget(nearOpen?1788:1);poll(c);assert(c.moving());
  f.p=target;poll(c,5);assert(c.state()==(nearOpen?State::Closed:State::Open));assert(!f.torque);
 }
 {now=0;RecoveryServo f;f.p=412;CoverController c(f);auto s=settings();s.minimum=0;s.maximum=4095;s.timeoutMs=26000;
  s.hasTravelArc=true;s.arc.closedRaw=397;s.arc.direction=-1;s.arc.length=1789;s.arc.circular=true;s.arc.maximumRaw=4095;
  assert(c.configure(s));c.stop();assert(c.moveEndpoint(2704,true,true));
  f.p=396;poll(c);assert(c.moving());f.p=412;poll(c,3);assert(c.state()==State::Fault&&!f.torque);
 }
 {now=0;RecoveryServo f;f.p=412;CoverController c(f);auto s=settings();s.minimum=0;s.maximum=4095;s.timeoutMs=26000;
  s.hasTravelArc=true;s.arc.closedRaw=397;s.arc.direction=-1;s.arc.length=1789;s.arc.circular=true;s.arc.maximumRaw=4095;
  assert(c.configure(s));c.stop();assert(c.moveEndpoint(2704,true,true));f.p=413;poll(c,3);assert(c.state()==State::Fault&&!f.torque);
 }
 // Saved endpoint commands span the taught arc despite the independent jog cap.
 {struct ArcFake:Fake {
   bool endpoint=false;
   bool rolloverSupported() const override{return true;}
   ServoResult moveCalibratedEndpoint(uint16_t target,uint16_t speed,uint8_t acceleration,const TravelArc& arc) override {
    endpoint=true;assert(arc.length==885);return moveTo(target,speed,acceleration,0,4095);
   }
  } f;
  now=0;f.p=3528;f.stepLimit=100;CoverController c(f);auto s=settings();
  s.minimum=0;s.maximum=4095;s.timeoutMs=15000;s.hasTravelArc=true;
  s.arc.closedRaw=317;s.arc.direction=-1;s.arc.length=885;s.arc.circular=true;s.arc.maximumRaw=4095;
  assert(c.configure(s));assert(!c.manualJog(500,true));assert(!f.enables);
  assert(c.moveEndpoint(317,false,true));assert(f.endpoint && f.goal==317 && c.state()==State::Closing);
 }
 // Driver commissioning limits reject oversized jogs before torque or a goal.
 {now=0;Fake f;f.stepLimit=100;CoverController c(f);assert(c.configure(settings()));
  for(int step:{-500,-101,101,500}){assert(!c.manualJog(step,true));assert(!c.jog(step,true));}
  assert(!f.enables&&!f.moves&&!f.releases);
  assert(c.manualJog(100,true));f.p=f.goal;poll(c,5);assert(c.state()==State::Stopped&&!f.torque);
 }
 // A measured approach followed by normal in-band rebound must settle in both
 // directions, for Manual, calibration jogs and endpoint moves alike.
 for(int direction:{-1,1})for(int mode:{0,1,2,3}){
  now=0;Fake f;f.p=2000;CoverController c(f);auto s=settings();s.minimum=0;s.maximum=4095;s.timeoutMs=29000;
  assert(c.configure(s));
  const int target=2000+direction*100;
  assert(mode==0?c.jog(direction*100,true):mode==1?c.manualJog(direction*100,true):c.moveEndpoint(target,mode==2,true));
  for(int step=2;step<=100;step+=2){f.p=2000+direction*step;poll(c);assert(c.moving());}
  f.p=target+direction*(mode<2?20:10);poll(c,4);assert(c.moving());poll(c);
  assert(c.state()==(mode<2?State::Stopped:mode==2?State::Open:State::Closed));assert(!f.torque);
 }
 // Replay the measured 2494 -> 2594 goal continuing past target to 2641.
 // Keep the stop, identify overshoot, and never claim this is reversed motion.
 for(int direction:{-1,1}){
  now=0;Fake f;f.p=2494;CoverController c(f);auto s=settings();s.minimum=0;s.maximum=4095;s.timeoutMs=29000;
  assert(c.configure(s));assert(c.manualJog(direction*100,true));
  for(int delta:{0,5,16,26,37,48,58,69,79,89,100,110,120,131,142,147}){
   f.p=2494+direction*delta;now+=101;c.tick(true);
  }
  assert(c.state()==State::Fault && !f.torque && c.torqueOffConfirmed());
  assert(!strcmp(c.fault(),"Repeated target overshoot"));
  MotionFaultEvidence evidence;c.copyFault(evidence);
  assert(evidence.wrongSamples==3 && c.trace().failedReads==0);
  bool found=false;for(const auto& sample:c.trace().samples)found|=sample.disposition==PositionDisposition::TargetOvershoot;
  assert(found);
 }
 // Confirm progress at the sampled speed; a fixed three-count/poll filter
 // would lag behind these valid reads and miss genuine backtracking.
 {now=0;Fake f;f.p=1000;CoverController c(f);auto s=settings();s.minimum=0;s.maximum=4095;
  assert(c.configure(s));assert(c.manualJog(500,true));
  for(int p:{1100,1200,1250}){f.p=p;poll(c);assert(c.moving());}
  f.p=1120;poll(c,2);assert(c.moving());poll(c);assert(c.state()==State::Fault && !f.torque);
  assert(!strcmp(c.fault(),"Repeated movement away from target"));
 }
 // An isolated closer outlier (including one followed by a read failure)
 // cannot promote an impossible progress baseline and manufacture a fault.
 for(bool lostRead:{false,true}){
  now=0;Fake f;f.p=1000;CoverController c(f);auto s=settings();s.minimum=0;s.maximum=4095;
  assert(c.configure(s));assert(c.manualJog(500,true));f.p=1100;poll(c,2);
  f.p=1499;poll(c);if(lostRead){f.failRead=true;poll(c);f.failRead=false;}
  f.p=1110;poll(c,6);assert(c.moving());c.stop();assert(!f.torque);
 }
 // Wrong direction, overshoot and discontinuity need their own consecutive
 // evidence; one observation of each cannot be counted as three of one kind.
 {now=0;Fake f;f.p=1000;CoverController c(f);auto s=settings();s.minimum=0;s.maximum=4095;
  assert(c.configure(s));assert(c.manualJog(100,true));f.p=1100;poll(c,2);
  for(int p:{990,1125,3500,1125}){f.p=p;poll(c);assert(c.moving());}
  f.p=1110;poll(c);assert(c.moving()); // Valid in-band feedback resets the evidence.
  f.p=1125;poll(c,2);assert(c.moving());f.p=1105;poll(c,5);
  assert(c.state()==State::Stopped && !f.torque);
 }
 // Manual recovery can start beyond saved limits without widening normal motion.
 for(bool arc:{false,true})for(int direction:{1,-1}) {
  now=0;Fake f;f.p=2200;CoverController c(f);auto s=settings();
  if(arc){s.minimum=0;s.maximum=4095;s.hasTravelArc=true;s.arc.closedRaw=direction==1?2000:2100;s.arc.direction=direction;s.arc.length=100;s.arc.minimumRaw=0;s.arc.maximumRaw=4095;s.arc.circular=true;}
  const int closed=direction==1?2000:2100,open=direction==1?2100:2000;
  assert(!c.initializeStationary(s,closed,open));
  assert(c.initializeStationary(s,closed,open,false,true));assert(!c.positionInRange());
  assert(f.moves==0 && f.enables==0 && !f.torque);
  assert(!c.jog(-100,true) && !c.moveEndpoint(2100,true,true));
  assert(c.manualJog(-100,true));assert(f.goal==2100 && f.minimum==0 && f.maximum==4095);
  f.p=2100;poll(c,5);assert(c.state()==State::Stopped && !f.torque && c.positionInRange());
  assert(c.manualJog(100,true));f.p=2200;poll(c,5);assert(c.state()==State::Stopped && !f.torque);
  assert(!c.jog(-100,true) && !c.moveEndpoint(2100,true,true));
  assert(c.manualJog(-10,true));poll(c,1,false);assert(c.state()==State::Fault);
  assert(!c.manualJog(-10,true) && !c.recover());assert(c.recover(true));assert(!f.torque);
  assert(c.manualJog(-10,true));f.p=2210;poll(c,3);assert(c.state()==State::Fault && !f.torque);
 }
 // Manual still rejects uncommissioned raw rollover, invalid feedback/configuration,
 // missing path clearance and timeouts. Returning from Manual restores saved bounds.
 {now=0;Fake f;CoverController c(f);assert(c.configure(settings()));
  for(uint16_t p:{0,4095}){f.p=p;assert(!c.manualJog(p?10:-10,true));}
  f.p=2200;assert(!c.manualJog(10,false));f.valid=false;assert(!c.manualJog(10,true));assert(f.enables==0);
  f.valid=true;assert(c.recover(true));f.failRead=true;assert(!c.manualJog(10,true));f.failRead=false;assert(c.recover(true));
  f.p=5000;assert(!c.manualJog(-100,true));f.p=2200;
  assert(c.manualJog(-100,true));now+=5000;c.tick(true);assert(c.state()==State::Fault && !f.torque);
  assert(c.recover(true));f.p=2045;assert(c.manualJog(10,true));f.p=2055;poll(c,5);
  assert(!c.jog(100,true));assert(c.jog(-10,true) && f.minimum==2000 && f.maximum==2100);c.stop();
 }
 // Overcurrent is a device fault requiring external power cycling, not a generic
 // transport timeout. It faults immediately; unsuccessful release is explicit.
 for(uint8_t status:{8,9}){now=0;Fake f;CoverController c(f);assert(c.configure(settings()));assert(c.manualJog(10,true));
  f.deviceStatus=status;poll(c);assert(c.state()==State::Fault && !c.torqueOffConfirmed());
  assert(strstr(c.fault(),"overcurrent") && strstr(c.fault(),"cycle servo power"));
  assert(!c.recover(true) && !c.manualJog(10,true));
  f.deviceStatus=0;assert(c.recover(true));assert(!f.torque && c.fault()[0]=='\0');
 }
 assert(!strcmp(servoFaultReason({ServoError::Timeout},"timeout"),"timeout"));
 assert(!strcmp(servoFaultReason({ServoError::DeviceError,32},"other fault"),"other fault"));
 // Fault evidence precedes release, survives explicit recovery/new motion, and
 // reports repeated rejected observations without promoting them to position.
 {now=0;Fake f;CoverController c(f);assert(c.configure(settings()));assert(c.moveEndpoint(2080,true,true));
  f.p=1999;poll(c,3);assert(c.state()==State::Fault);MotionFaultEvidence evidence;c.copyFault(evidence);
  assert(evidence.sequence==1 && evidence.limitSamples==3 && evidence.releaseConfirmed);
  assert(evidence.servo.torqueValid && evidence.servo.torque && !f.torque); // Captured before release.
  assert(evidence.traceAvailable && evidence.acceptedPosition==2045 && c.trace().rejectedReads==3);
  assert(c.trace().lastPosition==1999); // Valid transport observation, explicitly rejected by controller.
  assert(c.trace().samples[1].disposition==PositionDisposition::OutsideLimits);
  f.p=2045;assert(c.recover());assert(c.moveEndpoint(2050,true,true));c.copyFault(evidence);
  assert(evidence.sequence==1 && evidence.limitSamples==3 && evidence.acceptedPosition==2045);
 }
 {now=0;Fake f;CoverController c(f);assert(c.configure(settings()));f.valid=false;
  assert(!c.moveEndpoint(2050,true,true));MotionFaultEvidence evidence;c.copyFault(evidence);
  assert(evidence.sequence==1 && !evidence.traceAvailable && !evidence.positionKnown);
 }
 // Copy into a reusable status buffer: live settling, independent snapshots,
 // and a new operation must not expose samples/counters from the previous move.
 {now=0;Fake f;CoverController c(f);assert(c.configure(settings()));
  assert(c.moveEndpoint(2050,true,true));f.p=2050;poll(c,4);
  MotionTrace snapshot;c.copyTrace(snapshot);
  assert(snapshot.settled==4 && snapshot.operation==1 && snapshot.target==2050);
  const auto previousReads=snapshot.validReads;poll(c);
  assert(snapshot.validReads==previousReads && snapshot.settled==4);
  c.copyTrace(snapshot);assert(snapshot.settled==5 && c.state()==State::Open);
  assert(c.moveEndpoint(2040,false,true));c.copyTrace(snapshot);
  assert(snapshot.operation==2 && snapshot.target==2040 && snapshot.tolerance==10);
  assert(snapshot.validReads==1 && snapshot.failedReads==0 && snapshot.settled==0);
  assert(snapshot.count==1 && snapshot.next==1 && snapshot.lastPosition==2050);
  for(unsigned i=1;i<MotionTrace::capacity;++i)
   assert(snapshot.samples[i].elapsedMs==0 && snapshot.samples[i].position==0 && !snapshot.samples[i].valid);
 }
 // Reboot hold takes over a supervised jog without any torque-off write.
 for(bool retain:{false,true}){
  now=0;Fake f;CoverController c(f);assert(c.configure(settings()));
  assert(c.jog(1,true,true));f.p=2046;poll(c,5);assert(c.holding());
  const int releases=f.releases;
  assert(c.prepareReboot(retain));assert(f.torque==retain && !c.holding() && !c.moving());
  if(retain){assert(f.releases==releases);poll(c,20,false);assert(f.torque);}
  CoverController restarted(f);
  assert(restarted.initializeStationary(settings(),-1,-1,true));
  assert(f.torque==retain && restarted.torqueOffConfirmed()==!retain);
  assert(restarted.jog(1,true,true));assert(!retain || f.releases==releases);
  restarted.stop();assert(!f.torque);
 }
 {now=0;Fake f;CoverController c(f);assert(c.configure(settings()));
  assert(c.prepareReboot(true));assert(f.torque && f.goal==0); // Fake enable stages no motion command.
  CoverController normalBoot(f);assert(!normalBoot.initializeStationary(settings()));
  f.failRead=true;assert(!c.prepareReboot(true));assert(c.state()==State::Fault && !f.torque);
 }
 {now=0;Fake f;CoverController c(f);assert(c.configure(settings()));assert(c.jog(10,true));
  assert(!c.prepareReboot(true));assert(c.moving());c.stop();}

 for(bool disable:{false,true})for(bool opening:{false,true}){
  now=0;Fake f;CoverController c(f);auto config=settings();config.disableTorqueAfterMove=disable;
  assert(!MotionSettings{}.disableTorqueAfterMove);assert(c.configure(config));
  assert(c.moveEndpoint(2050,opening,true));f.p=2050;poll(c,5);
  assert(!c.moving() && f.torque==!disable && c.torqueOffConfirmed()==disable);
  poll(c,20,false);assert(f.torque==!disable); // Completed hold is independent of browser heartbeat.
  const auto releases=f.releases;
  assert(c.moveEndpoint(2040,!opening,true));assert(disable || f.releases==releases);
  poll(c,1,false);assert(c.state()==State::Fault && !f.torque);
  assert(c.recover());assert(c.moveEndpoint(2050,opening,true));f.p=2050;poll(c,5);
  c.stop();assert(!f.torque && c.torqueOffConfirmed());
 }

 // Reproduce an endpoint eleven counts away: evidence survives torque release and idle ticks.
 {now=0;Fake f;f.p=2050;CoverController c(f);assert(c.configure(settings()));
  assert(c.moveEndpoint(2040,false,true));f.p=2051;poll(c,100);
  assert(c.state()==State::Fault&&!f.torque&&!strcmp(c.fault(),"Movement timeout"));
  auto t=c.trace();assert(t.target==2040&&t.tolerance==10&&t.lastPosition==2051);
  assert(t.validReads>=90&&t.failedReads==0&&t.settled==0&&t.count>40);
  const auto count=t.validReads;f.p=2040;poll(c,10);assert(c.trace().validReads==count&&c.trace().lastPosition==2051);
  assert(c.recover());assert(c.moveEndpoint(2050,true,true));assert(c.trace().operation==2&&c.trace().count==1);}
 // Ring remains bounded on long moves and failed reads are never position zero evidence.
 {now=0;Fake f;CoverController c(f);auto s=settings();s.timeoutMs=10000;assert(c.configure(s));
  assert(c.moveEndpoint(2080,true,true));poll(c,150);assert(c.trace().count==MotionTrace::capacity);
  auto t=c.trace();auto oldest=t.samples[t.next].elapsedMs;assert(oldest>0);
  f.failRead=true;poll(c,3);t=c.trace();assert(t.failedReads==3&&t.lastPosition==2045&&c.state()==State::Fault);
  bool failed=false;for(unsigned i=0;i<t.count;++i)failed|=!t.samples[i].valid;assert(failed);}
 // Measured plateau and both inclusive ten-count boundaries require stable samples.
 for(bool opening:{false,true})for(int offset:{-10,-5,-4,4,5,10}){
  now=0;Fake f;f.p=opening?2020:2080;CoverController c(f);assert(c.configure(settings()));
  assert(c.moveEndpoint(2050,opening,true));f.p=2050+offset;
  poll(c,4);assert(c.moving()&&f.torque);poll(c);
  assert(c.state()==(opening?State::Open:State::Closed)&&!f.torque);
 }
 // Landing ten counts away after briefly reaching target is normal settling.
 for(int offset:{-10,10}){
  now=0;Fake f;f.p=2020;CoverController c(f);assert(c.configure(settings()));
  assert(c.moveEndpoint(2050,true,true));f.p=2050;poll(c,4);
  f.p=2050+offset;poll(c,4);assert(c.moving());poll(c);
  assert(c.state()==State::Open && c.position()==2050+offset);
 }
 // Eleven counts in either direction remains outside the accepted band.
 for(int offset:{-11,11}){
  now=0;Fake f;f.p=2020;CoverController c(f);assert(c.configure(settings()));
  assert(c.moveEndpoint(2050,true,true));f.p=2050+offset;poll(c,5);
  assert(c.moving() && c.trace().settled==0);
  now+=5000;c.tick(true);assert(c.state()==State::Fault && !f.torque);
 }
 // Boot classification uses the same inclusive band at both endpoints.
 for(int endpoint:{2020,2080})for(int offset:{-11,-10,10,11}){
  now=0;Fake f;f.p=endpoint+offset;CoverController c(f);
  assert(c.initializeStationary(settings(),2020,2080));
  const State expected=(offset==-11 || offset==11)?State::Unknown:
    (endpoint==2020?State::Closed:State::Open);
  assert(c.state()==expected && f.moves==0 && f.enables==0);
 }
 {Fake f;CoverController c(f);
  assert(!c.initializeStationary(settings(),2040,2060));
  assert(c.initializeStationary(settings(),2040,2061));}
 // Crossing the widened band does not count as a stable five-sample window.
 {now=0;Fake f;f.p=2020;CoverController c(f);assert(c.configure(settings()));assert(c.moveEndpoint(2050,true,true));
  for(int p:{2045,2047,2049,2051,2053}){f.p=p;poll(c);assert(c.moving());}
  f.p=2053;poll(c,5);assert(c.state()==State::Open);}
 // A failed read breaks the consecutive sample requirement.
 {now=0;Fake f;CoverController c(f);assert(c.configure(settings()));assert(c.moveEndpoint(2060,true,true));
  f.p=2064;poll(c,4);f.failRead=true;poll(c);f.failRead=false;poll(c,4);assert(c.moving());poll(c);assert(c.state()==State::Open);}
 // Fine steps must not settle at their starting position within a wide tolerance.
 for(int step:{1,10}){
  Fake fine;CoverController controller(fine);assert(controller.configure(settings()));
  assert(controller.jog(step,true));poll(controller,5);assert(controller.moving());
  fine.p+=step;poll(controller,5);assert(controller.state()==State::Stopped && !fine.torque);
 }
 // Small jogs can settle short or long without Stop before the next command.
 // Scale the error band so an unchanged starting position never completes a jog.
 for(int step:{1,5,10,20,50,100})for(int direction:{-1,1})for(bool retain:{false,true}){
  const int tolerance=step/5<20?step/5:20;
  for(int error:{-tolerance,tolerance}){
   now=0;Fake fine;CoverController controller(fine);auto s=settings();s.minimum=1000;s.maximum=3000;
   assert(controller.configure(s));assert(controller.jog(direction*step,true,retain));
   assert(controller.trace().tolerance==tolerance);
   poll(controller,5);assert(controller.moving() && controller.trace().settled==0);
   fine.p=fine.goal+error;poll(controller,4);assert(controller.moving());poll(controller);
   assert(!controller.moving() && controller.holding()==retain && fine.torque==retain);
   const int measured=fine.p,releases=fine.releases,enables=fine.enables;
   assert(controller.jog(-direction*step,true,retain));assert(fine.goal==measured-direction*step);
   if(retain)assert(fine.releases==releases && fine.enables==enables);
   fine.p=fine.goal-direction; // Reproduce a ten-count step moving only nine counts.
   if(step==10){poll(controller,5);assert(!controller.moving() && controller.holding()==retain);}
  }
 }
 // The ten-count band is inclusive at two counts; three-count errors time out.
 for(int direction:{-1,1})for(int error:{-3,3}){
  now=0;Fake fine;CoverController controller(fine);assert(controller.configure(settings()));
  assert(controller.jog(direction*10,true));fine.p=fine.goal+error;
  poll(controller,5);assert(controller.moving() && controller.trace().settled==0);
  now+=5000;controller.tick(true);assert(controller.state()==State::Fault && !fine.torque);
 }
 // Failed feedback also breaks the stable window for fine steps.
 {now=0;Fake fine;CoverController controller(fine);assert(controller.configure(settings()));
  assert(controller.jog(10,true));fine.p=fine.goal-1;poll(controller,4);
  fine.failRead=true;poll(controller);fine.failRead=false;poll(controller,4);
  assert(controller.moving());poll(controller);assert(controller.state()==State::Stopped && !fine.torque);
 }
 // Inspected temporary ranges keep faults latched and never energize the motor.
 Fake inspected;CoverController working(inspected);assert(working.configure(settings()));
 assert(working.jog(10,true));poll(working,1,false);assert(working.state()==State::Fault);
 MotionSettings expanded=settings();expanded.minimum=1900;expanded.maximum=2200;
 int inspectedMoves=inspected.moves,inspectedEnables=inspected.enables;
 assert(working.applyStationarySettings(expanded));assert(working.state()==State::Fault);
 assert(inspected.moves==inspectedMoves && inspected.enables==inspectedEnables && !inspected.torque);
 assert(working.recover());assert(working.setMotionProfile(400,20,15000));
 assert(!working.setMotionProfile(1601,20,15000));assert(!working.setMotionProfile(400,101,15000));
 Fake probe;probe.p=3482;CoverController diagnostic(probe);now=100;
 assert(diagnostic.startTorqueTest());assert(diagnostic.torqueTesting()&&probe.moves==0&&probe.torque);
 now=849;diagnostic.tick(false);assert(diagnostic.torqueTesting());
 now=850;diagnostic.tick(false);assert(diagnostic.state()==State::Fault&&!probe.torque&&probe.moves==0);
 assert(diagnostic.startTorqueTest());probe.failRead=true;now+=100;diagnostic.tick(false);assert(diagnostic.state()==State::Fault&&!probe.torque);
 probe.failRead=false;probe.torque=true;assert(!diagnostic.startTorqueTest());probe.torque=false;
 assert(diagnostic.startTorqueTest());probe.p+=30;now+=100;diagnostic.tick(false);assert(diagnostic.state()==State::Fault&&!probe.torque);
 MotionSettings revised=settings();revised.minimum=3300;revised.maximum=3600;
 assert(diagnostic.initializeStationary(revised));assert(probe.moves==0 && !probe.torque);

 Fake setup;setup.p=477;CoverController startup(setup);MotionSettings bounds=settings();
 assert(!startup.initializeStationary(bounds)); // No automatic expansion of the defaults.
 bounds.minimum=450;bounds.maximum=2000;
 setup.torque=true;assert(!startup.initializeStationary(bounds));setup.torque=false;
 setup.valid=false;assert(!startup.initializeStationary(bounds));setup.valid=true;
 setup.failRead=true;assert(!startup.initializeStationary(bounds));setup.failRead=false;
 setup.unstable=true;assert(!startup.initializeStationary(bounds));setup.unstable=false;setup.p=477;
 assert(startup.initializeStationary(bounds));
 assert(startup.state()==State::Unknown && startup.position()==477);
 assert(setup.moves==0 && setup.enables==0 && setup.releases==0 && !setup.torque);
 assert(startup.initializeStationary(bounds,477,1975) && startup.state()==State::Closed);
 setup.p=1973;assert(startup.initializeStationary(bounds,477,1975) && startup.state()==State::Open);
 setup.p=488;assert(startup.initializeStationary(bounds,477,1975) && startup.state()==State::Unknown);
 setup.p=487;assert(startup.initializeStationary(bounds,477,1975) && startup.state()==State::Closed);
 assert(startup.initializeStationary(bounds,1975,477) && startup.state()==State::Open);
 assert(!startup.initializeStationary(bounds,477,480));
 setup.p=1000;assert(startup.initializeStationary(bounds,477,1975) && startup.state()==State::Unknown);
 assert(setup.moves==0 && setup.enables==0 && setup.releases==0);
 assert(startup.jog(100,true));assert(!startup.initializeStationary(bounds));startup.stop();

 Fake f; CoverController c(f); assert(c.state()==State::Unknown && !c.jog(20,true));
 assert(c.configure(settings()));assert(!c.jog(20,false));assert(!c.jog(100,true));assert(f.moves==0);
 assert(c.jog(20,true));assert(c.moving() && f.torque);assert(!c.jog(1,true));
 f.p=0;poll(c);assert(c.moving());f.p=2048;poll(c);assert(c.moving());
 f.p=2065;poll(c,5);assert(c.state()==State::Stopped && !f.torque && c.torqueOffConfirmed());
 assert(c.jog(-20,true));f.p=2045;poll(c,5);assert(c.state()==State::Stopped);
 assert(c.jog(20,true));f.p=2035;poll(c,2);assert(c.moving());poll(c);assert(c.state()==State::Fault && !f.torque);
 assert(!c.jog(20,true));c.stop();assert(c.state()==State::Fault);assert(c.recover());assert(c.state()==State::Unknown);
 f.p=2045;assert(c.jog(20,true));f.failRead=true;poll(c,2);assert(c.moving());poll(c);assert(c.state()==State::Fault);f.failRead=false;assert(c.recover());
 assert(c.jog(20,true));now+=5000;c.tick(true);assert(c.state()==State::Fault && !f.torque);assert(c.recover());
 assert(c.jog(20,true));poll(c,1,false);assert(c.state()==State::Fault && !f.torque);assert(c.recover());
 f.valid=false;assert(!c.jog(20,true));assert(c.state()==State::Fault);f.valid=true;assert(c.recover());
 f.failMove=true;assert(!c.jog(20,true));assert(c.state()==State::Fault && !f.torque);f.failMove=false;assert(c.recover());
 assert(c.jog(20,true));f.failRelease=true;c.stop();assert(c.state()==State::Fault && !c.torqueOffConfirmed());f.failRelease=false;assert(c.recover());
 assert(c.jog(20,true));f.p=0;poll(c,3);assert(c.state()==State::Fault);f.p=2045;assert(c.recover());
 now=0xfffffff0;assert(c.jog(20,true));now+=5001;c.tick(true);assert(c.state()==State::Fault);
 Fake endpoint;CoverController e(endpoint);assert(e.configure(settings()));
 assert(!e.moveEndpoint(2200,true,true) && endpoint.moves==0);
 assert(!e.moveEndpoint(2060,true,false));
 assert(e.moveEndpoint(2060,true,true) && e.state()==State::Opening && e.moving());
 endpoint.p=2060;poll(e,5);assert(e.state()==State::Open && !endpoint.torque);
 assert(e.moveEndpoint(2020,false,true) && e.state()==State::Closing);
 e.stop();assert(e.state()==State::Stopped);
 assert(e.moveEndpoint(2020,false,true));endpoint.p=2020;poll(e,5);assert(e.state()==State::Closed && !endpoint.torque);
 assert(e.configure(settings()) && e.state()==State::Unknown);
 assert(e.moveEndpoint(2050,true,true));poll(e,1,false);assert(e.state()==State::Fault && !endpoint.torque);
 Fake wideServo;CoverController wide(wideServo);MotionSettings wideSettings=settings();wideSettings.minimum=1000;wideSettings.maximum=3000;
 assert(wide.configure(wideSettings));assert(wide.jog(100,true)&&wideServo.goal==2145);wide.stop();
 assert(wide.jog(-100,true)&&wideServo.goal==1945);wide.stop();assert(!wide.jog(501,true));
 Fake recoveryServo;CoverController recovery(recoveryServo);assert(recovery.configure(settings()));
 assert(recovery.jog(20,true));poll(recovery,1,false);assert(recovery.state()==State::Fault);
 const int movesBefore=recoveryServo.moves;
 recoveryServo.valid=false;assert(!recovery.recover());recoveryServo.valid=true;
 recoveryServo.failRead=true;assert(!recovery.recover());recoveryServo.failRead=false;
 recoveryServo.p=1900;assert(!recovery.recover());recoveryServo.p=2045;
 recoveryServo.unstable=true;assert(!recovery.recover());recoveryServo.unstable=false;recoveryServo.p=2045;
 recoveryServo.failRelease=true;assert(!recovery.recover());recoveryServo.failRelease=false;
 assert(recovery.recover());assert(recovery.state()==State::Unknown&&!recovery.moving()&&!recoveryServo.torque);
 assert(recoveryServo.moves==movesBefore);assert(!recovery.recover());
 // Loaded-cover examples: measured error 14 and 13 counts, both directions.
 for(int direction : {1,-1}) {
  Fake loaded;loaded.p=483;CoverController jog(loaded);MotionSettings m=settings();m.minimum=0;m.maximum=1000;
  assert(jog.configure(m));assert(jog.jog(direction*100,true));
  loaded.p=loaded.goal-direction*14;poll(jog,4);assert(jog.moving());poll(jog);
  assert(jog.state()==State::Stopped&&!loaded.torque&&jog.position()==loaded.p);
 }
 Fake loaded;loaded.p=484;CoverController jog(loaded);MotionSettings m=settings();m.minimum=0;m.maximum=1000;
 assert(jog.configure(m));assert(jog.jog(100,true));loaded.p=571;poll(jog,5);assert(jog.state()==State::Stopped);
 loaded.p=484;assert(jog.jog(100,true));loaded.p=563;poll(jog,8);assert(jog.moving());
 loaded.p=564;poll(jog,4);assert(jog.moving());loaded.failRead=true;poll(jog);loaded.failRead=false;
 poll(jog,4);assert(jog.moving());poll(jog);assert(jog.state()==State::Stopped);
 loaded.p=484;assert(jog.jog(100,true));
 for(uint16_t p=564;p<=580;p+=4){loaded.p=p;poll(jog);assert(jog.moving());}
 poll(jog,4);assert(jog.state()==State::Stopped);
 loaded.p=484;assert(jog.jog(100,true));loaded.p=563;poll(jog,5);now+=5000;jog.tick(true);
 assert(jog.state()==State::Fault&&!loaded.torque);assert(jog.recover());
 for(bool opening : {true,false}) {
  loaded.p=484;assert(jog.moveEndpoint(584,opening,true));loaded.p=570;poll(jog,8);assert(jog.moving());
  loaded.p=581;poll(jog,5);assert(jog.state()==(opening?State::Open:State::Closed));
 }
 Fake support;support.p=500;CoverController held(support);assert(held.configure(m));
 assert(held.jog(100,true,true));support.p=586;poll(held,5);
 assert(held.holding()&&!held.moving()&&support.torque&&!held.torqueOffConfirmed());
 const int releases=support.releases,enables=support.enables;
 assert(!held.configure(m)&&!held.moveEndpoint(700,true,true)&&!held.jog(100,true,false));
 now+=6000;held.tick(true);assert(held.holding()&&support.torque); // Idle hold isn't motion timeout.
 assert(held.jog(100,true,true));assert(support.releases==releases&&support.enables==enables);
 support.p=672;poll(held,5);assert(held.holding());held.stop();assert(!held.holding()&&!support.torque);
 assert(held.jog(100,true,true));support.p=758;poll(held,5);assert(held.holding());
 held.tick(false);assert(held.state()==State::Fault&&!support.torque);assert(held.recover());
 assert(held.jog(-100,true,true));support.p=672;poll(held,5);assert(held.holding());
 support.p=730;poll(held,2);assert(held.holding());poll(held);assert(held.state()==State::Fault&&!support.torque);assert(held.recover());
 assert(held.jog(-100,true,true));support.p=644;poll(held,5);assert(held.holding());
 support.failRead=true;poll(held,3);assert(held.state()==State::Fault&&!support.torque);
 puts("Cover controller safety tests passed");
 // Fresh repeated telescope clearance gates Close and is revoked during movement.
 for(unsigned reason=0;reason<5;++reason){
  Fake servo;CoverController cover(servo);assert(cover.configure(settings()));now=1000;
  alpaca::Snapshot scope;scope.enabled=scope.valid=scope.connected=scope.canFindHome=scope.atHome=true;
  scope.sampledAt=now;scope.consecutiveStowed=1;
  assert(!cover.moveEndpoint(2020,false,scope.stowedCandidate(now)) && servo.moves==0);
  scope.consecutiveStowed=2;assert(cover.moveEndpoint(2020,false,scope.stowedCandidate(now)));
  if(reason==0)scope.atHome=false;
  if(reason==1)scope.slewing=true;
  if(reason==2)scope.tracking=true;
  if(reason==3)scope.connected=false;
  if(reason==4)scope.sampledAt=now-5001;
  cover.tick(true,scope.stowedCandidate(now));assert(cover.state()==State::Fault && !servo.torque);
  assert(strcmp(cover.fault(),"Telescope stow confirmation lost")==0);
  scope.atHome=true;scope.slewing=scope.tracking=false;scope.connected=true;scope.sampledAt=now;
  cover.tick(true,scope.stowedCandidate(now));assert(cover.state()==State::Fault && servo.moves==1);
 }
}
