#include "emergency_shutdown.h"
#include "seestar_power.h"
#include <cJSON.h>
#include <cassert>
#include <cstring>
#include <cstdio>
#include <initializer_list>
using namespace cover;
bool parse(const char* device,const char* camera,const char* app,const char* plans,ShutdownNative& out){
 auto d=cJSON_Parse(device),c=cJSON_Parse(camera),a=cJSON_Parse(app),p=cJSON_Parse(plans);
 const bool result=parseShutdownNative(d,c,a,p,100,out);cJSON_Delete(d);cJSON_Delete(c);cJSON_Delete(a);cJSON_Delete(p);return result;
}
int main(){
 const char* device=R"({"device":{"product_model":"Seestar S30 Pro"},"mount":{"close":true,"tracking":false,"move_type":"none"}})";
 const char* camera=R"({"state":"idle"})";
 const char* app=R"({"FocuserMove":{"state":"complete"},"ViewPlan":{"state":"cancel"},"selected_cam":"View"})";
 ShutdownNative s;assert(parse(device,camera,app,"[]",s)&&s.quiet(101)&&s.closed);
 assert(parse(device,camera,"{}","[]",s)&&s.quiet(101));
 for(const auto* activity:{"working","paused","waiting","unknown"}){
  char data[160];snprintf(data,sizeof(data),"{\"SecondView\":{\"state\":\"%s\"}}",activity);
  assert(parse(device,camera,data,"[]",s)&&!s.quiet(101));
 }
 assert(parse(device,R"({"state":"exposing"})",app,"[]",s)&&!s.quiet(101));
 assert(parse(device,camera,R"({"View":{"state":"cancel","Stack":{"state":"working"}}})","[]",s)&&!s.quiet(101));
 assert(parse(device,camera,app,"[{}]",s)&&!s.quiet(101));
 for(const auto* missing:{"{}","null",R"({"state":false})"})assert(!parse(device,missing,app,"[]",s)&&!s.valid);
 for(const auto* bad:{"null","[]",R"({"View":{}})",R"({"View":{"state":true}})",R"({"View":false})"})assert(!parse(device,camera,bad,"[]",s)&&!s.valid);
 assert(!parse("{}",camera,app,"[]",s));assert(!parse(device,camera,app,"{}",s));
 assert(parse(device,camera,app,"[]",s)&&!s.quiet(3100));
 puts("Native shutdown evidence: real idle schema, wide-camera activity, plans, capture, malformed/unknown states, and freshness passed");
}
