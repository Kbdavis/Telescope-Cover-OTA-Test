#include "servo_controller.h"
#include <assert.h>
#include <stdio.h>
unsigned long millis() { static unsigned long now; return now++; }
void yield() {}
class Bus : public Stream {
 public:
  unsigned writes = 0;
  int available() override { return 0; }
  int read() override { return -1; }
  size_t write(const uint8_t*, size_t count) override { ++writes; return count; }
};
int main() {
  Bus bus;
  cover::ServoController servo(bus);
  assert(servo.releaseTorque().error == cover::ServoError::InvalidArgument);
  assert(bus.writes == 0);
  assert(servo.ping().error == cover::ServoError::Timeout);
  assert(bus.writes == 3 && servo.retryCount() == 2);
  uint8_t snapshot[40];for(auto& byte:snapshot)byte=0xa5;
  assert(servo.readConfigurationSnapshot(snapshot).error==cover::ServoError::Timeout);
  for(auto byte:snapshot)assert(byte==0xa5);
  assert(bus.writes==6);
  puts("Read-only guard checks passed");
}
