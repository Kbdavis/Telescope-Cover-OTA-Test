#include "memory_failures.h"
#include <cassert>
#include <cstdio>
#include <thread>
#include <vector>
using namespace cover;
int main(){
 AllocationFailures f;AllocationFailureSample s;
 f.failure(1024,3);assert(f.count==0);
 f.enabled=true;f.failure(2048,5);
 assert(f.count==1 && f.snapshot(s) && s.sequence==1 && s.size==2048 && s.caps==5);
 assert(!f.busy.test_and_set());f.failure(4096,7);assert(f.count==2 && f.metadataLost==1);
 assert(!f.snapshot(s));f.busy.clear();assert(f.snapshot(s) && s.sequence==1);
 std::vector<std::thread> threads;
 for(unsigned n=0;n<4;++n)threads.emplace_back([&]{for(unsigned i=0;i<10000;++i)f.failure(8192,9);});
 for(auto& t:threads)t.join();
 assert(f.count==40002 && f.snapshot(s) && s.size==8192 && s.caps==9);
 f.enabled=false;f.failure(1,1);assert(f.count==40002);
 assert(usbMemoryWindow(179999,0) && !usbMemoryWindow(180000,0));
 assert(usbMemoryWindow(99,UINT32_MAX-100) && !usbMemoryWindow(180000,UINT32_MAX-100));
 assert(usbMemoryWindow(599999,0,600000) && !usbMemoryWindow(600000,0,600000));
 puts("Allocation failure recorder: disabled gate, coherent nonblocking metadata, contention counts, concurrency and timed window passed");
}
