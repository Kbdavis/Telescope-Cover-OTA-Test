#include "emergency_shutdown.h"
#include <cassert>
#include <cstdio>
#include <initializer_list>
using namespace cover;
ShutdownEvidence evidence(uint32_t now,uint32_t sequence,bool stowed=false){
 ShutdownEvidence e;e.coverReady=e.coverStationary=e.coverOpen=e.torqueOff=e.positionFresh=e.calibrationClean=true;
 e.scope.enabled=e.scope.valid=e.scope.connected=e.scope.canFindHome=true;e.scope.sampledAt=now;e.scope.sequence=sequence;
 e.scope.atHome=stowed;e.scope.consecutiveStowed=stowed?2:0;
 e.native.operation=1;e.native.sequence=sequence;e.native.sampledAt=now;e.native.valid=true;
 e.native.imagingIdle=e.native.cameraIdle=e.native.planIdle=true;e.native.closed=stowed;return e;
}
void ack(EmergencyShutdown& op,uint32_t now,ShutdownAction action,bool ok=true){
 auto e=evidence(now,1);e.reply={op.status().operation,now,action,true,ok,{}};op.tick(now,e);
}
void stopped(EmergencyShutdown& op){ack(op,110,ShutdownAction::StopCapture);op.tick(200,evidence(200,2));op.tick(300,evidence(300,3));}
void stowed(EmergencyShutdown& op){stopped(op);assert(op.status().phase==ShutdownPhase::Stowing);ack(op,310,ShutdownAction::Park);op.tick(400,evidence(400,4,true));op.tick(500,evidence(500,5,true));}
int main(){
 for(int guard=0;guard<9;++guard){EmergencyShutdown op;auto e=evidence(100,1);
  switch(guard){case 0:e.coverReady=false;break;case 1:e.positionFresh=false;break;case 2:e.calibrationClean=false;break;
   case 3:e.coverStationary=false;break;case 4:e.torqueOff=false;break;case 5:e.scope.enabled=false;break;
   case 6:e.scope.connected=false;break;case 7:e.scope.valid=false;break;case 8:e.coverOpen=false;break;}
  assert(!op.start(100,e));
 }
 EmergencyShutdown success;assert(success.start(100,evidence(100,1)));assert(!success.start(100,evidence(100,1)));
 stowed(success);assert(success.status().phase==ShutdownPhase::Closing);assert(success.closePermitted(500,evidence(500,5,true)));
 auto closed=evidence(600,6,true);closed.coverOpen=false;closed.coverClosed=true;success.tick(600,closed);
 assert(success.status().phase==ShutdownPhase::Complete&&!success.status().locked());
 // Tracking/capture are allowed on entry, but not as evidence of successful stop.
 EmergencyShutdown imaging;auto busy=evidence(100,1);busy.scope.tracking=true;busy.scope.slewing=true;busy.native.cameraIdle=false;
 assert(imaging.start(100,busy));ack(imaging,110,ShutdownAction::StopCapture);
 for(int i=0;i<5;++i){busy=evidence(200+i*100,i+2);busy.native.imagingIdle=false;imaging.tick(200+i*100,busy);}
 assert(imaging.status().phase==ShutdownPhase::VerifyingIdle);
 auto timeout=evidence(30200,9);imaging.tick(30200,timeout);assert(imaging.status().phase==ShutdownPhase::Fault);
 // Old, duplicate, contradictory, and wrong-operation readings cannot grant clearance.
 EmergencyShutdown fresh;assert(fresh.start(100,evidence(100,1)));ack(fresh,110,ShutdownAction::StopCapture);
 fresh.tick(150,evidence(100,1));assert(fresh.status().phase==ShutdownPhase::VerifyingIdle);
 auto e=evidence(200,2);fresh.tick(200,e);fresh.tick(210,e);assert(fresh.status().phase==ShutdownPhase::VerifyingIdle);
 e=evidence(300,3);e.native.operation=999;fresh.tick(300,e);assert(fresh.status().phase==ShutdownPhase::VerifyingIdle);
 fresh.tick(400,evidence(400,4));assert(fresh.status().phase==ShutdownPhase::Stowing);ack(fresh,410,ShutdownAction::Park);
 e=evidence(500,5,true);e.scope.slewing=true;fresh.tick(500,e);assert(fresh.status().phase==ShutdownPhase::VerifyingStow);
 fresh.tick(600,evidence(600,6,true));fresh.tick(650,evidence(600,6,true));assert(fresh.status().phase==ShutdownPhase::VerifyingStow);
 e=evidence(700,7,true);e.native.closed=false;fresh.tick(700,e);assert(fresh.status().phase==ShutdownPhase::VerifyingStow);
 fresh.tick(800,evidence(800,8,true));fresh.tick(900,evidence(900,9,true));assert(fresh.status().phase==ShutdownPhase::Closing);
 // Missing clearance during closure revokes permission immediately.
 for(int fault=0;fault<8;++fault){EmergencyShutdown op;assert(op.start(100,evidence(100,1)));stowed(op);e=evidence(600,6,true);
  switch(fault){case 0:e.scope.connected=false;break;case 1:e.native.valid=false;break;case 2:e.native.imagingIdle=false;break;
   case 3:e.native.closed=false;break;case 4:e.scope.atHome=false;break;case 5:e.positionFresh=false;break;
   case 6:e.calibrationClean=false;break;case 7:e.native.sampledAt=0;break;}
  const uint32_t now=fault==7?3100:600;
  assert(!op.closePermitted(now,e));op.tick(now,e);assert(op.status().phase==ShutdownPhase::Fault&&op.status().locked());
 }
 // An unacknowledged command is never retried or treated as completed movement.
 for(auto action:{ShutdownAction::StopCapture,ShutdownAction::Park}){EmergencyShutdown op;assert(op.start(100,evidence(100,1)));
  if(action==ShutdownAction::Park)stopped(op);ack(op,400,action,false);assert(op.status().phase==ShutdownPhase::Fault);
  op.tick(500,evidence(500,5,true));assert(op.status().phase==ShutdownPhase::Fault);
 }
 // Stop wins at every phase; a late response cannot continue the operation.
 for(int phase=0;phase<5;++phase){EmergencyShutdown op;assert(op.start(100,evidence(100,1)));
  if(phase==1)ack(op,110,ShutdownAction::StopCapture);
  if(phase>=2)stopped(op);
  if(phase>=3)ack(op,310,ShutdownAction::Park);
  if(phase==4){op.tick(400,evidence(400,4,true));op.tick(500,evidence(500,5,true));}
  op.cancel(600);assert(op.status().phase==ShutdownPhase::Cancelled);ack(op,700,ShutdownAction::Park);
  op.tick(800,evidence(800,8,true));assert(op.status().phase==ShutdownPhase::Cancelled&&!op.closePermitted(800,evidence(800,8,true)));
  e=evidence(900,9,true);e.native.cameraIdle=false;assert(!op.finish(900,e));e.native.cameraIdle=true;assert(op.finish(900,e));
  assert(op.status().phase==ShutdownPhase::Idle);
 }
 // Already-stowed telescopes skip the arm move, still needing new idle observations.
 EmergencyShutdown home;auto h=evidence(100,1,true);h.coverOpen=false;h.coverClosed=true;assert(home.start(100,h));
 ack(home,110,ShutdownAction::StopCapture);home.tick(200,evidence(200,2,true));home.tick(300,evidence(300,3,true));assert(home.status().phase==ShutdownPhase::Closing);
 // Wrap-safe deadlines, fresh observations, and no implicit resume after construction.
 EmergencyShutdown wrap;assert(wrap.start(0xffffff00,evidence(0xffffff00,1)));ack(wrap,0xffffff10,ShutdownAction::StopCapture);
 wrap.tick(30,evidence(30,2));wrap.tick(100,evidence(100,3));assert(wrap.status().phase==ShutdownPhase::Stowing);
 EmergencyShutdown reboot;assert(!reboot.status().active()&&!reboot.status().locked());
 puts("Emergency shutdown: ordered phases, fresh repeated evidence, failure locks, cancellation, stale/unsafe close guards, and wraparound passed");
}
