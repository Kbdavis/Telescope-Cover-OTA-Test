#include "sta_recovery.h"
#include <cassert>
#include <cstdio>
using namespace cover;

int main(){
 StaRecovery policy;
 StaRecoveryConditions state;state.credentials=true;
 policy.reset(1000);
 assert(!policy.poll(20999,state));
 assert(policy.poll(21000,state) && policy.waitMs()==40000);
 assert(!policy.poll(60999,state));
 assert(policy.poll(61000,state) && policy.waitMs()==80000);
 assert(!policy.poll(140999,state));
 assert(policy.poll(141000,state) && policy.waitMs()==120000);
 for(uint32_t t=141001;t<261000;++t)assert(!policy.poll(t,state));
 assert(policy.poll(261000,state));
 // Indefinite outages retain a bounded rate rather than disabling recovery.
 for(uint32_t t=381000;t<2000000;t+=120000){
  assert(!policy.poll(t-1,state));assert(policy.poll(t,state));
  assert(policy.waitMs()==120000);
 }
 // Every gate suppresses an already-due retry and gives the operation a fresh
 // grace period on exit. No accumulated retries burst after a setup/OTA lease.
 bool StaRecoveryConditions::* gates[]={&StaRecoveryConditions::setupBusy,
  &StaRecoveryConditions::maintenanceBusy,&StaRecoveryConditions::portalClient,
  &StaRecoveryConditions::connected};
 for(auto gate:gates){
  StaRecovery p;p.reset(0);
  state.*gate=true;assert(!p.poll(500000,state));
  state.*gate=false;assert(!p.poll(519999,state));
  assert(p.poll(520000,state) && p.waitMs()==40000);
 }
 // No saved network: recovery cannot start. Adding credentials gets a grace period.
 policy.reset(0);state.credentials=false;assert(!policy.poll(900000,state));
 state.credentials=true;assert(!policy.poll(919999,state));assert(policy.poll(920000,state));
 // A healthy connection resets even a saturated backoff to the initial wait.
 state.connected=true;assert(!policy.poll(1000000,state));
 state.connected=false;assert(!policy.poll(1019999,state));
 assert(policy.poll(1020000,state) && policy.waitMs()==40000);
 // millis() wrap does not trigger an early retry or stall future attempts.
 policy.reset(UINT32_MAX-9999);
 assert(!policy.poll(9999,state));assert(policy.poll(10000,state));
 assert(!policy.poll(49999,state));assert(policy.poll(50000,state));
 puts("STA recovery: bounded backoff, outage persistence, setup/maintenance/portal gates, success reset and rollover passed");
}
