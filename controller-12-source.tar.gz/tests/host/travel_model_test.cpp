#include "cover_controller.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <initializer_list>
using namespace cover;
static unsigned long now=0;
unsigned long millis(){return now;}
void yield(){}
struct Servo : ServoMotion {
 uint16_t p=1000,goal=0;bool torque=false,badRead=false,qualified=false;unsigned moves=0,enables=0;
 bool rolloverSupported() const override{return qualified;}
 ServoResult moveAcrossBoundary(uint16_t g,uint16_t,uint8_t,const TravelArc& a) override{assert(qualified&&a.contains(p)&&a.contains(g));goal=g;++moves;return {};}
 ServoResult validateConfiguration() override{return {};}
 ServoResult readPosition(uint16_t& out) override{out=badRead?0:p;return badRead?ServoResult{ServoError::Timeout}:ServoResult{};}
 ServoResult readTorque(bool& out) override{out=torque;return {};}
 ServoResult releaseTorque() override{torque=false;return {};}
 ServoResult enableTorque() override{torque=true;++enables;return {};}
 ServoResult moveTo(uint16_t g,uint16_t,uint8_t,uint16_t,uint16_t) override{goal=g;++moves;return {};}
};
MotionSettings config(int closed,int direction,int length,int lo,int hi){
 MotionSettings s;s.minimum=lo;s.maximum=hi;s.hasTravelArc=true;
 s.arc.closedRaw=closed;s.arc.direction=direction;s.arc.length=length;s.arc.minimumRaw=lo;s.arc.maximumRaw=hi;
 s.timeoutMs=30000;s.disableTorqueAfterMove=true;return s;
}
void poll(CoverController& c,unsigned n=1){while(n--){now+=50;c.tick(true);}}
int main(){
 for(int direction:{1,-1})for(int base:{5,1000,3890}){
  const int closed=direction>0?base:base+100,opened=closed+direction*100;
  auto s=config(closed,direction,100,base-5,base+105);const auto a=s.arc;
  assert(a.valid()&&a.rawTarget(0)==closed&&a.rawTarget(100)==opened);
  for(int raw=base;raw<=base+100;++raw){int travel=-1;assert(a.progress(raw,travel));assert(a.rawTarget(travel)==raw);}
  int sentinel=123;assert(!a.progress(base-1,sentinel)&&sentinel==123);assert(!a.progress(4096,sentinel));
  Servo f;f.p=closed;CoverController c(f);
  assert(c.initializeStationary(s,closed,opened)&&c.state()==State::Closed&&f.moves==0&&f.enables==0);
  assert(!c.moveEndpoint(closed,true,true)); // Target must match the named endpoint.
  assert(c.moveEndpoint(opened,true,true));
  f.p=direction>0?0:4095;poll(c);assert(c.moving()); // Isolated valid-looking outlier.
  f.badRead=true;poll(c);assert(c.moving());f.badRead=false;
  f.p=closed+direction*50;poll(c);assert(c.moving());f.p=opened;poll(c,5);
  assert(c.state()==State::Open&&!f.torque&&c.position()==opened);
  assert(c.moveEndpoint(closed,false,true));f.p=closed;poll(c,5);assert(c.state()==State::Closed);
  // A restart never resumes; interior feedback remains UNKNOWN, outside arc rejected.
  f.p=closed+direction*50;CoverController rebooted(f);assert(rebooted.initializeStationary(s,closed,opened));
  assert(rebooted.state()==State::Unknown&&f.moves==2&&f.enables==2);
  f.p=base+106;CoverController outside(f);assert(!outside.initializeStationary(s,closed,opened));
 }
 // A short modular distance is not authorization for a boundary-crossing command.
 for(int direction:{1,-1}){
  auto s=config(direction>0?4000:100,direction,196,0,4095);
  assert(!s.arc.valid());Servo f;f.p=s.arc.closedRaw;CoverController c(f);
  assert(!c.initializeStationary(s,s.arc.closedRaw,direction>0?100:4000));
  s.hasTravelArc=false;assert(c.configure(s));
  assert(!c.moveEndpoint(direction>0?100:4000,true,true)&&!f.moves&&!f.enables);
  f.p=direction>0?4090:5;assert(!c.jog(direction*10,true)&&!f.moves&&!f.enables);
 }
 // Explicit circular arcs cross zero in both directions; unsupported hardware
 // rejects before enabling torque. Endpoints determine the allowed arc.
 for(int dir:{1,-1}){
  auto wrapped=config(dir>0?2386:100,dir,1810,0,4095);wrapped.arc.circular=true;
  const int opened=wrapped.arc.rawTarget(1810);
  assert(opened==(dir>0?100:2386));assert(wrapped.arc.valid());
  for(int n=0;n<=1810;++n){int out=-1;assert(wrapped.arc.progress(wrapped.arc.rawTarget(n),out)&&out==n);}
  assert(!wrapped.arc.contains(1000));
  Servo servo;servo.p=wrapped.arc.closedRaw;CoverController ctrl(servo);
  assert(ctrl.initializeStationary(wrapped,servo.p,opened));
  assert(!ctrl.moveEndpoint(opened,true,true)&&!servo.enables&&!servo.moves);
  servo.qualified=true;assert(ctrl.moveEndpoint(opened,true,true));
  for(int n=20;n<1810;n+=20){servo.p=wrapped.arc.rawTarget(n);poll(ctrl);assert(ctrl.moving());}
  servo.p=opened;poll(ctrl,5);assert(ctrl.state()==State::Open&&!servo.torque);
  assert(ctrl.moveEndpoint(wrapped.arc.closedRaw,false,true));
  for(int n=1790;n>0;n-=20){servo.p=wrapped.arc.rawTarget(n);poll(ctrl);assert(ctrl.moving());}
  servo.p=wrapped.arc.closedRaw;poll(ctrl,5);assert(ctrl.state()==State::Closed);
  // Restart at a forbidden point never classifies or enables the actuator.
  servo.p=1000;CoverController restart(servo);assert(!restart.initializeStationary(wrapped,wrapped.arc.closedRaw,opened));
 }
 // Qualified Manual steps have their own continuous arc even outside saved
 // limits, and fault on repeated wrong-direction readings across the boundary.
 for(int dir:{1,-1}){
  Servo servo;servo.p=dir>0?4090:5;servo.qualified=true;CoverController ctrl(servo);
  MotionSettings manual;manual.minimum=2000;manual.maximum=2100;assert(ctrl.configure(manual));
  const int start=servo.p;assert(ctrl.manualJog(dir*10,true));
  servo.p=wrapPosition(start+dir*10);poll(ctrl,5);assert(ctrl.state()==State::Stopped&&!servo.torque);
  assert(ctrl.manualJog(-dir*10,true));servo.p=start;poll(ctrl,5);assert(ctrl.state()==State::Stopped&&!servo.torque);
  assert(ctrl.manualJog(dir*10,true));servo.p=wrapPosition(start-dir*20);poll(ctrl,3);
  assert(ctrl.state()==State::Fault&&!servo.torque);
 }
 // Uncalibrated supervised small steps get their own bounded circular arc.
 for(int dir:{1,-1}){
  Servo servo;servo.p=dir>0?4090:5;servo.qualified=true;CoverController ctrl(servo);
  MotionSettings manual;manual.minimum=0;manual.maximum=4095;assert(ctrl.configure(manual));
  assert(ctrl.jog(dir*10,true));servo.p=wrapPosition(int(servo.p)+dir*10);poll(ctrl,5);
  assert(ctrl.state()==State::Stopped&&!servo.torque);
  assert(ctrl.jog(-dir*10,true));servo.p=wrapPosition(int(servo.p)-dir*10);poll(ctrl,5);assert(ctrl.state()==State::Stopped);
  assert(ctrl.jog(dir*10,true));servo.p=wrapPosition(int(servo.p)-dir*40);poll(ctrl,3);assert(ctrl.state()==State::Fault&&!servo.torque);
 }
 // A legacy linear range never acquires circular endpoint classification.
 auto linear=config(0,1,100,0,4095);Servo atOtherEnd;atOtherEnd.p=4095;CoverController legacy(atOtherEnd);
 assert(legacy.initializeStationary(linear,0,100)&&legacy.state()==State::Unknown);
 assert(supportedDirectPath(0,2047)&&!supportedDirectPath(0,2048));
 assert(!supportedDirectPath(4000,100)&&!supportedDirectPath(100,4000));
 auto s=config(1048,1,2000,1000,3100);
 const auto estimate=travelTiming(2000,100,10);
 assert(estimate.nominalMs==20000&&estimate.expectedMs==22500&&estimate.recommendedMs==29000);
 Servo f;f.p=1048;CoverController c(f);assert(c.initializeStationary(s,1048,3048));
 assert(c.setMotionProfile(100,10,5000));assert(!c.moveEndpoint(3048,true,true)&&!f.enables&&!f.moves);
 assert(c.setMotionProfile(100,10,29000));assert(c.moveEndpoint(3048,true,true));
 now+=29000;c.tick(true);assert(c.state()==State::Fault&&!f.torque&&!strcmp(c.fault(),"Movement timeout"));
 assert(c.setMotionProfile(100,10,30000));assert(c.state()==State::Fault&&!strcmp(c.fault(),"Movement timeout"));
 assert(!c.moveEndpoint(3048,true,true));c.stop();assert(c.state()==State::Fault);
 assert(c.recover()&&c.state()==State::Unknown&&f.moves==1&&!f.torque);
 // Repeated valid boundary-like readings fault; one sample never creates a lap.
 auto near=config(3900,1,100,3850,4095);Servo edge;edge.p=3900;CoverController monitored(edge);
 assert(monitored.initializeStationary(near,3900,4000));assert(monitored.moveEndpoint(4000,true,true));
 edge.p=0;poll(monitored,2);assert(monitored.moving());poll(monitored);assert(monitored.state()==State::Fault&&!edge.torque);
 puts("Travel coordinates, path gates, restart ambiguity, bad samples, timing and fault latching passed");
}
