#include "close_dry_run.h"
#include <assert.h>
#include <stdio.h>
using namespace cover;
int main(){
 CloseDryRun run;alpaca::StowStatus test;alpaca::Snapshot s;
 s.enabled=s.valid=s.connected=s.canFindHome=s.atHome=true;s.consecutiveStowed=2;s.sampledAt=100;
 test.operation=1;test.phase=alpaca::StowPhase::Complete;
 run.start(100,2);run.step(100,test,s,true);assert(run.phase()==CloseDryRun::Phase::Stowing);
 test.operation=2;run.step(200,test,s,true);assert(run.phase()==CloseDryRun::Phase::Rechecking);
 run.step(201,test,s,true);assert(run.phase()==CloseDryRun::Phase::Rechecking);
 s.sampledAt=250;run.step(300,test,s,true);assert(run.phase()==CloseDryRun::Phase::Ready);
 s.slewing=true;run.step(301,test,s,true);assert(run.phase()==CloseDryRun::Phase::Cancelled);
 s.slewing=false;run.step(302,test,s,true);assert(run.phase()==CloseDryRun::Phase::Cancelled); // No automatic resume.
 run.start(400,2);run.step(400,test,s,false);assert(run.phase()==CloseDryRun::Phase::Cancelled);
 run.start(500,2);s.error=alpaca::Error::Offline;run.step(500,test,s,true);assert(run.phase()==CloseDryRun::Phase::Cancelled);
 s.error=alpaca::Error::None;run.start(600,2);test.phase=alpaca::StowPhase::Unknown;run.step(600,test,s,true);assert(run.phase()==CloseDryRun::Phase::Cancelled);
 test.phase=alpaca::StowPhase::Complete;run.start(700,2);run.step(700,test,s,true);run.step(6000,test,s,true);assert(run.phase()==CloseDryRun::Phase::Cancelled);
 run.start(0xfffffff0U,2);s.sampledAt=0xfffffff0U;run.step(0xfffffff0U,test,s,true);s.sampledAt=20;run.step(25,test,s,true);assert(run.phase()==CloseDryRun::Phase::Ready);
 run.reset();assert(run.phase()==CloseDryRun::Phase::Idle);
 puts("Close dry run: new operation, final fresh recheck, interlock, stale data, disconnect, cancellation latch and rollover passed");
}
