#include "http_request.h"
#include <cassert>
#include <cstdio>
#include <string>
#include <random>
#include <new>
using cover::HttpRequest;
static unsigned allocations=0;
void* operator new(size_t n){++allocations;void* p=malloc(n);if(!p)throw std::bad_alloc();return p;}
void operator delete(void* p)noexcept{free(p);}
void operator delete(void* p,size_t)noexcept{free(p);}
static HttpRequest parse(const std::string& text){
 HttpRequest request(0);unsigned before=allocations;
 for(char c:text){if(!request.feed(c,1))break;}
 assert(allocations==before);return request;
}
static void rejects(const std::string& text,unsigned error){auto r=parse(text);assert(!r.ready && r.error==error);}
static std::string post(const std::string& body,const std::string& type="text/plain",const std::string& path="/api/ota/prepare"){
 return "POST "+path+" HTTP/1.1\r\nHost: cover\r\nContent-Type: "+type+"\r\nContent-Length: "+std::to_string(body.size())+"\r\n\r\n"+body;
}
int main(){
 auto get=parse("GET /api/debug?after=123&boot_id=abc HTTP/1.1\r\nHost: cover\r\nX-Cover-Token: canary\r\n\r\n");
 assert(get.ready && !get.error && !strcmp(get.bytes+get.target,"/api/debug") && !strcmp(get.bytes+get.query,"after=123&boot_id=abc"));
 assert(!strcmp(get.header("x-cover-token"),"canary"));
 auto plain=parse(post("transaction=abc\n"));assert(plain.ready && plain.length==16 && !strcmp(plain.bytes+plain.body,"transaction=abc\n"));
 auto form=parse(post("ssid=A%26B&password=%25x+z&name=Cover","application/x-www-form-urlencoded","/api/network/connect"));
 assert(form.ready && form.encoded());
 assert(parse("POST /api/stop HTTP/1.1\r\nHost: cover\r\nContent-Length: 0\r\n\r\n").ready);
 assert(parse("GET / HTTP/1.0\r\n\r\n").ready);
 assert(parse("GET / HTTP/1.1\r\nHost:\tcover\t\r\n\r\n").ready);
 assert(parse(post(std::string(640,'x'))).ready);
 assert(parse(post(std::string(640,'x'),"text/plain","/api/ota/probe/prepare")).ready);
 rejects(post(std::string(641,'x'),"text/plain","/api/ota/probe/prepare"),413);
 rejects(post("x","multipart/form-data; boundary=x","/api/ota/probe/cancel"),415);
 rejects(post(std::string(641,'x')),413);
 assert(parse(post(std::string(2048,'x'),"application/x-www-form-urlencoded","/settings")).ready);
 rejects(post(std::string(2049,'x'),"application/x-www-form-urlencoded","/settings"),413);
 rejects(post("x","multipart/form-data; boundary=x"),415);
 rejects(post("x","application/x-www-form-urlencoded"),415);
 rejects(post("x","text/plain; charset=UTF-8"),415);
 rejects(post("x","text/plain","/api/ota/prepare?extra=1"),400);
 rejects(post("x","text/plain","/settings"),415);
 for(auto length:{"-1","+1","01","1x","", "0,0"})
  rejects(std::string("POST /api/stop HTTP/1.1\r\nHost: cover\r\nContent-Length: ")+length+"\r\n\r\n",400);
 rejects("POST /api/stop HTTP/1.1\r\nHost: cover\r\nContent-Length: 4294967296\r\n\r\n",413);
 for(auto header:{"Transfer-Encoding: chunked", "transfer-encoding: identity", "Content-Length: 0\r\ncontent-length: 0", "X-Ota-Mac: a\r\nx-ota-mac: b", " Host: cover", "Host : cover", "NoColon", "Host: cover\r\nHost: cover", "Host: co\rver"})
  rejects(std::string("GET / HTTP/1.1\r\n")+header+"\r\n\r\n",400);
 rejects("GET / HTTP/1.1\r\nHost: cover\r\nExpect: 100-continue\r\n\r\n",417);
 rejects("GET / HTTP/1.1\r\nHost: cover\r\nContent-Encoding: gzip\r\n\r\n",415);
 rejects("POST /api/stop HTTP/1.1\r\nHost: cover\r\n\r\n",411);
 rejects("GET / HTTP/1.1\r\n\r\n",400);
 rejects("GET / HTTP/1.1\nHost: cover\n\n",400);
 rejects("GET / HTTP/1.1\r\nHost: cover\r\nContent-Length: 1\r\n\r\nx",400);
 rejects("PUT / HTTP/1.1\r\nHost: cover\r\n\r\n",405);
 rejects("GET http://cover/ HTTP/1.1\r\nHost: cover\r\n\r\n",400);
 rejects("GET /api/%6fta/prepare HTTP/1.1\r\nHost: cover\r\n\r\n",400);
 for(auto query:{"a=%00", "a=%", "a=%1", "a=%zz", "a=b c"})
  rejects(std::string("GET /?")+query+" HTTP/1.1\r\nHost: cover\r\n\r\n",400);
 rejects(post(std::string("x\0y",3)),400);
 rejects("GET /"+std::string(1024,'x')+" HTTP/1.1\r\nHost: cover\r\n\r\n",414);
 rejects("GET / HTTP/1.1\r\nHost: cover\r\nX-Large: "+std::string(512,'x')+"\r\n\r\n",431);
 std::string headers="GET / HTTP/1.1\r\nHost: cover\r\n";
 for(unsigned i=0;i<32;++i)headers+="X-"+std::to_string(i)+": x\r\n";
 rejects(headers+"\r\n",431);
 headers="GET / HTTP/1.1\r\nHost: cover\r\n";
 for(unsigned i=0;i<10;++i)headers+="X-"+std::to_string(i)+": "+std::string(250,'x')+"\r\n";
 rejects(headers+"\r\n",431);
 std::string arguments="a=b";
 for(unsigned i=1;i<32;++i)arguments+="&a=b";
 assert(parse(post(arguments,"application/x-www-form-urlencoded","/api/stop")).ready);
 rejects(post(arguments+"&a=b","application/x-www-form-urlencoded","/api/stop"),400);
 rejects(post(arguments,"application/x-www-form-urlencoded","/api/stop?q=1"),400);
 // No timeout extension from progress, including millis() rollover.
 HttpRequest slow(0);assert(slow.feed('G',1999));assert(!slow.feed('E',2000) && slow.error==408);
 HttpRequest rollover(UINT32_MAX-100);assert(!rollover.expired(1898));assert(rollover.expired(1899));
 HttpRequest incomplete(0);for(char c:post("xxx").substr(0,post("xxx").size()-1))assert(incomplete.feed(c,1));
 assert(!incomplete.ready && incomplete.expired(2000));
 auto pipelined=parse("GET / HTTP/1.0\r\n\r\nGET / HTTP/1.0\r\n\r\n");assert(pipelined.error==400);
 // Adversarial byte streams under sanitizers: fixed arena, never heap allocation.
 std::mt19937 random(0xC0A7);for(unsigned i=0;i<10000;++i){HttpRequest r(0);for(unsigned n=0;n<6000 && !r.error;++n)r.feed(char(random()%256),n/4);}
 puts("Bounded HTTP: framing, allocation-free input, media/length/header/argument limits, fragments, deadlines, rollover and fuzz passed");
}
