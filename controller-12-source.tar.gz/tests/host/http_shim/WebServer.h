#pragma once
#include <string>
#include <vector>
#include <memory>
#include <functional>
#include <cstring>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cassert>
#include <strings.h>
#include <sys/socket.h>
#include <unistd.h>
inline uint32_t fakeHttpNow=100;
inline uint32_t millis(){return fakeHttpNow;}
class String {
 std::string value_;
 public:
 String()=default;String(const char* s):value_(s){}String(std::string s):value_(std::move(s)){}
 size_t length()const{return value_.size();}const char* c_str()const{return value_.c_str();}
 char operator[](size_t i)const{return value_[i];}
 int indexOf(char c,int from=0)const{auto pos=value_.find(c,from);return pos==std::string::npos?-1:int(pos);}
 String substring(int a,int b)const{return value_.substr(a,b-a);}
 String& operator+=(char c){value_+=c;return *this;}String& operator+=(const char* s){value_+=s;return *this;}
 bool operator==(const String& s)const{return value_==s.value_;}
};
struct HttpConnection {
 std::string input;size_t cursor=0;bool connected=true;unsigned reads=0,stops=0;int sockets[2];
 explicit HttpConnection(std::string data):input(std::move(data)){assert(socketpair(AF_UNIX,SOCK_STREAM,0,sockets)==0);}
 ~HttpConnection(){::close(sockets[0]);::close(sockets[1]);}
 void append(const std::string& data){input+=data;}
 std::string response(){char buf[256];int n=recv(sockets[1],buf,sizeof(buf),MSG_DONTWAIT);return n>0?std::string(buf,n):"";}
};
class WiFiClient {
 std::shared_ptr<HttpConnection> connection_;
 public:
 WiFiClient()=default;explicit WiFiClient(std::shared_ptr<HttpConnection> c):connection_(c){}
 explicit operator bool()const{return bool(connection_);}
 int available()const{return connection_?connection_->input.size()-connection_->cursor:0;}
 bool connected()const{return connection_ && connection_->connected;}
 int read(){if(!available())return -1;++connection_->reads;return uint8_t(connection_->input[connection_->cursor++]);}
 void stop(){if(connection_){connection_->connected=false;++connection_->stops;}}
 int fd(){return connection_?connection_->sockets[0]:-1;}
 void setTimeout(unsigned){}
};
class WiFiServer {
 public:
 std::vector<std::shared_ptr<HttpConnection>> clients;
 explicit operator bool(){return true;}
 WiFiClient available(){if(clients.empty())return WiFiClient();auto c=clients.front();clients.erase(clients.begin());return WiFiClient(c);}
};
enum HTTPMethod {HTTP_ANY,HTTP_GET,HTTP_POST};
constexpr int HC_NONE=0;
constexpr size_t CONTENT_LENGTH_NOT_SET=size_t(-2);
class RequestHandler {
 public:
 RequestHandler* next_=nullptr;String path;HTTPMethod method;std::function<void()> callback;
 RequestHandler(String p,HTTPMethod m,std::function<void()> c):path(p),method(m),callback(c){}
 RequestHandler* next(){return next_;}
 bool canHandle(HTTPMethod m,String p){return m==method && p==path;}
};
class WebServer {
 public:
 unsigned routed=0,legacyParses=0;bool closed=false;
 explicit WebServer(int){}
 virtual ~WebServer(){delete[] _currentArgs;delete[] _currentHeaders;while(_firstHandler){auto* h=_firstHandler;_firstHandler=h->next();delete h;}}
 virtual void handleClient(){++legacyParses;}
 virtual void close(){closed=true;_currentClient.stop();}
 void send(unsigned status,const char*,const char* body){std::string response=std::to_string(status)+" "+body;::send(_currentClient.fd(),response.data(),response.size(),MSG_DONTWAIT);}
 void enqueue(std::shared_ptr<HttpConnection> c){_server.clients.push_back(c);}
 void on(const char* path,HTTPMethod method,std::function<void()> callback){auto* h=new RequestHandler(path,method,callback);h->next_=_firstHandler;_firstHandler=h;}
 void collectHeaders(const char* keys[],size_t n){_headerKeysCount=n;_currentHeaders=new RequestArgument[n];for(size_t i=0;i<n;++i)_currentHeaders[i].key=keys[i];}
 String arg(const char* name){for(int i=0;i<_currentArgCount;++i)if(_currentArgs[i].key==String(name))return _currentArgs[i].value;return String();}
 String header(const char* name){for(int i=0;i<_headerKeysCount;++i)if(!strcasecmp(_currentHeaders[i].key.c_str(),name))return _currentHeaders[i].value;return String();}
 int args(){return _currentArgCount;}
 int clientContentLength(){return _clientContentLength;}
 static String urlDecode(String s){std::string out;for(size_t i=0;i<s.length();++i){if(s[i]=='+')out+=' ';else if(s[i]=='%'){char digits[3]={s[i+1],s[i+2],0};out+=char(strtoul(digits,nullptr,16));i+=2;}else out+=s[i];}return out;}
 protected:
 struct RequestArgument {String key,value;};
 WiFiServer _server;WiFiClient _currentClient;int _currentStatus=HC_NONE;
 HTTPMethod _currentMethod=HTTP_ANY;unsigned _currentVersion=0;String _currentUri,_hostHeader;
 RequestArgument* _currentArgs=nullptr;int _currentArgCount=0;
 RequestArgument* _currentHeaders=nullptr;int _headerKeysCount=0;
 bool _chunked=false;size_t _contentLength=0;int _clientContentLength=0;String _responseHeaders;
 std::unique_ptr<int> _currentUpload,_currentRaw;
 RequestHandler* _currentHandler=nullptr;RequestHandler* _firstHandler=nullptr;
 void _collectHeader(const char* key,const char* value){for(int i=0;i<_headerKeysCount;++i)if(!strcasecmp(_currentHeaders[i].key.c_str(),key))_currentHeaders[i].value=value;}
 void _handleRequest(){++routed;if(_currentHandler)_currentHandler->callback();}
};
