#include "servo_controller.h"
#include "servo_test_bus.h"
#include <cstring>
#include <cstdio>
using namespace cover;
static unsigned long now=0;
unsigned long millis(){return now;}
void yield(){++now;}
int main(){
 Bus bus;
 const uint8_t factory[40]={3,9,0,9,3,1,0,0,1,0,0,255,15,70,140,40,232,3,12,44,47,32,32,0,16,0,1,1,54,1,1,85,0,0,20,200,80,10,200,200};
 memcpy(bus.registers,factory,40);bus.registers[11]=bus.registers[12]=0;bus.registers[18]=28;
 bus.registers[55]=1;bus.registers[40]=0;bus.registers[56]=21;bus.registers[57]=16;
 uint8_t before[80];memcpy(before,bus.registers,sizeof(before));
 ServoController servo(bus);uint16_t position=0,model=0;
 assert(servo.readModel(model)&&model==777);assert(servo.validateConfiguration());
 assert(servo.readPosition(position)&&position==21);
 assert(!servo.enableTorque());assert(!servo.releaseTorque());assert(!servo.moveTo(100,100,10,0,4095));
 assert(!memcmp(before,bus.registers,sizeof(before)));
 for(const auto& packet:bus.writes)assert(packet[4]==1 || packet[4]==2);
 puts("Read-only web driver: native reads accepted; goal/torque/register writes never reach bus");
}
