#include "bounded_web_server.h"
#include <cassert>
#include <cstdio>
#include <string>
using namespace cover;
static std::shared_ptr<HttpConnection> connection(const std::string& data){return std::make_shared<HttpConnection>(data);}
static void drain(BoundedWebServer& s,const std::shared_ptr<HttpConnection>& c){for(unsigned n=0;n<50 && c->connected;++n)s.handleClient();assert(!c->connected);}
static BoundedWebServer* deferredServer=nullptr;
static bool completed=false;static unsigned checks=0;
static bool completeResponse(){++checks;if(!completed)return false;deferredServer->send(200,"text/plain","consumed");return true;}
int main(){
 BoundedWebServer server;
 const char* headers[]={"X-Cover-Token","X-Ota-Mac","Content-Type"};server.collectHeaders(headers,3);
 unsigned stops=0,prepares=0;
 server.on("/api/stop",HTTP_POST,[&]{++stops;assert(server.arg("control_generation")==String("8"));assert(server.arg("automatic")==String("yes"));assert(server.header("X-Cover-Token")==String("canary"));});
 std::string body="control_generation=8&automatic=yes";
 auto stop=connection("POST /api/stop HTTP/1.1\r\nHost: cover\r\nX-Cover-Token: canary\r\nContent-Type: application/x-www-form-urlencoded\r\nContent-Length: "+std::to_string(body.size())+"\r\n\r\n"+body);
 server.enqueue(stop);drain(server,stop);assert(stops==1);
 server.on("/api/ota/prepare",HTTP_POST,[&]{++prepares;assert(server.arg("plain")==String("exact\nbody\n"));assert(server.clientContentLength()==11);assert(server.header("X-Ota-Mac")==String("mac"));assert(server.arg("control_generation")==String());});
 auto prepare=connection("POST /api/ota/prepare HTTP/1.1\r\nHost: cover\r\nX-Ota-Mac: mac\r\nContent-Type: text/plain\r\nContent-Length: 11\r\n\r\nexact\nbody\n");
 server.enqueue(prepare);drain(server,prepare);assert(prepares==1);
 unsigned gets=0;server.on("/api/status",HTTP_GET,[&]{++gets;assert(server.args()==0);assert(server.header("X-Ota-Mac")==String());assert(server.header("X-Cover-Token")==String());assert(server.clientContentLength()==0);});
 auto get=connection("GET /api/status HTTP/1.1\r\nHost: cover\r\n\r\n");server.enqueue(get);drain(server,get);assert(gets==1);
 for(auto invalid:{"POST /api/stop HTTP/1.1\r\nHost: cover\r\nContent-Length: 9000000\r\n\r\n", "POST /api/ota/prepare HTTP/1.1\r\nHost: cover\r\nContent-Type: multipart/form-data; boundary=x\r\nContent-Length: 10\r\n\r\n", "GET /api/status HTTP/1.1\r\nHost: cover\r\n\r\nGET /api/status HTTP/1.1\r\nHost: cover\r\n\r\n"}){
  auto c=connection(invalid);server.enqueue(c);unsigned calls=server.routed;drain(server,c);assert(server.routed==calls);assert(c->response().find("Rejected")!=std::string::npos);
 }
 // A drip does not extend the deadline; a subsequent Stop client can be served.
 auto slow=connection("G");server.enqueue(slow);server.handleClient();assert(slow->connected);
 fakeHttpNow+=1999;slow->append("E");server.handleClient();assert(slow->connected);
 ++fakeHttpNow;server.handleClient();assert(!slow->connected && slow->response().find("408")!=std::string::npos);
 auto next=connection(stop->input);server.enqueue(next);drain(server,next);assert(stops==2);
 auto truncated=connection("POST /api/ota/prepare HTTP/1.1\r\nHost: cover\r\nContent-Type: text/plain\r\nContent-Length: 640\r\n\r\nx");server.enqueue(truncated);server.handleClient();assert(truncated->connected);
 fakeHttpNow+=2000;server.handleClient();assert(!truncated->connected && prepares==1);
 // Each loop consumes at most 256 bytes even when the socket has the whole form.
 std::string large="x="+std::string(1500,'a');
 auto budget=connection("POST /unknown HTTP/1.1\r\nHost: cover\r\nContent-Type: application/x-www-form-urlencoded\r\nContent-Length: "+std::to_string(large.size())+"\r\n\r\n"+large);
 server.enqueue(budget);server.handleClient();assert(budget->reads==256);drain(server,budget);
 unsigned decoded=0;server.on("/api/network/connect",HTTP_POST,[&]{++decoded;assert(server.arg("ssid")==String("A&B"));assert(server.arg("password")==String("%x z"));assert(server.arg("name")==String("Cover"));});
 body="ssid=A%26B&password=%25x+z&name=Cover";
 auto form=connection("POST /api/network/connect HTTP/1.1\r\nHost: cover\r\nContent-Type: application/x-www-form-urlencoded\r\nContent-Length: "+std::to_string(body.size())+"\r\n\r\n");server.enqueue(form);server.handleClient();assert(decoded==0);
 for(char c:body){form->append(std::string(1,c));server.handleClient();}
 assert(decoded==1 && !form->connected);
 auto empty=connection("");server.enqueue(empty);server.handleClient();fakeHttpNow+=2000;server.handleClient();assert(!empty->connected);
 auto disconnect=connection("GET /");server.enqueue(disconnect);server.handleClient();disconnect->connected=false;server.handleClient();assert(disconnect->stops==1);
 auto closing=connection("G");server.enqueue(closing);server.handleClient();server.close();assert(!closing->connected);
 // The real adapter must keep a queued response open without accepting a second
 // client, and must never report completion before the worker publishes it.
 deferredServer=&server;
 server.on("/chunk",HTTP_POST,[&]{server.deferResponse(completeResponse);});
 const std::string chunk="POST /chunk HTTP/1.1\r\nHost: cover\r\nContent-Length: 0\r\n\r\n";
 auto pending=connection(chunk),waiting=connection("GET /api/status HTTP/1.1\r\nHost: cover\r\n\r\n");
 server.enqueue(pending);server.handleClient();assert(pending->connected && pending->response().empty());
 server.enqueue(waiting);for(unsigned i=0;i<20;++i)server.handleClient();
 assert(pending->connected && waiting->reads==0 && checks==20 && pending->response().empty());
 completed=true;server.handleClient();assert(!pending->connected && pending->response()=="200 consumed");
 drain(server,waiting);assert(gets==2);
 completed=false;auto timeout=connection(chunk);server.enqueue(timeout);server.handleClient();
 fakeHttpNow+=5000;server.handleClient();assert(!timeout->connected && timeout->response().find("503")!=std::string::npos);
 auto lost=connection(chunk);server.enqueue(lost);server.handleClient();lost->connected=false;server.handleClient();
 completed=true;auto recovered=connection(waiting->input);server.enqueue(recovered);drain(server,recovered);assert(gets==3 && recovered->response().empty());
 auto deferredClose=connection(chunk);server.enqueue(deferredClose);server.handleClient();server.close();assert(!deferredClose->connected);
 assert(!server.legacyParses);
 puts("Bounded WebServer adapter: exact OTA bytes, form decoding, header/argument cleanup, input budget, timeout/reconnect and no invalid dispatch passed");
}
