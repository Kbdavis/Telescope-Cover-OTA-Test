#include "maintenance.h"
#include "maintenance_worker.h"
#include <cassert>
#include <cstdio>
using namespace cover;
struct Servo {
 bool config=true,read=true,torque=false;uint16_t model=777,a=500,b=501;unsigned calls=0,positions=0;
 bool readModel(uint16_t& out){++calls;out=model;return read;}
 bool validateConfiguration(){++calls;return config;}
 bool readTorque(bool& out){++calls;out=torque;return read;}
 bool readPosition(uint16_t& out){++calls;out=positions++%2?b:a;return read;}
};
int main(){
 MaintenanceArbiter arbiter;auto snapshot=arbiter.snapshot();assert(snapshot.controlGeneration==1);
 assert(!arbiter.reserve(MaintenanceOwner::Network,100,0));
 auto network=arbiter.reserve(MaintenanceOwner::Network,100,1);assert(network);
 assert(!arbiter.commandsAllowed(1));assert(!arbiter.reserve(MaintenanceOwner::Ota,101,1));
 assert(!arbiter.ready(network));assert(!arbiter.ready({}));
 assert(arbiter.heartbeatsAllowed(1)); // Supervision continues before clearance acknowledgment.
 assert(arbiter.acknowledge(network,102));assert(arbiter.ready(network));
 assert(!arbiter.heartbeatsAllowed(1));assert(!arbiter.heartbeatsAllowed(2));
 assert(arbiter.snapshot().controlGeneration==2);
 assert(!arbiter.requestRelease({}));assert(arbiter.requestRelease(network));
 assert(arbiter.finish(network,true));assert(arbiter.commandsAllowed(3));
 assert(!arbiter.commandsAllowed(1)); // Old queued work never replays after release.
 auto ota=arbiter.reserve(MaintenanceOwner::Ota,110,3,3);assert(ota);
 assert(!arbiter.requestRelease(network));assert(!arbiter.cleanup(network));assert(!arbiter.ready(network));
 assert(!arbiter.acknowledge(ota,111));
 assert(arbiter.pause(ota,kMaintenanceAlpacaWorker));assert(!arbiter.acknowledge(ota,112));
 assert(arbiter.pause(ota,kMaintenancePowerWorker));assert(arbiter.acknowledge(ota,113));
 assert(arbiter.ready(ota));assert(!arbiter.stop(true,3)); // Stale automatic Stop after acknowledgment.
 assert(arbiter.ready(ota));assert(!arbiter.mayExposeAp());
 arbiter.revoke(MaintenanceReason::Network);assert(!arbiter.ready(ota));
 assert(arbiter.snapshot().locked());assert(!arbiter.mayExposeAp());
 assert(arbiter.requestRelease(ota));assert(!arbiter.finish(ota,true)); // Transport cleanup must finish first.
 assert(arbiter.cleanup(ota));assert(arbiter.mayExposeAp());
 assert(!arbiter.finish(ota,false));assert(arbiter.snapshot().locked()); // Uncertain physical state keeps the lock.
 assert(arbiter.finish(ota,true));assert(!arbiter.snapshot().locked());
 auto pending=arbiter.reserve(MaintenanceOwner::Ota,200,arbiter.snapshot().controlGeneration);assert(pending);
 const auto before=arbiter.snapshot().controlGeneration;
 assert(arbiter.stop(true,before)); // Before acknowledgment cleanup remains effective.
 assert(!arbiter.acknowledge(pending,201));assert(arbiter.snapshot().locked());
 assert(arbiter.stop(false,0)); // Explicit/legacy Stop never depends on a generation.
 assert(arbiter.cleanup(pending));assert(arbiter.requestRelease(pending));assert(arbiter.finish(pending,true));
 auto reboot=arbiter.reserve(MaintenanceOwner::Reboot,300,arbiter.snapshot().controlGeneration);assert(reboot);
 assert(!arbiter.finish(network,true));assert(arbiter.stop(false,0));assert(!arbiter.ready(reboot));
 assert(arbiter.requestRelease(reboot));assert(arbiter.finish(reboot,false)); // Network/reboot cleanup cannot unlock OTA.
 MaintenanceEvidence e;e.ready=e.calibrated=e.closed=true;e.dirty=e.moving=e.holding=e.fault=false;e.minimum=400;e.maximum=600;e.closedPosition=500;
 Servo servo;assert(validateOtaStationary(servo,e));assert(servo.calls==5);
 servo.torque=true;assert(validateOtaStationary(servo,e));
 servo.a=servo.b=510;assert(validateOtaStationary(servo,e));
 servo.a=servo.b=511;assert(!validateOtaStationary(servo,e));
 // Developer OTA accepts stable OPEN/interior feedback, while ordinary policy
 // and settings maintenance still demand CLOSED. Read/configuration guards stay.
 auto openEvidence=e;openEvidence.closed=false;
 Servo stationary;stationary.a=stationary.b=550;
 assert(!validateOtaStationary(stationary,openEvidence));
 assert(validateOtaStationary(stationary,openEvidence,true,false));
 stationary.torque=true;assert(validateOtaStationary(stationary,openEvidence,true,false));
 stationary.b=555;assert(!validateOtaStationary(stationary,openEvidence,true,false));
 stationary.a=stationary.b=650;assert(!validateOtaStationary(stationary,openEvidence,true,false));
 OtaMaintenanceRequirements developer;developer.closedCover=false;
#ifdef COVER_OTA_DEVELOPMENT
 assert(otaPositionPolicyAllowed(developer));
 // Recovery may replace firmware despite calibration/configuration faults,
 // but it never moves or silently unloads the mechanism.
 auto recovery=e;recovery.ready=recovery.calibrated=recovery.closed=false;
 recovery.dirty=recovery.fault=true;recovery.minimum=600;recovery.maximum=400;
 Servo recovering;recovering.config=false;recovering.a=recovering.b=3000;
 assert(validateOtaStationary(recovering,recovery,true,false,true));
 assert(recovering.calls==4); // No critical-configuration validation for a flash.
 assert(!validateOtaStationary(recovering,recovery,true,true,true));
 recovery.moving=true;assert(!validateOtaStationary(recovering,recovery,true,false,true));recovery.moving=false;
 recovery.holding=true;assert(!validateOtaStationary(recovering,recovery,true,false,true));recovery.holding=false;
 for(unsigned check=0;check<6;++check){
  Servo bad;bad.a=bad.b=3000;
  switch(check){case 0:bad.torque=true;break;case 1:bad.read=false;break;case 2:bad.model=1;break;
   case 3:bad.b=3004;break;case 4:bad.a=bad.b=4096;break;case 5:bad.a=0;bad.b=4095;break;}
  assert(!validateOtaStationary(bad,recovery,true,false,true));
 }
#else
 assert(!otaPositionPolicyAllowed(developer));
 Servo noRecovery;assert(!validateOtaStationary(noRecovery,e,true,false,true));assert(!noRecovery.calls);
 developer.closedCover=developer.recovery=true;assert(!otaPositionPolicyAllowed(developer));
#endif
 MaintenanceArbiter exhausted(UINT32_MAX-1);
 const auto last=exhausted.reserve(MaintenanceOwner::Network,0,UINT32_MAX-1);assert(last);
 assert(!exhausted.acknowledge(last,1));assert(!exhausted.commandsAllowed(UINT32_MAX));
 assert(exhausted.stop(false,0));assert(exhausted.snapshot().controlGeneration==UINT32_MAX); // No generation reuse.
 for(unsigned check=0;check<7;++check){
  auto invalid=e;
  switch(check){case 0:invalid.ready=false;break;case 1:invalid.calibrated=false;break;case 2:invalid.dirty=true;break;
   case 3:invalid.moving=true;break;case 4:invalid.holding=true;break;case 5:invalid.fault=true;break;case 6:invalid.closed=false;break;}
  Servo untouched;assert(!validateOtaStationary(untouched,invalid));assert(!untouched.calls);
 }
 for(unsigned check=0;check<6;++check){
  Servo bad;
  switch(check){case 0:bad.model=1;break;case 1:bad.config=false;break;case 2:bad.read=false;break;
   case 3:bad.a=bad.b=520;break;case 4:bad.b=510;break;case 5:bad.a=0;break;}
  assert(!validateOtaStationary(bad,e));
 }
 std::puts("Maintenance ownership, stale releases, queued generations, worker acknowledgments, Stop, AP cleanup and fresh servo validation passed");
}
