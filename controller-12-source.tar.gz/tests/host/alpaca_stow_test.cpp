#include "alpaca_client.h"
#include <assert.h>
#include <stdio.h>
using namespace cover::alpaca;
struct Fake:Transport {
 int writes=0;Reply reply;
 Reply get(Property,uint32_t) override{return {};}
 Reply findHome(uint32_t) override{++writes;return reply;}
};
Snapshot sample(uint32_t now,uint32_t seq,bool home=true){
 Snapshot s;s.enabled=s.valid=s.connected=s.canFindHome=true;s.atHome=home;
 s.sampledAt=now;s.sequence=seq;return s;
}
int main(){
 Fake t;StowTest test;assert(test.start(100,10000));assert(!test.start(100,10000));
 test.step(100,sample(100,1,false),t);assert(t.writes==1 && test.status().phase==StowPhase::Waiting);
 auto s=sample(200,2);s.slewing=true;test.step(200,s,t); // AtHome alone is insufficient.
 test.step(300,sample(300,3),t);test.step(301,sample(300,3),t);
 assert(test.status().active()); // Re-reading one snapshot is not two observations.
 s=sample(400,4);s.tracking=true;test.step(400,s,t);
 test.step(500,sample(500,5),t);assert(test.status().active());
 test.step(600,sample(600,6),t);assert(test.status().phase==StowPhase::Complete && t.writes==1);
 assert(test.start(1000,10000));s=sample(1000,1);s.tracking=true;test.step(1000,s,t);
 assert(test.status().phase==StowPhase::Failed && t.writes==1);
 assert(test.start(2000,10000));t.reply.error=Error::Timeout;test.step(2000,sample(2000,1),t);
 assert(test.status().phase==StowPhase::Unknown && t.writes==2);
 test.step(3000,sample(3000,2),t);assert(t.writes==2 && test.status().phase==StowPhase::Unknown);
 t.reply={};assert(test.start(4000,10000));test.step(4000,sample(4000,1),t);
 s=sample(4100,2);s.valid=false;s.error=Error::Offline;test.step(4100,s,t);
 assert(test.status().phase==StowPhase::Unknown);
 assert(test.start(0xfffffff0U,10000));test.step(0xfffffff0U,sample(0xfffffff0U,1,false),t);
 test.step(10000,sample(10000,2,false),t);assert(test.status().phase==StowPhase::Unknown);
 assert(!test.start(0,0));
 puts("Stow tests: one PUT, repeated fresh completion, contradictions, timeout, lost connection and wraparound passed");
}
