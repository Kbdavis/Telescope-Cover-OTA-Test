#pragma once
#include <stdlib.h>
#include <time.h>
#include <string>
inline unsigned timeClientStarts=0;
inline std::string configuredZone,configuredServer;
inline void configTzTime(const char* zone,const char* server){
 ++timeClientStarts;configuredZone=zone;configuredServer=server;
 setenv("TZ",zone,1);tzset();
}
