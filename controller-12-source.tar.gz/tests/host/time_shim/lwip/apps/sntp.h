#pragma once
#include <sys/time.h>
inline void (*syncCallback)(struct timeval*)=nullptr;
inline void sntp_set_time_sync_notification_cb(void (*callback)(struct timeval*)){syncCallback=callback;}
