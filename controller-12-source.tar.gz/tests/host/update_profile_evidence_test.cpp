#include "update_profile_evidence.h"
#include <assert.h>
#include <stdio.h>
using namespace cover;
int main(){
 ServoDiagnostics d;
 assert(!updateNativeProfileVerified(d,1000));
 const uint8_t profile[40]={3,9,0,9,3,1,0,0,1,0,0,0,0,70,140,40,232,3,28,44,47,32,32,0,16,0,1,1,54,1,1,85,0,0,20,200,80,10,200,200};
 memcpy(d.snapshot,profile,sizeof(profile));
 d.modelValid=true;d.model=777;d.validationAttempted=true;d.validationPassed=true;
 d.snapshotValid=true;d.lockValid=true;d.lock=1;d.nativePositionValid=true;
 d.modelAt=d.validationAt=d.snapshotAt=d.nativePositionAt=1000;
 assert(updateNativeProfileVerified(d,2500));
 assert(!updateNativeProfileVerified(d,2501));
 d.modelAt=0;assert(!updateNativeProfileVerified(d,2000));d.modelAt=1000;
 d.validationPassed=false;assert(!updateNativeProfileVerified(d,1000));d.validationPassed=true;
 d.lock=0;assert(!updateNativeProfileVerified(d,1000));d.lock=1;
 d.model=1;assert(!updateNativeProfileVerified(d,1000));d.model=777;
 d.snapshot[21]^=1;assert(!updateNativeProfileVerified(d,1000));d.snapshot[21]^=1;
 d.nativePositionValid=false;assert(!updateNativeProfileVerified(d,1000));d.nativePositionValid=true;
 d.modelAt=d.validationAt=d.snapshotAt=d.nativePositionAt=0xfffffff0;
 assert(updateNativeProfileVerified(d,16));
 assert(!updateNativeProfileVerified(d,2000));
 puts("Passive update profile evidence: exact identity, freshness, invalidation and uptime wrap passed");
}
