const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const D=require('../../data/ui/release_discovery.js');
const M=require('../../data/ui/release_metadata.js');
const fixture=JSON.parse(fs.readFileSync(path.join(__dirname,'../fixtures/release_metadata.json'),'utf8'));
const clone=v=>JSON.parse(JSON.stringify(v));
const raw=(changes={})=>({id:100,tag_name:'v0.1.0',draft:false,prerelease:false,published_at:'2026-11-12T12:00:00Z',body:'Plain release notes.',...changes});
const catalog=release=>({schema:'telescope-cover-catalog-preview/1',releases:[{release_id:100,metadata:release||fixture.release}]});
const reply=(value,status=200,headers={})=>new Response(status===304?null:typeof value==='string'?value:JSON.stringify(value),{status,headers});
const storage=()=>{const map=new Map();return {getItem:k=>map.get(k)||null,setItem:(k,v)=>map.set(k,v),removeItem:k=>map.delete(k),map};};
function setup(handler,options={}){
 let now=1800000000000,visible=true;const calls=[],store=options.storage||storage();
 const engine=new D.Discovery({clock:()=>now,storage:store,visible:()=>visible,random:()=>0.25,
  getDevice:()=>clone(fixture.device),getFirmware:()=>clone(fixture.device.firmware),
  fetch:async(url,options)=>{calls.push({url,options});return handler?handler(url,options,calls.length):url===D.CATALOG?reply(catalog()):reply([raw()],200,{ETag:'"first"'});},...options});
 return {engine,calls,store,advance:n=>{now+=n;},hide:()=>{visible=false;},show:()=>{visible=true;}};
}
test('read-only discovery intersects release ID/tag/channel and defaults to stable',async()=>{
 const f=setup();await f.engine.tick();const s=f.engine.snapshot();
 assert.equal(s.notification,'Update available');assert.equal(s.suggested.version,'0.1.0');assert.equal(s.suggested.assessment.installable,false);
 assert.equal(f.calls.length,2);for(const call of f.calls){assert.equal(call.options.method,'GET');assert.equal(call.options.credentials,'omit');assert(!('Authorization' in call.options.headers));}
 await f.engine.tick();assert.equal(f.calls.length,2,'fresh cached check is not repeated');
});
test('missing catalog or capabilities remains unknown and never offers install',async()=>{
 for(const getDevice of [()=>fixture.device,()=>null]){
  const f=setup(url=>url===D.CATALOG?reply('',404):reply([raw()]),{getDevice});await f.engine.check();
  assert.equal(f.engine.snapshot().notification,null);assert.equal(f.engine.snapshot().rows[0].assessment.code,'compatibility-unknown');
 }
});
test('stale capability identity cannot advertise an update for a different installed build',async()=>{
 const f=setup(null,{getFirmware:()=>({...fixture.device.firmware,elf:'a'.repeat(64)})});
 await f.engine.check();assert.equal(f.engine.snapshot().notification,null);
 assert.equal(f.engine.snapshot().rows[0].assessment.code,'compatibility-unknown');
});
test('empty published list is different from access failure',async()=>{
 const empty=setup(()=>reply([]));await empty.engine.check();assert.equal(empty.engine.snapshot().status,'checked');assert.equal(empty.calls.length,1);
 const denied=setup(()=>reply('',404));await denied.engine.check();assert.equal(denied.engine.snapshot().status,'access-unavailable');assert.equal(denied.engine.snapshot().last_success,0);
});
test('beta preference is explicit and does not fetch again',async()=>{
 const r=clone(fixture.release);Object.assign(r,{version:'0.1.0-beta.2',tag:'v0.1.0-beta.2',channel:'beta'});
 const f=setup(url=>url===D.CATALOG?reply(catalog(r)):reply([raw({tag_name:r.tag,prerelease:true})]));
 await f.engine.check();assert.equal(f.engine.snapshot().rows.length,0);assert.equal(f.engine.snapshot().notification,null);
 f.engine.setPreferences({include_beta:true});assert.equal(f.engine.snapshot().suggested.version,r.version);assert.equal(f.calls.length,2);
});
test('pipeline, withdrawn, drafts, mismatched catalog and same-name unknown identities are not updates',async()=>{
 for(const qualification of ['pipeline-test','withdrawn','candidate']){
  const r=clone(fixture.release);r.qualification=qualification;
  const f=setup(url=>url===D.CATALOG?reply(catalog(r)):reply([raw()]));await f.engine.check();assert.equal(f.engine.snapshot().notification,null);
 }
 const draft=setup(()=>reply([raw({draft:true})]));await draft.engine.check();assert.equal(draft.engine.snapshot().rows.length,0);
 const mismatch=setup(url=>url===D.CATALOG?reply({...catalog(),releases:[{release_id:999,metadata:fixture.release}]}):reply([raw()]));
 await mismatch.engine.check();assert.equal(mismatch.engine.snapshot().notification,null);
});
test('ETags and matching 304 bodies are reused; orphan 304 is an error',async()=>{
 const f=setup((url,options,n)=>url===D.CATALOG?reply(catalog()):n>2?reply(null,304):reply([raw()],200,{ETag:'"first"'}));
 await f.engine.check();f.advance(D.COOLDOWN);await f.engine.check();
 assert.equal(f.calls[2].options.headers['If-None-Match'],'"first"');assert.equal(f.engine.snapshot().suggested.version,'0.1.0');
 const orphan=setup(()=>reply(null,304));await orphan.engine.check();assert.equal(orphan.engine.snapshot().status,'invalid-cache');
});
test('rate-limit headers block manual and automatic requests until deadline',async()=>{
 const f=setup(()=>reply('',429,{'Retry-After':'7200'}));await f.engine.check();
 assert.equal(f.engine.snapshot().status,'rate-limited');f.advance(D.HOUR);assert.equal(await f.engine.check(),false);assert.equal(f.calls.length,1);
 f.advance(D.HOUR);await f.engine.check();assert.equal(f.calls.length,2);
});
test('secondary limit without readable headers backs off and persists across tabs/reload',async()=>{
 const f=setup(()=>reply('',403));await f.engine.check();assert.equal(await f.engine.check(),false);
 f.advance(D.COOLDOWN);await f.engine.check();const deadline=f.engine.snapshot().retry_at;
 assert(deadline-f.engine.clock()>=2*D.COOLDOWN);
 const restored=setup(()=>{throw Error('must not fetch');},{storage:f.store,clock:f.engine.clock});
 await restored.engine.tick();assert.equal(restored.calls.length,0);assert.equal(restored.engine.snapshot().retry_at,deadline);
});
test('offline failure retains dated cache and never claims a new successful check',async()=>{
 let offline=false;const f=setup(url=>{if(offline)throw Error('network');return url===D.CATALOG?reply(catalog()):reply([raw()]);});
 await f.engine.check();const success=f.engine.snapshot().last_success;offline=true;f.advance(D.STALE);await f.engine.check();
 const s=f.engine.snapshot();assert.equal(s.last_success,success);assert.equal(s.status,'offline');assert.equal(s.stale,true);assert.match(s.notification,/stale/);
 const restored=setup(null,{storage:f.store,clock:f.engine.clock});assert.equal(restored.engine.snapshot().status,'offline');
});
test('hidden page and automatic preference prevent polling; manual checks obey cooldown',async()=>{
 const f=setup();f.hide();await f.engine.tick();assert.equal(f.calls.length,0);
 f.show();f.engine.setPreferences({automatic:false});await f.engine.tick();assert.equal(f.calls.length,0);
 await f.engine.check();assert.equal(f.calls.length,2);await f.engine.check();assert.equal(f.calls.length,2);
 f.advance(D.COOLDOWN);await f.engine.check();assert.equal(f.calls.length,4);
});
test('in-flight requests and shared lease prevent duplicate checks',async()=>{
 let resolve;const f=setup(()=>new Promise(r=>resolve=r));const pending=f.engine.check();
 assert.equal(await f.engine.check(),false);assert.equal(f.calls.length,1);
 const second=setup(()=>{throw Error('unexpected');},{storage:f.store,random:()=>0.75});
 assert.equal(await second.engine.check(),false);assert.equal(second.calls.length,0);
 resolve(reply([]));await pending;
});
test('pagination is sequential, bounded to three pages and marks truncated history',async()=>{
 let page=0;const f=setup(url=>{
  if(url===D.CATALOG)return reply({schema:'telescope-cover-catalog-preview/1',releases:[]});
  page++;return reply([raw({id:page})],200,{Link:`<https://api.github.com/repositories/123/releases?per_page=30&page=${page+1}>; rel="next"`});
 });await f.engine.check();assert.equal(f.engine.snapshot().incomplete,true);assert.equal(f.calls.length,4);
 const bad=setup(()=>reply([raw()],200,{Link:'<https://attacker.example/releases?per_page=30&page=2>; rel="next"'}));
 await bad.engine.check();assert.equal(bad.engine.snapshot().status,'invalid-pagination');assert.equal(bad.calls.length,1);
});
test('malformed, mismatched prerelease and oversized provider data do not replace valid results',async()=>{
 for(const payload of ['{bad',{},[raw({prerelease:true})],[raw({tag_name:'v01.0.0'})]]){
  const f=setup(()=>reply(payload));await f.engine.check();assert.equal(f.engine.snapshot().status,'invalid-metadata');assert.equal(f.engine.snapshot().last_success,0);
 }
 const huge=setup(()=>reply('x'.repeat(1048577)));await huge.engine.check();assert.equal(huge.engine.snapshot().status,'response-too-large');
});
test('storage denied, corrupt cache and clock changes remain recoverable',async()=>{
 const unavailable={getItem(){throw Error('denied');},setItem(){throw Error('denied');}};
 const f=setup(null,{storage:unavailable});await f.engine.check();assert.equal(f.engine.snapshot().status,'checked');
 f.advance(-D.HOUR);assert.equal(f.engine.snapshot().status,'clock-changed');assert.equal(f.engine.snapshot().can_check,true);assert.equal(f.engine.snapshot().notification,null);
 const store=storage();store.setItem(D.CACHE,'{bad');const bad=setup(null,{storage:store});await bad.engine.check();assert.equal(bad.engine.snapshot().status,'checked');
});
test('preferences and cache restore without caching a device compatibility verdict',async()=>{
 const f=setup();await f.engine.check();f.engine.setPreferences({include_beta:true});
 const restored=setup(null,{storage:f.store,getDevice:()=>null});
 assert.equal(restored.engine.snapshot().rows.length,1);assert.equal(restored.engine.snapshot().preferences.include_beta,true);
 assert.equal(restored.engine.snapshot().notification,null);assert.equal(restored.engine.snapshot().rows[0].assessment.code,'compatibility-unknown');
 assert.equal(f.store.getItem(D.CACHE).includes('assessment'),false);
});
test('catalog parser rejects duplicate fields, duplicate release IDs and unknown schema',()=>{
 const text=JSON.stringify(catalog());assert.equal(M.parseCatalogJson(text).releases.length,1);
 assert.throws(()=>M.parseCatalogJson(text.replace('"schema":','"schema":"ignored","schema":')));
 const duplicate=catalog();duplicate.releases.push(duplicate.releases[0]);assert.throws(()=>M.parseCatalogJson(JSON.stringify(duplicate)));
 assert.throws(()=>M.parseCatalogJson(JSON.stringify({...catalog(),schema:'future'})));
});
test('live read-only capabilities explain blocking without advertising an update',async()=>{
 const device={...clone(fixture.device),schema:M.LIVE_DEVICE_SCHEMA,read_only_test:true,servo_profile_verified:false};
 const f=setup(null,{getDevice:()=>device});
 await f.engine.check();
 const s=f.engine.snapshot();
 assert.equal(s.rows[0].assessment.code,'read-only-test');
 assert.equal(s.metadata_error,false);assert.equal(s.notification,null);
 device.firmware={...device.firmware,elf:'a'.repeat(64)};
 assert.equal(f.engine.snapshot().rows[0].assessment.code,'compatibility-unknown');
});
test('ordinary failures back off automatic checks but allow manual retry after one minute',async()=>{
 const f=setup(()=>{throw Error('network');});
 await f.engine.check();assert.equal(f.engine.snapshot().check_block,'cooldown');
 f.advance(D.COOLDOWN);await f.engine.check();
 assert.equal(f.engine.snapshot().retry_at-f.engine.clock(),2*D.COOLDOWN);
 assert.equal(f.engine.snapshot().last_success,0);
 f.advance(D.COOLDOWN);
 assert.equal(f.engine.snapshot().can_check,true);
 assert.equal(f.engine.snapshot().check_block,null);
 await f.engine.tick();assert.equal(f.calls.length,2,'automatic backoff still applies');
 await f.engine.check();assert.equal(f.calls.length,3,'manual retry does not inherit automatic backoff');
});
test('explicit rate limits and secondary-limit backoff still block manual checks',async()=>{
 const f=setup(()=>reply('',403));
 await f.engine.check();f.advance(D.COOLDOWN);await f.engine.check();
 f.advance(D.COOLDOWN);
 assert.equal(f.engine.snapshot().check_block,'rate-limited');
 assert.equal(f.engine.snapshot().can_check,false);
 assert.equal(await f.engine.check(),false);
 const restored=setup(null,{storage:f.store,clock:f.engine.clock});
 assert.equal(restored.engine.snapshot().can_check,false);
 f.advance(D.COOLDOWN);assert.equal(f.engine.snapshot().can_check,true);
});
test('old cached failure backoff does not lock manual retry, but old rate limits do',async()=>{
 for(const status of ['offline','access-unavailable','rate-limited']){
  const f=setup(()=>reply('',404));await f.engine.check();f.advance(D.COOLDOWN);
  const cache=JSON.parse(f.store.getItem(D.CACHE));cache.schema=1;cache.state.status=status;
  cache.state.retry_at=f.engine.clock()+5*D.COOLDOWN;cache.state.next_check=cache.state.retry_at;
  delete cache.state.rate_limit_until;f.store.setItem(D.CACHE,JSON.stringify(cache));
  const restored=setup(null,{storage:f.store,clock:f.engine.clock});
  assert.equal(restored.engine.snapshot().can_check,status!=='rate-limited',status);
 }
});

test('long server Retry-After waits survive cache restore',async()=>{
 const f=setup(()=>reply('',429,{'Retry-After':'86400'}));await f.engine.check();
 const restored=setup(null,{storage:f.store,clock:f.engine.clock});
 assert.equal(restored.engine.snapshot().check_block,'rate-limited');
 assert.equal(restored.engine.snapshot().manual_check_at,f.engine.clock()+D.STALE);
 assert.equal(await restored.engine.check(),false);
});
