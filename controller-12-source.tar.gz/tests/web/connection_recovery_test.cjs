/* Exercise the real transport with a persistent tab store and controlled clock. */
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync('data/ui/transport.js','utf8').replace('  async function start() {',
 '  window.testRecovery={tick:recoveryTick,unavailable:connectionUnavailable};\n  async function start() {');
const key='cover.connectionReloads.v1';
const settle=async()=>{for(let i=0;i<20;i++)await Promise.resolve();};
function fixture(store=new Map(),options={}){
 let clock=0,reloads=0,guard=true;
 const calls=[],intervals=[],events={},windowEvents={};
 const storage={getItem:k=>{if(options.storageReadFails)throw Error('blocked');return store.get(k)??null;},
  setItem:(k,v)=>{if(options.storageWriteFails)throw Error('blocked');if(!options.storageIgnoresWrites)store.set(k,v);},removeItem:k=>store.delete(k)};
 const window={sessionStorage:storage,location:{reload:()=>++reloads},addEventListener:(k,fn)=>(windowEvents[k]??=[]).push(fn)};
 const document={hidden:false,addEventListener:(k,fn)=>(events[k]??=[]).push(fn),dispatchEvent(){}};
 const status=()=>({state:'CLOSED',moving:false,holding:false,dirty:false,control_generation:1,uptime_ms:clock+1,position:500,age_ms:0,notice:''});
 const fetch=async(path,opts)=>{
  calls.push({path,opts});
  if(options.hang)return new Promise(()=>{});
  if(options.offline)throw new TypeError('Network unavailable');
  const body=path==='/api/session'?{token:'test',boot_id:'test',beta_accepted:true}:path==='/api/status'?status():{};
  return {ok:true,status:200,text:async()=>JSON.stringify(body)};
 };
 vm.runInNewContext(source,{window,document,fetch,crypto:{getRandomValues:a=>{a[0]=1;return a;}},
  performance:{now:()=>clock},AbortSignal,URLSearchParams,Event,CustomEvent:class{},
  setTimeout(){},setInterval:(fn,ms)=>intervals.push({fn,ms}),Date,Map,Set});
 const api=window.coverAPI;api.canAutoReload=()=>guard;
 const tick=at=>{clock=at;window.testRecovery.tick();};
 const healthy=at=>{clock=at;api.state.session={token:'test'};api.state.cover=status();api.state.coverAt=at;window.testRecovery.tick();};
 return {api,document,store,calls,intervals,windowEvents,tick,healthy,unavailable:window.testRecovery.unavailable,
  get reloads(){return reloads;},setGuard:value=>{guard=value;},show(at){clock=at;document.hidden=false;for(const fn of events.visibilitychange)fn();}};
}
(async()=>{
 // The second document inherits the first attempt; a third cannot reload again.
 const store=new Map();const a=fixture(store);
 a.tick(9999);assert.equal(a.reloads,0);a.tick(10000);assert.equal(a.reloads,1);assert.equal(store.get(key),'1');
 a.tick(90000);assert.equal(a.reloads,1);
 const b=fixture(store);b.tick(10000);assert.equal(b.reloads,1);assert.equal(store.get(key),'2');
 const c=fixture(store);for(const t of [10000,20000,60000,3600000])c.tick(t);
 assert.equal(c.reloads,0);assert.match(c.api.state.message,/stopped after two attempts/);
 assert.equal(a.calls.length+b.calls.length+c.calls.length,0,'Recovery never sends actuator commands');

 // A brief success cannot reset the budget; 30 seconds of observed health can.
 const d=fixture(new Map([[key,'2']]));d.healthy(0);d.healthy(1000);d.tick(11000);
 assert.equal(d.reloads,0);assert.equal(d.store.get(key),'2');
 for(let t=12000;t<=41000;t+=1000)d.healthy(t);
 assert.equal(d.store.get(key),'2');d.healthy(42000);assert.equal(d.store.has(key),false);
 d.tick(52000);assert.equal(d.reloads,1);assert.equal(d.store.get(key),'1');
 // A suspended timer interval is not continuous healthy observation.
 const gap=fixture(new Map([[key,'2']]));gap.healthy(0);gap.healthy(60000);assert.equal(gap.store.get(key),'2');

 // Visible grace also applies to old/bfcache pages, and reads the latest budget.
 const hidden=fixture();hidden.document.hidden=true;hidden.tick(60000);assert.equal(hidden.reloads,0);
 hidden.show(60000);hidden.tick(69999);assert.equal(hidden.reloads,0);hidden.tick(70000);assert.equal(hidden.reloads,1);
 const history=fixture();history.store.set(key,'2');for(const fn of history.windowEvents.pageshow)fn();
 history.tick(10000);assert.equal(history.reloads,0);

 // If persistence is unavailable, unreliable or corrupt, do not risk a loop.
 for(const option of ['storageReadFails','storageWriteFails','storageIgnoresWrites']){
  const f=fixture(new Map(),{[option]:true});f.tick(10000);f.tick(60000);assert.equal(f.reloads,0,option);
 }
 for(const bad of ['garbage','-1','3','1.5']){const f=fixture(new Map([[key,bad]]));f.tick(10000);assert.equal(f.reloads,0,bad);}

 // Safety, operations and unsaved state always take precedence over reloads.
 for(const patch of [{active:true},{repeats:{}},{busy:true},{cover:{moving:true}},{cover:{holding:true}},
   {cover:{dirty:true}},{cover:{maintenance:{locked:true}}},{cover:{ota:{active:true}}},{network:{busy:true}}]){
  const f=fixture();Object.assign(f.api.state,patch);f.tick(10000);assert.equal(f.reloads,0,JSON.stringify(patch));
 }
 const draft=fixture();draft.setGuard(false);draft.tick(10000);assert.equal(draft.reloads,0);
 draft.setGuard(true);draft.tick(10001);assert.equal(draft.reloads,1);
 const unknown=fixture();delete unknown.api.canAutoReload;unknown.tick(10000);assert.equal(unknown.reloads,0);
 const badGuard=fixture();badGuard.api.canAutoReload=()=>{throw Error('render failed');};badGuard.tick(10000);assert.equal(badGuard.reloads,0);

 // The independent timer is installed even if the first session fetch never settles.
 const hung=fixture(new Map(),{hang:true});hung.api.start();await settle();
 assert(hung.intervals.some(t=>t.ms===1000));hung.tick(10000);assert.equal(hung.reloads,1);
 assert(hung.calls.every(call=>call.opts.method==='GET'));

 // A recovered status clears only its own stale unavailable banner.
 const restored=fixture();restored.api.state.session={token:'test'};restored.unavailable();
 assert(restored.api.state.error);await restored.api.cover();
 assert.match(restored.api.state.message,/connection restored/);assert.equal(restored.api.state.error,false);
 restored.unavailable();restored.api.note('A separate command failed',true);await restored.api.cover();
 assert.equal(restored.api.state.message,'A separate command failed');assert(restored.api.state.error);
 // Telescope-only failures do not reload a healthy controller page.
 const scope=fixture();scope.api.state.scope={enabled:true,valid:false,error:'timeout'};
 for(let t=0;t<=60000;t+=1000)scope.healthy(t);assert.equal(scope.reloads,0);
 console.log('Connection recovery: two persistent attempts, grace/reset timing, suspension, storage failure, safety/draft gates, hung startup and stale-message clearing passed');
})().catch(error=>{console.error(error);process.exitCode=1;});
