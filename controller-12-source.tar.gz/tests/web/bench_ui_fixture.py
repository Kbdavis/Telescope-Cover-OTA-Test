"""Loopback UI fixture only. Never accesses the controller or GitHub."""
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'tools'))
from bench_assets import assets
ASSETS=assets(ROOT)
class Handler(BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def do_GET(self):
  route=self.path.split('?')[0]
  if route in ['/','/app.js']:
   data=ASSETS['index.html' if route=='/' else 'app.js'];kind='text/html' if route=='/' else 'application/javascript'
  elif route=='/api/bench/status':
   data=json.dumps(dict(profile='bench-ota-v1',servo_operations=False,accepted=True,build=5,version='0.1.0-beta.5',elf='a'*64,boot='fixture-boot-5',nonce='fixture-nonce-5',phase='idle',settings_preserved=True)).encode();kind='application/json'
  elif route=='/api/bench/session':
   data=json.dumps(dict(boot='fixture-boot-5',nonce='fixture-nonce-5',update_token='e'*64)).encode();kind='application/json'
  else:self.send_error(404);return
  self.send_response(200);self.send_header('Content-Type',kind);self.send_header('Content-Length',str(len(data)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(data)
if __name__=='__main__':
 print('Bench UI fixture http://127.0.0.1:8099 — no hardware',flush=True)
 ThreadingHTTPServer(('127.0.0.1',8099),Handler).serve_forever()
