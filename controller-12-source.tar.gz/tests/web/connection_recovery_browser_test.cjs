/* Local fixture on 8095, isolated Chrome CDP on 9226. No hardware requests. */
const assert=require('node:assert/strict');
const base='http://127.0.0.1:8095',key='cover.connectionReloads.v1';
const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
(async()=>{
 const pages=await(await fetch('http://127.0.0.1:9226/json/list')).json();
 const ws=new WebSocket(pages.find(p=>p.type==='page').webSocketDebuggerUrl),pending=new Map(),errors=[],documents=[];let sequence=0;
 await new Promise((r,j)=>{ws.addEventListener('open',r,{once:true});ws.addEventListener('error',j,{once:true});});
 const call=(method,params={})=>new Promise((resolve,reject)=>{const id=++sequence;pending.set(id,{resolve,reject});ws.send(JSON.stringify({id,method,params}));});
 ws.addEventListener('message',event=>{const m=JSON.parse(event.data);
  if(m.id){const p=pending.get(m.id);pending.delete(m.id);m.error?p.reject(Error(m.error.message)):p.resolve(m.result);}
  if(m.method==='Runtime.exceptionThrown')errors.push(m.params.exceptionDetails);
  if(m.method==='Network.requestWillBeSent'&&m.params.type==='Document'&&m.params.request.url.startsWith(base))documents.push(m.params.request.url);
 });
 const ev=async expression=>{const r=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true,userGesture:true});if(r.exceptionDetails)throw Error(r.exceptionDetails.exception?.description||r.exceptionDetails.text);return r.result.value;};
 const wait=async(test,label,timeout=15000)=>{const deadline=Date.now()+timeout;while(Date.now()<deadline){try{if(await test())return;}catch(_){}await delay(100);}throw Error('Timed out: '+label);};
 const expression=(text,label,timeout)=>wait(()=>ev(text),label,timeout);
 const patch=async value=>{const r=await fetch(base+'/test/patch',{method:'POST',body:JSON.stringify(value)});assert(r.ok);};
 try{
  await call('Runtime.enable');await call('Page.enable');await call('Network.enable');await call('Emulation.setFocusEmulationEnabled',{enabled:true});
  await fetch(base+'/test/reset',{method:'POST'});await patch({controls:{beta:true}});
  await call('Page.navigate',{url:base+'/'});
  await expression('window.coverAPI?.state.network&&coverAPI.freshCover()','healthy page');
  await ev(`sessionStorage.removeItem('${key}')`);
  // Protect unsaved edits even if the page is inaccessible for longer than the grace.
  await ev("document.getElementById('nav-configuration').click();document.getElementById('cfg-hostname').value='keep-this-draft';document.getElementById('cfg-hostname').dispatchEvent(new Event('input',{bubbles:true}))");
  assert.equal(await ev('coverAPI.canAutoReload()'),false);
  const originalDocuments=documents.length;await patch({controls:{drop_status:true}});await delay(12000);
  assert.equal(documents.length,originalDocuments);
  assert.equal(await ev("document.getElementById('cfg-hostname').value"),'keep-this-draft');
  await patch({controls:{drop_status:false}});await expression('coverAPI.freshCover()','draft recovery');
  await ev("document.querySelector('[data-discard=name]').click();document.getElementById('nav-overview').click();document.getElementById('ov-supervised').click()");
  assert.equal(await ev('coverAPI.canAutoReload()'),true);
  assert.equal(await ev("document.getElementById('ov-supervised').checked"),true);
  // Real navigation, including a failed initial status request on the next page.
  await patch({controls:{drop_status:true}});
  await wait(()=>documents.length===originalDocuments+1,'first automatic reload',20000);
  await expression(`window.coverAPI&&sessionStorage.getItem('${key}')==='1'`,'first persisted count');
  assert.equal(await ev("document.getElementById('ov-supervised').checked"),false);
  await wait(()=>documents.length===originalDocuments+2,'second automatic reload',20000);
  await expression(`window.coverAPI&&sessionStorage.getItem('${key}')==='2'`,'second persisted count');
  await delay(12000);assert.equal(documents.length,originalDocuments+2,'No third reload');
  await expression("coverAPI.state.message.includes('stopped after two attempts')",'capped recovery message');
  assert.equal(await ev("document.getElementById('ov-open').disabled"),true);
  await patch({controls:{drop_status:false}});
  await expression('coverAPI.freshCover()&&!coverAPI.state.error','connection restored');
  assert.equal(await ev('coverAPI.state.message.includes("connection unavailable")'),false);
  assert.equal(await ev(`sessionStorage.getItem('${key}')`),'2','One success does not reset the budget');
  assert.equal(await ev("document.getElementById('ov-supervised').checked"),false);
  assert.equal(await ev('coverAPI.state.active'),false);
  const events=await(await fetch(base+'/test/events')).json();
  assert.equal(events.length,0,'Reload recovery sends no commands');assert.deepEqual(errors,[]);
  console.log('Browser recovery: unsaved draft preserved, exactly two real reloads, persistent cap, cleared supervision and automatic status recovery passed');
 }finally{await patch({controls:{drop_status:false}}).catch(()=>{});ws.close();}
})().catch(error=>{console.error(error);process.exitCode=1;});
