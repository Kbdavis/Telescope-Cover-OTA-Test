/* Run against a local API fixture on 8091 and isolated Chrome CDP on 9226.
 * Node 22+; no dependencies, hardware calls, or credentials. Screenshots go to /tmp. */
const assert=require('node:assert/strict');
const fs=require('node:fs');
const connect=async()=>{
const targets=await(await fetch('http://127.0.0.1:9226/json/list')).json();
const ws=new WebSocket(targets.find(t=>t.type==='page').webSocketDebuggerUrl),pending=new Map(),errors=[],requests=[],logs=[];let id=0;
await new Promise((r,j)=>{ws.addEventListener('open',r,{once:true});ws.addEventListener('error',j,{once:true});});
ws.addEventListener('message',e=>{const m=JSON.parse(e.data);if(m.id){const p=pending.get(m.id);pending.delete(m.id);m.error?p.j(Error(m.error.message)):p.r(m.result);}if(m.method==='Runtime.exceptionThrown')errors.push(m.params.exceptionDetails);if(m.method==='Network.requestWillBeSent')requests.push(m.params.request.url);if(m.method==='Log.entryAdded')logs.push(m.params.entry);if(m.method==='Page.javascriptDialogOpening'&&m.params.type==='beforeunload')call('Page.handleJavaScriptDialog',{accept:true});});
const call=(method,params={})=>new Promise((r,j)=>{const n=++id;pending.set(n,{r,j});ws.send(JSON.stringify({id:n,method,params}));});
const ev=async expression=>{const r=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true,userGesture:true});if(r.exceptionDetails)throw Error(r.exceptionDetails.exception?.description||r.exceptionDetails.text);return r.result.value;};
const shot=async n=>{const img=await call('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});fs.writeFileSync('/tmp/'+n+'.png',Buffer.from(img.data,'base64'));};
await call('Runtime.enable');await call('Page.enable');await call('Network.enable');await call('Log.enable');
return {call,ev,shot,errors,requests,logs,close:()=>ws.close()};};
const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
(async()=>{
 const c=await connect(),{call,ev}=c;
 const base=process.env.FIXTURE_URL||'http://127.0.0.1:8091';
 const patch=async value=>fetch(base+'/test/patch',{method:'POST',body:JSON.stringify(value)});
 const wait=async expression=>{for(let n=0;n<200;n++){if(await ev(expression))return;await delay(50);}throw Error('Timed out: '+expression);};
 try{
  await fetch(base+'/test/reset',{method:'POST'});
  await call('Page.navigate',{url:base+'/'});await wait('window.coverAPI?.state.network&&coverAPI.state.cover');
  await ev("document.getElementById('betaAccept').click()");await wait('coverAPI.state.session.beta_accepted');
  await patch({cover:{control_generation:10,maintenance:{owner:'ota',phase:'ready',generation:4,locked:true}}});
  await ev('coverAPI.cover()');
  assert.equal(await ev("document.getElementById('ov-open').disabled"),true);
  await ev("document.getElementById('nav-manual').click()");
  assert.equal(await ev("document.getElementById('manual-enable').disabled&&document.getElementById('manual-reboot').disabled"),true);
  assert.equal(await ev("coverAPI.request('stop',{body:{automatic:'yes',control_generation:9}}).then(()=>false,()=>true)"),true);
  await ev('coverAPI.cover()');assert.equal(await ev('coverAPI.state.cover.control_generation'),10);
  assert.equal(await ev("coverAPI.request('recover',{body:{inspect:'yes'}}).then(()=>false,()=>true)"),true);
  await ev("document.getElementById('nav-configuration').click()");
  assert.equal(await ev("document.getElementById('cfg-name-fields').disabled"),true);
  assert.equal(await ev("document.getElementById('stop').disabled"),false);
  await ev('coverAPI.stop()');await ev('coverAPI.cover()');
  assert.equal(await ev('coverAPI.state.cover.control_generation'),11);
  assert.equal(await ev('coverAPI.state.cover.maintenance.locked'),true);
  assert.equal(await ev('coverAPI.state.cover.maintenance.phase'),'revoked');
  const events=await(await fetch(base+'/test/events')).json();
  assert(!events.some(e=>e.path==='manual/enable'||e.path==='controller/reboot'));
  assert.deepEqual(c.errors,[]);
  console.log('Maintenance browser: locked views, stale cleanup rejection and explicit Stop without unlocking passed');
 }finally{c.close();}
})().catch(error=>{console.error(error);process.exitCode=1;});
