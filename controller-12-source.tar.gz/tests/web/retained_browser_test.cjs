/* Local fixture on 8098, isolated Chrome CDP on 9228. Never contacts hardware. */
const assert=require('node:assert/strict'),fs=require('node:fs');
const delay=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{
 const targets=await(await fetch('http://127.0.0.1:9228/json/list')).json();
 const ws=new WebSocket(targets.find(t=>t.type==='page').webSocketDebuggerUrl),pending=new Map(),requests=[],errors=[];let id=0;
 await new Promise((resolve,reject)=>{ws.addEventListener('open',resolve,{once:true});ws.addEventListener('error',reject,{once:true});});
 ws.addEventListener('message',e=>{
  const message=JSON.parse(e.data);
  if(message.id){const p=pending.get(message.id);pending.delete(message.id);message.error?p.reject(message.error):p.resolve(message.result);}
  if(message.method==='Network.requestWillBeSent')requests.push(message.params.request.url);
  if(message.method==='Runtime.exceptionThrown')errors.push(message.params.exceptionDetails);
 });
 const call=(method,params={})=>new Promise((resolve,reject)=>{const current=++id;pending.set(current,{resolve,reject});ws.send(JSON.stringify({id:current,method,params}));});
 const evaluate=async expression=>{const result=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(result.exceptionDetails)throw Error(result.exceptionDetails.text);return result.result.value;};
 const wait=async expression=>{for(let i=0;i<150;i++){if(await evaluate(expression))return;await delay(50);}throw Error('Timed out: '+expression);};
 try{
  await call('Runtime.enable');await call('Network.enable');await call('Page.enable');
  await fetch('http://127.0.0.1:8098/test/patch',{method:'POST',body:JSON.stringify({network:{enable_debug_tab:true},controls:{beta:true,
   retained_wifi:{context:{firmware:'a'.repeat(64),boot_id:'old-boot',uptime_ms:12000,free_heap:170000,minimum_heap:150000,largest_internal_block:90000},same_boot:false,active_in_recorded_boot:true,first_reason:8,last_reason:2,rssi:-80,bssid:'01:02:03:04:05:06',retries:3,retry_result:12295,last_retry_uptime_ms:20000,next_wait_ms:120000,outage_ms:null,local_action:'saved-STA-retry',action_age_ms:40000},
   retained_fault:{context:{firmware:'b'.repeat(64),boot_id:'old-boot',uptime_ms:5000,free_heap:180000,minimum_heap:160000,largest_internal_block:100000},message:'<img src=x onerror=alert(1)> Servo timeout',position:500,target:1500}}})});
  await call('Emulation.setDeviceMetricsOverride',{width:1280,height:1500,deviceScaleFactor:1,mobile:false});
  await call('Page.navigate',{url:'http://127.0.0.1:8098/#debug'});
  await wait('window.coverAPI?.state.network?.enable_debug_tab && window.coverAPI?.state.session?.boot_id');await delay(500);
  const reads=()=>requests.filter(url=>url.includes('/api/debug/retained')).length;
  assert.equal(reads(),0);
  await evaluate("document.getElementById('debug-retained').open=true");
  await wait("document.getElementById('retained-wifi').textContent.includes('earlier boot')");
  assert.equal(await evaluate("document.getElementById('retained-wifi-largest').textContent"),'90000 bytes');
  assert.equal(await evaluate("document.getElementById('retained-fault').querySelector('img')"),null);
  assert.equal(await evaluate("document.getElementById('debug-metrics').open"),false);
  const screenshot=await call('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});
  fs.writeFileSync('/tmp/cover-retained-summary.png',Buffer.from(screenshot.data,'base64'));
  await evaluate("document.getElementById('debug-retained').open=false");await delay(100);
  const count=reads();await delay(5500);assert.equal(reads(),count);
  assert.equal(requests.filter(url=>url.includes('/diagnostics/metrics/')).length,0);
  assert.deepEqual(errors,[]);
  console.log('Real browser: summary renders safely, metrics stay OFF, closed panel sends no summary requests; screenshot /tmp/cover-retained-summary.png');
 }finally{ws.close();}
})().catch(error=>{console.error(error);process.exitCode=1;});
