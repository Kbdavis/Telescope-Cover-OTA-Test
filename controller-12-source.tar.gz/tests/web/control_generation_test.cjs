const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync('data/ui/transport.js','utf8');
const settle=async()=>{for(let n=0;n<20;n++)await Promise.resolve();};
function fixture(){
 const calls=[],listeners={};let pending=null,generation=1,moving=false;
 const window={addEventListener:(key,fn)=>(listeners[key]??=[]).push(fn)};
 const document={hidden:false,addEventListener:()=>{},dispatchEvent:()=>{}};
 const status=()=>({state:moving?'MANUAL':'STOPPED',control_generation:generation,uptime_ms:1000,position:500,age_ms:0,
  moving,holding:false,owner:0,command_id:0,command_client:1,command_ok:false});
 const response=(body,code=200)=>({ok:code===200,status:code,text:async()=>typeof body==='string'?body:JSON.stringify(body)});
 const fetch=async(url,options)=>{
  const body=Object.fromEntries(options.body||[]),path=url.replace('/api/','');calls.push({path,body});
  if(path==='status')return response(status());
  if(path==='manual/jog-plus')return new Promise(resolve=>pending=()=>resolve(response('Start was overtaken',409)));
  if(path==='stop'){
   if(body.automatic==='yes' && Number(body.control_generation)!==generation)return response('Stale automatic Stop',409);
   moving=false;++generation;return response('Stop queued');
  }
  throw Error('Unexpected request '+path);
 };
 vm.runInNewContext(source,{window,document,fetch,crypto:{getRandomValues:a=>{a[0]=0;return a;}},performance:{now:()=>1000},
  AbortSignal,URLSearchParams,Event,CustomEvent:class{},setTimeout:()=>{},setInterval:()=>{},Date,Map,Set});
 const api=window.coverAPI;api.state.session={token:'boot',beta_accepted:true};api.state.cover=status();api.state.coverAt=1000;
 return {api,calls,listeners,setGeneration:value=>{generation=value;},currentGeneration:()=>generation,finish:()=>pending()};
}
(async()=>{
 const f=fixture();
 const command=f.api.command('manual/jog-plus',{step:1},{motion:true}).catch(()=>{});await settle();
 assert.equal(f.calls[0].body.control_generation,'1');
 await f.api.stop();assert.equal(f.currentGeneration(),2);
 const explicit=f.calls.find(call=>call.path==='stop');assert.equal(explicit.body.automatic,undefined);
 // A newer maintenance generation is acknowledged while the old start is in flight.
 f.setGeneration(7);await f.api.cover();f.finish();await command;
 const cleanup=f.calls.filter(call=>call.path==='stop' && call.body.automatic==='yes');
 assert(cleanup.length>=1);assert(cleanup.every(call=>call.body.control_generation==='1' && call.body.stop_reason==='command_cleanup'));
 assert.equal(f.currentGeneration(),7); // Late cleanup never borrows the latest status generation.
 await f.api.stop();assert.equal(f.currentGeneration(),8); // Explicit Stop remains unconditional.
 const g=fixture();const start=g.api.command('manual/jog-plus',{step:1},{motion:true}).catch(()=>{});await settle();
 for(const listener of g.listeners.pagehide)listener();await settle();
 const hidden=g.calls.find(call=>call.path==='stop');assert.equal(hidden.body.automatic,'yes');
 assert.equal(hidden.body.control_generation,'1');assert.equal(hidden.body.stop_reason,'page_hidden');
 g.finish();await start;
 console.log('Control protocol: explicit Stop, delayed command cleanup and pagehide keep the observed generation passed');
})().catch(error=>{console.error(error);process.exitCode=1;});
