const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const source=fs.readFileSync('data/ui/app.js','utf8'),nodes=new Map(),calls=[],listeners={};
const el=id=>{if(!nodes.has(id))nodes.set(id,{checked:false});return nodes.get(id);};
let now=100,fresh=true;
const state={cover:{state:'OPEN',control_generation:1},scope:{enabled:true},scopeAt:100,network:{busy:false},session:{beta_accepted:true},view:'overview',generation:1};
const context={state,$:el,api:{now:()=>now,freshScope:()=>fresh&&state.scope.valid===true,freshStow:()=>false,freshCover:()=>true,
 scope:async()=>{throw Error('unavailable');},note(){},command:async(path,body)=>calls.push({path,body})},
 commonReason:()=>'',coverTravel:{directPath:()=>true},render(){},configBusy:false,freshNetwork:()=>true,moving:()=>false,armLocked:()=>false,
 window:{addEventListener:(name,fn)=>listeners[name]=fn},document:{hidden:false,hasFocus:()=>true,addEventListener:(name,fn)=>listeners[name]=fn}};
vm.createContext(context);
vm.runInContext(source.slice(source.indexOf(' let overrideUntil='),source.indexOf(' function syncTheme()')),context);
vm.runInContext(source.slice(source.indexOf(' async function moveCover('),source.indexOf(' function metricText(')),context);
const run=code=>vm.runInContext(code,context);
const approve=()=>{el('ov-override').checked=true;el('ov-override').onchange();};
el('ov-supervised').checked=true;
assert.match(run("coverReason('closed')"),/Stow the telescope|status is unavailable/);
approve();assert.equal(run("coverReason('closed')"),'');
now+=60000;assert.match(run("coverReason('closed')"),/Stow the telescope|status is unavailable/);assert(!el('ov-override').checked);
approve();state.cover.control_generation++;assert(!run('stowOverride()'));
for(const unsafe of [{at_home:false},{at_home:true,slewing:true},{at_home:true,tracking:true}]){
 state.scope={enabled:true,valid:true,...unsafe};approve();assert.match(run("coverReason('closed')"),/Override blocked/);
}
fresh=false;assert.equal(run("coverReason('closed')"),'');
listeners.blur();assert(!run('stowOverride()'));approve();context.document.hidden=true;listeners.visibilitychange();assert(!run('stowOverride()'));context.document.hidden=false;
for(const label of ['OPEN','CLOSED','STOPPED','UNKNOWN','FAULT']){state.cover.state=label;assert.equal(run('settingsReason()'),'');}
state.cover.state='OPEN';state.scope={enabled:true};approve();
(async()=>{
 await run("moveCover('closed')");assert.equal(calls.length,1);assert.equal(calls[0].body.override,'yes');assert.equal(calls[0].body.stowed,'yes');
 assert(!run('stowOverride()'));await run("moveCover('closed')");assert.equal(calls.length,1);
 assert(fs.readFileSync('data/ui/index.html','utf8').includes('class="check stow-override"'));
 console.log('Actual dashboard override: expiry, generation, unsafe reports, blur/hide, one-use close, failed refresh and settings at all states passed');
})().catch(e=>{console.error(e);process.exitCode=1;});
