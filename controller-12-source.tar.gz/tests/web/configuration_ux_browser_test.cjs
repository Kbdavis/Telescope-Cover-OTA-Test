/* Run against a local API fixture on 8094 and isolated Chrome CDP on 9226.
 * Node 22+; no dependencies, hardware calls, or credentials. Screenshots go to /tmp. */
const assert=require('node:assert/strict');
const fs=require('node:fs');
const connect=async()=>{
const targets=await(await fetch('http://127.0.0.1:9226/json/list')).json();
const ws=new WebSocket(targets.find(t=>t.type==='page').webSocketDebuggerUrl),pending=new Map(),errors=[],requests=[],logs=[];let id=0;
await new Promise((r,j)=>{ws.addEventListener('open',r,{once:true});ws.addEventListener('error',j,{once:true});});
ws.addEventListener('message',e=>{const m=JSON.parse(e.data);if(m.id){const p=pending.get(m.id);pending.delete(m.id);m.error?p.j(Error(m.error.message)):p.r(m.result);}if(m.method==='Runtime.exceptionThrown')errors.push(m.params.exceptionDetails);if(m.method==='Network.requestWillBeSent')requests.push(m.params.request.url);if(m.method==='Log.entryAdded')logs.push(m.params.entry);if(m.method==='Page.javascriptDialogOpening'&&m.params.type==='beforeunload')call('Page.handleJavaScriptDialog',{accept:true});});
const call=(method,params={})=>new Promise((r,j)=>{const n=++id;pending.set(n,{r,j});ws.send(JSON.stringify({id:n,method,params}));});
const ev=async expression=>{const r=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true,userGesture:true});if(r.exceptionDetails)throw Error(r.exceptionDetails.exception?.description||r.exceptionDetails.text);return r.result.value;};
const shot=async n=>{const img=await call('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});fs.writeFileSync('/tmp/'+n+'.png',Buffer.from(img.data,'base64'));};
await call('Runtime.enable');await call('Page.enable');await call('Network.enable');await call('Log.enable');
return {call,ev,shot,errors,requests,logs,close:()=>ws.close()};};
const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
(async()=>{
 const c=await connect(),{call,ev,shot}=c;
 const patch=async value=>fetch('http://127.0.0.1:8094/test/patch',{method:'POST',body:JSON.stringify(value)});
 const click=id=>ev(`document.getElementById('${id}').click()`);
 const input=(id,value)=>ev(`document.getElementById('${id}').value=${JSON.stringify(value)};document.getElementById('${id}').dispatchEvent(new Event('input',{bubbles:true}))`);
 const wait=async expression=>{for(let i=0;i<180;i++){if(await ev(expression))return;await delay(75);}throw Error('Timed out: '+expression);};
 try{
 await call('Page.navigate',{url:'about:blank'});await wait("location.href==='about:blank'&&!window.coverAPI");
 await fetch('http://127.0.0.1:8094/test/reset',{method:'POST'});
 await call('Emulation.setFocusEmulationEnabled',{enabled:true});
 await call('Page.navigate',{url:'http://127.0.0.1:8094/#configuration'});
 await wait('window.coverAPI?.state.network&&coverAPI.state.cover&&coverAPI.state.scope');
 await click('betaAccept');await wait('coverAPI.state.session.beta_accepted');
 assert.deepEqual(c.errors,[]);
 assert.equal(await ev("document.getElementById('configurationHeading').textContent"),'Configuration');
 // Session Debug works while OPEN, without a configuration write or restart.
 await patch({cover:{state:'OPEN',position:3200,torque:true}});await ev('coverAPI.cover()');
 await input('cfg-hostname','unsaved-debug-draft');
 const boot=await ev('coverAPI.state.session.boot_id');
 await click('cfg-debug-session');await wait("coverAPI.state.view==='debug'");
 assert.equal(await ev('coverAPI.state.network.enable_debug_tab'),false);
 assert.equal(await ev("document.getElementById('nav-debug').hidden"),false);
 await wait('coverAPI.state.debugMessages.some(entry=>entry.source==="Controller")');
 await ev("document.getElementById('debug-retained').open=true");
 await wait("document.getElementById('retained-reset').textContent.includes('SOFTWARE')");
 await ev("document.getElementById('debug-metrics').open=true");
 await wait('coverAPI.metrics.hasSnapshot()');
 await click('nav-configuration');
 assert.equal(await ev("document.getElementById('cfg-hostname').value"),'unsaved-debug-draft');
 await ev("document.querySelector('[data-discard=name]').click()");
 await click('nav-debug');await ev('window.__configurationBeforeReload=true');await call('Page.reload',{ignoreCache:true});
 await wait("!window.__configurationBeforeReload&&window.coverAPI?.state.network&&coverAPI.state.view==='debug'&&coverAPI.state.debugSession");
 assert.equal(await ev('coverAPI.state.session.boot_id'),boot);
 assert.equal(await ev('coverAPI.state.network.enable_debug_tab'),false);
 const sessionEvents=await(await fetch('http://127.0.0.1:8094/test/events')).json();
 assert(sessionEvents.every(event=>event.path.startsWith('diagnostics/metrics/')));
 await click('debug-end-session');await wait("coverAPI.state.view==='overview'");
 assert.equal(await ev("document.getElementById('nav-debug').hidden"),true);
 assert.equal(await ev("sessionStorage.getItem('cover.debugSession.v1')"),null);
 await click('nav-configuration');
 // Exercise every settings form on a fresh controller without servo feedback.
 await patch({cover:{state:'UNKNOWN',ready:false,calibrated:false,position:null,torque:null,settings_offline_allowed:true}});await ev('coverAPI.cover()');
 assert.equal(await ev("document.getElementById('cfg-lock-reason').hidden"),true);
 assert.equal(await ev("document.getElementById('cfg-recovery-active').hidden"),false);
 assert.equal(await ev("document.getElementById('ov-open').disabled&&document.getElementById('ov-close').disabled"),true);
 for(const id of ['cfg-reset-network','cfg-reset-calibration','cfg-scan'])assert.equal(await ev(`document.getElementById('${id}').disabled`),false);
 await click('cfg-scan');await wait("coverAPI.state.network.message==='Scan complete'");
 await wait("!document.getElementById('cfg-wifi-fields').disabled");
 // Optional NTP: defaults, editable server/zone, retained drafts, save/restart,
 // unavailable server, and configured local time (independent of browser zone).
 assert.equal(await ev("document.getElementById('cfg-ntp-enabled').checked"),false);
 assert.equal(await ev("document.getElementById('cfg-ntp-server').value"),'pool.ntp.org');
 assert.equal(await ev("document.getElementById('cfg-time-zone').value"),'MST7');
 await input('cfg-ntp-server','unreachable.example');await input('cfg-time-zone','EST5EDT,M3.2.0/2,M11.1.0/2');await click('cfg-ntp-enabled');
 await ev('coverAPI.network()');assert.equal(await ev("document.getElementById('cfg-ntp-server').value"),'unreachable.example');
 await click('cfg-time-save');await wait('coverAPI.state.network.ntp_enabled');await wait("!document.getElementById('cfg-time-fields').disabled");
 assert.equal(await ev('coverAPI.state.network.ntp_server'),'unreachable.example');
 assert.equal(await ev('coverAPI.state.network.time_zone'),'EST5EDT,M3.2.0/2,M11.1.0/2');
 assert.match(await ev("document.getElementById('cfg-time-status').textContent"),/Waiting for time synchronization/);
 assert.equal(await ev("document.getElementById('cfg-time-save').disabled"),true);
 await patch({network:{time_synchronized:true,local_time:'2025-12-31T19:00:00-0500'}});await ev('coverAPI.network()');
 assert.match(await ev("document.getElementById('cfg-time-status').textContent"),/2025-12-31T19:00:00-0500/);
 await click('cfg-ntp-enabled');await click('cfg-time-save');await wait('!coverAPI.state.network.ntp_enabled');await wait("!document.getElementById('cfg-time-fields').disabled");
 assert.match(await ev("document.getElementById('cfg-time-status').textContent"),/off/);
 await patch({network:{alpaca_read_only:true}});await ev('coverAPI.network()');
 assert.match(await ev("document.getElementById('cfg-mode').textContent"),/Seestar app may not establish that session/);
 await patch({network:{alpaca_read_only:false}});await ev('coverAPI.network()');
 assert.match(await ev("document.getElementById('cfg-mode').textContent"),/Automatically reconnects monitoring/);
 assert.match(await ev("document.getElementById('cfg-mode').textContent"),/movement stays in the Seestar app/);
 await input('cfg-hostname','garden-cover');await click('cfg-enable-debug');
 await click('cfg-diagnostics-save');assert.equal(await ev("document.getElementById('settingsDraftDialog').open"),true);
 await click('settingsDraftCancel');assert.equal(await ev("document.getElementById('cfg-hostname').value"),'garden-cover');
 await click('cfg-diagnostics-save');await click('settingsDraftConfirm');
 await wait('coverAPI.state.network.enable_debug_tab');await wait("!document.getElementById('cfg-diagnostics-fields').disabled");
 assert.equal(await ev('coverAPI.state.network.disable_torque_after_move'),false);
 assert.equal(await ev("document.getElementById('cfg-hostname').value"),'cover');
 await input('cfg-hostname','garden-cover');await click('cfg-name-save');
 await wait("coverAPI.state.network.mdns_name==='garden-cover'");await wait("!document.getElementById('cfg-name-fields').disabled");
 // Saving holding behavior must not submit a draft Debug setting.
 await click('cfg-enable-debug');await click('cfg-disable-torque');await click('cfg-advanced-save');await click('settingsDraftConfirm');
 await wait('coverAPI.state.network.disable_torque_after_move');await wait("!document.getElementById('cfg-advanced-fields').disabled");
 assert.equal(await ev('coverAPI.state.network.enable_debug_tab'),true);
 await input('cfg-hostname','discard-me');await ev("document.querySelector('[data-discard=name]').click()");assert.equal(await ev("document.getElementById('cfg-hostname').value"),'garden-cover');
 // Disabled monitoring retains saved address; empty addresses do not block disabling.
 await patch({network:{alpaca_host:'',alpaca_enabled:true}});await ev('coverAPI.network()');await ev("document.querySelector('[data-discard=alpaca]').click()");
 await click('cfg-enabled');assert.equal(await ev("document.getElementById('cfg-scope-connection').disabled"),true);
 await click('cfg-alpaca-save');await wait('!coverAPI.state.network.alpaca_enabled');await wait("!document.getElementById('cfg-alpaca-fields').disabled");
 assert.equal(await ev('coverAPI.state.network.alpaca_read_only'),false);
 await input('cfg-password','new-password');await patch({controls:{fail_save:true}});await click('cfg-connect');
 await wait("document.getElementById('cfg-wifi-message').dataset.error==='true'");assert.equal(await ev("document.getElementById('cfg-password').value"),'new-password');
 await patch({controls:{fail_save:false}});await ev("document.querySelector('[data-discard=wifi]').click()");
 await click('cfg-replace-password');assert.equal(await ev("document.getElementById('cfg-connect').disabled"),false);
 await click('cfg-connect');await wait('!coverAPI.state.network.password_saved');await wait("!document.getElementById('cfg-wifi-fields').disabled");
 await click('cfg-enabled');await input('cfg-ip','not-an-address');await click('cfg-alpaca-save');assert.equal(await ev("document.getElementById('cfg-ip').getAttribute('aria-invalid')"),'true');assert.equal(await ev("document.getElementById('cfg-ip-error').hidden"),false);
 await ev("document.querySelector('[data-discard=alpaca]').click()");assert.equal(await ev("document.getElementById('cfg-ip').getAttribute('aria-invalid')"),null);
 await ev("document.getElementById('cfg-reset').open=true");await click('cfg-reset-network');assert.equal(await ev('document.activeElement.id'),'resetCancel');
 assert.equal(await ev("document.getElementById('resetDescription').textContent.includes('motor holding')"),true);await click('resetCancel');
 for(const width of [1440,390]){
 await call('Emulation.setDeviceMetricsOverride',{width,height:1000,deviceScaleFactor:1,mobile:width<500});
 await ev('window.scrollTo(0,0)');assert.equal(await ev('document.documentElement.scrollWidth<=innerWidth'),true);await shot('configuration-ux-'+width);
 }
 // Stationary settings saves permit torque ON/OFF at OPEN as well as CLOSED.
 // Offline permission cannot override active motion, holding or stale HTTP status.
 for(const field of ['moving','holding']){
  await patch({cover:{[field]:true}});await ev('coverAPI.cover()');
  assert.equal(await ev("document.getElementById('cfg-scan').disabled"),true);
  await patch({cover:{[field]:false}});await ev('coverAPI.cover()');
 }
 await patch({controls:{drop_status:true}});await delay(1800);await ev('coverAPI.emit()');
 assert.equal(await ev("document.getElementById('cfg-scan').disabled"),true);
 await patch({controls:{drop_status:false}});await ev('coverAPI.cover()');
 assert.equal(await ev("document.getElementById('cfg-scan').disabled"),false);
 await patch({cover:{state:'CLOSED',ready:true,calibrated:true,position:600,torque:true,settings_offline_allowed:false}});await ev('coverAPI.cover()');assert.equal(await ev("document.getElementById('cfg-lock-reason').hidden"),true);
 for(const state of ['OPEN','STOPPED','UNKNOWN','FAULT']){
  await patch({cover:{state}});await ev('coverAPI.cover()');assert.equal(await ev("document.getElementById('cfg-lock-reason').hidden"),true);
 }
 assert.equal(await ev("document.getElementById('cfg-recovery-active').hidden"),true);
 await ev("document.querySelector('[data-theme=dark]').click()");assert.equal(await ev('document.documentElement.dataset.appearance'),'dark');
 assert.deepEqual(c.errors,[]);console.log('Configuration UX browser checks passed');
 }finally{c.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
