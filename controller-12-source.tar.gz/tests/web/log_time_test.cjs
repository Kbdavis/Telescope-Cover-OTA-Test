const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync('data/ui/app.js','utf8');
const start=source.indexOf(' function receiptLabel('),end=source.indexOf(' function receiptTime(',start);
const context=vm.createContext({Date,Math});
vm.runInContext(source.slice(start,end),context);
const label=context.receiptLabel;
const today=new Date(2026,9,24,12).getTime();
assert.equal(label(today,0,today,59000),'Today · received 59 seconds ago');
assert.equal(label(today,0,today,60000),'Today · received 1 minute ago');
assert.equal(label(today,0,today,119999),'Today · received 1 minute ago');
assert.equal(label(today,0,today,120000),'Today · received 2 minutes ago');
assert.equal(label(today,1000,today,0),'Today · received 0 seconds ago');
// Wall clock jumps do not affect receipt age; midnight changes the calendar label.
assert.equal(label(today,0,today+3600000,2000),'Today · received 2 seconds ago');
assert(!label(today,0,today+86400000,86400000).startsWith('Today'));
assert(label(today,0,today+86400000,86400000).endsWith('received 1440 minutes ago'));
console.log('Log times: second/minute boundaries, midnight, and clock adjustments passed');
// Switching modes updates existing nodes, preserving original event timestamps.
const toggle={checked:false},el={dataset:{receivedAt:String(today),receivedMono:'0',originalTime:'Original event · uptime 00:00:01'},textContent:'',closest:()=>null};
context.state={view:'overview'};context.$=()=>toggle;context.document={hidden:false,querySelectorAll:()=>[el]};context.performance={now:()=>12000};
const refreshStart=source.indexOf(' function refreshReceiptTimes(){'),refreshEnd=source.indexOf(' setInterval(refreshReceiptTimes',refreshStart);
vm.runInContext(source.slice(refreshStart,refreshEnd),context);
context.refreshReceiptTimes();assert.equal(el.textContent,el.dataset.originalTime);
toggle.checked=true;context.refreshReceiptTimes();assert(el.textContent.endsWith('received 12 seconds ago'));
toggle.checked=false;context.refreshReceiptTimes();assert.equal(el.textContent,el.dataset.originalTime);
context.document.hidden=true;toggle.checked=true;context.refreshReceiptTimes();assert.equal(el.textContent,el.dataset.originalTime);
context.document.hidden=false;context.refreshReceiptTimes();assert(el.textContent.endsWith('received 12 seconds ago'));
console.log('Live timestamp toggle: immediate switching, original restoration, and hidden-page pause passed');

const uptimeStart=source.indexOf(' function formatUptime('),uptimeEnd=source.indexOf(' function renderLogUptime(',uptimeStart);
vm.runInContext(source.slice(uptimeStart,uptimeEnd),context);
assert.equal(context.formatUptime(0),'00:00:00');
assert.equal(context.formatUptime(3599999),'00:59:59');
assert.equal(context.formatUptime(3600000),'01:00:00');
assert.equal(context.formatUptime(90061000),'1d 01:01:01');
console.log('Controller uptime formatting: seconds, hours and days passed');
