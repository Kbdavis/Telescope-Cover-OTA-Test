/* Read-only check of the CURRENT board's updater. Never clicks install/confirm.
   Usage: node bench_published_release_readiness_test.cjs BASE EVIDENCE_DIR */
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
(async()=>{
 const [base,out]=process.argv.slice(2);assert(/^http:\/\/192\.168\.\d{1,3}\.\d{1,3}$/.test(base));
 const saved=JSON.parse(fs.readFileSync(path.join(out,'board-before.json'))),candidate=JSON.parse(fs.readFileSync(path.join(out,'candidate/artifact.json')));
 const status=async()=>{const r=await fetch(base+'/api/bench/status',{signal:AbortSignal.timeout(5000)});assert(r.ok);return r.json();};
 const before=await status();assert.equal(before.elf,saved.elf);assert.equal(before.build,4);assert(before.accepted&&before.phase==='idle');
 const target=(await(await fetch('http://127.0.0.1:9234/json/list')).json()).find(t=>t.type==='page');
 const ws=new WebSocket(target.webSocketDebuggerUrl),pending=new Map(),errors=[],requests=[],responses=[];let id=0;
 await new Promise(r=>ws.addEventListener('open',r,{once:true}));
 const call=(method,params={})=>new Promise((resolve,reject)=>{const n=++id;pending.set(n,{resolve,reject});ws.send(JSON.stringify({id:n,method,params}));});
 ws.addEventListener('message',event=>{const m=JSON.parse(event.data);if(m.id){const p=pending.get(m.id);pending.delete(m.id);m.error?p.reject(Error(m.error.message)):p.resolve(m.result);}
  if(m.method==='Runtime.exceptionThrown')errors.push(m.params.exceptionDetails.text);
  if(m.method==='Network.requestWillBeSent')requests.push({url:m.params.request.url,method:m.params.request.method});
  if(m.method==='Network.responseReceived')responses.push({url:m.params.response.url,status:m.params.response.status});
 });
 const ev=async expression=>{const r=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error(r.exceptionDetails.text);return r.result.value;};
 try{
  await call('Runtime.enable');await call('Page.enable');await call('Network.enable');await call('Network.setCacheDisabled',{cacheDisabled:true});
  await call('Emulation.setDeviceMetricsOverride',{width:1100,height:1100,deviceScaleFactor:1,mobile:false});
  await call('Page.navigate',{url:base+'/?published-release-readiness='+Date.now()});
  let ready=false;
  for(let n=0;n<200;n++){if(await ev(`document.getElementById('available')?.textContent.includes('${candidate.version}')`)){ready=true;break;}await new Promise(r=>setTimeout(r,100));}
  assert(ready,'Current firmware did not advertise the published target');
  assert.equal(await ev("document.getElementById('installed').textContent"),before.version);
  assert.equal(await ev("document.getElementById('confirm').checked"),false);assert.equal(await ev("document.getElementById('install').disabled"),true);
  assert.match(await ev("document.getElementById('notes').textContent"),/Configuration/);
  assert(requests.every(r=>r.method==='GET'),'Readiness check must not write or install');
  assert(responses.some(r=>r.url.startsWith('https://api.github.com/repos/Kbdavis/Telescope-Cover-OTA-Test/releases')&&r.status===200));
  assert(responses.some(r=>r.url.startsWith('https://kbdavis.github.io/Telescope-Cover-OTA-Test/index.json')&&r.status===200));
  const screen=await call('Page.captureScreenshot',{format:'png'});fs.writeFileSync(path.join(out,'current-beta4-offers-beta5.png'),Buffer.from(screen.data,'base64'));
  const after=await status();assert.equal(after.elf,before.elf);assert.equal(after.boot,before.boot);assert.equal(after.phase,'idle');assert.equal(after.build,4);assert.deepEqual(errors,[]);
  const result={passed:true,real_controller:true,installed_version:after.version,offered_version:candidate.version,source_elf:after.elf,target_elf:candidate.elf,source_boot_unchanged:true,controller_mutations:0,installation_started:false,owner_will_install:true};
  fs.writeFileSync(path.join(out,'published-readiness.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
 }finally{ws.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
