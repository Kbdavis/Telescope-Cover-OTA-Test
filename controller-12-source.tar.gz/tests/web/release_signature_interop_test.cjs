const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const os=require('node:os');
const crypto=require('node:crypto');
const {execFileSync}=require('node:child_process');
const signing=require('../../tools/release_signing.cjs');
const vector=JSON.parse(fs.readFileSync(path.join(__dirname,'../fixtures/release_signature.json'),'utf8'));
test('public Node signature vector is independently verified by C++/OpenSSL',()=>{
 const point=Buffer.from(vector.public_point_hex,'hex');assert.equal(point.length,65);assert.equal(point[0],4);
 const publicKey=crypto.createPublicKey({key:{kty:'EC',crv:'P-256',x:point.subarray(1,33).toString('base64url'),y:point.subarray(33).toString('base64url')},format:'jwk'});
 assert.equal(signing.verifyPreview(vector.envelope,new Map([['test-only',publicKey]])).signature_valid,true);
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'cover-signature-interop-'));
 try{
  const array=(name,bytes)=>`static const uint8_t ${name}[]={${[...bytes].join(',')}};\n`;
  fs.writeFileSync(path.join(dir,'release_signature_vector.h'),
   array('publicPoint',point)+array('payload',Buffer.from(vector.envelope.payload,'base64'))+array('signature',Buffer.from(vector.envelope.signature,'base64')));
  let flags;
  try{flags=execFileSync('pkg-config',['--cflags','--libs','openssl'],{encoding:'utf8',stdio:['ignore','pipe','ignore']}).trim().split(/\s+/);}
  catch(_){
   const prefix=['/opt/homebrew/opt/openssl@3','/usr/local/opt/openssl@3'].find(p=>fs.existsSync(path.join(p,'include/openssl/evp.h')));
   if(!prefix)throw Error('OpenSSL development headers/library required for cross-language release verification');
   flags=['-I'+prefix+'/include','-L'+prefix+'/lib','-lcrypto'];
  }
  const binary=path.join(dir,'release-signature-test');
  execFileSync('c++',['-std=c++17','-Wall','-Wextra','-Werror','-Isrc','-I'+dir,'tests/host/release_signature_test.cpp',...flags,'-o',binary],{cwd:path.join(__dirname,'../..'),stdio:'pipe'});
  assert.match(execFileSync(binary,{encoding:'utf8'}),/Cross-language release signature/);
 }finally{fs.rmSync(dir,{recursive:true,force:true});}
});
