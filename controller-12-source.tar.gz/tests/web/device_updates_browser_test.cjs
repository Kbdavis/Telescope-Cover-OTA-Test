/* Explicit read-only spare-board browser test. Release responses are simulated;
   all controller requests must be GET. Requires isolated Chrome CDP on 9234.
   Usage: node tests/web/device_updates_browser_test.cjs http://SPARE-IP evidence-dir */
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const M=require('../../data/ui/release_metadata.js');
const fixture=JSON.parse(fs.readFileSync(path.join(__dirname,'../fixtures/release_metadata.json'),'utf8'));
(async()=>{
 const base=process.argv[2],evidence=process.argv[3];
 assert(base && /^http:\/\/192\.168\.\d{1,3}\.\d{1,3}$/.test(base),'Explicit spare LAN address required');
 assert(evidence && fs.statSync(evidence).isDirectory(),'Existing evidence directory required');
 const real=await(await fetch(base+'/api/session',{signal:AbortSignal.timeout(5000)})).json();
 assert.equal(real.read_only_test,true,'Only the spare read-only build may be tested');
 M.validateDevice(real.update_capabilities);
 assert.equal(real.update_capabilities.read_only_test,true);
 assert.equal(real.update_capabilities.receiver.enabled,false);
 const targets=await(await fetch('http://127.0.0.1:9234/json/list')).json();
 const target=targets.find(t=>t.type==='page');assert(target);
 const ws=new WebSocket(target.webSocketDebuggerUrl),pending=new Map(),errors=[],requests=[];
 let id=0;
 await new Promise((resolve,reject)=>{ws.addEventListener('open',resolve,{once:true});ws.addEventListener('error',reject,{once:true});});
 const call=(method,params={})=>new Promise((resolve,reject)=>{const n=++id;pending.set(n,{resolve,reject});ws.send(JSON.stringify({id:n,method,params}));});
 const release=fixture.release;
 const releases=[{id:100,tag_name:release.tag,draft:false,prerelease:false,published_at:'2026-11-12T12:00:00Z',body:'Synthetic browser test release. No installable artifact.'}];
 ws.addEventListener('message',async event=>{
  const m=JSON.parse(event.data);
  if(m.id){const p=pending.get(m.id);pending.delete(m.id);m.error?p.reject(Error(m.error.message)):p.resolve(m.result);}
  if(m.method==='Runtime.executionContextsCleared')errors.length=0;
  if(m.method==='Runtime.exceptionThrown')errors.push(m.params.exceptionDetails);
  if(m.method==='Network.requestWillBeSent')requests.push({url:m.params.request.url,method:m.params.request.method});

 });
 const ev=async expression=>{const r=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));return r.result.value;};
 const wait=async expression=>{for(let n=0;n<180;n++){if(await ev(expression))return;await new Promise(r=>setTimeout(r,50));}throw Error('Timed out: '+expression);};
 try{
  await call('Runtime.enable');await call('Page.enable');await call('Network.enable');
  await call('Network.setCacheDisabled',{cacheDisabled:true});
  // Mock remote fetch in page memory, leaving real asset loads unchanged. CDP Fetch
  // interception can alter concurrent socket scheduling on the small ESP32 server.
  await call('Page.addScriptToEvaluateOnNewDocument',{source:`(()=>{
   const original=window.fetch.bind(window);
   window.fetch=async(input,options)=>{
    const url=String(input);
    if(!url.startsWith('https://api.github.com/')&&!url.startsWith('https://kbdavis.github.io/'))return original(input,options);
    const unavailable=localStorage.getItem('spareBrowserReleaseMode')!=='normal';
    const body=unavailable?{message:'Not Found'}:url.startsWith('https://api.github.com/')?${JSON.stringify(releases)}:
     ${JSON.stringify({schema:'telescope-cover-catalog-preview/1',releases:[{release_id:100,metadata:release}]})};
    return new Response(JSON.stringify(body),{status:unavailable?404:200,headers:{'Content-Type':'application/json'}});
   };
  })();`});
  await call('Storage.clearDataForOrigin',{origin:base,storageTypes:'local_storage'});
  await call('Page.navigate',{url:base+'/?spare-browser-test='+Date.now()+'#configuration'});
  await wait("document.getElementById('updates-status')?.textContent.includes('private or inaccessible')");
  await wait("window.coverAPI?.state.session?.read_only_test && !document.getElementById('readOnlyTestNotice').hidden");
  assert.equal(await ev("document.getElementById('readOnlyTestNotice').hidden"),false);
  assert.match(await ev("document.getElementById('updates-device').textContent"),/Read-only test firmware/);
  assert.equal(await ev("document.getElementById('firmware-update-link').hidden"),true);
  await ev("localStorage.clear();localStorage.setItem('spareBrowserReleaseMode','normal')");await call('Page.reload');
  await wait("document.getElementById('updates-release')?.options.length===1 && window.coverAPI?.state.session?.update_capabilities");
  assert.match(await ev("document.getElementById('updates-compatibility').textContent"),/Development build installed/);
  assert.equal(await ev('coverAPI.state.session.update_capabilities.receiver.enabled'),false);
  // Simulation only: replace browser memory, never controller identity or NVS.
  await ev(`(()=>{coverAPI.state.session.firmware=${JSON.stringify({...fixture.device.firmware,profile:fixture.device.firmware.build_profile})};coverAPI.state.session.firmware_id=${JSON.stringify(fixture.device.firmware.elf)};coverAPI.state.session.update_capabilities=${JSON.stringify(fixture.device)};coverAPI.emit();})()`);
  await wait("document.getElementById('updates-available').textContent==='0.1.0'");
  await ev("document.getElementById('nav-overview').click();document.getElementById('firmware-update-link').click()");
  assert.equal(await ev('document.activeElement.id'),'cfg-updates');
  for(const width of [1440,390]){
   await call('Emulation.setDeviceMetricsOverride',{width,height:1000,deviceScaleFactor:1,mobile:width<500});
   await ev("document.getElementById('cfg-updates').scrollIntoView()");
   assert(await ev('document.documentElement.scrollWidth<=innerWidth+1'));
  }
  const simulatedScreen=await call('Page.captureScreenshot',{format:'png'});
  fs.writeFileSync(path.join(evidence,'update-available-simulated.png'),Buffer.from(simulatedScreen.data,'base64'));
  // Restore the actual report before recording the final page screenshot.
  await ev(`(()=>{coverAPI.state.session=${JSON.stringify({...real,token:undefined})};coverAPI.emit();document.getElementById('cfg-updates').scrollIntoView();})()`);
  const screen=await call('Page.captureScreenshot',{format:'png'});
  fs.writeFileSync(path.join(evidence,'firmware-updates-mobile.png'),Buffer.from(screen.data,'base64'));
  assert.equal(requests.filter(r=>r.url.startsWith(base) && r.method!=='GET').length,0,'No controller mutation is allowed');
  assert.deepEqual(errors,[]);
  const after=await(await fetch(base+'/api/session',{signal:AbortSignal.timeout(5000)})).json();
  assert.equal(after.firmware_id,real.firmware_id);assert.equal(after.boot_id,real.boot_id);
  const result={real_device:{firmware_id:real.firmware_id,boot_id:real.boot_id,read_only_test:true},
   tested:['LAN page/session','live capability report','read-only banner','inaccessible release service','development compatibility block','simulated update notification and focus','desktop/mobile layout'],
   release_responses_simulated:true,update_notification_identity_simulated:true,controller_mutations:0,ota_transfer_tested:false};
  fs.writeFileSync(path.join(evidence,'browser-result.json'),JSON.stringify(result,null,2)+'\n');
  console.log(JSON.stringify(result,null,2));
 }catch(error){if(errors.length)console.error('Browser exceptions:',JSON.stringify(errors));throw error;}
 finally{ws.close();}
})().catch(error=>{console.error(error);process.exitCode=1;});
