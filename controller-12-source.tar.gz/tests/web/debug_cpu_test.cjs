const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync('data/ui/app.js','utf8');
const start=source.indexOf(' function renderCpuLoad(){'),end=source.indexOf('\n function renderMetrics',start);
assert(start>=0 && end>start);
let now=2000,fresh=true;const values={};
const state={coverAt:2000,cover:null};
const context=vm.createContext({state,api:{now:()=>now,freshCover:()=>fresh,metrics:{hasSnapshot:()=>true}},text:(id,value)=>values[id]=value});
vm.runInContext(source.slice(start,end),context);
const render=()=>vm.runInContext('renderCpuLoad()',context);
const check=(a,b,c)=>assert.deepEqual([values['debug-cpu-core0'],values['debug-cpu-core1'],values['debug-cpu-average']],[a,b,c]);
render();check('Unavailable','Unavailable','Unavailable');
state.cover={resources:{cpu_load:{available:true,method:'timer_sampled',window_ms:1000,age_ms:0,core0_percent:100,core1_percent:0,average_percent:50}}};
render();check('100.0%','0.0%','50.0%');
assert.match(values['debug-cpu-status'],/1\.0 s/);
now=8000;render();check('Unavailable','Unavailable','Unavailable');
now=2000;
for(const patch of [{available:false},{average_percent:null},{core0_percent:101},{core1_percent:NaN},{age_ms:-1},{window_ms:900},{method:'unsupported'}]){
 const saved={...state.cover.resources.cpu_load};Object.assign(state.cover.resources.cpu_load,patch);
 render();check('Unavailable','Unavailable','Unavailable');state.cover.resources.cpu_load=saved;
}
fresh=false;render();check('Unavailable','Unavailable','Unavailable');
// The renderer has no fetch, request or logging dependency: it only reads the existing status.
console.log('Debug CPU rendering: values, averaging, old firmware, stale/unavailable and invalid samples passed');
