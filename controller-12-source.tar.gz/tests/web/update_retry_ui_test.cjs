/* Real firmware update renderer, injected time, no DOM/controller polling events. */
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const M=require('../../data/ui/release_metadata.js');
const D=require('../../data/ui/release_discovery.js');
test('Check now explains cooldown/rate limits and reenables without controller polling',async()=>{
 let now=1800000000000,status=404,engine;
 const nodes=new Map(),timers=[];
 const get=id=>{if(!nodes.has(id))nodes.set(id,{textContent:'',hidden:false,disabled:false,value:'',replaceChildren(){},append(){}});return nodes.get(id);};
 const map=new Map([[D.PREF,JSON.stringify({automatic:false,include_beta:false})]]);
 const context={Date:class extends Date {static now(){return now;}},
  CoverReleaseMetadata:M,CoverReleaseDiscovery:{...D,Discovery:class extends D.Discovery{
   constructor(options){super({...options,clock:()=>now});engine=this;}
  }},
  document:{getElementById:get,hidden:false,addEventListener(){},createElement:()=>({})},
  window:{coverAPI:{state:{},subscribe(){}},addEventListener(){},
   localStorage:{getItem:k=>map.get(k)||null,setItem:(k,v)=>map.set(k,v),removeItem:k=>map.delete(k)},
   fetch:async()=>new Response('{}',{status,headers:status===429?{'Retry-After':'300'}:{}})},
  setInterval:(fn,ms)=>timers.push({fn,ms})};
 vm.runInNewContext(fs.readFileSync('data/ui/firmware_updates.js','utf8'),context);
 const button=get('updates-check'),reason=get('updates-check-reason');
 assert.equal(button.disabled,false);assert.equal(button.textContent,'Check now');
 assert.equal(get('updates-last-success').textContent,'No successful check yet');
 await button.onclick();
 assert.equal(button.disabled,true);assert.equal(button.textContent,'Check in 60s');
 assert.match(reason.textContent,/attempted recently/);assert.equal(reason.hidden,false);
 assert.notEqual(get('updates-last-attempt').textContent,'Never');
 assert.equal(get('updates-last-success').textContent,'No successful check yet');
 const timer=timers.find(t=>t.ms===1000);assert(timer,'A timer must refresh controls without controller status events');
 now+=61000;timer.fn();
 assert.equal(button.disabled,false);assert.equal(button.textContent,'Check now');assert.equal(reason.hidden,true);
 await button.onclick();now+=61000;timer.fn();
 assert.equal(button.disabled,false,'Ordinary automatic backoff must not lock manual retry');
 assert(engine.snapshot().retry_at>now,'Automatic backoff still applies');
 status=429;await button.onclick();
 assert.equal(button.disabled,true);assert.match(reason.textContent,/service requested a wait/);
 now+=61000;timer.fn();assert.equal(button.disabled,true,'Server rate limits remain enforced');
 now+=240000;timer.fn();assert.equal(button.disabled,false);
});
