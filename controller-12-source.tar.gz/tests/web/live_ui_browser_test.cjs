/* Run against a local API fixture on 8091 and isolated Chrome CDP on 9226.
 * Node 22+; no dependencies, hardware calls, or credentials. Screenshots go to /tmp. */
const assert=require('node:assert/strict');
const fs=require('node:fs');
const connect=async()=>{
const targets=await(await fetch('http://127.0.0.1:9226/json/list')).json();
const ws=new WebSocket(targets.find(t=>t.type==='page').webSocketDebuggerUrl),pending=new Map(),errors=[],requests=[],logs=[];let id=0;
await new Promise((r,j)=>{ws.addEventListener('open',r,{once:true});ws.addEventListener('error',j,{once:true});});
ws.addEventListener('message',e=>{const m=JSON.parse(e.data);if(m.id){const p=pending.get(m.id);pending.delete(m.id);m.error?p.j(Error(m.error.message)):p.r(m.result);}if(m.method==='Runtime.exceptionThrown')errors.push(m.params.exceptionDetails);if(m.method==='Network.requestWillBeSent')requests.push(m.params.request.url);if(m.method==='Log.entryAdded')logs.push(m.params.entry);if(m.method==='Page.javascriptDialogOpening'&&m.params.type==='beforeunload')call('Page.handleJavaScriptDialog',{accept:true});});
const call=(method,params={})=>new Promise((r,j)=>{const n=++id;pending.set(n,{r,j});ws.send(JSON.stringify({id:n,method,params}));});
const ev=async expression=>{const r=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true,userGesture:true});if(r.exceptionDetails)throw Error(r.exceptionDetails.exception?.description||r.exceptionDetails.text);return r.result.value;};
const shot=async n=>{const img=await call('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});fs.writeFileSync('/tmp/'+n+'.png',Buffer.from(img.data,'base64'));};
await call('Runtime.enable');await call('Page.enable');await call('Network.enable');await call('Log.enable');
return {call,ev,shot,errors,requests,logs,close:()=>ws.close()};};
const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
(async()=>{
 const c=await connect(),{call,ev,shot}=c;
 const patch=async value=>{await fetch('http://127.0.0.1:8091/test/patch',{method:'POST',body:JSON.stringify(value)});};
 const click=id=>ev(`document.getElementById(${JSON.stringify(id)}).click()`);
 const input=(id,value)=>ev(`document.getElementById(${JSON.stringify(id)}).value=${JSON.stringify(String(value))};document.getElementById(${JSON.stringify(id)}).dispatchEvent(new Event('input',{bubbles:true}))`);
 const select=(id,value)=>ev(`document.getElementById(${JSON.stringify(id)}).value=${JSON.stringify(value)};document.getElementById(${JSON.stringify(id)}).dispatchEvent(new Event('change',{bubbles:true}))`);
 const wait=async(expression,label)=>{for(let i=0;i<200;i++){if(await ev(expression))return;await delay(50);}throw Error('Timed out: '+label);};
 const ready=()=>wait('!!coverAPI.state.cover && !!coverAPI.state.scope && !!coverAPI.state.network','live data');
 const done=async()=>{await wait('!coverAPI.state.active&&!coverAPI.state.busy&&!coverAPI.state.cover.moving&&!coverAPI.state.cover.holding','movement finished');await delay(450);};
 const step=n=>ev(`document.querySelector('[data-step="${n}"]').click()`);
 const disabled=id=>ev(`document.getElementById(${JSON.stringify(id)}).disabled`);
 try{
  await call('Emulation.setFocusEmulationEnabled',{enabled:true});await call('Emulation.setDeviceMetricsOverride',{width:1440,height:1000,deviceScaleFactor:1,mobile:false});
  c.errors.length=0;c.requests.length=0;await fetch('http://127.0.0.1:8091/test/reset',{method:'POST',body:''});console.log('Loading live UI fixture');await call('Page.navigate',{url:'http://127.0.0.1:8091/'});await wait("document.readyState==='complete'&&!!window.coverAPI",'page loaded');await ready();console.log('Live data ready');
  assert.deepEqual(c.errors,[]);
  assert.equal(await ev("document.querySelectorAll('main > [data-view]').length"),5);
  assert.equal(await ev("document.getElementById('betaNotice').open"),true);
  assert.equal(await disabled('ov-open'),true);
  await click('betaAccept');await wait('coverAPI.state.session.beta_accepted','beta saved');

  // Manual authorization is explicit, temporary, and bypasses telescope/calibration workflow only.
  await click('nav-manual');assert.equal(await disabled('manual-fields'),true);
  assert.equal(await ev("coverAPI.request('manual/jog-plus',{body:{step:1}}).then(()=>false,()=>true)"),true);
  await click('manual-enable');assert.equal(await ev("document.getElementById('manualWarning').open"),true);
  await click('manual-cancel');assert.equal(await disabled('manual-fields'),true);
  await patch({scope:{at_home:false,stowed_observation:false},cover:{dirty:true}});await ev('coverAPI.scope();coverAPI.cover()');
  await click('manual-enable');await click('manual-accept');
  await wait("!document.getElementById('manual-fields').disabled",'manual enabled');
  assert.equal(await ev("document.getElementById('manual-disable-torque').checked"),true);
  assert.equal(await ev("document.getElementById('manual-hold-torque').checked"),true);
  await click('manual-hold-torque'); // Exercise explicit release-after-step.
  const manualStart=await ev('coverAPI.state.cover.position');
  await select('manual-step','10');await click('manual-plus');await done();assert.equal(await ev('coverAPI.state.cover.torque'),false);
  assert.equal(await ev('coverAPI.state.cover.position'),manualStart+10);
  await click('manual-minus');await done();assert.equal(await ev('coverAPI.state.cover.torque'),false);assert.equal(await ev('coverAPI.state.cover.position'),manualStart);
  await click('manual-stop');await done();
  await click('nav-overview');await click('nav-manual');assert.equal(await disabled('manual-fields'),true);
  await click('manual-disable-torque');await click('manual-reboot');await click('reboot-cancel');
  await click('manual-reboot');await click('reboot-accept');
  await wait("document.getElementById('manual-reboot-message').textContent.includes('Controller restarted')",'manual reboot confirmed');
  assert.equal(await disabled('manual-fields'),true);
  await ev('coverAPI.cover()');assert.equal(await ev('coverAPI.state.cover.torque'),true);
  await click('manual-disable-torque');await click('manual-reboot');await click('reboot-accept');
  await wait("document.getElementById('manual-reboot-message').textContent.includes('Controller restarted')&&!document.getElementById('manual-reboot').disabled",'released reboot');
  await ev('coverAPI.cover()');assert.equal(await ev('coverAPI.state.cover.torque'),false);
  await patch({scope:{at_home:true,stowed_observation:true},cover:{dirty:false,state:'CLOSED'}});await ev('coverAPI.scope();coverAPI.cover()');
  await click('nav-overview');
  // Telescope details retain their disclosure state; missing/stale charge is never shown as zero.
  await ev("document.querySelector('#ov-scope-telemetry summary').click()");
  assert.equal(await ev("document.getElementById('ov-tel-address').textContent"),'192.168.1.131:32323');
  assert.equal(await ev("document.getElementById('ov-tel-altitude').textContent"),'-90.0°');
  assert.equal(await ev("document.getElementById('ov-tel-battery-temp').textContent"),'23 °C');
  for(const mode of ['light','dark']){
   await select('appearance',mode);
   for(const value of [100,11,10,0,null,-1,101]){
    await patch({scope:{battery_percent:value}});await ev('coverAPI.scope()');
    const valid=value!==null&&value>=0&&value<=100;
    assert.equal(await ev("document.getElementById('ov-scope-battery-track').getAttribute('aria-valuenow')"),valid?String(value):null);
    const color=await ev("getComputedStyle(document.getElementById('ov-scope-battery-fill')).backgroundColor");
    if(valid){
     const expected=await ev(`(()=>{const e=document.createElement('i');e.style.color='var(--${value<=10?'red':'green'})';document.body.append(e);const color=getComputedStyle(e).color;e.remove();return color;})()`);
     assert.equal(color,expected,mode+' battery color at '+value+'%');
    }else assert.equal(await ev("document.getElementById('ov-scope-battery-value').textContent"),'Unavailable');
   }
  }
  for(const stale of [{power_valid:false,power_age_ms:0},{power_valid:true,power_age_ms:61000}]){
   await patch({scope:{battery_percent:42,...stale}});await ev('coverAPI.scope()');
   assert.equal(await ev("document.getElementById('ov-scope-battery-value').textContent"),'Unavailable');
   assert.equal(await ev("document.getElementById('ov-scope-battery-track').hasAttribute('aria-valuenow')"),false);
  }
  await patch({scope:{power_valid:true,power_age_ms:0,battery_percent:42}});await ev('coverAPI.scope()');
  // Native power loss/recovery is independent of Alpaca and the inspection lock.
  await patch({scope:{power_valid:false,power_retrying:true,arm_locked:true,arm_phase:'inspect'}});await ev('coverAPI.scope()');
  assert.equal(await ev("document.getElementById('ov-scope-tag').textContent"),'Connected');
  assert.equal(await ev("document.getElementById('ov-tel-power-status').textContent"),'Retrying automatically');
  assert.equal(await ev("document.getElementById('ov-scope-battery-value').textContent"),'Unavailable');
  assert.equal(await ev("document.getElementById('ov-power-status').textContent"),'Power readings unavailable. Retrying automatically.');
  await patch({scope:{power_valid:true,power_retrying:false,battery_percent:41}});await ev('coverAPI.scope()');
  assert.equal(await ev("document.getElementById('ov-scope-battery-value').textContent"),'41%');
  assert.equal(await ev("document.getElementById('ov-tel-power-status').textContent"),'Available');
  assert.equal(await ev('coverAPI.state.scope.arm_locked'),true);
  assert.equal(await disabled('ov-close'),true,'Power recovery never clears the movement lock');
  await patch({scope:{power_paused:true}});await ev('coverAPI.scope()');
  assert.equal(await ev("document.getElementById('ov-tel-power-status').textContent"),'Paused during arm movement');
  await patch({scope:{power_paused:false,arm_locked:false,arm_phase:'idle',battery_percent:42}});await ev('coverAPI.scope()');
  // Retain failed display readings with an explicit age, never as stow permission.
  await patch({scope:{altitude:null,altitude_error:'timeout',altitude_last_value:3.52,altitude_last_age_ms:65000,valid:false,error:'timeout',failed_request:'athome',request_ms:1200}});
  await ev('coverAPI.scope()');
  assert.match(await ev("document.getElementById('ov-tel-altitude').textContent"),/3.5° · stale, 6[5-9]s ago/);
  assert.match(await ev("document.getElementById('ov-tel-error').textContent"),/athome · 1200 ms/);
  assert.equal(await disabled('ov-close'),true);
  await patch({scope:{altitude:-90,altitude_age_ms:0,altitude_error:'none',valid:true,error:'none',failed_request:'none'}});await ev('coverAPI.scope()');
  // Telescope control belongs to the app; only cover controls remain.
  for(const id of ['ov-arm-open','ov-arm-close','ov-arm-finish','emergency','emergencyInspect','emergencyDialog'])
   assert.equal(await ev(`document.getElementById('${id}')`),null,id+' removed');
  assert.equal(await disabled('stop'),false);
  await click('ov-supervised');
  await patch({cover:{state:'OPEN',position:2000},scope:{at_home:false,stowed_observation:false}});
  await ev('coverAPI.cover()');await ev('coverAPI.scope()');assert.equal(await disabled('ov-close'),true);
  for(const unsafe of [{valid:false},{connected:false},{at_home:false},{slewing:true},{tracking:true},{age_ms:6000},{stowed_observation:false}]){
   await patch({scope:{valid:true,connected:true,at_home:true,stowed_observation:true,slewing:false,tracking:false,age_ms:0,...unsafe}});
   await ev('coverAPI.scope()');assert.equal(await disabled('ov-close'),true,JSON.stringify(unsafe));
  }
  await patch({scope:{valid:true,connected:true,at_home:true,stowed_observation:true,slewing:false,tracking:false,age_ms:0}});
  await ev('coverAPI.scope()');assert.equal(await disabled('ov-close'),false,'Fresh app-stowed telescope permits cover close');
  await patch({controls:{delay_heartbeat:.16}});
  await click('ov-close');await done();
  await patch({controls:{delay_heartbeat:0}});
  const monitoringEvents=await(await fetch('http://127.0.0.1:8091/test/events')).json();
  assert.equal(monitoringEvents.some(e=>/^(telescope\/|emergency\/|alpaca\/)/.test(e.path)),false,'No telescope commands');
  await click('ov-supervised');
  await select('appearance','light');await shot('live-ui-overview');
  await ev('window.originalMain=document.querySelector("main");window.originalTimeOrigin=performance.timeOrigin');
  await click('nav-configuration');assert.equal(await ev("document.getElementById('cfg-ssid').value"),'Observatory Wi-Fi');
  assert.equal(await ev("document.getElementById('cfg-disable-torque').checked"),false);
  for(const value of [true,false]){
   await click(value?'cfg-disable-torque':'cfg-keep-torque');await click('cfg-advanced-save');
   await wait(`coverAPI.state.network.disable_torque_after_move===${value}&&!document.getElementById('cfg-advanced-fields').disabled`,'advanced saved');
   assert.equal(await ev("document.getElementById('cfg-disable-torque').checked"),value);
  }


  assert.equal(await ev("document.getElementById('nav-debug').hidden"),true);
  await click('cfg-enable-debug');await click('cfg-diagnostics-save');
  await wait("coverAPI.state.network.enable_debug_tab&&!document.getElementById('cfg-advanced-fields').disabled",'debug enabled');
  await click('nav-debug');
  assert.equal(await ev("document.getElementById('debug-metrics').open"),false);
  assert.equal(await ev("coverAPI.state.cover.resources.state"),'off');
  assert.equal((await(await fetch('http://127.0.0.1:8091/test/events')).json()).filter(e=>e.path.startsWith('diagnostics/metrics/')).length,0);
  await ev("document.querySelector('#debug-metrics>summary').click()");
  await wait("document.getElementById('debug-cpu-core0').textContent==='12.5%'&&document.getElementById('debug-cpu-core1').textContent==='3.5%'&&document.getElementById('debug-cpu-average').textContent==='8.0%'",'live CPU readings');
  await patch({controls:{cpu_available:false}});await ev('coverAPI.cover()');
  assert.equal(await ev("document.getElementById('debug-cpu-average').textContent"),'Unavailable');
  await patch({controls:{cpu_available:true}});await ev('coverAPI.cover()');
  await wait("document.getElementById('debug-heap-free').textContent==='170,000 bytes'",'cached memory readings');
  await wait("document.getElementById('debug-log-suppressed').textContent==='100'",'cached event counters');
  await shot('live-ui-debug-cpu');
  await delay(2300);await wait("coverAPI.state.cover.resources.state==='active'",'metrics stay active');
  assert((await(await fetch('http://127.0.0.1:8091/test/events')).json()).some(e=>e.path==='diagnostics/metrics/renew'));
  await ev("document.querySelector('#debug-metrics>summary').click()");
  await wait("coverAPI.state.cover.resources.state==='off'",'last viewer stops collection');
  const closedMetricsRequests=(await(await fetch('http://127.0.0.1:8091/test/events')).json()).filter(e=>e.path.startsWith('diagnostics/metrics/')).length;
  await delay(2400);
  assert.equal((await(await fetch('http://127.0.0.1:8091/test/events')).json()).filter(e=>e.path.startsWith('diagnostics/metrics/')).length,closedMetricsRequests);
  await ev("document.querySelector('#debug-metrics>summary').click()");
  await wait("coverAPI.state.cover.resources.state==='active'",'explicit reopen');
  await click('nav-overview');await wait("coverAPI.state.cover.resources.state==='off'",'leaving Debug unsubscribes');
  await click('nav-debug');assert.equal(await ev("document.getElementById('debug-metrics').open"),false);
  await wait("document.getElementById('debug-log').textContent.includes('SERVO OPEN')&&document.getElementById('debug-log').textContent.includes('ALPACA connection dropped')",'controller debug messages');
  await wait("document.querySelector('#debug-log .debug-info')",'info message');
  await click('debug-warn');await click('debug-info');
  assert.equal(await ev("[...document.querySelectorAll('#debug-log .debug-entry')].every(e=>e.classList.contains('debug-error'))"),true);
  await click('debug-warn');
  assert.equal(await ev("!!document.querySelector('#debug-log .debug-warn')&&!document.querySelector('#debug-log .debug-info')"),true);
  await click('debug-info');
  assert.equal(await ev("new Set([...document.querySelectorAll('#debug-log .debug-entry')].map(e=>getComputedStyle(e).color)).size"),3);
  await click('debug-error');await click('debug-info');
  assert.equal(await ev("[...document.querySelectorAll('#debug-log .debug-entry')].every(e=>e.classList.contains('debug-warn'))"),true);
  await click('debug-error');await click('debug-info');
  await patch({controls:{debug_epoch:1}});
  await wait("document.getElementById('debug-log').textContent.includes('Controller event cursor reset')",'event rollover resets browser cursor');

  await patch({controls:{drop_status:true}});
  await wait("document.getElementById('debug-log').textContent.includes('Controller request failed (status)')",'browser failure logged offline');
  await patch({controls:{drop_status:false}});
  await wait("[...document.querySelectorAll('#debug-log .debug-entry')].some(e=>e.textContent.includes('Controller request failed (status)')&&e.textContent.includes('Communication recovered at'))",'browser recovery');
  await click('nav-configuration');await click('cfg-enable-debug');await click('cfg-diagnostics-save');
  await wait("!coverAPI.state.network.enable_debug_tab&&!document.getElementById('cfg-advanced-fields').disabled",'debug disabled');
  assert.equal(await ev("document.getElementById('nav-debug').hidden"),true);
  assert.equal(await ev("document.getElementById('cfg-password').placeholder"),'********');
  await input('cfg-hostname','garden-cover');await click('nav-calibration');await step(2);await input('openSpeed',120);
  await click('nav-configuration');assert.equal(await ev("document.getElementById('cfg-hostname').value"),'garden-cover');
  await click('nav-calibration');assert.equal(await ev("document.getElementById('openSpeed').value"),'120');await input('openSpeed',100);
  await click('nav-overview');assert.equal(await ev('originalMain===document.querySelector("main")&&originalTimeOrigin===performance.timeOrigin'),true);
  await click('ov-supervised');await click('ov-open');await done();
  assert.equal(await ev('coverAPI.state.cover.state'),'OPEN');
  // Model app-driven arm motion using observations, never controller commands.
  await patch({scope:{at_home:false,stowed_observation:false,slewing:true}});await ev('coverAPI.scope()');
  assert.equal(await disabled('ov-close'),true);
  await patch({scope:{at_home:true,stowed_observation:true,slewing:false}});await ev('coverAPI.scope()');
  await click('ov-close');await wait('coverAPI.state.active||coverAPI.state.cover.state==="CLOSED"','close started');await done();
  assert.equal(await ev('coverAPI.state.cover.state'),'CLOSED');
  // Actual requests for teaching, fine jogs, capture, profile, save and discard.
  await click('nav-calibration');await step(0);for(const id of ['present','supported','stowed'])await click(id);
  await click('prepareNext');await wait('coverAPI.state.cover.teaching&&!coverAPI.state.busy','teaching begun');
  await input('openingDirection',1);await click('directionObserved');await click('applyDirection');await done();
  await step(1);await ev("document.querySelector('[data-count=\"1\"]').click()");
  const before=await ev('coverAPI.state.cover.position');await click('plus');await done();assert.equal(await ev('coverAPI.state.cover.position'),before+1);
  await click('capture');await wait('coverAPI.state.cover.draft_closed==='+String(before+1),'captured real position');
  await ev("document.querySelector('[data-count=\"100\"]').click()");await click('plus');await done();
  await click('capture');await wait('coverAPI.state.cover.draft_open!==null&&!coverAPI.state.busy','open recaptured');
  await step(2);await input('openSpeed',120);await input('timeout',10);await click('applyProfile');
  await wait('coverAPI.state.cover.draft_profile.open_speed===120&&!coverAPI.state.busy','profile applied');
  await patch({controls:{fail_save:true}});await click('save');await wait("coverAPI.state.cover.notice.includes('Save failed')",'failed save');
  assert.equal(await ev('coverAPI.state.cover.dirty'),true);assert.equal(await disabled('reviewNext'),true);
  await patch({controls:{fail_save:false}});await click('save');await wait('!coverAPI.state.cover.dirty&&!coverAPI.state.busy','verified save');
  assert.equal(await ev('coverAPI.state.cover.saved_profile.open_speed'),120);
  await input('openSpeed',130);await click('applyProfile');await wait('coverAPI.state.cover.dirty&&!coverAPI.state.busy','new draft');
  await click('discard');await click('confirmDiscard');await wait('!coverAPI.state.cover.dirty&&!coverAPI.state.busy','discarded');
  assert.equal(await ev("document.getElementById('openSpeed').value"),'120');
  // Idle updates must not rewrite stable status nodes in either view.
  for(const view of ['overview','calibration']){
   await click('nav-'+view);await delay(600);await ev(`window.mutations=0;window.watch=new MutationObserver(rows=>mutations+=rows.length);watch.observe(document.getElementById('view-${view}'),{subtree:true,attributes:true,childList:true,characterData:true})`);
   await delay(1300);assert.equal(await ev('mutations'),0,'Stable '+view+' does not flash');await ev('watch.disconnect()');
  }
  // Failed settings keep the draft and previous active value; successful save is read back.
  // Calibration jogs leave STOPPED; current maintenance requires a verified close.
  await click('nav-overview');if(!await ev("document.getElementById('ov-supervised').checked"))await click('ov-supervised');
  await click('ov-close');await done();assert.equal(await ev('coverAPI.state.cover.state'),'CLOSED');
  await click('nav-configuration');await patch({controls:{fail_save:true}});await click('cfg-name-save');
  await wait("document.getElementById('cfg-name-message').dataset.error==='true'",'failed name save');
  assert.equal(await ev('coverAPI.state.network.mdns_name'),'cover');assert.equal(await ev("document.getElementById('cfg-hostname').value"),'garden-cover');
  await patch({controls:{fail_save:false}});await click('cfg-name-save');await wait("coverAPI.state.network.mdns_name==='garden-cover'&&!document.getElementById('cfg-name-fields').disabled",'name saved');
  await input('cfg-password','draft-password');await click('cfg-scan');await wait("!document.getElementById('cfg-wifi-fields').disabled",'scan done');
  assert.equal(await ev("document.getElementById('cfg-password').value"),'draft-password');await input('cfg-password','');
  // Stop must win even when a start request arrives late.
  await click('nav-overview');await patch({controls:{delay_start:.45}});await click('ov-open');await delay(80);await click('stop');
  await wait('!coverAPI.state.busy&&!coverAPI.state.active','late start cancelled');await delay(800);await ev('coverAPI.cover()');
  assert.equal(await ev('coverAPI.state.cover.moving'),false);assert.equal(await ev('coverAPI.state.cover.torque'),false);
  await patch({controls:{delay_start:0}});
  await click('ov-open');await wait('coverAPI.state.active','start before view switch');await click('nav-configuration');
  assert.equal(await ev("document.getElementById('navigationDialog').open"),true);await click('navigationConfirm');
  await wait("coverAPI.state.view==='configuration'&&!coverAPI.state.cover.moving",'stop and switch');
  for(const mode of ['light','dark'])for(const width of [390,1440]){
   await select('appearance',mode);await call('Emulation.setDeviceMetricsOverride',{width,height:width===390?844:1000,deviceScaleFactor:1,mobile:width===390});
   for(const view of ['overview','calibration','configuration','manual']){await click('nav-'+view);await ev('window.scrollTo(0,0)');await delay(100);assert.equal(await ev('document.documentElement.scrollWidth<=innerWidth'),true,view+' fits '+width);await shot(`live-ui-${view}-${mode}-${width}`);}
  }
  await patch({controls:{drop_status:true}});await delay(2200);await click('nav-overview');assert.equal(await disabled('ov-open'),true);assert.match(await ev("document.getElementById('dockState').textContent"),/unconfirmed/);
  await patch({controls:{drop_status:false}});await ready();
  const events=await(await fetch('http://127.0.0.1:8091/test/events')).json();
  assert(events.some(e=>e.path==='jog-plus'&&e.body.step==='1'));
  assert(events.some(e=>e.path==='heartbeat'),'Movement sends supervision heartbeats');
  assert(events.some(e=>e.path==='heartbeat'&&Number(e.body.skipped)>0),'Delayed response records skipped heartbeat timers');
  const hb=events.find(e=>e.path==='heartbeat');
  for(const key of ['seq','b_ms','gen','send_gap','timer_gap','skipped','prev_rtt','status_age'])assert(Number.isFinite(Number(hb.body[key])),key);
  await ev(`window.traceExport=null;window.originalURL=URL.createObjectURL;URL.createObjectURL=blob=>{window.traceExport=blob.text();return originalURL(blob);};window.originalClick=HTMLAnchorElement.prototype.click;HTMLAnchorElement.prototype.click=function(){};`);
  await click('download-heartbeat-trace');
  const exported=JSON.parse(await ev('traceExport'));
  assert(exported.events.length<=200);assert(exported.events.some(e=>e.kind==='status-error'));
  assert(!JSON.stringify(exported).includes('test-boot-1'),'No session token exported');
  await ev('URL.createObjectURL=originalURL;HTMLAnchorElement.prototype.click=originalClick');
  assert(events.some(e=>e.path==='calibration/profile'&&e.body.open_speed==='120'));
  assert.equal(c.requests.filter(url=>url==='http://127.0.0.1:8091/').length,1,'Tabs do not reload the document');
  assert(c.requests.every(url=>url.startsWith('http://127.0.0.1:8091/')||url.startsWith('data:')),'No hardware requests');
  assert.deepEqual(c.errors,[]);
  console.log('Live UI: beta gate, persisted drafts, live command payloads/results, fine jogs, calibration/profile saves, failure handling, read-only telescope monitoring and cover interlocks, Stop races, idle DOM stability, themes, responsive layouts, and disconnection passed.');
 }finally{c.close();}
})().catch(error=>{console.error(error);process.exitCode=1;});
