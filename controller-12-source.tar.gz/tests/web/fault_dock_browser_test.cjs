// Local debug server on 8083; isolated Chrome CDP on 9237. No hardware access.
const assert=require('node:assert/strict');
(async()=>{
 const targets=await(await fetch('http://127.0.0.1:9237/json/list')).json();
 const ws=new WebSocket(targets.find(t=>t.type==='page').webSocketDebuggerUrl);let id=0;const pending=new Map(),errors=[];
 await new Promise(r=>ws.addEventListener('open',r,{once:true}));
 ws.addEventListener('message',e=>{const m=JSON.parse(e.data);if(m.id){const p=pending.get(m.id);pending.delete(m.id);m.error?p.reject(Error(m.error.message)):p.resolve(m.result);}if(m.method==='Runtime.exceptionThrown')errors.push(m.params);});
 const call=(method,params={})=>new Promise((resolve,reject)=>{pending.set(++id,{resolve,reject});ws.send(JSON.stringify({id,method,params}));});
 const ev=async expression=>{const r=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error(r.exceptionDetails.text);return r.result.value;};
 const wait=async expr=>{for(let n=0;n<100;n++){if(await ev(expr))return;await new Promise(r=>setTimeout(r,100));}throw Error('Timeout: '+expr);};
 try{
  await call('Runtime.enable');await call('Page.enable');
  await call('Emulation.setDeviceMetricsOverride',{width:1440,height:1000,deviceScaleFactor:1,mobile:false});
  await call('Page.navigate',{url:'http://127.0.0.1:8083/?test='+Date.now()+'#overview'});
  await wait('window.coverAPI?.state.cover && document.getElementById("simulate-fault")');
  await ev('document.getElementById("simulate-fault").click()');
  await wait('!document.getElementById("recoveryControls").hidden');
  await wait('document.getElementById("stop").disabled');
  assert(await ev('document.querySelector(".stop-dock").classList.contains("fault-active")'));
  assert(await ev('document.querySelector(".stop-dock #recover")!==null'));
  assert(await ev('document.getElementById("recover").disabled'));
  await ev('document.getElementById("inspected").click()');
  await wait('!document.getElementById("recover").disabled');
  assert.equal(await ev('document.getElementById("supported").checked'),false,'No Calibration confirmation required');
  for(const width of [1440,390]){
   await call('Emulation.setDeviceMetricsOverride',{width,height:1000,deviceScaleFactor:1,mobile:false});
   assert(await ev('(()=>{const a=document.getElementById("recover").getBoundingClientRect(),b=document.getElementById("stop").getBoundingClientRect();return a.left>=0&&a.right<=innerWidth&&a.bottom<=innerHeight&&(a.bottom<=b.top||a.top>=b.bottom||a.right<=b.left||a.left>=b.right)})()'),'Recovery and Stop remain visible without overlap');
  }
  await ev('document.getElementById("recover").click()');
  await wait('coverAPI.state.cover.state!=="FAULT" && document.getElementById("recoveryControls").hidden');
  await wait('!document.getElementById("stop").disabled');
  assert.equal(await ev('document.querySelector(".stop-dock").classList.contains("fault-active")'),false);
  assert.equal(await ev('location.hash'),'#overview');
  await ev('document.getElementById("simulate-fault").click()');
  await wait('!document.getElementById("recoveryControls").hidden');
  assert.equal(await ev('document.getElementById("inspected").checked'),false);
  assert(await ev('document.getElementById("recover").disabled'));
  await ev('document.getElementById("inspected").click()');await wait('!document.getElementById("recover").disabled');
  await ev('document.getElementById("recover").click()');await wait('document.getElementById("recoveryControls").hidden');
  assert.deepEqual(errors,[]);console.log('Fault trigger, dock recovery, confirmation reset, desktop/mobile layout passed');
 }catch(error){console.error(JSON.stringify(errors));throw error;}finally{ws.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
