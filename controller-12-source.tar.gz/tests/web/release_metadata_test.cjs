const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const crypto=require('node:crypto');
const path=require('node:path');
const {spawnSync}=require('node:child_process');
const os=require('node:os');
const api=require('../../data/ui/release_metadata.js');
const fixture=JSON.parse(fs.readFileSync(path.join(__dirname,'../fixtures/release_metadata.json'),'utf8'));
const clone=v=>JSON.parse(JSON.stringify(v));
function patch(value,changes={}){
 for(const [key,next] of Object.entries(changes)){
  const parts=key.split('.');let item=value;
  for(const part of parts.slice(0,-1))item=item[part];
  item[parts.at(-1)]=next;
 }
 return value;
}
// The same vectors run in Node tooling and the browser global, with no DOM,
// networking, local storage, device endpoint or install function available.
const browser={TextEncoder};vm.createContext(browser);
vm.runInContext(fs.readFileSync(path.join(__dirname,'../../data/ui/release_metadata.js'),'utf8'),browser);
for(const [runtime,model] of [['node',api],['browser',browser.CoverReleaseMetadata]]){
 test(`${runtime}: strict SemVer including numeric identifiers above JS precision`,()=>{
  for(const {a,b,order} of fixture.versions){
   assert.equal(model.compareVersions(a,b),order,`${a} / ${b}`);
   assert.equal(model.compareVersions(b,a),order===0?0:-order);
  }
  for(const bad of [...fixture.invalid_versions,null,1,true,{},'1'.repeat(161)])assert.throws(()=>model.parseVersion(bad));
 });
 for(const vector of fixture.assessments)test(`${runtime}: ${vector.name}`,()=>{
  const release=model.parseReleaseJson(JSON.stringify(patch(clone(fixture.release),vector.release)));
  const device=model.parseDeviceJson(JSON.stringify(patch(clone(fixture.device),vector.device)));
  const result=model.assessRelease(release,device,vector.options);
  assert.equal(result.code,vector.code);
  assert.equal(result.method,vector.method||null);
  assert.equal(result.compatible,Boolean(vector.method));
  assert.equal(result.update_available,Boolean(vector.method));
  assert.equal(result.installable,false);
 });
 test(`${runtime}: malformed and unsupported metadata fail closed`,()=>{
  const cases=[
   {schema:1},{product:'other'},{version:'01.0.0'},{tag:'0.1.0'},{channel:'beta'},
   {version:'0.1.0+rebuild',tag:'v0.1.0+rebuild'},{commit:'a'.repeat(40)+'\n'},
   {elf:'G'.repeat(64)},{published:1},{protocol:true},{protocol:2},{extra:'unknown'},
   {'hardware.layout':'new-layout'},{'hardware.flash_bytes':8388608},
   {'hardware.board':'unknown-board'},{'motion.reference_offset':true},
   {'artifacts.0.size':1310721},{'artifacts.0.size':NaN},{'artifacts.0.size':1.5},
   {'artifacts.0.kind':'filesystem'},{'artifacts.0.filename':'../firmware.bin'},
   {'artifacts.0.filename':'factory.zip'},{'artifacts.0.sha256':'5'.repeat(64)+'\n'},
   {'transitions.0.version':'0.1.0'},{'transitions.0.rollback_compatible':'true'},
   {'qualification':'hardware-tested'},
  ];
  for(const changes of cases)assert.throws(()=>model.validateRelease(patch(clone(fixture.release),changes)),JSON.stringify(changes));
  for(const key of Object.keys(fixture.release)){
   const bad=clone(fixture.release);delete bad[key];assert.throws(()=>model.validateRelease(bad),key);
  }
  const duplicate=clone(fixture.release);duplicate.artifacts.push(duplicate.artifacts[0]);
  assert.throws(()=>model.validateRelease(duplicate));
  const transitions=clone(fixture.release);transitions.transitions.push(transitions.transitions[0]);
  assert.throws(()=>model.validateRelease(transitions));
  const missingApp=clone(fixture.release);missingApp.artifacts.shift();
  assert.throws(()=>model.validateRelease(missingApp));
  const noTransition=clone(fixture.release);noTransition.transitions=[];
  assert.equal(model.assessRelease(noTransition,fixture.device).code,'source-unsupported');
  const usbOnly=clone(fixture.release);usbOnly.artifacts.shift();usbOnly.transitions.shift();
  assert.equal(model.assessRelease(usbOnly,fixture.device).code,'usb-install-only');
  const noUsb=clone(fixture.release);noUsb.artifacts.pop();noUsb.transitions.pop();
  const disabled=patch(clone(fixture.device),{'receiver.enabled':false});
  assert.equal(model.assessRelease(noUsb,disabled).code,'receiver-disabled');
  for(const bad of [{include_beta:'yes'},{bypass:true},null])assert.throws(()=>model.assessRelease(fixture.release,fixture.device,bad));
  for(const change of [{'firmware.dirty':0},{'receiver.enabled':'true'},{'receiver.rollback':true},{'firmware.version':'1.0.0\n'}]){
   assert.throws(()=>model.validateDevice(patch(clone(fixture.device),change)));
  }
 });
 test(`${runtime}: bounded JSON rejects duplicate keys and ambiguous encodings`,()=>{
  const source=JSON.stringify(fixture.release);
  const bad=[
   source.replace('"schema":','"schema":"ignored","schema":'),
   source.replace('"schema":','"sch\\u0065ma":"ignored","schema":'),
   source.replace('"calibration":5','"calibration":5,"calibration":5'),
   source+' null',source.replace('"size":1000000','"size":1e6'),
   source.replace('"size":1000000','"size":1000000.0'),
   source.replace('"size":1000000','"size":01000000'),
   source.replace('"size":1000000','"size":-0'),
   source.replace('"size":1000000','"size":9007199254740993'),
   source+' '.repeat(8192),source.replace('"product":"telescope-cover"','"product":"'+'é'.repeat(4100)+'"'),
   '['.repeat(10)+'0'+']'.repeat(10),'['+Array(33).fill('0').join(',')+']',
   '{"__proto__":{"polluted":true}}','{"schema":NaN}','{"schema":Infinity}',
   '{"schema":"unterminated}',source.slice(0,-1)+',}',source.replace('"size":1000000','"size":null'),
  ];
  for(const value of bad)assert.throws(()=>model.parseReleaseJson(value),value.slice(0,90));
  assert.equal({}.polluted,undefined);
 });
}
test('profile fingerprint is bound to the existing exact 40-byte native profile and lock',()=>{
 const header=fs.readFileSync(path.join(__dirname,'../../src/servo_factory_profile.h'),'utf8');
 const initializer=header.split('expected[40] = {')[1].split('}')[0];
 const bytes=Buffer.from([...initializer.matchAll(/0x([0-9a-f]+)/g)].map(m=>parseInt(m[1],16)));
 assert.equal(bytes.length,40);bytes[11]=bytes[12]=0;bytes[18]=28;
 const digest=crypto.createHash('sha256').update(bytes).update(Buffer.from([1])).digest('hex');
 assert.equal(digest,api.NATIVE_PROFILE_SHA256);
 assert.equal(digest,fixture.release.motion.profile_sha256);
});
test('exact source settings and full source identity are required',()=>{
 for(const field of ['calibration','application','network','auth','handoff']){
  const r=clone(fixture.release);
  for(const t of r.transitions)t.settings[field]=typeof t.settings[field]==='number'?t.settings[field]+1:'other-schema';
  assert.equal(api.assessRelease(r,fixture.device).code,'source-unsupported',field);
 }
 for(const field of ['commit','elf']){
  const device=clone(fixture.device);device.firmware[field]='a'.repeat(field==='commit'?40:64);
  assert.equal(api.assessRelease(fixture.release,device).code,'source-unsupported');
 }
});
test('preview schemas on both sides cannot manufacture support for unknown settings',()=>{
 const release=clone(fixture.release),device=clone(fixture.device);
 release.settings.auth=device.settings.auth='unknown-auth';
 for(const transition of release.transitions)transition.settings.auth='unknown-auth';
 assert.equal(api.assessRelease(release,device).code,'settings-unsupported');
 const original=JSON.stringify(fixture);
 api.assessRelease(fixture.release,fixture.device);
 assert.equal(JSON.stringify(fixture),original,'Assessment must not alter shared metadata or device evidence');
});
test('offline CLI validates preview input and never authorizes installation',()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'cover-release-metadata-'));
 try{
  const release=path.join(dir,'release.json'),device=path.join(dir,'device.json');
  fs.writeFileSync(release,JSON.stringify(fixture.release));fs.writeFileSync(device,JSON.stringify(fixture.device));
  const command=path.join(__dirname,'../../tools/release_metadata.cjs');
  const run=spawnSync(process.execPath,[command,release,device],{encoding:'utf8'});
  assert.equal(run.status,0,run.stderr);assert.equal(JSON.parse(run.stdout).assessment.code,'ota-candidate');
  assert.equal(JSON.parse(run.stdout).assessment.installable,false);
  fs.writeFileSync(release,'{"schema":1,"schema":2}');
  const rejected=spawnSync(process.execPath,[command,release],{encoding:'utf8'});
  assert.equal(rejected.status,1);assert.equal(rejected.stdout,'');assert.match(rejected.stderr,/rejected/);
 }finally{fs.rmSync(dir,{recursive:true,force:true});}
});

for(const [runtime,model] of [['node',api],['browser',browser.CoverReleaseMetadata]]){
 test(`${runtime}: live device observations stay separate from synthetic compatibility`,()=>{
  const device={...clone(fixture.device),schema:model.LIVE_DEVICE_SCHEMA,
   read_only_test:true,servo_profile_verified:false,
   settings:{...fixture.device.settings,network:'cover-app-network-v1',auth:'legacy-session-token-v1'}};
  const assess=()=>model.assessRelease(fixture.release,model.parseDeviceJson(JSON.stringify(device)));
  assert.equal(assess().code,'read-only-test');
  device.read_only_test=false;
  assert.equal(assess().code,'servo-unverified');
  device.motion=null;
  assert.equal(assess().code,'servo-unverified');
  device.motion=clone(fixture.device.motion);device.servo_profile_verified=true;
  assert.equal(assess().code,'settings-unsupported','Actual legacy auth must never be labelled preview device auth');
  device.hardware.layout='unknown';device.hardware.slot_bytes=0;
  assert.equal(assess().code,'hardware-mismatch');
  device.firmware.release=false;device.firmware.dirty=true;
  assert.equal(assess().code,'development-build');
  assert.equal(assess().installable,false);
  for(const [key,value] of [['read_only_test',1],['servo_profile_verified','true']]){
   assert.throws(()=>model.validateDevice({...device,[key]:value}));
  }
  assert.throws(()=>model.validateDevice({...device,unexpected:true}));
 });
}
