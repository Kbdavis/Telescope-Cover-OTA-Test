/* Real UI against loopback fixture only. Chrome CDP 9226, HTTP fixture 8094. */
const assert=require('node:assert/strict');
(async()=>{
 const targets=await(await fetch('http://127.0.0.1:9226/json/list')).json();
 const ws=new WebSocket(targets.find(t=>t.type==='page').webSocketDebuggerUrl),pending=new Map(),errors=[];let id=0;
 await new Promise((resolve,reject)=>{ws.addEventListener('open',resolve,{once:true});ws.addEventListener('error',reject,{once:true});});
 ws.addEventListener('message',event=>{const m=JSON.parse(event.data);if(m.id){const p=pending.get(m.id);pending.delete(m.id);m.error?p.reject(Error(m.error.message)):p.resolve(m.result);}if(m.method==='Runtime.exceptionThrown')errors.push(m.params.exceptionDetails);});
 const call=(method,params={})=>new Promise((resolve,reject)=>{const n=++id;pending.set(n,{resolve,reject});ws.send(JSON.stringify({id:n,method,params}));});
 const ev=async expression=>{const r=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error(r.exceptionDetails.text);return r.result.value;};
 const wait=async expr=>{for(let n=0;n<150;n++){if(await ev(expr))return;await new Promise(r=>setTimeout(r,50));}throw Error('Timed out: '+expr);};
 try{
  await call('Runtime.enable');await call('Page.enable');
  await fetch('http://127.0.0.1:8094/test/reset',{method:'POST',body:''});
  await call('Page.navigate',{url:'http://127.0.0.1:8094/#configuration'});await wait('!!window.coverAPI?.state?.session && !!coverAPI.state.network');
  await ev(`(()=>{coverAPI.state.session.firmware={version:'0.1.0-beta.1',release:true,commit:'a'.repeat(40),profile:'web_control_usb',built_at:'2026-11-11T20:00:00Z'};document.querySelector('dialog[open]')?.close();})()`);
  await wait("document.getElementById('cfg-firmware-version').textContent==='0.1.0-beta.1'");
  assert.match(await ev("document.getElementById('sessionNote').textContent"),/Firmware 0.1.0-beta.1/);
  assert.match(await ev("document.getElementById('cfg-firmware-notes').href"),/releases\/tag\/v0.1.0-beta.1$/);
  for(const width of [1440,390]){
   await call('Emulation.setDeviceMetricsOverride',{width,height:1000,deviceScaleFactor:1,mobile:width<500});
   await ev("document.getElementById('cfg-about').scrollIntoView()");
   assert(await ev('document.documentElement.scrollWidth<=innerWidth+1'),'About metadata overflows viewport');
  }
  assert.deepEqual(errors,[]);console.log('Real browser: installed version footer/About/release link and desktop/mobile hash layout passed');
 }finally{ws.close();}
})().catch(error=>{console.error(error);process.exitCode=1;});
