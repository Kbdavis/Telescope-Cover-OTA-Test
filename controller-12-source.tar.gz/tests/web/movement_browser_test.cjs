/* Real embedded UI; loopback fixture 8094 and isolated Chrome CDP 9226. No hardware. */
const assert=require('node:assert/strict'),fs=require('node:fs');
const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
const HTTP='http://127.0.0.1:'+(process.env.COVER_TEST_HTTP_PORT||8094),CDP='http://127.0.0.1:'+(process.env.COVER_TEST_CDP_PORT||9226);
(async()=>{
 const targets=await(await fetch(CDP+'/json/list')).json();
 const ws=new WebSocket(targets.find(target=>target.type==='page').webSocketDebuggerUrl),pending=new Map(),errors=[];let next=0;
 await new Promise(resolve=>ws.addEventListener('open',resolve,{once:true}));
 ws.addEventListener('message',event=>{const m=JSON.parse(event.data);if(m.id){const p=pending.get(m.id);if(!p)return;clearTimeout(p.timer);pending.delete(m.id);m.error?p.reject(Error(m.error.message)):p.resolve(m.result);}if(m.method==='Runtime.exceptionThrown')errors.push(m.params.exceptionDetails);if(m.method==='Page.javascriptDialogOpening')call('Page.handleJavaScriptDialog',{accept:true}).catch(error=>errors.push(error.message));});
 const call=(method,params={})=>new Promise((resolve,reject)=>{const id=++next,timer=setTimeout(()=>{pending.delete(id);reject(Error('CDP timeout: '+method));},15000);pending.set(id,{resolve,reject,timer});ws.send(JSON.stringify({id,method,params}));});
 const ev=async expression=>{const r=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true,userGesture:true});if(r.exceptionDetails)throw Error(r.exceptionDetails.exception?.description||r.exceptionDetails.text);return r.result.value;};
 const wait=async expression=>{for(let n=0;n<120;n++){if(await ev(expression))return;await delay(100);}throw Error('Timeout: '+expression);};
 const click=id=>ev(`document.getElementById('${id}').click()`);
 const patch=async body=>{await fetch(HTTP+'/test/patch',{method:'POST',body:JSON.stringify(body)});await ev(body.controls?.drop_status?'coverAPI.cover().catch(()=>{})':'coverAPI.cover()');};
 const reload=async()=>{await ev('window.__beforeReload=true');await call('Page.reload',{ignoreCache:true});await wait("!window.__beforeReload&&window.coverAPI?.state.network&&coverAPI.state.cover&&coverAPI.state.session");};
 const input=(id,value)=>ev(`(()=>{const e=document.getElementById('${id}');e.value=${JSON.stringify(String(value))};e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));})()`);
 const done=()=>wait('!coverAPI.state.busy&&!coverAPI.state.active&&!coverAPI.state.cover.moving&&!coverAPI.state.cover.holding');
 const step=async n=>{await ev(`calibrationUI.navigate(${n})`);await delay(450);};
 const events=async()=>await(await fetch(HTTP+'/test/events')).json();
 const arc=(closed,open,direction)=>({circular:false,draft_circular:false,teaching:false,rollover_supported:false,state:'UNKNOWN',fault:'',ready:true,moving:false,holding:false,torque:false,position:closed,
  calibration_only:false,calibrated:true,dirty:false,calibration_review:false,opening_direction:direction,draft_direction:direction,
  travel_counts:Math.abs(open-closed),draft_travel_counts:Math.abs(open-closed),closed,open,draft_closed:closed,draft_open:open,
  minimum:0,maximum:4095,draft_minimum:0,draft_maximum:4095,saved_minimum:0,saved_maximum:4095});
 try{
  await call('Runtime.enable');await call('Page.enable');await call('Emulation.setFocusEmulationEnabled',{enabled:true});
  await call('Emulation.setDeviceMetricsOverride',{width:1440,height:1000,deviceScaleFactor:1,mobile:false});
  await call('Page.navigate',{url:'about:blank'});await wait("location.href==='about:blank'&&!window.coverAPI");errors.length=0;
  await fetch(HTTP+'/test/reset',{method:'POST'});
  await fetch(HTTP+'/test/patch',{method:'POST',body:JSON.stringify({controls:{beta:true}})});
  await call('Page.navigate',{url:HTTP+'/#overview'});
  await wait('window.coverAPI?.state.network&&coverAPI.state.cover&&coverAPI.state.session');
  await click('nav-calibration');await step(0);for(const id of ['present','supported','stowed'])await click(id);
  await click('prepareNext');await done();await step(1);
  assert.deepEqual(await ev('[...document.querySelectorAll("[data-count]")].map(e=>Number(e.dataset.count))'),[10,100,500]);
  const jogs=async()=> (await events()).filter(e=>e.path==='jog-plus'||e.path==='jog-minus').length;
  const waitJogs=async count=>{for(let n=0;n<240;n++){if(await jogs()>=count)return;await delay(100);}throw Error('Held movement stopped before '+count+' steps');};
  // A real pointer remains down across eight completed movements, including
  // delayed torque feedback between steps. No second press is sent.
  const point=await ev("(()=>{const e=document.getElementById('holdPlus');e.scrollIntoView({block:'center'});const r=e.getBoundingClientRect();return {x:r.x+r.width/2,y:r.y+r.height/2}})()");
  await call('Input.dispatchMouseEvent',{type:'mousePressed',...point,button:'left',buttons:1,clickCount:1});
  await waitJogs(2);await wait('!coverAPI.state.active&&!coverAPI.state.cover.moving&&coverAPI.state.repeats');
  await patch({cover:{torque:null}});const gap=await jogs();await delay(650);
  assert.equal(await jogs(),gap,'No new move before torque feedback is confirmed');
  await patch({cover:{torque:true}});await delay(300);assert.equal(await jogs(),gap,'Wait for delayed torque-OFF confirmation too');
  await patch({cover:{torque:false}});await waitJogs(8);
  await call('Input.dispatchMouseEvent',{type:'mouseReleased',...point,button:'left',buttons:0,clickCount:1});await done();
  let released=await jogs();await delay(900);assert.equal(await jogs(),released,'Pointer release cancels repetition');
  // Keyboard hold also repeats, and releasing while a repeat is waiting
  // prevents a later move when feedback recovers.
  await ev("document.getElementById('holdMinus').focus()");
  await call('Input.dispatchKeyEvent',{type:'keyDown',key:' ',code:'Space',windowsVirtualKeyCode:32});
  await waitJogs(released+6);await wait('!coverAPI.state.active&&!coverAPI.state.cover.moving&&coverAPI.state.repeats');
  await patch({cover:{torque:null}});
  await call('Input.dispatchKeyEvent',{type:'keyUp',key:' ',code:'Space',windowsVirtualKeyCode:32});
  await patch({cover:{torque:false}});await done();released=await jogs();await delay(900);
  assert.equal(await jogs(),released,'Release during the feedback wait never restarts');
  // Opting out of the default manual hold releases torque after each step.
  await patch({cover:{teaching:false,dirty:false}});await click('nav-manual');await click('manual-enable');await click('manual-accept');
  await wait("!document.getElementById('manual-fields').disabled");
  assert.equal(await ev("document.getElementById('manual-hold-torque').checked"),true);
  await click('manual-hold-torque');
  for(const dir of ['plus','minus','plus']){
   await click('manual-'+dir);await done();assert.equal(await ev('coverAPI.state.cover.torque'),false);
   assert.equal(await ev("document.getElementById('manual-fields').disabled"),false);
  }
  assert.deepEqual(await ev('[...document.getElementById("manual-step").options].map(e=>Number(e.value))'),[10,100,500]);
  await ev("document.getElementById('manual-step').value='500'");
  const before500=await ev('coverAPI.state.cover.position');await click('manual-plus');await done();
  assert.equal(await ev('coverAPI.state.cover.position'),before500+500);
  assert.equal(await ev('coverAPI.state.cover.torque'),false);
  const manualEvents=(await events()).filter(e=>e.path.startsWith('manual/jog'));
  assert.equal(manualEvents.length,4);assert(manualEvents.every(e=>e.body.hold==='no'));
  // Reversed mounting takes precedence over old draft direction. Manual remains
  // available outside both raw configured limits and the taught cover arc.
  await patch({cover:{ready:false,manual_ready:true,assembly_opening_direction:-1,calibration_only:true,
   teaching:false,position:2200,minimum:2000,maximum:2100,draft_minimum:2000,draft_maximum:2100,
   draft_closed:2000,draft_open:2100,draft_direction:1,draft_travel_counts:100}});
  await input('manual-step',100);
  await click('manual-plus');await done();assert.equal(await ev('coverAPI.state.cover.position'),2100);
  await click('manual-minus');await done();assert.equal(await ev('coverAPI.state.cover.position'),2200);
  let lastManual=(await events()).filter(e=>e.path.startsWith('manual/jog')).slice(-2);
  assert.deepEqual(lastManual.map(e=>e.path),['manual/jog-minus','manual/jog-plus']);
  assert(lastManual.every(e=>e.body.hold==='no'));
  await input('manual-step',10);
  await patch({cover:{position:5}});
  assert(await ev("document.getElementById('manual-plus').disabled"));
  assert(!await ev("document.getElementById('manual-minus').disabled"));
  await patch({cover:{position:4090}});
  assert(await ev("document.getElementById('manual-minus').disabled"));
  await patch({cover:{state:'FAULT',fault:'Servo overcurrent; cycle servo power before clearing fault',
   manual_ready:false,calibration_only:false,position:null,torque:null}});
  assert(await ev("document.getElementById('manual-fields').disabled"));
  assert(!await ev("document.getElementById('faultPowerCycleHelp').hidden"));
  assert.match(await ev("document.getElementById('faultPowerCycleHelp').textContent"),/external power supply OFF, then ON/);
  await click('nav-calibration');
  assert.match(await ev("document.getElementById('issueTitle').textContent"),/overcurrent/);
  assert.match(await ev("document.getElementById('issueText').textContent"),/Restarting the controller alone does not clear/);
  await patch({cover:{state:'UNKNOWN',fault:'',ready:false,manual_ready:true,calibration_only:true,position:2200,torque:false}});
  await click('nav-manual');await click('manual-enable');await click('manual-accept');
  await wait("!document.getElementById('manual-fields').disabled");
  for(const width of [320,390,768,1440]){
   await call('Emulation.setDeviceMetricsOverride',{width,height:1000,deviceScaleFactor:1,mobile:width<500});
   assert.equal(await ev('document.documentElement.scrollWidth<=document.documentElement.clientWidth'),true,'Manual layout '+width);
   const shot=await call('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});fs.writeFileSync('/tmp/cover-manual-'+width+'.png',Buffer.from(shot.data,'base64'));
  }
  // Fresh teaching uses the physical opening direction. Clear the old +1
  // fixture calibration so Prepare does not intentionally resume that pair.
  await patch({cover:{state:'UNKNOWN',ready:true,calibration_only:false,position:2500,teaching:false,
   calibrated:false,draft_closed:null,draft_open:null}});
  await click('nav-calibration');await step(0);await click('prepareNext');await done();await step(1);
  assert.equal(await ev('coverAPI.state.cover.draft_direction'),-1);
  await ev("document.querySelector('[data-count=\"100\"]').click()");
  await click('plus');await done();await delay(450);assert.equal(await ev('coverAPI.state.cover.position'),2400);
  await click('minus');await done();await delay(450);assert.equal(await ev('coverAPI.state.cover.position'),2500);
  const reversedPoint=await ev("(()=>{const e=document.getElementById('holdPlus');e.scrollIntoView({block:'center'});const r=e.getBoundingClientRect();return {x:r.x+r.width/2,y:r.y+r.height/2}})()");
  const reverseCount=await jogs();
  await call('Input.dispatchMouseEvent',{type:'mousePressed',...reversedPoint,button:'left',buttons:1,clickCount:1});
  await waitJogs(reverseCount+2);
  await call('Input.dispatchMouseEvent',{type:'mouseReleased',...reversedPoint,button:'left',buttons:0,clickCount:1});await done();
  assert((await events()).filter(e=>e.path==='jog-plus'||e.path==='jog-minus').slice(-2).every(e=>e.path==='jog-minus'));
  assert.deepEqual(errors,[]);console.log('Held pointer/keyboard repetition, delayed feedback, release cancellation and automatic manual release passed');
  await call('Page.navigate',{url:'about:blank'});
 }finally{ws.close();}
})().catch(error=>{console.error(error);process.exitCode=1;});
