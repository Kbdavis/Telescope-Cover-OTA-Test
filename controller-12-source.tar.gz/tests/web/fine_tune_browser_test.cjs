/* Real UI, loopback fixture 8091 and isolated Chrome CDP 9226. No hardware. */
const assert=require('node:assert/strict');
const HTTP=process.env.COVER_TEST_HTTP_URL||'http://127.0.0.1:8091';
(async()=>{
 const targets=await(await fetch('http://127.0.0.1:9226/json/list')).json();
 const ws=new WebSocket((targets.find(t=>t.type==='page'&&t.url==='about:blank')||targets.find(t=>t.type==='page')).webSocketDebuggerUrl),pending=new Map();let id=0;
 await new Promise(resolve=>ws.addEventListener('open',resolve,{once:true}));
 ws.addEventListener('message',e=>{const m=JSON.parse(e.data);if(m.method==='Page.javascriptDialogOpening')call('Page.handleJavaScriptDialog',{accept:true});if(m.id){const p=pending.get(m.id);pending.delete(m.id);m.error?p.reject(Error(m.error.message)):p.resolve(m.result);}});
 const call=(method,params={})=>new Promise((resolve,reject)=>{pending.set(++id,{resolve,reject});ws.send(JSON.stringify({id,method,params}));});
 const ev=async expression=>{const r=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true,userGesture:true});if(r.exceptionDetails)throw Error(r.exceptionDetails.text);return r.result.value;};
 const wait=async expression=>{for(let n=0;n<100;n++){if(await ev(expression))return;await new Promise(r=>setTimeout(r,100));}throw Error('Timeout: '+expression);};
 const click=id=>ev(`document.getElementById('${id}').click()`);
 try{
  await call('Page.enable');
  await call('Page.handleJavaScriptDialog',{accept:true}).catch(()=>{});
  await fetch(HTTP+'/test/reset',{method:'POST'});
  await fetch(HTTP+'/test/patch',{method:'POST',body:JSON.stringify({controls:{beta:true},scope:{enabled:false},cover:{teaching:false,torque:false,moving:false,holding:false}})});
  await ev('window.__fineTuneOldPage=true');
  await call('Page.navigate',{url:HTTP+'/?fine-tune-test='+Date.now()+'#calibration'});
  await wait('!window.__fineTuneOldPage&&window.coverAPI?.state.cover&&window.calibrationUI&&coverAPI.state.session');
  await click('nav-calibration');await ev('calibrationUI.navigate(3)');
  const endpoints=await ev('[coverAPI.state.cover.draft_closed,coverAPI.state.cover.draft_open]');
  await click('backToTeach');
  assert.equal(await ev("document.querySelector('[data-panel=\"0\"]').hidden"),false,'Missing confirmations lead to Prepare');
  assert.equal(await ev('coverAPI.state.cover.teaching'),false);
  for(const id of ['present','supported','stowed'])await click(id);
  await click('prepareNext');
  await wait('coverAPI.state.cover.teaching&&!coverAPI.state.busy');
  await wait("!document.getElementById('plus').disabled");
  assert.deepEqual(await ev('[coverAPI.state.cover.draft_closed,coverAPI.state.cover.draft_open]'),endpoints);
  assert.equal(await ev("document.querySelector('[data-panel=\"1\"]').hidden"),false);
  await fetch(HTTP+'/test/patch',{method:'POST',body:JSON.stringify({cover:{teaching:false,dirty:false}})});
  await ev('coverAPI.cover()');await ev('calibrationUI.navigate(3)');
  await click('backToTeach');await wait('coverAPI.state.cover.teaching&&!coverAPI.state.busy');
  assert.equal(await ev("document.querySelector('[data-panel=\"1\"]').hidden"),false,'Existing confirmations resume directly');
  assert.deepEqual(await ev('[coverAPI.state.cover.draft_closed,coverAPI.state.cover.draft_open]'),endpoints);
  // Reload path: check Prepare, then click the Step 2 sidebar directly.
  await fetch(HTTP+'/test/patch',{method:'POST',body:JSON.stringify({cover:{teaching:false,dirty:false}})});
  await ev('coverAPI.cover()');
  await ev('calibrationUI.navigate(0)');
  await ev("document.querySelector('[data-step=\"1\"]').click()");
  await wait('coverAPI.state.cover.teaching&&!coverAPI.state.busy');
  await wait("!document.getElementById('plus').disabled");
  assert.deepEqual(await ev('[coverAPI.state.cover.draft_closed,coverAPI.state.cover.draft_open]'),endpoints);
  // The main Prepare button must preserve endpoints too, without Fine tune first.
  await fetch(HTTP+'/test/patch',{method:'POST',body:JSON.stringify({cover:{teaching:false,dirty:false}})});
  await ev('coverAPI.cover()');await ev('calibrationUI.navigate(0)');
  await click('prepareNext');await wait('coverAPI.state.cover.teaching&&!coverAPI.state.busy');
  assert.deepEqual(await ev('[coverAPI.state.cover.draft_closed,coverAPI.state.cover.draft_open]'),endpoints);
  await fetch(HTTP+'/test/patch',{method:'POST',body:JSON.stringify({cover:{position:endpoints[0]+10}})});
  await ev('coverAPI.cover()');await click('chooseClosed');await click('capture');
  await wait('!coverAPI.state.busy&&coverAPI.state.cover.draft_closed==='+String(endpoints[0]+10));
  assert.equal(await ev('coverAPI.state.cover.draft_open'),endpoints[1]);
  assert.equal(await ev("document.getElementById('teachNext').disabled"),false,'One endpoint adjustment can be reviewed');
  await click('teachNext');
  assert.equal(await ev("document.querySelector('[data-panel=\"2\"]').hidden"),false);
  const events=await(await fetch(HTTP+'/test/events')).json();
  assert(events.some(e=>e.path==='calibration/begin'&&e.body.resume==='yes'));
  assert(!events.some(e=>/jog|^open$|^close$/.test(e.path)),'Fine tune never commands movement');
  console.log('Fine tune: Prepare confirmations, teaching resume, preserved endpoints, enabled jogs and no automatic movement passed');
 }finally{ws.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
