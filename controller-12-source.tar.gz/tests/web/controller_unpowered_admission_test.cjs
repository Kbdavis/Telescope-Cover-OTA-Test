/* Explicit spare-only rejection test. Sends no image chunks and cannot select
   firmware. A synthetic signed manifest tests admission after authentication. */
const fs=require('node:fs'),assert=require('node:assert/strict'),crypto=require('node:crypto'),path=require('node:path');
(async()=>{
 const [base,out,keyfile]=process.argv.slice(2);assert.equal(base,'http://192.168.1.135');assert(fs.statSync(out).isDirectory());
 const get=async route=>{const r=await fetch(base+'/api/'+route,{signal:AbortSignal.timeout(5000)});assert(r.ok);return r.json();};
 const before=await get('update/status'),cover=await get('status');assert.equal(before.phase,'idle');assert.equal(cover.settings_offline_allowed,true);assert.equal(cover.moving,false);assert.equal(cover.ready,false);
 const manifest='product=telescope-cover\nprotocol=browser-signed-v1\nlayout=cover-4mb-v1\nmotion=native-multiturn-v1\nstartup=inspect-only-v1\nsettings=preserve-cover-v1\nsource_build='+before.build+'\nsource_elf='+before.firmware_id+'\ntarget_build='+(before.build+1)+'\ntarget_elf='+'b'.repeat(64)+'\nsize=1200000\nsha256='+'c'.repeat(64)+'\n';
 const signature=crypto.sign('sha256',Buffer.from(manifest),{key:fs.readFileSync(keyfile),dsaEncoding:'ieee-p1363'}).toString('hex');
 const noHeader=await fetch(base+'/api/update/session');assert.equal(noHeader.status,403);
 const cross=await fetch(base+'/api/update/session',{headers:{'X-Update-Session':'1',Origin:'https://unrelated.example'}});assert.equal(cross.status,403);
 const session=await(await fetch(base+'/api/update/session',{headers:{'X-Update-Session':'1',Origin:base}})).json();assert.equal(session.boot,before.boot_id);
 const send=async({key=session.update_token,origin=base,confirm='install',sig=signature,generation=String(before.generation)}={})=>fetch(base+'/api/update/start',{method:'POST',headers:{Origin:origin,'Content-Type':'application/x-www-form-urlencoded','X-Update-Key':key,'X-Update-Boot':session.boot},body:new URLSearchParams({manifest,signature:sig,confirm,generation}),signal:AbortSignal.timeout(5000)});
 const guards={missing_session_header:noHeader.status,foreign_session_origin:cross.status};
 for(const [name,options,expected] of [['bad_token',{key:'0'.repeat(64)},403],['foreign_origin',{origin:'https://unrelated.example'},403],['missing_confirmation',{confirm:''},400],['bad_signature',{sig:'0'.repeat(128)},400],['stale_generation',{generation:'9999'},400]]){const r=await send(options);await r.text();assert.equal(r.status,expected,name);guards[name]=r.status;assert.equal((await get('update/status')).phase,'idle');}
 const r=await send();assert.equal(r.status,202);const transaction=await r.text();assert(/^[a-f0-9]{32}$/.test(transaction));
 let after;for(let n=0;n<80;n++){after=await get('update/status');if(after.phase==='failed')break;await new Promise(r=>setTimeout(r,100));}
 assert.equal(after.phase,'failed');assert.equal(after.reason,'admission');assert.equal(after.received,0);assert.equal(after.boot_id,before.boot_id);assert.equal(after.firmware_id,before.firmware_id);assert.equal(after.handoff.last_update,null);
 const finalCover=await get('status');assert.equal(finalCover.moving,false);assert.equal(finalCover.holding,false);assert.equal(finalCover.maintenance.locked,false);
 const result={passed:true,hardware_test:true,source:before.firmware_id,version:before.version,guards,valid_signed_start_status:202,phase:after.phase,reason:after.reason,bytes_transferred:0,image_chunks_sent:0,boot_unchanged:true,no_boot_selection:true,maintenance_unlocked:true,synthetic_manifest_not_published:true,blocker:'Spare servo has no external power; no stationary/configuration/CLOSED admission evidence'};
 fs.writeFileSync(path.join(out,'unpowered-admission-result.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
})().catch(e=>{console.error(e);process.exitCode=1;});
