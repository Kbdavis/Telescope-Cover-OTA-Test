/* Actual spare + actual public GitHub/Pages. No mocked release, identity, download
   or update response. Uses only the per-device key captured privately from USB.
   Usage: node tests/web/bench_happy_path_browser_test.cjs http://SPARE-IP evidence-dir key-file */
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
(async()=>{
 const base=process.argv[2],dir=process.argv[3],key=fs.readFileSync(process.argv[4],'utf8').trim();
 assert(/^http:\/\/192\.168\.\d{1,3}\.\d{1,3}$/.test(base));assert(/^[a-f0-9]{64}$/.test(key));
 const a=JSON.parse(fs.readFileSync(path.join(dir,'a/artifact.json'))),b=JSON.parse(fs.readFileSync(path.join(dir,'b/artifact.json')));
 const catalog=JSON.parse(fs.readFileSync('/tmp/telescope-cover-ota-public-test/index.json'));
 const get=async()=>{const r=await fetch(base+'/api/bench/status',{signal:AbortSignal.timeout(5000)});assert(r.ok);return r.json();};
 const before=await get();assert.equal(before.profile,'bench-ota-v1');assert.equal(before.servo_operations,false);assert(before.accepted);assert.equal(before.elf,a.elf);assert.equal(before.slot,65536);
 fs.writeFileSync(path.join(dir,'a/status.json'),JSON.stringify(before,null,2)+'\n');
 const target=(await(await fetch('http://127.0.0.1:9234/json/list')).json()).find(t=>t.type==='page');assert(target);
 const ws=new WebSocket(target.webSocketDebuggerUrl),pending=new Map(),errors=[],requests=[],responses=[];let id=0;
 await new Promise(r=>ws.addEventListener('open',r,{once:true}));
 const call=(method,params={})=>new Promise((resolve,reject)=>{const n=++id;pending.set(n,{resolve,reject});ws.send(JSON.stringify({id:n,method,params}));});
 ws.addEventListener('message',event=>{const m=JSON.parse(event.data);
  if(m.id){const p=pending.get(m.id);pending.delete(m.id);m.error?p.reject(Error(m.error.message)):p.resolve(m.result);}
  if(m.method==='Runtime.exceptionThrown')errors.push(m.params.exceptionDetails.text);
  if(m.method==='Network.requestWillBeSent')requests.push({url:m.params.request.url,method:m.params.request.method});
  if(m.method==='Network.responseReceived')responses.push({url:m.params.response.url,status:m.params.response.status});
 });
 const ev=async expression=>{const r=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error(r.exceptionDetails.text);return r.result.value;};
 const wait=async(expression,ms=30000)=>{const until=Date.now()+ms;while(Date.now()<until){if(await ev(expression))return;await new Promise(r=>setTimeout(r,100));}throw Error('Timed out: '+expression);};
 const screenshot=async name=>{const r=await call('Page.captureScreenshot',{format:'png'});fs.writeFileSync(path.join(dir,name),Buffer.from(r.data,'base64'));};
 try{
  await call('Runtime.enable');await call('Page.enable');await call('Network.enable');await call('Network.setCacheDisabled',{cacheDisabled:true});
  await call('Page.navigate',{url:base+'/?real-bench-pipeline='+Date.now()});
  await wait("document.getElementById('available')?.textContent.includes('Update available')");
  assert.equal(await ev("document.getElementById('installed').textContent"),a.version);
  await ev("document.getElementById('updates').scrollIntoView()");await screenshot('01-real-update-available.png');
  // Safe negative admission checks: neither request is allowed to enqueue flash.
  const manifest=catalog.releases[0];
  const admission=await ev(`(async()=>{const s=await(await fetch('/api/bench/status')).json();const send=async(key,signature)=>{
   const r=await fetch('/api/bench/start',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded','X-Bench-Key':key,'X-Bench-Nonce':s.nonce},body:new URLSearchParams({manifest:${JSON.stringify(manifest.manifest)},signature})});return r.status;};
   const wrongKey=await send('0'.repeat(64),${JSON.stringify(manifest.signature)});
   const badSignature=await send(${JSON.stringify(key)},'0'.repeat(128));
   return {wrongKey,badSignature,status:await(await fetch('/api/bench/status')).json()};})()`);
  assert.equal(admission.wrongKey,403);assert.equal(admission.badSignature,400);assert.equal(admission.status.phase,'idle');assert.equal(admission.status.received,0);
  await ev(`(()=>{document.getElementById('key').value=${JSON.stringify(key)};document.getElementById('key').dispatchEvent(new Event('input'));document.getElementById('confirm').checked=true;document.getElementById('confirm').dispatchEvent(new Event('change'));})()`);
  assert.equal(await ev("document.getElementById('install').disabled"),false);
  const started=Date.now();await ev("document.getElementById('install').click()");
  let success=false,last='',lastLog=0;
  while(Date.now()-started<720000){
   const s=await ev("({operation:document.getElementById('operation').textContent,progress:document.getElementById('progress').value,result:window.benchLastResult||null})");
   if(Date.now()-lastLog>10000||s.operation!==last&&!s.operation.startsWith('Installing:')){console.log(s.operation);lastLog=Date.now();last=s.operation;}
   if(s.operation.startsWith('Update stopped:'))throw Error(s.operation);
   if(s.result){success=true;break;}await new Promise(r=>setTimeout(r,1000));
  }
  assert(success,'No confirmed completion before browser-test deadline');
  const after=await get();assert(after.accepted);assert.equal(after.build,2);assert.equal(after.elf,b.elf);assert.equal(after.slot,1376256);assert.notEqual(after.boot,before.boot);assert.equal(after.outcome,'complete');assert(after.settings_preserved);assert.equal(after.journal_target,b.elf);
  const result=await ev('window.benchLastResult');assert.equal(result.transaction,after.journal_transaction);assert.equal(result.source,a.elf);assert.equal(result.target,b.elf);
  await screenshot('02-real-update-complete.png');
  assert(responses.some(r=>r.url.startsWith('https://api.github.com/repos/Kbdavis/Telescope-Cover-OTA-Test/releases')&&r.status===200));
  assert(responses.some(r=>r.url==='https://kbdavis.github.io/Telescope-Cover-OTA-Test/bench-2.bin'&&r.status===200));
  assert.deepEqual(errors,[]);
  fs.writeFileSync(path.join(dir,'b/status.json'),JSON.stringify(after,null,2)+'\n');
  const record={passed:true,simulated:false,source:a,target:b,source_boot:before.boot,target_boot:after.boot,source_slot:before.slot,target_slot:after.slot,transaction:result.transaction,
   settings_preserved:after.settings_preserved,startup_accepted:after.accepted,outcome:after.outcome,elapsed_ms:Date.now()-started,
   authentication_rejection:admission.wrongKey,signature_rejection:admission.badSignature,requests,responses,servo_operations:false};
  fs.writeFileSync(path.join(dir,'browser-result.json'),JSON.stringify(record,null,2)+'\n');
  console.log(JSON.stringify({...record,requests:record.requests.length,responses:record.responses.length},null,2));
 }catch(error){fs.writeFileSync(path.join(dir,'browser-failure.json'),JSON.stringify({message:String(error).split(key).join('[REDACTED]'),errors,requests:requests.length},null,2)+'\n');throw error;}
 finally{ws.close();}
})().catch(error=>{console.error(error);process.exitCode=1;});
