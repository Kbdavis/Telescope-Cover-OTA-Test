const assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs');
const c={window:{}};vm.createContext(c);vm.runInContext(fs.readFileSync('data/ui/travel.js','utf8'),c);
const t=c.window.coverTravel;
assert.equal(t.openingDirection({assembly_opening_direction:-1,draft_direction:1}),-1);
assert.equal(t.openingDirection({assembly_opening_direction:1,draft_direction:-1}),1);
assert.equal(t.openingDirection({draft_direction:-1}),-1);
const outside={position:2200,minimum:2000,maximum:2100,draft_minimum:2000,draft_maximum:2100,draft_closed:2000,draft_open:2100,draft_direction:1,draft_travel_counts:100};
assert(t.jogReason(outside,-100));assert.equal(t.jogReason(outside,-100,true),'');
assert.equal(t.jogReason(outside,500,true),'');
assert.match(t.jogReason({...outside,position:5},-10,true),/boundary/);
assert.match(t.jogReason({...outside,position:4090},10,true),/boundary/);
assert.equal(t.jogReason({...outside,position:4090,rollover_supported:true},100,true),'');
assert.equal(t.jogReason({...outside,position:5,rollover_supported:true},-100,true),'');
assert.equal(t.jogReason({...outside,position:4090,rollover_supported:true,jog_step_limit:500},500,true),'');
assert.match(t.jogReason({...outside,position:2000,rollover_supported:true,jog_step_limit:100},500,true),/100 counts/);
assert.match(t.jogReason({...outside,position:null},10,true),/feedback/);
for(const direction of [-1,1])for(const start of [0,20,1000,3895]){
 const a={closed:direction>0?start:start+100,open:direction>0?start+100:start,direction,length:100,minimum:start,maximum:start+101};
 assert(t.supported(a));
 for(let x=0;x<=100;x++){const r=t.estimate(a,a.closed+direction*x);assert(r.valid);assert.equal(r.percent,x);}
 for(const value of [null,NaN,-1,4096,start+102])assert(!t.estimate(a,value).valid);
 const beyond={...a,minimum:Math.max(0,start-5),maximum:start+105};
 const out=t.estimate(beyond,start+101);assert(!out.valid);assert(!('percent' in out));
}
for(const a of [{closed:4000,open:100,direction:1,length:196,minimum:0,maximum:4095},
 {closed:100,open:4000,direction:-1,length:196,minimum:0,maximum:4095},
 {closed:0,open:2048,direction:1,length:2048,minimum:0,maximum:4095}])assert(!t.supported(a));
const a={closed:1048,open:3048,direction:1,length:2000,minimum:1000,maximum:3100};
const p={openSpeed:100,closeSpeed:100,acceleration:10,timeoutMs:5000};
assert(t.supported(a));assert.equal(t.duration(a,p).opening.nominal,20000);assert.equal(t.duration(a,p).recommended,29000);
assert.match(t.timeoutReason(a,p),/too short/);assert.equal(t.timeoutReason(a,{...p,timeoutMs:29000}),'');
assert.match(t.timeoutReason(a,{...p,openSpeed:1}),/exceeds the 30 s/);
console.log('Browser travel model: both directions, boundary positions, no clamping and timeout guidance passed');

for(const a of [{closed:2386,open:100,direction:1,length:1810,minimum:0,maximum:4095,circular:true},
 {closed:100,open:2386,direction:-1,length:1810,minimum:0,maximum:4095,circular:true}]){
 assert(t.supported(a));
 for(let n=0;n<=1810;n++){const raw=t.wrap(a.closed+a.direction*n);assert.equal(t.estimate(a,raw).counts,n);}
 assert(!t.estimate(a,1000).valid);
 const c={position:a.direction>0?4090:5,minimum:0,maximum:4095,teaching:true,rollover_supported:true};
 assert.equal(t.jogReason(c,a.direction*10),'');c.rollover_supported=false;assert.match(t.jogReason(c,a.direction*10),/commissioning/);
}
console.log('Circular travel: both directions, all encoder samples, forbidden complementary arc and commissioning gates passed');

// A confirmed endpoint can settle either side of its taught count. This is
// display-only: unknown/stopped/moving estimates and mechanical bounds stay strict.
for(const direction of [-1,1])for(const closed of [0,365,4095]){
 const length=1781,open=t.wrap(closed+direction*length);
 const arc={closed,open,direction,length,minimum:0,maximum:4095,circular:true};
 for(const [state,endpoint,percent] of [['CLOSED',closed,0],['OPEN',open,100]]){
  for(let delta=-25;delta<=25;delta++){
   const value=t.wrap(endpoint+delta),r=t.estimate(arc,value,state);
   assert(r.valid);assert.equal(r.percent,percent);assert.equal(r.rawCounts,(state==='CLOSED'?0:length)+direction*delta);
  }
  const outside=t.wrap(endpoint+direction*(state==='CLOSED'?-26:26));
  assert(!t.estimate(arc,outside,state).valid);
  for(const unconfirmed of [null,'STOPPED','UNKNOWN','OPENING','CLOSING'])
   assert(!t.estimate(arc,t.wrap(endpoint+direction*(state==='CLOSED'?-2:2)),unconfirmed).valid);
  for(const invalid of [null,NaN,-1,4096])assert(!t.estimate(arc,invalid,state).valid);
 }
}
const reported={closed:365,open:2680,direction:-1,length:1781,minimum:0,maximum:4095,circular:true};
assert.equal(t.estimate(reported,367).reason,'Outside taught endpoints');
assert.equal(t.label(t.estimate(reported,367,'CLOSED')),'0% travel');
assert(!t.estimate({closed:100,open:200,direction:1,length:100,minimum:100,maximum:200},99,'CLOSED').valid);
console.log('Confirmed endpoint display: live 365/367 regression, both directions, wrapping, tolerance and strict unknown/bounds passed');

// An interrupted move remains STOPPED: explain proximity without claiming a
// verified endpoint or manufacturing a 0/100% progress reading.
const stoppedArc={closed:397,open:2704,direction:-1,length:1789,minimum:0,maximum:4095,circular:true};
const stopped=t.estimate(stoppedArc,412,'STOPPED');
assert.equal(stopped.reason,'Stopped near CLOSED');
assert.equal(stopped.detail,'15 counts beyond taught CLOSED endpoint');
assert.equal(t.label(stopped),'Stopped near CLOSED · 15 counts beyond taught CLOSED endpoint');
assert(!stopped.valid);assert(!('percent' in stopped));
for(const direction of [-1,1])for(const closed of [0,397,4095]){
 const length=1789,arc={closed,open:t.wrap(closed+direction*length),direction,length,minimum:0,maximum:4095,circular:true};
 for(const [endpoint,name,travel] of [[closed,'CLOSED',0],[arc.open,'OPEN',length]]){
  for(let delta=-25;delta<=25;delta++){
   const value=t.wrap(endpoint+delta),r=t.estimate(arc,value,'STOPPED');
   assert.equal(r.nearEndpoint,name);assert.equal(r.distance,Math.abs(delta));assert(!r.valid);assert(!('percent' in r));
   const beyond=name==='CLOSED'?direction*delta<0:direction*delta>0;
   assert.equal(r.detail,`${Math.abs(delta)} counts ${beyond?'beyond':'from'} taught ${name} endpoint`);
  }
  const outside=t.wrap(endpoint+direction*(name==='CLOSED'?-26:26));
  assert(!t.estimate(arc,outside,'STOPPED').nearEndpoint);assert(!t.estimate(arc,outside,'STOPPED').valid);
 }
}
for(const state of ['UNKNOWN','FAULT','OPENING','CLOSING'])assert(!t.estimate(stoppedArc,412,state).nearEndpoint);
for(const value of [null,NaN,-1,4096])assert(!t.estimate(stoppedArc,value,'STOPPED').nearEndpoint);
assert(!t.estimate({closed:397,open:200,direction:-1,length:197,minimum:190,maximum:400},412,'STOPPED').nearEndpoint);
// Exercise the actual dashboard helpers so the stopped state reaches the model
// and moving/fault/stale status never acquires a near-endpoint state label.
const app=fs.readFileSync('data/ui/app.js','utf8');
const cover={state:'STOPPED',calibrated:true,position:412,closed:397,open:2704,opening_direction:-1,travel_counts:1789,circular:true,saved_minimum:0,saved_maximum:4095};
let fresh=true;
Object.assign(c,{state:{cover},coverTravel:t,api:{freshCover:()=>fresh,freshPosition:()=>fresh},position:()=>cover.position});
vm.runInContext(app.slice(app.indexOf(' const displayedTravel='),app.indexOf(' function commonReason()')),c);
assert.equal(vm.runInContext('coverState()',c),'Stopped near CLOSED');
cover.moving=true;assert(!vm.runInContext('displayedTravel(state.cover,state.cover.position).nearEndpoint',c));
cover.moving=false;cover.state='FAULT';assert.equal(vm.runInContext('coverState()',c),'Fault');
fresh=false;assert.equal(vm.runInContext('coverState()',c),'Disconnected');
console.log('Stopped endpoint display: 397/412 regression, both endpoints/directions, 25/26-count bounds and no false endpoint confirmation passed');
