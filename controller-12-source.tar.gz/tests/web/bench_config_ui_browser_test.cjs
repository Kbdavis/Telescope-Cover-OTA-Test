/* Loopback fixture + simulated future beta.6 for notification/navigation testing.
   Never installs firmware, contacts hardware, or publishes a beta.6 artifact. */
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
(async()=>{
 const out=process.argv[2];assert(fs.statSync(out).isDirectory());
 const target=(await(await fetch('http://127.0.0.1:9234/json/list')).json()).find(t=>t.type==='page');assert(target);
 const ws=new WebSocket(target.webSocketDebuggerUrl),pending=new Map(),errors=[],requests=[];let id=0,script;
 await new Promise(r=>ws.addEventListener('open',r,{once:true}));
 const call=(method,params={})=>new Promise((resolve,reject)=>{const n=++id;pending.set(n,{resolve,reject});ws.send(JSON.stringify({id:n,method,params}));});
 ws.addEventListener('message',event=>{const m=JSON.parse(event.data);if(m.id){const p=pending.get(m.id);pending.delete(m.id);m.error?p.reject(Error(m.error.message)):p.resolve(m.result);}
  if(m.method==='Runtime.exceptionThrown')errors.push(m.params.exceptionDetails.text);
  if(m.method==='Network.requestWillBeSent')requests.push({url:m.params.request.url,method:m.params.request.method});
 });
 const ev=async expression=>{const r=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error(r.exceptionDetails.text);return r.result.value;};
 const wait=async expression=>{for(let n=0;n<180;n++){if(await ev(expression))return;await new Promise(r=>setTimeout(r,50));}throw Error('Timed out: '+expression);};
 const shot=async name=>{const r=await call('Page.captureScreenshot',{format:'png'});fs.writeFileSync(path.join(out,name),Buffer.from(r.data,'base64'));};
 try{
  await call('Runtime.enable');await call('Page.enable');await call('Network.enable');await call('Network.setCacheDisabled',{cacheDisabled:true});
  await call('Storage.clearDataForOrigin',{origin:'http://127.0.0.1:8099',storageTypes:'local_storage'});
  script=await call('Page.addScriptToEvaluateOnNewDocument',{source:`(()=>{
   const original=fetch.bind(window),clock=Date.now.bind(Date);window.fixtureOffset=0;window.fixtureMode='newer';window.releaseChecks=0;Date.now=()=>clock()+window.fixtureOffset;
   window.fetch=async(url,options)=>{
    if(!String(url).startsWith('https://'))return original(url,options);
    const api=String(url).startsWith('https://api.github.com/');if(api)window.releaseChecks++;
    const manifest='product=telescope-cover-ota-bench\\nprotocol=1\\nlayout=cover-4mb-v1\\nsettings=preserve-cover-app-v1\\nsource_build=5\\nsource_elf='+('a'.repeat(64))+'\\ntarget_build=6\\ntarget_elf='+('b'.repeat(64))+'\\nsize=1000000\\nsha256='+('c'.repeat(64))+'\\n';
    const empty=window.fixtureMode==='none';
    const body=api?(empty?[]:[{tag_name:'v0.1.0-beta.6',draft:false,prerelease:true,published_at:'2026-11-12T20:00:00Z'}]):{schema:'telescope-cover-bench-catalog/1',releases:empty?[]:[{build:6,tag:'v0.1.0-beta.6',application:'bench-6.bin',manifest,signature:'d'.repeat(128),notes:'SIMULATED future release for UI testing only.'}]};
    return new Response(JSON.stringify(body),{headers:{'Content-Type':'application/json'}});
   };
  })();`});
  await call('Emulation.setDeviceMetricsOverride',{width:1440,height:1000,deviceScaleFactor:1,mobile:false});
  await call('Page.navigate',{url:'http://127.0.0.1:8099/'});
  await wait("document.getElementById('header-update') && !document.getElementById('header-update').hidden");
  assert.equal(await ev("document.getElementById('automatic-check').checked"),true);
  assert.equal(await ev("document.getElementById('view-overview').hidden"),false);
  const box=await ev(`(()=>{const b=document.getElementById('header-update'),r=b.getBoundingClientRect(),brand=document.querySelector('.brand').getBoundingClientRect(),nav=document.querySelector('nav').getBoundingClientRect();return {text:b.textContent,center:r.x+r.width/2,width:r.width,height:r.height,bg:getComputedStyle(b).backgroundColor,between:r.x>=brand.right&&r.right<=nav.x};})()`);
  assert.equal(box.text,'Update available');assert(Math.abs(box.center-720)<2);assert(box.width<155&&box.height<40);assert(box.between);assert.equal(box.bg,'rgb(23, 111, 208)');
  await shot('header-update-desktop-fixture.png');
  for(const view of ['overview','calibration','configuration','manual']){
   await ev(`document.querySelector('nav [data-view-link="${view}"]').click()`);
   assert.equal(await ev("document.getElementById('header-update').hidden"),false);
   await ev("document.getElementById('header-update').click()");
   assert.equal(await ev("document.getElementById('view-configuration').hidden"),false);
   assert.equal(await ev('document.activeElement.id'),'cfg-updates');
   assert.equal(await ev("document.getElementById('cfg-jump').value"),'cfg-updates');
   assert.equal(await ev('location.hash'),'#configuration/firmware');
  }
  await shot('configuration-firmware-desktop-fixture.png');
  for(const width of [1024,390]){
   await call('Emulation.setDeviceMetricsOverride',{width,height:1000,deviceScaleFactor:1,mobile:width<700});
   for(const view of ['overview','calibration','configuration','manual']){
    await ev(`document.querySelector('nav [data-view-link="${view}"]').click()`);
    assert(await ev('document.documentElement.scrollWidth<=innerWidth+1'),`Overflow at ${width}/${view}`);
   }
  }
  await ev("document.getElementById('header-update').click()");await shot('configuration-firmware-mobile-fixture.png');
  await ev("document.getElementById('automatic-check').click()");
  assert.equal(await ev("localStorage.getItem('cover.bench.autoCheck.v1')"),'false');
  const previous=await ev('window.releaseChecks');await ev('window.fixtureOffset+=3600001');await new Promise(r=>setTimeout(r,1200));assert.equal(await ev('window.releaseChecks'),previous);
  await call('Page.reload');
  await wait("document.getElementById('discovery')?.textContent.startsWith('Automatic checks are off')");
  assert.equal(await ev('window.releaseChecks'),0);assert.equal(await ev("document.getElementById('automatic-check').checked"),false);
  assert.equal(await ev("document.getElementById('header-update').hidden"),true);
  await ev("document.getElementById('check').click()");await wait("!document.getElementById('header-update').hidden");
  assert.equal(await ev("document.getElementById('automatic-check').checked"),false);
  await ev("document.getElementById('automatic-check').click();window.fixtureOffset+=3600001");
  await wait('window.releaseChecks>=2');
  await wait("document.getElementById('check').textContent!=='Checking…'");
  await ev("window.fixtureMode='none';window.fixtureOffset+=61000");
  await wait("!document.getElementById('check').disabled");
  await ev("document.getElementById('check').click()");
  await wait("document.getElementById('available').textContent==='No compatible newer bench release found.'");
  assert.equal(await ev("document.getElementById('header-update').hidden"),true);
  assert.equal(await ev("!!document.querySelector('input[type=password]')"),false);
  assert.equal(requests.filter(r=>r.method!=='GET').length,0);assert.deepEqual(errors,[]);
  const result={passed:true,fixture_only:true,hardware_updated:false,simulated_future_release:6,tested:['small blue centered text badge','badge on all four views','click opens Configuration and focuses Firmware updates','automatic checking default on','preference persists off across reload','manual checks work while automatic disabled','reenabling resumes checks','no badge without a compatible update','1440/1024/390 layout','no key field or write requests'],badge:box};
  fs.writeFileSync(path.join(out,'ui-browser-result.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
 }finally{if(script)await call('Page.removeScriptToEvaluateOnNewDocument',{identifier:script.identifier});ws.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
