/* Complete candidate on spare; only GET controller requests. Remote future
   release metadata is simulated in this isolated browser. Never installs. */
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
(async()=>{
 const [base,out]=process.argv.slice(2);assert(base==='http://192.168.1.135');assert(fs.statSync(out).isDirectory());
 const real=await(await fetch(base+'/api/update/status')).json();assert(real.protocol==='browser-signed-v1');
 const target=(await(await fetch('http://127.0.0.1:9234/json/list')).json()).find(t=>t.type==='page');
 const ws=new WebSocket(target.webSocketDebuggerUrl),pending=new Map(),errors=[],requests=[];let id=0,script;
 await new Promise(r=>ws.addEventListener('open',r,{once:true}));
 const call=(method,params={})=>new Promise((resolve,reject)=>{const n=++id;pending.set(n,{resolve,reject});ws.send(JSON.stringify({id:n,method,params}));});
 ws.addEventListener('message',event=>{const m=JSON.parse(event.data);if(m.id){const p=pending.get(m.id);pending.delete(m.id);m.error?p.reject(Error(m.error.message)):p.resolve(m.result);}if(m.method==='Runtime.exceptionThrown')errors.push(m.params.exceptionDetails);if(m.method==='Network.requestWillBeSent')requests.push({url:m.params.request.url,method:m.params.request.method});});
 const ev=async expression=>{const r=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));return r.result.value;};
 const wait=async expression=>{for(let n=0;n<240;n++){if(await ev(expression))return;await new Promise(r=>setTimeout(r,50));}throw Error('Timed out: '+expression);};
 const shot=async name=>{const r=await call('Page.captureScreenshot',{format:'png'});fs.writeFileSync(path.join(out,name),Buffer.from(r.data,'base64'));};
 try{
  await call('Runtime.enable');await call('Page.enable');await call('Network.enable');await call('Network.setCacheDisabled',{cacheDisabled:true});
  await call('Storage.clearDataForOrigin',{origin:base,storageTypes:'local_storage'});
  const manifest='product=telescope-cover\nprotocol=browser-signed-v1\nlayout=cover-4mb-v1\nmotion=native-multiturn-v1\nstartup=inspect-only-v1\nsettings=preserve-cover-v1\nsource_build='+real.build+'\nsource_elf='+real.firmware_id+'\ntarget_build='+(real.build+1)+'\ntarget_elf='+'b'.repeat(64)+'\nsize=1200000\nsha256='+'c'.repeat(64)+'\n';
  const release={build:real.build+1,tag:'v0.1.0-beta.'+(real.build+1),application:'controller-'+(real.build+1)+'.bin',manifest,signature:'d'.repeat(128),notes:'SIMULATED future release; no binary or installation in this test.'};
  script=await call('Page.addScriptToEvaluateOnNewDocument',{source:`(()=>{const original=window.fetch.bind(window);window.fixtureClock=0;window.remoteChecks=0;const now=Date.now.bind(Date);Date.now=()=>now()+window.fixtureClock;window.fetch=async(url,options)=>{if(!String(url).startsWith('https://'))return original(url,options);window.remoteChecks++;return new Response(JSON.stringify(String(url).startsWith('https://api.github.com/')?[{tag_name:${JSON.stringify(release.tag)},draft:false,prerelease:true,published_at:'2026-11-12T20:00:00Z'}]:{schema:'telescope-cover-controller-catalog/1',releases:[${JSON.stringify(release)}]}),{headers:{'Content-Type':'application/json'}});};})();`});
  await call('Emulation.setDeviceMetricsOverride',{width:1440,height:1000,deviceScaleFactor:1,mobile:false});
  await call('Page.navigate',{url:base+'/?full-candidate-test='+Date.now()});
  await wait("document.getElementById('ota-available')?.textContent.includes('Update available')");
  // Dismiss only the DOM modal for layout inspection; no beta acceptance POST.
  await ev("if(document.getElementById('betaNotice').open)document.getElementById('betaNotice').close()");
  assert.equal(await ev("document.getElementById('ota-installed').textContent"),real.version);
  assert.equal(await ev("document.getElementById('ota-automatic-check').checked"),true);
  const box=await ev("(()=>{const el=document.getElementById('firmware-header-update'),r=el.getBoundingClientRect(),b=document.querySelector('.brand').getBoundingClientRect(),n=document.querySelector('nav').getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height,brand_right:b.right,nav_left:n.left,bg:getComputedStyle(el).backgroundColor,between:r.x>=b.right&&r.right<=n.left};})()");
  assert(box.width<160&&box.height<40&&box.between);assert(Math.abs(box.x+box.width/2-720)<2);assert.equal(box.bg,'rgb(22, 113, 218)');
  await shot('full-overview-update-badge.png');
  for(const view of ['overview','calibration','configuration','manual']){
   await ev(`document.getElementById('nav-${view}').click()`);assert.equal(await ev("document.getElementById('firmware-header-update').hidden"),false);
   await ev("document.getElementById('firmware-header-update').click()");assert.equal(await ev("document.getElementById('view-configuration').hidden"),false);assert.equal(await ev('document.activeElement.id'),'cfg-updates');
  }
  assert.equal(await ev("document.getElementById('ota-install').disabled"),true);await shot('full-configuration-updates.png');
  for(const width of [1024,390]){await call('Emulation.setDeviceMetricsOverride',{width,height:1000,deviceScaleFactor:1,mobile:width<700});for(const view of ['overview','calibration','configuration','manual']){await ev(`document.getElementById('nav-${view}').click()`);assert(await ev('document.documentElement.scrollWidth<=innerWidth+1'),`Overflow ${width}/${view}`);}}
  await ev("document.getElementById('firmware-header-update').click()");await shot('full-configuration-updates-mobile.png');
  await ev("document.getElementById('ota-automatic-check').click()");assert.equal(await ev("localStorage.getItem('cover.controller.autoCheck.v1')"),'false');const count=await ev('remoteChecks');await ev('fixtureClock+=3600001');await new Promise(r=>setTimeout(r,1100));assert.equal(await ev('remoteChecks'),count);
  await call('Page.reload');await wait("document.getElementById('ota-discovery')?.textContent.includes('Automatic checks are off')");assert.equal(await ev('remoteChecks'),0);
  assert.deepEqual(errors,[]);assert(requests.every(r=>r.method==='GET'));
  const after=await(await fetch(base+'/api/update/status')).json();assert.equal(after.boot_id,real.boot_id);assert.equal(after.phase,real.phase);assert.equal(after.firmware_id,real.firmware_id);
  const result={passed:true,hardware_page:true,release_metadata_simulated:true,installation_performed:false,firmware:real.version,elf:real.firmware_id,boot_unchanged:true,header:box,viewports:[1440,1024,390],automatic_default:true,automatic_preference_persists:true,requests:requests.length,controller_writes:0,errors};fs.writeFileSync(path.join(out,'full-browser-result.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
 }finally{if(script)await call('Page.removeScriptToEvaluateOnNewDocument',{identifier:script.identifier});ws.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
