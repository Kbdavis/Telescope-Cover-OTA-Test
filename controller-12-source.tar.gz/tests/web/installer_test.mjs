import test from 'node:test';
import assert from 'node:assert/strict';
import {InstallSession,sha256,validateManifest,validateAssets} from '../../installer/core.mjs';
import {createHash} from 'node:crypto';
async function fixture(layout='compatible'){
 const image=new Uint8Array(0x10100).fill(255),components=[];
 for(const [role,offset,size] of [['bootloader',4096,128],['partitions',32768,3072],['boot_selection',57344,128],['application',65536,256]]){
  const data=new Uint8Array(size).fill(role.charCodeAt(0));image.set(data,offset);components.push({role,offset,size,sha256:await sha256(data)});
 }
 const partition=image.slice(32768,32768+3072);
 const manifest={schema:1,name:'Telescope Cover',version:'0.1.0-beta.1',commit:'a'.repeat(40),profile:'web_control_multiturn_usb',chipFamily:'ESP32',flash_size:'4MB',flash_mode:'dio',flash_freq:'40m',flash_size_bytes:4194304,
  image:{path:'factory.bin',offset:0,size:image.length,sha256:await sha256(image),md5:createHash('md5').update(image).digest('hex')},
  partition:{path:'partitions.bin',offset:32768,size:3072,sha256:await sha256(partition)},components};
 const calls=[],table=layout==='blank-table'?new Uint8Array(3072).fill(255):layout==='unrecognized'?new Uint8Array(3072).fill(7):partition;
 const loader={chip:{CHIP_NAME:'ESP32'},detectFlashSize:async()=>{calls.push('size');return '4MB';},
  readFlash:async()=>{calls.push('read');return table;},eraseFlash:async()=>calls.push('erase'),
  writeFlash:async options=>{calls.push('write');assert.equal(options.eraseAll,false);assert.equal(options.flashMode,'keep');},
  flashMd5sum:async()=>{calls.push('verify');return manifest.image.md5;},after:async mode=>{assert.equal(mode,'hard_reset');calls.push('reset');}};
 return {manifest,image,partition,loader,calls,session:new InstallSession(loader,manifest,image,partition)};
}
for(const layout of ['compatible','blank-table','unrecognized'])test(`inspect ${layout}, confirm, write and verify`,async()=>{
 const f=await fixture(layout);assert.equal(await f.session.inspect(),layout);assert(!f.calls.includes('erase'));
 const result=await f.session.install({eraseConfirmed:true,boardConfirmed:true,mechanismDetached:true});
 assert.deepEqual(result,{verified:true,startupConfirmed:false});assert.deepEqual(f.calls,['size','read','size','read','erase','write','verify','reset']);
 await assert.rejects(()=>f.session.install({eraseConfirmed:true,boardConfirmed:true,mechanismDetached:true}));
});
test('cancel and missing confirmations never erase or write',async()=>{
 for(const missing of ['eraseConfirmed','boardConfirmed','mechanismDetached','cancel']){
  const f=await fixture();await f.session.inspect();const confirmations={eraseConfirmed:true,boardConfirmed:true,mechanismDetached:true};
  if(missing==='cancel')f.session.cancel();else confirmations[missing]=false;
  await assert.rejects(()=>f.session.install(confirmations));assert(!f.calls.includes('erase'));assert(!f.calls.includes('write'));
 }
});
test('failed/short read, wrong chip and wrong capacity reject before erase',async()=>{
 for(const kind of ['failed','short','chip','capacity']){
  const f=await fixture();if(kind==='failed')f.loader.readFlash=async()=>{throw Error('USB read failed');};
  if(kind==='short')f.loader.readFlash=async()=>new Uint8Array(0);
  if(kind==='chip')f.loader.chip.CHIP_NAME='ESP32-S3';if(kind==='capacity')f.loader.detectFlashSize=async()=>undefined;
  await assert.rejects(()=>f.session.inspect());assert(!f.calls.includes('erase'));
 }
});
test('changed table after confirmation blocks erase',async()=>{
 const f=await fixture();await f.session.inspect();f.loader.readFlash=async()=>new Uint8Array(3072).fill(1);
 await assert.rejects(()=>f.session.install({eraseConfirmed:true,boardConfirmed:true,mechanismDetached:true}),/changed/);assert(!f.calls.includes('erase'));
});
test('application-only, overlapping, test profiles and corrupt assets reject',async()=>{
 for(const kind of ['app-only','overlap','profile','factory-profile','probe-profile','image','partition']){
  const f=await fixture();if(kind==='app-only')f.manifest.components=f.manifest.components.slice(-1);
  if(kind==='overlap')f.manifest.components[0].size=0x9000;
  if(kind==='profile')f.manifest.profile='web_control_dev';
  if(kind==='factory-profile')f.manifest.profile='web_control_usb';
  if(kind==='probe-profile')f.manifest.profile='web_control_multiturn_startup';
  if(kind==='image')f.image[5000]^=1;if(kind==='partition')f.partition[0]^=1;
  await assert.rejects(()=>f.session.inspect());assert.equal(f.calls.length,0);
 }
});
test('write failure or readback mismatch never reports verified startup or resets',async()=>{
 for(const kind of ['write','digest']){
  const f=await fixture();await f.session.inspect();
  if(kind==='write')f.loader.writeFlash=async()=>{throw Error('Disconnected');};else f.loader.flashMd5sum=async()=>'0'.repeat(32);
  await assert.rejects(()=>f.session.install({eraseConfirmed:true,boardConfirmed:true,mechanismDetached:true}));
  assert.equal(f.session.phase,'failed');assert(!f.calls.includes('reset'));
 }
});
