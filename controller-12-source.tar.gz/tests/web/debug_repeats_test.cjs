/* Exercise the production log collector without a browser or hardware. */
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync('data/ui/transport.js','utf8');
let batch,clock=1000,httpStatus=200;const paths=[];
const window={addEventListener(){}};
// Expose private collectors only inside this VM; no test hooks in the shipped UI.
vm.runInNewContext(source.replace('  async function debugPoll(){','  window.testDebug={append:debugMessage,poll:debugPoll};\n  async function debugPoll(){'),{
 window,document:{addEventListener(){},dispatchEvent(){}},
 fetch:async path=>{paths.push(path);return {ok:httpStatus===200,status:httpStatus,text:async()=>JSON.stringify(batch)};},
 crypto:{getRandomValues:a=>{a[0]=1;return a;}},performance:{now:()=>clock},
 AbortSignal,URLSearchParams,Event,CustomEvent:class{},setTimeout(){},setInterval(){},Date,Map,Set
});
const {append,poll}=window.testDebug,state=window.coverAPI.state;
const reset=()=>{state.debugMessages.length=0;};
const last=()=>state.debugMessages.at(-1);
(async()=>{
 append('Browser','Connection failed','10:00:00','warn');
 const revision=state.debugRevision;
 for(let i=0;i<10000;i++)append('Browser','Connection failed','10:00:01','warn');
 assert.equal(state.debugMessages.length,1);assert.equal(last().count,10001);
 assert.equal(last().time,'10:00:00');assert.equal(last().lastTime,'10:00:01');
 assert.equal(state.debugRevision,revision+10000); // Repeat updates trigger rendering.
 append('Browser','Connection failed','10:00:02','error');
 append('Controller','Connection failed','Time unsynchronized · uptime 00:00:01','error');
 append('Controller','Different message','Time unsynchronized · uptime 00:00:02','error');
 append('Browser','Connection failed','10:00:03','warn');
 assert.equal(state.debugMessages.length,5);assert.equal(last().count,1);
 // Intervening info remains a boundary even if the viewer hides Info.
 append('Browser','Recovered','10:00:04','info');append('Browser','Connection failed','10:00:05','warn');
 assert.equal(state.debugMessages.filter(e=>e.level==='warn').length,3);
 reset();for(let i=0;i<1001;i++)append('Controller','Event '+i,String(i),'info');
 assert.equal(state.debugMessages.length,1000);assert.equal(state.debugMessages[0].message,'Event 1');
 append('Controller','Event 1000','1002','info');assert.equal(state.debugMessages.length,1000);assert.equal(last().count,2);
 reset();
 const entry=(sequence,message='Repeated',ms=sequence*1000)=>({sequence,message,ms,level:'warn'});
 batch={schema_version:1,available:true,boot_id:'boot-a',sequence_epoch:0,next_after:2,entries:[entry(1),entry(2)]};
 await poll();assert.equal(last().count,2);
 batch={...batch,next_after:3,entries:[entry(2),entry(3)]};await poll();
 assert.equal(last().count,3);assert.equal(last().time,'Time unsynchronized · uptime 00:00:01');assert.equal(last().lastTime,'Time unsynchronized · uptime 00:00:03');
 assert(paths.at(-1).includes('after=2')); // Duplicate sequences never inflate counts.
 batch={...batch,next_after:5,entries:[entry(5)]};await poll();
 assert.equal(state.debugMessages.length,3);assert.equal(last().count,1);
 assert(state.debugMessages[1].message.includes('overwritten'));
 batch={...batch,boot_id:'boot-b',cursor_reset:true,next_after:1,entries:[entry(1)]};await poll();
 assert.equal(last().count,1);assert(state.debugMessages.at(-2).message.includes('cursor reset'));
 // Check the actual row renderer, including safe literal message text.
 batch={...batch,entries:[{sequence:100,ms:4000,local_time:'2025-12-31T17:00:00-0700',message:'Synchronized event',level:'info'}],next_after:100};
 await poll();assert.equal(last().time,'2025-12-31T17:00:00-0700 · uptime 00:00:04');
 const app=fs.readFileSync('data/ui/app.js','utf8');
 const rowStart=app.indexOf('    const rows=entries.map('),rowEnd=app.indexOf('\n',rowStart);
 assert(rowStart>=0&&rowEnd>rowStart);
 const renderContext=vm.createContext({entries:[
  {source:'Controller',message:'<b>same</b>',level:'warn',time:'uptime 1s',lastTime:'uptime 2s',count:2},
  {source:'Browser',message:'offline',level:'error',time:'10:00',lastTime:'10:02',count:3},
  {source:'Browser',message:'recovered',level:'info',time:'10:03',lastTime:'10:03',count:1}
 ],receiptTime:(e,latest=false)=>({textContent:latest?e.lastTime:e.time}),document:{createTextNode:textContent=>({textContent}),createElement:()=>({textContent:'',append(...nodes){this.textContent+=nodes.map(n=>n.textContent).join('');}})}});
 vm.runInContext(app.slice(rowStart,rowEnd)+';globalThis.result=rows;',renderContext);
 assert.match(renderContext.result[0].textContent,/<b>same<\/b> — repeated 1 more time \(2 total; latest uptime 2s\)/);
 assert.match(renderContext.result[1].textContent,/repeated 2 more times \(3 total; latest 10:02\)/);
 assert(!renderContext.result[2].textContent.includes('repeated'));
 reset();
 const request=window.coverAPI.request;
 httpStatus=503;
 await assert.rejects(request('debug?after=100'),/HTTP 503/);
 const incident=last(),firstTime=incident.time;
 assert.match(incident.message,/Controller request failed \(debug\): HTTP 503/);
 clock+=4999;await assert.rejects(request('debug'),/HTTP 503/);
 assert.equal(incident.count,1); // Failures inside five seconds remain throttled.
 clock+=1;await assert.rejects(request('debug'),/HTTP 503/);
 assert.equal(incident.count,2);
 httpStatus=200;await request('debug');
 assert.equal(state.debugMessages.length,1);
 assert.match(incident.message,/HTTP 503\. Communication recovered at /);
 assert.equal(incident.time,firstTime);
 const recoveredRevision=state.debugRevision;
 await request('debug');assert.equal(state.debugRevision,recoveredRevision);
 httpStatus=503;await assert.rejects(request('debug'),/HTTP 503/);
 assert.equal(last(),incident);assert.equal(incident.count,3);
 assert(!incident.message.includes('recovered')); // A fresh outage is visible immediately.
 append('Controller','Intervening event');
 httpStatus=200;await request('debug');
 assert.equal(state.debugMessages.length,2);
 assert.match(incident.message,/Communication recovered/); // Recovery updates its own row.
 httpStatus=503;await assert.rejects(request('debug'),/HTTP 503/);
 assert.equal(state.debugMessages.length,3);assert.equal(last().count,1);
 httpStatus=200;await request('debug');
 httpStatus=504;await assert.rejects(request('debug'),/HTTP 504/);
 assert.equal(state.debugMessages.length,4); // Different causes do not coalesce.
 await assert.rejects(request('status'),/HTTP 504/);
 const statusIncident=last();
 httpStatus=200;await request('debug');
 assert(!statusIncident.message.includes('recovered'));
 await request('status');assert.match(statusIncident.message,/Communication recovered/);
 console.log('Debug repeats: flooding, timestamps, boundaries, retention, batches, cursor gaps and restart passed');
 console.log('Request incidents: combined recovery, five-second throttle, repeat cycles and endpoint isolation passed');
})().catch(error=>{console.error(error);process.exitCode=1;});
