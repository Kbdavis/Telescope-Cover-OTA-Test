const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync('data/ui/metrics.js','utf8');
function fixture(){
 let now=1000;const calls=[],events={},windowEvents={},panelEvents={};
 const panel={open:true,addEventListener:(name,fn)=>panelEvents[name]=fn};
 const state={view:'debug',network:{enable_debug_tab:true},session:{beta_accepted:true,setup_only:false,boot_id:'boot-1'},
  coverAt:1000,cover:{uptime_ms:5000,resources:{boot_id:'boot-1',available:false}}};
 const document={hidden:false,getElementById:()=>panel,addEventListener:(name,fn)=>events[name]=fn};
 const api={state,now:()=>now,freshCover:()=>now-state.coverAt<1500,emit:()=>{},request:(path,options)=>{
  assert(path.startsWith('diagnostics/metrics/')); // No actuator/settings requests.
  return new Promise((resolve,reject)=>calls.push({path,options,resolve:value=>resolve(JSON.stringify(value)),reject}));
 }};
 const window={coverAPI:api,addEventListener:(name,fn)=>windowEvents[name]=fn};
 vm.runInNewContext(source,{window,document});
 return {api,state,panel,calls,document,events,windowEvents,
  advance:ms=>{now+=ms;state.coverAt=now;},toggle:open=>{panel.open=open;panelEvents.toggle();}};
}
const settle=async()=>{for(let n=0;n<8;n++)await Promise.resolve();};
(async()=>{
 const f=fixture();assert(!f.panel.open);f.api.metrics.poll();assert.equal(f.calls.length,0);
 f.toggle(true);assert.equal(f.calls.length,1);assert.match(f.calls[0].path,/subscribe$/);
 assert.equal(f.calls[0].options.body.observed_uptime_ms,5000);assert(!f.api.metrics.hasSnapshot());
 f.toggle(false);assert.match(f.calls[1].path,/unsubscribe$/);assert(!f.api.metrics.isOpen());
 f.toggle(true);assert.equal(f.calls[2].options.body.generation,2);
 f.calls[0].resolve({accepted:true});await settle();assert.match(f.calls[3].path,/unsubscribe$/);
 assert.equal(f.calls[3].options.body.generation,1);assert(f.api.metrics.isOpen());
 f.calls[2].resolve({accepted:true});await settle();
 f.state.cover.resources.available=true;f.advance(1);assert(f.api.metrics.hasSnapshot());
 f.advance(1999);f.api.metrics.poll();assert.match(f.calls[4].path,/renew$/);
 f.api.metrics.poll();assert.equal(f.calls.length,5); // Only one renewal in flight.
 f.calls[4].resolve({accepted:true});await settle();
 f.state.view='overview';f.api.metrics.sync();assert(!f.panel.open);assert.match(f.calls[5].path,/unsubscribe$/);
 f.advance(10000);f.api.metrics.poll();assert.equal(f.calls.length,6);
 f.state.view='debug';f.api.metrics.sync();assert(!f.panel.open); // No automatic reopen.
 f.toggle(true);f.calls[6].resolve({accepted:true});await settle();
 f.document.hidden=true;f.events.visibilitychange();assert(!f.panel.open);
 f.document.hidden=false;f.api.metrics.poll();assert(!f.panel.open);
 f.toggle(true);f.calls[8].resolve({accepted:true});await settle();
 f.state.network.enable_debug_tab=false;f.api.metrics.sync();assert(!f.panel.open);
 const g=fixture();g.toggle(true);g.calls[0].resolve({accepted:true});await settle();
 g.advance(5000);g.api.metrics.poll();assert(!g.panel.open); // Local lease deadline prevents resurrection.
 const h=fixture();h.toggle(true);h.calls[0].resolve({accepted:true});await settle();
 h.advance(2000);h.api.metrics.poll();h.calls[1].reject(Error('expired'));await settle();assert(!h.panel.open);
 h.api.metrics.poll();assert.equal(h.calls.length,3); // Best-effort unsubscribe, no resubscribe.
 const b=fixture();b.toggle(true);b.events.controllerrestart();assert(!b.panel.open);
 b.calls[0].resolve({accepted:true});await settle();assert(!b.panel.open);
 const p=fixture();p.toggle(true);p.windowEvents.pagehide();assert(!p.panel.open);
 const s=fixture();s.state.network.enable_debug_tab=false;s.state.debugSession=true;
 s.toggle(true);assert.equal(s.calls.length,1);s.calls[0].resolve({accepted:true});await settle();
 assert(s.api.metrics.isOpen());s.state.debugSession=false;s.api.metrics.sync();
 assert(!s.panel.open);assert.match(s.calls[1].path,/unsubscribe$/);
 for(const x of [f,g,h,b,p,s])for(const call of x.calls)assert(!/stop|cancel|settings/.test(call.path));
 console.log('Metrics browser lifecycle: default OFF, racing starts, renewals, expiry, navigation, visibility and reboot passed');
})().catch(error=>{console.error(error);process.exitCode=1;});
