/* Real spare assets with deliberate main-script network failures. GET only. */
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
(async()=>{
 const [base,out]=process.argv.slice(2);assert.equal(base,'http://192.168.1.135');
 const before=await(await fetch(base+'/api/update/status')).json();
 const target=(await(await fetch('http://127.0.0.1:9234/json/list')).json()).find(t=>t.type==='page');
 const ws=new WebSocket(target.webSocketDebuggerUrl),pending=new Map(),requests=[],errors=[];let id=0,failures=1,attempts=0;
 await new Promise(r=>ws.addEventListener('open',r,{once:true}));
 const call=(method,params={})=>new Promise((resolve,reject)=>{const n=++id;pending.set(n,{resolve,reject});ws.send(JSON.stringify({id:n,method,params}));});
 ws.addEventListener('message',async event=>{const m=JSON.parse(event.data);if(m.id){const p=pending.get(m.id);pending.delete(m.id);m.error?p.reject(Error(m.error.message)):p.resolve(m.result);}if(m.method==='Fetch.requestPaused'){++attempts;await call(attempts<=failures?'Fetch.failRequest':'Fetch.continueRequest',attempts<=failures?{requestId:m.params.requestId,errorReason:'ConnectionReset'}:{requestId:m.params.requestId});}if(m.method==='Network.requestWillBeSent')requests.push({url:m.params.request.url,method:m.params.request.method});if(m.method==='Runtime.exceptionThrown')errors.push(m.params.exceptionDetails);});
 const ev=async expression=>{const r=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));return r.result.value;};
 const wait=async expression=>{for(let n=0;n<240;n++){if(await ev(expression))return;await new Promise(r=>setTimeout(r,50));}throw Error('Timed out: '+expression);};
 try{
  await call('Runtime.enable');await call('Page.enable');await call('Network.enable');await call('Network.setCacheDisabled',{cacheDisabled:true});await call('Fetch.enable',{patterns:[{urlPattern:base+'/ui/app.js',requestStage:'Request'}]});
  await call('Page.navigate',{url:base+'/?one-script-failure='+Date.now()});await wait('!!window.coverAPI?.state.session?.browser_update');assert.equal(attempts,2);assert.equal(await ev("!!document.getElementById('page-load-error')"),false);
  failures=3;attempts=0;await call('Page.navigate',{url:base+'/?three-script-failures='+Date.now()});await wait("!!document.getElementById('page-load-error')");await new Promise(r=>setTimeout(r,700));assert.equal(attempts,3);assert.equal(await ev('!!window.coverAPI'),false);
  const shot=await call('Page.captureScreenshot',{format:'png'});fs.writeFileSync(path.join(out,'bounded-script-load-failure.png'),Buffer.from(shot.data,'base64'));
  await call('Fetch.disable');await call('Page.navigate',{url:base+'/?recovered='+Date.now()});await wait('!!window.coverAPI?.state.session?.browser_update');
  assert(requests.every(r=>r.method==='GET'));assert.deepEqual(errors,[]);
  const after=await(await fetch(base+'/api/update/status')).json();assert.equal(after.boot_id,before.boot_id);assert.equal(after.firmware_id,before.firmware_id);assert.equal(after.phase,before.phase);
  const result={passed:true,real_spare_assets:true,network_failures_deliberate:true,recovers_after_one_script_failure:true,maximum_attempts:3,visible_error_after_three_failures:true,partially_executed_app_retried:false,controller_writes:0,boot_unchanged:true,errors};fs.writeFileSync(path.join(out,'page-load-recovery-result.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
 }finally{await call('Fetch.disable');ws.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
