const {test}=require('node:test');
const assert=require('node:assert/strict');
const crypto=require('node:crypto');
const fs=require('node:fs');
const path=require('node:path');
const signer=require('../../tools/release_signing.cjs');
const fixture=JSON.parse(fs.readFileSync(path.join(__dirname,'../fixtures/release_metadata.json'),'utf8'));
// Ephemeral in-memory keys only. No key file, provisioning or deployed trust root.
const keys=crypto.generateKeyPairSync('ec',{namedCurve:'prime256v1'});
const trust=new Map([['test-only',keys.publicKey]]);
const text=JSON.stringify(fixture.release);
test('signature binds exact manifest bytes and all compatibility fields',()=>{
 const envelope=signer.signPreview(text,'test-only',keys.privateKey);
 const verified=signer.verifyPreview(envelope,trust);
 assert.equal(verified.signature_valid,true);assert.equal(verified.installable,false);
 assert.deepEqual(JSON.parse(JSON.stringify(verified.release)),fixture.release);
 for(const [field,value] of [['commit','a'.repeat(40)],['qualification','withdrawn'],['version','9.0.0']]){
  const changed=JSON.parse(text);changed[field]=value;
  assert.throws(()=>signer.verifyPreview({...envelope,payload:Buffer.from(JSON.stringify(changed)).toString('base64')},trust),/Signature/);
 }
 const whitespace={...envelope,payload:Buffer.from(text+'\n').toString('base64')};
 assert.throws(()=>signer.verifyPreview(whitespace,trust),/Signature/);
});
test('trust is external; unknown/revoked keys and key substitution fail',()=>{
 const envelope=signer.signPreview(text,'test-only',keys.privateKey);
 assert.throws(()=>signer.verifyPreview(envelope,new Map()),/Unknown/);
 assert.throws(()=>signer.verifyPreview(envelope,new Map([['test-only',keys.publicKey],['alias',keys.publicKey]])),/alias/);
 assert.throws(()=>signer.verifyPreview(envelope,trust,new Set(['test-only'])),/revoked/);
 const other=crypto.generateKeyPairSync('ec',{namedCurve:'prime256v1'});
 assert.throws(()=>signer.verifyPreview(envelope,new Map([['test-only',other.publicKey]])),/Signature/);
 assert.throws(()=>signer.verifyPreview({...envelope,public_key:keys.publicKey.export({type:'spki',format:'pem'})},trust),/envelope/);
});
test('algorithm/curve/encoding confusion and malformed envelopes fail closed',()=>{
 const envelope=signer.signPreview(text,'test-only',keys.privateKey);
 for(const change of [{schema:'future'},{algorithm:'none'},{key_id:'test-only\n'},
  {signature:'A'.repeat(88)},{signature:envelope.signature+'\n'},{payload:envelope.payload+'\n'},
  {signature:Buffer.alloc(63).toString('base64')},{payload:Buffer.alloc(signer.MAX_PAYLOAD+1).toString('base64')}]){
  assert.throws(()=>signer.verifyPreview({...envelope,...change},trust));
 }
 const otherCurve=crypto.generateKeyPairSync('ec',{namedCurve:'secp384r1'});
 assert.throws(()=>signer.signPreview(text,'test-only',otherCurve.privateKey),/P-256/);
 assert.throws(()=>signer.verifyPreview(envelope,new Map([['test-only',keys.privateKey]])),/public key/);
 assert.throws(()=>signer.signPreview(text,'test-only',keys.publicKey),/private key/);
});
test('signing validates metadata and leaves production key handling absent',()=>{
 assert.throws(()=>signer.signPreview('{bad','test-only',keys.privateKey));
 assert.throws(()=>signer.signPreview('{"schema":1,"schema":2}','test-only',keys.privateKey));
 assert.throws(()=>signer.signPreview(text+' '.repeat(4096),'test-only',keys.privateKey),/limit/);
 const envelope=signer.signPreview(text,'test-only',keys.privateKey);
 assert(JSON.stringify(envelope).length<=8192,'Envelope fits the proposed bounded metadata staging ceiling');
 assert.equal(JSON.stringify(envelope).includes('PRIVATE KEY'),false);
});
