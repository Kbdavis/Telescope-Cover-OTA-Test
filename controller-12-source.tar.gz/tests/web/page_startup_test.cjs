const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
function loader(){
 const scripts=[],messages=[],timers=[],window={};
 const document={createElement:tag=>({tag,setAttribute(){},remove(){this.removed=true;}}),getElementById:id=>{assert.equal(id,'mainContent');return {prepend:n=>messages.push(n)};},head:{append:s=>scripts.push(s)}};
 vm.runInNewContext(fs.readFileSync('data/ui/startup.js','utf8'),{document,window,setTimeout:(fn,delay)=>timers.push({fn,delay})});return {scripts,messages,timers,window};
}
test('main script network failure retries once; successful download starts only once',()=>{
 const p=loader();assert.equal(p.scripts.length,1);assert.equal(p.scripts[0].src,'/ui/app.js');p.scripts[0].onerror();p.scripts[0].onerror();assert.equal(p.timers.length,1);assert.equal(p.timers[0].delay,500);p.timers.shift().fn();assert.equal(p.scripts.length,2);
 p.window.coverAPI={};p.scripts[1].onload();p.scripts[1].onerror();assert.equal(p.timers.length,0);assert.equal(p.messages.length,0);
});
test('three download failures stop with a visible error instead of an infinite reload',()=>{
 const p=loader();for(let i=0;i<3;++i){p.scripts[i].onerror();p.timers.shift().fn();}assert.equal(p.scripts.length,3);assert.equal(p.timers.length,0);assert.equal(p.messages.length,1);assert.match(p.messages[0].textContent,/reload this page/);
});
test('partially executed application is never retried',()=>{
 const p=loader();p.scripts[0].onload();assert.equal(p.messages.length,1);assert.equal(p.scripts.length,1);assert.equal(p.timers.length,0);
});
