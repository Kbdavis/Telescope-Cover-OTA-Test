/* Live UI fixture on 8094; isolated Chrome CDP on 9226. No hardware calls. */
const assert=require('node:assert/strict'),fs=require('node:fs');
const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
(async()=>{
 const targets=await(await fetch('http://127.0.0.1:9226/json/list')).json();
 const ws=new WebSocket(targets.find(target=>target.type==='page').webSocketDebuggerUrl),pending=new Map(),errors=[];let next=0;
 await new Promise(resolve=>ws.addEventListener('open',resolve,{once:true}));
 ws.addEventListener('message',event=>{const m=JSON.parse(event.data);if(m.id){const p=pending.get(m.id);if(!p)return;clearTimeout(p.timer);pending.delete(m.id);m.error?p.reject(Error(m.error.message)):p.resolve(m.result);}if(m.method==='Runtime.exceptionThrown')errors.push(m.params.exceptionDetails);if(m.method==='Page.javascriptDialogOpening')call('Page.handleJavaScriptDialog',{accept:true}).catch(error=>errors.push(error.message));});
 const call=(method,params={})=>new Promise((resolve,reject)=>{const id=++next,timer=setTimeout(()=>{pending.delete(id);reject(Error('CDP timeout: '+method));},15000);pending.set(id,{resolve,reject,timer});ws.send(JSON.stringify({id,method,params}));});
 const ev=async expression=>{const r=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true,userGesture:true});if(r.exceptionDetails)throw Error(r.exceptionDetails.exception?.description||r.exceptionDetails.text);return r.result.value;};
 const wait=async expression=>{for(let n=0;n<120;n++){if(await ev(expression))return;await delay(100);}throw Error('Timeout: '+expression);};
 const click=id=>ev(`document.getElementById('${id}').click()`);
 const patch=async body=>{await fetch('http://127.0.0.1:8094/test/patch',{method:'POST',body:JSON.stringify(body)});await ev(body.controls?.drop_status?'coverAPI.cover().catch(()=>{})':'coverAPI.cover()');};
 const reload=async()=>{await ev('window.__beforeReload=true');await call('Page.reload',{ignoreCache:true});await wait("!window.__beforeReload&&window.coverAPI?.state.network&&coverAPI.state.cover&&coverAPI.state.session");};
 const missing={state:'UNKNOWN',fault:'Servo not responding; check servo power and bus cable',ready:false,calibrated:false,calibration_only:false,position:null,torque:null,settings_offline_allowed:true};
 try{
  await call('Runtime.enable');await call('Page.enable');await call('Emulation.setFocusEmulationEnabled',{enabled:true});
  await call('Page.navigate',{url:'about:blank'});await wait("location.href==='about:blank'&&!window.coverAPI");
  await fetch('http://127.0.0.1:8094/test/reset',{method:'POST'});
  await fetch('http://127.0.0.1:8094/test/patch',{method:'POST',body:JSON.stringify({cover:missing,controls:{beta:true}})});
  await call('Page.navigate',{url:'http://127.0.0.1:8094/#overview'});
  await wait('window.coverAPI?.state.network&&coverAPI.state.cover&&coverAPI.state.session');
  await ev("sessionStorage.removeItem('cover.servoSetupNotice.v1');sessionStorage.removeItem('cover.debugSession.v1')");await reload();
  assert.equal(await ev("document.getElementById('servoSetupNotice').hidden"),false);
  assert.equal(await ev("document.getElementById('recoveryControls').hidden"),true);
  assert.equal(await ev("document.getElementById('ov-health').textContent"),'Controller setup');
  assert.equal(await ev("document.getElementById('ov-open').disabled&&document.getElementById('ov-close').disabled"),true);
  for(const width of [1440,390]){
   await call('Emulation.setDeviceMetricsOverride',{width,height:1000,deviceScaleFactor:1,mobile:width<500});
   assert.equal(await ev('document.documentElement.scrollWidth<=innerWidth'),true);
   const shot=await call('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});fs.writeFileSync('/tmp/servo-setup-'+width+'.png',Buffer.from(shot.data,'base64'));
  }
  await click('dismissServoNotice');await click('nav-configuration');
  assert.equal(await ev("document.getElementById('cfg-lock-reason').hidden"),true);
  assert.equal(await ev("document.getElementById('recoveryControls').hidden"),true);
  await click('cfg-debug-session');await wait("coverAPI.state.view==='debug'");
  for(let n=0;n<4;n++)await ev('coverAPI.cover()');
  assert.equal(await ev("document.getElementById('servoSetupNotice').hidden"),true);
  await reload();assert.equal(await ev("document.getElementById('servoSetupNotice').hidden"),true);
  assert.equal(await ev('coverAPI.state.network.enable_debug_tab'),false);
  assert.deepEqual(await(await fetch('http://127.0.0.1:8094/test/events')).json(),[]);
  // Missing servo feedback cannot prevent an explicit worker recheck.
  await click('nav-calibration');assert.equal(await ev("document.getElementById('recoveryControls').hidden"),false);
  assert.equal(await ev("document.getElementById('recover').textContent"),'Recheck servo');
  assert.equal(await ev("document.getElementById('recover').disabled"),true);
  await click('inspected');assert.equal(await ev("document.getElementById('recover').disabled"),false);
  for(const field of ['moving','holding']){
   await patch({cover:{[field]:true}});assert.equal(await ev("document.getElementById('recover').disabled"),true);
   await patch({cover:{[field]:false}});
  }
  await patch({cover:{maintenance:{owner:'network',locked:true}}});assert.equal(await ev("document.getElementById('recover').disabled"),true);
  await patch({cover:{maintenance:{owner:'none',locked:false}}});
  await patch({scope:{arm_locked:true}});await ev('coverAPI.scope()');assert.equal(await ev("document.getElementById('recover').disabled"),true);
  await patch({scope:{arm_locked:false}});await ev('coverAPI.scope()');
  await patch({controls:{drop_status:true}});await delay(1800);await ev('calibrationUI.render()');
  assert.equal(await ev("document.getElementById('recover').disabled"),true);
  await patch({controls:{drop_status:false}});assert.equal(await ev("document.getElementById('recover').disabled"),false);
  await click('recover');await wait('!coverAPI.state.busy&&coverAPI.state.cover.command_id>0');
  assert.equal(await ev('coverAPI.state.cover.command_ok'),false);
  assert.equal(await ev('coverAPI.state.cover.ready'),false);
  assert.equal(await ev("document.getElementById('inspected').checked"),false);
  assert.equal(await ev("document.getElementById('servoSetupNotice').hidden"),true);
  // Reconnected, uncalibrated servo: successful check permits calibration, never motion.
  await patch({cover:{position:600,torque:false,settings_offline_allowed:false}});
  await click('inspected');await click('recover');await wait('!coverAPI.state.busy&&coverAPI.state.cover.calibration_only');
  assert.equal(await ev('coverAPI.state.cover.command_ok'),true);
  assert.equal(await ev('coverAPI.state.cover.ready'),false);
  assert.equal(await ev("document.getElementById('recoveryControls').hidden"),true);
  // Internal configuration failures take priority over the default travel range.
  for(const fault of ['Invalid ST3215 configuration; inspect USB diagnostics','ST3215 configuration mismatch; phase=12 (need 0); offset=85 (need 0)']){
   await patch({cover:{fault,state:'UNKNOWN',ready:false,calibration_only:false,calibrated:false,dirty:false,position:2420,torque:false,minimum:2015,maximum:2075,draft_minimum:2015,draft_maximum:2075}});
   assert.match(await ev("document.getElementById('issueText').textContent"),/Application calibration cannot fix this/);
   assert.doesNotMatch(await ev("document.getElementById('issueText').textContent"),/begin supervised teaching/);
   await ev("calibrationUI.navigate(0)");
   assert.equal(await ev("document.getElementById('minimum')"),null);
   assert.equal(await ev("document.getElementById('prepareNext').disabled"),true);
   await click('inspected');await click('recover');await wait('!coverAPI.state.busy');
   assert.equal(await ev('coverAPI.state.cover.command_ok'),false);
   assert.equal(await ev('coverAPI.state.cover.calibration_only'),false);
   assert.equal(await ev('coverAPI.state.cover.fault'),fault);
  }
  // Valid saved-range recovery remains available; unrelated startup errors do not suggest it.
  await patch({cover:{fault:'Position outside saved travel limits; inspect calibration',calibrated:true}});
  assert.match(await ev("document.getElementById('issueText').textContent"),/begin supervised teaching/);
  await patch({cover:{fault:'Cannot read ST3215 configuration; check servo communication'}});
  assert.doesNotMatch(await ev("document.getElementById('issueText').textContent"),/begin supervised teaching/);
  await patch({cover:{fault:'Position outside saved travel limits; inspect calibration',age_ms:5000}});
  assert.doesNotMatch(await ev("document.getElementById('issueText').textContent"),/begin supervised teaching/);
  await patch({cover:{age_ms:0}});
  // A distinct disconnection gets one new notice; a real motion fault stays visible.
  await patch({cover:missing});await click('nav-overview');
  assert.equal(await ev("document.getElementById('servoSetupNotice').hidden"),false);
  await click('dismissServoNotice');
  await patch({cover:{state:'FAULT',fault:'Repeated position read failures'}});
  assert.equal(await ev("document.getElementById('servoSetupNotice').hidden"),true);
  assert.equal(await ev("document.getElementById('recoveryControls').hidden"),false);
  assert.equal(await ev("document.getElementById('recover').textContent"),'Clear fault');
  assert.equal(await ev("document.getElementById('inspected').checked"),false);
  await click('inspected');assert.equal(await ev("document.getElementById('recover').disabled"),false);
  const events=await(await fetch('http://127.0.0.1:8094/test/events')).json();assert.deepEqual(events.map(event=>event.path),['recover','recover','recover','recover']);
  // Endpoint timeouts explain where to adjust timing without clearing the fault or issuing commands.
  for(const target of [2424,3464]){
   await patch({cover:{state:'FAULT',fault:'Movement timeout',calibrated:true,position:2964,torque:false,closed:2424,open:3464,target}});
   assert.equal(await ev("document.getElementById('endpointTimeoutNotice').hidden"),false);
   assert.match(await ev("document.getElementById('endpointTimeoutNotice').textContent"),/Calibration → Step 4.*Movement settings/);
   await click('nav-calibration');
   assert.equal(await ev("document.getElementById('endpointTimeoutNotice').hidden"),false);
   assert.equal(await ev("document.getElementById('issueTitle').textContent"),'Movement timeout');
   await click('nav-overview');
   assert.equal(await ev('coverAPI.state.cover.state'),'FAULT');
   assert.equal(await ev("document.getElementById('ov-open').disabled&&document.getElementById('ov-close').disabled"),true);
  }
  await reload();assert.equal(await ev("document.getElementById('endpointTimeoutNotice').hidden"),false);
  for(const cover of [{target:3000},{target:2424,fault:'Repeated position read failure'},{fault:'',state:'STOPPED',ready:true}]){
   await patch({cover});assert.equal(await ev("document.getElementById('endpointTimeoutNotice').hidden"),true);
  }
  assert.deepEqual(await(await fetch('http://127.0.0.1:8094/test/events')).json(),events);
  await ev('calibrationUI.loadFields()'); // Discard fixture-only edits before leaving the page.
  assert.deepEqual(errors,[]);console.log('Servo setup: notices, guarded rechecks, configuration mismatch guidance and saved-range recovery passed');
  await call('Page.navigate',{url:'about:blank'});
 }finally{ws.close();}
})().catch(error=>{console.error(error);process.exitCode=1;});
