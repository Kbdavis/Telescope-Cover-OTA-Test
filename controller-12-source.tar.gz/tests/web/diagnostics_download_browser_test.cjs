/* Local fixture on 8091 and isolated Chrome CDP on 9226; no controller access. */
const assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const base=process.env.FIXTURE_URL||'http://127.0.0.1:8091',cdp=process.env.CDP_URL||'http://127.0.0.1:9226';
const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
(async()=>{
 const target=await(await fetch(cdp+'/json/new?about:blank',{method:'PUT'})).json();
 const ws=new WebSocket(target.webSocketDebuggerUrl),pending=new Map(),errors=[];let id=0;
 await new Promise((resolve,reject)=>{ws.addEventListener('open',resolve,{once:true});ws.addEventListener('error',reject,{once:true});});
 const call=(method,params={})=>new Promise((resolve,reject)=>{const n=++id;pending.set(n,{resolve,reject});ws.send(JSON.stringify({id:n,method,params}));});
 ws.addEventListener('message',event=>{const m=JSON.parse(event.data);if(m.id){const p=pending.get(m.id);pending.delete(m.id);m.error?p.reject(Error(m.error.message)):p.resolve(m.result);}if(m.method==='Runtime.exceptionThrown')errors.push(m.params.exceptionDetails);});
 const ev=async expression=>{const r=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true,userGesture:true});if(r.exceptionDetails)throw Error(r.exceptionDetails.exception?.description||r.exceptionDetails.text);return r.result.value;};
 const wait=async expression=>{for(let n=0;n<150;n++){if(await ev(expression))return;await delay(100);}throw Error('Timed out: '+expression);};
 const directory=fs.mkdtempSync(path.join(os.tmpdir(),'cover-diagnostics-browser-'));
 try{
  await fetch(base+'/test/reset',{method:'POST'});
  await call('Runtime.enable');await call('Page.enable');
  await call('Emulation.setFocusEmulationEnabled',{enabled:true});
  await call('Page.setDownloadBehavior',{behavior:'allow',downloadPath:directory});
  await call('Page.navigate',{url:base+'/#configuration'});
  await wait('window.coverAPI?.diagnostics&&coverAPI.state.cover&&coverAPI.state.network&&coverAPI.state.scope');
  // Read-only download works before beta acceptance and without enabling Debug.
  assert.equal(await ev('coverAPI.state.session.beta_accepted'),false);
  const before=await ev('({boot:coverAPI.state.session.boot_id,debug:coverAPI.state.network.enable_debug_tab})');
  await ev("document.getElementById('cfg-password').value='unsaved-form-password';coverAPI.state.debugMessages.push({message:'password=browser-private token=private-token'})");
  await ev("document.getElementById('cfg-download-diagnostics').click()");
  await wait("!coverAPI.diagnostics.busy()&&document.getElementById('cfg-download-message').textContent.includes('download started')");
  let files=[];for(let n=0;n<50;n++){files=fs.readdirSync(directory).filter(name=>name.endsWith('.json'));if(files.length)break;await delay(100);}
  assert.equal(files.length,1);const raw=fs.readFileSync(path.join(directory,files[0]),'utf8'),report=JSON.parse(raw);
  assert.equal(report.kind,'telescope-cover-diagnostics');assert.equal(report.consistency,'same_boot');assert.equal(report.partial,false);
  assert.equal(report.sections.controller.data.state,'CLOSED');assert(report.sections.controller.data.saved_profile);
  assert(report.sections.configuration.data.mdns_name);assert.equal(report.sections.controller_events.data.pages.length,1);
  assert(report.sections.servo_evidence.data.available);assert(report.sections.motion_trace.data.samples);assert(report.sections.heartbeat_trace.data.http);
  for(const secret of ['unsaved-form-password','browser-private','private-token'])assert(!raw.includes(secret));
  assert.equal(await ev("document.getElementById('cfg-password').value"),'unsaved-form-password');
  assert.deepEqual(await ev('({boot:coverAPI.state.session.boot_id,debug:coverAPI.state.network.enable_debug_tab})'),before);
  assert.deepEqual(await(await fetch(base+'/test/events')).json(),[],'Download sends no commands or metrics subscriptions');
  // Simulate losing the API while leaving previously observed state in the tab.
  await ev("window.__originalRequest=coverAPI.request;coverAPI.request=async()=>{throw Error('Offline fixture')}");
  const offline=await ev('coverAPI.diagnostics.collect()');assert(offline.partial);assert(offline.sections.controller.cached);
  assert.equal(offline.sections.controller.data.state,'CLOSED');await ev('coverAPI.request=window.__originalRequest');
  assert.deepEqual(errors,[]);
  console.log('Diagnostics browser: actual JSON download, Configuration placement, private form exclusion, offline cache and no controller writes passed');
 }finally{
  await fetch(cdp+'/json/close/'+target.id).catch(()=>{});ws.close();fs.rmSync(directory,{recursive:true,force:true});
 }
})().catch(error=>{console.error(error);process.exitCode=1;});
