/* Real public GitHub/Pages release discovery and download on the spare. GET only.
   Never confirms installation, starts a transaction, writes flash or reboots. */
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
(async()=>{
 const [base,out]=process.argv.slice(2);assert.equal(base,'http://192.168.1.135');assert(fs.statSync(out).isDirectory());
 const expected=JSON.parse(fs.readFileSync(path.join(out,'frozen/release.json')));
 const get=async()=>{const r=await fetch(base+'/api/update/status',{signal:AbortSignal.timeout(5000)});assert(r.ok);return r.json();};
 const before=await get();assert.equal(before.build,9);assert.equal(before.startup,'accepted');assert.equal(before.active,false);
 const target=(await(await fetch('http://127.0.0.1:9234/json/list')).json()).find(t=>t.type==='page');assert(target);
 const ws=new WebSocket(target.webSocketDebuggerUrl),pending=new Map(),errors=[],requests=[],responses=[];let id=0;
 await new Promise(r=>ws.addEventListener('open',r,{once:true}));
 const call=(method,params={})=>new Promise((resolve,reject)=>{const n=++id;pending.set(n,{resolve,reject});ws.send(JSON.stringify({id:n,method,params}));});
 ws.addEventListener('message',event=>{const m=JSON.parse(event.data);if(m.id){const p=pending.get(m.id);pending.delete(m.id);m.error?p.reject(Error(m.error.message)):p.resolve(m.result);}if(m.method==='Runtime.exceptionThrown')errors.push(m.params.exceptionDetails);if(m.method==='Network.requestWillBeSent')requests.push({url:m.params.request.url,method:m.params.request.method});if(m.method==='Network.responseReceived')responses.push({url:m.params.response.url,status:m.params.response.status});});
 const ev=async expression=>{const r=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));return r.result.value;};
 const wait=async expression=>{for(let n=0;n<400;n++){if(await ev(expression))return;await new Promise(r=>setTimeout(r,50));}throw Error('Timed out: '+expression);};
 const shot=async name=>{const r=await call('Page.captureScreenshot',{format:'png'});fs.writeFileSync(path.join(out,name),Buffer.from(r.data,'base64'));};
 try{
  await call('Runtime.enable');await call('Page.enable');await call('Network.enable');await call('Network.setCacheDisabled',{cacheDisabled:true});
  await call('Emulation.setDeviceMetricsOverride',{width:1440,height:1000,deviceScaleFactor:1,mobile:false});
  await call('Page.navigate',{url:base+'/?published-beta10-check='+Date.now()});
  await wait("document.getElementById('ota-available')?.textContent.includes('Update available · 0.1.0-beta.10')");
  assert.equal(await ev("document.getElementById('firmware-header-update').hidden"),false);
  assert.equal(await ev("document.getElementById('ota-installed').textContent"),'0.1.0-beta.9');
  await shot('published-beta10-update-badge.png');
  await ev("document.getElementById('firmware-header-update').click()");
  assert.equal(await ev("document.getElementById('view-configuration').hidden"),false);assert.equal(await ev('document.activeElement.id'),'cfg-updates');
  assert.equal(await ev("document.getElementById('ota-confirm').checked"),false);assert.equal(await ev("document.getElementById('ota-install').disabled"),true);
  assert.equal(await ev("!!document.getElementById('cfg-updates').querySelector('input[type=password]')"),false);
  assert.equal(await ev("document.getElementById('ota-release').href"),'https://github.com/Kbdavis/Telescope-Cover-OTA-Test/releases/tag/v0.1.0-beta.10');
  await shot('published-beta10-configuration.png');
  const downloaded=await ev(`(async()=>{const r=await fetch('https://kbdavis.github.io/Telescope-Cover-OTA-Test/controller-10.bin',{cache:'no-store',credentials:'omit',referrerPolicy:'no-referrer',signal:AbortSignal.timeout(15000)});if(!r.ok)throw Error('Download HTTP '+r.status);const bytes=new Uint8Array(await r.arrayBuffer());return {size:bytes.length,elf:Array.from(bytes.slice(176,208),v=>v.toString(16).padStart(2,'0')).join('')};})()`);
  assert.equal(downloaded.size,expected.application.size);assert.equal(downloaded.elf,expected.application.elf);
  assert(requests.every(r=>r.method==='GET'));assert.deepEqual(errors,[]);
  assert(responses.some(r=>r.url.startsWith('https://api.github.com/repos/Kbdavis/Telescope-Cover-OTA-Test/releases?')&&r.status===200));
  assert(responses.some(r=>r.url.includes('/controller-index.json?')&&r.status===200));
  const after=await get();for(const key of ['boot_id','firmware_id','build','phase','transaction','received','active'])assert.equal(after[key],before[key],key);
  const result={passed:true,simulated:false,source_version:before.version,target_version:expected.version,source_elf:before.firmware_id,target_elf:expected.application.elf,update_available:true,header_badge_visible:true,configuration_navigation:true,confirmation_unchecked:true,install_disabled_without_confirmation:true,public_browser_download:downloaded,controller_writes:0,installation_performed:false,reboot_performed:false,boot_unchanged:true,requests:requests.length,errors};
  fs.writeFileSync(path.join(out,'published-readiness.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
 }finally{ws.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
