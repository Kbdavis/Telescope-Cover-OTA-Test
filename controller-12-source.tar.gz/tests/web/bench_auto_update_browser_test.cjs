/* Actual public-release OTA. mode=legacy migrates the old manual-key receiver;
   mode=auto never reads a key file or enters credentials. No mocked responses.
   Usage: node bench_auto_update_browser_test.cjs BASE EVIDENCE_DIR MODE [legacy-key-file] */
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
(async()=>{
 const [base,dir,mode,legacyFile]=process.argv.slice(2);assert(['legacy','auto'].includes(mode));
 assert(/^http:\/\/192\.168\.\d{1,3}\.\d{1,3}$/.test(base));
 const legacyKey=mode==='legacy'?fs.readFileSync(legacyFile,'utf8').trim():null;
 if(mode==='auto')assert.equal(legacyFile,undefined,'Automatic flow must not receive any USB key file');
 const source=JSON.parse(fs.readFileSync(path.join(dir,'a/artifact.json'))),targetMeta=JSON.parse(fs.readFileSync(path.join(dir,'b/artifact.json')));
 const catalog=JSON.parse(fs.readFileSync(path.join(dir,'catalog.json'))),release=catalog.releases.find(r=>r.build===targetMeta.build);assert(release);
 const get=async()=>{const r=await fetch(base+'/api/bench/status',{signal:AbortSignal.timeout(5000)});assert(r.ok);return r.json();};
 const before=await get();assert(before.accepted);assert.equal(before.elf,source.elf);assert.equal(before.servo_operations,false);assert.equal(before.phase,'idle');
 const nodeSession=async()=>{const r=await fetch(base+'/api/bench/session',{headers:{'X-Bench-Session':'1',Origin:base},signal:AbortSignal.timeout(5000)});assert(r.ok);return r.json();};
 const oldSession=mode==='auto'?await nodeSession():null;
 const page=(await(await fetch('http://127.0.0.1:9234/json/list')).json()).find(t=>t.type==='page');assert(page);
 const ws=new WebSocket(page.webSocketDebuggerUrl),pending=new Map(),errors=[],requests=[],responses=[];let id=0;
 await new Promise(r=>ws.addEventListener('open',r,{once:true}));
 const call=(method,params={})=>new Promise((resolve,reject)=>{const n=++id;pending.set(n,{resolve,reject});ws.send(JSON.stringify({id:n,method,params}));});
 ws.addEventListener('message',event=>{const m=JSON.parse(event.data);
  if(m.id){const p=pending.get(m.id);pending.delete(m.id);m.error?p.reject(Error(m.error.message)):p.resolve(m.result);}
  if(m.method==='Runtime.exceptionThrown')errors.push(m.params.exceptionDetails.text);
  if(m.method==='Network.requestWillBeSent')requests.push({url:m.params.request.url,method:m.params.request.method});
  if(m.method==='Network.responseReceived')responses.push({url:m.params.response.url,status:m.params.response.status});
 });
 const ev=async expression=>{const r=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error(r.exceptionDetails.text);return r.result.value;};
 const wait=async(expression,ms=30000)=>{const end=Date.now()+ms;while(Date.now()<end){if(await ev(expression))return;await new Promise(r=>setTimeout(r,100));}throw Error('Timed out: '+expression);};
 const shot=async name=>{const layout=await call('Page.getLayoutMetrics');const r=await call('Page.captureScreenshot',{format:'png',captureBeyondViewport:true,clip:{x:0,y:0,width:layout.cssContentSize.width,height:layout.cssContentSize.height,scale:1}});fs.writeFileSync(path.join(dir,name),Buffer.from(r.data,'base64'));};
 try{
  await call('Runtime.enable');await call('Page.enable');await call('Network.enable');await call('Network.setCacheDisabled',{cacheDisabled:true});
  await call('Page.navigate',{url:base+'/?automatic-auth-test='+Date.now()});
  await wait(`document.getElementById('available')?.textContent.includes('0.1.0-beta.${targetMeta.build}')`);
  assert.equal(await ev("document.getElementById('installed').textContent"),source.version);
  const manualField=await ev("!!document.getElementById('key') || !!document.querySelector('input[type=password]')");
  assert.equal(manualField,mode==='legacy');
  await shot('01-update-available.png');
  const admission=await ev(`(async()=>{const s=await(await fetch('/api/bench/status')).json();
   const session=${mode==='auto'?"await(await fetch('/api/bench/session',{headers:{'X-Bench-Session':'1'}})).json()":JSON.stringify({update_token:legacyKey})};
   const send=async(key,signature,confirm)=>{const body={manifest:${JSON.stringify(release.manifest)},signature};if(confirm)body.confirm='install';const r=await fetch('/api/bench/start',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded','X-Bench-Key':key,'X-Bench-Nonce':s.nonce},body:new URLSearchParams(body)});return r.status;};
   const wrongToken=await send('0'.repeat(64),${JSON.stringify(release.signature)},true);
   const badSignature=await send(session.update_token,'0'.repeat(128),true);
   const noConfirmation=${mode==='auto'?`await send(session.update_token,${JSON.stringify(release.signature)},false)`:'null'};
   return {wrongToken,badSignature,noConfirmation,phase:(await(await fetch('/api/bench/status')).json()).phase};})()`);
  assert.equal(admission.wrongToken,403);assert.equal(admission.badSignature,400);assert.equal(admission.phase,'idle');
  let sessionGuards=null;
  if(mode==='auto'){
   assert.equal(admission.noConfirmation,400);
   const missing=await fetch(base+'/api/bench/session',{signal:AbortSignal.timeout(5000)});
   const cross=await fetch(base+'/api/bench/session',{headers:{'X-Bench-Session':'1',Origin:'https://unrelated.example'},signal:AbortSignal.timeout(5000)});
   assert.equal(missing.status,403);assert.equal(cross.status,403);sessionGuards={missing_request_header:missing.status,cross_origin:cross.status};
  }
  assert.equal(await ev("document.getElementById('install').disabled"),true,'Confirmation is still required');
  if(mode==='legacy')await ev(`document.getElementById('key').value=${JSON.stringify(legacyKey)};document.getElementById('key').dispatchEvent(new Event('input'))`);
  await ev("document.getElementById('confirm').checked=true;document.getElementById('confirm').dispatchEvent(new Event('change'))");
  assert.equal(await ev("document.getElementById('install').disabled"),false);
  const started=Date.now();await ev("document.getElementById('install').click()");let succeeded=false,lastLog=0;
  while(Date.now()-started<720000){
   const view=await ev("({operation:document.getElementById('operation').textContent,result:window.benchLastResult||null})");
   if(Date.now()-lastLog>15000){console.log(view.operation);lastLog=Date.now();}
   if(view.operation.startsWith('Update stopped:'))throw Error(view.operation);
   if(view.result){succeeded=true;break;}await new Promise(r=>setTimeout(r,1000));
  }
  assert(succeeded,'No confirmed update completion');
  const after=await get();assert(after.accepted&&after.settings_preserved);assert.equal(after.elf,targetMeta.elf);assert.equal(after.build,targetMeta.build);assert.equal(after.outcome,'complete');assert.notEqual(after.boot,before.boot);assert.equal(after.slot,before.slot===65536?1376256:65536);
  const browserResult=await ev('window.benchLastResult');assert.equal(browserResult.transaction,after.journal_transaction);assert.equal(after.journal_target,targetMeta.elf);
  await shot('02-update-complete.png');
  // Both new builds expose automatic sessions. Never save the token itself.
  const freshSession=await nodeSession();assert.equal(freshSession.boot,after.boot);assert.equal(freshSession.nonce,after.nonce);
  let staleTokenRejected=null;
  if(oldSession){
   assert.notEqual(oldSession.update_token,freshSession.update_token);
   const stale=await fetch(base+'/api/bench/start',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded','Origin':base,'X-Bench-Key':oldSession.update_token,'X-Bench-Nonce':after.nonce},body:new URLSearchParams({manifest:release.manifest,signature:release.signature,confirm:'install'}),signal:AbortSignal.timeout(5000)});
   assert.equal(stale.status,403);staleTokenRejected=stale.status;
  }
  assert(responses.some(r=>r.url===`https://kbdavis.github.io/Telescope-Cover-OTA-Test/bench-${targetMeta.build}.bin`&&r.status===200));
  await call('Page.navigate',{url:base+'/?verify-no-key-field='+Date.now()});
  await wait(`document.getElementById('installed')?.textContent==='${targetMeta.version}'`);
  assert.equal(await ev("!!document.getElementById('key') || !!document.querySelector('input[type=password]')"),false);
  await shot('03-new-page-no-key.png');assert.deepEqual(errors,[]);
  const result={passed:true,simulated:false,mode,source,target:targetMeta,source_boot:before.boot,target_boot:after.boot,source_slot:before.slot,target_slot:after.slot,
   transaction:browserResult.transaction,elapsed_ms:Date.now()-started,settings_preserved:true,startup_accepted:true,outcome:after.outcome,
   manual_key_required:mode==='legacy',target_has_key_prompt:false,session_guards:sessionGuards,stale_token_rejected:staleTokenRejected,admission,requests,responses,servo_operations:false};
  fs.writeFileSync(path.join(dir,'browser-result.json'),JSON.stringify(result,null,2)+'\n');fs.writeFileSync(path.join(dir,'target-status.json'),JSON.stringify(after,null,2)+'\n');
  console.log(JSON.stringify({...result,requests:requests.length,responses:responses.length},null,2));
 }catch(error){fs.writeFileSync(path.join(dir,'browser-failure.json'),JSON.stringify({message:String(error).split(legacyKey||'never-a-token').join('[REDACTED]'),errors,requests:requests.length},null,2)+'\n');throw error;}
 finally{ws.close();}
})().catch(error=>{console.error(error);process.exitCode=1;});
