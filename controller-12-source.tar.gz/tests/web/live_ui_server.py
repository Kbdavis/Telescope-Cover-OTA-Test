"""Local-only HTTP fixture for the real UI transport; never connects to hardware."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs
import json, time, threading, sys, gzip, copy
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'tools'))
from embed_ui import generate
assets=generate()
lock=threading.RLock()
profile=dict(open_speed=100,close_speed=100,jog_speed=100,acceleration=10,timeout_ms=25000)
cover=dict(state='CLOSED',fault='',ready=True,manual_ready=True,assembly_opening_direction=1,moving=False,holding=False,settings_offline_allowed=False,owner=0,position=600,age_ms=0,torque=False,
 travel_schema=4,rollover_supported=False,teaching=False,circular=False,draft_circular=False,calibration_review=False,opening_direction=1,travel_counts=1400,draft_direction=1,draft_travel_counts=1400,
 calibration_only=False,calibrated=True,dirty=False,notice='Saved calibration loaded',minimum=400,maximum=3600,
 draft_minimum=400,draft_maximum=3600,draft_open=2000,draft_closed=600,open=2000,closed=600,saved_minimum=400,saved_maximum=3600,
 draft_profile=profile.copy(),saved_profile=profile.copy(),wifi='Home Wi-Fi',wifi_rssi=-62,target=600,motion_ms=0,heartbeat_age_ms=0,timeout_ms=25000,
 control_generation=1,maintenance=dict(owner='none',phase='idle',generation=0,locked=False),
 uptime_ms=10000,firmware_id='ui-test',servo_voltage=12.2,servo_temperature=32,servo_load=0,servo_current_raw=0,command_id=0,command_client=0,command_ok=False,
 emergency=dict(supported=True,locked=False,active=False,operation=0,stop_epoch=0,phase='idle',recovering=False,recoveries=0,diagnostic=None,message='Emergency shutdown ready'),
 resources=dict(cpu_load=dict(available=True,method='timer_sampled',core0_percent=12.5,core1_percent=3.5,average_percent=8.0,window_ms=1000,age_ms=0)))
scope=dict(enabled=True,read_only=False,polling_read_only=False,sequence=2,valid=True,connected=True,at_home=True,stowed_observation=True,slewing=False,tracking=False,age_ms=0,stow_locked=False,
 arm_locked=False,arm_supported=True,arm_phase='idle',arm_opening=False,altitude=-90,altitude_age_ms=0,azimuth=0,azimuth_age_ms=0,camera_state=0,camera_state_age_ms=0,
 camera_temperature=20,camera_temperature_age_ms=0,heater_on=False,heater_on_age_ms=0,power_valid=True,power_age_ms=0,battery_percent=42,external_power=False,
 charging_state='Discharging',battery_temperature=23,battery_overtemp=False,can_find_home=True,stow_phase='idle',error='none',driver_error=0,power_telemetry_supported=True,
 power_retrying=False,power_paused=False)
network=dict(ntp_enabled=False,ntp_server="pool.ntp.org",time_zone="MST7",time_synchronized=False,local_time=None,enable_debug_tab=False,disable_torque_after_move=False,alpaca_enabled=True,alpaca_read_only=False,alpaca_host='192.168.1.131',alpaca_port=32323,alpaca_device=0,mdns_name='cover',busy=False,connected=True,
 ssid='Observatory Wi-Fi',saved_ssid='Observatory Wi-Fi',password_saved=True,ip='192.168.1.135',ap='',message='Ready',networks=[dict(ssid='Observatory Wi-Fi',rssi=-62,secure=True),dict(ssid='Guest',rssi=-69,secure=False)])
controls=dict(manual_client=0,beta=False,token='test-boot-1',setup=False,fail_save=False,delay_start=0,drop_status=False,delay_emergency=0,emergency_fail_phase='',emergency_recovery=False)
initial=copy.deepcopy([cover,scope,network,controls])
metrics_leases={}
metrics_boot=''
metrics_epoch=0
metrics_active=False
metrics_values=copy.deepcopy(cover['resources'])
events=[];motion=None;arm=None;emergency=None;timer=time.monotonic();last_beat=timer

def update():
 global motion,arm,emergency,metrics_boot,metrics_epoch,metrics_active
 if metrics_boot!=controls['token']:
  metrics_leases.clear();metrics_boot=controls['token'];metrics_active=False
 now=time.monotonic();cover['uptime_ms']=10000+int((now-timer)*1000)
 for lease in metrics_leases.values():
  if lease['active'] and now-lease['at']>=5:lease['active']=False
 viewers=sum(lease['active'] for lease in metrics_leases.values())
 if viewers and not metrics_active:metrics_epoch+=1
 metrics_active=bool(viewers)
 resources=dict(state='active' if viewers else 'off',available=bool(viewers),viewers=viewers,epoch=metrics_epoch if viewers else 0,boot_id='public-'+controls['token'])
 if viewers:
  resources.update(copy.deepcopy(metrics_values))
  resources['wifi']=dict(connected=True,disconnects=3,reconnects=2,last_reason=200,last_reason_name='BEACON_TIMEOUT',
   last_disconnect_uptime_ms=5000,current_outage_ms=0,last_outage_ms=1800,rssi=-62,minimum_rssi=-78,
   alpaca_requests=120,alpaca_failures=4,alpaca_timeouts=3,last_request_ms=35,max_request_ms=1200,packet_loss=None,radio_retries=None)
  resources['cpu_load']['available']=controls.get('cpu_available',True)
  resources.update(sampled_at_ms=cover['uptime_ms'],age_ms=0,internal_free_heap_bytes=170000,internal_min_free_heap_bytes=150000,
   internal_largest_free_block_bytes=110000,debug_log_available=True,debug_log_capacity=1000,log_dropped=0,
   web_gap_ms=1,motion_gap_ms=5,ring_overwrites=0,log_truncated=0,suppressed_trace=100,task_stacks={task:dict(min_free_bytes=1800,sample_age_ms=0) for task in ['web','cover','alpaca','diagnostics']})
 cover['resources']=resources
 cover['ota']=dict(available=False,phase='unavailable')
 if emergency and not controls['emergency_recovery']:
  phase=['stopping_capture','verifying_idle','stowing','verifying_stow','closing','complete'][min(5,int((now-emergency)/.6))]
  e=cover['emergency'];e.update(phase=phase,recovering=False,message=phase.replace('_',' ').capitalize())
  if controls['emergency_fail_phase']==phase:
   e.update(phase='fault',active=False,locked=True,message='Shutdown failed; closure inhibited');cover.update(moving=False,torque=False);emergency=None
  elif phase=='complete':
   e.update(active=False,locked=False,message='Shutdown complete: telescope stowed, cover at saved closed position')
   cover.update(state='CLOSED',position=cover['closed'],moving=False,torque=False);emergency=None
  elif phase in ['verifying_idle','stowing','verifying_stow','closing']:
   scope.update(camera_state=0,tracking=False,slewing=False)
   if phase in ['verifying_stow','closing']:scope.update(at_home=True,stowed_observation=True,altitude=-90)
   if phase=='closing':cover.update(state='CLOSING',moving=True,torque=True)
 if emergency and controls['emergency_recovery']:
  cover['emergency'].update(recovering=True,recoveries=1,message='Reconnecting telescope status; cover stays open',diagnostic=dict(sequence=1,phase='stopping_capture',source='alpaca',request='tracking',error='timeout',driver_code=0,transaction=8,request_ms=1200,sample_age_ms=5500))
 if motion:
  start,origin,target,retain=motion;cover['motion_ms']=int((now-start)*1000)
  if now-last_beat>.65:
   cover.update(state='FAULT',fault='Safety interlock',ready=False,moving=False,holding=False,torque=False,owner=0);motion=None
  else:
   f=min(1,(now-start)/.8);cover['position']=round(origin+(target-origin)*f)
   if f>=1:
    cover.update(moving=False,holding=retain,torque=retain,state='HOLDING' if retain else 'OPEN' if target==cover['open'] else 'CLOSED' if target==cover['closed'] else 'STOPPED')
    if not retain:cover['owner']=0
    motion=None
 if arm and now>=arm[0]:
  scope.update(arm_locked=False,arm_phase='complete',at_home=not arm[1],stowed_observation=not arm[1],altitude=0 if arm[1] else -90);arm=None

class Handler(BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def send(self,value,code=200,kind='application/json',gzip_asset=False):
  data=value if isinstance(value,bytes) else (json.dumps(value).encode() if kind=='application/json' else str(value).encode())
  self.send_response(code);self.send_header('Content-Type',kind);self.send_header('Cache-Control','no-store')
  if gzip_asset:data=gzip.compress(data,mtime=0);self.send_header('Content-Encoding','gzip')
  self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
 def do_GET(self):
  with lock:
   update();path=self.path.split('?')[0]
   assets=generate() if not path.startswith(('/api/','/test/')) else {}
   if path in ['/','/configuration','/calibration','/control']:return self.send(assets['uiIndex'],kind='text/html',gzip_asset=True)
   asset={'/favicon.ico':('uiFaviconIco','image/x-icon'),'/favicon.png':('uiFavicon','image/png'),'/ui/app.js':('uiScript','application/javascript'),'/ui/styles.css':('uiStyles','text/css'),'/ui/theme.js':('uiTheme','application/javascript')}.get(path)
   if asset:return self.send(assets[asset[0]],kind=asset[1],gzip_asset=not path.startswith('/favicon.'))
   if path=='/api/session':return self.send(dict(token=controls['token'],beta_accepted=controls['beta'],setup_only=controls['setup'],firmware_id='ui-test',boot_id='public-'+controls['token']))
   if path=='/api/status':return self.send(cover if not controls['drop_status'] else {},503 if controls['drop_status'] else 200)
   if path=='/api/alpaca/status':return self.send(scope)
   if path=='/api/ota/status':return self.send(dict(available=False,phase='unavailable'))
   if path in ['/api/motion/trace','/api/heartbeat/trace','/api/diagnostics/servo']:
    if controls['setup']:return self.send('Home Wi-Fi only',403,'text/plain')
    common=dict(schema_version=1,boot_id='public-'+controls['token'],firmware_id='ui-test')
    if path=='/api/motion/trace':return self.send(dict(common,operation=1,target=cover['target'],samples=[]))
    if path=='/api/heartbeat/trace':return self.send(dict(common,fault_at_ms=0,fault_age_ms=0,http=[]))
    return self.send(dict(common,available=True,retention='ram_until_reboot',current=dict(failed_reads=0,retries=0),fault=None))
   if path=='/api/debug/retained':
    if controls['setup']:return self.send('Home Wi-Fi only',403,'text/plain')
    return self.send(dict(schema_version=1,available=True,retention='rtc',power_loss_persistent=False,
     current_boot='public-'+controls['token'],reset_reason='SOFTWARE',retained_boots=2,
     wifi=controls.get('retained_wifi'),fault=controls.get('retained_fault')))
   if path=='/api/debug':
    if controls['setup']:return self.send('Home Wi-Fi only',403,'text/plain')
    query=parse_qs(self.path.partition('?')[2]);after=int(query.get('after',['0'])[0]);epoch=controls.get('debug_epoch',0);boot='public-'+controls['token']
    reset=query.get('boot_id',[boot])[0]!=boot or int(query.get('sequence_epoch',[epoch])[0])!=epoch or after>3
    if reset:after=0
    entries=[dict(sequence=1,ms=1000,level='error',message='SERVO OPEN encoder changed 3200 -> 3202 (delta=2 counts)',truncated=False),dict(sequence=2,ms=2000,level='warn',message='ALPACA connection dropped / status unavailable error=timeout',truncated=False),dict(sequence=3,ms=3000,level='info',message='Debug logging ready',truncated=False)]
    entries=[e for e in entries if e['sequence']>after]
    return self.send(dict(schema_version=1,firmware='ui-test',boot_id=boot,sequence_epoch=epoch,oldest_sequence=1,newest_sequence=3,
     entries=entries,available=True,capacity=1000,loss=dict(ring_overwrites=0,serial_dropped=0,truncated=0,suppressed_trace=0),
     cursor_reset=reset,gap=False,more=False,next_after=entries[-1]['sequence'] if entries else after,metrics_active=cover['resources']['available']))
   if path=='/api/network':return self.send(network)
   if path=='/test/events':return self.send(events)
   return self.send({},404)
 def do_POST(self):
  global motion,arm,last_beat,emergency
  size=int(self.headers.get('Content-Length',0));raw=self.rfile.read(size)
  if self.path=='/test/reset':
   with lock:
    motion=arm=emergency=None;events.clear();metrics_leases.clear()
    for dest,source in zip([cover,scope,network,controls],initial):dest.clear();dest.update(copy.deepcopy(source))
   return self.send({})
  if self.path=='/test/patch':
   patch=json.loads(raw)
   with lock:
    for key,d in [('cover',cover),('scope',scope),('network',network),('controls',controls)]:d.update(patch.get(key,{}))
   return self.send({})
  body={key:values[0] for key,values in parse_qs(raw.decode(),keep_blank_values=True).items()}
  path=self.path.removeprefix('/api/');client=int(self.headers.get('X-Cover-Client','0'))
  if self.headers.get('X-Cover-Token')!=controls['token']:return self.send('Reload page',403,'text/plain')
  if path=='beta/accept':controls['beta']=True;return self.send('Accepted',200,'text/plain')
  if not controls['beta'] and path!='stop':return self.send('Accept beta',403,'text/plain')
  if path in ['jog-plus','jog-minus','dashboard/open','dashboard/close','open','close'] and controls['delay_start']:time.sleep(controls['delay_start'])
  if path=='heartbeat' and controls.get('delay_heartbeat'):time.sleep(controls['delay_heartbeat'])
  if path=='emergency/start' and controls['delay_emergency']:time.sleep(controls['delay_emergency'])
  with lock:
   update();events.append(dict(path=path,body={k:v for k,v in body.items() if k!='password'},client=client))
   generation=int(body.get('control_generation','0'))
   exempt=path in ['stop','manual/disable'] or path.startswith('diagnostics/metrics/')
   if not exempt and (generation!=cover['control_generation'] or cover['maintenance']['locked']):return self.send('Stale controls or maintenance active',409,'text/plain')
   if path=='stop' and body.get('automatic')=='yes' and generation!=cover['control_generation']:return self.send('Old automatic Stop',409,'text/plain')
   if path.startswith('diagnostics/metrics/'):
    if controls['setup'] or body.get('boot_id')!='public-'+controls['token']:return self.send('Metrics session changed',409,'text/plain')
    generation=int(body.get('generation',0));action=path.rsplit('/',1)[-1]
    lease=metrics_leases.get(client)
    if action=='subscribe':
     if lease and (generation<lease['generation'] or generation==lease['generation'] and not lease['active']):return self.send('Stale',409,'text/plain')
     metrics_leases[client]=dict(generation=generation,active=True,at=time.monotonic())
    elif action=='renew':
     if not lease or not lease['active'] or generation!=lease['generation']:return self.send('Expired',409,'text/plain')
     lease['at']=time.monotonic()
    elif action=='unsubscribe':
     if not lease or generation>=lease['generation']:metrics_leases[client]=dict(generation=generation,active=False,at=time.monotonic())
    else:return self.send({},404)
    update();return self.send(dict(accepted=True,state=cover['resources']['state'],viewers=cover['resources']['viewers']))
   if path=='manual/enable':
    if body.get('acknowledge')!='equipment-damage':return self.send('Acknowledge equipment damage warning',400,'text/plain')
    controls['manual_client']=client;return self.send('Manual enabled',200,'text/plain')
   if path=='manual/disable':
    if controls['manual_client']==client:controls['manual_client']=0
    return self.send('Manual disabled',200,'text/plain')
   if path.startswith('manual/jog-'):
    if controls['manual_client']!=client:return self.send('Manual authorization required',403,'text/plain')
    path=path.removeprefix('manual/')
   if path=='controller/reboot':
    if body.get('confirm')!='reboot' or cover['moving']:return self.send('Finish movement before reboot',409,'text/plain')
    cover['control_generation']+=1;cover['maintenance']=dict(owner='reboot',phase='ready',generation=1,locked=True)
    keep=body.get('disable_torque')=='false';cover.update(holding=False,torque=keep,state='RETAINED' if keep else 'STOPPED')
    def reboot():
     with lock:
      controls['token']+='r';controls['manual_client']=0;cover['control_generation']=1;cover['maintenance']=dict(owner='none',phase='idle',generation=0,locked=False)
    threading.Timer(.3,reboot).start();return self.send('Restart requested',202,'text/plain')
   if path=='heartbeat':last_beat=time.monotonic();return self.send('Heartbeat',202,'text/plain')
   if path=='stop':
    cover['control_generation']+=1
    if cover['maintenance']['locked']:cover['maintenance']['phase']='revoked'
    motion=None;cover.update(moving=False,holding=False,torque=False,owner=0,state='STOPPED');cover['emergency']['stop_epoch']+=1
    if emergency:
     emergency=None;cover['emergency'].update(active=False,locked=True,recovering=False,phase='cancelled',message='Shutdown cancelled; inspect telescope and cover before recovery')
    return self.send('Stop queued',202,'text/plain')
   if path=='emergency/finish':
    if body.get('inspected')!='yes' or cover['emergency']['active']:return self.send('Inspection required',409,'text/plain')
    cover['emergency'].update(locked=False,phase='idle',message='Shutdown lock cleared after inspection; no movement requested')
    return self.send('Inspection accepted',202,'text/plain')
   if cover['emergency']['locked']:return self.send('Shutdown lock active',409,'text/plain')
   if path=='emergency/start':
    if not scope['enabled'] or not scope['connected'] or body.get('clear')!='yes' or body.get('interrupt_capture')!='yes' or int(body.get('stop_epoch',-1))!=cover['emergency']['stop_epoch']:
     return self.send('Shutdown preflight changed',409,'text/plain')
    emergency=time.monotonic();cover['emergency'].update(active=True,locked=True,recovering=False,diagnostic=None,phase='stopping_capture',operation=cover['emergency']['operation']+1,message='Stopping capture and observing plans')
    return self.send('Shutdown requested',202,'text/plain')
   if path=='telescope/arm/finish':
    if body.get('inspected')!='yes' or scope['arm_phase']!='inspect':return self.send('Inspection required',409,'text/plain')
    scope.update(arm_locked=False,arm_phase='idle');return self.send('Inspection accepted; no movement',202,'text/plain')
   if path.startswith('telescope/arm/'):
    opening=path.endswith('/open');scope.update(arm_locked=True,arm_phase='waiting',arm_opening=opening);arm=(time.monotonic()+.8,opening)
    return self.send('Arm queued',202,'text/plain')
   if path.startswith('network/') or path.startswith('settings/'):
    if cover['moving'] or cover['holding'] or (cover['state']!='CLOSED' and not cover['settings_offline_allowed']):return self.send('Require closed cover or unavailable servo',409,'text/plain')
    network['busy']=True;cover['control_generation']+=1;cover['maintenance']=dict(owner='network',phase='ready',generation=1,locked=True)
    def finish():
     with lock:
      cover['control_generation']+=1;cover['maintenance']=dict(owner='none',phase='idle',generation=0,locked=False)
      if controls['fail_save']:network.update(busy=False,message='Settings save failed; previous settings retained');return
      if path=='network/scan':network.update(busy=False,message='Scan complete');return
      if path=='network/connect':network.update(ssid=body['ssid'],saved_ssid=body['ssid'],password_saved=bool(body.get('password') or body.get('keep_password')),message='Wi-Fi saved',busy=False);return
      if path=='settings/advanced':network.update(enable_debug_tab=body.get('enable_debug_tab','false')=='true',disable_torque_after_move=body['disable_torque_after_move']=='true',busy=False,message='Advanced settings saved');controls['token']+='x';return
      if path=='settings/time':network.update(ntp_enabled=body['enabled']=='true',ntp_server=body['server'],time_zone=body['time_zone'],time_synchronized=False,local_time=None,busy=False,message='Time settings saved');controls['token']+='x';return
      if path=='settings/hostname':network.update(mdns_name=body['hostname'],busy=False,message='Name saved');return
      if path=='settings/alpaca':
       for key,value in body.items():
        if key in ['enabled','read_only']:value=value=='true'
        elif key in ['port','device']:value=int(value)
        network['alpaca_'+key]=value
       scope['enabled']=network['alpaca_enabled'];network.update(busy=False,message='Settings saved');controls['token']+='x';return
    threading.Timer(.8,finish).start();return self.send('Waiting for controller clearance',202,'text/plain')
   cover.update(command_id=int(body.get('request_id','0')),command_client=client,command_ok=True,notice='Command applied')
   if path in ['jog-plus','jog-minus','dashboard/open','dashboard/close','open','close']:
    target=cover['position']+int(body.get('step',100))*(1 if path=='jog-plus' else -1) if path.startswith('jog') else cover['open'] if path.endswith('open') else cover['closed']
    cover.update(moving=True,holding=False,torque=None,owner=client,target=target,state='MANUAL' if path.startswith('jog') else 'OPENING' if path.endswith('open') else 'CLOSING');last_beat=time.monotonic();motion=(last_beat,cover['position'],target,body.get('hold')=='yes')
   elif path=='calibration/limits':
    lo=int(body['minimum']);hi=int(body['maximum']);cover.update(minimum=lo,maximum=hi,draft_minimum=lo,draft_maximum=hi,dirty=True)
   elif path=='calibration/begin' and body.get('resume')=='yes':cover.update(teaching=True,dirty=True,minimum=0,maximum=4095,draft_minimum=0,draft_maximum=4095)
   elif path=='calibration/begin':cover.update(teaching=True,ready=cover['state']!='FAULT',calibration_only=False,minimum=0,maximum=4095,draft_minimum=0,draft_maximum=4095,draft_circular=True,draft_closed=None,draft_open=None,draft_direction=cover['assembly_opening_direction'],draft_travel_counts=0,dirty=True)
   elif path=='calibration/direction':cover.update(draft_direction=int(body['direction']),draft_open=None,draft_travel_counts=0,dirty=True)
   elif path=='calibration/profile':cover['draft_profile']={key:int(body[key]) for key in profile};cover['dirty']=True
   elif path in ['calibration/open','calibration/closed']:
    cover['draft_'+path.split('/')[1]]=cover['position'];cover['dirty']=True
    if cover['draft_open'] is None:cover['draft_travel_counts']=0
    else:cover['draft_travel_counts']=(cover['draft_direction']*(cover['draft_open']-cover['draft_closed']))%(4096 if cover['draft_circular'] else 100000)
   elif path=='calibration/save':
    if controls['fail_save']:cover.update(command_ok=False,notice='Save failed; previous values retained')
    else:cover.update(teaching=False,circular=cover['draft_circular'],opening_direction=cover['draft_direction'],travel_counts=cover['draft_travel_counts'],calibration_review=False,open=cover['draft_open'],closed=cover['draft_closed'],saved_minimum=cover['draft_minimum'],saved_maximum=cover['draft_maximum'],saved_profile=cover['draft_profile'].copy(),calibrated=True,dirty=False,notice='Calibration saved and read back from NVS')
   elif path=='calibration/discard':cover.update(teaching=False,draft_circular=cover['circular'],draft_direction=cover['opening_direction'],draft_travel_counts=cover['travel_counts'],draft_open=cover['open'],draft_closed=cover['closed'],minimum=cover['saved_minimum'],maximum=cover['saved_maximum'],draft_minimum=cover['saved_minimum'],draft_maximum=cover['saved_maximum'],draft_profile=cover['saved_profile'].copy(),dirty=False)
   elif path=='recover':
    if cover['position'] is None or cover['torque'] is None:cover.update(command_ok=False,notice='Servo not responding; check servo power and bus cable')
    elif cover['fault'].startswith(('ST3215 configuration mismatch','Invalid ST3215 configuration')):cover.update(command_ok=False,notice=cover['fault'])
    elif not cover['calibrated']:cover.update(ready=False,calibration_only=True,settings_offline_allowed=False,fault='Calibration missing/invalid; set safe limits on Calibration page',notice='Servo checks passed; calibrate before movement')
    else:cover.update(ready=True,fault='',state='STOPPED',torque=False,settings_offline_allowed=False)
   return self.send('Request queued',202,'text/plain')

if __name__=='__main__':
 print('Live UI test fixture: http://127.0.0.1:8091 (no hardware)',flush=True)
 ThreadingHTTPServer(('127.0.0.1',8091),Handler).serve_forever()
