/* Read-only spare test: actual page, simulated retry timing, then real GitHub check.
   Usage: node tests/web/device_update_retry_browser_test.cjs http://SPARE-IP evidence-dir */
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
(async()=>{
 const base=process.argv[2],dir=process.argv[3];
 assert(/^http:\/\/192\.168\.\d{1,3}\.\d{1,3}$/.test(base));assert(fs.statSync(dir).isDirectory());
 const session=await(await fetch(base+'/api/session',{signal:AbortSignal.timeout(5000)})).json();
 assert.equal(session.read_only_test,true);
 const target=(await(await fetch('http://127.0.0.1:9234/json/list')).json()).find(t=>t.type==='page');
 const ws=new WebSocket(target.webSocketDebuggerUrl),pending=new Map(),errors=[],requests=[];let id=0;
 await new Promise(r=>ws.addEventListener('open',r,{once:true}));
 const call=(method,params={})=>new Promise((resolve,reject)=>{const n=++id;pending.set(n,{resolve,reject});ws.send(JSON.stringify({id:n,method,params}));});
 ws.addEventListener('message',event=>{const m=JSON.parse(event.data);
  if(m.id){const p=pending.get(m.id);pending.delete(m.id);m.error?p.reject(Error(m.error.message)):p.resolve(m.result);}
  if(m.method==='Runtime.exceptionThrown')errors.push(m.params.exceptionDetails);
  if(m.method==='Network.requestWillBeSent')requests.push({url:m.params.request.url,method:m.params.request.method});
 });
 const ev=async expression=>{const r=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));return r.result.value;};
 const wait=async expression=>{for(let n=0;n<180;n++){if(await ev(expression))return;await new Promise(r=>setTimeout(r,50));}throw Error('Timed out: '+expression);};
 try{
  await call('Runtime.enable');await call('Page.enable');await call('Network.enable');
  await call('Network.setCacheDisabled',{cacheDisabled:true});
  await call('Storage.clearDataForOrigin',{origin:base,storageTypes:'local_storage'});
  const script=await call('Page.addScriptToEvaluateOnNewDocument',{source:`(()=>{
   localStorage.setItem('cover.releasePreferences.v1',JSON.stringify({automatic:false,include_beta:false}));
   const clock=Date.now.bind(Date),original=fetch.bind(window);window.retryOffset=0;window.retryStatus=404;
   Date.now=()=>clock()+window.retryOffset;
   window.fetch=async(url,options)=>String(url).startsWith('https://api.github.com/')?
    new Response('{}',{status:window.retryStatus,headers:window.retryStatus===429?{'Retry-After':'300'}:{}}):original(url,options);
  })();`});
  await call('Page.navigate',{url:base+'/?retry-test='+Date.now()+'#configuration'});
  await wait('!!window.coverAPI?.state.session');
  assert.equal(await ev("document.getElementById('updates-check').disabled"),false);
  assert.equal(await ev("document.getElementById('updates-last-success').textContent"),'No successful check yet');
  await ev("document.getElementById('updates-check').click()");
  await wait("document.getElementById('updates-status').textContent.includes('private or inaccessible')");
  assert.match(await ev("document.getElementById('updates-check').textContent"),/^Check in /);
  assert.match(await ev("document.getElementById('updates-check-reason').textContent"),/attempted recently/);
  await ev('window.retryOffset+=61000');
  await wait("!document.getElementById('updates-check').disabled");
  await ev("document.getElementById('updates-check').click()");
  await wait("document.getElementById('updates-check').disabled");
  await ev('window.retryOffset+=61000');
  await wait("!document.getElementById('updates-check').disabled");
  await ev("window.retryStatus=429;document.getElementById('updates-check').click()");
  await wait("document.getElementById('updates-check-reason').textContent.includes('service requested a wait')");
  await ev('window.retryOffset+=61000');await new Promise(r=>setTimeout(r,1100));
  assert.equal(await ev("document.getElementById('updates-check').disabled"),true);
  // Remove all simulation before observing a real anonymous release request.
  await call('Page.removeScriptToEvaluateOnNewDocument',{identifier:script.identifier});
  await call('Storage.clearDataForOrigin',{origin:base,storageTypes:'local_storage'});
  await call('Page.navigate',{url:base+'/?real-release-check='+Date.now()+'#configuration'});
  await wait("document.getElementById('updates-status')?.textContent.includes('private or inaccessible') && !!window.coverAPI?.state.session");
  await ev("document.getElementById('cfg-updates').scrollIntoView()");
  const screen=await call('Page.captureScreenshot',{format:'png'});
  fs.writeFileSync(path.join(dir,'check-now-real-private-repo.png'),Buffer.from(screen.data,'base64'));
  const actual=await ev(`JSON.stringify({button:document.getElementById('updates-check').textContent,
   disabled:document.getElementById('updates-check').disabled,reason:document.getElementById('updates-check-reason').textContent,
   status:document.getElementById('updates-status').textContent,last_attempt:document.getElementById('updates-last-attempt').textContent,
   last_success:document.getElementById('updates-last-success').textContent})`);
  assert.deepEqual(errors,[]);assert.equal(requests.filter(r=>r.url.startsWith(base)&&r.method!=='GET').length,0);
  const after=await(await fetch(base+'/api/session',{signal:AbortSignal.timeout(5000)})).json();
  assert.equal(after.boot_id,session.boot_id);assert.equal(after.firmware_id,session.firmware_id);
  const result={passed:true,firmware_id:after.firmware_id,boot_id:after.boot_id,
   simulated_retry_checks:['initial manual check enabled','visible cooldown reason/countdown','manual retry after one minute despite automatic backoff','server rate-limit wait preserved'],
   real_anonymous_release_check:JSON.parse(actual),controller_mutations:0,ota_transfer_tested:false};
  fs.writeFileSync(path.join(dir,'browser-result.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
 }finally{ws.close();}
})().catch(error=>{console.error(error);process.exitCode=1;});
