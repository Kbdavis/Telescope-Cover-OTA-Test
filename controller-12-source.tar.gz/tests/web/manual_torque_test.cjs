const fs=require('fs'),vm=require('vm'),assert=require('node:assert/strict');
const nodes=new Map(),commands=[],requests=[],listeners={};let stops=0;
function el(id){if(!nodes.has(id))nodes.set(id,{checked:false,disabled:false,textContent:'',value:'10',options:[],open:false,close(){this.open=false;},showModal(){this.open=true;},addEventListener(){}});return nodes.get(id);}
const cover={state:'STOPPED',position:500,minimum:0,maximum:4095,ready:true,manual_ready:true,control_generation:1,holding:false,moving:false,owner:42};
const api={id:'42',state:{cover,view:'manual',session:{beta_accepted:true},network:{busy:false}},now:()=>100,freshCover:()=>true,freshPosition:()=>true,
 request:async(path,options)=>requests.push({path,options}),command:async(path,body)=>commands.push({path,body}),note(){},
 stop(){stops++;return Promise.resolve();}};
const c={coverAPI:api,window:{addEventListener:(name,fn)=>listeners[name]=fn},document:{getElementById:el,addEventListener:(name,fn)=>listeners[name]=fn}};
vm.createContext(c);vm.runInContext(fs.readFileSync('data/ui/travel.js','utf8'),c);c.coverTravel=c.window.coverTravel;
assert.match(fs.readFileSync('data/ui/index.html','utf8'),/id="manual-hold-torque"[^>]*checked/);
el('manual-hold-torque').checked=true;
vm.runInContext(fs.readFileSync('data/ui/manual.js','utf8'),c);
(async()=>{
 el('manual-enable').checked=true;el('manual-enable').onchange();await el('manual-accept').onclick();
 await el('manual-plus').onclick();assert.equal(commands.at(-1).body.hold,'yes');
 assert.equal(commands.at(-1).path,'manual/jog-minus');
 cover.holding=true;api.state.active=true;c.window.manualUI.render();assert(!el('manual-fields').disabled);assert(el('manual-hold-torque').disabled);
 await el('manual-plus').onclick();assert.equal(commands.length,2);assert.equal(commands.at(-1).body.hold,'yes');
 cover.owner=7;c.window.manualUI.render();assert(el('manual-fields').disabled);await el('manual-plus').onclick();assert.equal(commands.length,2);
 cover.owner=42;cover.holding=false;api.state.active=false;el('manual-hold-torque').checked=false;c.window.manualUI.render();
 await el('manual-minus').onclick();assert.equal(commands.at(-1).body.hold,'no');
 cover.holding=true;api.state.active=true;c.window.manualUI.disable();assert.equal(stops,1);
 assert(requests.some(r=>r.path==='manual/disable'));
 console.log('Actual Manual Control: default torque hold, successive owner steps, other-owner rejection, release opt-out and disable Stop passed');
})().catch(e=>{console.error(e);process.exitCode=1;});
