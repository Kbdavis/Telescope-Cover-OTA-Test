/* Real embedded page, loopback fixture only. Remote release requests are fulfilled
   by CDP; no hardware, GitHub credentials, hosting or publication is involved.
   Start live_ui_server.Handler on 127.0.0.1:8098 and isolated Chrome CDP 9234. */
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const fixture=JSON.parse(fs.readFileSync(path.join(__dirname,'../fixtures/release_metadata.json'),'utf8'));
(async()=>{
 const targets=await(await fetch('http://127.0.0.1:9234/json/list')).json();
 const target=targets.find(t=>t.type==='page');assert(target,'An isolated browser page is required');
 const ws=new WebSocket(target.webSocketDebuggerUrl),pending=new Map(),errors=[],requests=[];let id=0,mode='normal';
 await new Promise((resolve,reject)=>{ws.addEventListener('open',resolve,{once:true});ws.addEventListener('error',reject,{once:true});});
 const call=(method,params={})=>new Promise((resolve,reject)=>{const n=++id;pending.set(n,{resolve,reject});ws.send(JSON.stringify({id:n,method,params}));});
 const stable=fixture.release,beta={...stable,version:'0.2.0-beta.1',tag:'v0.2.0-beta.1',channel:'beta'};
 const data=[stable,beta].map((r,i)=>({id:100+i,tag_name:r.tag,draft:false,prerelease:i===1,published_at:'2026-11-12T12:00:00Z',body:i?'Beta notes.':'<img src="/unexpected-image" onerror="window.releaseXss=true"> Stable notes.'}));
 ws.addEventListener('message',async event=>{
  const m=JSON.parse(event.data);
  if(m.id){const p=pending.get(m.id);pending.delete(m.id);m.error?p.reject(Error(m.error.message)):p.resolve(m.result);}
  if(m.method==='Runtime.exceptionThrown')errors.push(m.params.exceptionDetails);
  if(m.method==='Network.requestWillBeSent')requests.push({url:m.params.request.url,method:m.params.request.method});
  if(m.method==='Fetch.requestPaused'){
   try{
    const api=m.params.request.url.startsWith('https://api.github.com/');
    const body=api?data:{schema:'telescope-cover-catalog-preview/1',releases:[{release_id:100,metadata:stable},{release_id:101,metadata:beta}]};
    await call('Fetch.fulfillRequest',{requestId:m.params.requestId,responseCode:mode==='unavailable'?404:200,
     responseHeaders:[{name:'Content-Type',value:'application/json'},{name:'Access-Control-Allow-Origin',value:'*'}],
     body:Buffer.from(JSON.stringify(mode==='unavailable'?{message:'Not Found'}:body)).toString('base64')});
   }catch(error){errors.push(String(error));}
  }
 });
 const ev=async expression=>{const r=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));return r.result.value;};
 const wait=async expression=>{for(let n=0;n<150;n++){if(await ev(expression))return;await new Promise(r=>setTimeout(r,50));}throw Error('Timed out: '+expression);};
 try{
  await call('Runtime.enable');await call('Page.enable');await call('Network.enable');
  await call('Fetch.enable',{patterns:[{urlPattern:'https://api.github.com/*'},{urlPattern:'https://kbdavis.github.io/*'}]});
  await fetch('http://127.0.0.1:8098/test/reset',{method:'POST',body:''});
  await fetch('http://127.0.0.1:8098/test/patch',{method:'POST',body:JSON.stringify({controls:{beta:true}})});
  await call('Storage.clearDataForOrigin',{origin:'http://127.0.0.1:8098',storageTypes:'local_storage'});
  await ev('window.releaseTestOldDocument=true');
  await call('Page.navigate',{url:'http://127.0.0.1:8098/?release-test='+Date.now()+'#configuration'});
  await wait('!window.releaseTestOldDocument && !!window.coverAPI?.state.session && !!window.CoverReleaseDiscovery');
  await wait("document.getElementById('updates-release').options.length===1");
  assert.equal(await ev("document.getElementById('firmware-update-link').hidden"),true,'Missing capabilities must not be guessed');
  await ev(`(()=>{coverAPI.state.session.firmware=${JSON.stringify({...fixture.device.firmware,profile:fixture.device.firmware.build_profile})};coverAPI.state.session.firmware_id=${JSON.stringify(fixture.device.firmware.elf)};coverAPI.state.session.update_capabilities=${JSON.stringify(fixture.device)};document.querySelector('dialog[open]')?.close();coverAPI.emit();})()`);
  await wait("!document.getElementById('firmware-update-link').hidden");
  assert.equal(await ev("document.getElementById('updates-available').textContent"),'0.1.0');
  await ev("document.getElementById('nav-overview').click();document.getElementById('firmware-update-link').click()");
  assert.equal(await ev('document.activeElement.id'),'cfg-updates');
  assert.equal(await ev('coverAPI.state.view'),'configuration');
  assert.equal(await ev("document.querySelectorAll('#updates-notes img').length"),0);
  assert.equal(await ev('!!window.releaseXss'),false);
  assert.match(await ev("document.getElementById('updates-notes').textContent"),/<img/);
  await ev("document.getElementById('updates-beta').click()");
  assert.equal(await ev("document.getElementById('updates-release').options.length"),2);
  assert.equal(await ev("document.getElementById('updates-available').textContent"),'0.2.0-beta.1');
  await ev("document.getElementById('updates-release').value='101';document.getElementById('updates-release').dispatchEvent(new Event('change'))");
  assert.equal(await ev("document.getElementById('updates-notes').textContent"),'Beta notes.');
  for(const width of [1440,390]){
   await call('Emulation.setDeviceMetricsOverride',{width,height:1000,deviceScaleFactor:1,mobile:width<500});
   await ev("document.getElementById('cfg-updates').scrollIntoView()");
   assert(await ev('document.documentElement.scrollWidth<=innerWidth+1'),'Firmware updates overflow the viewport');
  }
  assert.equal(requests.filter(r=>r.method!=='GET').length,0,'Discovery/navigation/selection must not mutate the controller');
  assert.equal(requests.some(r=>r.url.includes('unexpected-image')),false);
  mode='unavailable';await ev('localStorage.clear()');await call('Page.reload');
  await wait("document.getElementById('updates-status')?.textContent.includes('private or inaccessible')");
  assert.equal(await ev("document.getElementById('firmware-update-link').hidden"),true);
  assert.deepEqual(errors,[]);
  console.log('Real browser firmware updates: stable/beta selection, unknown capabilities, footer/focus, plain notes, mobile layout, access errors and GET-only behavior passed.');
 }finally{await call('Fetch.disable');ws.close();}
})().catch(error=>{console.error(error);process.exitCode=1;});
