const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
(async()=>{
 const elements={},events={};
 function element(id){return elements[id]??=(Object.defineProperty({textContent:'',open:false,addEventListener:(event,cb)=>events[id+':'+event]=cb},'innerHTML',{set:()=>{throw Error('Unsafe HTML rendering');}}));}
 let now=0,requests=0,fresh=true,resolve;
 const state={view:'debug',network:{enable_debug_tab:true},session:{boot_id:'boot'},cover:{}};
 const reply={schema_version:1,available:true,current_boot:'boot',reset_reason:'SOFTWARE',retained_boots:2,
  wifi:{context:{firmware:'a'.repeat(64),boot_id:'previous',uptime_ms:1200,free_heap:170000,minimum_heap:150000},same_boot:false,active_in_recorded_boot:true,first_reason:8,last_reason:2,rssi:-80,bssid:'01:02:03:04:05:06',retries:2,retry_result:12295,next_wait_ms:80000,outage_ms:null},
  fault:{message:'<img src=x onerror=alert(1)>',position:null,target:1500,context:{firmware:'b'.repeat(64),boot_id:'previous',uptime_ms:500,free_heap:180000,minimum_heap:160000}}};
 const api={state,now:()=>now,freshCover:()=>fresh,request:()=>{requests++;return new Promise(r=>resolve=r);}};
 const document={hidden:false,getElementById:element,addEventListener:(e,cb)=>events[e]=cb};
 vm.runInNewContext(fs.readFileSync('data/ui/retained.js','utf8'),{window:{coverAPI:api},document,Number,Infinity});
 const flush=()=>new Promise(r=>setImmediate(r));
 await api.retained.poll();assert.equal(requests,0); // Closed means no requests.
 element('debug-retained').open=true;events['debug-retained:toggle']();assert.equal(requests,1);
 resolve(reply);await flush();assert.match(element('retained-wifi').textContent,/earlier boot/);
 assert.equal(element('retained-fault').textContent,reply.fault.message);
 assert.equal(element('retained-wifi-heap').textContent,'170000 / 150000 bytes');
 assert.match(element('retained-fault-position').textContent,/Unknown/);
 await api.retained.poll();assert.equal(requests,1); // At most once per 5 seconds.
 for(const change of [()=>document.hidden=true,()=>state.view='overview',()=>state.cover.moving=true,()=>state.cover.holding=true,()=>state.cover.maintenance={owner:'ota'},()=>state.session.setup_only=true]){
  now+=6000;change();await api.retained.poll();assert.equal(requests,1);
  document.hidden=false;state.view='debug';state.cover={};state.session.setup_only=false;
 }
 fresh=false;api.retained.render();assert.match(element('retained-status').textContent,/offline/);
 await api.retained.poll();assert.equal(requests,1);fresh=true;
 now+=6000;const pending=api.retained.poll();assert.equal(requests,2);
 state.session.boot_id='new-boot';events.controllerrestart();resolve(reply);await pending;
 assert.equal(element('retained-fault').textContent,'None recorded'); // Old response cannot cross boots.
 element('debug-retained').open=false;now+=6000;await api.retained.poll();assert.equal(requests,2);
 state.network.enable_debug_tab=false;state.debugSession=true;element('debug-retained').open=true;
 const sessionPoll=api.retained.poll();assert.equal(requests,3);
 resolve({...reply,current_boot:'new-boot'});await sessionPoll;
 state.debugSession=false;now+=6000;await api.retained.poll();assert.equal(requests,3);
 console.log('Retained Debug panel: on-demand polling, safe text, past-boot context, cadence, operation gates and restart races passed');
})().catch(e=>{console.error(e);process.exitCode=1;});
