const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync('data/ui/diagnostics.js','utf8');
function fixture(handler){
 const elements={},calls=[],blobs=[],downloads=[],revoked=[],timers=[];
 const state={session:{boot_id:'boot-1',firmware_id:'firmware-1',token:'private-session-value',setup_only:false},
  cover:{state:'FAULT',fault:'Communication lost',resources:{boot_id:'boot-1'},saved_profile:{open_speed:100},open:2953,closed:1143},
  network:{ssid:'Home network',saved_ssid:'Home network',password:'wifi-private',networks:[{ssid:'Neighbour'}]},
  scope:{enabled:true},coverAt:9000,networkAt:8000,scopeAt:7000,events:[],debugMessages:[],view:'configuration'};
 const session=()=>({...state.session});
 const responses={session, status:()=>state.cover,network:()=>state.network,'alpaca/status':()=>state.scope,
  'motion/trace':()=>({boot_id:'boot-1',operation:1,samples:[{ms:100,position:null,disposition:'read_failed'}]}),
  'heartbeat/trace':()=>({boot_id:'boot-1',fault_age_ms:500,http:[]}),
  'diagnostics/servo':()=>({boot_id:'boot-1',available:true,current:{failed_reads:3},fault:{reason:'Repeated position read failure',motion:{target:2837}}}),
  'debug/retained':()=>({current_boot:'boot-1',available:true,fault:{message:'password="two secret words" token=another-private'}}),
  debug:()=>({boot_id:'boot-1',sequence_epoch:1,available:true,more:true,next_after:16,entries:[{message:'Normal event'}]}),
  'debug?after=16&boot_id=boot-1&sequence_epoch=1':()=>({boot_id:'boot-1',sequence_epoch:1,available:true,more:false,next_after:20,entries:[{message:'secret=event-private'}]})};
 const api={state,now:()=>10000,request:async(path,options)=>{
  calls.push(path);assert.equal(options,undefined,'Only read-only requests');
  const response=handler?await handler(path,state,responses):responses[path]?.();
  assert.notEqual(response,undefined,'Unexpected endpoint '+path);
  return structuredClone(response);
 }};
 const document={getElementById:id=>elements[id]??=( {disabled:false,textContent:''}),
  createElement:()=>({click(){downloads.push({name:this.download,url:this.href});},remove(){}}),body:{append(){}}};
 vm.runInNewContext(source,{window:{coverAPI:api},document,navigator:{onLine:true,userAgent:'Test browser'},Date,JSON,Math,Number,Error,
  Blob,URL:{createObjectURL:blob=>{blobs.push(blob);return 'blob:test';},revokeObjectURL:url=>revoked.push(url)},
  setTimeout:(fn,ms)=>{timers.push(ms);queueMicrotask(fn);}});
 return {api,state,elements,calls,blobs,downloads,revoked,timers};
}
(async()=>{
 const f=fixture();
 f.state.debugMessages=[{message:'authorization: Bearer browser-private\npassword=browser-password',token:'nested-private'},
  {message:'Session private-session-value',detail:{api_key:'key-private',refresh_token:'refresh-private'}}];
 const original=structuredClone(f.state);
 await f.api.diagnostics.download();
 assert.equal(f.blobs.length,1);assert.equal(f.revoked[0],'blob:test');
 assert.match(f.downloads[0].name,/^telescope-cover-diagnostics-.*\.json$/);
 assert.equal(f.blobs[0].type,'application/json');
 const raw=await f.blobs[0].text(),report=JSON.parse(raw);
 for(const secret of ['private-session-value','wifi-private','two secret words','another-private','browser-private','browser-password','nested-private','key-private','refresh-private','event-private','Neighbour'])assert(!raw.includes(secret),secret);
 assert.equal(report.consistency,'same_boot');assert.equal(report.partial,false);
 assert.equal(report.sections.controller.data.state,'FAULT');assert.equal(report.sections.controller.data.closed,1143);
 assert.equal(report.sections.configuration.data.ssid,'Home network');
 assert.equal(report.sections.motion_trace.data.samples[0].position,null);
 assert.equal(report.sections.servo_evidence.data.fault.motion.target,2837);
 assert.equal(report.sections.controller_events.data.pages.length,2);assert.equal(report.sections.controller_events.data.complete,true);
 assert(f.timers.filter(ms=>ms===1100).length>=2);
 assert.deepEqual(f.state,original,'Collection never mutates state or drafts');
 assert.equal(f.elements['cfg-download-diagnostics'].disabled,false);
 assert.match(f.elements['cfg-download-message'].textContent,/download started/);

 // Offline export preserves frozen caches with ages and explicit failures.
 const offline=fixture(()=>{throw Error('Network unavailable');});
 const cached=await offline.api.diagnostics.collect();
 assert.equal(cached.partial,true);assert.equal(cached.consistency,'unverified');
 assert.equal(cached.sections.controller.cached,true);assert.equal(cached.sections.controller.cache_age_ms,1000);
 assert.equal(cached.sections.configuration.cache_age_ms,2000);assert.equal(cached.sections.retained_failure.data,null);
 assert.deepEqual(offline.calls,['session']);
 for(const update of [{active:true},{busy:true},{repeats:{}},{cover:{moving:true}},{cover:{holding:true}},{cover:{maintenance:{locked:true}}},{cover:{ota:{active:true}}},{network:{busy:true}}]){
  const paused=fixture();Object.assign(paused.state,update);
  const r=await paused.api.diagnostics.collect();assert.equal(paused.calls.length,0);assert(r.partial);
 }
 // AP users can get their basic status/configuration; detailed access stays gated.
 const setup=fixture();setup.state.session.setup_only=true;
 const ap=await setup.api.diagnostics.collect();assert(ap.partial);assert(!setup.calls.some(p=>p.startsWith('debug')));
 assert.equal(ap.sections.configuration.cached,false);

 let sessions=0;
 const restart=fixture((path,state,responses)=>path==='session'?{...state.session,boot_id:++sessions===1?'boot-1':'boot-2'}:responses[path]());
 const restarted=await restart.api.diagnostics.collect();assert.equal(restarted.consistency,'controller_restarted');assert(restarted.partial);
 const eventRestart=fixture((path,state,responses)=>path==='debug'?{...responses.debug(),boot_id:'different',more:false}:responses[path]());
 assert.equal((await eventRestart.api.diagnostics.collect()).consistency,'controller_restarted');
 const servoRestart=fixture((path,state,responses)=>path==='diagnostics/servo'?{...responses[path](),boot_id:'different'}:responses[path]());
 assert.equal((await servoRestart.api.diagnostics.collect()).consistency,'controller_restarted');
 const oldFirmware=fixture((path,state,responses)=>{if(path==='diagnostics/servo')throw Error('HTTP 404');return responses[path]();});
 const legacy=await oldFirmware.api.diagnostics.collect();assert(legacy.partial);assert.equal(legacy.sections.servo_evidence.data,null);
 const pagedRestart=fixture((path,state,responses)=>path.startsWith('debug?')?{...responses[path](),boot_id:'different'}:responses[path]());
 const mixed=await pagedRestart.api.diagnostics.collect();assert(mixed.partial);assert.equal(mixed.consistency,'controller_restarted');
 const tokens=fixture((path,state,responses)=>{
  if(path==='session')return {...state.session,token:'session-reply-private'};
  if(path==='status'){state.session.token='replacement-private';state.debugMessages.push({message:'Old private-session-value new replacement-private reply session-reply-private'});}
  return responses[path]();
 });
 const redacted=JSON.stringify(await tokens.api.diagnostics.collect());
 for(const secret of ['private-session-value','replacement-private','session-reply-private'])assert(!redacted.includes(secret));
 const failure=fixture((path,state,responses)=>{if(path==='network')throw Error('HTTP 503');return responses[path]();});
 const partial=await failure.api.diagnostics.collect();assert(partial.partial);assert(partial.sections.configuration.cached);assert(!partial.sections.telescope.cached);
 const moving=fixture((path,state,responses)=>path==='status'?{...state.cover,moving:true}:responses[path]());
 const mid=await moving.api.diagnostics.collect();assert.deepEqual(moving.calls,['session','status']);assert.equal(mid.sections.configuration.cached,true);
 const bounded=fixture((path,state,responses)=>path.startsWith('debug?')?{...responses.debug(),next_after:Number(new URL('http://test/'+path).searchParams.get('after'))+16}:responses[path]());
 const limit=await bounded.api.diagnostics.collect();assert.equal(limit.sections.controller_events.data.pages.length,8);assert(limit.partial);assert(!limit.sections.controller_events.data.complete);
 const double=fixture();const pending=double.api.diagnostics.download();
 assert(double.api.diagnostics.busy());await double.api.diagnostics.download();await pending;assert.equal(double.blobs.length,1);
 console.log('Diagnostics download: JSON file, redaction, frozen caches, offline/motion/AP gates, restart detection, partial failures, bounded paging and duplicate clicks passed');
})().catch(error=>{console.error(error);process.exitCode=1;});
