const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs'),vm=require('node:vm');
function page({sessionBoot='boot-c',denySession=false,storedAutomatic=undefined}={}){
 const nodes=new Map(),calls=[],timers=[];
 const node=id=>{assert.notEqual(id,'key','The UI must never request a manual key field');if(!nodes.has(id))nodes.set(id,{textContent:'',disabled:false,checked:false,value:0});return nodes.get(id);};
 const state={profile:'bench-ota-v1',servo_operations:false,accepted:true,build:3,version:'0.1.0-beta.3',elf:'a'.repeat(64),boot:'boot-c',nonce:'nonce-c'};
 const manifest='product=telescope-cover-ota-bench\nprotocol=1\nlayout=cover-4mb-v1\nsettings=preserve-cover-app-v1\nsource_build=3\nsource_elf='+state.elf+'\ntarget_build=4\ntarget_elf='+'b'.repeat(64)+'\nsize=1000000\nsha256='+'c'.repeat(64)+'\n';
 const release={build:4,tag:'v0.1.0-beta.4',application:'bench-4.bin',manifest,signature:'d'.repeat(128),notes:'Test automatic authorization'};
 const fetch=async(url,options)=>{
  calls.push({url,options});
  if(url==='/api/bench/status')return new Response(JSON.stringify(state));
  if(url==='/api/bench/session')return new Response(JSON.stringify({boot:sessionBoot,nonce:state.nonce,update_token:'e'.repeat(64)}),{status:denySession?403:200});
  if(url.startsWith('https://api.github.com/'))return new Response(JSON.stringify([{tag_name:release.tag,draft:false,prerelease:true,published_at:'2026-11-12T20:00:00Z'}]));
  if(url.includes('index.json'))return new Response(JSON.stringify({schema:'telescope-cover-bench-catalog/1',releases:[release]}));
  throw Error('Unexpected request '+url);
 };
 const saved=new Map();if(storedAutomatic!==undefined)saved.set('cover.bench.autoCheck.v1',String(storedAutomatic));
 const storage={getItem(k){if(storedAutomatic===undefined)throw Error('Storage unavailable');return saved.get(k)||null;},setItem(k,v){if(storedAutomatic===undefined)throw Error('Storage unavailable');saved.set(k,v);}};
 const context={document:{getElementById:node,hidden:false,addEventListener(){}},window:{localStorage:storage,sessionStorage:storage,addEventListener(){}},location:{href:'http://192.168.1.135/'},fetch,Response,TextDecoder,Uint8Array,URL,URLSearchParams,AbortSignal,Date,Math,Number,performance,
  setTimeout, setInterval:(fn,ms)=>timers.push({fn,ms})};
 vm.runInNewContext(fs.readFileSync('data/bench/app.js','utf8'),context);
 return {node,calls,saved};
}
async function settled(p){for(let i=0;i<100;i++){if(/^(Checked |Release check failed|Controller connection failed|Automatic checks are off)/.test(p.node('discovery').textContent))return;await new Promise(r=>setTimeout(r,5));}throw Error('Page did not settle');}
test('bench automatically loads boot-bound authorization without a key field or saved browser data',async()=>{
 const p=page();await settled(p);
 assert.match(p.node('available').textContent,/Update available/);
 const session=p.calls.find(c=>c.url==='/api/bench/session');assert(session);assert.equal(session.options.headers['X-Bench-Session'],'1');
 assert.equal(p.node('install').disabled,true,'Explicit user confirmation remains required');
 p.node('confirm').checked=true;p.node('confirm').onchange();
 assert.equal(p.node('install').disabled,false);
 assert.equal(p.calls.filter(c=>c.options.method==='POST').length,0,'Discovery and automatic authorization must never install firmware');
});
test('mismatched boot and failed automatic authorization keep installation disabled',async()=>{
 for(const options of [{sessionBoot:'old-boot'},{denySession:true}]){
  const p=page(options);await settled(p);p.node('confirm').checked=true;p.node('confirm').onchange();
  assert.equal(p.node('install').disabled,true);assert.match(p.node('discovery').textContent,/failed/);
  assert.equal(p.calls.filter(c=>c.options.method==='POST').length,0);
 }
});

test('automatic checks default on; disabling is remembered and manual checks still work',async()=>{
 const p=page({storedAutomatic:true});await settled(p);
 assert.equal(p.node('automatic-check').checked,true);assert.equal(p.node('header-update').hidden,false);
 p.node('automatic-check').checked=false;p.node('automatic-check').onchange();
 assert.equal(p.saved.get('cover.bench.autoCheck.v1'),'false');
 const off=page({storedAutomatic:false});await settled(off);
 assert.equal(off.node('automatic-check').checked,false);assert.equal(off.node('header-update').hidden,true);
 assert.equal(off.calls.filter(c=>c.url.startsWith('https://')).length,0,'Disabled automatic checking must not contact release services on load');
 await off.node('check').onclick();
 assert.match(off.node('available').textContent,/Update available/);assert.equal(off.node('header-update').hidden,false);
 assert.equal(off.node('automatic-check').checked,false,'Manual check does not reenable automatic checks');
});
