const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
// Exercise the actual footer/About renderer without starting networking or motion.
const source=fs.readFileSync('data/ui/app.js','utf8');
const body=source.slice(source.indexOf(' function renderDock(){'),source.indexOf(' function renderCpuLoad(){'));
const nodes=new Map(),el=id=>{if(!nodes.has(id))nodes.set(id,{textContent:'',href:'',classList:{toggle(){}}});return nodes.get(id);};
const state={session:{firmware_id:'elf-id',firmware:{version:'0.1.0-beta.1',release:true,commit:'abc123',profile:'web_control_usb',built_at:'2026-11-11T20:00:00Z'}},cover:{torque:false,calibrated:false}};
const context={state,$:el,text:(id,value)=>el(id).textContent=value,disable(){},api:{freshCover:()=>true,servoSetupOnly:()=>false},document:{querySelector:()=>el('dock')}};
vm.createContext(context);vm.runInContext(body+'\nrenderDock();',context);
assert.match(el('sessionNote').textContent,/Firmware 0.1.0-beta.1/);assert.equal(el('cfg-firmware-profile').textContent,'web_control_usb');assert.equal(el('cfg-firmware-commit').textContent,'abc123');assert.equal(el('cfg-firmware-id').textContent,'elf-id');assert.match(el('cfg-firmware-notes').href,/tag\/v0.1.0-beta.1$/);
state.session.firmware={version:'0.1.0-dev+abc123.dirty',release:false};vm.runInContext('renderDock()',context);assert.match(el('sessionNote').textContent,/dirty/);assert.equal(el('cfg-firmware-notes').href,'https://github.com/Kbdavis/Telescope-Cover/releases');
delete state.session.firmware;vm.runInContext('renderDock()',context);assert.match(el('sessionNote').textContent,/version unavailable/);assert.equal(el('cfg-firmware-built').textContent,'Unavailable');
const html=fs.readFileSync('data/ui/index.html','utf8');for(const id of ['cfg-about','cfg-firmware-version','cfg-firmware-notes'])assert(html.includes(`id="${id}"`));
assert(fs.readFileSync('data/ui/diagnostics.js','utf8').includes('firmware:s.firmware'));
console.log('Installed version footer, About details, release notes, development labeling and old-firmware fallback passed');
