/* Real embedded UI; loopback fixture 8094 and isolated Chrome CDP 9226. No hardware. */
const assert=require('node:assert/strict'),fs=require('node:fs');
const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
const HTTP='http://127.0.0.1:'+(process.env.COVER_TEST_HTTP_PORT||8094),CDP='http://127.0.0.1:'+(process.env.COVER_TEST_CDP_PORT||9226);
(async()=>{
 const targets=await(await fetch(CDP+'/json/list')).json();
 const ws=new WebSocket(targets.find(target=>target.type==='page').webSocketDebuggerUrl),pending=new Map(),errors=[];let next=0;
 await new Promise(resolve=>ws.addEventListener('open',resolve,{once:true}));
 ws.addEventListener('message',event=>{const m=JSON.parse(event.data);if(m.id){const p=pending.get(m.id);if(!p)return;clearTimeout(p.timer);pending.delete(m.id);m.error?p.reject(Error(m.error.message)):p.resolve(m.result);}if(m.method==='Runtime.exceptionThrown')errors.push(m.params.exceptionDetails);if(m.method==='Page.javascriptDialogOpening')call('Page.handleJavaScriptDialog',{accept:true}).catch(error=>errors.push(error.message));});
 const call=(method,params={})=>new Promise((resolve,reject)=>{const id=++next,timer=setTimeout(()=>{pending.delete(id);reject(Error('CDP timeout: '+method));},15000);pending.set(id,{resolve,reject,timer});ws.send(JSON.stringify({id,method,params}));});
 const ev=async expression=>{const r=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true,userGesture:true});if(r.exceptionDetails)throw Error(r.exceptionDetails.exception?.description||r.exceptionDetails.text);return r.result.value;};
 const wait=async expression=>{for(let n=0;n<120;n++){if(await ev(expression))return;await delay(100);}throw Error('Timeout: '+expression);};
 const click=id=>ev(`document.getElementById('${id}').click()`);
 const patch=async body=>{await fetch(HTTP+'/test/patch',{method:'POST',body:JSON.stringify(body)});await ev(body.controls?.drop_status?'coverAPI.cover().catch(()=>{})':'coverAPI.cover()');};
 const reload=async()=>{await ev('window.__beforeReload=true');await call('Page.reload',{ignoreCache:true});await wait("!window.__beforeReload&&window.coverAPI?.state.network&&coverAPI.state.cover&&coverAPI.state.session");};
 const input=(id,value)=>ev(`(()=>{const e=document.getElementById('${id}');e.value=${JSON.stringify(String(value))};e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));})()`);
 const done=()=>wait('!coverAPI.state.busy&&!coverAPI.state.active&&!coverAPI.state.cover.moving&&!coverAPI.state.cover.holding');
 const step=async n=>{await ev(`calibrationUI.navigate(${n})`);await delay(450);};
 const events=async()=>await(await fetch(HTTP+'/test/events')).json();
 const arc=(closed,open,direction)=>({circular:false,draft_circular:false,teaching:false,rollover_supported:false,state:'UNKNOWN',fault:'',ready:true,moving:false,holding:false,torque:false,position:closed,
  calibration_only:false,calibrated:true,dirty:false,calibration_review:false,opening_direction:direction,draft_direction:direction,
  travel_counts:Math.abs(open-closed),draft_travel_counts:Math.abs(open-closed),closed,open,draft_closed:closed,draft_open:open,
  minimum:0,maximum:4095,draft_minimum:0,draft_maximum:4095,saved_minimum:0,saved_maximum:4095});
 try{
  await call('Runtime.enable');await call('Page.enable');await call('Emulation.setFocusEmulationEnabled',{enabled:true});
  await call('Page.navigate',{url:'about:blank'});await wait("location.href==='about:blank'&&!window.coverAPI");errors.length=0;
  await fetch(HTTP+'/test/reset',{method:'POST'});
  await fetch(HTTP+'/test/patch',{method:'POST',body:JSON.stringify({controls:{beta:true}})});
  await call('Page.navigate',{url:HTTP+'/#overview'});
  await wait('window.coverAPI?.state.network&&coverAPI.state.cover&&coverAPI.state.session');
  await click('nav-calibration');await step(0);for(const id of ['present','supported','stowed'])await click(id);await click('nav-overview');
  for(const [closed,open,direction] of [[5,105,1],[105,5,-1],[3990,4090,1],[4090,3990,-1]]){
   await patch({cover:arc(closed,open,direction)});
   for(const [raw,percent] of [[closed,0],[(closed+open)/2,50],[open,100]]){
    await patch({cover:{position:raw}});
    assert.equal(await ev("document.getElementById('ov-travel').textContent"),percent+'% travel');
    assert.match(await ev("document.getElementById('ov-position').textContent"),new RegExp(raw+' counts'));
   }
   await click('nav-calibration');await ev('calibrationUI.loadFields();calibrationUI.render()');await step(1);
   assert.equal(await ev("document.getElementById('plus').getAttribute('aria-label').startsWith('Toward open')"),true);
   assert.equal(await ev("document.getElementById('position').textContent"),'100');
   await click('nav-overview');
  }
  await patch({cover:{...arc(1048,3048,1),minimum:1000,maximum:3100,saved_minimum:1000,saved_maximum:3100,draft_minimum:1000,draft_maximum:3100,position:900}});
  assert.match(await ev("document.getElementById('ov-travel').textContent"),/Outside allowed travel/);
  assert.equal(await ev("document.getElementById('ov-lid').style.opacity"),'0.15');
  await patch({cover:{position:null}});assert.equal(await ev("document.getElementById('ov-travel').textContent"),'Travel unavailable');
  await patch({cover:{...arc(4000,100,1),travel_counts:196,draft_travel_counts:196,position:4050}});
  assert.match(await ev("document.getElementById('ov-travel').textContent"),/needs review/);
  await click('nav-calibration');await ev('calibrationUI.loadFields()');await step(1);
  await patch({cover:{position:100}});await click('chooseOpen');assert.equal(await ev("document.getElementById('capture').disabled"),true);
  await patch({cover:{position:4090}});await ev("document.querySelector('[data-count=\"10\"]').click()");
  assert.equal(await ev("document.getElementById('plus').disabled"),true);
  assert.match(await ev("document.getElementById('plus').title"),/Prepare/);
  assert.equal((await events()).length,0,'Displaying or selecting unsupported arcs sends no command');
  // Opening Teach directly explains the session gate and links to Prepare.
  assert.equal(await ev("document.getElementById('teachStartNotice').hidden"),false);
  assert.match(await ev("document.getElementById('teachStartReason').textContent"),/Begin teaching/);
  await click('teachPrepare');assert.equal(await ev("document.querySelector('[data-panel=\"0\"]').hidden"),false);
  assert.equal((await events()).length,0,'The recovery link only navigates');await step(1);
  // An ambiguous saved record is diagnostic evidence, not calibration permission.
  await patch({cover:{calibration_review:true,review_closed_raw:4000,review_open_raw:100,calibrated:false,ready:false,calibration_only:true,draft_direction:0,draft_open:null}});
  assert.equal(await ev("document.getElementById('calibrationReviewNotice').hidden"),false);
  assert.match(await ev("document.getElementById('calibrationReviewNotice').textContent"),/CLOSED 4000 \/ OPEN 100/);
  assert.equal((await events()).length,0);
  // Fixed assembly workflow: capture CLOSED, increase, capture OPEN; no direction question.
  await patch({cover:arc(2800,2900,1)});await ev('calibrationUI.loadFields()');await step(0);
  for(const id of ['present','supported','stowed'])if(!await ev(`document.getElementById('${id}').checked`))await click(id);
  await click('prepareNext');await done();await step(1);assert.equal(await ev("document.getElementById('teachStartNotice').hidden"),true);assert.equal(await ev("document.getElementById('minus').disabled"),false);assert.equal(await ev('document.querySelectorAll("[data-step]").length'),4);assert.equal(await ev('document.getElementById("minimum")'),null);
  await click('minus');await done();await delay(500);assert.equal(await ev('coverAPI.state.cover.position'),2790);
  await click('capture');await done();assert.equal(await ev('coverAPI.state.cover.draft_closed'),2790);
  assert.match(await ev("document.getElementById('capture').textContent"),/OPEN/);
  assert.equal(await ev('coverAPI.state.cover.draft_direction'),1);
  assert.equal(await ev("document.getElementById('directionSetup')"),null);
  await step(1);const beforeSelect=(await events()).length;await click('chooseClosed');assert.equal((await events()).length,beforeSelect,'Endpoint selection does not move or capture');
  await click('capture');await done();assert.equal(await ev('coverAPI.state.cover.draft_closed'),2790);
  await ev("document.querySelector('[data-count=\"100\"]').click()");await click('plus');await done();await delay(500);
  assert.equal(await ev('coverAPI.state.cover.position'),2890); // Past the former zero at 2853.
  assert.equal(await ev("document.getElementById('capture').disabled"),false);await click('capture');await done();
  assert.equal(await ev('coverAPI.state.cover.draft_travel_counts'),100);
  await step(2);await click('save');await done();assert.equal(await ev('coverAPI.state.cover.dirty'),false);
  await step(3);await click('testClose');await done();await delay(500);await click('testOpen');await done();
  assert.equal(await ev('calibrationState.s.tested.open&&calibrationState.s.tested.closed'),true);
  const physicalEvents=(await events()).filter(e=>/^(jog|open$|close$)/.test(e.path));
  assert.deepEqual(physicalEvents.map(e=>e.path),['jog-minus','jog-plus','close','open']);
  // A reload loses physical confirmations, but resuming must preserve the draft.
  await patch({cover:{teaching:true,dirty:true,draft_closed:2790,draft_open:2890,draft_direction:1,draft_travel_counts:100}});
  await reload();await step(1);
  assert.equal(await ev("document.getElementById('teachStartNotice').hidden"),false);
  await click('teachPrepare');
  for(const id of ['present','supported','stowed'])await click(id);
  const beforeResume=(await events()).length;await click('prepareNext');await delay(300);
  assert.equal((await events()).length,beforeResume,'Resume sends no begin/reset command');
  assert.equal(await ev('coverAPI.state.cover.draft_closed'),2790);
  assert.equal(await ev('coverAPI.state.cover.draft_open'),2890);
  assert.equal(await ev("document.getElementById('teachStartNotice').hidden"),true);
  await patch({cover:{teaching:false,dirty:false,...arc(2790,1890,-1)}});
  // Relative manual controls retain the same negative opening direction.
  await click('nav-manual');await click('manual-enable');await click('manual-accept');
  await wait("!document.getElementById('manual-fields').disabled");
  await click('manual-hold-torque'); // Keep this direction test focused on released steps.
  const manualStart=await ev('coverAPI.state.cover.position');
  await click('manual-plus');await done();assert.equal(await ev('coverAPI.state.cover.position'),manualStart-10);
  await click('manual-minus');await done();assert.equal(await ev('coverAPI.state.cover.position'),manualStart);
  assert.deepEqual((await events()).filter(e=>e.path.startsWith('manual/jog')).map(e=>e.path),['manual/jog-minus','manual/jog-plus']);
  await click('nav-calibration');await step(3);
  // Endpoint tests accept confirmed torque ON without a preparatory Stop.
  await patch({cover:{torque:true,state:'OPEN'}});
  assert.equal(await ev("document.getElementById('testOpen').disabled"),false);
  assert.equal(await ev("document.getElementById('testClose').disabled"),false);
  assert.equal(await ev("document.getElementById('testStopPointer')"),null);
  const poweredTest=(await events()).length;await click('testClose');await done();
  assert.deepEqual((await events()).slice(poweredTest).filter(e=>e.path!=='heartbeat').map(e=>e.path),['close']);
  for(const width of [320,390,768,1440]){
   await call('Emulation.setDeviceMetricsOverride',{width,height:1000,deviceScaleFactor:1,mobile:width<500});await call('Emulation.setPageScaleFactor',{pageScaleFactor:1});
   for(const n of [0,1,2,3]){
    await step(n);assert.equal(await ev('document.documentElement.scrollWidth<=document.documentElement.clientWidth'),true,'No overflow '+width+' step '+n);
    assert.equal(await ev("(()=>{const r=document.getElementById('stop').getBoundingClientRect();return r.top>=visualViewport.offsetTop&&r.bottom<=visualViewport.offsetTop+visualViewport.height&&r.left>=visualViewport.offsetLeft&&r.right<=visualViewport.offsetLeft+visualViewport.width})()"),true);
   }
   const screenshot=await call('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});fs.writeFileSync('/tmp/cover-travel-'+width+'.png',Buffer.from(screenshot.data,'base64'));
  }
  // Reviewing taught endpoints increases only an insufficient draft timeout;
  // it requires no manual field edit, save or actuator request.
  const shortProfile={open_speed:100,close_speed:100,jog_speed:100,acceleration:10,timeout_ms:17000};
  await patch({cover:{...arc(1143,2953,1),teaching:true,dirty:true,position:2953,draft_profile:shortProfile,saved_profile:shortProfile}});
  await ev('calibrationUI.loadFields()');await step(1);
  const beforeAuto=(await events()).length;await click('teachNext');await done();
  await wait('!document.querySelector(\'[data-panel="2"]\').hidden');
  assert.equal(await ev('coverAPI.state.cover.draft_profile.timeout_ms'),27000);
  assert.equal(await ev('coverAPI.state.cover.saved_profile.timeout_ms'),17000);
  assert.equal(await ev('coverAPI.state.cover.dirty'),true);
  assert.equal(await ev("document.getElementById('timeout').value"),'27');
  assert.equal(await ev("document.getElementById('timeoutWarning').textContent"),'');
  assert.equal(await ev("document.getElementById('save').disabled"),false);
  const autoEvents=(await events()).slice(beforeAuto);
  assert.deepEqual(autoEvents.map(e=>e.path),['calibration/profile']);
  assert.deepEqual(await ev('coverAPI.state.cover.draft_profile'),{...shortProfile,timeout_ms:27000});
  await step(1);await click('teachNext');await done();
  assert.equal((await events()).length,beforeAuto+1,'A sufficient timeout requires no further command');
  // Never shorten a longer timeout or silently exceed the existing 30-second cap.
  for(const [speed,timeout] of [[100,30000],[50,17000]]){
   await patch({cover:{draft_profile:{...shortProfile,open_speed:speed,timeout_ms:timeout}}});
   await ev('calibrationUI.loadFields()');await step(1);
   const beforeReview=(await events()).length;await click('teachNext');await done();
   assert.equal((await events()).length,beforeReview);
   assert.equal(await ev('coverAPI.state.cover.draft_profile.timeout_ms'),timeout);
   if(speed===50){assert.match(await ev("document.getElementById('timeoutWarning').textContent"),/30 s timeout limit/);assert.equal(await ev("document.getElementById('save').disabled"),true);}
  }
  // Explicit timeout suggestion only edits the form. Applying while faulted
  // preserves FAULT; recovery and saving are separate actions.
  const p={open_speed:100,close_speed:100,jog_speed:100,acceleration:10,timeout_ms:5000};
  await patch({cover:{...arc(1048,3048,1),state:'FAULT',ready:false,fault:'Movement timeout',target:3048,position:2048,draft_profile:p,saved_profile:p}});
  await ev('calibrationUI.loadFields();calibrationUI.render()');await step(2);
  assert.match(await ev("document.getElementById('durationEstimate').textContent"),/22.5 s/);
  assert.match(await ev("document.getElementById('timeoutWarning').textContent"),/29 s/);
  assert.equal(await ev("document.getElementById('endpointTimeoutNotice').hidden"),false);
  const count=(await events()).length;await click('adjustTimeout');
  assert.equal(await ev("document.getElementById('timeout').value"),'29');assert.equal((await events()).length,count);
  assert.equal(await ev('coverAPI.state.cover.draft_profile.timeout_ms'),5000);
  await click('inspected');await click('applyProfile');await done();
  assert.equal(await ev('coverAPI.state.cover.state'),'FAULT');assert.equal(await ev('coverAPI.state.cover.fault'),'Movement timeout');
  assert.equal(await ev('coverAPI.state.cover.draft_profile.timeout_ms'),29000);
  assert.equal(await ev("document.getElementById('testOpen').disabled"),true);
  assert.deepEqual((await events()).slice(count).map(e=>e.path),['calibration/profile']);
  await reload();assert.equal(await ev('coverAPI.state.cover.state'),'FAULT');assert.equal(await ev("document.getElementById('inspected').checked"),false);
  for(const id of ['present','supported','stowed'])if(!await ev(`document.getElementById('${id}').checked`))await click(id);
  // Qualified circular feedback stays continuous through zero, in both directions.
  for(const direction of [1,-1]){
   const closed=direction>0?2386:100,open=direction>0?100:2386;
   await patch({cover:{...arc(closed,open,direction),circular:true,draft_circular:true,rollover_supported:true,travel_counts:1810,draft_travel_counts:1810,position:direction>0?4090:5}});
   await ev('calibrationUI.loadFields();calibrationUI.render()');await step(1);
   const before=Number(await ev("document.getElementById('position').textContent"));
   await patch({cover:{position:direction>0?5:4090}});
   const after=Number(await ev("document.getElementById('position').textContent"));
   assert(after>before&&after-before<1,'Rollover progress is continuous');
   await patch({cover:{teaching:true}});await ev("document.querySelector('[data-count=\"10\"]').click()");
   assert.equal(await ev(`document.getElementById('${direction>0?'plus':'minus'}').disabled`),false);
  }
  assert.deepEqual(errors,[]);
  console.log('Travel UI: both directions, rollover rejection, explicit workflow/tests, fault-preserving timeout edits and 320–1440px layouts passed');
  await call('Page.navigate',{url:'about:blank'});
 }finally{ws.close();}
})().catch(error=>{console.error(error);process.exitCode=1;});
