const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const html=fs.readFileSync('data/beta_notice.html','utf8');
function setup(ok){
 const events={},requests=[];
 const dialog={showModal(){this.open=true;},close(){this.open=false;},remove(){this.removed=true;},addEventListener(n,f){events[n]=f;}};
 const checkbox={checked:false,disabled:false,focus(){},addEventListener(n,f){events[n]=f;}};
 const status={};
 vm.runInNewContext(html.split('<script>')[1].split('</script>')[0],{
  document:{getElementById:id=>({betaNotice:dialog,betaAccept:checkbox,betaNoticeStatus:status}[id])},
  AbortSignal:{timeout:()=>({})},
  fetch:async(url,options)=>{requests.push({url,options});return {ok,text:async()=> 'Save failed'};}
 });
 return {dialog,checkbox,status,events,requests};
}
(async()=>{
 const s=setup(true);assert(s.dialog.open);assert.equal(s.requests.length,0);
 let prevented=false;s.events.cancel({preventDefault(){prevented=true;}});assert(prevented);
 await s.events.change();assert.equal(s.requests.length,0);
 s.checkbox.checked=true;await s.events.change();
 assert.equal(s.requests[0].url,'/api/beta/accept');assert.equal(s.requests[0].options.body,'accepted=yes');
 assert(s.dialog.removed&&!s.dialog.open);
 const fail=setup(false);fail.checkbox.checked=true;await fail.events.change();
 assert(fail.dialog.open&&!fail.dialog.removed&&!fail.checkbox.checked&&!fail.checkbox.disabled);
 assert.match(fail.status.textContent,/not confirmed saved/);
 console.log('Beta acknowledgment: modal, explicit acceptance, successful save and retry checks passed');
})().catch(e=>{console.error(e);process.exit(1);});
