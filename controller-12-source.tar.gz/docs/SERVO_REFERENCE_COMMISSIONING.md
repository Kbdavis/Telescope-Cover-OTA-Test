# Fixed-reference commissioning

The unsafe automatic `web_control_reference_dev` build alias was removed during release cleanup on 2026-11-12. References below describe historical evidence, not an available deployment target.

Current status (2026-10-29): **moving commands remain unqualified at both tested
references**. After the factory-offset hold below passed, the user's 100-count
OPEN command requested 3923 → 3823 but moved toward CLOSED, reaching 3947.
Register 42 retained the correct 3823 goal, and the exact factory snapshot still
matched at offset 85. The direction guard stopped motion and confirmed torque
OFF. Thus the successful hold did not establish a repair, and the failure cannot
be attributed solely to offset 1328. No further automatic reference changes,
button inversions or weakened direction guard are justified by these readings.

Offset 1328 is no longer qualified for operation.
The detached servo moved 3192 → 3220 during a current-position hold, despite a
stored goal of 3192 and the exact reference snapshot matching. After explicit
user approval, offset registers 31–32 alone were restored to factory 85 with
lock 55 remaining 1; all 40 bytes matched the factory snapshot and stationary
feedback shifted 2681 → 3923 (predicted +1243 modulo 4096, within one count).
The repeated 750 ms unloaded hold stayed at 3923 with internal target 3923,
zero speed, no failed reads, and confirmed torque OFF after the intended timed
release. That hold comparison alone did not distinguish reference-dependent
target handling from other servo/runtime behavior, and did not validate any
moving command or boundary crossing. Keep the linkage detached
until supervised bidirectional settling is established. Do not deploy the
automatic `web_control_reference_dev` profile or reinterpret saved offset-1328
endpoints at offset 85. See [MOTION.md](MOTION.md#detached-current-position-hold)
for traces and limitations. The earlier commissioning below is historical.

Status (2026-10-28): the approved detached-shaft test passed. With lock 55
remaining 1, offset 85 → 1328 shifted stationary feedback 2391 → 1148,
exactly −1243. Only configuration bytes 31–32 changed. Supervised moves
2807 → 2905 → 2807 crossed the former zero in both directions at speed 100 /
acceleration 10. Restoring offset 85 recovered the complete factory snapshot.

The initial validated `web_control_reference_dev` firmware was installed on
`cover-dev.local` by OTA; ELF
`a183d4b787886ce326160143fda468a50471aede5ba97dd2b7604ff456bc2f40`.
Startup accepted the update and confirmed durable boot selection. Served UI
assets match the frozen build. Saved calibration migrated from CLOSED 2386 /
OPEN 3464 to 1143 / 2221, preserving physical positions, profile and network
settings. Explicit save and controller reboot preserved the new basis without
double shifting. External servo power-cycle behavior remains unverified.

The installed build prepares the fixed reference with torque OFF and checks the
exact configuration before motion. It accepts an already prepared reference
without writing it again; a servo reset to offset 85 blocks movement until
startup or explicit recovery prepares and verifies it. Normal routes expose no
reference-programming command. Actual crossing of the new raw 4095/0 remains
disabled: the formerly problematic physical path now lies inside one raw range.

After reboot, a browser began teaching and issued movement commands before the
installation script could restore its retained-CLOSED draft. The script's Begin
was rejected; no subsequent automatic motion or draft reset was attempted.
The existing CLOSED remains saved as 1143, but the browser's new draft initially
had neither endpoint captured. Capture CLOSED at the physical closed position
before teaching OPEN. Desired old OPEN near 100 now reads approximately 2953.
Private snapshots and traces are in
`diagnostics/reference-probe-cover-dev-20261028/`.

Follow-up deployment (2026-10-28): ELF
`3c1ffb52c2fd84eb0cdb972ac58d8198627275640ef0c5a499c831e7c2169070`
replaces that build by OTA transaction `a197369653a2554af9bb926ef818b5e3`.
It fixes the assembly's opening direction to +1 in teaching, removes the direction
question and permits stationary development OTA away from CLOSED. Production
keeps its CLOSED policy. The old receiver's actual CLOSED/clean admission was
met for this one-time update: the draft (CLOSED 1151, OPEN not captured) was
backed up, saved calibration restored and the short 1184 → 1148 closing move
completed. Saved CLOSED 1143 / OPEN 2221, bounds, profile and reference remain
unchanged. Post-reboot UI assets match the build exactly, startup and durable
selection are confirmed, and normal endpoint torque remains ON at CLOSED 1148.
The new software passed host, browser and both production/development build
checks. OTA from a physically non-CLOSED position has not yet been bench-tested;
the development admission path was exercised at OPEN/interior positions in
worker tests. Evidence: `diagnostics/fixed-opening-cover-dev-20261028/`.

The user taught CLOSED at raw 2386 and needs increasing travel through the old
boundary to OPEN near 100. A direct wrapped goal was physically tested on the
exact mode-0 factory profile and moved the wrong way. Changing only UI arithmetic
cannot establish the required path.

## Bounded RAM-only experiment

`web_control_reference_probe` contains fixed apply/restore commands, absent from
normal firmware. They require authenticated home-network access, current control
generation, explicit detached/clear acknowledgement, stable torque-OFF feedback,
and the exact factory 40-byte profile. Applying additionally requires an active
teaching session. Restoration can run while the deliberate reference fault is
latched, so rollback does not require enabling movement.

Proposed reference writes (servo ID 1):

| Operation | Address | Value | Bytes, low first |
| --- | --- | --- | --- |
| Apply proposed reference | 31–32 | 1328 (0x0530), previously 85 | `30 05` |
| Restore factory reference after the experiment | 31–32 | 85 (0x0055) | `55 00` |

Register 55 must read **1 before and after**. The tool never writes register 55,
never unlocks EEPROM, never writes mode/phase/limits/resolution, and never retries
an uncertain write. It sends no torque-enable or goal command. Feetech documents
that EEPROM-address writes with lock 1 are not retained across power loss; whether
this unit accepts the proposed offset in RAM must be established experimentally.
If it ignores the locked write, the tool reports failure rather than unlocking it.

The experimentally verified mapping is `new = (old - 1243) mod 4096`, from the
offset change 85 → 1328. CLOSED 2386 would become 1143; OPEN 100 would become 2953,
leaving their physical travel at 1810 counts. Position 4057 would become 2814.
A stationary two-read check verifies the feedback shift before any motion.
Unexpected mapping, failed readback or an uncertain write blocks further motion.

An attempted reference write always latches FAULT, releases torque and invalidates
active calibration, including on failed acknowledgement. Original raw endpoints
remain diagnostic evidence; NVS is not rewritten by the probe. Explicit inspection
and fresh calibration are required before motor testing. A reboot while the probe
reference is present cannot use old saved endpoint coordinates.

## Authorized execution, once approved

1. Preserve the user's current draft, original calibration and full configuration
   snapshots. Try OTA first and meet its actual CLOSED/clean admission checks;
   do not bypass those checks. Controlled preparation movement needs the user
   present with the detached shaft/horn clear.
2. Install the isolated probe, release torque, begin supervised teaching and
   apply the exact proposed offset while keeping lock 1.
3. Check all 40 identity/configuration bytes: only addresses 31–32 may differ.
   Confirm lock 1, torque OFF and the predicted stable position shift. A mismatch
   stops the experiment; do not infer success or try another offset automatically.
4. If verified, perform supervised small moves at speed 100 / acceleration 10
   across the former boundary and back, under heartbeat, timeout and direction
   monitoring. This is physical validation of the reference approach, not a
   claim of loaded-cover or unattended qualification.
5. Restore offset 85 with lock 1, validate full readback and stationary feedback.
   Keep draft/reference bases explicit. A production implementation may use the
   approved fixed RAM reference only after successful validation, with schema
   migration that distinguishes the old and new coordinate bases. Never apply
   old raw endpoints under the new reference without conversion/reteaching.
6. Confirm the factory offset after an external servo power cycle before claiming
   that EEPROM retention behavior has been verified on this unit.

## Offline verification

Driver tests cover rejection of every mismatching factory byte, unlocked EEPROM,
enabled torque and unstable feedback; ignored locked writes; predicted mapping;
fixed restoration; unexpected sign; and absence of any write except address 31.
Worker tests cover deliberate fault latching, calibration invalidation without
motion, rejected repeated apply while faulted, safe fixed restoration and explicit
recovery/reteaching. Both normal and probe PlatformIO builds pass. These tests do
not substitute for hardware evidence.

Sources: [Feetech STS memory table](https://ftservo.github.io/ftservo-wiki/reference/parameter/memory-sts/)
(registers 31, 55 and phase/mode definitions), and the project's measured boundary
failure in [CALIBRATION.md](CALIBRATION.md#detached-shaft-boundary-test--2026-10-28).

Approval is required by [AGENTS.md](../AGENTS.md): “before programming the servo,
show the exact proposed register changes and wait for the user's approval”.
