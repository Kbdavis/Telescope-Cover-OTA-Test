# Bill of materials

[Back to the project README](../../README.md)

**[Assembly manual →](../assembly/)** — best-effort draft with assembly order,
wiring preparation and initial operating checks.

[Firmware installation and recovery](../INSTALLATION.md) covers flashing the
ESP32 servo controller and checking its installed software version.

**Current electronics cost: under $60 USD**, excluding 3D prints and mechanical
hardware (screws, nuts, washers and spacers). This is the project owner's current
cost estimate, not a live retailer quote; prices and availability can change.

This working BOM combines the controller electronics with the hardware modeled
in the **V10 controller enclosure / horizontal 90 mm revision** (2026-10-31).
Servo-interface items marked provisional still need physical verification.

## Electronics

| Item | Quantity | Specification / purpose | Amazon | Reference |
| --- | ---: | --- | --- | --- |
| Serial-bus servo | 1 | Waveshare / Feetech **ST3215, 12 V / 30 kg·cm version**; cover actuator | [ST3215 on Amazon](https://www.amazon.com/dp/B0B6P9271Q) | [Waveshare ST3215](https://www.waveshare.com/st3215-servo.htm) |
| Servo controller | 1 | **Waveshare Servo Driver with ESP32**, SKU **21593**, with onboard OLED and USB-C | [Find on Amazon](https://www.amazon.com/s?k=Waveshare+Servo+Driver+with+ESP32+21593) | [Waveshare controller documentation](https://docs.waveshare.com/Servo_Driver_with_ESP32) |

## Power and cabling

These are required for a working assembly; exact purchase selections and their
inclusion in the owner's electronics estimate have not yet been itemized.

| Item | Quantity | Specification / status |
| --- | ---: | --- |
| DC power supply | 1 | Regulated 12 V supply suitable for the controller and servo load; controller input is a 5.5 × 2.1 mm DC jack. Supply model, current rating and polarity must be recorded before this becomes a complete shopping list. |
| 300 mm servo bus cable — **strongly recommended** | 1 cable; linked pack contains 6 | [Waveshare 5264-3PIN servo cables, 300 mm (Amazon)](https://www.amazon.com/dp/B0GVDPPF72). Use the longer lead for the current V10 assembly and covered cable route. |
| Included 150 mm servo cable — alternative | 1; included with the servo | If using the included 150 mm cable instead, use the **V9 servo assembly (not waterproof)**. See the cable/assembly note below. |
| USB data cable | 1 | USB-C at the controller, for firmware installation and recovery; development equipment. |

## Mechanical hardware

**87 pieces across 19 specifications:** 51 screws, 20 nuts, 14 washers
(including four sealing washers) and two spacers. Quantities below come from the
[CAD hardware CSV](../../cad/v10_controller_enclosure_large/horizontal_90mm/hardware/BOM.csv).
Internal part numbers describe modeled geometry, not supplier SKUs.

| Part number | Quantity | Description | Notes |
| --- | ---: | --- | --- |
| `TC-HW-M2p5-L6-SH` | 4 | M2.5 × 6 mm socket-head screw | — |
| `TC-HW-M3-L10-BH` | 2 | M3 × 10 mm button-head screw | Button-head maximum dimensions referenced to ISO 7380-1 manufacturer data; grade/material/finish remain unselected. |
| `TC-HW-M3-L12-SH` | 8 | M3 × 12 mm socket-head screw | **Provisional.** Horn interface candidate: 2 mm nominal engagement in the supplied CAD. Confirm actual horn threads and available depth before fitting. |
| `TC-HW-M3-L16-SH` | 8 | M3 × 16 mm socket-head screw | — |
| `TC-HW-M3-L20-SH` | 6 | M3 × 20 mm socket-head screw | — |
| `TC-HW-M3-L30-SH` | 4 | M3 × 30 mm socket-head screw | — |
| `TC-HW-M3-L6-BH` | 2 | M3 × 6 mm button-head screw | Button-head maximum dimensions referenced to ISO 7380-1 manufacturer data; grade/material/finish remain unselected. |
| `TC-HW-M3-L6-SH` | 1 | M3 × 6 mm socket-head screw | **Provisional.** Rear horn-retaining screw; confirm actual interface and thread depth. |
| `TC-HW-M3-L8-SH` | 2 | M3 × 8 mm socket-head screw | — |
| `TC-HW-M4-L16-SH` | 2 | M4 × 16 mm socket-head screw | — |
| `TC-HW-M4-L25-SH` | 6 | M4 × 25 mm socket-head screw | — |
| `TC-HW-N-M3-AF5p5-T2p4` | 12 | M3 nut; 5.5 mm across flats, 2.4 mm thick | — |
| `TC-HW-N-M4-AF7-T3p2` | 8 | M4 nut; 7 mm across flats, 3.2 mm thick | — |
| `TC-HW-N6-L15p875-PAN-ST` | 4 | #6 self-tapping × 15.875 mm pan-head self-tapping screw | Generic pointed thread envelope. Thread form and physical pilot suitability require confirmation; this is not #6-32 UNC. |
| `TC-HW-PA2-L8-PAN-ST` | 2 | PA2 nominal self-tapping × 8 mm pan-head self-tapping screw | **Provisional.** Servo housing interface provisional: confirm actual case revision, screw thread and depth. 1.6 mm nominal insertion in supplied model before pointed-tip allowance. |
| `TC-HW-SEAL-M3-7x3p2x1` | 4 | Sealing washer; OD 7 × ID 3.2 × 1 mm | Nominal sealing-washer envelope. Actual material, compression and product dimensions not selected. |
| `TC-HW-SP-3p4x2p2-L3p2` | 2 | Spacer; OD 3.4 × ID 2.2 × 3.2 mm | **Provisional.** Servo-front spacer candidate based on nominal CAD faces Y2.85 and Y6.05. Confirm real load-bearing seating surfaces before tightening. |
| `TC-HW-W-M3-7x3p2x0p5` | 2 | Washer; OD 7 × ID 3.2 × 0.5 mm | — |
| `TC-HW-W-M4-9x4p3x0p8` | 8 | Washer; OD 9 × ID 4.3 × 0.8 mm | — |

## Printed parts and seals

| Item | Quantity / status | Files |
| --- | --- | --- |
| V10 servo/controller mounting and enclosure parts | 19 printed parts across two X1C plate layouts | [Print files and instructions](../../cad/v10_controller_enclosure_large/horizontal_90mm/export/README.md) |
| Servo outlet gasket | 1; compliant sealing sheet, material not selected | [1:1 cut template](../../cad/v10_controller_enclosure_large/horizontal_90mm/servo_outlet_gasket.svg) |
| Controller coupling seal | Thin compliant seal or removable sealing bead; selection pending physical fit | [Weather-interface notes](../../cad/v10_controller_enclosure_large/horizontal_90mm/README.md#weather-interfaces) |
| Cover shell and base | Revision and complete print inventory still to be consolidated | Separate from the 19-part servo/controller print set above |

## Notes

- **Cable and assembly choice:** the linked 300 mm cable is strongly recommended
  for the current V10 assembly. Otherwise, use the 150 mm cable included with the
  servo and the [V9 assembly](../../cad/controller_case_v1/README.md), which is
  **not waterproof**. Do not substitute the short lead into the V10 covered route.
  Further details about this choice will be added by the project owner.
- **Cost scope:** the under-$60 figure covers electronics only. It excludes 3D
  prints and mechanical hardware; individual electronics prices and the exact
  power/cable allowance still need itemizing. It is not a complete enclosure
  build cost.
- The controller Amazon link is a search link, not a verified product listing.
  Match **Waveshare SKU 21593**, the OLED, connector layout and mounting geometry.
  Select the **12 V ST3215** servo rather than the 7.4 V variant. Retail listings
  and package contents can change.
- **Thirteen pieces are provisional:** eight M3 × 12 horn screws, one M3 × 6
  rear horn-retaining screw, two PA2 × 8 lower servo screws and two spacers.
  Confirm the actual servo revision, threads, seating surfaces and available
  depth before fitting or loading them.
- Mechanical hardware material, finish, strength grade, thread pitch and supplier
  part numbers remain unselected. Nominal CAD fit does not establish safe thread
  engagement or tightening torque.
- **Curved-mount wall fasteners are omitted** from this revision at the owner's
  request. Select them once the actual cover/base wall construction is defined.
- The gasket, sealing washers, cable retention and weather interfaces still need
  physical fit and water testing. Rain, OPEN/CLOSED and temperature/humidity
  sensors are future additions and are not included in this BOM.
- See the [hardware placement and verification notes](../../cad/v10_controller_enclosure_large/horizontal_90mm/hardware/README.md)
  and [assembly revision notes](../../cad/v10_controller_enclosure_large/horizontal_90mm/README.md)
  before purchasing or printing. This remains a prototype BOM.
