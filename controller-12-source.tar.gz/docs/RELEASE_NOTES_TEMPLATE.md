# Telescope Cover <VERSION>

**Unpublished multi-turn candidate — dependency clearance and hardware/browser acceptance pending.**

Source commit: `<COMMIT>`

## Included

- Complete destructive USB installation image for Waveshare Servo Driver with
  ESP32 (SKU 21593), ESP32 with 4 MB flash, and the exact supported 12 V ST3215
  identity/configuration. Exact board/servo revisions await acceptance.
- `web_control_multiturn_usb`: native multi-turn goals and checked stationary
  RAM startup preparation, without operator commissioning routes, local Wi-Fi/
  telescope credentials, or a development OTA receiver.
- Guarded browser installer, checksums, installation/recovery guide, build
  identity, scoped project license texts and embedded-font notices.
- Visible version in the footer and Configuration → About firmware.

## Compatibility and limitations

Supervised prototype only. macOS Chrome/Edge are the initial qualification
scope; no browser has passed physical acceptance for this package yet. Windows
and Linux are unverified. GitHub Releases/Pages hosting remains pending.

Installation erases existing firmware, Wi-Fi settings and calibration. There is
no settings-preserving update, public wireless update or qualified downgrade.
First powered startup may change only locked RAM maximum-angle and phase fields
for the exact supported factory snapshot: registers 11–12 to `00 00`, 18 to `1c`.
Mode 0, minimum 0, resolution 1, offset 85 and lock 1 remain required. See
INSTALLATION.md for startup rejection and recovery. No EEPROM unlock or automatic
cover movement occurs. Fresh endpoints must be taught for the actual mechanism.

Motion retains speed 100 / acceleration 10 limits, 500-count jog bounds and
bounded taught arcs. Profile loss blocks movement. Replacement-servo identity
cannot distinguish individual units: replacement/remounting requires fresh
teaching. Full loaded travel, power-cycle behavior and fault/recovery tests remain
acceptance gates. Unattended rain/weather protection is unqualified.

Original software is MIT; hardware is CERN-OHL-S-2.0; documentation is CC BY 4.0.
Third-party terms still apply. LICENSE_STATUS.md and THIRD_PARTY_NOTICES.md explain
why project licensing alone does not clear this candidate for distribution.

## Acceptance record to complete before publication

- [ ] Supported board/servo revision, power requirements and wiring verified.
- [ ] Changes reviewed for this exact commit and final dependency notices,
      source/relinking obligations and asset redistribution rights resolved.
- [ ] macOS browsers, fresh/vendor install, cancellation and USB recovery tested.
- [ ] Interrupted flashing and readback-failure recovery tested.
- [ ] Exact-profile cold/warm startup, both signed crossings, profile-loss blocking,
      calibration, replacement/reteach instructions and loaded travel qualified.
- [ ] Startup, Wi-Fi onboarding, Stop/faults and settings persistence passed.
- [ ] Exact package hashes, debugging artifacts and source retained with evidence.
- [ ] Hosted installer/download paths verified; beta marked prerelease.

Candidate creation does not authorize publication or establish a qualified release.
