> Current calibration revision: explicit circular arcs and supervised teaching
> now handle coordinates across zero. Production boundary motion remains gated
> after the exact-profile detached test took the wrong physical route. The bench build permits
> only ≤100-count crossing segments at speed ≤100 / acceleration ≤10. See
> [CALIBRATION.md](CALIBRATION.md). Legacy linear bounds remain unchanged.

# Motion controller

Current travel revision (2026-10-28, installed on `cover-dev.local`): the controller uses explicit
calibrated actuator travel and named endpoints. `travel_model.h` centralizes
nonwrapping coordinate conversion, allowed arcs, direct-path admission and
planning duration. Both controller and driver reject uncommissioned rollover
and half-turn-or-longer direct goals. Limits, direction convergence, settling,
holding drift and telemetry use the same nonwrapping path; absolute raw
sample differences equal actuator-coordinate differences on these supported
arcs. Failed reads never become samples, and one anomalous read cannot create
a lap or fault. Profile corrections preserve latched faults. See
[CALIBRATION.md](CALIBRATION.md) for migration, timeout admission and checks.
The bench history below describes earlier releases, not current deployment.

## Initial manual-controller implementation

`CoverController` now owns bounded manual jogs through a `ServoMotion` interface.
It starts UNKNOWN, requires validated in-memory travel settings and a current
caller-supplied path-clear decision, and enters MANUAL only after preflight.
OPEN/CLOSE endpoint commands, NVS calibration, physical sensors, and web routes
are not implemented yet. No servo position is labeled physically OPEN/CLOSED.

Preflight checks configuration, two consistent position reads, travel bounds,
and a maximum jog of 100 counts. It releases and checks torque before staging
present position and enabling torque, so an old active goal is not resumed.
Movement uses a configurable speed/acceleration and timeout (500–30000 ms).

During motion the controller checks safety permission on each tick and polls
position at most every 50 ms. Three consecutive failed position operations,
three out-of-range samples, or three samples more than six counts farther from
target than the filtered best distance cause a fault. An isolated failed or
anomalous sample does not declare wrong-direction motion. Progress baseline
improvement is limited to three counts per sample. Five consecutive samples
within three counts of target complete the move.

Stop and completion release torque and read back its state. Fault handling
also attempts release, latches FAULT, and reports whether torque-off readback
succeeded. Failed communication cannot guarantee a physical stop. STOP never
clears FAULT; explicit `recover()` requires configuration and position checks
and confirmed torque release, returns UNKNOWN, and never resumes motion.

This release-on-completion policy is for supervised commissioning. It is not a
validated policy for supporting a heavy cover. No load/current thresholds or
physical sensor contradiction logic are implemented. The safety boolean is an
integration boundary, not a sensor implementation. The caller must service
ticks promptly; blocking driver calls add latency to timeout/interlock response.
No automatic recovery, rain closure, or unattended operation is enabled.

## Bench firmware

`pio run -e motion_bench` builds a separate serial-command harness. Upload only
with a mechanically safe setup and an operator present. It does not move on
boot, requires torque OFF at startup, checks model 777 and configuration, and
sets temporary limits to the measured origin ±30 counts. These are disposable
bench limits, not calibrated enclosure limits.

At USB 115200 baud:

- `j`: one +20-count jog, speed 100, acceleration 10, timeout 5 seconds.
- `r`: one return to the original position after successful forward settling.
- `h`: refresh the host heartbeat; during motion it must arrive within 500 ms.
- `x`: release torque and disarm the bench session.

Each leg can be requested once per boot. Missing heartbeat trips the controller
interlock; it does not automatically retry or return after a fault. No recovery
command is exposed in this harness. Do not use a terminal that unexpectedly
sends these command characters while the mechanism is attached.

## Verification — 2026-09-30

All three PlatformIO environments (`esp32dev`, `servo_diagnostic`, `motion_bench`)
built successfully. Driver and read-only guard tests passed. Host controller
tests covered travel guards, both directions, settling, isolated outliers,
repeated wrong-direction/out-of-range samples, failed reads, timeout and millis
wraparound, interlock loss, uncertain writes, torque-release failure, fault
latching, and explicit recovery.

With the user confirming clearance and authorizing +20 counts and return:

| Leg | Start | Target | Settled | Torque after completion |
| --- | --- | --- | --- | --- |
| Forward | 2045 | 2065 | 2063 | OFF, readback confirmed |
| Return | 2063 | 2045 | 2046 | OFF, readback confirmed |

No faults occurred. Host sent STOP/disarm at the end. The motion bench firmware
remains installed, inactive until an explicit permitted command. The full log
is local at `backups/motion-bench-20260930.log`. Hardware fault injection and
physical Stop/heartbeat-loss behavior have not yet been bench tested; those
paths currently have offline coverage at the controller boundary.

Run the controller tests without hardware:

```sh
c++ -std=c++11 -Wall -Wextra -Werror -Itests/host -Isrc \
  tests/host/cover_controller_test.cpp src/cover_controller.cpp \
  -o /tmp/cover-controller-test
/tmp/cover-controller-test
```

## Loaded-cover manual-jog settling (2026-10-01)

The operator measured target 583 / actual 569 and target 584 / actual 571 before
torque release. Manual jogs now accept up to 20 counts of target error, provided
five consecutive valid in-range readings span at most 3 counts (50-ms polling).
A wider target band alone does not count as settled while still moving through
it. Failed reads or out-of-band samples reset settling. The actual measured
position remains the reported position; no synthetic target position is used.
OPEN/CLOSE retain their existing 3-count target tolerance and settling behavior.
Torque release, travel bounds, wrong-direction checks, heartbeat lease and
five-second timeout are unchanged. This is a manual commissioning tolerance,
not a fix for slipping after torque release or a physical closed-cover guarantee.
Host checks cover both directions, 13/14-count shortfalls, the 20/21-count
boundary, continued travel inside the band, failed-read resets and endpoints.

## Opt-in supervised holding after manual steps

Uploaded on 2026-10-01; loaded-cover physical validation remains pending. Single
manual jogs may request retained torque. After five stable readings inside the manual
20-count band, the controller enters HOLDING instead of releasing torque.
The original servo goal remains active; measured position remains the displayed
position. Subsequent retained-torque jogs validate configuration and stable
position and confirm torque is on, without the usual preflight torque-off/on
cycle. A new step is relative to the measured position, not the previous target.
Default jogs and OPEN/CLOSE retain existing behavior.

HOLDING requires the owner's continuing 500-ms heartbeat lease. The five-second
motion timeout does not expire an idle hold, but still applies to each move.
While holding, the controller polls position and torque, faults on confirmed
loss of torque, repeated failed feedback, repeated out-of-range position, or
three consecutive positions more than 20 counts from the retained target.
No new thermal/current threshold or mechanical support guarantee is introduced.

**Stop, hiding/closing the page, loss of focus, lost heartbeat, and unexplained
faults still release torque. Power loss also removes support. Mechanically
support the cover before using this mode; it is not a gravity-safe stop.**
The existing torque-OFF-on-fault invariant is preserved. Reliable loaded-cover
operation still needs a validated mechanical retention/counterbalance solution.

The checkbox is off on page load and is not saved. Selecting it alone sends no
hardware command. Only the owning client can request a subsequent retained jog;
any client may Stop/release. Endpoints and calibration changes require release
first; hold-to-jog buttons are disabled when the option is selected because
releasing those buttons requests Stop. On the page, Stop is explicitly labeled
STOP / release torque. Unchecking operator presence stops/release as before.
Recovery returns to UNKNOWN with torque off and never resumes holding.

## Loaded-cover endpoint tolerance (2026-10-24)

OPEN/CLOSE now accept a measured position within **10 encoder counts inclusive**
of the requested endpoint. Completion still requires five consecutive valid
samples spanning at most 3 counts. A closer sample followed by a stable landing
inside this band does not trigger wrong-direction detection. Eleven counts of
remaining error cannot complete a move; the movement timeout still applies.

Startup endpoint classification and downstream endpoint checks use the same
10-count tolerance. Saved OPEN and CLOSED targets must be more than 20 counts
apart so their accepted bands cannot overlap. Actual feedback remains displayed;
servo position does not independently prove physical cover seating.

Manual jogs use the step-scaled settling band documented below. Travel limits,
communication checks, interlocks and torque handling remain enforced. Host boundary and regression tests cover
these changes; loaded-cover hardware verification is pending.

### Wi-Fi-only installation and diagnostics (2026-10-24)

Installed the 10-count endpoint build by authenticated development OTA with USB
unplugged and the operator confirming mechanical support and torque release.
Firmware `0e3ba35bc05a5a6be13ad0b8238364da93c57756e15b65b9885ca1d0480a6c01`
booted, passed deferred startup acceptance, and reported CLOSED at position 496,
with torque OFF and saved targets CLOSED 493 / OPEN 1531 preserved.

All 60 one-second status samples succeeded in the same boot: median 56 ms,
maximum 174 ms; free heap minimum 164,924 bytes, final 169,096 bytes; RSSI
−86 to −82 dBm. Optional metrics remained off. Wi-Fi debug logs, retained
failure summary, NTP synchronization, and read-only Alpaca monitoring were
accessible. Logs showed normal association, IP acquisition, and startup;
Alpaca recovered after the initial pre-network boot check.

The retained prior-firmware movement timeout (1525 against target 1531) survived
the OTA reboot and is correctly identified as a previous-boot incident. No
movement was commanded in this check: loaded-cover settling with the new
10-count tolerance still needs a supervised exercise. Evidence is local under
`diagnostics/endpoint-tolerance-ota-20261024/`.

## Fine manual-step completion (2026-10-28)

Manual jog tolerance is now `min(20, floor(abs(step) / 5))` encoder counts.
A 10-count step therefore accepts up to 2 counts of error, including the observed
9-count movement, and completes without requiring Stop/release before the next
command. Steps of 1–4 counts still require the exact target; steps of 100 counts
or more retain the commissioned 20-count maximum. The starting position is
always outside the acceptance band for a nonzero step.

Completion still requires five consecutive valid samples spanning at most
3 counts. Failed reads reset that window; travel limits, direction checks,
timeouts, endpoint tolerance and torque policy remain unchanged. The next jog
uses the actual measured position. Host regressions cover both directions,
consecutive steps, retained/released torque, acceptance boundaries and timeout
outside the band. Physical verification of this change remains pending.

Installed on `cover-dev.local` by authenticated development OTA transaction
`5ffcec50ea958fadb2dc5444f44aaf67`; ELF
`a29fae8252080852f3812cf6a86e4fae8a33e3c2e92781dff56bce97c69959a8`.
Startup accepted the image and confirmed durable boot selection. Saved CLOSED
1148 / OPEN 2837, the speed/acceleration profile and reference offset 1328 were
preserved. Actual raw 4095/0 crossing remains uncommissioned and blocked in
manual mode as well as normal operation; the validated fixed reference changes
where that boundary lies, rather than enabling a wrapped direct goal.

## Manual range recovery and reversed mounting (2026-10-29)

Explicit Manual Control uses a separate controller entry point, with raw
0–4095 bounds for that move only. It accepts a stable starting position outside
configured limits or a taught arc. It retains configuration validation, path
clearance, heartbeat, settling, timeout, wrong-direction checks and automatic
torque release. It cannot cross the raw boundary or move while faulted. Saved
limits remain unchanged; subsequent ordinary jogs and endpoints enforce them.

Startup and explicit fault recovery may establish UNKNOWN with valid stationary
feedback outside saved travel. This provides manual eligibility without granting
normal movement readiness. The reversed mounting opens with decreasing counts;
old +1 calibration is retained for review and fresh teaching is required.

Overcurrent (`device_status & 0x08`) faults immediately and instructs external
servo power cycling. Failed torque release remains unconfirmed. Clearing the
application fault still requires fresh successful configuration, position and
torque checks and never resumes movement.

Installed on `192.168.1.43` by authenticated development OTA transaction
`24fc2f689dda23b1c7ba1691263bb445`; ELF
`8a1961e23e26187fef5fd96b7ddbd6c554083f3a8ba7c785e5642f13ad38ee44`.
Startup accepted the image and reported UNKNOWN, manual eligibility true,
normal movement readiness false and torque OFF. Saved CLOSED 1147 / OPEN 3140
remain in NVS as review evidence; the old +1 orientation requires reteaching.
The empty temporary teaching session was discarded before OTA; saved endpoints
and profile were verified unchanged. The exact fixed-reference servo snapshot
still matches (phase 12, offset 1328, lock 1).

Validation: both firmware variants build; controller, driver, read-only,
settings/reference and browser travel-model checks pass. Real-browser regressions
cover manual range recovery, reversed buttons and held repeats, raw boundaries,
overcurrent instructions, guarded rechecks and configuration mismatches.
No physical movement was commanded during this update; supervised verification
of the remounted assembly remains necessary.

## Direction and overshoot checks (2026-10-29)

The mechanical load at capture time is unknown. Operation 4 requested raw
2494 → 2594 at speed 100 / acceleration 10. Valid feedback passed 2594 and
continued through 2604, 2614, 2625, 2636 and 2641. No serial reads failed;
the controller faulted and confirmed torque OFF. This is measured target
overshoot, not evidence that the requested direction was reversed. The frozen
snapshot is retained locally under
`diagnostics/2026-10-29-direction-overshoot/before-servo.json`. The cause of the
servo continuing past its goal remains unproven; these logic changes do not
establish a hardware repair or authorize relaxing protection.

All movement types now permit normal settling within their existing target
band, including manual jogs. Outside that band, three consistent samples more
than six counts beyond the confirmed closest distance still stop motion.
Samples past the goal in the commanded direction are identified as
`Repeated target overshoot` / `target_overshoot`; backtracking retains
`Repeated movement away from target` / `away_from_target`. Boundary jumps,
overshoot, backtracking and holding drift cannot pool different kinds of evidence
to manufacture three consistent samples. Failed reads and valid in-band feedback
reset the rejection streak; completion still requires the stable sample window.

The closest-distance baseline uses the farther distance from two consecutive
accepted samples. A single closer outlier cannot promote the baseline. This
replaces the fixed three-count improvement per 50 ms poll, which lagged behind
normal motion above 60 counts/s and delayed detection. Failed reads and rejected
observations break baseline confirmation; they never become accepted positions.

Host regressions cover the recorded overshoot in both directions (the stop is
retained with the correct classification), in-band rebound for manual/calibration/
endpoint motion, fast valid progress followed by real backtracking, isolated
closer outliers, intervening read failures, mixed rejection types and return to
stable settling. Physical movement is not exercised by these tests.

Both `web_control` and `web_control_reference_dev` compile with this correction.
The host controller, travel-model and bounded support-response suites pass.
OTA installation was attempted and rejected by the receiver's existing admission
checks: the current controller is faulted, uncalibrated and in unfinished teaching.
No calibration was fabricated or saved to gain admission; no fault was cleared
and no movement was commanded. At that first check no USB serial port was present. The user subsequently
provided USB access; the installation is recorded below.

### Supervised reduced-speed evidence

With the user present, supporting the mechanism, and confirming telescope stow
and a clear closing path, one 10-count closing test requested 2686 → 2696 at
application jog speed 25 / acceleration 10. Two stationary preflight reads agreed.
The earlier attempted test issued no movement because another browser had
changed the position between inspection and preflight.

The executed step reported 2687 at 121 ms, 2693 at 222 ms, 2699 at 324 ms,
2704 at 428 ms and 2710 at 536 ms, with zero failed reads. The controller faulted
and released torque; the supervising script also sent Stop when the bounded
step envelope was exceeded. Final feedback was 2710, stationary, torque OFF.
The lower requested speed did not establish target settling or a verified
25-count/s physical rate. This remains actual overshoot, not just a false
message. Evidence is in `slow-step-status.json` and `slow-step-trace.json` in
the same local diagnostics directory.

At that point the installed receiver had no uncalibrated recovery-update override. The
USB-free supported route is supervised teaching of real physical CLOSED/OPEN
positions, using Stop as needed, followed by a verified save and normal OTA
admission. No dummy calibration, restored wrong-orientation endpoints or
receiver-admission bypass is used. The controller was initially enclosed without USB access. After the reduced-speed
test, the user made USB available and selected USB recovery. The unfinished
teaching draft was archived in `before-usb-status.json` before flashing; it was
not saved as a calibration merely to gain OTA admission.

### Installed correction

After the user selected USB recovery and `/dev/cu.usbserial-0001` appeared,
`web_control_reference_dev` was installed with hash verification. Running ELF:
`a1f2935c768ffa4fd00ab98a2f695c157e1978e2132f32b1670b5a4999468780`.
Post-boot status confirmed this identity, OTA startup accepted, UNKNOWN,
manual eligibility true, position 2709 and torque OFF. Saved review
endpoints CLOSED 1147 / OPEN 3140, profile 100/100/100, acceleration 10, timeout
29000 and reference offset 1328 were preserved. The full fixed-reference servo
snapshot still matches, with lock 1. The unsaved teaching draft is archived;
fresh endpoint teaching remains required. No calibration or OTA-admission
checks were bypassed.

The physical reduced-speed overrun was observed on the preceding firmware.
No movement was commanded after this installation; physical settling on the
updated firmware remains unverified. The correction permits in-band settling
and accurately classifies continued past-goal motion, while retaining the stop
on real overrun. It does not establish a repair of the servo's underlying
target-tracking behavior.

## Reversed OPEN command evidence and goal readback (2026-10-29)

After teaching CLOSED at 2981, the user requested OPEN. Operation 4 on firmware
`a1f2935c768ffa4fd00ab98a2f695c157e1978e2132f32b1670b5a4999468780`
requested 3003 → 2503 at speed 100 / acceleration 10. Feedback increased to
3023 at 275 ms, with zero failed reads; final stationary feedback was 3027.
The user visually confirmed motion toward CLOSED. The controller latched the
correct wrong-direction fault and confirmed torque OFF. This is separate from
the earlier positive-direction overshoot. UI/worker mapping requested decreasing
raw counts for OPEN as intended; neither button relabeling nor relaxing the
direction guard repairs the underlying target-following failure.

The complete commissioned snapshot still matches: mode 0, range 0–4095, phase
12, resolution 1, offset 1328, EEPROM lock 1. Snapshot/draft evidence is archived
under `diagnostics/2026-10-29-reversed-open/`. The CLOSED draft is retained there
for review; firmware installation resets an unsaved teaching session.

Passive diagnostics now expose acceleration/goal/raw register 44/speed/torque-limit
readback from registers 41–49, sampled only during idle secondary polling. The
existing 56–70 telemetry block also retains raw target feedback from 67–68.
During motion the existing 250 ms secondary position transaction reads this
feedback block instead, retaining target/load/current evidence without adding a
transaction; primary 50 ms position supervision remains unchanged. These are
timestamped raw readbacks; old cached evidence is not
proof that a later command reached the servo. Failed reads do not replace output
or cached evidence. HTTP diagnostics still use passive caches only. No goal
staging, torque enable, servo configuration change or movement is introduced
by collecting this evidence.

### Detached current-position hold

The user detached the cover linkage for unloaded diagnosis. Diagnostic build
`b5b2b1dfd75e9c5cc19463ed5ebcb9a7483411817487fe72bc003c39c471577e`
was installed over USB after OTA refused uncalibrated admission. Before testing,
two stationary readings agreed at 3192, torque was verified OFF, the exact
fixed-reference snapshot matched, and register 48 read 1000. No servo
configuration was changed for this test.

One bounded current-position torque test staged 3192 at speed 100 / acceleration
10. Feedback rose through 3201 and 3207; the safety read reached 3217 and stopped
the test at 7250 ms uptime with `Torque test position changed`. Frozen telemetry
from 7243 ms showed position 3217, raw target feedback (67–68) 3222, speed 100,
relative load −48, current raw 0, 12.2 V and 38 °C. No reads failed. After release,
position was stationary at 3220, torque OFF confirmed, and register 42 still
read 3192. A final script status connection timed out; a subsequent read verified
the same boot, latched fault and torque OFF. Evidence is retained in
`unloaded-hold-*.json` under the diagnostics directory above.

The failure therefore occurs without the cover load and without requesting a
position change. This does not establish whether the cause is the servo's
reference handling, internal motion behavior or a hardware defect. The
increasing feedback is real; weakening wrong-direction detection is not a fix.
The previous bidirectional reference commissioning remains historical evidence,
not proof that the present failing unit/state can hold or settle correctly.

A separate `web_control_reference_probe` comparison build is prepared but not
installed. The proposed next experiment requires explicit operator approval:
with torque OFF, restore only offset registers 31–32 from 1328 (`30 05`) to the
factory 85 (`55 00`), keep lock 55 at 1, verify all 40 bytes and the predicted
+1243 modulo-4096 feedback shift, then repeat the same bounded unloaded hold.
No saved calibration is rewritten or reused across that reference change;
raw 4095/0 crossing remains disabled. The currently installed fixed-reference
build would reapply 1328 after restart/recovery, so it must be replaced by the
nonautomatic probe build before an approved comparison. No reference write or
second torque test had been performed at that decision point.

### Approved factory-reference comparison

The user subsequently approved that exact restoration and repeated hold. The
nonautomatic probe build `53f6a08cba556946cc964c2c3649fb6994664ccd57f736f2351374b68198c2d0`
was installed via USB after OTA refusal. The first script stopped at its first
network read during Wi-Fi startup, before any write. Once reachable, the one-time
restore changed only bytes 31–32 (`30 05` → `55 00`); lock stayed 1 and the full
factory snapshot matched. Position shifted 2681 → 3923, within one count of the
predicted modulo-4096 mapping. Saved offset-1328 calibration was retained.

The repeated bounded hold staged current position 3923 at speed 100 /
acceleration 10. Every published position stayed 3923; frozen telemetry showed
internal target 3923, speed/load/current all zero, 12.2 V and 38 °C. The test
completed its 750 ms limit with `Torque test finished; inspect before recovery`
and confirmed torque OFF. No reads failed. Evidence is in `factory-*.json`.
This is a successful unloaded hold comparison, not a bidirectional movement or
loaded-cover qualification. The automatic offset-1328 profile is no longer
qualified; no second reference adjustment or full travel was attempted.

The final normal `web_control_dev` build
`48b0e6f2200124c6ac47fc4ef7d0931a758d8225cf510d505af4e82c4ad74788`
was subsequently installed via recovery OTA while uncalibrated. It accepts the
exact factory profile at offset 85 and never automatically reapplies 1328.
Normal motion remains disabled pending fresh calibration, manual eligibility
is available, and torque is OFF. See [OTA implementation](OTA_IMPLEMENTATION_PLAN.md)
for the completed transaction and the preceding safely aborted network transfer.

### Factory-reference OPEN movement still fails

The user subsequently attempted a 100-count OPEN step on normal development
ELF `48b0e6f…`, operation 1, boot `589c3601d1154112d9abf1532055eddc`.
Start was 3923, requested target 3823, speed 100 / acceleration 10, timeout
5000 ms. Accepted feedback reached 3928 at 142 ms; repeated valid readings
continued increasing, with last valid 3944 at 296 ms. The wrong-direction guard
latched `Repeated movement away from target`, confirmed torque OFF, and final
stationary position was 3947. The command did not cross the raw encoder boundary.

Register 42 readback retained 3823. Frozen telemetry at 185 ms showed position
3932, internal target readback 3937, speed +100, relative load −48, current raw
0, voltage 12.2 V and temperature 38 °C. All 40 factory bytes matched, offset
85, mode 0, limits 0–4095 and resolution 1. Six supervision reads succeeded,
none failed; one configuration-read timeout was recovered by a retry before
the move. Heartbeat age at fault was 67 ms. This is an actual wrong-direction
move, not a heartbeat loss or isolated position anomaly. Evidence is archived in
`diagnostics/2026-10-29-factory-open-fault/{status,trace,servo}.json`.

The successful factory-reference hold did not repair or qualify moving commands.
The application's seven-byte goal payload matches Feetech's
[SMS_STS::WritePosEx](https://github.com/ftservo/FTServo_Arduino/blob/main/src/SMS_STS.cpp):
acceleration, little-endian target, two zero bytes, little-endian positive speed.
No speed-direction-bit workaround, configuration write, fault clearance or new
movement was performed during this inspection. A cold external servo power
cycle, with the linkage detached and no automatic resume, was requested before
any further controlled test. Its result is not yet recorded.

### Cold servo power cycle and stationary recheck

The user unplugged the servo connector from the ESP32 board for ten seconds,
then reconnected it while keeping the controller powered. Readbacks showed
register 42 goal, register 46 speed and register 41 acceleration all reset to
zero, torque OFF, stationary position 3946, 12.2 V and 37 °C. The existing
wrong-direction fault remained latched on the same controller boot. The failed
read counters include the expected disconnection interval; current reads had
recovered. These reset control registers are evidence of a servo power reset,
not merely a controller reboot.

An explicit stationary Recheck then performed fresh model/configuration and
position validation, confirmed all 40 factory bytes at offset 85, and cleared
only the application fault to UNKNOWN. Torque stayed OFF; no goal or servo
configuration was written and no movement was requested. The cached
configuration before Recheck was old and was not mistaken for a post-reset
measurement. Evidence is in `diagnostics/2026-10-29-servo-cold-start/`.

A single supervised 10-count OPEN test was prepared with
fresh stationary torque-OFF preflight near 3946, requests decreasing raw position
by 10, maintains the existing heartbeat, sends Stop on a position outside
target−6 through start+6 or after three seconds, and records the final trace and
torque readback. No automatic return movement follows an unexplained fault.

The user confirmed readiness, detached linkage and a clear shaft. The test ran
on the same boot and firmware as the preceding failed OPEN, after the servo
power cycle and Recheck. It requested 3946 → 3936 at speed 100 / acceleration
10. Feedback decreased correctly: 3943 at 116 ms, 3939 at 217 ms, then stayed
3939 through 3047 ms. All 59 control reads succeeded; none were rejected, no
heartbeat requests failed and no wrong-direction fault occurred. The external
three-second test limit sent Stop, and final position 3939 / torque OFF were
confirmed. The retained support fault still describes the earlier operation 1;
it must not be presented as a new fault from this operation 2.

This establishes a correct-direction OPEN step after cold reset, with no
firmware or configuration change between the failed and successful moves.
It does not establish root cause or bidirectional/full-travel reliability.
The fine-jog tolerance was two counts; the servo remained three counts short,
so the controller did not declare settling before the supervisory Stop.
Evidence is in `step-{samples,trace,servo,after-status}.json` in the cold-start
diagnostics directory. No return movement or new firmware was commanded.

### Intervening browser CLOSE test

The user confirmed readiness for a single ten-count CLOSE test from 3939. Its
preflight found position 4040 instead, so the script exited before manual enable,
heartbeat or any movement command. Status showed an intervening browser command
from client 35584182, distinct from the supervising test client.

The latest browser trace (operation 5 on the same boot) already recorded a
100-count CLOSE request 3941 → 4041 at speed 100 / acceleration 10. Feedback
increased smoothly, reached 4039 at 1059 ms, then settled at 4040. It completed
five stable samples by 1267 ms with 25 valid reads, zero failed or rejected reads,
no fault and confirmed torque OFF. Register 42 retained 4041. This validates a
small unloaded positive-direction movement after cold reset; it is not a claim
that the agent executed the separately proposed ten-count test. The latter was
not retried or rebased nearer the raw boundary. Current 4040 has only 55 counts
to raw 4095; full mechanical travel must be arranged inside the raw domain
before reconnecting and calibrating the cover.

Evidence: `close-preflight-status.json`, `browser-close-trace.json`, and
`browser-close-servo.json` in the cold-start diagnostics directory. Earlier
operations 3–4 were not retained in this trace and are not reconstructed here.
