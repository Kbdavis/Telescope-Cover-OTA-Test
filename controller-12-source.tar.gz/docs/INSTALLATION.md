# Install and recover Telescope Cover firmware

**Implementation available; public release and physical validation pending.**
The agreed public target is a supervised multi-turn `v0.1.0-beta.1`, with
GitHub Pages hosting and macOS browser qualification first. Production multi-turn
USB packaging is implemented; hardware/browser acceptance and dependency
clearance remain pending. The procedures below describe the multi-turn candidate.
Use only an explicitly identified candidate during supervised development.
An owner-authorized private pipeline-test prerelease may be published before
physical acceptance. Its notes and metadata explicitly say NOT HARDWARE TESTED;
publication does not establish a supported installation or safe cover behavior.
A GitHub source ZIP is not a firmware installation package. No published release
or hosted installer is established by this guide.

## Supported candidate hardware

The candidate targets the **Waveshare Servo Driver with ESP32, SKU 21593**, with
ESP32 and **4 MB flash**, and the **12 V ST3215** servo. Confirm the board name,
connectors and wiring; detecting an ESP32 does not identify its external circuit.
The exact supported revisions and power-supply specification still require
hardware acceptance.

This package builds `web_control_multiturn_usb`. It accepts only model 777 with
the exact supported 40-byte factory or native multi-turn identity/configuration,
not an arbitrary ST3215 with matching phase/offset alone. A replacement servo
must pass this check and requires fresh teaching. Hardware revisions and
replacement units have not yet been qualified for public support.

On a stationary factory-profile startup with torque OFF and EEPROM lock 55 = 1,
the driver prepares only these fixed RAM fields: maximum angle registers 11–12
`ff 0f` → `00 00`, phase register 18 `0c` → `1c` (12 → 28). Mode 0, minimum 0,
resolution 1, offset 85 and lock 1 remain required. It verifies the full snapshot,
lock and unchanged native feedback; it never unlocks EEPROM, enables torque or
sends a movement goal as part of preparation. Existing multi-turn configuration
is inspected without rewriting it or resetting its native turn. The controller's
startup torque checks still apply; retained torque does not imply readiness.

Failed/uncertain writes latch movement disabled for that driver lifetime. Missing
or mismatched configuration, motion, unlocked EEPROM or energized factory setup
block initialization. Do not reboot repeatedly to retry an unexplained failure.
Loss of the RAM profile while the ESP32 stays powered blocks motion; support the
cover, inspect diagnostics and perform controlled recovery. Do not deliberately
power-cycle a loaded servo to test this behavior. Never use the old Waveshare
SC-style interface or the disqualified offset-1328 build to fix a fault.

Installation programs the ESP32, not the servo's firmware. Initial hardware
acceptance will use the spare controller/servo with the arm detached. This build
has not been installed on the active controller during release preparation.

## Before connecting USB

1. Stow and remove the telescope from the work area. Support the cover independently.
2. Disconnect the arm and disconnect the servo's external power. USB connection
   and bootloader entry can reset the controller, including before installation
   is confirmed. Never rely on motor torque to support the cover during flashing.
3. Use a USB data cable and close serial monitors or other apps using the port.
4. Have access to the board's BOOT and RESET buttons for recovery. Board-specific
   button timing and USB serial drivers still need verification on each supported OS.

A clean installation **erases all existing firmware and settings**, including
Wi-Fi and calibration. There is currently no settings-preserving USB update or
public wireless update in this workflow. A compatible partition table does not
change that erase policy. A full-flash backup is optional and may contain private
credentials; do not share it or use it as a public release image.

## Browser installation

The intended entry point is an HTTPS installer attached to a versioned GitHub
Release. Hosting and physical browser qualification are still pending. For a
local candidate preview, extract the USB ZIP and serve that extracted directory:

```sh
python3 -m http.server 8080 --bind 127.0.0.1
```

Open `http://localhost:8080/` in desktop **Chrome or Edge**. Localhost is suitable
for development; remotely hosted installers require HTTPS. Opening index.html
directly as a file is not the supported workflow. The browser loads the pinned
esptool-js library from unpkg.com, so internet access is required.

1. Check the displayed candidate version and source commit. Review its release
   notes and SHA256SUMS. On macOS use `shasum -a 256 -c SHA256SUMS` in the extracted
   directory; on Linux use `sha256sum -c SHA256SUMS`. In Windows PowerShell,
   `Get-FileHash .\factory.bin -Algorithm SHA256` must match the factory.bin entry.
2. Confirm the exact board and mechanical preparation on the page. Click
   **Connect & inspect** and select the controller's USB port. On macOS it may
   appear as `/dev/cu.usbserial-…`; the suffix is not universal. The page resets
   into the loader and checks chip family, flash capacity and the partition table.
3. A matching table is reported as compatible. A table area containing only FF
   bytes is reported as blank; that does not prove the whole board is blank.
   Other readable tables are reported as incompatible or unrecognized. Failed
   or incomplete reads block installation; they are never treated as blank.
4. Review the explicit erase warning. **Cancel** performs no flash erase/write,
   although the connection may already have reset the controller. To proceed,
   click **Erase and install Telescope Cover**. The installer rechecks the device
   and partition table, erases flash, writes the complete image, verifies its
   readback digest and requests a restart. Keep the cable connected throughout.
5. The final message distinguishes verified flashing from confirmed startup.
   Startup and servo validation must be checked separately below. A mismatch or
   interruption leaves installation incomplete; use the same USB recovery route.

The package's `manifest.json` is for this guarded installer. Its separate
`esp-web-tools-manifest.json` supports ESP Web Tools integration, but that generic
flow does not implement this project's partition preflight and is not the primary
installation route.

## Download-and-flash alternative

Use an esptool.py installation compatible with the package metadata. The candidate
build currently uses esptool **4.11.0**. With the same mechanical preparation,
substitute the selected USB port in these commands:

```sh
python3 -m esptool --chip esp32 --port <PORT> --baud 115200 erase_flash
python3 -m esptool --chip esp32 --port <PORT> --baud 115200 write_flash 0x0 factory.bin
python3 -m esptool --chip esp32 --port <PORT> --baud 115200 verify_flash 0x0 factory.bin
```

**Running erase_flash is the destructive confirmation for this alternative.**
It bypasses the browser's board/layout inspection, so use it only after checking
manifest.json and the physical board. `factory.bin` is the complete image and
its start address is **0x0**. Do not flash it at the application offset. Do not
substitute an application-only firmware.bin or a private device backup.
Automatic reset after flashing may boot the new image; keep servo power disconnected.

## Confirm startup, then commission the mechanism

1. Look for the controller's setup hotspot, named `TelescopeCover-` followed by
   six device-specific hexadecimal characters; use `http://192.168.4.1/` after joining it.
   Configure home Wi-Fi and reconnect using the controller's local name/IP.
2. In **Configuration → About firmware**, verify the installed version, source
   commit and `web_control_multiturn_usb` profile against release.json. The page footer
   shows the installed version. Diagnostic downloads and startup logs include
   build identity. A `dev`/`dirty` version is a development build, not the named
   release candidate.
3. Keep the mechanism detached, inspect the electrical wiring and restore the
   correctly selected external supply only when ready for supervised servo checks.
   Confirm communication, identity/configuration, valid position and torque state.
   A successful USB write or an OPEN/CLOSED encoder estimate does not establish
   a safe physical cover position.
4. If validation fails, leave movement disabled, inspect the reason, and follow
   the project's servo/recovery notes. Do not silently rewrite EEPROM or switch
   firmware profiles until the actual configuration is understood.
5. Follow the assembly manual and fresh teaching process: Prepare → Teach →
   Review & save → Test. Stow the telescope before closing. Check each movement
   separately, with independent cover support available and Stop accessible.
6. Record supervised OPEN/CLOSE/STOP, settings persistence, startup and supported
   fault/recovery results for this exact image. Do not assume unattended readiness.

## Release discovery in the development source

The current development source adds **Configuration → Firmware updates**, with
automatic checks while the page is visible, a manual Check now button, stable/beta
selection, release notes and dated error/cache states. A newer compatible release
can produce an **Update available** footer link. This is not present in the older
published pipeline-test image and has not been installed on the active controller.

Discovery uses anonymous GitHub API access. Private/inaccessible repositories
cannot be checked without public access; no GitHub token is embedded. Compatibility
remains unknown unless both a matching project catalog entry and a controller
capability report are available. The catalog endpoint and production capability
integration are still pending, so a successful GitHub list alone cannot claim an
installable update. Beta opt-in never makes an unqualified pipeline test eligible.

Wireless installation remains disabled. The intended end state is one initial
USB installation followed by optional user-confirmed webpage updates; that
requires a separately qualified OTA-capable bootstrap. Current USB installation
and recovery remain destructive and require the mechanical precautions above.

## USB recovery

Keep external servo power disconnected and the cover supported. Close all serial
apps, reconnect with a known data cable, and try Connect & inspect again. If
bootloader entry fails, consult the board's BOOT/RESET procedure; do not guess a
sequence while the mechanism is attached. Driver installation may be required
if the board has no serial port on the host OS.

After a power/cable interruption during erase or writing, use USB to repeat the
complete clean installation and verify it. Do not infer that the previous image
or settings survived. If the page cannot inspect the table, resolve the USB/read
failure or use the documented command-line route after identifying the hardware.
Keep the same tested image/checksums; downgrade and settings migration paths are
not yet qualified.

## Maintainer packaging

From a clean committed repository with PlatformIO installed, build an unpublished
candidate in an isolated temporary source directory:

```sh
TELESCOPE_RELEASE_VERSION=0.1.0-beta.1 \
  ~/.platformio/penv/bin/python tools/package_release.py \
  --output dist/telescope-cover-0.1.0-beta.1-usb
```

`--commit <SHA>` can select a frozen commit explicitly. The packager reads only
tracked release source paths from that commit, excludes private local headers,
selects `web_control_multiturn_usb`, validates the application and all four USB boot inputs,
and derives image offsets and flash settings from that build. Development/probe
images are rejected. It first runs `tools/validate_release.py` inside the isolated
source: Python artifact tests, browser policy/model tests and selected C++ motion,
maintenance, commissioning and production multi-turn startup regressions. This offline gate does not run real USB or
browser hardware tests. Maintainers need Python/PlatformIO, Node 22+ and a C++17
compiler; end users of a hosted installer need none of those build tools.
The output directory contains the guarded installer, image,
checksums, metadata, scoped project license texts, font notices and this standalone
guide. Final framework/browser license clearance remains outstanding; a ZIP and its checksum
are beside it. ELF/map, build logs, build-input records and the curated source
archive are retained separately in the `-maintainer` directory. Do not overwrite an earlier candidate; use a new directory.

The manual CI workflow creates private candidate artifacts without publishing.
Project licenses are selected; see [coverage and third-party exceptions](../LICENSING.md).
Candidate status remains blocked on completed dependency notices/license packaging,
framework/browser redistribution obligations and hardware/browser acceptance. Nothing in this command
flashes hardware, creates a tag, uploads to GitHub or authorizes publication.

### Isolated public OTA bench test (2026-11-12)

The spare completed a real webpage-driven beta.1 → beta.2 update using the
[public test repository](https://github.com/Kbdavis/Telescope-Cover-OTA-Test).
The dedicated `bench_ota` environment excludes servo/telescope operations and uses
an isolated test key/channel. This is separate from operational cover firmware.
Its webpage discovers published test releases, downloads the signed application,
transfers bounded chunks, and confirms the exact new firmware, accepted startup,
matching transaction and unchanged application-settings record after reboot.

The measured [acceptance report](https://github.com/Kbdavis/Telescope-Cover-OTA-Test/blob/main/acceptance.json)
records a passing real happy path. The spare was left on beta.2 at its configured
LAN address; refreshing the page shows the bench UI. A controller already running
beta.2 will need a newer compatible test release to show another available update.
Legacy bench beta.1/beta.2 used a USB-console update key. Starting with beta.3,
the page obtains boot-scoped authorization automatically on the trusted home LAN;
there is no key field, USB lookup or browser pairing. Signed firmware checks and
explicit install confirmation remain. Runtime tokens and signing private keys are
not embedded in public downloads. This bench build requires already configured home Wi-Fi and
keeps USB as its recovery route. It provides no enclosure controls and does not
establish production OTA or power-loss/rollback qualification. See
[FIRMWARE_UPDATE_PLAN.md](FIRMWARE_UPDATE_PLAN.md), section 18, for exact evidence.

Bench beta.5 integrates firmware updates into **Configuration → Firmware updates**
and adds a compact blue **Update available** header badge across its views. The
badge opens/focuses Firmware updates. Automatic checking defaults on, with a
remembered browser checkbox to disable it; manual checks still work. The published
beta.5 package is signed for the exact installed beta.4 test build. The owner can
install it from beta.4's existing page; automation verified discovery but did not
install it. Wait for confirmed reboot before refreshing to see the new layout.
This remains the isolated update-test build with motion unavailable. A current
beta.5 page shows the badge only after a later compatible release is available.
