# Cover-relative travel and calibration

Single-endpoint fine tuning (2026-10-29): capturing CLOSED keeps an existing
draft OPEN position and recomputes the directed travel length. Capturing OPEN
already keeps CLOSED. The pair must remain 21–2047 counts apart in the recorded
opening direction; an invalid CLOSED replacement is rejected without changing
either draft endpoint. Review and Save operate on the updated endpoint and the
retained endpoint. A fresh teaching session still starts without either endpoint.
Adjustments remain drafts until explicitly saved.

Prepare-button correction: when a valid saved calibration and both draft
endpoints are present, the main Prepare button resumes that pair too. It must
not clear OPEN merely because the user entered through Prepare instead of the
Fine tune or Step 2 buttons. The browser test now explicitly exercises Prepare
→ its main button → capture CLOSED → Review with OPEN unchanged.

Prepare correction installed through OTA `ea1b88ea73acf94a23771b9e3c243ad3`,
ELF `7210e3b7dd17922dd56a1969550f2bf6eb4d86729b293915cdf3ce5d97a26510`.
Startup accepted; draft restored from saved CLOSED 329 / OPEN 3330, position
remained 346 and torque OFF. No hardware capture or movement was commanded.

Installed by OTA `4587fa1c0e3cd64837d52d6f4a97acf1`, ELF
`be2c4e91119d0c15ac3f3b3fccce3d6bdaa016644aebbdb686bb8b8e11377f18`.
Startup accepted; saved OPEN 3330 / CLOSED 329 retained, shaft still at 346
with torque OFF. The unsaved CLOSED 346 draft was not persisted by reboot;
the user can recapture it without moving and retain OPEN 3330. Worker tests
cover each endpoint independently, atomic rejection and zero-crossing arcs;
the real-browser regression verifies that Review unlocks after CLOSED alone.

Fine tune (2026-10-29): choosing **Fine-tune the positions** after saving now
resumes supervised teaching while preserving both draft endpoints, direction
and movement settings. If Prepare confirmations are missing or another safety
check blocks teaching, the UI returns to Prepare and requests the checks before
resuming. Resumption validates configuration, stable feedback and torque OFF;
it starts no movement and does not save changes. Saved calibration stays intact
until an explicit Save. Beginning a fresh teaching session still clears the
draft endpoints as before. Browser and worker regression tests cover the resume
path and verify that no motion is issued.

The **Step 2 — Teach positions** sidebar button also starts/resumes teaching
after the Prepare checks, rather than opening a locked panel. With existing
calibration it preserves the current draft endpoints. Missing confirmations or
other blockers return to Prepare with the reason. Checking the boxes alone
does not start teaching; either Begin teaching or the Step 2 button completes
that explicit action. The browser regression covers this direct sidebar path.

Direct Step 2 fix installed through OTA `cf9f796402357574e733ef963c9bf2f9`,
ELF `6216926faa3eae00387de109b18167139557a7defd802a22513a99f3a8d7c52d`.
Startup accepted; OPEN 3454 / CLOSED 354 and the 500-count capability retained.

Installed by OTA transaction `17da7f276569fe60d15fa5059852428e`, ELF
`1ffa12b16dbbd88b88fc1ef30341988c9d895b60f774c808046a0da46abee4bd`.
Startup accepted, saved OPEN 3454 / CLOSED 354 preserved, torque OFF, and
500-count jog capability retained. No teaching or movement command was sent
to the hardware to validate the UI change.

The current workspace uses four steps: **Prepare → Teach → Review & save → Test**.
The normal four-step interface is installed on `cover-dev.local` through authenticated OTA.
The physical boundary test failed safely; production crossing remains disabled.
The deployment history below records both the preceding five-step firmware and this update.

## Workflow

1. **Prepare:** confirm presence, mechanical support and a stowed telescope. Begin
   teaching validates the model/configuration, torque OFF and two stable position
   reads. It starts no movement. The controller opens a temporary supervised
   teaching domain internally; users do not enter raw travel limits.
2. **Teach:** use small supervised steps or position the detached mechanism by hand.
   Decreasing position moves toward OPEN for the remounted assembly (2026-10-29); beginning teaching
   records that direction automatically. Capture CLOSED as application zero,
   move toward OPEN, stop and capture OPEN. Selection/capture never moves the
   servo; recapturing CLOSED invalidates OPEN. There is no direction question.
3. **Review & save:** inspect 0–100% travel, shaft rotation, the endpoint settling
   margin, speeds, acceleration and timeout. Explicitly apply profile edits and
   save; NVS readback verifies the complete record. Saving starts no movement.
4. **Test:** request each endpoint move separately while watching. Support the cover
   before Stop releases torque. Encoder completion is not physical cover verification.

Presence/support/stow, authenticated home-network access, beta acknowledgement,
maintenance exclusion, fault latching, ownership and the 500-ms heartbeat remain
required. Beginning teaching never clears FAULT. Inspect and explicitly recover
before moving. Normal endpoint commands remain blocked while the draft is dirty.
Discard validates and restores the saved calibration without movement.

## Continuous coordinates and rollover

Current (2026-10-29): the active multi-turn commissioning firmware has passed
one bounded unloaded positive crossing: display 4016 → 20, final 19, using
native goal 4116. It permits supervised Manual steps up to 100 counts with
the approved exact RAM profile (max angle 0, phase 28, mode 0, offset 85,
EEPROM lock 1). A simple wrapped-goal retest at factory settings failed first;
continuous native targets and full-angle feedback were required for the passed
test. Reverse crossing and loaded/full travel remain unvalidated. See
[MULTITURN_COMMISSIONING.md](MULTITURN_COMMISSIONING.md). Do not reapply offset
1328 or assume arithmetic wrapping establishes a physical route.

Historical 2026-10-28: the fixed-reference development firmware installed on
`cover-dev.local` moves the former boundary inside the raw range. Old CLOSED
2386 becomes 1143, old OPEN 100 becomes 2953, and old zero becomes 2853.
The user teaches physical endpoints normally; no rollover control is needed.
The approved detached-shaft crossing test passed in both directions. Actual
new raw 4095/0 crossing stays gated. See
[fixed-reference commissioning](SERVO_REFERENCE_COMMISSIONING.md).

Raw feedback remains 0–4095 in diagnostics. The application stores explicit
opening direction and travel length. New circular calibration maps feedback onto
that taught arc; it does not choose an endpoint path from shortest distance or
accumulate a lap counter. For example, CLOSED 2386 → OPEN 100 in the increasing
opening direction is **1810 counts**, with continuous progress through 4095 → 0.
The reversed direction example maps identically to 0–100% travel.

Current taught travel is 21–2047 counts. This is the commissioned direct-goal
software bound, not a universal mechanical limit. New calibration derives allowed
application travel as **−10 through taught length + 10 counts**, providing the
existing endpoint settling margin. The complementary arc is excluded. Legacy
records retain their original inspected raw bounds. Out-of-arc feedback never
clamps to 0%/100%; unknown/stale feedback dims the diagram and hides its marker.
Degrees are shaft rotation (`counts * 360 / 4096`), not physical cover angle.

Controller preflight, progress, settling spread, direction checks and endpoint
classification use consistent coordinates across zero. Consecutive stable reads
use bounded circular deltas; these never infer a full revolution. Repeated valid
wrong-direction/outside/jump evidence faults and attempts verified torque OFF;
one anomalous sample or failed read cannot establish motion or an endpoint.
Startup validates the saved arc and stable feedback, never resumes movement,
and classifies interior feedback UNKNOWN. A point outside the saved arc requires
inspection and fresh teaching.

**Hardware crossing was tested and failed on this profile.** Production driver capability stays
false until the exact commissioned factory profile has passed a supervised
crossing test. The `web_control_rollover_bench` development build admits only
crossing segments of at most 100 counts, speed ≤100 and acceleration ≤10, using
that exact 40-byte factory profile. It changes only torque/goal RAM registers;
mode, angle limits, phase, offset and all EEPROM remain untouched. A wrong physical
route must stop/fault rather than be relabeled as successful rollover. Legacy
servo profiles do not inherit qualification from a different unit/profile.

## Timing

The browser and controller share the planning estimate:

- nominal = ceil(counts × 1000 / speed) ms;
- expected = nominal + ceil(20000 / acceleration) + 500 ms;
- recommended timeout = expected + max(1500 ms, nominal / 4) + 1000 ms, rounded
  up to whole seconds.

The ramp allowance is a heuristic pending loaded measurements. At 2000 counts,
speed 100 and acceleration 10, expected duration is 22.5 s and recommended timeout
29 s. Endpoint commands reject insufficient timeout before torque writes. Existing
profiles retain their timeout until teaching is reviewed or explicitly edited.
“Review both positions” raises an insufficient draft timeout automatically to
the recommended duration, without changing speed/acceleration, shortening longer
timeouts, saving NVS or starting motion. The 30-second cap remains; a larger
recommendation requires speed/travel review. The suggestion button only
edits the form; apply/save/test and fault recovery remain separate actions. The
existing 30-second cap is retained.

## Persistence and API

Schema **v5**, 34 bytes under `cover-cal/v1`, adds the reference-offset basis
to v4's circular flag, endpoints, limits, profile, direction and length; the final
word is the checksum. Fixed-reference builds convert old coordinates by −1243
modulo 4096 in RAM, preserving physical positions. Linear bounds that would wrap
require review instead of silently widening. Saving persists the new basis;
reloading it never shifts twice. A build using another basis requires review.
Loaded values and relationships are validated. V1 (16 bytes), v2
(26 bytes), v3 (30 bytes) and v4 (32 bytes) remain readable without flash migration. V1/v2 only
infer their original unambiguous linear path; long/rollover-looking legacy
endpoints require review and retain original raw diagnostic evidence. V3 retains
its linear bounds. No schema changes servo EEPROM.

`POST /api/calibration/begin` requires calibration/session/generation gates and
`present=yes`, `supported=yes`, `stowed=yes`, with fresh monitored stow when enabled.
It validates configuration and stable torque-OFF feedback in the worker.
The legacy `direction` route takes `direction=1|-1`, `observed=yes`; the guided
UI does not call it, and teaching captures use the assembly's fixed -1 direction.
Capture, profile, save
and discard remain queued worker operations. The legacy limits route remains
available for compatibility but is absent from the guided UI.

Status reports `travel_schema=5`, active/saved/draft reference offsets,
saved/draft circular flags, direction and length,
`teaching`, hardware `rollover_supported`, nullable travel counts/percent and raw
review evidence. HTTP 202 means queued, not physical success.

## Verification

Host suites cover both circular directions, every sample of the 1810-count example,
complementary-arc rejection, unqualified hardware with no torque writes, bounded
manual crossing, bad samples, restart, settings readback and fault latching. Worker
integration checks beginning teaching and capture/save across zero without motion.
Browser tests exercise the actual embedded assets against a local fake controller,
with four-step teaching, direction, explicit profile/save/test actions, continuous
rollover display and Stop visibility at 320–1440 px. These are software checks;
they do not prove physical servo routing, loaded clearance or unattended safety.

## Previous revision installation — 2026-10-28

Installed on `cover-dev.local` (`192.168.1.43`) through authenticated development
OTA transaction `886df5f180585151fcb4f2d4ceb8da79`, firmware
`c8aa7d71d55b4359f154bc42e58a11504696c641e634e9ab4b17d66287a028d4`.
The 1,111,536-byte candidate passed the existing CLOSED/maintenance/memory gates;
none were bypassed. Durable source/target/slot selection evidence reports COMPLETE,
startup is accepted, and the development OTA receiver remains available.

Before installation, the user explicitly confirmed presence, telescope stow and
a clear path and authorized one Close on the previous firmware. It moved from
raw 2731 to the CLOSED encoder band at 2391 (target 2386), completing in about
3.66 s without a fault. Endpoint holding torque remained ON. This observation
does not constitute movement validation of the new firmware.

After restart, read-only checks confirmed CLOSED at 2391, torque ON, no fault,
idle maintenance, and unchanged saved endpoints 2386/3464, limits 2015–4000,
speed 100, acceleration 10, timeout 15 s, and application/network settings.
The existing calibration loads with increasing-count opening direction and
1078 counts of travel without a review requirement. Served HTML, JavaScript
and CSS match the built workspace assets exactly. No calibration save, servo
EEPROM change or post-update movement was performed.

The preserved 15 s timeout is below this model's 17 s recommendation for the
1078-count full travel. Review and explicitly apply/save an adjustment in
Calibration Review & save before endpoint testing; installation did not silently change
it. Existing browser pages need a reload to load the new interface.

Private build, movement and OTA verification evidence is under
`diagnostics/travel-ota-cover-dev-20261028T182135Z/`. Per-target development state
is `.ota-dev/targets/cover-dev/state.json`; the separate root state for the
main controller at `192.168.1.135` was preserved.

Initial deployment history (2026-09-30): the original controller served the
calibration API while UNKNOWN at raw position 2034 with torque OFF and no saved
endpoints. Locked/invalid requests were rejected; those checks assigned no
endpoints and moved no hardware. That historical result does not validate this
new travel revision.

## Detached-shaft boundary test — 2026-10-28

User confirmed the servo was detached, shaft/horn clear, and authorized supervised
preparation, OTA and a small crossing/return test. Original draft and network
settings were preserved under `diagnostics/rollover-cover-dev-20261028/` before
movement. A −100-count jog brought the shaft inside the old saved bounds; the
saved 2386/3464 endpoints were restored, the timeout explicitly set to 30 s for
preparation, and Close completed at 2391 without fault.

Authenticated development OTA installed bench firmware
`05d0b7bec7e69a83cff16aba979f21220b60c466bf41bac9a0e5b6c35d35558f`, transaction
`e399e6967de4749e12cfd81f55f94a01`, with CLOSED/clean/stationary admission intact.
Startup accepted the saved calibration. Supervised 100-count noncrossing steps
staged the unloaded shaft to raw 4050 at speed 100 / acceleration 10.

The requested +100 crossing targeted raw 54. Valid feedback instead moved
4050 → 4046 → 4035, with the last valid controller read 4029 at 278 ms. The
controller latched FAULT and released torque. Subsequent stationary feedback was
4027, torque OFF. No failed reads were reported during that operation. The
negative return test was not run, and no automatic recovery occurred.

This measurement establishes that a simple wrapped absolute goal takes the wrong
physical route on the current mode-0 factory profile. Software modulo alone does
not deliver transparent boundary motion. Keep production capability false. A
separately approved and validated servo-reference adjustment or motion approach
is required before enabling the requested physical path. No mode, phase, offset,
limits, EEPROM lock or persistent servo configuration was written in this test.

The user subsequently confirmed post-fault inspection and authorized recovery,
return to CLOSED and normal firmware installation. Explicit recovery passed;
one supervised −100-count step returned inside the saved bounds. Restoring the
saved calibration and Close completed at raw 2391 without fault. The original
saved profile from the pre-test snapshot was restored exactly, including its
17-second timeout. Saved endpoints remain 2386/3464.

Authenticated OTA installed normal firmware
`8124efe786b67c4a333e04b25eecaa7d30a152230747eb693c1075fdd9e4ab8d`, transaction
`6197969c981ee70ccaa605eba1f48b88`, with admission checks intact.
Read-only verification confirmed accepted startup, CLOSED, torque OFF, clean
calibration, no fault, idle maintenance, unchanged application/network settings,
and `rollover_supported=false`. Served HTML/JavaScript/CSS exactly match the
frozen normal candidate; the HTML has four calibration steps and no Safe travel
form. The bench build has been replaced. Reload existing browser pages.

Evidence, original draft, operation traces and verification results are retained
under `diagnostics/rollover-cover-dev-20261028/`. No servo EEPROM was changed.

## Reversed mounting (2026-10-29)

The user mechanically reoriented the servo: decreasing raw counts now opens;
increasing closes. Manual and teaching buttons (including held repeats) map
semantic OPEN/CLOSE to this direction. No phase, offset, or other servo
configuration changes implement the reversal. Saved +1 calibration remains in
NVS and appears as requiring review; normal OPEN/CLOSE and restoring that old
calibration are blocked. Begin teaching, capture both physical endpoints, review
and save a new -1 calibration. No endpoints are swapped automatically.

Manual Control can position a validated stationary servo outside the configured
cover range without changing saved calibration or beginning teaching. It requires
explicit damage-warning acknowledgement and uses the raw interval 0–4095; it
cannot cross encoder zero or clear a latched fault. Normal and teaching movement
keep their configured range checks.
