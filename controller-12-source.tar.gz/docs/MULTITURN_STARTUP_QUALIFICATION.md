# Automatic RAM setup qualification

Prepared and installed 2026-11-09. **Qualification candidate; attached-cover
startup and external power-cycle restoration remain unqualified.** Normal and
existing probe builds retain their previous startup behavior.

## First live installation

After the exact-register proposal and request to support the cover and detach
the arm, the user replied `go`. This was taken as approval for installation and
the listed RAM writes, and confirmation of the requested mechanical preparation;
mechanical clearance was not independently observable over the network.

Preflight found stationary position 26 and torque ON. An explicit authenticated
Stop released torque; subsequent status confirmed stationary position 26 and
torque OFF before preparation. Authenticated recovery OTA transaction
`02d24b7531ab14b779bec843301ec5e3` completed and boot identity matched candidate
ELF `4dd7eae27ce3363f4f7543727eedd5928bda6a98ee15a42e80e1bd1a9d9ec757`.
Startup was accepted. The before/after 40-byte snapshots differed only at 11,
12 and 18; the full native profile and lock 1 passed verification. Feedback
before and after setup was 26, native feedback 26, torque OFF, no motion or
holding, and `rollover_supported=true`.

Saved CLOSED 346 / OPEN 25, opening direction -1, 321-count arc, offset 85 and
motion profile were unchanged. The reported OPEN state derives from that saved
endpoint; it does not prove the new cover is fully open. Fresh teaching is
required for the changed mechanics. No movement, teaching/save, subsequent
reboot or external power-cycle test was commanded in this installation.
Evidence: `diagnostics/2026-11-09-multiturn-startup/{before-status,before-servo,
stopped-status,after-status,after-servo}.json` (ignored local files).

## Problem and next step

Boundary crossing already uses an explicit logical travel arc and continuous
native servo goals. It depends on RAM configuration that the existing probe
never reapplies at boot. The controller at 192.168.1.43 reported the exact factory
profile, position 25, torque OFF and `rollover_supported=false`, despite having
the multi-turn-capable firmware installed. Power loss or replacement can explain
this; neither cause has been established for this incident.

`web_control_multiturn_startup` is a separate candidate for qualifying restoration
of that profile at startup. Installing it would cause automatic RAM writes on a
subsequent factory-profile startup. Do not install it as an ordinary firmware
update before exact-register approval and a detached, supported-cover test.

## Fixed behavior

The dedicated servo worker calls `prepareMultiTurnStartup` before allowing
stationary controller initialization. No HTTP handler programs the servo.

- Require model 777 and the exact supported 40-byte identity/configuration
  snapshot. Arbitrary models, legacy profiles and partially applied settings
  are rejected rather than repaired automatically.
- With the factory profile, require torque OFF, zero speed, no moving flag and
  stable feedback across a 100 ms observation window. Recheck the exact factory
  snapshot, EEPROM lock 1, torque and feedback immediately before writes.
- Write only maximum angle registers 11–12: `ff 0f` → `00 00`, and phase
  register 18: `0c` → `1c`. Keep mode 0, minimum 0, offset 85 and lock 1.
  No EEPROM unlock, goal, torque or calibration write is performed.
- Verify the full profile, lock, torque OFF, stationary feedback and unchanged
  native position. Equal wrapped angles a full turn apart are not sufficient.
- If already configured, perform reads only and preserve native turns,
  including negative positions. Existing startup policy still decides whether
  retained torque is permissible; setup never releases or enables it.
- Never repeat an attempted configuration write within a driver lifetime.
  Ignored writes, missing acknowledgements and failed verification latch a
  driver validation failure. Teaching, Recheck and torque enable cannot bypass
  it. Inspect before explicit recovery/reboot; do not retry by rebooting blindly.
- Once established, profile loss during the same controller boot rejects
  configuration validation and motion. It is not repaired inside a movement or
  silently treated as ordinary single-turn mode. A fresh controller startup is
  needed to prepare the reset servo again.

Diagnostics identify this candidate as
`exact_multiturn_ram_startup_qualification`. Existing supervision, speed 100 /
acceleration 10 caps, 500-count jog cap and bounded taught arcs remain in force.

## Calibration and replacement limits

This candidate does not change or erase saved calibration. A new cover, a
remount or a replacement servo requires explicit fresh teaching before normal
endpoint commands. The supported snapshot identifies a configuration class,
not an individual servo: two identical units cannot be distinguished with
these bytes. Automatic replacement detection is **not** implemented or promised.

Calibration progress is already logical travel from CLOSED, independent of raw
encoder wrapping. A complete builder release still needs guided first setup,
clear profile-loss messages, replacement/reteach handling and qualification of
attached-cover startup and failure behavior. This candidate is the next hardware
qualification step, not that finished release.

## Local verification

```sh
~/.platformio/penv/bin/pio run -e web_control_multiturn_startup
c++ -std=c++17 -Wall -Wextra -Werror \
  -DCOVER_REFERENCE_PROBE -DCOVER_MULTITURN_PROBE -DCOVER_MULTITURN_STARTUP \
  -Itests/host -Isrc tests/host/multiturn_driver_test.cpp \
  src/servo_controller.cpp -o /tmp/cover-startup-driver-test
/tmp/cover-startup-driver-test
c++ -std=c++17 -Wall -Wextra -Werror \
  -DCOVER_REFERENCE_PROBE -DCOVER_MULTITURN_PROBE -DCOVER_MULTITURN_STARTUP \
  -Itests/host/diagnostics_shim -Isrc \
  tests/host/maintenance_integration_test.cpp src/cover_controller.cpp \
  src/emergency_shutdown.cpp src/alpaca_client.cpp -o /tmp/cover-startup-worker-test
/tmp/cover-startup-worker-test
```

Driver checks cover cold/warm startup, both signed turns, servo-only reset,
fresh-controller setup, torque/motion/configuration rejection, drift, lost
acknowledgements, ignored writes and an unexpected full-turn feedback shift.
Actual-worker checks verify that failed setup blocks startup readiness and
successful startup issues no movement or torque release. Existing multi-turn,
ordinary-driver and browser travel-model regressions are also exercised.

## Hardware qualification sequence

Steps 1–2 passed for the first installation above; the remaining physical
qualification steps have not been performed.

1. Obtain approval for the exact writes above and confirm the cover is supported
   with the arm detached and the shaft clear. Archive live settings, profile,
   native/raw feedback and the source firmware identity.
2. Install by authenticated recovery OTA with its actual admission checks.
   Verify startup writes/readback, stationary position and torque OFF. Do not
   teach or command motion as a side effect of installation.
3. Test an ESP32-only reboot with the RAM profile retained: verify no reference
   jump or new configuration writes. Then test an external servo power cycle
   together with a controller restart: verify restoration with no movement.
4. With separate supervised movement authorization, test small positive and
   negative native crossings, hold staging, Stop and return. Compare native
   position as well as display position and preserve traces.
5. Test loss of the RAM profile while the controller stays powered: movement
   must remain blocked pending inspected recovery. Do not deliberately reset or
   disconnect a loaded mechanism to exercise this case.
6. Only after these pass, plan attached-cover checks and fresh endpoint teaching.
   Validate full loaded travel and restart behavior before promoting automatic
   setup into the normal builder firmware.

For recovery, factory-only firmware remains incompatible with an active native
profile. Verify exact factory restoration and single-turn feedback first, or
retain the existing multi-turn-aware probe firmware. Do not use the disqualified
offset-1328 reference build.
