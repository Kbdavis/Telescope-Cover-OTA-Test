# Push-based OTA firmware investigation

**Investigation date:** 2026-10-22, America/Phoenix  
**Repository examined:** `c794bd2dee4f9dbafeabeac0efec3e7626c53a11`  
**Scope:** VS Code/PlatformIO pushes firmware to the controller over the local Wi-Fi network. Investigation and this document only; no firmware, configuration, dependencies, or controller state were changed. No build, upload, reboot, servo operation, serial connection, or live controller interrogation was performed.

**Active implementation plan:** [OTA and WiFi diagnostics implementation plan](OTA_IMPLEMENTATION_PLAN.md).
It incorporates subsequent build/diagnostic groundwork, merges remote capture
with OTA, and supersedes the proposed sequencing and receiver choices below.
This investigation remains a dated record of its original findings; statements
about missing features and artifact sizes describe that investigation state.

## 1. Feasibility and evidence boundaries

Push OTA is feasible with the existing Arduino-on-ESP32 stack. The existing build artifacts already contain two suitably sized application partitions and OTA metadata. ArduinoOTA and the `espota` uploader are installed with the framework. An initial USB installation is required because the current project does not run an OTA receiver; changing the partition layout is not presently indicated.

A reliable implementation requires more than adding `ArduinoOTA.handle()` to `loop()`. Important integration findings are:

- The transfer blocks its calling task, while cover motion depends on a 500 ms browser supervision lease.
- The current deliberate reboot can preserve servo torque, but its RTC variable is not a guaranteed cross-firmware interface.
- The installed framework enables rollback support, but its default startup code accepts a pending image before the project's health checks run.
- The installed PlatformIO uploader enables debug logging that can print its authentication options.
- The new 1,000-message controller log consumes about 124 KB of runtime heap. Available heap with that version running has not been measured.

Throughout this document:

- **Verified local fact** means inspected repository code, installed package source/configuration, or existing local artifacts.
- **Official capability** means behavior checked against the linked primary documentation/source. Version-specific sources are used for the installed Arduino 2.0.17 / IDF 4.4.7 behavior; current stable documentation was also consulted.
- **Recommendation** describes work still to implement.
- **Unverified** identifies a hardware measurement, deployment condition, or design choice that cannot be established from local code.

No conclusion here establishes that the currently running controller matches the latest local artifact. Older documentation contains historical states; current source and decoded artifacts take precedence for this investigation.

## 2. Current hardware, build, and storage

### Verified local facts: target and installed tools

| Item | Finding and evidence |
| --- | --- |
| Hardware | Waveshare Servo Driver with ESP32; ESP32-D0WD-V3 revision 3.1, 40 MHz crystal, ST3215 ID 1/model 777. [AGENTS.md](../AGENTS.md) and [HARDWARE.md](HARDWARE.md) record prior bench identification. |
| Physical flash | 4 MB, historically identified by esptool on 2026-09-30 according to `docs/HARDWARE.md`; not queried again here. |
| PlatformIO board | `esp32dev`; installed board manifest specifies ESP32, 240 MHz CPU, DIO/40 MHz flash, 4 MB flash and a 327,680-byte RAM budget. |
| PlatformIO Core | Installed Python package reports **6.2.0**. VS Code extension version was not inspected. |
| Platform | [platformio.ini](../platformio.ini): **`espressif32@7.1.3`**, Arduino framework. |
| Framework package | Installed `package.json`: **`4.20017.260907+sha.dcc1105b`**. This is the package version, not Arduino core 4.x. |
| Arduino core | Installed `cores/esp32/esp_arduino_version.h`: **2.0.17**. |
| ESP-IDF under Arduino | Installed version header: **4.4.7**. The existing application image identifies its IDF build as **`v4.4.7-dirty`**; do not assume an unmodified upstream binary. |
| Production environment | **`web_control`**, with `COVER_WEB_CONTROL`. `default_envs` is currently **`esp32dev`**, which builds the scaffold. Every production build/upload command must explicitly select the correct environment. |
| USB | `web_control` uses 115200 baud. Historical Mac port: `/dev/cu.usbserial-0001`; enumerate ports before future use. |
| Web assets | `tools/embed_ui.py` generates compressed assets linked into application flash; the beta notice is also embedded. Firmware OTA can therefore update this UI without filesystem OTA. |
| Existing OTA integration | No ArduinoOTA receiver, OTA service/task, OTA maintenance state, or OTA uploader environment exists. `esp_ota_get_app_description()` in diagnostics reports identity; it does not enable OTA. |

The installed package roots are under `~/.platformio/`. Relevant package files are listed in section 10. No package was installed or upgraded.

### Verified local facts: actual generated partition table

The table below was decoded directly from `.pio/build/web_control/partitions.bin`. It matches the installed framework's `tools/partitions/default.csv`. There is no `board_build.partitions` override in the project. PlatformIO documents `default.csv` as the Arduino default. [PlatformIO partition configuration](https://docs.platformio.org/en/latest/platforms/espressif32.html#partition-tables).

| Label | Type/subtype | Offset | Size | Purpose |
| --- | --- | --- | --- | --- |
| `nvs` | data / nvs | `0x9000` | `0x5000` = 20,480 B | Application settings, calibration and other NVS namespaces |
| `otadata` | data / ota | `0xE000` | `0x2000` = 8,192 B | Boot-slot selection/state |
| `app0` | app / ota_0 | `0x10000` | `0x140000` = 1,310,720 B | First application slot |
| `app1` | app / ota_1 | `0x150000` | `0x140000` = 1,310,720 B | Second application slot |
| `spiffs` | data / spiffs | `0x290000` | `0x160000` = 1,441,792 B | Filesystem area; not needed for the embedded live UI |
| `coredump` | data / coredump | `0x3F0000` | `0x10000` = 65,536 B | Reserved coredump area; this table alone does not prove coredump recovery is operational |

The selected prebuilt SDK header also contains a `CONFIG_PARTITION_TABLE_SINGLE_APP` setting from its framework build. That setting does not override the independently generated project partition table decoded above; it is not evidence that this application has only one slot.

There is no factory/recovery application partition. Two application slots are not a separate immutable rescue firmware.

**Recommendation:** retain these offsets and sizes initially, and later pin the existing table explicitly for reproducible USB/OTA builds. Do not repartition merely to introduce OTA. Before the first USB bootstrap, verify the installed table against the intended one using an approved, non-destructive procedure; the local generated table is not a readback of the controller's flash.

### Verified local facts: existing image size and identity

These are measurements of existing artifacts, not a rebuild:

| Artifact/property | Measurement |
| --- | --- |
| `.pio/build/web_control/firmware.bin` length | **997,136 bytes**, about **973.77 KiB** |
| Occupancy of either application slot | **76.08%** |
| Remaining slot space before adding OTA | **313,584 bytes**, about **306.23 KiB** |
| Binary SHA-256 | `8a4a4b18c0e7dee8d4e9f7532941cab987f6d5e2933dd14ff922070c8cd02d45` |
| Embedded application ELF SHA-256 | `f39d6a4a353040df7621ff3b9bef1341f1cf3d9cdee19cfd6d1d72a706ca9531` |
| Existing `bootloader.bin` length / SHA-256 | 17,536 B / `3d234a7471f67b013686dabd4dee7c1fa915c9928463616a94bc9297acf1abf8` |

Use the **binary length** for transfer/slot budgeting. An ELF file's disk size, section totals, and PlatformIO's program-size display are different quantities. The future OTA-enabled binary must be measured again, including padding/signatures if introduced.

**Conclusion:** current slot capacity is sufficient to investigate ArduinoOTA without resizing. The initial USB installation should install a receiver-capable production image and establish the expected bootloader/table. Subsequent application-only OTA does not update those infrastructure components.

### Verified local facts and limitations: memory

Existing ELF sections show `.dram0.data` = **25,392 B** and `.dram0.bss` = **27,032 B**, totaling **52,424 B** of static DRAM. `.ext_ram.bss` is zero. Neither the board configuration nor project flags establish usable PSRAM; do not budget against external RAM. The SDK's PSRAM-capable code/configuration does not prove physical PSRAM is present and initialized.

[diagnostics.h](../src/diagnostics.h) and [debug_buffer.h](../src/debug_buffer.h) define 1,000 entries. An ESP32 entry is 124 bytes after alignment: sequence, timestamp, level and 112-character storage. Twenty allocations of 50 entries require **124,000 B**, plus the buffer object and allocator overhead. Allocation occurs at startup in `beginDiagnostics()` even when the Debug tab is hidden. Allocation failure leaves serial logging available and reports debug storage unavailable; it is not free memory reserved for OTA.

The cover task has a 6,144-byte stack; the Alpaca task has a 12,288-byte stack; diagnostics also has its own task/queue. Those and Wi-Fi/TCP allocations are additional runtime consumers. The installed Update implementation allocates a **4,096-byte** write buffer, plus other bookkeeping; TCP, UDP, authentication, service/task stacks and fragmentation add to the OTA requirement. [Installed-version Update implementation](https://github.com/espressif/arduino-esp32/blob/2.0.17/libraries/Update/src/Updater.cpp).

A saved `diagnostics/upload-20261021-settling/after.json` records 196,280 B free heap and 188,204 B minimum heap for older ELF `ced01d6d…`. This predates the large log and is **not** current runtime headroom. Do not subtract 124 KB from that sample and treat the result as a measurement of this build.

**Unverified / implementation gate:** measure free heap, minimum free heap, largest allocatable internal block, log allocation success and task stack high-water marks on the actual receiver-enabled firmware. Exercise Wi-Fi, web requests, Alpaca and a full log. An upload should fail closed before writing if measured memory requirements cannot be met. Select a numerical reserve after measuring peak usage; a small total-free-heap check alone is inadequate. Do not silently discard or shrink the requested 1,000-message log to make OTA fit.

## 3. Official OTA capabilities and host workflow

### What ArduinoOTA and espota provide

ArduinoOTA supplies a Wi-Fi receiver with password/password-hash configuration, start/error/progress/end callbacks, an adjustable receive timeout and optional automatic reboot. It is included with the installed framework; no third-party OTA dependency is needed. The BasicOTA example demonstrates registration and repeated handling, but its network/reboot policy is unsuitable to copy wholesale into this safety controller. [ArduinoOTA interface](https://github.com/espressif/arduino-esp32/blob/2.0.17/libraries/ArduinoOTA/src/ArduinoOTA.h), [official BasicOTA example](https://github.com/espressif/arduino-esp32/blob/2.0.17/libraries/ArduinoOTA/examples/BasicOTA/BasicOTA.ino).

PlatformIO supports `upload_protocol = espota`, a destination IP/hostname and uploader flags. Its current documentation has an inconsistent port-default bullet; the installed uploader and library both specify **3232**, which should be configured explicitly. [PlatformIO OTA workflow](https://docs.platformio.org/en/latest/platforms/espressif32.html#over-the-air-ota-update).

### Network direction matters

The developer initiates a logical **push**, but the installed `espota.py` first sends a UDP invitation/authentication exchange to the ESP32, then listens on the developer computer. The ESP32 opens a TCP connection back to that listener and receives the image. The uploader defaults to a randomly chosen host TCP port between 10000 and 60000; use a fixed port such as **3233** for predictable firewall rules. This is not an upload to the existing HTTP server. [Espressif uploader source](https://github.com/espressif/arduino-esp32/blob/2.0.17/tools/espota.py).

Required connectivity for the proposed explicit configuration:

| Traffic | Requirement |
| --- | --- |
| Developer → controller | UDP destination **3232**, with replies allowed |
| Controller → developer | TCP destination **3233**, allowed by the Mac firewall and LAN |
| Name resolution, if used | Existing `.local` mDNS normally needs local-link multicast UDP 5353; IP uploads avoid this dependency |
| Proposed maintenance preflight/status | Existing controller HTTP port **80**; this control plane still needs authorization, described below |

Use a DHCP reservation/numeric IP first. An existing mDNS hostname can work when the Mac resolves it, but guest isolation, routed VLANs, multicast filtering, VPN route selection and NAT can break discovery or the reverse TCP connection. Specify the developer's reachable LAN interface when necessary. Internet port forwarding is outside the recommended scope; this transport is for a trusted LAN or appropriately routed VPN with explicit firewall controls.

[network_setup.cpp](../src/network_setup.cpp) already owns mDNS and can stop/restart it when the hostname changes. **Recommendation:** initially disable ArduinoOTA's own mDNS management and use the existing hostname/IP. Otherwise `ArduinoOTA.end()` can also end the shared mDNS responder. Reconcile advertising ownership before offering automatic OTA discovery. Prefer STA-only service exposure; the recovery AP is open, and the receiver must not become reachable through it merely because a UDP socket binds all interfaces.

### The uploader currently risks printing credentials

**Verified local fact:** installed `platform-espressif32/builder/main.py`, in the `espota` branch, sets uploader flags including `--debug`. Installed `tools/espota.py:main()` logs its parsed `options` object at debug level, which includes the `auth` field. Passing a password through an environment interpolation still exposes it after expansion; verbose command output and process arguments are additional paths. [PlatformIO v7.1.3 uploader integration](https://github.com/platformio/platform-espressif32/blob/v7.1.3/builder/main.py).

**Recommendation:** include a small reviewed host wrapper and PlatformIO hook as part of implementation. They should preserve the espota wire protocol while reading the secret inside the uploader process, removing the unconditional debug-option dump, avoiding a secret in the generated command line, and redacting structured diagnostics. Calling/importing the bundled uploader's transfer function is one possible approach; do not patch files inside `~/.platformio/packages` as the project solution. An environment variable avoids Git exposure but is not protection from a privileged local user.

This credential/logging issue must be resolved before declaring password-protected PlatformIO upload ready for routine use.

### Proposed environments and commands — examples only

The following is **illustrative future configuration**, not installed functionality. The two named scripts do not exist. `COVER_ENABLE_OTA` is a proposed project flag. The shared production image must include the receiver in both its USB and OTA builds.

```ini
; Future change to the shared production environment:
[env:web_control]
; Keep the existing platform/board/framework inheritance and embedded assets.
build_flags = ${env:esp32dev.build_flags} -DCOVER_WEB_CONTROL -DCOVER_ENABLE_OTA
; Keep extra_scripts = pre:tools/embed_ui.py and the beta-notice embedding.

[env:web_control_usb]
extends = env:web_control
upload_protocol = esptool
upload_speed = 115200

[env:web_control_ota]
extends = env:web_control
upload_protocol = espota
upload_port = ${sysenv.COVER_OTA_HOST}
extra_scripts =
    pre:tools/embed_ui.py
    post:tools/configure_ota_upload.py
; Proposed hook substitutes a reviewed secret-safe upload wrapper.
; Its CLI contains only nonsecret parameters:
upload_flags =
    --port=3232
    --host_port=3233
; Do not add --auth=<secret> to this file or its generated command line.
```

Environment substitution is supported by PlatformIO. The proposed wrapper would read `COVER_OTA_PASSWORD` internally, obtain worker clearance, upload, then verify the running identity. The firmware credential/verifier would be provisioned separately through an ignored local header or a deliberate NVS provisioning step. [PlatformIO interpolation reference](https://docs.platformio.org/en/latest/projectconf/interpolation.html).

Future operator commands, **not executed during this investigation**:

```sh
# First receiver installation / USB recovery after verifying the serial port:
pio run -e web_control_usb -t upload --upload-port /dev/cu.usbserial-0001

# Build the production OTA image without uploading:
pio run -e web_control_ota

# After secret-safe tooling, receiver firmware and clearance exist:
# COVER_OTA_HOST is <CONTROLLER_IP> or <CONTROLLER_HOSTNAME>.local.
# COVER_OTA_PASSWORD comes from a secure prompt/keychain/environment, never a literal here.
pio run -e web_control_ota -t upload

# Equivalent explicit destination override:
pio run -e web_control_ota -t upload --upload-port <CONTROLLER_IP>
```

VS Code should select the corresponding named Project Task/environment. The upload wrapper must reject scaffold/diagnostic/motion-bench images and require the expected production build identity. A successful uploader exit is not yet proof that the new firmware booted or that motion remains locked correctly.

## 4. Safety, scheduling and torque retention

### Verified local architecture

[main.cpp](../src/main.cpp), `setup()`/`loop()`, starts diagnostics, cover control, HTTP/network service and Alpaca. The HTTP loop is synchronous. [web_control.cpp](../src/web_control.cpp), `worker()`/`supervise()`, owns the servo on core 1 at priority 2, normally yielding every 5 ms. Web commands are queued; entries at least 400 ms old are discarded. Normal movement and supervised jog holds require the owning browser heartbeat to be under **500 ms** old. Stop has a dedicated flag and clears pending work. Unexplained motion faults release torque.

`requestNetworkMaintenance()`, `networkMaintenanceReady()` and `endNetworkMaintenance()` provide a useful worker-acknowledged exclusion mechanism. Ordinary network maintenance requires stationary operation and verified torque OFF, with a narrowly defined disconnected-servo recovery exception. Manual jog commands also pass through the worker's maintenance rejection, so an OTA exclusion can cover them without trusting UI controls. A future OTA exclusion must also cover recovery, torque tests, calibration, reboot, Wi-Fi/hostname changes and every other actuator path.

The Alpaca worker runs independently on core 0. Safety requests have a 1200 ms deadline and optional telemetry uses 700 ms. It is monitoring-only; no native Seestar worker starts from `main.cpp`. The diagnostics task, Wi-Fi tasks and browser polling share CPU, heap and network resources with any future OTA transfer.

### Why a simple onStart callback is insufficient

In the inspected ArduinoOTA implementation, `handle()` can run the whole transfer synchronously. `_runUpdate()` calls `Update.begin()` before its void `onStart` callback, and the callback has no boolean rejection result. A receive timeout is not a complete arming/authentication/connect/transfer deadline. [Version-specific receiver implementation](https://github.com/espressif/arduino-esp32/blob/2.0.17/libraries/ArduinoOTA/src/ArduinoOTA.cpp).

**Recommendation:** acquire and acknowledge an exclusive update lease **before accepting a transfer**. Do not start flash writing and then try to obtain motion-worker clearance. Keep a defensive callback check that aborts invalid commands/expired clearance, but do not make that the only gate. Permit application (`U_FLASH`) updates only; reject filesystem commands.

Running the blocking transfer in the HTTP loop would prevent normal status/Stop requests from being serviced. A separate modest-priority OTA task can preserve some HTTP responsiveness, but it cannot guarantee normal real-time behavior: flash erase/write operations affect code/cache execution across cores. [Espressif flash concurrency constraints](https://docs.espressif.com/projects/esp-idf/en/v4.4.7/esp32/api-reference/storage/spi_flash.html#concurrency-constraints-for-flash-on-spi1). Consequently, OTA must never overlap active motion or browser-supervised holding, and neither a second core nor a longer heartbeat is an acceptable substitute for exclusion.

### Current torque-retaining reboot: what it actually does

Verified paths:

1. `network_setup.cpp`, `/api/controller/reboot`, validates a request and calls `requestRebootMaintenance(retainTorque, client)`.
2. `web_control.cpp:worker()` calls `CoverController::prepareReboot()` on the servo-owning task.
3. [cover_controller.cpp](../src/cover_controller.cpp), `prepareReboot(true)`, requires no movement/fault/torque test, validates configuration and two stable positions inside limits, enables current-position holding when needed, confirms torque ON, and enters `State::Retained`.
4. `Retained` is neither moving nor browser-supervised `Holding`. The worker can take over the stationary hold without a heartbeat-triggered release. Stop can cancel clearance.
5. Immediately before `ESP.restart()`, `markRetainedReboot()` writes a one-use `RTC_NOINIT_ATTR` marker. Startup accepts that marker only for `ESP_RST_SW`, clears it, and allows `initializeStationary(..., allowPowered=true)` after fresh configuration/position validation.
6. `prepareReboot(false)` releases torque instead. Manual permission and interrupted motion are not restored automatically.

[servo_controller.cpp](../src/servo_controller.cpp), `enableTorque()`, stages the measured current position before enabling a previously released servo, rather than blindly reusing an old target. This is useful, but it is not proof that a loaded cover cannot move during enabling.

**Limitation:** the marker is a variable at a linker-assigned RTC location. A different firmware image can change that layout. Existing code does not define a stable cross-image handoff format, expected target identity or rollback contract. Therefore the same-image manual reboot tests do **not** establish torque-retaining OTA safety. A receiver that simply lets ArduinoOTA auto-reboot would also omit the project's explicit handoff.

**Recommendation:** preserve the user's torque preference explicitly. For retained-torque OTA, use a reviewed, versioned handoff understood by the bootstrap, new image and rollback image—e.g. a small dedicated NVS record containing a checksum, transaction phase, torque policy and expected application identity. Match it to reset cause and incoming image, consume it deliberately, and keep movement locked until startup reconciliation succeeds. Prepare the record before activation; test power loss between every phase. Do not silently expand the existing RTC marker's meaning or assume power-loss startup should enable torque.

Initial bench OTA tests should use a mechanically supported cover and an explicit torque-OFF policy. Production retained-torque OTA remains blocked until the cross-image handoff and physical hold tests pass. The manual page's checkbox and the Advanced endpoint setting should not be inferred as authorization for a background upload; the push preflight should state its torque policy.

### Recommended update state machine

`IDLE → PREPARING → ARMED → RECEIVING → VERIFIED → REBOOTING → BOOT_CHECK → READY`

A rejection/failure leads to a reported failure/inspection state; it never resumes a queued movement.

1. **Prepare:** a host wrapper submits an authenticated update request with target image metadata and explicit torque policy. Reject movement, faults, another maintenance owner or an unsafe hold transition. Atomically reserve ownership so a manual jog cannot race the request.
2. **Worker clearance:** drain/reject movement requests, verify configuration/position/torque, and establish a stationary hold or verified release. Require fresh evidence and adequate measured memory. Return an expiring transaction ID only after worker acknowledgment.
3. **Arm:** expose/service the OTA receiver only for that bounded transaction on the permitted LAN interface. Pin expected uploader/image identity where feasible. Keep the worker exclusion even if the browser closes. Set `setRebootOnSuccess(false)` for application-controlled completion.
4. **Receive:** accept only application firmware. Recheck clearance in callbacks; use the OTA-owning task for Update calls. Worker Stop/fault requests cancellation; it must not concurrently call the global Update object. Pause Alpaca requests at a worker boundary, mark published stow unavailable, avoid settings writes, and throttle progress/debug downloads.
5. **Verify:** enforce length/digest/product/build checks before activation where supported. A receiver-side product allowlist is extra work; host checks alone protect against mistakes, not a malicious authenticated uploader.
6. **Finish:** stop the OTA listener and keep all movement locked after success, because `Update.end()` has already selected the next boot image before `onEnd`. Complete the durable torque handoff and controlled reboot; verify the new ELF identity and boot health from the host afterward.
7. **Fail/cancel:** abort and clean up the updater on its owning task, stop the listener, cancel stale commands, publish a clear outcome and reconcile torque. Never automatically reopen/close or resume manual movement. Retain exclusion if activation or physical safety is uncertain. A retry must acquire a new transaction.

Proposed starting limits for testing: 60 seconds to begin an armed upload and 180 seconds for the whole transfer. These are recommendations, not proven safe timing. ArduinoOTA's receive timeout alone does not enforce them; its connect/authentication/error paths need explicit audit. Do not kill a task in the middle of flash/Update operations to enforce a deadline.

### Failure and concurrency expectations

| Condition | Required behavior / evidence to collect |
| --- | --- |
| Moving, unacknowledged hold, fault or maintenance conflict | Reject before exposing the receiver or writing the inactive slot; leave existing command/fault ownership intact. |
| Wrong password / malformed invitation | No application activation; bounded auth/arming lifetime; no unrelated torque-release side effect from an authentication-error callback. |
| Oversized or incompatible image | Reject and report clearly; inactive-slot writes, if any occurred, must never turn into selection of that image. |
| Sender cancellation, timeout, Wi-Fi loss or stalled host TCP | Abort/cleanup; current application remains selected if activation has not completed. No automatic retry or movement. Test repeated retries for leaked memory. |
| Stop or valid servo fault during transfer | Worker handles Stop/fault and signals OTA cancellation. Record actual latency during flash erases. Do not advertise uninterrupted motion-grade response. |
| Power loss during application download | ESP-IDF's inactive-slot/dual-sector metadata design supports retaining a bootable selected image; actual behavior must be tested on this receiver. Mechanical holding is lost if servo power is lost. |
| Power loss or cancellation after activation | The next boot may already select the new image; inspect boot metadata/identity. Do not report that every failed host command leaves the old firmware selected. |
| Successful transfer, bad application startup | Needs the separately designed rollback health policy in section 6; successful byte transfer is not successful deployment. |
| Web UI during upload | Display update/maintenance state and lock controls. Browser errors may be expected, but must not send an automatic Stop that destroys an intentional transferred hold. Existing `expectRestart()` alone does not handle every communication-loss/heartbeat path. |
| Alpaca after failure/reboot | Resume fresh read-only polling; discard cached safety clearance and require new valid stow evidence before future closing. |
| Diagnostics | Log transaction, phase, progress at a bounded rate, failure reason and old/new build identity. No credentials, packet contents containing authentication, or per-packet log floods. |

ESP-IDF documents separate application slots and redundant OTA metadata for update selection. That protects the application update process; it does not establish safe mechanical behavior or make partition-table/bootloader replacement equally safe. [Current OTA overview](https://docs.espressif.com/projects/esp-idf/en/stable/esp32/api-reference/system/ota.html).

## 5. Authentication, integrity and settings

### Official capability and its limits

The inspected ArduinoOTA transport uses an MD5-based challenge/response when configured with a password or password hash. Without configuration, authentication is absent. Its firmware stream uses ordinary sockets, not TLS. A password hash stored in firmware is still sensitive authentication material. Firmware transfer integrity is not proof of publisher identity. Use a unique strong OTA credential and constrain the service to the intended network/update window; never reuse Wi-Fi or Seestar credentials. These properties are verified in the installed receiver/uploader source, not inferred from HTTPS OTA examples.

There is no project implementation of signed OTA manifests, Secure Boot provisioning, encrypted firmware transport, or OTA credential rotation. The selected SDK header does not establish enabled Secure Boot/flash encryption, and the actual eFuse security state was not read. Do not promise either mechanism based on ESP32 capabilities alone.

Current `/api/session` and `X-Cover-Token` provide the web application's boot/session gating. A local client can obtain the session endpoint; this is not a substitute for a dedicated OTA secret. A proposed prepare/arm endpoint needs deliberate authorization, not merely a public session token. If the threat model requires confidentiality or a hostile/shared LAN, authenticated encrypted transport or a secure network tunnel is a separate design requirement; stock espota does not supply it.

### Credential handling recommendation

- Add a specifically ignored OTA provisioning header/file only during implementation, with a checked-in placeholder example. Alternatively provision a dedicated NVS namespace deliberately. Neither method should rewrite servo EEPROM.
- Do not put a secret or its functional verifier into tracked INI flags, issue text, this document, screenshots, diagnostic JSON or upload logs.
- Read the developer-side secret via a secure prompt, keychain or non-echoing environment setup inside the reviewed wrapper. Redact failures before returning output to the IDE/agent.
- Existing ignored firmware binaries/backups may contain compiled Wi-Fi fallback credentials from `include/wifi_local.h`; treat firmware artifacts as sensitive. Current `.gitignore` does not yet name an OTA credential file because none exists.
- Test secret redaction with an artificial canary, including verbose mode, errors and process arguments. Credential rotation requires a version-compatible plan and USB fallback.

### Image validation

The installed Update library selects the next OTA application partition, checks size, computes the supplied MD5 and enables/selects the candidate after completion. IDF's `esp_ota_set_boot_partition()` performs image validation; it does not know this project's mechanical configuration, expected product, web-control environment or settings-schema compatibility. [IDF 4.4.7 activation implementation](https://github.com/espressif/esp-idf/blob/v4.4.7/components/app_update/esp_ota_ops.c).

**Recommendation:** use only `.pio/build/<production-env>/firmware.bin`, never an ELF, merged full-flash image, bootloader, partition table or filesystem image. Preflight should verify exact size, chip/product/environment, expected build identity and settings/handoff schema versions. A SHA-256 manifest makes artifact identification stronger than a filename; authenticated signatures are needed if publisher authenticity against a hostile sender is required. After reboot, compare `/api/status`'s ELF SHA with the manifest's embedded ELF SHA, not with the entire `.bin` SHA—they are different hashes.

### Preserving settings and rollback compatibility

[settings.cpp](../src/settings.cpp) stores application settings under `cover-app`, calibration under `cover-cal`, and beta acceptance under `cover-beta`. The current application record is version 5; the loader accepts several older layouts. Calibration accepts legacy and current records with checksum/validation.

Application-only OTA to an inactive app slot should leave the separate NVS partition intact. This is not permission to erase NVS, change its offsets, run reset endpoints, or perform destructive schema migration on first boot. Old firmware selected by rollback may not understand a newly written schema. Keep migrations backward-compatible or defer irreversible writes until the image has passed acceptance, with a tested fallback strategy.

## 6. Recovery: interrupted upload versus bad new firmware

### Verified framework configuration — rollback support is present

The selected installed SDK header `tools/sdk/esp32/dio_qspi/include/sdkconfig.h` defines `CONFIG_BOOTLOADER_APP_ROLLBACK_ENABLE=1` and aliases `CONFIG_APP_ROLLBACK_ENABLE` to it. Existing ELF symbols include `verifyOta`, `verifyRollbackLater` and the IDF mark-valid/mark-invalid functions. The installed bootloader ELF also contains OTA-selection logic. The actual deployed bootloader/otadata were not read back, so that hardware state remains unverified.

There is a second important local-source fact: Arduino's `initArduino()` calls a weak `verifyRollbackLater()` that defaults to false. For a pending image it then calls weak `verifyOta()`, defaulting to true, and marks the image valid. The project overrides neither. That happens before the project's `setup()` starts its motion/network checks. [Espressif core startup source corresponding to the package revision](https://github.com/espressif/arduino-esp32/blob/dcc1105b/cores/esp32/esp32-hal-misc.c).

Therefore it would be wrong to report that rollback is disabled in this framework. It would also be wrong to claim the project already rolls back an image whose web server, settings or motion worker fails after Arduino initialization.

### Distinct recovery cases

| Recovery feature | Current status |
| --- | --- |
| USB/esptool recovery | Implemented and historically used; needs controlled physical support and the correct production environment. |
| Setup AP for lost Wi-Fi | Implemented for network recovery; does not provide an OTA receiver or fix a firmware boot crash. |
| Inactive-slot interrupted application upload | Storage/framework support exists; no project receiver has exercised it yet. |
| Framework pending-image rollback | Configuration/core machinery is present; default core behavior accepts early. Actual bootstrap/deployed bootloader behavior needs a hardware test. |
| Project health-based post-OTA rollback | Not implemented: no deferred acceptance, health timeout, custom validation hook or controlled failure/rollback path. |
| Immutable factory recovery image | Not present in the decoded partition table. |
| Automatic rollback on every later bug | Not provided. An accepted image remains accepted; a reboot must actually occur for boot-time fallback to run. |
| `Update.canRollBack()` / `Update.rollBack()` | Library functions exist, but the project does not call them. Their existence is not a health policy. |

For IDF rollback, a new pending image must pass diagnostics and be marked valid; marking invalid/rebooting or an intervening reset can select the prior image when the bootloader supports that policy. Do not assume a running hang automatically triggers a reset; watchdog configuration and health deadlines need verification. [Matching IDF 4.4.7 rollback documentation](https://docs.espressif.com/projects/esp-idf/en/v4.4.7/esp32/api-reference/system/ota.html#app-rollback).

**Recommendation:** before offering recovery guarantees, defer the early Arduino acceptance using the supported weak-hook mechanism and add a bounded project health check. Check task/service creation, settings readability, memory and update endpoint availability; servo validation should reconcile a real hardware fault without causing an endless firmware rollback loop. Wi-Fi/AP recovery policy needs to tolerate an unavailable home AP. Accept only after the chosen checks pass. No checks may move the servo. The health contract and torque handoff must be implemented in the bootstrap image as well as later OTA images and tested across rollback.

### USB recovery procedure to document and test later

1. Physically support the cover and establish the intended torque/power state; a USB flash can reset the ESP32 and does not implement the manual page's controlled hold handoff.
2. Connect USB, confirm the actual port, close competing serial monitors, and select the future `web_control_usb` environment. Until it exists, the present production environment is `web_control`.
3. Use a known-good production artifact/toolchain and the expected partition table. The inspected Arduino builder supplies a bootloader at `0x1000`, the partition table at `0x8000`, and `boot_app0.bin` at `0xE000`, in addition to the application. Thus a normal USB recovery can reset OTA selection metadata; it is not equivalent to an application-only wireless transfer. These configured regions do not overlap the current NVS partition. Avoid full-chip erase; it would remove NVS/settings. Review affected regions before execution. [Official esptool write/erase behavior](https://docs.espressif.com/projects/esptool/en/latest/esp32/esptool/basic-commands.html).
4. Confirm image identity, partition selection, reset reason, NVS/calibration, manual authorization cleared, servo configuration and stationary state. Do not automatically resume an interrupted movement.
5. If a new layout or full erase is ever necessary, make an explicit settings/credential backup and restoration plan first. That is outside the initial OTA proposal.

## 7. Recommended implementation footprint

These are proposed changes, not changes made by this investigation.

| File/function | Proposed work |
| --- | --- |
| `platformio.ini` | Shared receiver-capable production build plus explicit USB/OTA environments; retain the UI embedding hook and current partition layout. Pin table/package inputs when appropriate. |
| New `src/ota_service.h/.cpp` | Receiver ownership, OTA task, transaction state/deadlines, callbacks, application-only restriction, secret configuration, cancellation, success/abort cleanup and progress publication. |
| `src/main.cpp:setup()/loop()` | Initialize/service OTA through the selected task model; no blocking transfer inside the normal HTTP loop. |
| `src/web_control.h/.cpp:worker(), supervise(), submitWebCommand()` and maintenance functions | An exclusive OTA owner/lease, atomic admission, queue draining, all-path command rejection, torque preparation, worker cancellation and fresh clearance. Do not widen the existing 500 ms lease. |
| `src/cover_controller.h/.cpp:prepareReboot(), initializeStationary()` | Share validated stationary preparation where useful; distinguish deliberate update hold from ordinary browser supervision; no direct servo writes in OTA/web handlers. |
| `src/network_setup.cpp:pollNetworkSetup(), reboot route, finish()` | Exclude concurrent scans, reconnects, settings/reset/reboot operations; coordinate mDNS lifecycle and controlled restart; do not route OTA through a state machine that restarts before transfer completion. |
| `src/settings.h/.cpp` or new handoff module | Versioned durable update/torque handoff and backward-compatible schema handling. Keep calibration/application settings separate from OTA transaction data. |
| `src/alpaca_transport.cpp:alpacaWorker()` | Cooperative pause/acknowledgment at a request boundary, mark safety evidence unavailable, resume fresh polling after cleanup. |
| `src/web_server.cpp` | Dedicated authenticated prepare/status/cancel endpoints, update state in status, prevent setup-AP OTA exposure and defensively reject actuator/maintenance requests. No firmware upload page is required. |
| `data/ui/transport.js`, `app.js`, `manual.js`, `index.html` | Display maintenance/restart state, lock actions, and avoid stale heartbeat/error handlers releasing an intentional OTA hold. Existing browser communication logs should distinguish update downtime. |
| `src/diagnostics.*`, `debug_buffer.h` | Bounded OTA phase logging; runtime heap/largest-block/stack evidence. Revisit storage only if measurements require an explicit design change. |
| New project startup-health module | Override/defer early acceptance; validate the new image without servo movement; deliberate acceptance or rollback with bounded deadlines. |
| New `tools/configure_ota_upload.py` / `tools/ota_push.py` | Secret-safe PlatformIO upload integration, image preflight, authenticated clearance, fixed host listener, transfer, cleanup and post-boot identity verification. |
| `.gitignore`, example provisioning file | Exclude OTA credentials and sensitive local transaction artifacts while checking in placeholder-only instructions. |
| `tests/host`, `tests/web`, docs | State-machine/race/failure tests, UI maintenance tests, deployment and USB recovery instructions, physical test records. |

A separate OTA task and a small host wrapper are the recommended starting point. This keeps Arduino/PlatformIO and uses the installed espota protocol. Migrating to ESP-IDF or adding a cloud updater is not required for this workflow. If the installed library's blocking/cancellation behavior cannot meet tested requirements, evaluate a project-owned receiver adapter before committing to a larger framework migration.

## 8. Staging, validation and acceptance

### Suggested stages and effort

| Stage | Deliverable | Rough engineering effort |
| --- | --- | --- |
| 1. Prerequisites | Runtime memory baseline, security/torque decisions, confirmed boot/table state, safe uploader plan | 0.5–1 day |
| 2. Bench receiver | Authenticated application-only push, explicit supported/torque-OFF maintenance, USB bootstrap, basic success/failure tests | 1–2 days |
| 3. Controller integration | Atomic exclusion, separate OTA scheduling, browser/Alpaca coordination, cleanup, identity reporting | 1–2 days |
| 4. Retained torque and rollback | Cross-image handoff, deferred acceptance, rollback compatibility and failure-injection tests | 1–2+ days |
| 5. Deployment validation | Repeated transfers, interruption/power tests, loaded mechanism verification and recovery documentation | Several bench sessions / 1–2+ days |

A simple demonstration could be done quickly; the requested controller-specific reliable workflow is more realistically **3–5 development days plus hardware validation**, potentially longer if memory pressure, bootloader behavior or cross-image torque retention exposes problems. These estimates assume the existing toolchain stays pinned and USB access is available.

### Automated validation to add

- Update lease races against Open/Close, calibration/manual jogs, supervised hold, Stop, settings maintenance and expired/duplicate requests. No request reaches servo movement after update admission.
- Torque policy transitions: reject active motion, no unintended release during retained hold takeover, release/readback for OFF, fault on failed preparation, Stop cancellation.
- Handoff parsing: invalid checksum/version, stale transaction, wrong target identity, normal reset, power loss, new firmware and rollback firmware. Never trust a stored position as physical closure.
- Callback/error cleanup: allocation failure, wrong command, auth timeout, TCP connect failure, truncated image, bad checksum, oversized/wrong build, stalled transfer and repeated retry. No concurrent access to `Update`.
- Fake-clock deadlines and no motion resumption after cancellation/reboot; fresh stow required for later normal closing.
- Host wrapper: canary credential absent from generated command, stdout/stderr, verbose mode, artifacts and process arguments; correct binary/hash/environment/size checks.
- Browser: update lock, expected downtime, no automatic Stop following a valid hold handoff, new boot identity, no retained manual authorization, errors still visible.
- Static/build checks: actual receiver-enabled binary fits both slots with documented headroom; USB/OTA environments embed the same production capabilities and do not change NVS offsets.

### Hardware tests and acceptance criteria

1. **Baseline:** confirm actual flash/table/boot metadata and receiver identity after the first approved USB bootstrap; record reset cause and internal memory/largest block/stack headroom with 1,000 logs, Alpaca and browser traffic.
2. **Two-way slot use:** push A→B→A with recognizable non-motion build identities and verify which slot runs, not just uploader success. Embedded UI updates with the app.
3. **Admission:** attempt update and manual/calibration motion concurrently. Update is rejected during motion; movement is rejected throughout an admitted update, including when the browser is absent or stale. No heartbeat threshold is relaxed.
4. **Torque:** test both policies, initially unloaded/supported. Instrument actual bus writes/torque/position during transfer, software reboot and rollback; then validate the real supported mechanism. There must be no unintended torque-OFF interval in a retained-torque software update and no unexpected commanded move. Servo power loss cannot meet that holding guarantee.
5. **Failures:** wrong password, wrong image/environment/chip, oversized/corrupt/truncated image, sender termination, lost Wi-Fi, unavailable host TCP port, timeout and repeated retries all leave a recoverable controller with the documented torque/inspection outcome. No heap decline or watchdog reset under accepted normal tests.
6. **Power interruption:** interrupt application download, metadata/activation window and first-boot checks at controlled points. Record the actual booted image and settings. Use a supported mechanism; these tests do not promise mechanical retention without power.
7. **Bad boot:** intentionally fail a non-moving startup health check and reset before acceptance. Confirm the prior healthy application is selected and its settings/handoff remain readable. A normal accepted boot must not roll back later just because the home AP is temporarily unavailable.
8. **Concurrency:** measure HTTP Stop/cancel latency, diagnostic task gaps, largest free block and total heap during erase/write. Establish measured acceptance bounds; do not claim motion-grade responsiveness during flashing. Alpaca is explicitly paused/stale and recovers with fresh samples.
9. **Recovery:** demonstrate USB restoration without NVS erasure, followed by correct endpoints, limits, application settings and no automatic movement.
10. **Operator success:** a VS Code/PlatformIO upload from the Mac, using only the intended LAN path and secret-safe credential source, completes without a web upload page and confirms the expected running ELF identity and startup result.

## 9. Decisions and unresolved blockers

| Question / blocker | Recommended disposition |
| --- | --- |
| Is the large log compatible with OTA peak memory? | Measure this firmware on hardware first; current local artifacts cannot establish runtime reserve. |
| What torque policy is authorized for OTA? | Make it explicit in host preflight. Preserve requested holding only after the stable cross-image handoff is implemented and tested. Use supported/OFF bench tests initially. |
| Is MD5-based authentication on a trusted LAN sufficient? | User/security decision. Stock espota provides no transport encryption or signed publisher identity. |
| How should the OTA credential be provisioned/rotated? | Choose ignored local provisioning or a dedicated NVS flow, with a secret-safe host wrapper; do not rely on current uploader defaults. |
| Which health failures require rollback? | Define a bounded startup contract that includes service/task/memory health without confusing a real servo/network fault with a bad firmware image. |
| Does the deployed bootloader match local rollback-capable inputs? | Verify during an approved bootstrap/recovery exercise. No readback or hardware test was performed here. |
| Are both update directions settings/handoff compatible? | Require schema compatibility in both bootstrap and future builds; defer destructive migration. |
| Can the Mac accept the reverse TCP connection? | Test the selected interface, fixed host port, local firewall and actual AP/VLAN arrangement. |
| How responsive is Stop during flash operations? | Measure under supported conditions and state the actual limit; do not reuse the ordinary 500 ms supervision claim as an OTA guarantee. |

These are implementation prerequisites and hardware-validation questions, not reasons to repartition or migrate frameworks immediately.

## 10. Reproduction and source notes

Read-only work performed for this investigation:

- Read `AGENTS.md`, `platformio.ini`, relevant current source, installed board/package/version files and existing safety/debugging documentation.
- Decoded the local binary partition table using Python `struct`; measured existing binary length/SHA-256 and parsed its embedded application description.
- Used the installed Xtensa `size -A` and `nm` on existing ELF files to inspect static memory and rollback symbols.
- Inspected installed ArduinoOTA, Update, espota, core startup and PlatformIO build/upload implementation. Read selected fields from an older saved status JSON as explicitly historical evidence.
- Consulted official PlatformIO/Espressif documentation and version-specific upstream source. No device was contacted and no build was run.

Existing source/artifact measurements can be repeated without connecting to hardware. Do not run `pio ... -t upload`, esptool flash/read commands that reset the target, a serial monitor, or a reboot endpoint as part of a documentation-only follow-up.

### Official references consulted

- [PlatformIO Espressif32: partitions and OTA](https://docs.platformio.org/en/latest/platforms/espressif32.html).
- [PlatformIO environment interpolation](https://docs.platformio.org/en/latest/projectconf/interpolation.html).
- [PlatformIO v7.1.3 upload implementation](https://github.com/platformio/platform-espressif32/blob/v7.1.3/builder/main.py).
- [ArduinoOTA 2.0.17 API](https://github.com/espressif/arduino-esp32/blob/2.0.17/libraries/ArduinoOTA/src/ArduinoOTA.h).
- [ArduinoOTA 2.0.17 receiver](https://github.com/espressif/arduino-esp32/blob/2.0.17/libraries/ArduinoOTA/src/ArduinoOTA.cpp).
- [ArduinoOTA BasicOTA example](https://github.com/espressif/arduino-esp32/blob/2.0.17/libraries/ArduinoOTA/examples/BasicOTA/BasicOTA.ino).
- [Espressif espota uploader](https://github.com/espressif/arduino-esp32/blob/2.0.17/tools/espota.py).
- [Arduino Update implementation](https://github.com/espressif/arduino-esp32/blob/2.0.17/libraries/Update/src/Updater.cpp).
- [Arduino core startup at package revision dcc1105b](https://github.com/espressif/arduino-esp32/blob/dcc1105b/cores/esp32/esp32-hal-misc.c).
- [ESP-IDF 4.4.7 OTA/rollback guide](https://docs.espressif.com/projects/esp-idf/en/v4.4.7/esp32/api-reference/system/ota.html).
- [Current stable ESP-IDF OTA overview](https://docs.espressif.com/projects/esp-idf/en/stable/esp32/api-reference/system/ota.html). Stable resolved to v6.1 during this investigation; those newer APIs/configuration are not assumed present in the installed 4.4.7 framework.
- [ESP-IDF 4.4.7 activation implementation](https://github.com/espressif/esp-idf/blob/v4.4.7/components/app_update/esp_ota_ops.c).
- [ESP-IDF 4.4.7 flash concurrency](https://docs.espressif.com/projects/esp-idf/en/v4.4.7/esp32/api-reference/storage/spi_flash.html).
- [Current esptool write/erase documentation](https://docs.espressif.com/projects/esptool/en/latest/esp32/esptool/basic-commands.html). The installed uploader is esptool 4.11.0; newer documentation's hyphenated CLI examples should not be copied into old tooling without checking its help.

### Installed package evidence locations

Paths below are local inspection references, not dependencies added to the repository:

```text
~/.platformio/penv/lib/python3.11/site-packages/platformio/__init__.py
~/.platformio/platforms/espressif32/platform.json
~/.platformio/platforms/espressif32/boards/esp32dev.json
~/.platformio/platforms/espressif32/builder/main.py
~/.platformio/packages/framework-arduinoespressif32/package.json
~/.platformio/packages/framework-arduinoespressif32/cores/esp32/esp_arduino_version.h
~/.platformio/packages/framework-arduinoespressif32/cores/esp32/esp32-hal-misc.c
~/.platformio/packages/framework-arduinoespressif32/tools/platformio-build.py
~/.platformio/packages/framework-arduinoespressif32/tools/partitions/default.csv
~/.platformio/packages/framework-arduinoespressif32/tools/sdk/esp32/dio_qspi/include/sdkconfig.h
~/.platformio/packages/framework-arduinoespressif32/tools/sdk/esp32/include/esp_common/include/esp_idf_version.h
~/.platformio/packages/framework-arduinoespressif32/tools/sdk/esp32/bin/bootloader_dio_40m.elf
~/.platformio/packages/framework-arduinoespressif32/libraries/ArduinoOTA/src/ArduinoOTA.{h,cpp}
~/.platformio/packages/framework-arduinoespressif32/libraries/Update/src/Updater.cpp
~/.platformio/packages/framework-arduinoespressif32/tools/espota.py
```

## 11. Final assessment

The existing 4 MB/two-slot layout can support push-based OTA, with roughly 306 KiB of application-slot headroom in the measured artifact. Keep Arduino/PlatformIO, install a receiver-capable production image once over USB, and use a secret-safe espota wrapper with worker-controlled maintenance admission and explicit post-boot verification.

Before production use, resolve runtime memory headroom, credential leakage in uploader defaults, cross-image torque handoff, and deferred health-based acceptance/rollback. OTA has not been implemented or hardware-tested by this investigation.
