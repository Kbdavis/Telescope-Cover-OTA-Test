# Local UI preview

Preview the current embedded interface against the local simulated API:

```sh
python3 tools/debug_server.py --port 8083
```

Open **http://127.0.0.1:8083/**. The banner identifies the local simulation;
no controller or telescope hardware is contacted. Stop the server with Ctrl-C.
The fixture uses in-memory device state, not a mechanical model or firmware
safety validation. See [WEB.md](WEB.md) for real controller behavior.

The production assets live in `data/ui/`. `tools/embed_ui.py` packages those
same assets for firmware and the local fixture. Browser regression tests use
`tests/web/live_ui_server.py`; tests describe their fixture and isolated browser
requirements in their headers.

The original standalone pages, static studio/calibration mockups, and their
preview servers were retired during release cleanup on 2026-11-12. Their design
history remains in Git. Current calibration and configuration behavior is
recorded in [CALIBRATION_UX.md](CALIBRATION_UX.md) and
[CONFIGURATION_UX_PLAN.md](CONFIGURATION_UX_PLAN.md).
