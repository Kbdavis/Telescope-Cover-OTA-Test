# Alpaca module design and initial implementation

> Current direction (2026-10-26): telescope motion belongs to the Seestar app.
> Monitoring automatically restores logical Alpaca sessions after a confirmed
> disconnected response. Its only write is `Connected=true`; arm/stow/emergency
> commands and native authenticated sessions remain disabled. Historical control
> workflows and the earlier blanket GET-only policy below are superseded by the
> session-recovery section at the end, which records validation/deployment status.


## Scope and boundary

Monitoring is disabled by default, with read-only monitoring selected. Unchecking
read-only allows the polling worker to establish a logical Alpaca connection
when a successful Connected GET returns false. A separate,
explicitly confirmed **stow-only test** can now send one FindHome PUT for the
commissioned Seestar S30 Pro. Automatic connection cannot change tracking,
operate cameras/heaters, stow the telescope, or command the cover. Configuration is loaded
at boot; saving configuration still uses the maintenance interlock and restart.
See the latest hardware verification section for deployment status.

The separate UI mockup remains simulated; the live main dashboard reads this
module's verified status. Supervised Close is allowed when the commissioned
telescope is already confirmed stowed. It does not automatically stow a raised
arm. See the guarded Close behavior below; optional telemetry cannot grant clearance.

The separate **Emergency shutdown** action now coordinates native capture/plan
stop, repeated idle verification, native arm parking, repeated native + Alpaca
stow verification, and guarded cover closure. Normal Close keeps its existing
already-stowed behavior. See Emergency shutdown below for the new sequence and
its verification limits.

## Components

- `alpaca_client`: platform-independent, transport-injected polling state machine.
  Calls at most one request per step; publishes complete, timestamped snapshots.
- `alpaca_transport`: ESP32 worker and bounded HTTP/JSON adapter. Runs at priority
  1 on core 0, separate from web serving and servo supervision. Publishes copies
  under a short critical section; never holds that section during network I/O.
- `StowTest`: supervised telescope-only state machine in `alpaca_client`, with
  fresh preflight, one command attempt, repeated completion and bounded timeout.
- Web adapter: queues the test after cover-worker maintenance acknowledgment;
  telescope HTTP remains in the Alpaca worker. Holds the cover interlock until
  the operator explicitly finishes the test. No automatic cover sequence exists.

The current transport supports literal IPv4 and configured port/device number.
Hostnames are rejected instead of using potentially blocking DNS resolution.
Discovery is a commissioning operation, not a prerequisite for each poll. There
is no proprietary Seestar fallback and no generic command passthrough.

## Monitoring protocol and resource limits

GET allowlist: Connected, CanFindHome, AtHome, Slewing, Tracking. Requests use
ClientID 731 and distinct nonzero ClientTransactionIDs. HTTP must be 200. Bodies are limited to 2048 bytes and headers to 1024 bytes.
A single Content-Length is accepted; absent length is accepted only for HTTP/1.0
or an explicit `Connection: close`, and the socket must close before the deadline.
This initial adapter rejects chunked encoding and redirects. HTTP/1.0 requests
cause the tested Seestar server to use connection-close framing.
Connection attempts have a 300 ms timeout; nonblocking sends and response reads
share a 1200 ms elapsed deadline. The worker yields while waiting. Deadline
accuracy is subject to RTOS scheduling; it never executes in the motion task.

With read-only monitoring off, the worker may PUT `Connected=true` to telescope
device `connected`. A valid GET with `Connected=false` is required first; failed
GETs never trigger writes. Each connection attempt is followed by fresh GETs,
including after a lost PUT response. Attempts are spaced at least ten seconds
apart; failure polling retains its three-second backoff. PUT success alone does
not grant valid status or stow clearance. Two fresh stowed sweeps remain required.

JSON parsing uses the bundled cJSON implementation, caps nesting at 16, rejects
duplicate fields, and verifies transaction echo, integer server transaction,
ErrorNumber and string ErrorMessage. Boolean values must actually be JSON
booleans. Error 1024 is unsupported; other driver failures retain their error
number. HTTP success with an Alpaca error is never success. Returned error values
such as temperature=0 must not be presented as readings.

There are no automatic retries inside one request. A failed sweep invalidates
its snapshot and backs off 3 seconds. A successful sweep waits 1 second before
starting again; properties within a sweep are spaced by at least 100 ms after
each completed request. Requests are sequential, never concurrent per device.

## Freshness and provisional stow observation

Each sweep brackets capability/home/slewing/tracking with Connected reads. A
false Connected invalidates the sweep even if the server returns other values.
Maximum sweep duration is 2500 ms. Freshness expires 5000 ms from the start of
the sweep (the oldest observation), not its publication time. Time arithmetic
handles millis wraparound. Partial sweeps cannot create a valid snapshot.

Two consecutive complete fresh sweeps must report Connected, CanFindHome and
AtHome true, Slewing and Tracking false, before `stowedCandidate()` is true.
Any contradictory observation or error immediately revokes earlier clearance.
That helper is one prerequisite for supervised Close, not a complete permission:
properties are not atomic, no mechanical sensor exists, other clients may move
the telescope, and camera activity does not verify Seestar stacking. Presence,
path clearance, calibration and cover readiness are still required. Polling
continues throughout closing. Disabled is distinct from offline; there is no
silent automatic-to-manual fallback.

## Future coordinated close (not implemented)

1. Reject if cover position/calibration or local safety checks fail.
2. If integration is disabled, require explicit manual stow/path-clear confirmation.
3. If configured, require a reachable, logically connected, identified telescope
   and fresh capabilities. Unknown activity/state blocks automatic closing.
4. If imaging/tracking, surface the activity and require an explicit stop policy;
   never silently abort an imaging run merely because Close was pressed.
5. Issue one FindHome request under an operation ID. Record its response separately
   from physical completion. A request timeout means outcome unknown: do not
   retry blindly or close. Continue observation with a bounded stow deadline.
6. Wait for repeated fresh AtHome AND not Slewing AND not Tracking plus verified
   imaging clearance. Do not substitute AtPark or a fixed timer.
7. Ask the cover controller to close. A cancel/network failure/changed telescope
   state must never automatically resume an interrupted close. Determine the
   cover stop/hold policy with the existing load/torque behavior before enabling.

FindHome is specific to this tested Seestar profile. Generic Alpaca home position
is not necessarily mechanical stow. A replacement device needs commissioning.
Future discovery should bind device identity, not merely reuse an IP address.
A telescope Stop and the existing cover Stop/release are separate actions.

## Live read-only observations, 2026-10-04

Native server: `192.168.1.131:32323`, API v1, telescope device 0, driver `1.3.1-1`.
Management lists two cameras/focusers, one telescope, filter wheel and switch.
GET-only probing found:

| Property | Observed response | Meaning |
|---|---|---|
| Telescope Connected | false | Not an established logical Alpaca session |
| AtHome / Slewing / Tracking | true / false / false | Returned despite Connected=false; not trusted clearance |
| CanFindHome | true | Capability advertised |
| AtPark | false | Must not replace the tested home/stow predicate |
| Altitude / Azimuth | −89.8 / 0 degrees | Returned values; session disconnected |
| Camera Connected | false | Camera telemetry not yet usable |
| CameraState / CCDTemperature | error 1031 | Not connected; returned zero is invalid |
| PercentCompleted | error 1024 | Not implemented |
| Switch Connected / MaxSwitch | false / error 1031 | Switch enumeration requires logical connection |
| Switch SupportedActions | OCHTestPowerReport | Name observed only; not invoked or assumed to be battery telemetry |

Battery and heater mapping remain unverified. Do not assume switch 0 means
heater: enumerate names, descriptions, ranges and write capabilities after
connection. Camera CCDTemperature is not ambient temperature. CameraState does
not necessarily describe proprietary Seestar stacking activity; verify before
using it as a safety interlock. No proprietary action, PUT, or movement command
was sent. Raw metric responses are in ignored diagnostics/alpaca-readonly-20261004.json.

## Validation and next steps

Host tests exercise disabled polling, repeated confirmations, stale observations,
contradiction revocation, disconnection, failure backoff, slow responses, and
clock wraparound. The ESP32 web_control firmware compiles with the module.
The live read-only probe established protocol behavior; it did not exercise the
new ESP32 transport on hardware. The module has not been uploaded.

Next: exercise the HTTP adapter against malformed/slow/failing fixture servers,
then continue with opt-in ESP32 configuration and diagnostics. The logical
connection and capability enumeration results are recorded below. Add optional metric types with explicit
unsupported/invalid/stale states. After that, integrate opt-in configuration and
read-only status reporting, then implement/test FindHome coordination separately.

References: [ASCOM telescope semantics](https://ascom-standards.org/alpyca/alpaca.telescope.html)
and [Alpaca API reference](https://ascom-standards.org/AlpacaDeveloper/ASCOMAlpacaAPIReference.html).

## Transport validation and connected-device probe, 2026-10-04

The user authorized the logical connection and read-only capability test. The
probe used only `Connected=true` PUTs for telescope 0, cameras 0/1, and switch 0;
all subsequent operations were GETs. These logical sessions were left connected.
No FindHome, park, slew, tracking change, camera exposure, heater write or
proprietary Action was issued.

| Item | Verified response | UI implication |
|---|---|---|
| Telescope Connected | true | Logical connection established |
| Home / Slewing / Tracking | true / false / false | Valid repeated stow observations, not authorization to close |
| Altitude / Azimuth | −89.8° / 0° | Reported pointing while stowed |
| Telephoto CameraState | 0 (Idle) | Camera state exposed; native Seestar stacking semantics still untested |
| Telephoto CCDTemperature | 25.375 °C | Use a specifically labeled telephoto-camera reading |
| Wide CCDTemperature | 0 °C, no error | Returned value only; practical accuracy/meaning unverified |
| PercentCompleted | 1024 NotImplemented | Hide percentage or show unsupported |
| HeatSinkTemperature | 1024 NotImplemented | Not available |
| Switch count | 1 | Enumerated ID 0 |
| Switch ID 0 name / description | Dew heater / Dew heater | Driver identifies heater channel |
| Switch write capability / range / step | true / 0–1 / 1 | Advertises binary control; no write tested |
| Heater value / state | 0 / false | Reported off; not physically verified |
| Switch device name | Alpaca Switch Simulator | Inconsistent generic name; do not claim physical heater validation |
| Battery | No verified standard mapping | Remains unavailable; OCHTestPowerReport was not invoked |

Raw observations: `diagnostics/alpaca-20261004T201758Z/responses.json` (ignored).
Reusable probe: `python3 tools/alpaca_capabilities.py --connect`. Omitting
`--connect` prohibits all writes, including connection changes. The probe limits
switch enumeration to 16 IDs and response bodies to 64 KiB.

The host transport harness compiles the actual `alpaca_transport.cpp` against a
small POSIX WiFiClient/RTOS shim and cJSON 1.7.17 matching the SDK's parser version.
Loopback fixtures cover boolean values, transaction mismatch, driver errors,
HTTP errors/redirects, missing/duplicate/oversized lengths, chunked rejection,
truncated bodies, malformed JSON, duplicate fields, nesting limit, embedded NUL,
no-progress and slow-trickle deadlines, disconnection and connection-close framing.
This verifies production HTTP/parser logic but does not emulate ESP32 radio or
FreeRTOS scheduling.

The first production-client live test failed: the scope's HTTP/1.0 reply used
`Connection: close` without Content-Length. After adding bounded EOF-delimited
body support and regression cases, the same C++ client completed two valid live
GET-only sweeps: connected=true, home=true, slewing=false, tracking=false,
consecutiveStowed=2. This directly exercised the real parser/poller against the
scope via the host adapter. No firmware was uploaded; ESP32 execution remains
an explicit next validation step.

Run the tests from the repository root:

```sh
cc -c tests/vendor/cjson/cJSON.c -o /tmp/cover-cjson.o
c++ -std=c++17 -Wall -Wextra -Werror -pthread -I tests/host/alpaca_shim -I tests/host -I tests/vendor/cjson -I src tests/host/alpaca_transport_test.cpp src/alpaca_client.cpp src/alpaca_telemetry.cpp /tmp/cover-cjson.o -o /tmp/cover-alpaca-transport-test
/tmp/cover-alpaca-transport-test
# Optional: explicitly target the real scope at 192.168.1.131:32323, GET only.
/tmp/cover-alpaca-transport-test --live-read-only
```

## ESP32 monitoring settings

Configuration → Alpaca monitoring saves `alpacaEnabled`, `alpacaReadOnly`, IPv4 address, port and
Telescope device number. Saving requires the existing stationary/torque-off
maintenance acknowledgment (or explicit disconnected-servo testing), preserves
Wi-Fi and calibration, and restarts after two seconds. Default remains disabled.
Read-only monitoring sends GETs and requires an already established logical
session. Uncheck **Read-only monitoring**, leave **Enable Alpaca monitoring**
checked, then save to allow automatic logical connection. The explicit stow test
remains a separate opt-in FindHome command in either monitoring mode.

Settings record version 3 persists the new mode. Versions 1 and 2 load with
read-only monitoring selected, preserving Wi-Fi, hostname, and other preferences.
Factory reset returns to disabled monitoring with read-only selected. Calibration
and beta acceptance storage are unaffected by the schema change.

`GET /api/alpaca/status` reports enabled/read_only, valid, connected, capability,
home/slewing/tracking, sequence, age, error and driver error. Unknown readings
are JSON null, not false. `stowed_observation` reports repeated verified stow;
`close_authorized` reports readiness for supervised Close as described below.
Optional display metrics have independent timestamps and do not grant clearance.

The polling task runs separately from servo supervision and web handling.
Configuration changes take effect only on restart. Factory reset disables
monitoring; Clear calibration preserves monitoring preferences.

### Hardware verification — read-only polling enabled

Uploaded and hash-verified `web_control`, firmware ID
`4c328bea0dd0fd772ba1011df60ffff3baaa1abb8e0531f54aea140bbff6f164`.
Saved read-only monitoring for `192.168.1.131:32323`, telescope device 0, using
the explicitly confirmed disconnected-servo setup. The settings restart loaded
the enabled configuration. During Wi-Fi startup the endpoint correctly reported
invalid/disconnected with null readings. It then reported valid sweep sequences
1 and 2, Connected/CanFindHome/AtHome true and Slewing/Tracking false. At sequence
2, stowed_observation=true while close_authorized=false.

Cover status remained ready=false, moving=false, holding=false with the servo
disconnected. Calibration remained CLOSED=532, OPEN=1975. USB capture resumed at
`diagnostics/20261004T202954666261Z/`. No scope control, heater, cover movement,
or calibration erase commands were issued. Sustained wireless outage and
long-duration stability tests remain outstanding.

## Supervised stow-only testing

Overview offers **Stow telescope only**. Before each test the operator confirms
this is the commissioned Seestar S30 Pro, the cover is fully open, imaging is
stopped, and the telescope path is clear. Camera/stacking activity is not yet
verified in firmware, so this is supervised commissioning, not unattended
clearance. FindHome may have different physical meaning on other mounts.

The beta acknowledgment is required first. The route requires a boot token,
valid client and fresh connected/capable telescope status, with tracking and
slewing off. Cover-worker maintenance must acknowledge idle/torque-off before
queuing the operation; failed startup with a physically disconnected servo
requires the explicit disconnected-servo checkbox. Pending cover commands are
suppressed by the worker interlock. Setup AP clients cannot start a test.

The worker resets its polling snapshot and obtains new preflight observations.
It sends exactly one form-encoded FindHome PUT. A successful Alpaca response is
command acknowledgment, not physical completion. Completion requires two distinct
fresh sweeps begun after the response, with Connected/CanFindHome/AtHome true and
Slewing/Tracking false. The configured stow timeout defaults to 60 seconds.
Stale/contradictory observations cannot build completion; disconnects, malformed
replies and command timeouts produce failure or an unknown outcome, never an
automatic retry. Polling continues for diagnosis.

All cover commands except Stop are blocked throughout the test. After any result,
including success, the operator must inspect that the telescope has stopped and
use **Finish test / unlock cover controls**. No cover command follows completion.
The firmware does not abort FindHome: Stop/release torque is a cover command,
not a telescope stop. Leaving the page does not stop telescope motion. Use the
Seestar app for telescope recovery. Reboot does not resume or retry a test.

Routes: POST `/api/alpaca/stow` and `/api/alpaca/stow/finish`; GET
`/api/alpaca/status` adds operation, phase, error, pending and locked status.
Originally `read_only=false` denoted explicit test capability. As of 2026-10-17,
`read_only` and `polling_read_only` both reflect the configured monitoring mode;
they do not describe the separately confirmed stow-test capability.
The stow-test lock keeps `close_authorized=false`. Logs record operation
and phase changes. Tests cover one PUT only, response loss, repeated/post-command
observations, early home while slewing, tracking contradiction, timeout and clock
wraparound. The actual HTTP adapter is tested with PUT fixtures, including void
success replies, transaction mismatch, driver errors and delayed responses.

FindHome behavior follows the [ASCOM telescope reference](https://ascom-standards.org/alpyca/alpaca.telescope.html#alpaca.telescope.Telescope.FindHome),
with the project's additional repeated-observation and cover-lock requirements.

### Live stow-only test — 2026-10-04

Uploaded and hash-verified firmware
`857f075b8c2a7ce51e8ac740b8d836453538f69061f2b1f58382c04ec95cbaad`.
The user confirmed a fully open cover, clear telescope path, stopped imaging and
supervision, then accepted the beta notice in the browser. Fresh initial scope
status was connected, not home, not slewing and tracking off. The cover servo
remained physically disconnected, with moving=false and holding=false.

One POST to the controller queued operation 1; its worker issued one FindHome.
The telescope reported slewing, then AtHome=true while Slewing remained true
at approximately 20 seconds. The test correctly remained waiting. First complete
stationary-home feedback was observed around 22.3 seconds, followed by a second
fresh sweep and `complete` around 24.5 seconds. Tracking remained off. No cover
movement command was sent, and cover moving/holding remained false throughout.
`close_authorized` stayed false. The test interlock was left engaged for the
operator to inspect and finish explicitly; no automatic unlock or close followed.

Raw trace: `diagnostics/stow-only-20261004T205549Z.json`.
Serial/firmware capture: `diagnostics/20261004T205417282620Z/`.
This is one successful supervised run, not unattended reliability validation.
Fault, timeout and malformed-response behavior was exercised with host fixtures,
not induced against the live telescope during this test.

## Coordinated Close dry run

The Overview button **Dry run: stow then check Close** uses the same supervised
Seestar confirmation and stow operation, followed by a separate final check.
This version specifically requires the servo to be physically disconnected,
unavailable position/torque feedback, and saved, unchanged calibration. The
operator confirms the cover is physically open; cover-open and readiness feedback
are explicitly simulated, never inferred from missing servo data.

`CloseDryRun` is a separate state machine with no actuator dependency:
`stowing -> rechecking -> ready_to_close`. It binds to the new operation ID and
cannot reuse an earlier stow result. After stow completion, a new sweep begun
after entering Rechecking must still show repeated fresh stowed observations.
The cover worker must remain in maintenance, with no motion/holding, and valid
saved calibration. The end-to-end deadline is 195 seconds (maximum configured
stow deadline plus 15 seconds). Readiness remains monitored and is revoked on
stale/contradictory data or an interlock failure. Cancellation is latched until
an explicitly started new run; no automatic retries or resumption occur.

POST `/api/alpaca/close-dry-run` never submits a cover command. Status adds
`dry_run`, `dry_run_phase`, `dry_run_message` and `cover_checks_simulated`.
Ready means **dry run only**: while the test lock is held, `close_authorized`
remains false and normal Close remains blocked. This is not validation of physical cover readiness or
imaging inactivity. Use the existing inspection and Finish test action to
release the cover lock after reviewing the outcome.

Checkpoint before this change: `ae13ea2`. Unit tests cover binding to a new
operation, fresh final observation, stale data, interlock failures, disconnection,
latched cancellation and clock wraparound. Browser tests verify the explicit
servo-disconnected gate, correct endpoint, and no cover command or Close enable
when dry-run readiness is displayed.

### Live dry run — 2026-10-04

Uploaded and hash-verified firmware
`18705967e3c27efed2947bb743454c140e6440982577f802e9e56854a3f3ff76`.
The prior beta acknowledgment persisted through the upload. Initial valid
feedback showed the telescope not home, stationary and tracking off. One
POST to `/api/alpaca/close-dry-run` initiated stow operation 1 with the previously
confirmed disconnected cover servo; calibration remained loaded and unchanged.

Observed elapsed times: home=true while still slewing at 19.5 seconds;
stationary-home at 21.7 seconds; repeated stow completion and Rechecking by
25.2 seconds; new final sweep and `ready_to_close` at 27.4 seconds. Readiness
remained stable for a further five seconds of observation. Throughout the trace,
cover moving/holding remained false and `close_authorized=false`. No cover
movement command was issued. Cover checks were explicitly simulated and the
maintenance lock was left engaged for operator inspection/Finish test.

Trace: `diagnostics/close-dry-run-20261004T210400Z.json`.
Serial and firmware archive: `diagnostics/20261004T210247410250Z/`.
Physical cover readiness, imaging-state verification and actual coordinated
closing remain unimplemented/unproven by this dry run.

## Optional altitude display telemetry

The worker reads numeric Altitude every other completed valid safety
sweep, alternating with optional display requests. It uses the existing bounded GET transport, accepts only finite JSON
numbers in −90..90 degrees, and keeps a separate timestamp/validity flag. Failure
or unsupported values hide the angle without changing the safety snapshot.
Altitude never participates in stow completion or Close authorization. Reads are
outside the safety sweep; the same worker serializes all requests. The status
endpoint returns altitude and altitude_age_ms only while both telescope and
angle feedback remain fresh (five seconds).

The yellow dashboard side-view arm maps this reported altitude to a side-view
rotation and interpolates visually between readings. It assumes the telescope
is upright, not on an equatorial wedge. Missing angle data uses a labeled
schematic fallback. Neither the graphic nor Altitude proves mechanical clearance.


## Close with an already stowed telescope — 2026-10-17

When monitoring is enabled, both dashboard and calibration endpoint Close
require `stowedCandidate()`. The HTTP handler checks it, the cover worker checks
again before starting, and every supervision tick checks while closing. Lost,
stale or contradictory telescope feedback faults with **Telescope stow confirmation
lost**, releases torque, and never resumes automatically. A queued checked Close
cannot silently become manual Close. The stow-test interlock must be explicitly
finished before any cover move.

`close_authorized` now reports combined telescope/cover readiness (including
calibration, fresh position, beta acceptance and maintenance interlocks). It
does not issue a command or replace the request's presence/path-clear check.
With Alpaca disabled, dashboard Close still requires manual stow confirmation.
No automatic FindHome is sent by Close. Full stow-then-close remains future work.

## Additional telemetry — 2026-10-17

The new `alpaca_telemetry` module reads Azimuth, camera 0 CameraState and
CCDTemperature, and switch 0 / channel 0 state only after MaxSwitch and the exact
name **Dew heater** are verified. These IDs are the commissioned S30 Pro profile.
CameraState is labeled camera activity, not Seestar stacking; CCDTemperature is
telephoto camera temperature, not ambient. Camera/switch Connected GETs precede
their readings. With read-only unchecked, verified false Connected can trigger
Connected=true, then GET verification; attempts are at least ten seconds apart.
There are no exposure, heater-output, tracking or motion writes in this path.

One optional request runs after each completed valid safety sweep. Independent
samples expire after 60 seconds (normal secondary rotation is roughly 30 seconds),
or immediately on a failed read/session check. The API also requires fresh core
status, so a telescope disconnect hides all readings. Altitude retains its
five-second freshness limit. Neither the safety sweep's five-second deadline nor
Close authorization is relaxed. Battery, charging and power source have no
verified mapping; the UI explicitly labels them unavailable.

Live checks at 192.168.1.131:32323 returned stowed/stationary, azimuth 0 degrees,
telephoto CameraState 0 (Idle), CCDTemperature 25.5 degrees C, and Dew heater Off.
Only logical camera/switch connections were established; no telescope/cover
motion, exposure or heater command was sent. The firmware changes compile and
host/browser tests pass; they have not yet been uploaded.

## Native power telemetry and steady Overview — 2026-10-17

A read-only native TCP 4700 probe of the S30 Pro (firmware 9.75) returned
three consistent samples: battery 44%, Discharging, external power false,
battery temperature 23 °C, battery overtemperature false. These readings are
from `get_device_state` → `pi_status`, not the native Alpaca switch action.
The firmware now polls this display-only source in a separate task, every
30 seconds after each attempt, with a six-second exchange deadline. It uses
the configured Alpaca host and requests only `device` and `pi_status`.

| Native field | `/api/alpaca/status` field | Display |
| --- | --- | --- |
| `battery_capacity` | `battery_percent` | Battery remaining (%) |
| `charge_online` | `external_power` | External power connected (Yes/No) |
| `charger_status` | `charging_state` | Reported charging state |
| `battery_temp` | `battery_temperature` | Battery temperature (°C) |
| `battery_overtemp` | `battery_overtemp` | Battery overtemperature (Yes/No) |

Absent, incorrectly typed, out-of-range or unrecognized values are null.
External power does not identify a wall supply versus a power bank and does
not imply active charging. The parser checks response ID, success code and
S30 Pro model identity. Frames, total receive traffic and JSON depth are bounded;
duplicate JSON fields are rejected. Last successful power samples survive brief
transport failures only until their original 60-second freshness deadline.
Power readings never grant movement permission.

Native authentication uses the local Seestar application's credential via
ignored `include/seestar_local.h`, declaring `static const char seestarPrivateKey[]`
as its PEM string. This machine's header is generated from the installed app;
it is not tracked. Firmware/ELF artifacts contain that credential and must stay
private, just like builds with local Wi-Fi credentials. Without the header,
native power telemetry is unavailable and the rest of the controller builds
normally. Authentication responses and credentials are never logged or served.
Current native firmware reports authentication success as `code=0` with a
result object; comparing the whole `result` to numeric zero is incorrect.

Overview no longer includes the completed stow-only/dry-run test card.
Its test routes and backend interlock remain intact. Removing the card does
not enable automatic stow-and-close; use the Seestar app to stow a raised arm.
Normal Close still requires the existing fresh, repeated Alpaca stow evidence.

Display text, graphic labels and angle styles are updated only when changed.
The existing ten-second status-display grace now keeps stable labels through
brief poll gaps instead of alternating Connected/Updating. Optional pointing
readings use their own 60-second display age, independently of the five-second
movement-safety deadline. Sustained loss still shows stale/unavailable status.

Validation: native parser host tests cover identity, IDs/error codes, zero/false,
missing/invalid fields, malformed/deep/oversized/duplicate JSON and age wraparound.
Dashboard tests cover no repeated text writes, power expiry and the distinction
between display grace and movement permission. Alpaca polling and optional
telemetry tests also pass; `web_control` compiles successfully.

Deployment verification: the user explicitly authorized storing the native
Seestar authentication key in controller firmware. USB upload succeeded with
verified flash hashes. Running ELF SHA-256:
`db4c1916debf89c896493239448b43b4d9d756eaf3b7d4ebd855148721516c7e`.
The ESP32 status endpoint and live browser both reported battery 42%,
Discharging, external power false, battery temperature 23 °C and no battery
overtemperature. The live Overview omitted the stow-test card and reported no
JavaScript exceptions. Mutation observers saw no changes to the connection tag,
arm caption or bottom status line during 12 seconds of stationary polling.
Initial browser navigation during reboot did not complete; verification passed
at `http://192.168.1.135/` after network recovery. Passive boot/health capture and
private firmware artifacts: `diagnostics/20261017T211959698411Z/` (ignored).
No telescope/cover movement command was issued during deployment verification.

## Supervised arm controls — local implementation, not uploaded

Overview has **Open arm** and **Close arm** buttons. They issue native
`scope_move_to_horizon` and `scope_park`, respectively, through the authenticated
native connection. These command names are documented in the upstream
[arm-control implementation](https://github.com/wokka1/seestar_status_monitor/blob/main/open_arm.py),
which reports app packet-capture verification for S50/S30 Pro. Neither native
motion command has been exercised on this project's telescope by this change;
the earlier tested Alpaca FindHome path remains separate.

Both routes require the boot token/client ID, beta acceptance, home-network
access, explicit presence/physically open supported cover/path-clear/imaging-
stopped confirmation, and no other operation or network-maintenance owner.
Cover feedback must be fresh (<1.5 seconds), calibrated, clean, OPEN and within
three counts of its saved open endpoint, stationary and torque OFF. Telescope
status must be fresh (five seconds), connected, stationary and not tracking;
the telephoto camera must report Idle within its 60-second telemetry deadline.
The operator's imaging-stopped confirmation remains required because Alpaca
camera Idle alone does not prove native stacking is stopped. Open requires home;
Close requires not home. Neither button changes the cover position.

Before issuing a command, the cover worker must acknowledge maintenance mode.
The native transport then checks S30 Pro identity, `mount.close`, tracking=false
and `move_type=none`, and rechecks current cover/telescope evidence immediately
before sending exactly one motion request. A lost acknowledgment is not retried.
The arm operation uses the native worker; Alpaca safety polling continues in its
separate task. Power polling pauses during an arm operation.

Completion requires two distinct, fresh, post-command Alpaca sweeps reporting
stationary and tracking off. Close requires home; Open requires not home plus
fresh post-command altitude within three degrees of the horizon. An early home
flag while slewing and a command acknowledgment are insufficient. Normal partial
polling sweeps do not count as completed observations. The completion deadline
is 60 seconds. Operation phase/direction/ID and cover lock are logged without
authentication material.

Successful completion releases the cover-worker pause. Lost status, unsafe
cover evidence, camera activity, timeout or an uncertain acknowledgment leaves
the cover locked and shows inspection recovery. **Clear arm operation lock**
requires an explicit inspection confirmation plus fresh stationary telescope,
idle camera and safe open cover feedback. It never resumes or retries a move.
Use the Seestar app to stop telescope movement; Cover Stop only releases cover
torque. Leaving the browser does not abort native telescope motion.

API: POST `/api/telescope/arm/open`, `/close` with `clear=yes&imaging_stopped=yes`;
POST `/api/telescope/arm/finish` with `inspected=yes`. Arm supported/locked/phase/
direction/operation fields are included in `/api/alpaca/status`. Builds without
the local authentication header leave arm controls unavailable.

Validation: arm-state host tests cover preflight failures, worker acknowledgment,
early home, horizon completion, repeated samples, normal in-progress sweeps,
timeouts, stale status, uncertain command delivery, inspection and clock wrap.
Dashboard tests cover cover clearance/torque/calibration, camera and telescope
activity, confirmation, both command routes, cover lock and inspection recovery.
The web firmware compiles. No upload or live motion test was performed.

## Emergency shutdown — 2026-10-17

The persistent bottom dock offers **Emergency shutdown** beside Stop/release
torque. It is disabled without configured, connected Alpaca monitoring and the
native Seestar control capability. Confirmation describes interruption of capture
and requires clear telescope/cover paths and a supported cover. It ends the
observing session and closes the enclosure; it does not power off the telescope
or change the cover's torque-release policy.

The cover task owns `EmergencyShutdown`; native networking stays on its existing
worker. The sequence continues if the browser disconnects and never resumes after
reboot. Calibration, ordinary cover/arm actions and network maintenance are locked
for the operation. Entry requires calibrated, stationary, fresh cover feedback
and torque OFF. A raised telescope requires a fully open cover; an already stowed
telescope may close from an intermediate position. The sequence never opens the
cover automatically.

1. Read native S30 Pro identity, mount, camera, app functions and enabled plans.
   Stop an active plan using `stop_func {name:ViewPlan}`; stop active view/capture
   with `iscope_stop_view`, and any remaining exposure with `stop_exposure`.
   Stop tracking and existing slewing if reported. Writes are attempted once;
   a lost or rejected acknowledgment inhibits closure.
2. Require two distinct post-command native observations and Alpaca sweeps
   confirming idle imaging, no active plan, stationary mount, and tracking OFF.
   Idle camera alone is insufficient. Unknown/paused functions and contradictory
   nested live capture states cannot grant clearance.
3. If not already stowed, recheck the supported fully open cover and native/Alpaca
   idle evidence immediately before one `scope_park` request.
4. Require two fresh post-command observations from both sources: native mount
   closed, imaging/plan idle, and repeated Alpaca home, stationary, tracking OFF.
5. Close with the existing controller/driver and saved profile. Continuously check
   native clearance (under 3 seconds old), Alpaca stow (under 5 seconds), position
   and existing motion safety. Browser heartbeats are not used for this operation.
   Completion requires the saved CLOSED state and verified torque release, not
   just acceptance of a movement command.

Command acknowledgment deadlines are 15 seconds, idle verification 30 seconds,
stow verification 60 seconds, and closure the saved motion timeout (plus a
35-second outer deadline). The whole operation is bounded to 150 seconds.
Unknown states, communication loss, conflicting activity, unsafe cover evidence,
or motion faults inhibit closure or stop a closure underway. Errors and
cancellation latch an inspection lock. **Inspect shutdown outcome** requires
fresh quiet native/Alpaca readings and supported, stationary, torque-off cover
feedback before unlocking; a separate cover motion fault still needs recovery.

Stop invalidates native work and future sequence steps and requests cover torque
release. A telescope command already transmitted may still finish; use the
Seestar app if its motion needs stopping. A `stop_epoch` counter prevents a delayed
HTTP start from taking effect after Stop. All gates remain enforced in firmware.

Routes: authenticated POST `/api/emergency/start` with `clear=yes`,
`interrupt_capture=yes` and current `stop_epoch`; POST `/api/emergency/finish`
with `inspected=yes`. `/api/status.emergency` reports capability, lock, phase,
operation, cancellation epoch and outcome. No credentials enter these responses.

Protocol sources: [capture controls](https://github.com/astronomyk/seestarpy/blob/master/src/seestarpy/raw.py),
[app-captured plan stop](https://github.com/astronomyk/seestarpy/blob/master/src/seestarpy/plan.py),
and [native command reference](https://github.com/irjudson/seestar-api/blob/main/docs/seestar-api-reference.md).
Read-only queries confirmed the idle native schema on this S30 Pro. Host tests
exercise sequencing, repeated observations, wrong-operation/old data, timeouts,
uncertain acknowledgments, early home, capture restart, cancellation and clock
wrap. Browser fixtures exercise availability, active imaging, progress,
inspection, tab changes and Stop overtaking delayed start. No physical emergency
sequence has been exercised. Cover position remains encoder-based without
physical limit sensors; supervised mechanical commissioning remains necessary
before unattended weather protection.

### Upload verification — 2026-10-17

Uploaded the `web_control` build over USB after the operator's controller reboot.
The running ELF SHA-256 matched
`28f4885292f90ff222bd6d8f97971ed09c8ddf70c1c48f479f0949010032beb2`.
The build uses 48,960 bytes of static RAM and 1,027,677 bytes of program flash.
Saved limits 450–1900, OPEN 1531, CLOSED 493, speeds 100, acceleration 10 and
5000 ms movement timeout all survived the upload unchanged.

Read-only live browser checks confirmed the emergency control, idle/unlocked
sequence state and all three tabs switching without a document reload or
JavaScript exceptions. Native power telemetry resumed and reported 26% battery.
The cover remained stationary with torque OFF at position 1543, so its state was
UNKNOWN rather than OPEN. With the telescope reporting unstowed, the emergency
button correctly required a fully open cover or confirmed telescope stow. No
physical movement or emergency sequence was initiated during upload verification.

## Power telemetry recovery — 2026-10-17

After app use, the controller still returned successful Alpaca observations but
power data was over six minutes old. An earlier arm operation had entered
`inspect`. The native worker suppressed battery polling for every locked arm
state, including this inactive inspection state. This explains the missing power
readings; the observations do not establish that the Seestar app disconnected
the native interface.

`PowerMonitor` now pauses separate power reads only during active arm work and
refreshes immediately when that work completes or enters inspection. Inspection
locks remain latched. Normal refreshes are 30 seconds apart; a failed read is
retried after a five-second pause with a new socket and authentication handshake.
Failed reads never renew the last good sample's timestamp; it expires after
60 seconds as before. A successful read automatically restores the display.
Emergency shutdown and its inspection state reuse `pi_status` from their existing
native device-state requests, without adding a separate request to the safety
sequence. Power remains display-only and cannot grant movement clearance.

The API includes `power_retrying` and `power_paused`. The power card and telescope
telemetry explain automatic retries and temporary pauses separately from Alpaca
connectivity. No app-control takeover, automatic lock clearing, or movement retry
was added. Local host tests cover retry timing, stale-data expiry, recovery while
inspection stays locked, active-arm pause/resume and clock wraparound; browser
tests cover missing/restored battery data while the movement lock remains set.
The firmware build and these tests passed. After the operator confirmed the
telescope was stopped and the open cover supported, USB upload succeeded. The
running ELF SHA-256 matched
`06454fb5b1dbed3107ce4bdd77553df4e791d58c90ce04a55b371d1674cbdfd1`.
Saved calibration/profile settings were unchanged. Read-only post-upload checks
reported OPEN at 1531, torque OFF, connected Alpaca, and fresh power telemetry:
20% battery, 27 °C, discharging. No motion commands were sent during verification.
Power-read failure and recovery were simulated in local tests; no live app
session was interrupted to force a disconnect.

## False disconnect during shutdown preflight — 2026-10-17

Live status sampling reproduced alternating `valid=true` and `valid=false` with
`error=none`, working native power data, and an unchanged raised telescope. The
poller revoked its published snapshot whenever AtHome was false (likewise for
Tracking/Slewing true or CanFindHome false), even when that value agreed with the
previous complete sweep. An emergency POST arriving during this partial sweep
was rejected as lacking connected Alpaca/native control.

The poller now revokes an older safe snapshot immediately only when a new unsafe
reading contradicts it. Repeated unchanged unsafe states remain valid connection
telemetry and cannot grant stow clearance. Read errors, disconnected responses,
the five-second age limit, the 2.5-second maximum sweep duration, and two fresh
stowed sweeps before closure remain unchanged. Emergency shutdown can therefore
start while the telescope is raised, tracking or slewing, as intended.

Preflight errors now distinguish unconfigured Alpaca, missing native capability,
unavailable fresh connected status and unsupported stowing. The UI also checks
reported stow capability. Host regressions cover every intermediate polling stage,
each newly unsafe observation, disconnects, restored stow confirmation, and the
real poller feeding emergency-shutdown entry; the original repeated-unstowed
regression failed before the correction. No motion command is needed to verify
this rejection window.

The firmware and browser tests passed, then the correction was uploaded after
confirming idle, torque-off cover status and no telescope operation locks. The
running ELF SHA-256 matched
`d7c0eaa444905f85d4091a48b8381ec4ffce43c567893c0cb55dfb8fcaaf52bb`.
Fifty live status samples spanning ten completed sweeps all passed the emergency
connection/capability checks, with maximum sample age 4081 ms. Saved settings
were unchanged. Live browser checks confirmed Connected and an enabled shutdown
button across repeated polls. The confirmation dialog was opened and cancelled;
no physical shutdown or movement command was issued.

## Bounded shutdown telemetry recovery — 2026-10-17

A supervised recording shutdown stopped capture but entered the latched fault
`Alpaca status lost; closure inhibited` before stow/closure completed. Read-only
inspection found the cover OPEN at 1531, torque off, camera idle, tracking off,
and telescope unstowed. The previous firmware did not retain the failing request
or phase, so the exact transient failure cannot be reconstructed from that run.

Emergency shutdown now pauses on an Alpaca connection/read/age failure for up to
15 seconds, only before cover closure and only with the cover verified OPEN,
stationary, calibrated, with fresh position feedback and confirmed torque OFF.
Two distinct, fresh observations from both Alpaca and native control, sampled
after the outage began, must agree on home/movement/tracking and have consistent
activity states. Recovery does not itself establish stow clearance: the normal
idle/stow verification requires new observations afterwards. A partial cover,
lost cover feedback, unintended cover movement, or lost clearance during closure
still faults immediately. Recovery never extends command, phase or total limits.
Stop cancels recovery and keeps the inspection lock; recovery expiry also latches
that lock. A completed/faulted/cancelled operation never automatically restarts.

The native worker retries authentication/read/preflight failures only when no
control write has been attempted, with at least one second between attempts and
within the original 15-second command deadline. Once any capture-stop or park
write is attempted, an uncertain outcome consumes the action and faults without
a retry. During recovery no new action is dispatched; an already-started bundle
of stop-only commands may finish, while park transmission is blocked. A received
success is retained while connectivity is being verified and is never resent.

`/api/status.emergency` now includes `recovering`, `recoveries`,
`recovery_remaining_ms`, and a retained `diagnostic` (or null). The diagnostic
records the phase, interface, request, error, driver code, transaction, request
duration and Alpaca sample age. It remains available after a successful recovery
or final fault until the next operation/reboot. Only fixed request/error labels
and numeric metadata are recorded; authentication material and response payloads
are excluded. The telescope telemetry drawer displays **Last shutdown issue**;
the bottom dock displays **Reconnecting telescope…** during recovery. Stable
messages do not trigger repeated DOM changes.

Validation passed: ESP32 `web_control` build; emergency sequence, recovery,
cover-controller integration, native parser, power, Alpaca polling and stow host
tests; and the full local browser suite. Fault injection covers all pre-closure
phases, stale/duplicate/contradictory evidence, unchanged deadlines, lost/late
acknowledgments, Stop, clock wraparound, and no movement until fresh stow evidence.
The real Alpaca poller integration exercises its three-second failure backoff and
two complete recovery sweeps. The real CoverController integration verifies torque
release on a new status failure during closure. Browser tests check the recovery
message, retained request detail, locked controls, available Stop, and no flashing.

Prepared firmware ELF SHA-256:
`b34f201c363fbcd8e97f62b9c6bf8a65d55ca42264f2f9ac27cb78941fee81c1`.
The physical recording-to-stow-to-close sequence has not been retested with this
build. The previous fault remains latched on the controller pending physical
inspection before an upload/reboot. Latest read-only state remained OPEN at 1531,
torque OFF, telescope stationary/unstowed, camera idle, battery 10% discharging.


## Arm inspection deadlock fix — 2026-10-21, local validation

The incident snapshot reported an arm inspection lock, a stationary telescope
at altitude 4.64 degrees, and cover state STOPPED at 1529 with saved OPEN 1531.
The old recovery predicate required state OPEN, preventing inspection recovery
as well as a subsequent stow. The original lock trigger was not captured;
4.64 degrees also fails the existing three-degree horizon completion check.

Inspection recovery now accepts STOPPED within three counts of saved OPEN,
provided calibration is clean, position feedback is fresh, the controller is
ready, the cover is neither moving nor holding, and torque is confirmed off.
Fresh connected telescope status, idle camera, tracking off, and no telescope
motion remain required. The operator must inspect the physically open,
supported cover and clearance before clearing the lock. Clearing it issues no
movement and leaves the cover state STOPPED. A separate confirmed Close arm
request may then stow with the same near-open feedback; Open arm still requires
state OPEN. UNKNOWN, FAULT, partial opening, stale feedback and torque-on states
are not eligible. Worker and native transport recheck evidence before dispatch.

The arm API now exposes `arm_reason`, also included in phase-change USB logs and
the UI inspection message, to distinguish lost cover/status evidence, uncertain
acknowledgment and verification timeout. The horizon tolerance remains three
degrees; the native lift sends `scope_move_to_horizon` with no angle parameter.
The relation between native completion and reported Alpaca altitude needs a
supervised measurement before changing that criterion.

Regression tests cover the 4.64-degree timeout, inspected STOPPED recovery,
separate stow, denied lift, lost clearance and recovery guard failures. Browser
coverage exercises the inspection request without movement and button guards.
Validation passed: host arm regression executable, full live UI browser suite,
`pio run -e web_control`, and `git diff --check`. Firmware upload and physical
retesting remain pending.


### Deployment — 2026-10-21

Uploaded current `web_control` over `/dev/cu.usbserial-0001` at 115200 baud.
Flash verification passed; read-only HTTP status matched ELF SHA-256
`ae2149062fce3326555d9e36b5fc88ecad7a62cc83af337622049b61e177995a`.
Saved limits, endpoints and motion profile were unchanged. Before upload the
controller reported a movement-timeout fault at position 497 (saved CLOSED 493),
stationary with torque off. After restart it correctly reported UNKNOWN at 497,
ready, stationary and torque off; the old runtime fault was cleared by reboot.
Alpaca reported connected, home, stationary, tracking off, with fresh power data
and arm phase idle. No motion or servo EEPROM commands were issued during
deployment. Physical recovery testing remains pending. Local evidence and build
artifacts are in `diagnostics/upload-20261021-arm-recovery/`.


## Monitoring-only telescope integration — 2026-10-21

Raise and stow the telescope in the Seestar app. Overview retains telescope
position/status and cover Open, Close and Stop/release torque; telescope arm
buttons, inspection recovery, and emergency shutdown have been removed.
The retired arm, stow-test, dry-run and emergency POST routes return HTTP 410,
including requests from cached browser pages. They cannot dispatch movement.

Production Alpaca monitoring is now GET-only regardless of previously saved
connection mode. It does not issue Connected=true, FindHome, or auxiliary
connection writes. The transport rejects all writes locally; settings expose
only use of an existing Alpaca connection. App connectivity alone does not
establish that connection (see the 2026-10-26 investigation below). If Alpaca
reports disconnected, the controller continues bounded
read retries and inhibits closing rather than attempting to claim a session.
The native TCP 4700 worker is no longer started, so it cannot authenticate,
request arm movement or poll battery telemetry. Battery readings must be viewed
in the Seestar app. Existing keys/settings are not erased or rewritten on boot.

Cover Close requires fresh connected AtHome, stationary, tracking-off readings
from two completed safety sweeps, plus the existing cover and supervision
checks. The button no longer uses cached stow permission during a telemetry gap.
A close request refreshes telescope status before dispatch; the cover worker
continues checking stow while closing and stops on loss of clearance. Altitude
remains a display value, not proof of stow. Stowing does not automatically move
the cover: the operator still chooses Close cover. Manual mode remains an
explicit setting with physical stow confirmation, never a connection-failure
fallback. No new unattended closure policy is introduced.

Validation covers read-only transport rejection of legacy write calls, polling
freshness/repetition/disconnection, optional telemetry read-only behavior, and
browser absence of telescope commands plus raised/moving/stale/disconnected
stow gating. Live app-coexistence and consistent position reads still need a
stationary comparison test; these changes do not prove the conflict's cause.

Local validation passed: web_control firmware build, Alpaca polling and optional
telemetry host tests, production HTTP transport tests (including local write
rejection), full live UI browser suite, and git diff whitespace checks. This
monitoring-only revision has not been uploaded; no hardware commands were sent.

### Monitoring-only deployment — 2026-10-21

USB upload and flash verification succeeded. HTTP firmware identity matched
`f22298cc71355a30f1b6a9f5444aa557bf0a5c6e7d8815d2a012e6bc1f1729ea`.
Served UI no longer contains arm controls or emergency shutdown; cover Stop
remains. Saved calibration/profile unchanged; position 497, UNKNOWN, stationary,
torque OFF. Pre-upload fault was telescope stow confirmation lost. Read-only
Alpaca mode and unsupported native controls were verified. Latest telescope
observation: {'valid': False, 'connected': None, 'at_home': None, 'error': 'timeout'}.
No movement commands sent. Evidence: `diagnostics/upload-20261021-monitoring-only/`.


## Prioritized polling — 2026-10-21

One worker still serializes all read-only requests. Optional telemetry now has
its own 700-ms transport budget, runs no more often than every two seconds, and
is admitted only between completed safety sweeps when at least 750 ms remain
before the next sweep. Safety request deadlines remain 1200 ms, sweep validity
2500 ms, and snapshot freshness five seconds. Optional reads cannot consume the
next safety sweep's reserved time under the transport's bounded request model.
Altitude alternates with secondary telemetry, so its actual update interval
depends on completed safety sweeps; failed safety polling suppresses optional
traffic. No concurrent sessions or telescope writes are introduced.

Read-only failures retry after 300 ms, then 1000 ms, then 3000 ms until a complete
valid safety sweep resets the backoff. Failed observations immediately revoke
clearance. Recovery still requires two fresh consistent stowed sweeps; no
movement resumes automatically. Failure request, duration and age are exposed in
status JSON; error transitions are logged. Optional samples retain their last
successful value/timestamp separately from validity. The UI labels retained
altitude/azimuth/temperature/heater readings as stale with age, and distinguishes
cached telescope status from live status. Retained values never grant closure.

Tests exercise idle-window admission including clock wrap, bounded retries and
reset, retained-value validity, a slow optional request's deadline, HTTP errors,
and stale display values with Close disabled. Live comparison over movement and
weak Wi-Fi remains necessary; software cannot guarantee uninterrupted readings.


### Polling deployment verification

Host polling, telemetry and production HTTP transport tests plus the live UI
browser regression suite passed. USB upload and flash verification succeeded;
running ELF identity matched
`ea5fd8a755c79c2315956ea5a0d598a4b485e706882b78332a4032742f98c1b6`.
Calibration and profiles remained unchanged, read-only mode remained enabled,
and the new failure/retained-value fields were present. Eight live observations
included one initial disconnected response followed by seven valid samples.
Altitude progressed from approximately -10 to -89.8 degrees and AtHome changed
from false to true during the observation. RSSI ranged from -81 to -87 dBm.
This is short-run evidence, not a guarantee against subsequent network loss.
No movement requests were sent by the agent. Evidence and artifacts:
`diagnostics/upload-20261021-polling/`.

## Alpaca disconnected after telescope restart — 2026-10-26

The operator reported working Seestar app access and confirmed a telescope
restart around the outage. Controller logs recorded available status at 18:16
and a `connected` timeout at 18:17 Arizona time. During inspection at 18:29–18:30,
the telescope API was reachable again but repeatedly returned HTTP 200,
`ErrorNumber=0`, and `Value=false` for telescope 0 `connected`. Camera 0 and
switch 0 also reported disconnected. The host remained `192.168.1.131:32323`,
identified as the Seestar S30 Pro with driver `1.3.1-1`.

The controller at `192.168.1.135` continued polling: failed-request durations
and ages advanced, but completed safety sequence 3899 never advanced. Its
error was `disconnected`, not a current transport timeout. Wi-Fi was connected,
maintenance was idle, and the cover remained OPEN and stationary at 1532 with
torque enabled. Running firmware ID:
`c629ab0d1df762ea7fbfe87a063b153202b41033fab382267058b14aa9c51c29`.

This is a recovery gap in the monitoring-only design. The restart is consistent
with losing the previously established Alpaca sessions, and app use had not
restored them. `alpacaWorker` enables the client with automatic connection off;
`HttpTransport` rejects every PUT. Repeated GETs therefore cannot establish a
logical connection. Restarting the controller would retain that behavior.
The UI's statement that monitoring uses a connection established by the Seestar
app is not reliable for this case.

The next recovery step is an explicit telescope `Connected=true` PUT, followed
by full fresh safety sweeps and app-coexistence verification. Any future
automatic session recovery needs a deliberate change to the current GET-only
policy; it must preserve the ban on telescope movement and other device writes.
Direct AtHome=true, Slewing=false, Tracking=false and altitude −89.8° responses
were also available while disconnected; these must not bypass the connection
or repeated-stow checks. Camera and switch sessions are separate display-only
concerns.

This investigation sent GETs only. No reconnect, firmware upload, controller
restart, torque change, or movement was requested. Recovery has not been tested
for this incident. Read-only capture:
`diagnostics/alpaca-disconnect-20261027T012958Z/responses.json`
(folder timestamp is UTC; observations were October 26 in Arizona).

## Automatic monitoring session recovery — 2026-10-26

The operator requested a fix for the restart recovery gap. Enabled monitoring
now automatically establishes the configured telescope session and the separate
camera 0 / switch 0 sessions used for optional telemetry. This deliberately
supersedes the October 21 blanket GET-only policy. The transport allows only
`PUT connected` with a fixed `Connected=true` body for those device families.
FindHome remains rejected before opening a socket; no generic command route,
camera exposure, heater setting, telescope movement, or native worker is enabled.

The existing polling state machines require a successful, validated
`Connected=false` GET before scheduling each connection attempt. Timeouts, HTTP
errors and malformed responses only trigger read retries. Each session has a
ten-second minimum reconnect interval; a lost PUT acknowledgment is followed by
GET verification rather than an immediate repeated write. A connection reply
never counts as a status or stow observation. Cover clearance still requires
two fresh complete stow sweeps, and a stopped/faulted move never resumes by
itself. Optional session work remains outside safety sweeps, within its existing
700-ms request budget. Maintenance pauses all monitoring and resumes recovery
after release.

`/api/network` now reports effective `alpaca_read_only=false`, matching the
poller's status. The legacy stored mode is retained for NVS compatibility but
does not override this behavior; no settings save or schema migration is needed.
Disabling monitoring still stops all polling/session requests. Configuration
explains automatic recovery and keeps movement in the Seestar app.

Regression coverage includes repeated telescope restarts, failed reads, lost
connection acknowledgments, reconnect throttling, fresh-stow requirements,
independent camera/switch recovery, exact PUT forms and response validation,
rejected telescope movement, and the updated Configuration explanation.

### Live session recovery and candidate build

The authorized one-time recovery sent one `Connected=true` PUT each to telescope
0, camera 0 and switch 0, after each reported disconnected. Each acknowledged
success and subsequently reported connected. Four controller observations then
reported valid, connected, repeated stow with advancing sequences 3901–3906;
later reads also refreshed camera state/temperature and heater status. Cover
state, position 1532, torque ON, command ID, calibration and firmware identity
were unchanged. No movement or other device setting was commanded.

The development candidate built successfully: 1,098,448-byte binary with 212,272
bytes remaining in each application slot; ELF ID
`5326a072345cc01fc4884c98ddfa0af652460d2ac385a2875df8e63f53f93fa2`.
Host polling, telemetry, production HTTP transport, cover safety and maintenance
integration tests passed. The transport test harness was updated for its newer
maintenance/Arduino dependencies. The full live UI and Configuration browser
suites passed. Their fixtures/assertions were brought up to date for completed
Alpaca sequences, grouped request-recovery messages, and the existing CLOSED
maintenance policy (torque ON is permitted; calibration jogs leave STOPPED).
The cover subsequently reported CLOSED at 495, stationary with torque ON,
allowing routine OTA under the existing maintenance policy.

Responses, the candidate manifest and local firmware artifacts are in
`diagnostics/alpaca-recovery-20261027T013358Z/`. Application coexistence and
automatic recovery after an actual telescope restart with the candidate remain
hardware validation steps; the incident recovery used the older running image.

### OTA deployment verification

Development OTA completed with transaction
`6c06aad432a4f76ac8278d0bf0a4929f`. HTTP identity matched candidate ELF
`5326a072345cc01fc4884c98ddfa0af652460d2ac385a2875df8e63f53f93fa2`,
startup was accepted, and the durable result reported complete. The served UI
contains the new automatic-reconnection explanation. Network and Alpaca status
both report the effective automatic connection mode.

Five post-update observations advanced from sequence 8 to 17, all valid,
connected and repeatedly stowed with no Alpaca error. Altitude, azimuth, camera
state/temperature and heater status all refreshed. The cover remained CLOSED at
495 with torque ON. Saved endpoints, limits, motion profile, telescope address,
hostname, holding preference and time settings matched the pre-update capture.
No cover or telescope movement was requested by the update. Evidence is in the
same recovery folder: `ota-upload.log`, `installed-status.json`,
`installed-network.json`, `installed-monitoring.json` and `final-status.json`.
