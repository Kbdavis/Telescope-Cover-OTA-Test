# Configuration interface plan

The Configuration tab should help an owner connect the controller, connect the telescope, choose cover behavior, and recover from problems. Organize settings around those tasks, make each change's effect clear before saving, and keep recovery actions separate from everyday setup.

Implemented locally in the live tab in `data/ui/index.html` and `data/ui/app.js`, with narrow settings-handler changes and browser tests. Hardware deployment is separate. The standalone configuration page was retired during release cleanup; the active `/configuration` route serves the live tab. This document retains the design rationale and acceptance criteria.

## Current usability problems

The existing section navigation, individual save buttons, password privacy, draft preservation, and recovery confirmations are good foundations. Keep them. Address these specific problems:

| Current presentation | Proposed improvement |
| --- | --- |
| “A setup that works for you.” | Use the direct page title “Configuration.” |
| “Name & appearance” combines a network address with a browser preference | Put the address beside Wi-Fi; give appearance its own section. |
| Telescope integration, monitoring, and connection mode use different terminology | Use “Telescope connection” consistently, with monitoring explained beneath it. |
| “Monitoring enabled” can appear without a working telescope connection | Separate the saved monitoring setting from live connection status. |
| A disabled connection-mode dropdown presents one option | Show a plain explanation of the supported mode and the actual saved state. |
| “Advanced” groups motor holding behavior with diagnostics | Give cover behavior a visible section; put diagnostics under Troubleshooting. |
| “Disable torque after move” requires interpreting a negative checkbox | Offer two explicitly named choices for what happens after Open or Close. |
| Disconnected-servo recovery appears between routine settings | Move it into an expanded-on-demand recovery section. |
| “Reset connection settings” understates what is reset | Name it “Reset controller settings” and list the full effects. |
| Appearance says “all three pages,” while navigation has more views | Say “Applies immediately in this browser.” |
| Save guidance says changes apply only on save, although appearance is immediate | Explain controller settings and browser appearance separately. |

## Proposed page layout

Keep one scrolling page with a compact section index. On desktop, place the index on the left and a single column of settings on the right. On mobile, replace the sidebar with a compact “Jump to section” control. Avoid another layer of tabs.

```text
Configuration                         All changes saved / Unsaved changes
Manage connections, cover behavior, and recovery.

[Settings availability message, when an action is blocked]

Section index                 Settings
Network & address             Current connection and controller addresses
Telescope connection          Monitoring setting and connection status
Cover behavior                Motor holding after Open or Close
Appearance                    Light / Dark / System
Troubleshooting & recovery    Diagnostics, recovery, and reset actions

Existing cover status and Stop control remain accessible
```

Use these section names verbatim in both navigation and headings. Keep ordinary fields visible. Collapse technical connection details and recovery controls, with summaries that explain what is inside. Do not collapse a section containing a validation error.

## Network and address

Start with a read-only summary: current network, connection state, IP address, and clickable local address. Distinguish “Connected to home Wi-Fi” from “Using setup hotspot.” An unavailable reading should say “Connection status unavailable,” rather than implying a confirmed disconnect.

Place two separate forms beneath that summary:

| Form | Fields and actions | Supporting text |
| --- | --- | --- |
| Home Wi-Fi | Network, Refresh networks, manual network entry, Password, Show, Connect & save | “Choose a 2.4 GHz network.” |
| Controller address | Local network name with fixed `.local` suffix, full address preview, Save address | “Use lowercase letters, numbers, and hyphens.” |

Use “Enter network name manually…” so users do not need to know whether their network is technically hidden. Keep saved networks available when they are absent from scan results. Show signal quality in ordinary language; retain raw dBm in optional details if useful.

Display “Saved password will be kept” explicitly. Show/Hide applies only to a newly entered password; the saved secret must never be fetched. When switching networks, make clear that a password must be entered for the new network. An explicit “Replace saved password” interaction would remove ambiguity between keeping a password and intentionally clearing it; implementation must preserve the server's exact-SSID reuse rule.

Before connecting, explain that this browser may lose contact and show the recovery hotspot details. Keep those instructions available during reconnection. Do not label the connection successful until the controller confirms the selected network and saved configuration. An uncertain response should say “Connection result not confirmed” and offer a status retry.

Changing the local name currently applies without restarting. Show the confirmed new URL and retain the numeric IP as a fallback when local-name resolution is unavailable.

## Telescope connection

Use the heading “Telescope connection” and the description “Read Seestar status used by the cover's closing checks.” Show two distinct facts:

- **Monitoring:** On or Off, based on saved settings.
- **Connection:** Connected, Connecting, Unavailable, or Status outdated, based on available fresh telemetry.

The primary controls are “Enable telescope monitoring” and “Telescope IP address.” Put Port and Device number under “Advanced connection details,” retaining the existing defaults of 32323 and 0 without overwriting saved values. Explain that the address must currently be a numeric IPv4 address. Include brief guidance to find it in the Seestar app or router's device list.

Replace the disabled mode dropdown with explanatory text for the supported mode: “Uses the connection established by the Seestar app.” The current UI forces its draft to read-only, while stored settings can represent automatic logical connection. A future implementation must display and preserve the actual saved mode rather than silently changing it during another edit. Adding a selectable mode requires a separate explicit design decision.

When monitoring is turned off, dim connection fields and retain their values. Disabling monitoring should not require entering a valid new address. This needs validation review in both the UI and server; it is not only a visual adjustment.

Use “Save telescope settings & restart.” Explain the restart beside the button. Saving these settings does not command telescope or cover movement. Do not describe the entire controller as monitoring-only: separate operational telescope actions already exist elsewhere.

Connection success must not be presented as confirmation that the telescope is stowed or that the cover may close. Continue using the existing motion interlocks for that decision.

## Cover behavior

Make this a normal, visible section because it affects how the cover is supported after movement.

Present “After a successful Open or Close” with two radio choices:

- **Keep motor holding** — “The motor continues holding the cover at the endpoint.” This reflects the current default.
- **Release motor** — “The motor stops providing holding force after the move. The cover must be mechanically supported.”

Add a short scope note: “Stop and motion faults still release torque. Calibration and manual jogs have separate holding behavior.” Do not suggest that holding torque guarantees retention during power loss.

Use “Save cover behavior & restart.” Keep endpoint positions, travel limits, speed, acceleration, and timeout in Calibration, with a link labeled “Adjust travel and motion in Calibration.” Avoid duplicate editors for those settings.

The current advanced-settings endpoint saves both holding behavior and Debug visibility. Splitting their presentation must preserve the other saved value when either section is saved; it must not save another section's uncommitted draft.

## Appearance

Use a small section with Light, Dark, and System choices and no Save button. Supporting text: “Applies immediately across the interface. Remembered in this browser.”

Appearance should remain usable while disconnected or while controller settings are locked. It must not contribute to the controller's unsaved-settings indicator.

## Troubleshooting and recovery

Use three clearly separated groups, with destructive actions last:

| Group | Proposed contents |
| --- | --- |
| Diagnostics | “Show Debug tab,” brief explanation, Save diagnostics & restart. Explain that visibility does not switch controller event collection on or off. |
| Settings recovery with servo disconnected | Collapsed instructions and the explicit physical-disconnection acknowledgment. Explain that this is for settings recovery after failed servo startup and does not authorize motion. |
| Reset settings | Two separately described actions with consequence-specific confirmations. |

Do not preselect or persist the disconnected-servo acknowledgment. Display an obvious active-recovery notice while it is selected. Preserve all server checks; the checkbox must never become a general bypass for an attached servo.

Rename the first reset action **Reset controller settings…**. Its confirmation must state that it resets Wi-Fi credentials, local name, telescope settings, endpoint holding preference, Debug visibility, and beta acknowledgment. Calibration is preserved. The controller restarts into its setup hotspot. Browser appearance remains a browser preference.

Name the second action **Clear calibration…**. Explain that it removes saved endpoints, travel limits, and the saved motion profile, preserves controller connection/settings, and restarts. Calibration is required before normal Open/Close use.

Use specific confirmation buttons: “Reset settings & restart” and “Clear calibration & restart.” Cancel receives initial focus. Show the recovery network instructions before the user confirms an action that disconnects them. Neither action changes servo EEPROM.

## Saving, validation, and availability

Keep section-level saves. Each form gets an Unsaved changes marker, its own Save button, and a “Discard changes” action that restores that section's confirmed values. The page summary can say “2 sections have unsaved changes.” Do not add Save all: network switching and restarts have different effects and ordering requirements.

Keep drafts when switching tabs and during background polling. Before a restart or network change, identify any unsaved edits in other sections and offer to return to them or explicitly discard them and continue. Do not persist passwords in browser storage to survive a restart.

Use consistent feedback beside each action: Saving, Restarting, Reconnecting, Saved, or Could not confirm. Mark Saved only after reading back the expected values. Preserve drafts after failure and prevent duplicate submissions while a request is pending. A lost response must not cause an automatic replay of a reset.

Show validation beneath the affected field, focus the first invalid field, and explain how to correct it. Examples: “Enter an IPv4 address, such as 192.168.1.131” and “Use a name without spaces or the .local suffix.” Retain backend validation as authoritative.

Put the current settings lock reason above the forms, visible on mobile as well as desktop. Explain the relevant next step: wait for movement to finish, reconnect, or support the cover before releasing motor torque. Do not release torque automatically when entering Configuration or saving settings. Keep the existing Stop control and its torque-release consequence visible.

## Visual and accessibility guidance

Use the existing visual theme with a consistent heading, description, fields, then action row in each section. Reduce decorative slogans and uppercase eyebrow labels. Use normal text size for instructions that affect safety or reconnection.

Ensure labels remain visible above inputs, units and suffixes are explicit, keyboard focus is visible, and status is communicated with text as well as color. Announce save results without repeatedly announcing routine polling. Support narrow phone widths and text zoom without horizontal scrolling or the persistent Stop control obscuring buttons.

## Implementation sequence for later work

1. Agree on the section order, labels, and sample interactions in this plan.
2. Produce a local static preview covering desktop and phone layouts, including disconnected, locked, and unsaved states.
3. Reorganize the existing controls and update copy while preserving behavior.
4. Implement draft discard, restart handling across sections, status distinctions, and conditional validation. Review the shared advanced-settings endpoint and saved telescope mode explicitly.
5. Bring any accessible standalone configuration page into terminology and behavior alignment. Update `docs/WEB.md` with the final behavior.
6. Run focused browser and settings tests before any hardware deployment. Treat deployment as separate work.

## Acceptance criteria

- An owner can find Wi-Fi, telescope address, motor holding behavior, and appearance from the section names alone.
- Every existing configuration control has a clear destination; calibration controls remain in Calibration.
- Every action states whether it saves immediately, switches networks, or restarts the controller.
- Monitoring enabled, telescope connected, and telescope stowed are visibly distinct concepts.
- Saving one section preserves other saved settings and does not silently submit another draft.
- Polling preserves edits; failures preserve recoverable drafts; restart actions account for drafts elsewhere.
- Saved passwords remain private, with unambiguous keep/replace behavior.
- Reset dialogs accurately describe the full reset scope and recovery path.
- Keyboard and mobile users can reach fields, explanations, error messages, and Stop.
- Existing motion interlocks and recovery restrictions remain enforced, with no new automatic movement or servo EEPROM writes.

## Source references

- `data/ui/index.html`: current live tab structure and copy.
- `data/ui/app.js`: settings drafts, save actions, availability rules, and confirmations.
- `data/ui/theme.js`: browser appearance persistence.
- `src/network_setup.cpp`: setting routes, maintenance checks, reconnect and restart behavior.
- `src/settings.h` and `src/settings.cpp`: saved values and reset scope.
- `docs/WEB.md` and `docs/ALPACA.md`: interface and telescope behavior context.

The implementation was checked in the local browser fixture at desktop and phone widths. Focused configuration checks, the existing full UI regression, and an isolated firmware build passed. No firmware upload or hardware movement was performed.
