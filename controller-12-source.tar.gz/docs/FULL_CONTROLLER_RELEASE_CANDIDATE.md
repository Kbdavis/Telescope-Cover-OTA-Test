# Complete controller release candidate — 2026-11-12

Status: **unpublished candidate; production installation blocked on hardware acceptance**.
The owner explicitly directed that `192.168.1.43` remain unchanged and that the
spare servo remain without external power. Those constraints remain in force.

The complete `web_control_multiturn_ota` application includes the existing cover
controller, calibration/teaching, settings, network setup/recovery, telescope
monitoring/interlocks and diagnostics, with a signed browser updater integrated
into Configuration. The shared small blue header badge opens Firmware updates.
Automatic checks default on; the browser preference can disable them. Device
update authorization is boot scoped and obtained automatically from the same
home-LAN page. Installation still requires explicit confirmation.

## Frozen candidate

- Current candidate: `0.1.0-beta.9`; monotonic controller build 9.
- Exact application, recovery images, curated source archive, source commit,
  public signing key, checksums, licensing inventory, ELF/map and release metadata:
  `diagnostics/2026-11-12-full-controller-candidate-01/beta9/`.
- `release.json` and `SHA256SUMS` in that frozen directory are the authoritative
  version, source and binary identity. Acceptance reports are retained alongside
  the candidate, without modifying its frozen bytes.
- Main workspace remains uncommitted. The candidate source is a separately
  committed, curated software snapshot; it excludes personal credential headers,
  private signing keys, CAD/manufacturer reference files and hardware captures.
- `tools/package_browser_candidate.py` rejects dirty/mismatched source, checks
  image/layout/ELF/startup hook, freezes the actual build inputs and marks the
  package unavailable for production installation or publication.

The private 4 MB spare-flash backup is retained outside the distributable package.
No full-controller image or GitHub release tag has been published. Public commit
`c597d35` adds only an empty controller catalog and explains qualification status.
The existing bench catalog/releases retain their original bytes and identity.

## Transfer and safety boundaries

Firmware uses 768-byte chunks within the existing 2,048-byte HTTP body bound.
A POST response confirms the exact transaction and consumed end offset only after
the flash-owning worker has written the chunk and updated its digest. The bounded
web adapter retains one connection without blocking its loop while completion is
pending, with a five-second acknowledgement deadline. Queue depth remains one.
The browser performs no successful-path progress GET between chunks. It stops
and requests cancellation after a lost, wrong-offset, stale or failed response;
it never blindly replays an ambiguous chunk. The separate bench client negotiates
its old 384-byte/GET fallback for legacy receivers.

For an image this size, the normal transfer drops from about 6,164 chunk/poll
requests to 1,541 chunk requests, excluding discovery/start/finish/reboot checks.
This is a request-count reduction, **not a measured full-controller speedup**.
No complete-controller OTA transfer has run while the servo is unpowered.

The worker reserves the existing OTA maintenance lease and preserves CLOSED,
stationarity, calibration, worker-pause, network, Stop and memory checks. The
existing conservative 98,304-byte internal-heap and 65,536-byte largest-block
budgets remain unqualified for the complete workload. Signature verification
precedes flash admission; source ELF/build, image prefix/descriptor and full-image
SHA-256 remain checked. Durable intent precedes boot selection. Application and
calibration settings are hashed and checked across browser updates. The established
pending-image startup, journal reconciliation and rollback machinery remains in
control of acceptance.

The complete-controller trust anchor is distinct from the bench signing key.
Personal Wi-Fi, development OTA and telescope credential headers are excluded
from this build. The old on-device desktop receiver is not enabled in the new
candidate; the production board's currently installed development receiver is the
one-time bootstrap route, once separately authorized and admitted.

## Servo startup limitation

This candidate requires the exact already commissioned native multi-turn profile,
with offset 85 and the supported identity/lock bytes. Startup and updates only
inspect it. They never apply or restore servo configuration. The native driver
rejects factory single-turn fallback without configuration, goal or torque writes.
It cannot silently reuse native calibration under factory feedback.

An external servo power cycle may restore the factory profile. Automatic RAM
profile restoration from the older commissioning/USB target is deliberately not
part of this inspect-only candidate. Its production replacement policy and cold
power-cycle behavior therefore require explicit qualification before deployment.
Any proposed servo-register writes must be shown exactly and approved first,
per AGENTS.md. No such writes were made in this work.

## Evidence and remaining gates

The offline release gate covers protocol bounds, HTTP framing/deferral/deadlines,
source/policy separation, native-only driver behavior, actual maintenance-worker
integration, signing interoperability, UI behavior and existing motion regressions.
Transfer tests exercise successful combined acknowledgements, old-receiver fallback,
wrong/stale offsets, HTTP failure and lost acknowledgement without replay/activation.

The spare (`192.168.1.135`, MAC `28:05:a5:4d:ff:9c`) was backed up while idle.
Its existing bootloader and partition table exactly matched the complete candidate.
The bench receiver rejects complete-controller product images, so its bootstrap
used verified USB writes to the same pinned boot components/application; NVS was
not erased. Beta.7 booted with startup accepted and no powered servo. A newly added
native-only regression rejected an earlier beta.6 before any hardware installation.
Beta.7/8 were superseded by beta.9 after browser connection-reset testing.
The small loader is embedded in the initial HTML and authorized by its exact CSP
hash, avoiding an additional critical network request. It provides bounded
main-script download retries. A failed download may retry at most three
times; partially executed application code is never reexecuted by that loader.

Hardware browser checks use the actual spare page and simulated future release
metadata, clearly distinguished from public-release discovery or installation.
They cover the shared badge, navigation to Configuration, small blue styling,
desktop/tablet/mobile layout, confirmation and persisted automatic-check settings.
Separate admission checks use a private synthetic signed manifest and send **no
image chunks**: invalid authorization, foreign origin, missing confirmation,
bad signature and stale control generation are rejected; the valid signed start
fails at physical admission with zero bytes, unchanged boot/firmware and unlocked
maintenance. This proves refusal with an unpowered servo, not successful OTA.

Before production promotion, power the spare with the mechanism detached/clear,
inspect its exact profile, obtain any required register approval, establish honest
stationary CLOSED/calibration evidence, then test full-workload signed update,
reboot, settings preservation, Stop/cancellation, interruption and rollback. Measure
transfer speed and runtime memory. Resolve cold-start/native-profile recovery and
complete dependency distribution review before publishing a supported full release.
Do not fabricate calibration, bypass admission or substitute bench-only success.

## Production read-only audit

Only GET `/api/session`, `/api/status` and `/api/ota/status` were used on
`192.168.1.43`. Installed ELF:
`5bdab9d858f9cfffa5966e35ff535602be36f66805ab320a23ce89eec70ea1cd`.
It reports startup accepted, development-recovery OTA enabled and idle, CLOSED,
calibrated, no motion/holding, and torque ON. The recovery updater requires verified
torque OFF. No torque, Stop, movement, maintenance preparation, flash, restart,
configuration or settings change was requested on that board. It remains the
owner's working controller; candidate promotion is not authorized by this report.

## Final retained identity

Beta.9 application: 1,183,664 bytes; slot headroom 127,056 bytes.
Source commit `de0fabb19746fb11bc2caf6ef20fbb8f98d72487`.
ELF `8f450f5c5d51c4bae23a6d22a71a4666f8ee55b9dd560c90478e75f864e291b1`.
The standalone unpublished ZIP is
`diagnostics/2026-11-12-full-controller-candidate-01/complete-controller-beta9-candidate.zip`.
It contains only the frozen package, never the raw flash backup or private evidence.

The final beta.9 served-page test deliberately failed the main-script request once
and observed recovery, then failed it three times and observed the visible bounded
failure message. The partially executed application was not rerun. There were no
controller POST requests, new boot or JavaScript exceptions in that test. The inline
loader's exact served bytes were independently checked against the embedded CSP
SHA-256 hash. Runtime HTML and application source keep the existing CSP restrictions.

Final beta.9 actual-page checks passed at 1440, 1024 and 390 px. The blue badge
measured 120.4 × 28 px centered at x=720 on a 1440 px viewport, between the brand
and navigation. All views linked to Configuration, the automatic-check preference
survived reload, confirmation remained required, and no controller write occurred.
Final beta.9 admission tests rejected every invalid request and refused the valid
signed start at physical admission with zero image bytes and no restart. The spare
was left in the expected terminal `failed/admission` state with maintenance unlocked,
servo unavailable and no motion. This is a recorded negative test, not a failed flash.

A final GET-only production audit confirmed the original ELF and boot ID, idle
receiver, CLOSED state and torque ON. No production changes occurred. The owner's
request to leave the spare servo without external power prevents the remaining
full-path hardware checks. The isolated test browser was closed; user browsers
and their update-check preferences were not modified.
