# Bounded multi-turn commissioning

2026-11-09: a separate [automatic RAM startup qualification candidate](MULTITURN_STARTUP_QUALIFICATION.md)
was installed after operator approval. Its first stationary RAM setup passed;
external power-cycle and movement qualification remain pending. It does not
change this probe's explicit-apply behavior and is not promoted into normal
firmware.

500-count jog update (2026-10-29): after the user reported correct operation
of the taught endpoint moves, the user requested 500-count jogs. The multi-turn
profile now advertises and enforces a 500-count jog limit, including crossings
in either direction. The UI uses the advertised limit for boundary steps.
Speed remains capped at 100 and acceleration at 10; calibrated jogging still
respects the taught arc, and explicit manual mode retains its range override.
No servo configuration changes or automatic movements accompany this update.
Driver tests cover positive and negative 500-count crossings and reject 501;
worker and browser tests cover the updated capability. Earlier 100-count caps
below describe the preceding commissioning builds.

Installed 500-count firmware ELF
`00db56bb95aa42a1afc3571f00e170ff52ff29fd3ddf4c58e3e56474c2fab905`
by OTA transaction `907b1c6a3612e87a9ee9285917800592`. Startup accepted;
500-count capability and rollover support verified, saved endpoints OPEN 3546
and CLOSED 338 retained. No jog or endpoint motion was commanded for the update.

Step 4 endpoint fix (2026-10-29): a newly saved CLOSED 317 / OPEN 3528,
direction -1, 885-count arc was rejected by the blanket 100-count native-goal
guard. No endpoint goal was transmitted; the error was not a direction fault.
Explicit saved endpoint commands now have a separate driver entry point that
requires a valid taught arc shorter than half a turn, a target equal to one of
its endpoints, current feedback inside the arc, torque enabled, exact approved
configuration, speed at most 100 and acceleration at most 10. It maps the arc
into continuous native coordinates (3528 to 4413 for this CLOSE command).
Native goals remain bounded to +/-8191 and each displacement below 2048.
Manual and teaching jogs retain their independent 100-count cap. Fault notices
show the actual latched fault instead of replacing it with arc/timeout advice.
This software change does not qualify full physical travel; it needs a watched
Step 4 test. Installing firmware does not command motion or rewrite endpoints
or servo configuration.

Installed by recovery OTA transaction `726cbafdf224a5a06694c7006bdeacf3`,
ELF `0332bd3f69ae8944e8037d934e6ae5df104d6c939f3ee4986e03fcaa182a6f11`.
Startup accepted; readback OPEN 3528, torque OFF, saved CLOSED 317 / OPEN 3528,
direction -1, length 885, rollover enabled and jog cap 100. No motion command
was issued during installation. Driver regressions verify continuous 4413 CLOSE
and 3528 OPEN goals, endpoint/arc rejection, speed/acceleration limits and the
unchanged ordinary-goal cap; controller, travel and worker integration tests
and both development firmware builds passed.

Status 2026-10-29: **approved settings applied; one unloaded positive crossing
passed**. The user approved the exact maximum-angle and phase changes below
and one bounded 100-count test. Tested firmware was
`cc5ad9198fc7cbe3e4d63e6951658bc4d60b99cf675522c5c78ec44ffbdfd26a`,
installed by recovery OTA transaction `4549aef2e5c673835951dbc3659b4848`.
The user requests physical positive travel through encoder 4095 → 0, and has
confirmed a detached shaft and a bounded unloaded test. Simple wrapped absolute
goals failed twice on the exact factory profile: most recently 4041 → 45 drove
backward to 4017. The supervisor faulted and confirmed torque OFF, with zero
failed reads. That bench image was replaced by normal development ELF
`48b0e6f…` through completed recovery OTA transaction
`5b7db11efcadd1932b9dda42ca4ede18`. Position was then 4016, stationary and OFF.
Evidence: `diagnostics/2026-10-29-boundary-retest/`.

Applied readback changed only bytes 11–12 and 18. Lock remained 1, mode 0,
offset 85, and stationary feedback stayed 4016 during configuration. After an
explicit stationary Recheck, the 100-count CLOSE test sent native goal 4116,
displayed goal 20. Accepted readings increased through 4019, 4031, 4041, 4051,
4061, 4072, 4082, **4094 → 7**, then 17 and 18. Five stable samples completed
by 1257 ms; final released position was 19 (native 4115). There were 25 valid
control reads, zero failed/rejected reads, no heartbeat errors and no new fault.
Later idle readback confirmed register 42 = 4116, native feedback 4115,
display 19, zero speed/load/current and torque OFF. No return move was commanded.
The support cache retains the deliberate configuration fault from before Recheck;
it must not be reported as a fault from the completed crossing.

This qualifies the observed small positive unloaded crossing only. Reverse
crossing, loaded/full cover travel, restart with attached cover and external
power-cycle behavior remain unvalidated. The settings remain RAM-only; no EEPROM
unlock occurred and application calibration was not saved. Do not install
factory-only normal firmware while this profile is active: restore and verify
the exact factory configuration and single-turn feedback first, or retain a
build that explicitly understands this native feedback/profile.

Final step-limit alignment firmware
`132539ebb7e904ca426d098c92415b6ccc017b07f90bdb4f25222f28a6dab381`
was installed by OTA `97b88930dc5cff64f7bea652efce1fb1`. This changes UI/backend
jog-limit enforcement, not the tested native goal/feedback logic. After the
ESP32-only restart, all 40 probe bytes and lock 1 still matched, native position
was 4115 / display 19, torque OFF, manual eligible, rollover supported and the
advertised maximum step 100. Old saved endpoints/reference/profile remained
review evidence unchanged. Startup is UNKNOWN and requires fresh calibration.

Host driver, controller, travel and actual-worker tests passed, including
rejection of oversized commissioning steps before torque enable; production,
normal development and probe builds passed. No additional movement was used to
verify the UI-limit update.

## Exact approved configuration changes

These are a separately approved experiment, not an automatic startup repair.

| Address | Function | Apply | Restore |
| --- | --- | --- | --- |
| 11–12 | Maximum angle | 4095 (`ff 0f`) → 0 (`00 00`) | 4095 (`ff 0f`) |
| 18 | Phase / full-angle feedback bit | 12 (`0c`) → 28 (`1c`) | 12 (`0c`) |

Minimum angle 9–10 remains 0. Mode 33 remains **0**, position servo mode.
Offset 31–32 remains 85. Lock 55 must remain **1** and is never written or
unlocked. No configuration write is retried. Both before and after snapshots
must match all 40 identity/configuration bytes except these exact fields.
Rollback accepts only the factory, complete probe, or either exact known
intermediate combination, to recover an uncertain acknowledgement without
repairing unrelated corruption. A write attempt invalidates application motion
permission and latches a fault; no goal or torque enable is part of application.

The [manufacturer's memory table](https://ftservo.github.io/ftservo-wiki/reference/parameter/memory-sts/)
documents min/max zero for multi-turn absolute position control, signed-magnitude
position words, phase bit 4 for full-angle feedback, and nonretention of locked
configuration writes across power loss. The acceptance and positive crossing
observed above do not qualify other units or unattended operation.

## Prepared implementation and limits

`web_control_multiturn_probe` inherits authenticated development recovery OTA.
It never changes configuration at startup. Its fixed apply/restore routes are
`/api/commission/multiturn/apply` and `/api/commission/multiturn/restore`, guarded
by detached/clear confirmation, teaching, verified torque OFF and maintenance.
They reuse the existing dedicated servo-worker commissioning commands; no HTTP
handler writes the bus. Evidence is published as `multiturn_probe` in status.

The driver accepts the exact probe profile only in that build. Native signed
feedback is retained internally and exposed in diagnostics; display and taught
arc coordinates remain modulo 4096. A positive crossing sends a continuous goal
such as **4016 → 4116**, displaying **4016 → 20**. It does not send raw 20 as a
full-turn reverse command. Negative crossing and torque-enable hold staging
also preserve the native turn. A native jump of half a turn or more is rejected
even if its wrapped display angle is identical. Native magnitude is capped at
8191; individual native moves at 100 counts, speed 100, acceleration 10.

Manual crossing derives its own explicit bounded arc and only becomes available
when the driver advertises crossing capability. Normal firmware still rejects
unqualified crossing. Existing configuration, direction, discontinuity,
heartbeat, settling, timeout, Stop and torque-release checks stay in force.
Saved endpoints and their reference are not rewritten. This commissioning
profile is not a full-cover or unattended-operation release.

The driver advertises `jog_step_limit=100`. HTTP/controller reject larger jogs
before enabling torque; browser checks and Manual Control's step selector use
that limit for direct moves as well as crossings. Normal profiles keep their
existing 500-count limit. This prevents a 500-count commissioning goal being
rejected only after torque has already been enabled.

After exact configuration approval: archive live state, install via recovery
OTA, verify unchanged stationary feedback, begin empty teaching, apply once,
verify snapshots/lock/native feedback, explicitly recover stationary readiness,
then execute one supervised positive 100-count crossing. Stop on wrong direction,
unexpected feedback, lost heartbeat or the short test deadline. Do not resume
after an unexplained fault. Restore the exact factory settings when abandoning
the experiment; do not install normal firmware over an unexplained partial
configuration without resolving its readback first.

Host checks cover exact-profile gates, locked writes, ignored writes, missing
acknowledgements and intermediate rollback, both signed native crossing goals,
hold staging after release, rejection of wrong native turns, manual arc
supervision and worker fault/recovery flow. They are not hardware evidence.
