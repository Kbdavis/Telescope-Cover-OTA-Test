# Controller firmware recovery

## 2026-10-27: development OTA enabled on the new controller

The user-authorized USB bootstrap installed `web_control_dev` on board
`28:05:a5:c2:a9:94` at `192.168.1.43`. Firmware identity:
`9af0d299b0dd24e1a13165403e61469f62f611c3e1ac626b0db4abe4484fdbc5`.
The receiver reports `available=true`, `development=true`, `phase=idle`, and
`startup=accepted`; its challenge endpoint responds successfully. The ten
development OTA tests passed. Private evidence/build artifacts are under
`diagnostics/ota-enable-20261027/`; do not distribute credential-bearing builds.

No OTA transfer was performed. Existing admission checks still require valid
calibration and confirmed CLOSED state. The servo remains at position 2420,
torque OFF, with its phase-12/offset-85 configuration mismatch unresolved.
Enabling controller OTA did not program the servo. Its original configuration
backup remains under `backups/new-servo-20261027T230952Z/`.

## 2026-10-09: torque diagnostics and faulted calibration

Uncalibrated controllers may now accept explicitly chosen safe limits while
faulted after inspection confirmation. The worker verifies model/configuration,
torque OFF and fresh stable position inside the proposed limits. This clears
the commissioning fault without movement or EEPROM changes. Saved calibration
does not use this exception. Open/Close still requires saved valid endpoints.

The guarded diagnostic endpoint `/api/diagnostics/torque-test` requires the
normal token/client and beta acknowledgment plus `supported=yes`. It stages
the current position before enabling torque, then releases after a nominal
750 ms or on feedback failure/deviation. Driver transaction latency can extend
that duration. It finishes in FAULT for explicit inspection before recovery;
it is a supervised diagnostic, not a normal control or automatic retry.

Firmware `da14bc741771573f28aa281dc73b862d1f68182d363f8e28ce097c4c9300f544`
was compiled and uploaded with verified flash hashes. Controller and Calibration
browser tests passed. New logs record servo read error/status codes, torque
acknowledgments and voltage/current/load snapshots.

Passive capture `diagnostics/20261009T222830912880Z/serial.log` repeatedly showed
position 3482, voltage_dV=52 (5.2 V), temperature 32 C, zero load/current and
torque OFF. The authorized torque test was **not sent** because that voltage
conflicts with the intended 12 V supply. Check the external supply and power
path before another powered test. Telemetry does not identify the failed
component or substitute for a voltage measurement. No limits were changed.
Calibration is currently missing; the active 2015–2075 bounds are defaults,
not suitable limits inferred for this mechanism.

The controller reports ESP32-D0WD-V3 revision 3.1 and 4 MB flash. The USB port
for this bench session is `/dev/cu.usbserial-0001`.

For future backups, choose a new filename and capture/verify without letting
application firmware run between commands (do not overwrite today's recovery):

```sh
esptool --chip esp32 --port /dev/cu.usbserial-0001 --baud 115200 --after no-reset-stub \
  read-flash 0 0x400000 backups/new-backup.bin --no-progress
esptool --chip esp32 --port /dev/cu.usbserial-0001 --baud 115200 --before no-reset --after no-reset-stub \
  verify-flash 0 backups/new-backup.bin
```

The `backups/` directory is local and ignored by Git. A full flash image includes
application settings and may include network credentials; keep it private.
The earlier `~/src/esp_flash/merged-firmware.bin` is a separate historical image,
not a verified full backup of today's controller state.

To restore the captured firmware and settings, close serial monitors and run:

```sh
esptool --chip esp32 --port /dev/cu.usbserial-0001 --baud 115200 --after no-reset-stub \
  write-flash 0 backups/controller-recovery-20260930.bin
esptool --chip esp32 --port /dev/cu.usbserial-0001 --baud 115200 --before no-reset --after hard-reset \
  verify-flash 0 backups/controller-recovery-20260930.bin
```

Restoring replaces the controller firmware and settings. Disconnect servo power
while restoring old firmware, then confirm SF mode before reconnecting servo
power. Do not use the old web interface to configure ST3215 mode or range.
The restore procedure is documented but has not been exercised by restoring.

Diagnostic firmware is not a USB-to-servo bridge. Use a 115200-baud serial monitor
to see its logs. It does not update the OLED; any retained display content is
not a reliable indication of the running firmware. Reset to repeat diagnostics.

On 2026-09-30 the original full read completed, but a reboot changed NVS before
verification. Boot and application/filesystem regions matched. The settings
region 0x9000–0xffff was reread while held in the flasher stub and incorporated
into `controller-recovery-20260930.bin`. The complete resulting 4 MB image then
passed esptool digest verification. Its SHA-256 is stored alongside the image.
The original read is also retained. A 460800-baud read failed; 115200 succeeded.

## Diagnosing a crash or disconnect before resetting

See [DEBUGGING.md](DEBUGGING.md) for the timestamped USB capture tool,
firmware health/motion logs, and backtrace decoding with the archived ELF.
Keep capture running before reproducing a failure; opening USB afterward can
itself reset some boards and obscure the original event.

## Startup recovery with missing calibration (2026-10-09)

Startup now reports the failed check: servo communication/model, critical
ST3215 configuration, torque state, stable position, missing calibration or
position outside saved limits. USB diagnostics are optional for normal operation;
a Mac USB connection is not a startup requirement.

Configuration mismatches report the observed and required values directly in
status, for example `phase=12 (need 0); offset=85 (need 0)`. A failed register
read is reported separately, without presenting stale or fabricated values.
Calibration prioritizes this configuration failure over an out-of-range encoder
reading: changing application travel limits cannot repair servo settings.
The initial 2015–2075 range is an unapplied default on an uncalibrated board.
Range-recovery instructions require fresh position feedback and an applied or
saved range; unrelated startup failures retain their own recovery guidance.

Verified on the new controller (2026-10-27): the corrected web firmware reports
`phase=12 (need 0); offset=85 (need 0)` at position 2420, with torque OFF and
motion blocked. Driver/read-only guard, worker recovery, and browser regression
checks passed. This update changes diagnostics and guidance only; servo settings
were not programmed. Local evidence: `diagnostics/servo-config-guidance-20261027/`.

Calibration exposes **Recheck servo** for startup failures even when state is
UNKNOWN or STOPPED. After inspection/support acknowledgment, retry is available
without existing position or torque feedback: the worker obtains and validates
that evidence. Controller freshness, idle state, home-network access and all
maintenance/interlock gates still apply. Startup retry only reads the servo: it never
releases/enables torque, moves, expands limits, restores historical endpoints or
writes servo EEPROM. Existing motion-fault recovery retains its torque-release
behavior; support the cover before using it.

When testing a board without a servo, **Servo not connected** is a dismissible
setup notice, shown once per disconnected period in that browser tab. Its seen
state survives page reloads in session storage; fresh position and torque feedback
rearm it for a later disconnection. Without session storage it lasts until reload.
Configuration and session Debug remain usable. Startup rechecks live in Calibration
instead of keeping fault controls across every page. A real `FAULT` retains the
global inspection/recovery controls and is never cleared by dismissing the notice.

If calibration is missing/invalid but the servo passes model/configuration,
torque-OFF and stable raw-position checks, status reports calibration_only=true,
ready=false. This is a successful recheck requiring calibration, not a failed
recovery. In Calibration, unlock editing and enter mechanically safe minimum
and maximum limits containing the current position. Only Set limits is enabled;
jogs and endpoint capture are blocked until those explicit limits pass fresh
validation. Applying these initial limits initializes manual commissioning without
movement. Jog within those limits, capture both endpoints and save. Automatic
Open/Close remains blocked until valid calibration is saved and verified.

Existing saved limits are never expanded by startup retry. Communication errors,
torque ON, unstable readings and invalid ST3215 configuration cannot enter this
calibration-only path. A failed save leaves endpoint moves disabled.

Verified on hardware after upload: firmware
`8438ec7bc80ef0549ebad00404cc2730c2295b4d3a48a71f67421121366e7e3b`;
NVS load result Missing, position 477, torque OFF, calibration_only=true and
ready=false. Both live pages contained recovery UI. No movement, torque write,
limit change or calibration save was requested during verification. Passive
capture: `diagnostics/20261009T221448009786Z/`. Controller tests verified stationary
initialization rejects invalid configuration, torque ON, unstable reads, motion
and out-of-range positions without servo writes; browser tests verified that
missing calibration exposes Set limits while blocking jog/capture/Open/Close.


## Startup endpoint recognition — 2026-10-17

Successful startup (or retry of incomplete startup) compares two stable readings
with saved OPEN/CLOSED endpoints, using a three-count tolerance. An endpoint
match establishes OPEN or CLOSED; otherwise state remains UNKNOWN. Configuration,
limits, calibration and torque-OFF checks still apply, with no servo writes.
Motion-fault recovery continues to enter UNKNOWN and never resumes a move.

## Current development OTA USB recovery (2026-10-23)

For the development OTA workflow, support the cover and verify torque OFF before
a planned reboot/reflash. Close serial monitors. To return to the current normal
receiver-disabled application, preserving application NVS under the pinned layout:

```sh
pio run -e web_control_usb -t upload --upload-port /dev/cu.usbserial-0001
```

The separate development header is ignored by this environment. This USB path
installs boot/application artifacts for the pinned layout; do not substitute an
old full-flash image or erase flash, which can replace settings. Verify the boot
identity, calibration/settings and physical state after recovery. A failed boot
or lost settings can require inspection/configuration beyond reflashing.

The development bootstrap session preserves its known original normal image,
full inactive-slot backup and native otadata separately under ignored private
`.ota-dev/recovery/`. Restore native otadata only with the matching slot images;
never restore the old combined metadata/NVS backup merely to change boot
selection. Current live settings should be retained. A successful development
OTA keeps both valid application slots for fallback; no cleanup erases the
active candidate or its source slot.

After enabling/saving the NTP feature, application settings use record v6.
Use a fresh build of the current USB firmware for recovery: archived pre-NTP
images only understand the older records and cannot load these application
settings. Calibration is stored separately. Do not restore old NVS merely to
change boot selection. The combined NTP/retained-summary hardware test verified
v5-to-v6 migration and current-image restarts, not a downgrade to an older image.
