# Capturing a disconnect or crash

For the current investigation status, known bugs, deployed fixes and evidence
locations, see [BUG_CONTEXT.md](BUG_CONTEXT.md).

The `web_control` build logs BOOT (reset reason, build timestamp, full ELF SHA),
Wi-Fi association/disconnection events and numeric reason codes, commands,
movement start/end, fault cause, and heartbeat gaps. Every five seconds a
separate diagnostics task prints uptime, free/minimum heap, Wi-Fi status/RSSI,
web-loop age, motion-loop age, and dropped-log count. A bounded queue keeps UART
output out of the motion task; overload drops logs instead of blocking motion.
No new movement, recovery, watchdog, or travel-limit behavior is introduced.
Status JSON also exposes uptime, reset reason, firmware ELF identity and heap.

## OTA resource baseline

The [OTA and WiFi diagnostics implementation plan](OTA_IMPLEMENTATION_PLAN.md)
defines shared event logging, remote capture, update exclusion and recovery.
The metrics, shared event path and read-only WiFi capture are implemented
locally. Maintenance arbitration and the OTA receiver remain future work.

The production builds (`web_control`, `web_control_usb`, `web_control_ota`) now
add a `resources` object to GET `/api/status`. Existing status fields are kept.
Optional collection is OFF at boot. Enable the Debug tab, then explicitly expand
**Controller metrics** to start it. Collapsing the section, leaving Debug,
hiding/closing the page or disabling Debug releases that viewer. Reopening is
always explicit; no preference restores an open panel after reload or reboot.

For immediate access, choose **Configuration → Troubleshooting & recovery →
Open Debug for this session**. It opens Debug without saving or restarting and
works with an open cover or unavailable servo. The per-tab selection survives
reloads when session storage is available; **End session Debug** or closing the
tab ends it. **Always show Debug tab** remains a separate saved preference.

The inactive descriptor contains only `state`, `available`, `viewers`, `epoch`
and the public `boot_id`. Status reads never start or renew collection. While
active, status returns the shared cached snapshot; it never performs heap walks
or stack scans in the HTTP handler. `age_ms` is the cached snapshot's age, and
`sampled_at_ms` is its controller uptime. All memory/stack values below are bytes:

| Field inside `resources` | Meaning |
| --- | --- |
| `sampled_at_ms` | Controller uptime at the end of the resource snapshot |
| `internal_free_heap_bytes` | Free memory with both INTERNAL and 8BIT capabilities |
| `internal_min_free_heap_bytes` | Sum of the per-region lifetime minima for that memory class; these minima may have occurred at different times |
| `internal_largest_free_block_bytes` | Largest single allocation currently available in that memory class |
| `debug_log_available` | Whether storage for the configured controller log was allocated |
| `debug_log_capacity` | Requested controller log capacity; production now uses 20 messages (2,560 bytes of entries, plus allocation/pointer overhead) |
| `task_stacks` | `web`, `cover`, `alpaca`, `diagnostics`, and `ota` stack samples; OTA is null when no worker exists |
| `ring_overwrites`, `log_truncated`, `suppressed_trace` | Cached event-loss/detail counters from the shared publisher |

During an active subscription, each task samples its own stack at most once
every five seconds. A stack entry
contains `min_free_bytes` (the lifetime low-water mark of unused stack) and
`sample_age_ms`. The installed ESP-IDF FreeRTOS API reports bytes directly.
An entry is `null` until that task samples; the Alpaca entry remains `null` when
monitoring is disabled or its worker could not start. Check configuration and
sample age before interpreting missing/stale data. Self-sampling avoids keeping
handles to deleted tasks.

Baseline five-second serial HEALTH records continue independently. Optional
METRICS records contain internal memory and log fields; separate STACK records
contain task names, byte counts and sample ages only while metrics are active.
A serial
`min_free_bytes=-1` means no sample is available. These diagnostics establish
baseline evidence; they do not enforce an OTA memory threshold or enable OTA.

After a separately supervised USB installation with the cover mechanically
supported and torque OFF:

1. Match the running `firmware_id` to the installed build. Preserve its binaries
   and serial log using the capture instructions below; select
   `--build-dir .pio/build/web_control_usb` when that is the installed environment.
2. First record ordinary status/serial with Controller metrics collapsed, then
   explicitly expand it and record resources while status/debug polling and
   configured Alpaca monitoring run. Compare closed and expanded overhead. Confirm
   all expected tasks sample,
   `debug_log_available=true`, and capacity 20. Exercise the full log ring;
   its storage is allocated at startup, so filling it should not allocate more
   controller log memory. No movement is needed for this measurement.
3. Save representative status JSON plus the worst observed internal free heap,
   minimum heap, largest block, and each task's minimum free stack. Include
   workload, firmware identity, observation duration and missing samples.
4. Repeat these measurements once the receiver and its buffers/task exist.
   Choose an OTA admission reserve from measured peak usage then; this baseline
   alone cannot establish receiver memory requirements or update reliability.

The local build checks validate the generated partition table (including NVS
offset/size and both application slots) against the frozen layout and compare
the actual `.bin` length with each slot. They can be repeated offline:

```sh
python3 tools/check_firmware.py .pio/build/web_control_usb
python3 -m unittest discover -s tests/tools -p '*_test.py'
```

These checks are size/layout checks, not image authentication or compatibility
validation. The local table is not a readback of the deployed controller.

## CPU load on the Debug page

**Current implementation:** the default-collapsed Controller metrics section
controls actual controller collection. Four fixed subscription slots share one
sampler. Authenticated STA-only subscribe/renew/unsubscribe requests carry the
public boot ID, browser client and monotonically increasing generation. Leases
expire after five seconds and renew no more often than every two seconds using
the existing browser service loop. A dropped close therefore stops collection
when its lease expires; closing one viewer does not stop another active viewer.

The last release disables and removes the CPU timer interrupt, releases the
timer, prevents new stack scans, waits for any in-progress scan, and invalidates
the cached snapshot. The controller reports `off` only after cleanup; a pending
or failed cleanup remains `stopping`. Failed initialization reports
`unavailable` after cleanup and requires an explicit close/reopen to retry.
Reopening uses a new CPU baseline and stack-sampling epoch. Delayed starts and
closes cannot revive closed generations or cancel newer generations. Rejected
renewal, expiry, loss of fresh status and reboot collapse the panel and never
automatically resubscribe. These requests issue no motion, settings or OTA
commands. Existing motion supervision is unchanged.

With zero viewers, only minimal lease/state checks remain in existing loops:
there is no optional CPU timer, heap walk, stack scan, CPU calculation, metric
history or periodic metric output. Ordinary operational diagnostics, basic
status fields and the existing event log remain available. Hardware validation
of timer teardown, timing impact and stack/memory margins is still pending.

The Debug page shows estimated non-idle task occupancy for Core 0, Core 1 and
their average. Each core is 0–100%; one fully busy core and one idle core give
a 50% average. Values arrive in `resources.cpu_load` through existing status
requests; collection adds only the explicit subscription and bounded renewals,
with no separate metrics polling timer or per-sample log entries. Additional
viewers do not increase the shared sampling rate. All optional values, including
CPU, heap, stack, log counters and existing network/loop readings, appear inside
the same disclosure.

The pinned framework does not enable task runtime statistics. Diagnostics
instead reserves general-purpose timer group 1 / timer 1, with a 4,093 µs
period (approximately 244 samples/second). Its IRAM interrupt callback compares
the running task on each core with that core's idle task and updates lock-free
counters. It does no logging, allocation, servo I/O, task enumeration or
scheduler suspension. The timer period is independent of the 1 ms RTOS tick to
reduce synchronization with periodic tasks. No new RTOS task is created.

The diagnostics task publishes approximately one-second observation windows.
Startup, failed timer initialization, fewer than 100 observations, or windows
longer than five seconds are unavailable. The browser also hides samples older
than five seconds or from stale controller status. Older firmware without the
field displays Unavailable. A sample is an occupancy estimate, not calibrated
CPU utilization or precise accounting of interrupt work and flash stalls.
It must never grant motion or OTA clearance. Measure timing/heap impact and
compare idle/controlled-workload results during a supported bench session;
desktop tests do not establish hardware accuracy or interrupt overhead.

Offline checks:

```sh
c++ -std=c++11 -Wall -Wextra -Werror -Isrc tests/host/cpu_load_test.cpp -o /tmp/cover-cpu-load-test
/tmp/cover-cpu-load-test
node tests/web/debug_cpu_test.cjs
c++ -std=c++11 -Wall -Wextra -Werror -Isrc tests/host/metrics_session_test.cpp -o /tmp/cover-metrics-test
/tmp/cover-metrics-test
node tests/web/metrics_test.cjs
```

## Capture

After building and uploading `web_control`, close other serial monitors and run:

```sh
~/.platformio/penv/bin/python tools/capture_diagnostics.py
```

Keep it running throughout supervised tests. Ctrl-C ends capture. Add
`--duration 60` for a one-minute capture. The tool listens at 115200 baud,
sends no serial commands, and sets DTR/RTS false before opening. USB drivers
can nevertheless cause a reset on open/reconnect; these events are marked in
the log. It retries disconnected USB ports every second. It does not flash,
reset deliberately, clear faults, or command movement.

Each run creates an ignored `diagnostics/<UTC timestamp>/` directory containing:

- `serial.log`: UTC-timestamped logs, including panic/backtrace text; known
  password fields are redacted.
- `firmware.elf` and `firmware.bin`: copies of the selected local build before
  capture starts.
- `manifest.json`: artifact SHA-256 hashes and capture settings.

Compare the BOOT `elf_sha256` (or status `firmware_id`) with the manifest's ELF
hash. A mismatch means the archived build is not the running firmware. Preserve
this directory before rebuilding. Firmware artifacts contain compiled Wi-Fi
credentials; keep them local. Redaction is not a general secret scanner.

## Read-only WiFi capture

After a separately supervised installation of firmware with package 1B, use the
controller's home-network address. USB remains the default capture tool above.

```sh
python3 tools/capture_wifi_diagnostics.py --host telescope-cover.local --duration 60
```

Optionally add `--build-dir .pio/build/web_control_usb` to archive the selected
local ELF/bin before capture. Without it, firmware matching stays unknown;
selecting a build does not establish a match. The manifest compares each
reported ELF identity with the archived ELF SHA-256 and records true/false/null
separately from the binary hash. Resume a folder with
`--host telescope-cover.local --resume diagnostics/<UTC-folder>`; the saved
origin and archived hashes must still agree. Resume preserves the cursor.

The ignored capture folder contains `events.jsonl`, `manifest.json` and
`cursor.json`, plus optional local binary archives. JSON Lines include host UTC,
event uptime (`ms`), boot/sequence identity, loss metadata, gap/reconnect markers
and snapshots. Cursor/manifest writes are atomic; events are flushed before
cursor advancement. Binary archives remain sensitive local files; text
redaction does not sanitize firmware. Known password/token/verifier/authorization
and credential labels are redacted in text, including shared USB helpers.

The client uses only allowlisted GET `/api/debug`, `/api/status` and
`/api/ota/status` requests. It requests no web session, auth headers, actuator
commands, settings writes, OTA admission or metrics subscriptions. Redirects
and environment proxies are disabled. Response bodies and socket waits are
bounded; request failures back off from one to at most 30 seconds and leave the
controller unchanged. Busy responses honor bounded retry guidance. Successful
reconnects resume the last saved cursor; new boot IDs/sequence epochs start new
segments. A reboot between event and resource responses records a gap instead
of attributing the snapshot to the previous boot.

One event batch per second is the maximum capture cadence. Resource snapshots
are fetched at most every five seconds, only when the event envelope reports
that a browser explicitly enabled metrics. GET requests never renew the panel
lease. Without an open metrics panel, capture keeps recording events and the
inactive state. Lightweight OTA snapshots are read every five seconds; during
a reported transfer bulk draining pauses and only OTA status is checked, at
most once per second. The current OTA snapshot is explicitly unavailable: this
package implements no receiver or upload capability.

### Event endpoint and budgets

GET `/api/debug?after=0` keeps `entries`, `firmware`, `available` and `capacity`
for existing readers. Schema 1 adds `boot_id`, `sequence_epoch`,
`oldest_sequence`, `newest_sequence`, `cursor_reset`, `gap`, `next_after`, `more`,
`metrics_active` and `loss`. New readers send the observed `boot_id` and
`sequence_epoch` with the next `after` cursor. Responses reset a stale boot,
epoch or future cursor, and advance only across returned entries. Reading never
consumes another reader's entries. At 32-bit sequence rollover the ring starts
an empty new sequence epoch at 1; discarded entries count as overwrites.

Both serial and the existing ring receive each selected event through one
publisher. BOOT/reset identity, WiFi transitions/local changes, startup and task
allocation failures, command/movement lifecycle and existing servo/Alpaca
fault events are shared. Heartbeat traces, periodic WiFi signal/health and normal
servo telemetry remain serial details. There is no recursive publishing from
serial forwarding or HTTP reads. `loss` reports cumulative 32-bit counters:
`ring_overwrites`, `serial_dropped`, `truncated`, and `suppressed_trace` (serial-only
publisher records deliberately omitted from the ring). Entries report their
own `truncated` flag. Displayed counters remain inside Controller metrics.

The controller ring holds 20 entries of 128 bytes each, including a compact
event-time epoch timestamp. The browser retains its separate 1,000-group history. A response contains
at most 16 entries and 4,096 serialized body bytes, including metadata and JSON
escaping. One temporary 4,097-byte formatting buffer is allocated only for an
admitted request; no second event ring or task exists. Formatting and HTTP I/O
happen outside the short per-entry ring lock. All readers share two admitted
responses per one-second budget window (at most 8 KiB of log bodies per window).
Busy or moving/holding controllers return 503 with `Retry-After: 1`; detailed
logs and OTA downloads return 403 on the setup AP, and optional resource values
are omitted there. These limits do not establish a measured Stop latency.
`/api/status.ota` and GET `/api/ota/status` share the same redacted snapshot,
including boot/firmware identity, startup acceptance and durable update outcome.
Receiver availability remains false until the OTA release gates are opened.

Offline verification:

```sh
python3 -m unittest discover -s tests/tools -p '*_test.py'
c++ -std=c++17 -Wall -Wextra -Werror -Itests/host/diagnostics_shim -Isrc tests/host/diagnostics_test.cpp -o /tmp/cover-diagnostics-test
/tmp/cover-diagnostics-test
```

The tests exercise the actual publisher and OFF acquisition gates using counted
platform stubs, plus real JSON serialization/size limits and mocked HTTP capture
failures. They do not establish on-device timing, RF reliability or OTA recovery.
Keep USB capture for the later supported-device workload measurements.

## Maintenance arbitration checks

The [package-2 contract](OTA_IMPLEMENTATION_PLAN.md#implemented-maintenance-contract-package-2)
explains typed owner leases, control generations, request-boundary telemetry
pauses and supported-cover/OFF admission. Status reports the maintenance owner,
phase, reason and lease generation separately from `control_generation`.
Explicit/legacy Stop remains unconditional; stale automatic cleanup is rejected.
The receiver and authenticated prepare/cancel endpoints are implemented but
release-gated; no memory reserve is selected without receiver workload measurements.

Local checks use the real servo-worker loop with counted hardware/platform fakes:

```sh
c++ -std=c++11 -Wall -Wextra -Werror -Isrc tests/host/maintenance_test.cpp -o /tmp/cover-maintenance-test
/tmp/cover-maintenance-test
c++ -std=c++17 -Wall -Wextra -Werror -Itests/host/diagnostics_shim -Isrc tests/host/maintenance_integration_test.cpp src/cover_controller.cpp src/emergency_shutdown.cpp src/alpaca_client.cpp -o /tmp/cover-maintenance-integration-test
/tmp/cover-maintenance-integration-test
node tests/web/control_generation_test.cjs
```

The worker tests cover queued movement at reservation, every normal command
class while locked, matched release, pause acknowledgments, pre/post-clearance
Stop, failed stationary validation, network loss during cleanup and expired
clearance. UI tests include the existing full/configuration browser suites and
`tests/web/maintenance_browser_test.cjs` against the local fixture. These checks
leave the controller untouched; timing under real servo, RF and flash workloads
remains a supported-device release gate.

## Interpreting a failure

- Continuing HEALTH lines with increasing uptime mean the logging task remains
  alive. A growing `web_gap_ms` with a small `motion_gap_ms` points to a stalled
  web loop. Wi-Fi disconnect events without a boot suggest network loss.
- A panic/backtrace followed by BOOT indicates a crash. Reset reasons PANIC,
  TASK_WATCHDOG, INTERRUPT_WATCHDOG, and BROWNOUT narrow the investigation.
- A new POWERON boot without a panic does not prove a software crash. Check
  supply, cables, manual resets, and capture open/reconnect markers.
- No serial output alone is inconclusive: power loss, USB failure, a full-system
  hang, or blocked UART output can all cause silence.
- A sustained drop in minimum heap is evidence to investigate, not proof of a
  memory leak. Positive `log_dropped` means some diagnostic records were lost.

Decode program-counter addresses from a panic using the archived ELF:

```sh
~/.platformio/packages/toolchain-xtensa-esp32/bin/xtensa-esp32-elf-addr2line \
  -pfiaC -e diagnostics/<capture>/firmware.elf 0x40081234
```

Substitute actual program-counter addresses from `Backtrace:`; stack-pointer
addresses after the colons are not code locations. The toolchain needs the
exact matching ELF. Start with idle observation, then individual supervised
moves; do not deliberately cause an obstruction or unattended movement.

## Correlating a heartbeat failure

Reload the live page after this diagnostic build is uploaded. Every heartbeat
has a browser request sequence (`seq`) plus client ID. The browser records
monotonic send/finish times, round-trip duration, timer delays, skipped timer
callbacks while a heartbeat is in flight, status-request timing/errors, and
visibility/blur/stop events. Timing summaries ride on the existing heartbeat
POST; instrumentation adds no extra HTTP requests or heartbeat renewals.

USB logs include:

- `HB HTTP`: parsed request handling time `rx_ms`, client/sequence, queue success,
  and browser timing summaries. `b_ms` is browser monotonic time, `send_gap` is
  time between heartbeat sends, `timer_gap` the latest timer interval, `skipped`
  the number of callbacks waiting for the previous response, `prev_rtt` the
  preceding completed heartbeat duration, and `status_age` time since a valid
  status result.
- `HB WORK`: same client/sequence, queue age, current owner, whether it renewed
  the lease, previous heartbeat age, and controller state. Expired commands
  include their client/sequence. Queueing success does not imply renewal.
- `WEB LOOP` / `MOTION LOOP`: completed loop gaps of at least 100 ms. Existing
  HEALTH records can reveal a loop that remains blocked; brief gaps between
  five-second health records are now logged too.

Match client/sequence across browser and USB records. Large browser timer gaps
suggest scheduling delays. Large send gaps with skipped callbacks and long
round trips indicate waiting on HTTP. Requests processed promptly by HTTP but
late in the worker indicate queue/worker delay. Regular browser sends followed
by delayed HTTP handling narrow the issue to network or server handling; this
instrumentation cannot distinguish RF packet loss from TCP retransmission
without a network packet capture. HTTP timestamps are after request parsing,
not radio arrival. Browser and ESP32 clocks have different origins: compare
intervals and sequences, not absolute timestamps between clocks.

The Connection diagnostics section keeps a bounded 200-event ring and freezes
the first failure snapshot. After a failure, **do not reload that tab**: select
**Download browser trace** there. The export includes the frozen snapshot and
recent events. If the network is unavailable the trace stays in browser memory
and can still be downloaded. Reloading discards it. The export includes no
page token or Wi-Fi credentials. Keep the USB capture running and save the
browser JSON alongside its capture folder for analysis.

Per-heartbeat logging is temporary diagnostic instrumentation. Monitor
`log_dropped`; a nonzero count means gaps may be lost records. Logging stays
queued and bounded; the 500-ms lease and motion behavior are unchanged.

The first continuous capture also recorded a later Wi-Fi disconnection
(reason 8 at uptime 286685 ms) and lost-IP event at 406686 ms, while both loop
ages remained around 1–2 ms and heap was stable. No reboot or panic accompanied
that outage. This is separate from the preceding heartbeat fault at 130098 ms;
the later network event does not by itself explain the earlier heartbeat gap.
The original evidence remains in the locally ignored
`diagnostics/20261001T183454666661Z/` capture folder.

## Correlated failure: client 86117353, generation 79

The browser export is preserved beside `20261001T184441027593Z/serial.log`.
Heartbeat 1089 was sent at browser time 230901 ms and completed at 231311 ms
(410 ms round trip). Timer callbacks at 231003, 231104, 231204 and 231305 ms
skipped sending because it was still in flight. The next request, 1090, was not
sent until 231406 ms: 95 ms after completion and 505 ms after the previous send.
The page remained visible, with regular timer callbacks.

The ESP32 handled 1089 at uptime 280445 ms and the worker renewed at 280449 ms
(queue age 4 ms). It faulted at 280947 ms with heartbeat age 501 ms. Heartbeat
1090 reached the HTTP handler at 280977 ms, 532 ms after 1089; the worker handled
it 5 ms later and correctly did not renew the now-faulted controller. There was
no recorded web-loop stall at that moment. This identifies response-gated browser
scheduling plus transport latency, rather than a worker backlog or hidden tab.
It does not establish which network component caused the long round trip.

The page now schedules an immediate send after a successful slow response if
100 ms have already elapsed since its send, instead of waiting for the next
100-ms interval tick. There is still at most one heartbeat request in flight.
Failure, Stop, and generation guards remain; the 500-ms firmware lease is
unchanged. Regression coverage replays the 410-ms response and confirms the
immediate send and suppression after Stop. Delays exceeding the watchdog can
still fault correctly; this removes avoidable browser delay, not network loss.

The heartbeat diagnostic body also no longer starts with an empty `&` field,
which was generating `_parseArguments(): arg missing value: 0` UART messages.
Wi-Fi disconnected later at uptime 302520 ms, approximately 22 seconds after the
fault; health logging continued. That later outage is separate from this
heartbeat deadline miss. The scheduling/body fixes passed local tests and were uploaded with the expanded
Wi-Fi diagnostics. Supervised physical retesting remains pending.

## Investigating the original Wi-Fi disconnect

Additional queued diagnostics record:

- `WIFI LINK` once per second while associated: BSSID, channel, RSSI, mode,
  power saving and Arduino auto-reconnect setting. No scan is performed.
- `WIFI DISCONNECT`: driver reason number/name, BSSID, driver-provided RSSI at
  disconnect, previous sampled RSSI and its age, association duration. A sample
  marked invalid has no prior signal measurement; zero is not valid RSSI.
- `WIFI EVENT`: named events, including STA start/stop, association, authentication
  changes, DHCP/IP loss and setup-AP events. IP acquisition includes address,
  gateway and netmask; SSIDs and credentials are not recorded by these logs.
- `WIFI LOCAL`: markers immediately before each application-controlled mode,
  modem-sleep, STA-start and fallback-AP change. Events include the most recent
  marker and its age; temporal proximity alone does not prove causation.

Compare the disconnect's BSSID and signal history with the preceding events and
local-operation markers. An association with a different BSSID/channel can
indicate a changed AP connection. A driver/library-internal operation is not an
application marker. `ASSOC_LEAVE` alone does not tell us which device originated
the frame. This SDK's disconnect event has no frame source/local-origin flag;
router logs or an external 802.11 management-frame capture may still be necessary
for conclusive attribution. Do not enable promiscuous capture or scans on the
motion controller as part of these passive diagnostics. Reconnect and motion
policies are unchanged by this instrumentation.


## Retained motion trace (2026-10-21)

GET `/api/motion/trace` returns the most recent accepted move's operation number,
target/tolerance, last successful position/time, successful/failed read counts,
settling count, and up to 64 chronological raw feedback samples. Samples are
retained at most every 100 ms from the existing control reads; failures carry a
null position and never count as position zero. Counters include all control
reads. This retains approximately the last 6.4 seconds on longer moves.
Fault/Stop/idle/recovery do not erase evidence; a new accepted move or reboot does.
The ring is RAM-only and introduces no extra servo queries or EEPROM writes.
The read-only endpoint does not command motion. Existing fault/settling safety
checks, the three-count endpoint tolerance and five-second saved timeout remain
unchanged. USB fault records now include last valid error, read counts and
settling progress. Save the trace before another move or reboot.

For the next supervised close, inspect the mechanism and use the normal UI.
After completion or fault, read `/api/motion/trace` before retrying. A plateau
near 497 for target 493 can then be distinguished from slow motion, drift, or
failed feedback. Servo-only tests do not validate physical cover closure.

Motion-trace firmware deployed over USB and identity verified: `3970aca636ec5606d7035507173e42ae40ea790ac3c8502a616b59b81ad1d0c6`. Controller tests passed including the four-count plateau, bounded ring, failed reads and trace retention. Saved calibration/profile unchanged. Post-upload trace endpoint responded correctly; no physical move was commanded. Evidence: `diagnostics/upload-20261021-motion-trace/`. Supervised physical close capture remains pending.


## Live UI heartbeat instrumentation — 2026-10-21

The live UI now sends browser monotonic send time, generation, send/timer gaps,
skipped timer count, previous round-trip duration and status age on existing
heartbeat requests. A bounded 200-event browser ring records sends/responses,
errors, status request duration, Stop, blur, visibility and pagehide events.
The first observed fault/request failure freezes a copy; subsequent events
continue in the ring. Recent activity → Download heartbeat trace saves both
without tokens, settings, credentials or response bodies. Download before
reloading: the browser trace exists only in that tab's memory.

GET `/api/heartbeat/trace` returns the last 64 HTTP receipt records, including
client/sequence, queued result and browser timing fields. It also exposes the
worker heartbeat snapshot captured immediately when supervision faults, before
late queued requests can overwrite it, and the fault timestamp/heartbeat age.
Worker receipt/processing times distinguish queue delay from late HTTP arrival;
browser timing helps distinguish timer delays from response-gated scheduling.
Compare elapsed times across clock domains, not absolute browser/ESP32 times.
No additional requests, renewals, retries, threshold or scheduling changes were
introduced. The 500-ms supervision lease and 700-ms browser request timeout are
unchanged. These diagnostics may expose the existing response-wait behavior;
they deliberately do not mask it. The HTTP ring survives idle but is overwritten
by later heartbeats and cleared by reboot; the worker fault snapshot resets on
the next accepted movement. Retrieve both traces before another test.

Heartbeat instrumentation deployed and HTTP identity verified: `3eaa24cd9221db5ede8177807e8cff6eb8a913fe83e63e2cd6e44c1b8e03b1bd`. Build, controller safety tests and browser suite passed, including delayed-heartbeat skipped-timer fields, bounded JSON export and token exclusion. Calibration/profile unchanged; post-upload state UNKNOWN at 502, stationary with torque OFF. Read-only trace endpoint and served download button verified. No movement requested. Evidence: `diagnostics/upload-20261021-heartbeat/`.


## Endpoint settling correction — 2026-10-21

The captured operation 6 reached encoder 497 at 1974 ms for target 493 and
remained at 497 through 4982 ms before the five-second timeout. All 97 reads
succeeded; heartbeat age at fault was 53 ms. Evidence is preserved in
`diagnostics/heartbeat-fault-20261021/` (browser, controller and motion traces).

Endpoint acceptance is now +/-5 counts, shared across runtime settling, startup
classification and endpoint evidence. Movement completion requires five
consecutive valid in-band readings with no more than three counts of total
spread; leaving the band, excessive spread or a failed read resets progress.
The endpoint separation requirement is now more than ten counts so acceptance
bands cannot overlap. Firmware validation and calibration UI use the new gap.
Fine-jog tolerance, mechanical limits, timeout, heartbeat supervision, EEPROM,
and saved endpoint values are unchanged. Tests cover both directions and band
edges, the measured four-count offset, rejection of six counts, traversing the
band, failed-read reset, startup classification and calibration band separation.
Encoder completion is not physical closure proof; validate seating with the
real cover attached before trusting weather protection.

Settling correction uploaded; flash verification and running ELF identity matched `ced01d6d04cf749ca0d1f2a88f354602062e5c88e4719d4f7ff036b4fe073020`. Controller/settings regression tests passed. Saved endpoints and profiles were preserved. Post-upload status: {'state': 'CLOSED', 'position': 497, 'moving': False, 'torque': False}. No movement commands sent; physical close retest remains pending. Evidence: `diagnostics/upload-20261021-settling/`.


### Repeated messages on the Debug page

The browser groups consecutive messages with identical source, severity, and
text into one row. The row retains the first timestamp and updates the repeat
count and last timestamp, including across download batches. For example,
“repeated 4 more times (5 total; last uptime 12.000s)” means five occurrences.
A different event starts a new row; level filtering does not merge separated
runs. Both browser and controller messages use this display behavior.

Browser request failures appear immediately and remain throttled to one recorded
failure per endpoint every five seconds during an outage. Recovery updates the
failure row with “Communication recovered at …” instead of adding a second row.
Consecutive failures with the same endpoint and cause share the existing repeat
counter, even across recovery cycles; a new outage clears the previous recovery
text. Counts represent recorded failures, excluding attempts suppressed by the
five-second throttle. Different causes or intervening events start new groups.

The browser retains up to 1,000 groups. Controller ring storage, sequence cursors,
overwrite reporting, raw capture, and serial output are unchanged. The display
counts only messages received by this browser; overwritten controller entries
cannot be included. Reload clears the browser groups.


### Local debug server

Run `python3 tools/debug_server.py`, then open http://127.0.0.1:8083/#debug.
Use `--port 8084` to choose another port. The server binds only to localhost and
serves the current UI with the existing simulated controller fixture. Debug is
visible immediately, and a banner identifies the simulation. It never contacts
the ESP32 or telescope. All settings and movement operations are simulated.

Sample events arrive once per second: ten identical warnings, four identical
recovery messages, then an error. This repeating cycle demonstrates repeat counts,
severity filters, first/latest timestamps, and polling across batches. Open the
metrics panel to inspect simulated CPU and memory readings. Refresh the browser
after editing UI assets. Stop with Ctrl+C; restarting resets simulated settings.


### Wi-Fi diagnostics in Controller metrics

The Wi-Fi section reports passive counters since boot: disconnect events, successful
reconnections with an IP address, last reason name/code and uptime, current outage,
last completed outage, current RSSI, and the lowest valid RSSI sampled since boot.
Repeated disconnect notifications update the reason but do not restart the outage
clock. Initial IP acquisition is not a reconnection. Intentional configuration
changes and failed association attempts can generate disconnect events too.
An outage begins at the first disconnect notification and ends at IP acquisition;
initial startup time before a disconnect notification is not included. Durations
use the 32-bit millisecond clock and assume outages shorter than its rollover period.

Existing Wi-Fi events and one-second signal sampling update bounded counters even
with the metrics panel closed. The optional metrics collector publishes a snapshot
at most once per second; stale or missing snapshots display Unavailable. Counts
saturate at the maximum 32-bit unsigned value and reset at controller restart.

Alpaca counters record completed monitoring request attempts after initiating TCP
connection: attempts, failures, timeouts (a subset of failures), and last/maximum
elapsed time. Failures include HTTP, parsing, unsupported responses, and driver
errors; they are not radio packet loss. Offline checks and rejected commands that
never attempt TCP are excluded. Native Seestar operations are not included.

Packet loss and radio retries are explicitly unavailable. The installed ESP32 SDK
has `esp_wifi_statis_dump`, but this implementation does not parse console dumps or
use undocumented counters. No pings, packet captures, retries, or new network probes
are added. See Espressif's [Wi-Fi event and disconnect reason documentation](https://docs.espressif.com/projects/esp-idf/en/release-v4.4/esp32/api-guides/wifi.html).

The local debug server shows illustrative Wi-Fi and Alpaca counters with the
simulation banner. Run `node tests/web/wifi_metrics_test.cjs` and the host test
`tests/host/wifi_diagnostics_test.cpp` for rendering and counter behavior.

## OTA resource-only USB experiment

`web_control_ota_resources` is a temporary USB-only test profile. It starts the
8,192-byte OTA owner task, but unconditionally rejects admission and skips the
transfer queue. There is no update listener, invitation, journal transaction or
SDK transfer/flash operation from the probe. Normal startup still validates its
boot metadata as in other USB images. The embedded `test_profile` descriptor is
incompatible with production OTA validation. No OTA secret or nonzero admission
reserve is needed. Restore `web_control_usb` after the experiment.

With metrics OFF, the worker is idle: no synthetic bytes, digests, stack scan or
probe log is produced. During an explicit metrics lease, accepted startup and
stationary/calibrated torque-OFF status on pure STA allow one 64-KiB
synthetic digest/staging pass per five seconds. Both digests have fixed test
vectors. The real stream prefix validator writes to a digest-only backend; these
bytes are **not a native flashable image**. Metrics epoch change
or physical/network precondition loss aborts the pass. Metrics cleanup waits
for in-flight work and its crypto resources before acknowledging OFF.

The Debug disclosure now displays OTA stack headroom. Sampling uses the same
self-scan, five-second cadence and epoch gating as the other tasks. It reports
Unavailable in the normal receiver-disabled build. The test task has the
production stack allocation, but the synthetic call path differs from a real
transfer. Neither its headroom nor its memory cost certifies the network/flash
path, SDK handle allocations, erase stalls, authentication allocation, commit
or rollback.

After supervised USB installation with the cover supported and torque OFF:

```sh
python3 tools/measure_ota_resources.py --host 192.168.1.135 \
  --build-dir .pio/build/web_control_ota_resources --probe \
  --duration 30 --off-duration 8 --output diagnostics/ota-resource-probe
```

Use the actual literal STA address. After restoring normal firmware, repeat
without `--probe`, selecting `.pio/build/web_control_usb`, for a paired workload
observation. The tool checks image/boot identity, accepted startup, no motion,
verified OFF torque, 20-entry log allocation and exclusive viewer access. It
explicitly subscribes only during the measured window, renews its own lease,
reads bounded status/events/Alpaca snapshots, then unsubscribes and verifies OFF.
It sends no actuator, settings or OTA-control requests and never acts as a
motion supervisor. Other viewers are not closed. A lost subscription response
still triggers cleanup; a disconnected/lost lease expires after five seconds.

Evidence folders are private and include matching local artifacts, timestamped
JSON samples and a summary. Session credentials are held in memory and excluded
from evidence. Compiled images can contain local WiFi credentials and must stay
private. Do not change telescope monitoring merely to fill a missing stack
sample; record the actual workload. Full-workload and flash-path measurements
remain necessary before choosing admission reserves.

## Nonactivating OTA flash experiment

`web_control_ota_flash_probe` is a supervised USB test image, with an incompatible
`test_profile` descriptor and production OTA admission forcibly disabled. It
permits one authenticated test preparation per boot through
`/api/ota/probe/challenge`, `/prepare` and `/cancel`. The normal canonical
manifest, boot-bound HMAC and espota authentication still apply. Only app0 may
run this experiment, with app0 still selected and app1 originally erased. The
device checks the target prefix; the operator must first back up and verify the
**entire** inactive slot as erased. Preserve current native boot metadata too.

An owner-only, untracked `ota_flash_probe_local.h` must supply a unique
`COVER_OTA_PROBE_SECRET` (32–128 printable non-space characters) and explicit
nonzero `COVER_OTA_PROBE_MIN_HEAP` / `COVER_OTA_PROBE_MIN_BLOCK`. Without them,
the test remains unavailable. Keep this header outside the repository and use
an isolated build directory. Never pass the credential in an argument or print
it. The initial experiment used 131,072/65,536-byte abort floors; these are
experimental limits, **not approved production reserves**.

The worker uses the real UDP/TCP transport, streaming hashes and SDK
begin/write/end on app1. Boot selection, transaction-journal writes and restart
are compiled out of this transfer branch. The distinct final reply is `NOACT`,
never the normal selection acknowledgement. Verify the resulting image by USB
readback, and compare native boot-selection metadata before and after. No
activation or rollback reliability is established by this experiment.

After a supported-cover, torque-OFF preflight and USB installation:

```sh
python3 tools/probe_ota_flash.py --host 192.168.1.135 \
  --build-dir /path/to/frozen-production-build \
  --probe-build-dir /path/to/frozen-test-build \
  --blank-slot-backup /path/to/current-erased-app1.bin \
  --secret-file /path/to/owner-only-secret --supported-cover-off \
  --output diagnostics/ota-flash-probe
```

The tool pins both transports to the same local interface, subscribes explicitly
to metrics, reads at most one root snapshot per second, and renews its own lease.
It fetches no bulk logs during transfer. It checks boot/image identity and
stationary OFF conditions throughout, then verifies cleanup and metrics OFF.
`VERIFIED_NOT_ACTIVATED` is the only success classification. Failures never
trigger automatic image retries; cancellation is attempted only for the original
active transaction. Preserve private failure evidence, restore the original
inactive slot, and install normal USB firmware before retiring the test secret.
Keep matching binaries private because they contain the temporary credential.

### Test-only allocation boundary recorder

`web_control_ota_memory_probe` extends the nonactivating flash experiment with
`COVER_OTA_MEMORY_PROBE`. It preserves the same private configuration,
experimental floors, one-shot preparation and activation exclusion. A build
without private configuration cannot arm. The first hardware run on 2026-10-23
aborted safely at the unchanged heap floor; see the
[instrumented results](OTA_IMPLEMENTATION_PLAN.md#first-instrumented-hardware-run-2026-10-23).
The subsequent freeze-at-transfer-exit correction has local validation only.

Pass `--memory-evidence` to `tools/probe_ota_flash.py` when using this profile.
After success or attempted cancellation, the tool stops its observer and fetches
`/api/ota/probe/memory` before unsubscribing. This endpoint accepts only a
completed prepared test on home WiFi; it refuses reporting while the owner is
active. The host requires the original boot and collection epoch, validates
bounded numeric rows and records only defined fields. Lost/unavailable failure
evidence is recorded without preventing viewer cleanup. No additional evidence
polls or per-write log messages are sent during transfer.

The recorder keeps fixed 484-byte evidence storage plus test-only synchronization
state. It observes internal free heap and largest free block at these boundaries:

- Before HTTP dispatch with the input arena live, then after freeing it.
- At root-status entry, after JSON construction and after sending (JSON still
  live at the final sample); completed response byte length is included.
- After TCP connection, and immediately before/after SDK begin, each write and
  finalization. Write size is included.

Each boundary retains count, lowest free heap, time of that lowest value,
independently lowest largest-block value and maximum payload/response bytes.
Idle and active-OTA observations have separate rows. A new metrics epoch clears
the previous evidence on its first accepted sample; OFF retains frozen evidence
without sampling. The existing RAII metrics gate covers heap inspection and
recording, so the OFF barrier waits for in-flight samples. Production builds
compile these entry points to no-ops and have no recorder endpoint/storage.

The recorder now freezes the current epoch at transfer exit, before SDK abort,
maintenance release and host cleanup reads. Frozen epochs perform no further
heap inspections; an already acquired sample cannot publish after freezing.
A later explicit metrics epoch can collect a new baseline. This prevents
cleanup requests from overwriting transfer minima, which the first run exposed.
Active ownership still gates report access until maintenance cleanup completes.

These are **instrumented boundary samples**, not allocation tracing or exact
peaks. Intermediate `String` expressions, allocator moves, allocations inside
SDK calls and concurrent TCP/HTTP activity can still escape observation. A
post-send sample retains the response string and socket. Do not subtract
independent minima to claim an allocation cost or infer causality from an
overlapping task's sample. Heap inspection itself takes time and the recorder
uses RAM: compare the instrumented workload with the original abort evidence,
then repeat a chosen change with instrumentation held constant. Do not reduce
the safety floor merely to compensate for the recorder.

Native checks:

```sh
c++ -std=c++17 -Wall -Wextra -Werror -fsanitize=address,undefined -Isrc \
  tests/host/ota_memory_probe_test.cpp -o /tmp/cover-ota-memory-test
/tmp/cover-ota-memory-test
c++ -std=c++17 -Wall -Wextra -Werror -fsanitize=address,undefined \
  -Itests/host/diagnostics_shim -Isrc tests/host/ota_memory_runtime_test.cpp \
  -o /tmp/cover-ota-memory-runtime-test
/tmp/cover-ota-memory-runtime-test
```

## USB-only memory and WiFi baseline

`web_control_usb_memory` is a separate USB test profile with an incompatible
`test_profile` descriptor. It forcibly disables OTA admission and never creates
the receiver task, even if a local OTA configuration enables it. Normal boot
metadata validation still applies. It keeps the 20-entry retained log and the
existing queue/stack sizes. Production builds contain no USB recorder state,
failure callback registration or additional sampling.

The test starts a single three-minute window in `beginDiagnostics()`. During
that explicit experiment, it samples internal 8-bit and internal DMA heap state
about once per second and calling tasks' lifetime minimum stack headroom once
per five seconds. This USB-only experiment runs independently of browser
metrics; it does not subscribe viewers or start the CPU sampling timer. It
counts HTTP dispatches so a supposedly quiet baseline can be checked. After
the `USBMEM end` marker it disables extra heap/stack sampling and failure
recording. The registered callback remains an inert gate until firmware is
replaced; no callback-unregistration assumption is required.

An allocation-failure callback records only a counter and a coherent last
requested-size/capabilities sample. It performs no allocation, formatting,
logging, clock read or wait. Metadata contention loses detail, counted separately,
while total failures are retained. Output reports whether registration succeeded;
`hook=0` is not a valid zero-failure result. It covers allocation APIs that invoke
the ESP-IDF hook, not driver buffer-pool exhaustion or allocations before hook
registration. No forced allocation failures are injected on the controller.

The diagnostics owner formats USB output into a fixed 352-byte buffer and
writes directly to Serial. It bypasses the queue being measured and avoids
the long-line allocation in `printf`. The collector still consumes RAM, CPU and
UART time. Queue high-water is **sampled**, not a proven maximum. Minimum heap
statistics can combine per-region lifetime lows; internal DMA and internal
8-bit values can overlap and must not be added together. An unavailable stack
row is not evidence of zero usage or a safe smaller stack.

Close all controller browser tabs, leave the supported mechanism stationary
with verified torque OFF, and keep telescope monitoring disabled. Archive the
exact binary/ELF and preserve USB recovery artifacts before installing. Capture
passively for at least 195 seconds from boot, with no HTTP requests during the
window. Existing `WIFI ASSOCIATED`, `WIFI DISCONNECT` and `WIFI LINK` records
provide the common timestamped radio timeline. A link BSSID change during
startup is not necessarily a roam by an established connection.

```sh
python3 tools/capture_diagnostics.py --port /dev/cu.usbserial-0001 \
  --duration 195 --build-dir /path/to/frozen-usb-memory-build \
  --output diagnostics/usb-memory-baseline
python3 tools/summarize_usb_memory.py /path/to/usb/serial.log \
  --output /path/to/private/summary.json
```

The offline summarizer requires a completed three-minute window and registered
hook, flags any HTTP activity, rejects resumed sampling after the end marker,
and reports settled heap observations, stack minima and WiFi changes. Restore
production over USB afterward and independently confirm accepted startup,
unchanged settings, torque/metrics OFF and disabled OTA/monitoring.

For a later controlled HTTP workload, retain at least two minutes of quiet
recovery. The pinned ESP32 SDK has `CONFIG_LWIP_TCP_MSL=60000`; TCP connection
state can outlive a completed request. This does not prove that a particular
heap drop is TCP retention. Repeated cycles and appropriate allocation evidence
are needed before diagnosing a leak or choosing a memory reserve.

Native tests: `tests/host/memory_failures_test.cpp` (including concurrent callback
contention) and `tests/host/usb_memory_probe_test.cpp` (actual collector cadence,
HTTP/stack counts and timed shutdown). The latter uses
`-Itests/host/diagnostics_shim -Isrc`; both support ASan/UBSan. Offline summary
tests are included in `python3 -m unittest discover -s tests/tools -p '*_test.py'`.

### Controlled status polling and recovery

Use the **same** frozen USB-memory image as the idle baseline. Start the
195-second passive USB capture at boot, then immediately start the read-only
client in another process/terminal:

```sh
python3 tools/probe_usb_http.py --host 192.168.1.135 \
  --build-dir /path/to/frozen-usb-memory-build \
  --capture /path/to/current-usb-console.log \
  --output /path/to/private/client-evidence --supported-cover-off
```

The client waits for a USB heap sample at 20–25 seconds uptime and the expected
boot ELF identity. It misses the window rather than automatically restarting
hardware or repeating the workload. One sequential `/api/status` request is
sent at most once per second for 20 seconds; slow responses do not cause a
catch-up burst or concurrent requests. Each response must retain the same
boot/image, accepted startup, ready/calibrated stationary OFF state, clean saved
settings, maintenance unlocked and metrics OFF/zero viewers. An HTTP or safety
check failure stops further requests. No session credential, subscription,
configuration, actuator or OTA command is sent.

The client then uses the capture file only, with no HTTP recovery polling.
It requires the completed USB window and at least 125 seconds of host-observed
quiet recovery, validates hook/end-marker evidence, and compares the pre-load
median, sampled load minimum and final ten-sample median. Device HTTP/status
dispatch totals must match attempted requests to call the workload isolated;
additional traffic is explicitly flagged. Save both request timestamps/status
snapshots and USB output. `COMPLETED_CONTROLLED_HTTP` means a completed measured
workload, not a certified memory reserve, absence of every leak or OTA readiness.
Inspect failures, radio events and transient sampling limitations separately.

After the full passive capture, independently verify OFF state and restore
production firmware. Do not reduce admission floors or task stacks merely
because this small workload completes successfully.

### User-driven browser/control exercise

`web_control_usb_memory_manual` uses the same USB instrumentation but sets an
explicit ten-minute window (`COVER_USB_MEMORY_DURATION_MS=600000`). OTA admission
and the receiver task remain disabled. Normal web controls and optional metrics
still operate through their existing safety/session checks. The operator may
exercise the page while USB records independently; this is not an isolated
status-only workload and its HTTP count is expected to exceed zero.

Install only while stationary with verified torque OFF, then start the passive
capture for at least 630 seconds and confirm the expected image/startup before
handing the browser to the user. Record the handoff and finish times. Allow time
for at least two minutes without HTTP after browser use. Do not reboot/reflash
while the user is exercising controls; obtain fresh stationary/OFF conditions
before restoring production. The sampling window ends automatically; it does
not stop the web interface or issue a cover command.

Use `tools/summarize_usb_memory.py --duration 600` for a **completed** manual
window. The default analyzer still requires 180 seconds, preventing accidental
acceptance of the wrong experiment duration. Keep action/fault/radio timestamps
with the heap data. Summarizing a ten-minute uncontrolled interaction does not
attribute a memory drop to any particular button or certify motion/OTA reserves.

## OTA with passive USB memory recording

`web_control_ota_usb_memory_probe` explicitly combines the nonactivating
inactive-slot flash test with the bounded ten-minute USB collector. It requires
both experiment flags and rejects the metrics-gated boundary recorder. Ordinary
USB baseline builds still exclude the receiver; normal OTA admission remains
closed. Provision the same private header and nonzero experimental floors as
for the existing flash probe. Never expose its credential in command arguments.

Start an independent USB capture, close controller browser tabs and use the
existing flash client with **`--passive-usb`**. It does not request a session,
subscribe/renew metrics or start the CPU timer; it still reads one root status
per second to check boot/image and stationary torque-OFF conditions. An active
metrics viewer makes the observer stop. USB evidence must be archived separately;
the client does not invent heap/stack values when browser metrics are OFF.
`--memory-evidence` and `--passive-usb` are mutually exclusive.

Keep the entire erased inactive-slot backup and current native boot metadata.
The receiver writes only the inactive slot and returns `NOACT`; a guard failure
is evidence, not authorization to lower the floor or retry automatically. Keep
Alpaca configured as the user selected; existing maintenance pauses its polling
during transfer. After the attempt, preserve at least two minutes of passive
quiet recovery where practical, verify slot contents/metadata over USB, restore
the original inactive slot and normal firmware, and retire the temporary secret.
Use a fresh supported-cover/torque-OFF check before any restoration reset.

## Supervised activation and pending-first-boot reset

`tools/probe_ota_activation.py` is a separate explicit bench experiment; the
normal upload CLI remains disabled. It uses the production commit/journal path
with temporary, private receiver-enabled builds. First install source A in
app0 over USB with a current full inactive-slot backup, original native otadata
and a normal recovery image available. Source A and healthy B need distinct
ELFs/private credentials; the normal recovery image is the third distinct build.
Keep the cover supported and confirm fresh stationary torque OFF.

```sh
python3 tools/probe_ota_activation.py --host 192.168.1.135 \
  --port /dev/cu.usbserial-0001 \
  --source-build-dir /private/source-A --candidate-build-dir /private/candidate-B \
  --recovery-build-dir /private/normal-recovery \
  --source-secret-file /private/source-secret \
  --candidate-secret-file /private/candidate-secret \
  --supported-cover-off --run-activation-recovery-experiment \
  --output diagnostics/activation-experiment
```

The driver exclusively owns USB; do not start another serial capture or esptool
while it runs. It records serial/status, performs A → B healthy activation, then
B → normal recovery and one EN reset before pending startup acceptance. Reset
requires a matching candidate BOOT, source reboot event and final selection ACK
within a short window; it is never repeated automatically. A matching durable
COMPLETE followed by ROLLED_BACK, expected identities/slots and safe recovery
are required; missing an injection is not rollback evidence. This is not a
power-loss or watchdog-hang test.

Afterward, verify both images and native ABORTED/VALID slot states over USB.
Restore the **original native otadata** (only 0xe000..0xffff), normal app0 and
original inactive slot; do not restore old application NVS. Keep the terminal
historical test outcome, confirm normal disabled-OTA firmware/torque OFF and
monitoring, and retire private plaintext credentials. Source/candidate binaries
contain credentials and must remain private. See the dated activation results
in [the OTA plan](OTA_IMPLEMENTATION_PLAN.md#activation-and-pending-reset-rollback-hardware-results).

## Supervised interrupted upload and authenticated cancellation

`tools/probe_ota_interruption.py` tests a deliberate TCP disconnect and signed
cancellation at 65,536 acknowledged bytes, then a complete upload without
resetting the source. It requires a private receiver-enabled source build,
normal recovery payload, `--supported-cover-off` and
`--run-interruption-experiment`. Supply the credential through `--secret-file`,
never command-line plaintext. Run `--help` for the build/output arguments.

The driver exclusively owns USB and never arms its serial reset gate. For the
intentional disconnect only, it suppresses automatic uploader cancellation; for
the cancellation case, it keeps the data socket open until receiver cancellation
is observed. Unexpected failures retain ordinary cleanup. Both tests require
matching unselected durable transactions, unchanged source boot and released
maintenance before continuing. No ambiguous attempt is automatically repeated.

As with the activation experiment, preserve the full inactive slot and native
otadata first. Verify both images/native selection afterward, restore original
native otadata plus normal app0 and the original inactive slot, preserve live
NVS, check safe normal startup and retire temporary plaintext credentials.
See the [dated results](OTA_IMPLEMENTATION_PLAN.md#interrupted-upload-and-cancellation-hardware-results).

Add `--stop-experiment` to the interruption driver to run explicit Stop followed
by a full same-boot upload instead of the drop/cancel stages. Stop uses a fresh
boot-bound UI session and the normal `/api/stop` route; no motion request is
sent. The test requires one Stop-epoch increment, clearance-loss failure and
maintenance cleanup while the data socket remains open. This tests active
transaction revocation at an acknowledged block boundary, not worst-case flash
latency or final-commit timing. Use the same backup/restoration procedure.

## Supervised autonomous startup watchdog recovery

`tools/probe_ota_watchdog.py` requires `--run-watchdog-experiment`,
`--supported-cover-off`, `--stage before_setup` or `--stage setup`, a private
healthy `--source-build-dir`, isolated hang `--candidate-build-dir`,
`--source-secret-file`, literal `--host`, `--port` and private `--output`.
Its USB reset gate remains unarmed; no host reset is a substitute for the
45-second RTC watchdog. Reconciliation has a bounded 90-second deadline.

The module's `make_hang_source(source, destination, stage)` copies `src/` to a
fresh isolated directory and injects only there. Build it with
`PLATFORMIO_SRC_DIR` pointing to that private snapshot and a separate
`PLATFORMIO_BUILD_DIR`; verify the candidate binary's stage marker and freeze
its manifest/ELF. Never install a hang candidate by USB as the sole recovery
image. It must enter a pending slot through the healthy source's real OTA path.
A matching hang marker, RTCWDT reset, recovered source boot and durable
ROLLED_BACK are required. Independently check native metadata and candidate
flash bytes before another test. Follow the same original-otadata/app0/app1
restoration procedure; keep all hang artifacts private and never distribute them.

## Operator-assisted power interruption

`tools/probe_ota_power_loss.py` requires explicit supported-cover/OFF,
confirmed-power-path and manual-experiment flags, private source/payload builds,
a secret file, literal host and private output. It cues at 65,536 acknowledged
bytes, paces blocks and caps the image at 524,288 bytes so it cannot activate.
An expired window is not a power-loss test. Use `--without-usb` only after the
operator removes USB while idle and the healthy controller is verified on its
remaining supply; this mode opens no serial port. Otherwise specify `--port`.

Give the operator an explicit cut/restore cue, confirm all supply paths were
removed and the controller was visibly off, then archive the first recovered
HTTP boot **before opening USB**. Require a new POWERON source boot, safe torque
OFF, unchanged settings and unchanged native selection. Journal history may
remain unchanged before commit, or a matching unselected FAILED record may have
been saved before complete shutdown. The latter is safe recovery evidence but
not proof of a cut inside an uncheckpointed write. Continuous ACKs/unchanged
boot ID disprove a claimed complete power cut. Manually timed cuts do not prove
a narrow flash/commit window. Preserve original evidence and restore normal
firmware/native otadata/inactive slot after independent device checks.

## Power loss between journal persistence and boot selection

`tools/probe_ota_checkpoint.py` builds no live source changes: use its
`make_checkpoint_source(source, destination)` helper for an isolated private
snapshot, then build with `PLATFORMIO_SRC_DIR`, a separate build directory and
private OTA header. The post-NVS barrier lasts at most 90 seconds and always
returns false, so it never authorizes selection if the operator misses the cue.

Run the driver with private source/payload directories, secret file, literal
host, private output and all three explicit flags: `--supported-cover-off`,
`--usb-removed-power-path-confirmed`, `--run-checkpoint-experiment`. Confirm the
sole controller supply and remove Mac USB while idle before starting. The driver
requires matching verified image/intent/lease evidence before its cut cue.
Use one operator action per cue: unplug the controller power input; confirm all
lights out; wait at least 10 seconds; restore power; archive first recovered
HTTP status before reconnecting Mac USB. Expect matching UNCONFIRMED, accepted
original source, safe OFF state and unchanged settings. Verify both full images
and native selection independently, then restore original otadata, normal app0
and the original inactive slot, preserving live NVS. Retire the plaintext secret.

## Routine development OTA

Use the [local development workflow](../README.md#local-development-ota) instead
of the fault-injection scripts. `python3 tools/ota_dev_setup.py` creates ignored,
owner-only credential/header files; it never changes device settings. Build
`web_control_dev`, bootstrap once over USB, then build changes and use
`tools/ota_upload.py upload-dev` with `--host` and `--closed-cover`.
It requires development markers on the artifact/controller and uses the same
HMAC, manifest, maintenance and durable-startup checks as the exercised engine.

Leave the persistent development credential in place for subsequent updates;
do not retire it after each ordinary upload. Source/candidate images contain
that credential. Normal builds ignore this separate header, and generic
production upload gates remain closed. Existing hardware failure/memory results
retain their measured limits; the user has deferred remaining production gates
for supervised development, not declared them tested. Any state other than CLOSED,
stale telemetry or active maintenance must be resolved through normal controller
operation before retrying. The uploader never issues an actuator command.

Current admission permits torque ON or OFF without writing torque or position.
Fresh, stable encoder readings must agree with the saved closed endpoint within
10 counts throughout transfer. Normal OTA startup repeats the closed-position
checks. Aborted-transfer cleanup can also unlock after a confirmed stationary
torque-OFF Stop; this does not permit another upload until CLOSED is restored.
The signed policy changed, so the older installed receiver needs a one-time
USB migration or an update using the old uploader and its original prerequisites.
Earlier experiment results below and above retain their historical OFF policy.

## Bounded saved-STA recovery

The application now supplements Arduino's automatic reconnect, including its
ASSOC_LEAVE exception. In `pollNetworkSetup()`, a fixed-storage policy issues
one asynchronous `esp_wifi_connect()` request after 20 seconds without a usable
STA connection. Subsequent application requests wait 40, 80, then at most 120
seconds from the preceding request. The capped rate continues through long
outages; there is no permanent retry-count lockout. Arduino may independently
attempt its own reconnection sooner. A healthy connection resets the backoff.

The policy issues no forced disconnect, radio reset, reboot, scan or credential
write. Existing boot/setup paths install the intended WiFi RAM configuration;
recovery requests connection using that configuration. An SDK refusal (including
an already-running connection attempt) consumes one retry slot rather than
triggering a tight loop. USB/debug records `saved-STA-retry` and the numeric
`WIFI RETRY result=… next_wait_ms=…`, without credentials.

Retries are suppressed during all network setup phases, any maintenance lease
(including pending/revoked OTA cleanup), and while an AP client is associated
with the fallback hotspot. Those gates reset the delay, giving setup or an
existing driver connection attempt a fresh 20-second grace period when released.
The normal connected path only checks fixed state and timers; no extra task,
sampling buffer or periodic heap allocation is added by the policy itself.
WiFi driver allocations during connection remain subject to normal SDK behavior.

Fallback AP still opens after 20 seconds offline, subject to existing maintenance
safety. An automatically opened recovery AP closes after 30 seconds of connected
STA operation, when no AP clients or maintenance/setup operation are active.
Explicit setup AP behavior is retained. This returns automatic recovery to STA-only
mode, which OTA admission requires. Recovery never commands the cover or telescope.

Native policy verification:

```sh
c++ -std=c++11 -Wall -Wextra -Werror -Isrc tests/host/sta_recovery_test.cpp -o /tmp/cover-sta-recovery-test
/tmp/cover-sta-recovery-test
```

As of 2026-10-24 this change is built and host-tested, **not hardware-verified or
installed by this change**. With the cover supported and torque OFF, install the
development build, remove/restore AP availability without editing controller
credentials, and verify recovery without controller reboot, retry spacing and
fallback closure. Also check that active portal/setup and OTA cleanup suppress
retries. Then repeat a continuous connected hour with read-only Alpaca and normal
browser traffic. This recovery policy does not establish the initial disconnect's
cause or improve RF signal strength.

Installation follow-up on 2026-10-24: `4fbb7b8a…` is now running after a verified
development OTA update; startup, preserved settings, torque OFF and read-only
Alpaca connectivity passed. Controlled outage/reconnection and hour-long connected
standby checks remain pending. Evidence: `diagnostics/sta-recovery-20261024/`.

Hardware follow-up: client block/unblock verified retry timing and same-boot
reconnection, then exposed a core return-value defect in `softAPdisconnect(true)`:
the AP radio stopped but application state was left active. The application now
uses `WiFi.enableAP(false)` directly. Corrected image `47e279e6…` was installed
over USB and a repeat block/unblock verified both physical AP shutdown and empty
AP status after 30 connected seconds. Read-only Alpaca, settings and torque OFF
were preserved. Driver authentication retries were active during these tests;
the original ASSOC_LEAVE-only case was not isolated. The repeat hour is running
without another USB reset. See [the complete evidence](OTA_IMPLEMENTATION_PLAN.md#reconnection-checks-and-hotspot-cleanup-correction--2026-10-24).

## Retained failure summary

The Debug page has a separate **Retained failure summary** disclosure. It starts
closed and performs no summary requests until opened on the visible Debug page.
While open it refreshes at most every five seconds; hidden pages, setup-hotspot
sessions, stale connectivity, motion/holding and OTA suppress reads. Opening it
does not subscribe to optional metrics, CPU sampling or task stack scans. When
offline, the page labels the last downloaded summary as cached evidence.

The recorder holds two independent records:

- **WiFi incident:** firmware/boot identity, incident uptime, first/latest reason
  codes, initial RSSI/BSSID, preceding controller WiFi action and age, application
  retry count, most recent SDK return code, retry uptime/delay, and completed
  outage duration when IP returns in the same boot. Repeated disconnect events
  update the same episode without replacing its initial context. These are
  application retries, not all WiFi driver authentication/radio attempts.
- **Controller fault:** bounded fault message, firmware/boot identity, uptime and
  known position/target. Actual cover FAULT transitions, failed startup validation
  (excluding expected missing calibration), and diagnostics/cover task or queue
  allocation failures populate it. Normal servo state changes and HTTP/log-read
  failures do not populate it, avoiding recursive capture.

Each new incident/fault captures free heap, historical minimum heap and the
largest free internal block. Largest-block sampling happens only at a new
incident/fault, outside the recorder lock; repeated disconnects and retries reuse
the incident snapshot. It is additional event-triggered evidence, not continuous
metrics collection. Record reads do not resample memory or access the servo.
No SSID, password, session token or OTA credential is copied into the record.

Records occupy **896 bytes in `.rtc_noinit`**, including two checksummed copies
with commit markers. Reset-interrupted writes can fall back to the previous
complete copy; reads also validate integrity. Schema/integrity mismatches are
discarded. **This is not flash persistence:** retention depends on the reset
preserving RTC memory. Power-on, brownout and unknown reset causes deliberately
start a new retention period. Some reset types or firmware/layout changes may
also invalidate it. No NVS/flash writes or new tasks are introduced.

The current reset reason and boot count for the retention period are displayed.
An unresolved record from an earlier boot stays marked as historical; its uptime
is never subtracted from the new boot's clock. A normal new boot or log rollover
does not erase a valid fault. Brief initial association failures do not replace
an earlier boot's WiFi evidence; a prolonged startup outage is recorded once an
application retry is due (its observation timestamp is then the retry time).
Expected disconnects immediately following the controller/OTA reboot markers are
excluded. Intentional network configuration changes may still be recorded, with
their preceding action shown for interpretation. Existing OTA durable journal
evidence remains separate. This is not a crash backtrace or core-dump download.

Read-only API: `GET /api/debug/retained`, schema version 1, no-store, bounded
2,048-byte response. It shares the detailed-debug read budget (two reads/second
across viewers) and returns 503 during protected operations or memory shortage;
setup-AP access is rejected. Null fields mean not recorded/known. A completed
outage duration assumes the outage is shorter than the millisecond-clock wrap.

Verification includes native storage/serializer tests with ASan/UBSan, actual
diagnostic callback and servo-worker integration tests, browser lifecycle tests,
and an isolated Chrome test against the localhost fixture. The browser test
checks safe text rendering, no CPU-metrics subscription and no summary requests
after closing the disclosure. Tests:
`tests/host/failure_summary_test.cpp`, `failure_response_test.cpp`,
`diagnostics_test.cpp`, and `tests/web/retained_test.cjs` /
`retained_browser_test.cjs`.

As of this implementation step (2026-10-24), firmware builds and host/browser
checks pass; hardware retention/display verification is **pending installation**.
The connected standby hour remains on `47e279e6…`, with its own archived matching
artifacts and uninterrupted USB capture. New workspace builds include this
feature and must not be assumed to identify that running image. After the hour,
install safely and verify a real disconnect/recovery and warm reboot, then confirm
the recorded firmware/boot identities and unchanged calibration/torque OFF.


## Optional network time and local log timestamps

Configuration → Date & time provides **Enable network time (NTP)** (off by
default), an editable server (default `pool.ntp.org`), and an editable POSIX time
zone (default `MST7`, Arizona, UTC−07:00 year-round). Examples:

- `UTC0`: UTC.
- `EST5EDT,M3.2.0/2,M11.1.0/2`: US Eastern, including daylight saving.
- `PST8PDT,M3.2.0/2,M11.1.0/2`: US Pacific, including daylight saving.

POSIX offset signs are opposite to UTC-offset notation: `MST7` means UTC−07:00.
IANA names such as `America/Phoenix` require a zone database and are not accepted.
Daylight-saving zones require explicit transition rules. Server names accept
DNS hostnames or IPv4 addresses, without schemes or ports (UDP 123 is used).
Saving uses the existing maintenance clearance, persists the settings, and
restarts the controller. Existing v1–v5 settings migrate with NTP disabled;
current application records are v6. Calibration remains independent.

`time_sync.cpp` starts the framework SNTP client once, only when enabled and
STA has an address. DNS, UDP requests, retry/backoff, and periodic resynchronization
run in lwIP. There is no new application task, blocking DNS call, `getLocalTime()`
wait, or synchronization loop. A missing/unreachable server never gates startup,
web service, or movement. No servo control, deadline, heartbeat, or interlock
uses calendar time; all existing monotonic timing remains unchanged.

Log publishers capture epoch seconds at the event, before queueing. Serial output
keeps its existing `[uptime_ms] EVENT ...` prefix and appends, for example,
`local_time=2025-12-31T17:00:00-0700`. Shared log responses add `local_time` (a string
with UTC offset, or JSON null). The Debug view shows this configured local time
alongside uptime, independent of the browser's time zone. Browser-originated
messages continue using browser-local time. Calendar precision is one second;
uptime retains millisecond precision. Low-level boot/probe output outside the
central logger keeps its existing format.

Before the first valid SNTP callback, events remain explicitly unsynchronized;
they are not retroactively assigned dates. A full power loss requires another
synchronization. After synchronization, the system clock continues through network
outages with possible drift; `time_synchronized` means synchronized at least once
this boot, not a guarantee of current server reachability. `/api/network` also
reports `last_time_sync` (epoch seconds, zero until synchronized) and `local_time`.
Synchronization may adjust calendar timestamps; uptime preserves event timing.

Numeric timestamps add 80 bytes to the 20-entry ring and 96 bytes to the 24-entry
serial queue. Server/time-zone settings and SNTP also consume memory; runtime heap
and latency still need measurement on hardware with NTP enabled and unavailable.
Host tests cover defaults, settings migration, missing synchronization, reconnect
polling, event-time capture, local offsets/DST, validation and bounded JSON output.
The configuration browser test covers editing, save/restart, and unsynchronized
status. No hardware timing or live NTP reliability is implied by those tests.

### Hardware verification — 2026-10-24

Combined image `58202622…` is installed and accepted. An unreachable-server boot
remained responsive and explicitly unsynchronized. Real synchronization and log
timestamps passed with `pool.ntp.org` in UTC0, then MST7; reported calendar time
was checked against the Mac clock and offsets were verified. The installed
Configuration page showed the enabled server, zone and synchronized local time.

A saved-SSID reconnect generated an actual retained WiFi incident. Its full
payload survived a subsequent warm time-settings reboot, kept its source boot
identity/heap snapshot, and appeared on the actual Debug page. No metrics
subscription or control request was generated by the isolated browser check.
An actual cover fault and full power-loss retention were not tested; RTC loss
behavior remains as described above. Retained incident timestamps remain source
boot uptime, while ordinary synchronized logs also include local calendar time.

The following five-minute workload passed 299 status requests with no disconnect
or unexpected reboot (49 ms median, 187 ms maximum). NTP remains enabled with
`pool.ntp.org` / `MST7`; torque OFF, calibration/profile preserved and read-only
Alpaca connected. See [full evidence](OTA_IMPLEMENTATION_PLAN.md#combined-ntp-and-retained-summary-hardware-tests--2026-10-24).

## Configuration saves with CLOSED feedback or an unavailable servo

With a responding servo, configuration saves require CLOSED, clean calibration, and stable valid servo
readings within 10 counts of the saved closed endpoint. Torque may be ON or OFF;
settings maintenance does not change torque. Clearance is rechecked while the
maintenance lease is held. Settings-triggered software restarts preserve the
existing torque state using the retained-reboot marker and fresh startup checks.
Without servo communication, all controller settings can be saved after three
consecutive failed position/torque poll cycles and a failed model probe establish
offline clearance in the worker. This works on fresh boards and after later
communication loss; a single failed read or a device-error reply is insufficient.
The UI uses fresh `settings_offline_allowed` status instead of a physical-
disconnection checkbox. It reports unknown position/torque, keeps movement blocked,
and withdraws offline permission when feedback returns. Missing controller HTTP
status still blocks saving. The exception issues no servo writes.
Calibration capture/save and manual reboot controls retain their own requirements.
