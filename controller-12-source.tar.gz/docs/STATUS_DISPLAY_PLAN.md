# Status display and Manual tab mirror

Preliminary design for the next release, 2026-10-26. Implementation is pending.

Add one status screen to the board's OLED, refreshed once per second, and a
live copy on the Manual tab with a similar font. Include a virtual panel button
there so the same interaction can later serve an external button wired across
BOOT. Multiple screens and button-driven Open/Close follow later.

## Hardware findings

The board's screen is an OLED. Waveshare's
[display initialization](https://github.com/waveshare/Servo-Driver-with-ESP32/blob/main/ServoDriver/BOARD_DEV.h)
specifies SSD1306, 128 × 32 pixels, I2C address `0x3C`, and no separate reset pin.
Its [pin definitions](https://github.com/waveshare/Servo-Driver-with-ESP32/blob/main/ServoDriver/ServoDriver.ino)
use SDA GPIO 21 and SCL GPIO 22. These are separate from the servo UART on
GPIO 18/19. Verify the fitted display against these defaults during implementation.

Waveshare's [schematic](https://files.waveshare.com/wiki/Servo-Driver-with-ESP32/Servo_Driver_with_ESP32.pdf)
connects the FLASH/BOOT switch between GPIO 0 and ground. The later external
button can be a normally open momentary contact in parallel with that switch;
confirm the pads on the actual board before wiring. Holding GPIO 0 low during
reset enters the bootloader, so a held or stuck button can prevent normal
startup. This is inherent to using BOOT; firmware cannot suppress it.
[Espressif boot behavior](https://docs.espressif.com/projects/esptool/en/latest/esp32/advanced-topics/boot-mode-selection.html)

## First screen

Use four rows of up to 21 characters with the default small fixed-width font.
Adafruit GFX's [classic font](https://github.com/adafruit/Adafruit-GFX-Library/blob/master/Adafruit_GFX.cpp)
uses 6 × 8 pixel character cells, which fits this screen. Suggested layout:

```text
CLOSED         T:OFF
P:2048 12.3V 38C
L:+0 Iraw:+12
STA 192.168.1.123
```

- Row 1: controller state and torque ON/OFF/unknown. Use compact labels for
  longer states; never invent CLOSED from missing feedback.
- Row 2: encoder position, servo supply voltage, and servo temperature.
- Row 3: signed relative load and raw current. `L` is not calibrated torque;
  `Iraw` is not amperes.
- Row 4: Wi-Fi mode and useful IP address; prefer STA when connected, otherwise
  the active setup AP. A fault or maintenance message takes priority over the IP.

Keep this a single fixed page with no automatic rotation or scrolling text.
Truncate messages safely; the existing browser status retains the full fault.
Physical limit and weather sensors remain future additions; this screen does
not add independent proof of cover position.

One-second refresh means refreshing the view, not increasing servo polling.
[The worker](../src/web_control.cpp) already publishes position roughly every
250 ms during movement and 500 ms when stationary. Secondary telemetry normally
updates every five seconds while neither moving nor holding, with a separate
torque-test cadence. Reuse those readings. Apply the existing position freshness
limit of 1.5 seconds and secondary telemetry limit of 15 seconds; show `--` for
invalid or expired data. Mark retained secondary readings with `*` during motion
or holding, meaning “last sampled values.” Live moving load/current sampling is
separate work.

## Firmware and browser hookup

Add a small `status_display.h/.cpp` module under `COVER_WEB_CONTROL`. It copies
the protected `webStatus()` snapshot and current network state, formats four
bounded text rows once, and caches them with a sequence and update timestamp.
The OLED and browser consume these same rows, keeping labels, rounding,
abbreviations, and stale markers consistent.

```text
Cover worker snapshot + network state
                   |
          Shared four-row screen
             /             \
       I2C OLED        /api/status
                            |
                      Manual tab mirror
```

Call initialization from [main.cpp](../src/main.cpp), then service the display
from its existing loop using a `millis()` deadline. Keep I2C and formatting out
of the servo worker and its critical sections. Start with Adafruit SSD1306/GFX,
as used by the board reference; pin compatible dependencies and include their
license notices. Do not import the vendor's servo or configuration code.

Allocate once: a 128 × 32 monochrome buffer is 512 bytes, and four terminated
21-character rows need 88 bytes, plus metadata and library/I2C overhead. Avoid
per-refresh allocation and a new task initially. Bound I2C transaction timeouts
and check the whole update's worst-case duration, including multiple failed
transfers. Stop OLED updates after a detected bus failure; keep control and the
web mirror operating. SSD1306 `begin()` success does not prove display presence,
and its transfer code does not return delivery success; use an address probe
and timing checks, without claiming the physical pixels were verified.
[Driver behavior](https://github.com/adafruit/Adafruit_SSD1306/blob/master/Adafruit_SSD1306.cpp)

Extend the existing [status response](../src/web_server.cpp) with a small
`display` object containing `rows`, `sequence`, `age_ms`, and OLED availability.
Use the existing [browser polling](../data/ui/transport.js); no new polling loop,
WebSocket, screenshot stream, or browser-side metric formatter is needed.
Refresh the displayed rows only when the screen sequence changes. Loss of
controller freshness, or a screen snapshot older than three seconds, labels
the mirror stale and disables its button. A failed OLED is labeled separately
from a stale controller connection.

Place a **Controller display** panel near the top of the
[Manual tab](../data/ui/index.html), outside the manual-jog enable fieldset.
Render identical text using a local monospace font, tight line spacing, white
on black, and approximately the OLED's 4:1 shape. Preserve whitespace and use
`textContent`. A close font match is sufficient; no font download or pixel-exact
renderer. Show the `*` legend, connection status, and **Press panel button** below
the mirror. Viewing it does not require enabling manual jogs.

## Button now and later

For the first release, **Press panel button** sends a discrete authenticated
`POST /api/display/button` short-press event to the display module. With one
screen, it stays on screen 1 of 1 and acknowledges the press beneath the mirror.
It never moves the cover. Keep existing session, home-network, beta-acceptance,
and maintenance checks; reject unsupported events. No physical button wiring
is required for this increment.

Later, poll GPIO 0 separately from the one-second redraw, debounce it, and feed
the same panel event handler. Require an initial release after startup and one
event per gesture. A short press can advance screens; a deliberate long press
can activate an explicitly displayed Open or Close action. A press during
movement should request Stop immediately, without waiting for long-press
detection, and must not also trigger navigation or a new move on release.
Finalize gesture timing when the button is fitted.

The main integration issue is motion ownership. Today the worker requires the
owning browser's heartbeat within 500 ms. A physical button needs an explicit
local supervision/ownership policy before it can start motion; do not fake a
browser heartbeat or remove its timeout. Virtual-button motion must still use
the browser's existing command acknowledgment, heartbeat, and Stop handling.

Both inputs must pass normal Open/Close checks, including calibration, path
clearance, telescope stow, maintenance exclusion, and worker preflight. Some
checks currently live in the HTTP handler, so share that admission logic before
adding local commands. The Manual tab's special jog bypass must not extend to
panel Open/Close. If local telescope-stow confirmation is unavailable, reject
Close; define an explicit local confirmation interaction in that later phase.
Keep Stop available and do not toggle direction from UNKNOWN or FAULT.

## Implementation checks

1. Confirm the fitted OLED, address, orientation, and four-row readability;
   verify the BOOT connection before adding the external switch later.
2. Check row widths and invalid/stale/fault formatting, then compare the OLED
   and browser through state changes and reconnects. The virtual press should
   receive one acknowledgment and issue no servo command.
3. Measure firmware size, heap, web response time, and heartbeat gaps with the
   display active and with the OLED absent or the I2C bus stalled. Preserve Stop
   responsiveness and the existing motion timeout. If I2C cannot fit the loop's
   timing budget, resolve that before release.

The first increment needs no NVS schema change, screen editor, display settings
page, or new telemetry subsystem. Review the four proposed rows on hardware;
leave additional screens and local motion for the button increment.
