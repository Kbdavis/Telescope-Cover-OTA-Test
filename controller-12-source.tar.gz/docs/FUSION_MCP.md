# Accessing Autodesk Fusion through its local MCP server

This records the connection and CAD workflow successfully used on this Mac on **2026-10-26**, including the V6 inspection and V7 bearing revision. These are observed behaviors of that installation; discover the server's current tools before relying on their schemas after a Fusion update.

## Start here

1. Open Fusion and select the intended design tab.
2. In **Preferences → General → API**, enable **Fusion MCP Server (runs locally on this device)**.
3. Read the endpoint shown there. The working endpoint in this session was:

   ```text
   http://127.0.0.1:27182/mcp
   ```

4. Prefer Fusion MCP tools if they are already exposed to the agent. If none appear, connect directly to the local HTTP endpoint using the client below.
5. Initialize an MCP session, retain its session ID, and send `notifications/initialized` before listing or calling tools.
6. Read the open documents and verify the active document before inspecting or editing anything.

**Fusion's built-in server was sufficient.** No separate add-in or plugin installation was needed. Its endpoint was not automatically exposed in the agent's tool list. The absence of connected document sessions, a matching plugin, or entries in `~/.codex/config.toml` did not mean Fusion was unavailable. The Fusion API AddIns directory was also empty; that did not prevent this connection.

The screenshot's debugging ports **9000** and **9229** were unrelated to the MCP endpoint. Use the port displayed specifically for **Fusion MCP Server**. Recheck it rather than assuming it is always 27182.

## Local network access and the execution sandbox

The first request from the sandbox failed immediately:

```text
curl: (7) Failed to connect to 127.0.0.1 port 27182
```

The same request succeeded with approved execution outside the sandbox. In this agent environment, the successful `exec_command` used `sandbox_permissions: "require_escalated"` with a justification explaining access to the user's local Fusion MCP server.

Do not diagnose a disabled Fusion server from a sandboxed connection failure alone. Use the supported approval mechanism to test local access. If an approved request still fails, check that Fusion is running, the setting is enabled, and the endpoint matches Preferences. Do not expose the server on a public network or disable unrelated security controls.

Successful initialization returned HTTP 200, an `MCP-Session-Id` header, protocol version `2024-11-05`, and server identity `MCP Server Adapter`, version `1.0.0`.

## Reusable session client

The following creates a temporary Python client using only the standard library. Run the shell block from the repository directory. It does not modify Fusion merely by being created; each subsequent invocation performs the requested MCP operation.

```sh
cat > /private/tmp/fusion_mcp.py <<'PY'
import json
import pathlib
import sys
import urllib.request

URL = "http://127.0.0.1:27182/mcp"  # Confirm in Fusion Preferences.
headers = {
    "Content-Type": "application/json",
    "Accept": "application/json, text/event-stream",
}

def request(body):
    req = urllib.request.Request(
        URL, data=json.dumps(body).encode("utf-8"), headers=headers
    )
    with urllib.request.urlopen(req, timeout=45) as response:
        session = response.headers.get("MCP-Session-Id")
        if session:
            headers["MCP-Session-Id"] = session
        payload = response.read().decode("utf-8")
    result = json.loads(payload) if payload.strip() else None
    if isinstance(result, dict) and "error" in result:
        raise RuntimeError(json.dumps(result["error"]))
    return result

initialized = request({
    "jsonrpc": "2.0", "id": 1, "method": "initialize",
    "params": {
        "protocolVersion": "2024-11-05",
        "capabilities": {},
        "clientInfo": {"name": "telescope-cover-cad", "version": "1.0"},
    },
})
request({"jsonrpc": "2.0", "method": "notifications/initialized"})

method = sys.argv[1] if len(sys.argv) > 1 else "tools/list"
argument = sys.argv[2] if len(sys.argv) > 2 else "{}"
params = json.loads(
    pathlib.Path(argument[1:]).read_text()
    if argument.startswith("@") else argument
)
result = request({"jsonrpc": "2.0", "id": 2, "method": method, "params": params})
output = json.dumps(result, indent=2)
if len(sys.argv) > 3:
    pathlib.Path(sys.argv[3]).write_text(output)
    print("Saved response to", sys.argv[3])
else:
    print(output)
PY
```

This client matches the JSON responses observed here. Although the request advertises both JSON and event-stream acceptance, the client does **not** parse SSE responses. If a later server returns `text/event-stream`, use an MCP client with that transport support or extend the parser before proceeding.

Each invocation establishes a fresh session. Never reuse the numeric session ID from a previous conversation. Keep the `MCP-Session-Id` header on subsequent requests in the same session. The initialized notification has no request ID and may return an empty response body.

Skipping `notifications/initialized` produced this error even after a successful initialize response:

```text
Session not initialized. Call 'initialize' first.
```

If a long operation times out, inspect Fusion and its output files before retrying. The operation may already have run; blindly resubmitting can create duplicate documents or edits. The 45-second client timeout is not an execution cancellation mechanism.

## Discover tools and identify the active design

Save discovery output to avoid truncating large schemas:

```sh
python3 /private/tmp/fusion_mcp.py tools/list '{}' /private/tmp/fusion-tools.json
python3 /private/tmp/fusion_mcp.py tools/call '{"name":"fusion_mcp_read","arguments":{"queryType":"document","operation":"open"}}'
```

The observed tools were:

| Tool | Relevant capability |
| --- | --- |
| `fusion_mcp_read` | Open documents, screenshots, active command, API documentation |
| `fusion_mcp_execute` | Python scripts through the Fusion API; document operations |
| `fusion_mcp_update` | Undo and redo |
| `fusion_mcp_electronics_read` | Electronics documents; unnecessary for this mechanical assembly |

Copy exact tool names and argument schemas from discovery. Open-document results include the name, active flag, modified/saved state, and identifiers. In the original inspection, the active document was **V6 weather shields - closed assembly**. After the revision it was **V7 integral bearings - assembly**. Names can be duplicated, so do not select a document by name alone when multiple matches exist.

Tool results can contain JSON serialized inside `result.content[].text`. That inner JSON can contain another JSON string in `message`, especially for script `print()` output. Inspect every layer for errors. An HTTP 200 or successful shell exit does not prove the Fusion operation succeeded: script exceptions were returned inside the tool result as `success: false` plus a traceback.

## Inspect geometry without changing the design

Use `fusion_mcp_execute` with `featureType: "script"` and **`object.readOnly: true`**. Fusion enforces this mode. Scripts must define `run` with one argument; printed output is returned through MCP. Avoid swallowing exceptions, which obscures failed operations.

Create a JSON request using Python rather than escaping a multiline script into a shell command:

```sh
python3 - <<'PY'
import json
from pathlib import Path

script = '''import adsk.core, adsk.fusion, json
def run(context):
    app = adsk.core.Application.get()
    design = adsk.fusion.Design.cast(app.activeProduct)
    assert design, "The active product is not a Fusion design"
    print(json.dumps({
        "document": app.activeDocument.name,
        "modified": app.activeDocument.isModified,
        "components": [c.name for c in design.allComponents],
        "joints": design.rootComponent.joints.count,
        "asBuiltJoints": design.rootComponent.asBuiltJoints.count,
    }))
'''
request = {
    "name": "fusion_mcp_execute",
    "arguments": {
        "featureType": "script",
        "object": {"readOnly": True, "script": script},
    },
}
Path("/private/tmp/fusion-inspect.json").write_text(json.dumps(request))
PY
python3 /private/tmp/fusion_mcp.py tools/call @/private/tmp/fusion-inspect.json
```

Useful inspection APIs exercised in this session:

- `design.allComponents`, `rootComponent.occurrences`, and `rootComponent.allOccurrences`.
- `component.bRepBodies` for component-local geometry; occurrence body proxies for assembly-context measurements.
- `occurrence.transform2` to reconcile local geometry with its assembled pose.
- `body.boundingBox`, `body.volume`, `body.faces`, and `adsk.core.Cylinder.cast(face.geometry)`.
- `app.measureManager.measureMinimumDistance(bodyA, bodyB)`.

**Fusion API lengths are in centimeters.** Multiply lengths/radii by 10 for millimeters and volumes by 1000 for cubic millimeters. Angles used in the API are radians. In V6, the arm bodies were upright in their native component geometry but rotated in the closed assembly; ignoring occurrence transforms would describe the wrong pose.

Do not assume the design is parametric. Reading `design.userParameters` on the original direct design failed with `this is not a parametric design`. Check `design.designType` first. Do not convert a design merely to inspect it.

Read-only scripts can inspect while an interactive command is open. Normal editing scripts may be rejected until the user finishes or closes the command. Read-only scripts must also avoid `Application.executeTextCommand`.

## Capture and view the actual model

```sh
python3 /private/tmp/fusion_mcp.py tools/call '{"name":"fusion_mcp_read","arguments":{"queryType":"screenshot","width":1400,"height":1000,"transparentBackground":false,"direction":"current"}}' /private/tmp/fusion-view.json
```

Keep `direction: "current"` when preserving the user's view. Other supported directions include front, back, top, bottom, left, right, and isometric views; changing direction may change the viewport.

Decode the returned image locally instead of printing base64 into the conversation:

```sh
python3 - <<'PY'
import base64, json
from pathlib import Path

def find_image(value):
    if isinstance(value, dict):
        if value.get("type") == "image" and "data" in value:
            return value["data"]
        if "base64Data" in value:
            return value["base64Data"]
        for child in value.values():
            found = find_image(child)
            if found:
                return found
    elif isinstance(value, list):
        for child in value:
            found = find_image(child)
            if found:
                return found
    elif isinstance(value, str):
        try:
            decoded = json.loads(value)
        except ValueError:
            return None
        if isinstance(decoded, (dict, list)):
            return find_image(decoded)

data = find_image(json.loads(Path("/private/tmp/fusion-view.json").read_text()))
assert data, "No image found; inspect the response for a Fusion error"
Path("/private/tmp/fusion-view.png").write_bytes(base64.b64decode(data))
PY
```

Use the agent's local `view_image` tool on the resulting PNG. A document title or component list alone is not a visual inspection.

## Authorized editing and repeatable exports

For an explicitly authorized edit, send a script request with `readOnly` omitted or false. Do not silently promote an inspection request into an edit.

The working V7 approach was:

1. Export the current source as an F3D backup before modifying geometry.
2. Copy geometry and build a **new document**, preserving the user's original.
3. Use `TemporaryBRepManager` for copies, transforms, unions, and cuts; add the resulting bodies to new components.
4. Check `body.isSolid` **and** `body.lumps.count == 1`. A solid BRep can contain disconnected pieces; this happened in the first rear-bearing export.
5. Check static interferences against the manufacturer servo reference and sample the moving assembly across its travel. Exclude intentional touching faces from volumetric interference results.
   For additional tool-access or removal checks, `Design.analyzeInterference` rejected temporary BRep bodies with `InternalValidationError : pComponent`. Adding copies to a dedicated inspection component allowed those checks; delete only that newly created scratch geometry afterward. V8 uses this approach.

6. Verify motion constraints separately from geometry transformed by a script.
7. Export the assembly, printable layout, individual STLs, screenshots, and validation results into a versioned repository directory.
8. Verify STL topology, connected pieces, and bed bounds, then leave the final assembly selected.

The finished implementation is [cad/bearing_v7/build_v7.py](../cad/bearing_v7/build_v7.py). Its [README](../cad/bearing_v7/README.md) records dimensions, reprint requirements, support needs, and limits. Its [mesh checker](../cad/bearing_v7/check_meshes.py) caught disconnected exported geometry that a simple solid check missed.

Joint-specific findings:

- `AsBuiltJoints.add` rejected the direct design: **AsBuiltJointInput is only supported in parametric**.
- In the new V7 document, a construction point was created at the servo axis before enabling parametric design history.
- A rigid group connected the two arms, saddle, and horn references. Stationary occurrences were grounded.
- A revolute as-built joint was then created about the Y axis with limits 0–180 degrees.
- All three moving printed parts were checked at the midpoint, open endpoint, and restored closed pose against the expected transforms.

Fusion's API documentation query returned only a completion message for one attempted search. Reading specific installed API `__doc__` strings through a read-only script was a useful fallback, for example `adsk.fusion.AsBuiltJoints.createInput.__doc__`. Use the installed API rather than guessing signatures.

**Exporting an F3D locally does not save the document to the user's Fusion cloud project.** New tabs remained unsaved even after successful local exports. Report the actual local artifact paths; do not claim a cloud save.

## Unsaved tabs and approval boundaries

### Property updates observed on 2026-10-29

Repeated empty replies from the listening local server persisted after toggling
the server and closing Preferences. The user's restart of Fusion restored the
connection. The first script took about 72 seconds to initialize and finish;
the 50-component metadata update took about 312 seconds. Increase the HTTP
client timeout for these operations and poll its running process while keeping
the user informed. A timeout does not cancel the Fusion operation.

The root component's name cannot be assigned, even to its existing value.
Use ASCII Python source with Unicode escape sequences when matching original
non-ASCII component names through MCP. Repeated hardware with the same part
number must use a common specification description rather than differing
location text. Keep placement information in component names.

After a script failed a final assertion, local names and attributes reverted,
while cloud-backed part numbers/descriptions persisted. Inspect the committed
state in a separate read-only request before retrying. Final V9 verification
checked all 50 component identities and body volumes with zero mismatches.

Repeated generator runs created temporary assembly, layout, coupon, and imported-source tabs. Automatic approval review rejected a cleanup script using `document.close(False)` because closing unsaved documents could discard work. The safe completion path was to leave those tabs open, verify/export the final assembly, and keep it selected.

Do not repeat that cleanup or work around a rejection. If cleanup is wanted, identify the exact tabs and obtain explicit authorization to discard them, or let the user close them. The original V6 document was verified unmodified at completion.

## What CAD checks do not establish

No MCP operation here moved real hardware. Collision-free CAD, a working Fusion joint, and manifold STLs do not prove physical fit, bearing load capacity, weather sealing, or telescope clearance. Preserve the project's hardware safety rules and distinguish measured CAD dimensions from physical test results.
