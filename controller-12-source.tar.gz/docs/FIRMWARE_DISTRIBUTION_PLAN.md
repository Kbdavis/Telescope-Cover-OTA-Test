# Firmware distribution and first-install plan

Status: implementation started 2026-11-11. Build identity, isolated candidate
packaging and a guarded esptool-js browser installer are implemented; see
[INSTALLATION.md](INSTALLATION.md). No public release, hosted installer or
hardware support claim is established. Project licenses and first-beta scope
were selected on 2026-11-12; see [the release decisions](RELEASE_PLAN.md#agreed-first-beta-scope--2026-11-12).
Production multi-turn USB packaging is implemented. Physical acceptance and
dependency clearance remain pending; production wireless updates are a separate milestone.

Follow-up implementation: read-only browser release discovery, compatibility
preview validators, an offline signing prototype and Firmware updates UI now
exist in the working source. See [implementation and remaining gates](FIRMWARE_UPDATE_PLAN.md#11-discovery-and-offline-signing--implementation-handoff).
The owner requires initial USB installation followed by optional user-confirmed
webpage installation with automatic discovery. The discovery-only increment does
not fulfill that complete requirement or make the existing public candidate
OTA-capable. Production trust/authorization, capability/catalog deployment,
startup integration and hardware qualification remain gated.

## Objective

Let a user install Telescope Cover on a supported controller without obtaining
the repository, VS Code, PlatformIO, or a compiler. Provide a downloadable,
versioned complete installation image and a browser-based USB installer as the
primary end-user path, with standalone download/recovery instructions.
Keep a documented USB recovery route available throughout the product life.

The first release should use USB. Wireless updates are a separate milestone
with their own safety and recovery gates; packaging must not enable OTA merely
because an OTA-compatible partition layout exists.

## Current project foundations

- The packager builds `web_control_multiturn_usb` with a distinct `multiturn_usb`
  binary descriptor and exact stationary RAM startup setup. Factory-profile
  `web_control_usb` remains a separate build and is rejected for this beta.
  Probe/development builds remain excluded. The default `esp32dev` is a scaffold.
- `tools/embed_ui.py` embeds the web UI in the application. A separate UI
  filesystem upload is not currently part of installation.
- `tools/firmware_build.py`, `tools/check_firmware.py`, and
  `tools/ota_manifest.py` validate build artifacts and produce application
  metadata. Reuse appropriate checks rather than creating competing rules.
- An OTA application manifest is not an ESP Web Tools installation manifest.
  Use distinct names and validate both against their respective consumers.
- The current production partition table is `partitions/cover_4mb.csv`, with
  NVS, OTA metadata, two application slots, SPIFFS, and a coredump partition.
  Packaging must use the actual selected build's layout.
- OTA uploads are currently blocked pending release gates. See
  [OTA_IMPLEMENTATION_PLAN.md](OTA_IMPLEMENTATION_PLAN.md) and
  [OTA_INVESTIGATION.md](OTA_INVESTIGATION.md).
- The firmware already validates ST3215 configuration at startup. See
  [SERVO.md](SERVO.md) for commissioning and the separate read-only diagnostic
  build.

## Intended user experience

1. Identify the supported board revision and servo, read the short setup
   requirements, and disconnect the mechanism for initial commissioning.
2. Connect the controller using a USB data cable. Follow board-specific power
   instructions; USB availability does not establish that the servo is powered.
3. Open the installer, select the supported hardware and release, and choose
   the USB port. After USB permission and connection, inspect the partition
   layout and show the installed version if it can be identified reliably.
4. Explain whether the selected operation erases settings. Obtain an explicit
   choice before a destructive clean installation. A fresh install erases flash
   and writes the complete matching image. An incompatible/unrecognized layout
   must not silently enter a settings-preserving update path.
5. Flash, verify the written image, and reboot. Distinguish flash success from
   successful firmware startup and from successful servo validation.
6. Join the setup hotspot, configure home Wi-Fi, and reconnect through the
   controller's local address or IP address.
7. Review startup checks, correct any hardware/configuration problem, and
   establish safe mechanical limits before supervised endpoint teaching.
8. Confirm settings survive reboot and that no motion occurs automatically.

Provide an equivalent download-and-flash path for users who cannot use the
browser installer. Neither path should require the source repository.

## Hardware compatibility

- Establish an exact supported Waveshare board name/revision, ESP32 family,
  flash size, UART pin mapping, bus circuitry, supply requirements, and servo.
- Initially scope support to the validated ESP32/ST3215 combination. Other
  ESP32 boards must not be treated as compatible based on chip family alone.
- Verify flash size, mode, frequency, crystal assumptions, and bootloader
  settings against the real board and generated build metadata.
- Document automatic bootloader entry and manual BOOT/RESET recovery, if
  applicable to the supported revision.
- Document USB serial driver requirements and serial-port selection on each
  tested operating system. `/dev/cu.usbserial-0001` is a historical example,
  not a universal device path.
- Distinguish USB flashing/monitor baud from the separate servo bus baud.
- Decide how future hardware revisions receive separate images/manifests.
  Automatic chip detection cannot prove external wiring or board identity.

## Release artifacts

Proposed release contents, with final naming to be decided:

| Artifact | Purpose |
| --- | --- |
| Versioned factory/install image | Complete USB installation on a blank or replacement board |
| Browser installation manifest | Exact hardware family, image URL, version, and flash offsets |
| SHA-256 checksum file | Detect corrupt or mismatched downloads |
| Release metadata | Commit, build environment, toolchain, partition/settings schemas, supported hardware |
| Installation and recovery guide | Instructions usable without the repository |
| Release notes | Changes, limitations, compatibility, upgrade/downgrade restrictions |
| Application update image, later | Updates through a separately validated supported update path |

Keep ELF/map files and build logs as maintainer debugging artifacts, with a
retention policy. Do not distribute private device backups as release images.

### Image assembly

- Assemble the bootloader, partition table, required boot/OTA initialization
  data, and application from the same validated build.
- Derive component paths and offsets from the build; do not copy offsets from
  a tutorial or an unrelated ESP32 variant.
- Select and pin the image-merging tool. Validate merged image start address,
  flash parameters, segment bounds, overlaps, and total flash capacity.
- Verify application capacity against both slots and retain the existing
  descriptor/profile/ELF identity checks where applicable.
- Confirm how padding or gaps in a merged image affect NVS, OTA metadata,
  filesystem contents, and other existing data when flashed.
- Never assume a merged image preserves settings. Label a factory image as
  a clean-install artifact until preservation behavior is explicitly tested.
- Verify the published installer manifest references exactly the released
  bytes. Fail packaging on missing components or mismatched metadata.
- Verify the actual first-install image/upload manifest includes every required
  boot component. An application-only upload must not leave a vendor partition
  table in place; checking a partition file on disk alone does not establish this.
- Reject diagnostic, heartbeat-test, reduced-log, or other test profiles from
  the production release workflow.

## Clean builds, credentials, and provenance

- Build from a clean tagged commit in an isolated environment with pinned
  dependencies. Prevent untracked developer configuration from entering it.
- Exclude `wifi_local.h`, `ota_local.h`, credentials, per-device secrets,
  saved calibration, NVS dumps, backup images, and personal network addresses.
- Confirm fallback network behavior when compiled credentials are absent.
- Audit defaults for telescope addresses and other bench-specific values.
  Initial setup must not silently target somebody else's telescope.
- Do not embed one shared OTA secret in every distributed image. Define
  per-device provisioning before releasing authenticated wireless updates.
- Record source commit, build tools, dependency versions, and artifact hashes.
  Document remaining nondeterministic build inputs rather than claiming
  byte-for-byte reproducibility without testing it.
- Check dependency and firmware redistribution licenses and required notices.
- Protect publishing credentials, use least-privilege release jobs, and decide
  whether to sign releases or publish build attestations. Checksums alone do
  not establish authenticity if an attacker can replace both image and hash.

## Browser installer and download hosting

The implemented guarded installer uses pinned **esptool-js 0.7.1** directly;
an ESP Web Tools-compatible manifest is also supplied. See the
[release plan's browser workflow and timing budget](RELEASE_PLAN.md#browser-usb-installation-and-complete-image).
GitHub Pages is the selected HTTPS host, with versioned firmware downloads in
GitHub Releases. Hosting and physical browser qualification remain pending.
Initial qualification targets macOS Chrome/Edge; other host systems remain unverified.

Partition comparison requires additional installer logic after the user grants
USB access. Distinguish blank, recognized compatible, incompatible/unrecognized,
and unreadable layouts; a read failure must not become an erase decision.
Prompt before destructive installation and leave flash unchanged on cancellation.
The controller's own web UI cannot supply this check when the existing layout
prevents firmware startup. Install all matching boot/application components on
fresh installation; do not repair only the partition table. Original-firmware
backup is optional and separate from the normal installation time budget.

- Host the installer and versioned artifacts over HTTPS; test browser serial
  support and secure-context requirements on supported OS/browser combinations.
- Provide useful unsupported-browser guidance and an independent download.
- Pin or self-host installer dependencies according to the chosen maintenance
  policy; consider integrity checks and availability of external assets.
- Handle manifest fetch errors, CORS, cache invalidation, stale pages, removed
  releases, and interrupted downloads. Keep released version URLs immutable.
- Clearly identify board, version, prerelease/stable status, erase behavior,
  and known limitations before connecting or writing.
- Distinguish USB permission denial, port busy, wrong port, missing driver,
  bootloader failure, transfer interruption, and post-flash boot failure.
- Explain that serial monitors and other tools may need to release the port.
- Offer progress, verification results, retry instructions, and accessible
  keyboard/screen-reader behavior.
- Do not imply that browser flashing validates the servo or cover mechanism.
- Decide hosting location, release retention, withdrawal procedure, and how
  users discover a newer stable release without being forced to upgrade.

## First boot and servo commissioning

- No automatic movement, homing, centering, or test sweep on first boot.
- Validate configured ID, model 777, mode 0, minimum 0, maximum 4095, phase 0,
  resolution 1, and offset 0. Reject failed reads and retain bounded retries.
- Validate torque and stable position feedback before authorizing control.
  Do not infer actual enclosure position from stored state alone.
- Improve setup feedback if needed: show observed versus expected values,
  distinguish communication failure from configuration mismatch, and provide
  read-only diagnostic export without requiring a working Debug tab.
- Avoid concurrent UART access: diagnostics and setup checks must use the
  existing hardware owner/controller boundary, not direct web-handler reads.
- Define guidance for a servo with another ID or baud rate. Do not silently
  rewrite IDs, broadcast writes, or assume only one servo is attached.
- Do not automatically repair EEPROM or use Waveshare SC-series setup code.
  If a future repair tool is desired, separately design explicit authorization,
  supported model checks, before/after records, exact writes, readback,
  interruption recovery, and mandatory mechanical recalibration.
- Missing application calibration should lead to safe-limit setup and endpoint
  teaching. Replacing the servo on an existing controller also requires a
  deliberate review of old limits/endpoints; valid stored data is not proof
  that it fits the replacement mechanism.
- Present physical-sensor status honestly. A valid shaft encoder does not prove
  that the cover is physically closed or safe for unattended weather protection.

## Network onboarding

- Verify hotspot naming, credentials/access policy, recovery access, and
  instructions without relying on hard-coded developer Wi-Fi settings.
- Explain supported Wi-Fi band, failed credential handling, and fallback AP.
- Test captive-portal behavior and provide a direct IP fallback.
- Cover phone/laptop switching away from a hotspot with no internet access,
  mDNS failure, client isolation, and changing DHCP addresses.
- Keep passwords out of diagnostics and downloads. Explain what a factory
  reset removes and how to recover after network settings are lost.
- Verify the complete workflow when the servo is absent. Recovery setup must
  remain explicitly separated from permission to move the mechanism.

## Updates, settings, and rollback

- Distinguish new installation, compatible update, factory reset, and recovery
  in artifact names and user instructions.
- Define a version/settings-schema/partition compatibility matrix, including
  which older releases can be upgraded or downgraded safely.
- Decide how NVS migrations work and how invalid or interrupted migrations
  return to a safe, recoverable state.
- Test preservation of Wi-Fi, calibration, motion settings, and other supported
  preferences for every advertised non-destructive update path.
- Treat partition changes as a separate migration, not an ordinary update.
- Define stale browser-page handling after firmware changes so old controls
  cannot submit incompatible commands.
- USB flashing bypasses application-level motion interlocks. Require physical
  support/disconnection and stationary equipment in flashing instructions;
  do not promise torque retention through a USB installation.
- Wireless updates remain gated by the existing OTA plan, including motion
  exclusion, startup acceptance, interrupted-transfer recovery, and rollback.
- Define when to withdraw a bad release and how users recover without needing
  a functioning network or application firmware.

## Validation and release gates

Automated checks should cover packaging and manifest correctness, production
profile selection, component bounds, checksums, missing inputs, exclusion of
local secrets, and existing firmware/driver safety tests.

Hardware acceptance should include:

- Blank board installation using only published artifacts and instructions.
- Replacement of factory/vendor firmware, with backup guidance where needed.
- Browser partition inspection, mismatch confirmation, cancellation without
  flash changes, and read-error handling; measure actual installation phases.
- Fresh installation with no servo, valid servo, nonresponding servo, and
  invalid configuration simulated safely without corrupting working hardware.
- First-boot hotspot, home-network setup, invalid credentials, and AP recovery.
- No automatic motion on flashing, reboot, missing calibration, or failed checks.
- Calibration and settings persistence across power cycles.
- Supported OS/browser/cable/driver combinations and manual bootloader recovery.
- Interrupted flashing, unplugged USB, failed verification, and successful retry.
- Compatible update preservation and deliberately destructive reinstall behavior.
- Downgrade/migration rejection and recovery for supported version combinations.
- Public artifacts downloaded after publication: hashes, manifest URLs,
  flashing, UI version, and startup behavior must match the release record.

Use disconnected or safely supported hardware for failure testing. Hardware
installation success does not establish unattended weather-protection safety.

## Suggested implementation sequence

1. Confirm supported hardware and freeze the initial USB release contract.
2. Add an offline packager that consumes the validated production build,
   assembles the installation image, and emits hashes and release metadata.
3. Add meaningful packaging tests and clean-build credential checks.
4. Write standalone installation/recovery instructions and test the downloadable
   artifact on a fresh board without using the repository.
5. Add the browser manifest and installer, then test the full onboarding flow.
6. Promote the exact accepted candidate to an annotated tag and draft GitHub
   prerelease without rebuilding; any publication automation must preserve the
   tested bytes and remain gated on acceptance and owner authorization.
7. Publish the first supported release and retain its exact artifacts.
8. Address OTA separately after its existing release gates pass.

## Remaining decisions and evidence

Version, public audience, GitHub Releases/Pages hosting, licenses, macOS-first
qualification and supervised-only scope are settled in RELEASE_PLAN.md. The
following items require evidence or implementation rather than reopening those choices:

- Exact initial board revision and flash-size support.
- Exact candidate commit, production multi-turn build environment, and retention location.
- Physical qualification of the pinned installer on the advertised macOS browsers.
- Validate the destructive clean-install path; settings-preserving updates are
  excluded from the first beta.
- Optional existing-vendor-firmware backup and user-facing restoration guidance.
- Firmware defaults for network security and telescope integration.
- Setup diagnostics presentation and whether register mismatch details need
  new firmware/API/UI work.
- Release signing, retention, support-log export, privacy, and license notices.
- Hardware evidence required to label a release supported rather than beta.

## Completion criteria

A new user can obtain a published artifact, install it on explicitly supported
hardware, configure networking, understand servo-check failures, and complete
supervised cover calibration without the repository. Failed installation has
a tested USB recovery path. Release files contain no developer secrets, and
the documentation accurately distinguishes installation, updates, and the
mechanical validation still required before unattended use.
