# OTA and WiFi diagnostics implementation plan

Webpage-update follow-up: the working source now includes read-only release
discovery/UI, compatibility preview checks and offline signing tests. See
[FIRMWARE_UPDATE_PLAN.md](FIRMWARE_UPDATE_PLAN.md#11-discovery-and-offline-signing--implementation-handoff).
Production receiver defaults, private development credentials, maintenance
admission and servo startup behavior are unchanged. No new image was installed.

The redundant `web_control_wifi_test` alias was removed during release cleanup on 2026-11-12; production already uses the same log capacity. Dated experiment records below are preserved.

Current development policy (2026-10-29, explicitly requested): updated receivers
advertise signed `development-recovery`. Firmware replacement can proceed while
FAULT, uncalibrated, in unfinished teaching, outside saved limits, or blocked by
critical configuration validation. Recovery admission requires idle motion with
no holding, fresh model 777, confirmed torque OFF, and two successful stable raw
position reads inside 0–4095. It performs no configuration/goal/torque writes and
does not call fault recovery. Reboot runs the normal stationary startup checks;
no interrupted movement resumes. Authentication, STA-only access, maintenance
exclusion, worker pauses, resource reserves, Stop, transfer validation and durable
startup checks remain enforced throughout. Production rejects this policy and
retains CLOSED admission. Receiver startup acceptance remains independent of
calibration readiness, so recovery firmware can boot with unfinished calibration.

Use the updated client:

```sh
python3 tools/ota_upload.py upload-dev .pio/build/web_control_dev --host 192.168.1.43
```

Older receivers still enforce their installed policy and need one legitimate
bootstrap via USB or their existing OTA admission. Do not invent calibration or
move the mechanism merely to gain update admission. Saved calibration and its
reference basis remain unchanged by firmware recovery. Tests cover faulted,
dirty, uncalibrated and invalid-configuration admission, fresh-read failures,
energized/moving rejection, clearance revocation and safe cleanup. The older
signed `development-stationary` policy remains supported for compatible clients.

Live bootstrap (2026-10-29): the old receiver rejected the recovery bootstrap
because calibration was incomplete. It was installed over USB as probe ELF
`c620604280950da091a81c31c8a43d94614b5566e3824fc69bc6abf68fa39911`,
without changing servo offset 85, saved calibration or application settings.
The next wireless update was admitted with UNKNOWN, ready false, calibrated
false and torque OFF. Transaction `5f840187aad285fb1e6ff65f5d5f6794`
received 209,920 bytes before STA disconnected (ASSOC_LEAVE, RSSI about −80 dBm).
Maintenance revoked on network loss and the transfer stopped with `tcp_ack`;
boot selection was never committed, the source kept running and torque stayed
OFF. Recovery admission worked; this attempt did not establish completed OTA.
Automatic STA recovery rejoined the LAN and closed its fallback AP after the
normal delay; maintenance was idle and OTA became available again on the same
boot before a deliberate follow-up attempt. Evidence is archived under
`diagnostics/2026-10-29-reversed-open/recovery-*.json`.

That follow-up completed: transaction `26443850ad81d7c4623c8d0dc61167ae`
installed normal `web_control_dev` ELF
`48b0e6f2200124c6ac47fc4ef7d0931a758d8225cf510d505af4e82c4ad74788`
from slot 0x10000 to 0x150000. Startup accepted, running identity matched the
manifest, and durable selection/completion were confirmed. Admission occurred
with ready false, calibrated false and torque OFF; the unsaved dirty flag had
reset to false during USB bootstrap. Faulted/dirty/invalid-configuration recovery
is covered by host and real-worker integration tests, not induced again on the
hardware solely to exercise OTA. Final state UNKNOWN, position 3921, torque OFF,
factory offset 85 and all 40 bytes matching. Saved CLOSED 1147 / OPEN 3140,
reference 1328 and profile remain review evidence unchanged; normal movement
requires fresh calibration. The commission-only reference routes are absent
from the final normal development build. No movement was commanded during
either transfer. The intermittent weak Wi-Fi remains a separate limitation.

Validation: 43 OTA tool tests; production/development manifest and maintenance
host suites; production/development actual-worker integration; all three
firmware builds; and the live completed uncalibrated OTA above passed.

Previous development policy (2026-10-28, superseded): development OTA
accepts any stationary position with clean saved calibration, valid configuration,
stable feedback inside the active limits, and confirmed torque readback. No motion
or supervised holding is allowed. Authenticated maintenance, worker pause, heap,
generation, Stop, transfer and reboot checks remain. The receiver advertises and
accepts the signed `development-stationary` policy only in development builds;
production rejects it and retains the CLOSED policy. The uploader no longer needs
`--closed-cover` for an updated development receiver. Older receivers require
their existing CLOSED admission once to install this revision. No draft is saved
implicitly. See README for current commands.

Previous policy (2026-10-25): routine OTA requires CLOSED with fresh, stable
encoder readings within 10 counts of the saved closed endpoint. Torque may be
ON or OFF and is preserved. Use `--closed-cover`; see README local development
OTA for migration and reboot behavior. Historical OFF-policy experiments in
this plan remain historical evidence, not the current routine admission rule.

Updated 2026-10-23, America/Phoenix.

Implement push OTA and remote diagnostics as coordinated maintenance features
of the telescope-cover controller. Keep Arduino/PlatformIO, the existing flash
layout, and USB recovery. The first OTA release requires a mechanically
supported cover and explicitly verified torque OFF. Retained-torque updates
follow as a separate release after cross-image recovery is proven.

All optional live metrics belong inside one collapsed-by-default expandable
section on the Debug page. Opening that section explicitly starts collection;
closing it stops collection when no other visible viewer has it open. Merely
enabling the Debug tab or polling normal status must not start metrics work.

This is the active implementation sequence. It incorporates the
[OTA investigation](OTA_INVESTIGATION.md) and supersedes its proposed ordering
and receiver choices. Historical measurements in that investigation retain
their original dates and scope. Planned APIs and modules below do not yet exist
unless marked complete.

## Development scope decision (2026-10-23)

The user has explicitly chosen routine local **development OTA**, with USB
recovery available, and deferred the remaining production-hardening gates. This
supersedes the earlier requirement that every remaining release test block any
live upload CLI. It does not claim production/unattended readiness or make USB
reflashing a guarantee of preserved settings/mechanical safety.

`web_control_dev` is a persistent opt-in receiver build. Its separate ignored
`ota_dev_local.h` is consumed only under `COVER_OTA_DEVELOPMENT`; the normal
builds keep their existing disabled defaults. Setup creates a paired owner-only
`.ota-dev/secret` and header without printing/rotating the credential. The
validated development image retains an explicit marker and reports
`ota.development=true`. Product/profile/settings compatibility stays unchanged
because this is the same controller/application protocol, not a new hardware
family. Incompatible probe/test profiles cannot combine with this build flag.

`tools/ota_upload.py upload-dev` requires a literal STA IPv4, explicit
supported-cover/OFF confirmation, a development-marked artifact and an already
bootstrapped development receiver. It uses the existing authenticated workflow,
image checks, maintenance arbitration, startup acceptance and durable verdicts.
A successful candidate keeps development OTA enabled for the next update.
The production `upload` command and reserved production OTA upload target remain
blocked. The previously exercised 98,304/65,536-byte development guards and
20-entry log remain; the production memory reserve is still deferred. No
motion/torque commands or implicit metrics activation are part of the uploader.

USB bootstrap and a real full development OTA update passed; the development
receiver remains installed and available. Hardware results are recorded at the
end of this plan. Development credentials and
images remain local/private; they must not enter published firmware packages.

## Current implementation status

| Work | Status |
| --- | --- |
| Explicit USB and build-only production OTA environments | Implemented in `platformio.ini`; OTA device targets and the fallback upload command reject uploads |
| Routine development OTA | `web_control_dev` USB bootstrap and real `upload-dev` update passed; receiver remains enabled, normal defaults and production upload gates remain closed |
| Pinned partition table and binary size checks | Implemented; generated tables match the installed Arduino default byte-for-byte, including NVS and both application slots |
| Internal heap, largest block, log allocation and task stack diagnostics | First complete nonactivating transfer measured over passive USB with read-only monitoring enabled; broader workload reserves remain unresolved |
| Debug CPU panel | Stationary activation, warmup, shared viewers, stale-request fencing and OFF/expiry checks passed in the 50-entry build; interrupt-count, overhead and accuracy acceptance remain pending |
| Local build baseline | Current frozen production image: 1,045,600 bytes, leaving 265,120 bytes per slot; static DRAM 53,336 bytes. Build size is not a runtime memory margin |
| Shared important events and read-only WiFi capture | Package 1B implemented locally; runtime workload/latency measurements remain pending |
| Maintenance arbitration and client generations | Package 2 implemented locally; hardware race/latency validation remains pending |
| WiFi regression / controller log | Production default is 20 entries (2,480 bytes); full transfer passed a supervised 96 KiB test guard; production reserve approval remains pending |
| Authenticated receiver and startup recovery | Full transfer, healthy activation, pending-first-boot reset rollback, interrupted TCP upload, authenticated cancellation, explicit Stop and subsequent same-boot retry verified; normal OTA remains disabled |
| Durable update outcome, startup acceptance and rollback | Healthy acceptance, pending-first-boot reset rollback, autonomous RTC-watchdog recovery before/during setup and manual receiving-phase and post-intent/pre-selection power-loss recovery verified; cuts inside journal/selection writes and remaining timing gates stay pending |
| HTTP input bounds | Project-owned incremental parser and adapter pass local sanitizer tests and initial stationary STA boundary checks; full-workload memory and response/Stop-latency gates remain pending |
| Retained torque | Deferred to package 6; OTA admission requires supported cover and confirmed torque OFF |

The controller debug ring now holds 20 messages, using 2,480 bytes plus small
allocation/object overhead. The browser retains its separate 1,000-group
history. The former 124,000-byte controller allocation is not the default.
Neither image headroom nor
static RAM usage establishes runtime OTA headroom. Use the
[resource baseline procedure](DEBUGGING.md#ota-resource-baseline), then repeat
measurements as logging, receiver buffers and tasks are added.

## Design boundaries

- Only the servo-owning worker may validate or change servo state. Logging,
  capture and OTA transport never write servo registers or renew supervision.
- Never flash during movement or browser-supervised holding. Preserve the
  existing 500 ms heartbeat. Explicit Stop and unexplained motion faults retain
  their existing torque-release semantics.
- OTA writes application slots only. Preserve calibration/NVS offsets and
  backward-compatible settings. No filesystem, partition-table, bootloader or
  servo EEPROM updates through the receiver.
- Diagnostic loss is reported as diagnostic loss. It is not permission to
  resume motion, clear a fault, accept an image or release an update lock.
- Optional metrics are OFF after boot, page load and reboot. With no active
  viewer, perform no metric-specific timer interrupts, heap/stack sampling,
  history collection, polling, rendering or periodic metric output. Existing
  motion safety, operational telemetry and event logging remain independent.
- USB remains the path for early boot output, live panic output and firmware
  recovery when networking cannot start.

## Architecture and ownership

```mermaid
flowchart LR
    Events[Important application events] --> Ring[Existing bounded RAM ring]
    Events --> SerialQueue[Bounded serial queue]
    Trace[Detailed timing traces] --> SerialQueue
    Ring --> HTTP[Bounded HTTP log batches]
    Snapshot[Resource and OTA snapshots] --> HTTP
    HTTP --> Capture[Mac capture files]
    Host[OTA host wrapper] --> Admission[Authenticated maintenance admission]
    Admission --> Cover[Servo worker clearance]
    Admission --> OTA[OTA receiver task]
    OTA --> Slot[Inactive application slot]
    OTA --> Journal[Durable transaction summary]
```

| Component | Responsibility |
| --- | --- |
| `web_control` and maintenance model | Sole actuator authority; reserve/acknowledge/revoke maintenance ownership, drain work and reconcile torque |
| `ota_service` | Own transaction deadlines, receiver lifecycle, transport and all OTA API calls |
| `ota_handoff` and startup health | Interpret durable transaction state across firmware versions and rollback; accept or reject pending images |
| Diagnostics | Bounded events, counters and snapshots; no control decisions or transport writes from producers |
| Existing HTTP loop | Short request handlers, capped responses, command submission and status retrieval |
| Host wrapper and capture tool | Store evidence on the Mac, transfer firmware, reconnect and verify results; capture remains read-only |

Use a small project-owned receiver compatible with the installed espota wire
protocol. Put Espressif's OTA APIs behind a testable flash-writer boundary.
The OTA task exclusively owns begin/write/end/abort and boot selection; other
tasks signal requests. Do not modify installed framework packages or terminate
the task during a flash operation.

`network_setup` continues to own WiFi and mDNS. The receiver neither starts nor
ends the shared mDNS responder. Initially use a reserved numeric controller IP,
UDP 3232 for invitations and a fixed host TCP listener on 3233; diagnostics
reuse HTTP port 80. Bind invitations to the confirmed STA address and disarm
admission on link/interface changes before fallback AP exposure. AP recovery
must not release the OTA maintenance lock: network recovery and completed
flash/torque cleanup are separate conditions.

This resolves the stock ArduinoOTA callback and deadline limitations identified
in the investigation. Espressif separates image validation with `esp_ota_end()`
from selection with `esp_ota_set_boot_partition()`, allowing a verified image and
durable handoff before activation. Using these APIs does not require migrating
the application to ESP-IDF. [ESP-IDF 4.4.7 OTA API](https://docs.espressif.com/projects/esp-idf/en/v4.4.7/esp32/api-reference/system/ota.html)

## Conflict analysis and resolutions

| Conflict | Resolution |
| --- | --- |
| Mirroring all serial traffic versus useful log retention | Share selected important events. Keep per-heartbeat/per-packet traces on serial and summarize their counters remotely. Never mirror the complete serial stream automatically. |
| WiFi diagnostics versus scarce RAM | Use the approved 20-entry controller ring without enlarging entries. Put boot/build identity in the response envelope; keep structured OTA state in a small fixed snapshot. Allocate no per-client history on the ESP32. |
| Hidden metrics versus background overhead | Gate collection on an explicit, expiring viewer lease. Stop the CPU timer and optional heap/stack work when the last lease ends; hiding values alone does not meet the requirement. |
| Multiple viewers versus stopping collection | Share one sampler. Closing one panel releases only that viewer; stop collection after the last active panel closes. General status readers and capture clients never implicitly enable it. |
| Default-OFF metrics versus OTA safety checks | OTA admission/startup checks may measure memory when their transaction requires it. They do not start the optional display sampler and must not depend on whether a browser panel is open. |
| Log retrieval versus heartbeat and HTTP responsiveness | Producers never wait for consumers. Keep HTTP batches bounded and suspend debug draining during movement/holding as the browser already does. Tighten the budget further during transfer. |
| WiFi outage versus capturing WiFi failures | Retain important disconnect/reconnect events in RAM while the link is down; the host fetches them after reconnect. Report overwritten history. A reset loses the RAM ring; USB and the durable OTA summary cover different failure cases. |
| Reboot versus sequence continuity | Identify each boot independently of firmware identity. A reboot of the same image must reset the capture cursor. Detect resets between requests and return one consistent boot envelope per response. |
| Progress reporting versus transfer performance | Update a fixed snapshot after chunks; log phase transitions immediately and progress at most once per second. No log or flash write for every packet. |
| Cancellation versus deliberate torque retention | Cancel requests the OTA task to stop before activation and reconcile the agreed stationary policy. Explicit Stop releases torque and revokes clearance. Capture failures never issue Stop or cancel. |
| Flash operations versus task deadlines | Admit OTA only when stationary. Account for flash stalls in measured HTTP/Stop latency; a second core cannot provide a motion-grade timing guarantee. |
| Durable outcomes versus flash wear and write contention | Persist a small versioned transaction summary at defined checkpoints. Keep ordinary logs in RAM and on the Mac. Serialize NVS checkpoint writes with OTA writes; block settings/reset operations during the transaction. |
| Diagnostic failures versus startup rollback | A missing host/capture client never fails health checks. Critical service/task/allocation failures may require rollback; a real servo fault leaves motion locked without a firmware rollback loop. |
| Recovery AP versus OTA security | The initial receiver arms only with STA connected and the setup AP inactive. Close/cancel the receiver before fallback AP exposure. Keep minimum setup/recovery status available on the AP; deny detailed log downloads and update control there. |

Flash erase/write can affect cache execution and scheduling across cores. The
stationary admission rule is the safety boundary, even with separate tasks.
[ESP-IDF flash concurrency constraints](https://docs.espressif.com/projects/esp-idf/en/v4.4.7/esp32/api-reference/storage/spi_flash.html#concurrency-constraints-for-flash-on-spi1)

## Shared diagnostics design

### On demand metrics panel and collection lifecycle

Use one expandable section labeled Controller metrics on the Debug page,
implemented as an accessible disclosure control such as `details`/`summary`.
Keep it collapsed after each page load and controller reboot, without a saved
auto-open preference. Move the CPU panel into it alongside internal heap and
largest block, per-task stack headroom, log availability/counters, loop timing
and available network health fields. Reuse existing measurements for normal
servo/network status; opening this section never requests extra servo reads.

The controller, not just the browser, owns this lifecycle:

```text
OFF -> STARTING -> ACTIVE -> STOPPING -> OFF
```

1. Opening the section while the Debug view is visible submits an explicit
   subscription with this boot ID, browser client ID and request generation.
   STARTING shows waiting/unavailable until collection is acknowledged and a
   fresh window exists. A pending start overtaken by close must not activate.
2. ACTIVE runs one shared sampler at the bounded rates already designed: CPU
   observation windows about once per second, heap snapshots at most once per
   second, and stack scans at most once every five seconds. Render changed
   fields without generating event-log messages. Treat CPU percentages as
   sampled estimates, with separate values for each core and their average.
3. Collapse, navigation away, hiding the page or disabling Debug immediately
   stops browser renewals, metric requests and rendering, and submits a
   best-effort unsubscribe. It sends no motion Stop or OTA cancel. Existing
   supervision rules are not changed by this lifecycle.
4. When the final subscription is released, the diagnostics owner disables
   and removes the CPU timer interrupt, releases timer resources, stops heap
   snapshots and stack scans, and invalidates cached metric windows. It
   acknowledges OFF only after collection is stopped, not when stop is queued.
5. If close/unsubscribe is lost, the viewer lease expires. Reopening requires
   fresh collection and a new counter baseline; never display an old window as
   current. No automatic resubscription after reboot or background reconnect.
   On expiry, rejected renewal or a new boot, collapse the section and require
   another explicit open instead of silently restarting collection.

Start with a five-second lease renewed at most every two seconds while the
panel remains visible and expanded. Bind renewals to the explicit subscription
generation through explicit POST `/renew` requests scheduled by the existing
browser service loop. Ordinary status requests never renew or create a lease.
The explicit subscribe/renew/unsubscribe endpoints are under
`/api/diagnostics/metrics/`, using existing local session/client validation
and STA-only access; these endpoints
have no actuator, settings-write or OTA privileges.

Maintain a small fixed-capacity subscription table, with no per-viewer history
or task. Return busy when full. The last-close rule applies across viewers:
another deliberately opened visible panel can keep the shared sampler active.
Use generation checks so delayed unsubscribe/retry messages cannot revoke a
new subscription or restart a closed one. Serialize start/stop and timer
allocation on the diagnostics owner; request handlers only submit lifecycle
changes. Validate lease expiry even when a browser disappears without notice.

OFF means no optional metric acquisition or timer activity. The minimal
enable-state/lease checks in existing service loops are the control mechanism,
not a background sampler. Stop checks must remain bounded if serial output or
the network is slow. On a clean close, the browser can report stopped only
after the final controller acknowledgment; an unacknowledged close relies on
the lease expiry and must not claim immediate remote shutdown.

Refactor all current unconditional acquisition paths, not just the CPU timer:
`beginCpuSampling()`, `pollCpuLoad()`, `noteTaskStack()`,
`runtimeDiagnostics()` calls from `/api/status`, and expanded periodic serial
HEALTH/STACK collection. When OFF, normal status returns an inactive metrics
descriptor without running heap walks, stack scans, CPU calculations or
formatting historical values. Existing baseline status fields and operational
diagnostics can continue at their existing cadence. Guard the new optional
work before allocation/acquisition rather than discarding its output later.

OTA memory admission and startup health remain separate explicit operations.
They perform necessary checks on demand even when the panel is closed, without
starting the CPU sampler or renewing a viewer lease. CPU load is never an
actuator or OTA safety interlock. During transfer, optional diagnostics remain
subordinate to the maintenance budget and may report paused/unavailable; the
host cannot force collection by polling status.

The Mac capture tool observes optional metrics only while a user has explicitly
opened the panel. Default capture cannot silently subscribe. Record inactive
or paused metrics honestly. Any later headless collection mode would need its
own explicit opt-in lifecycle; it is outside this default panel workflow.

### Event selection and storage

Keep existing `debugLog()` messages and promote BOOT, reset identity, WiFi state
transitions, task/allocation failures, maintenance admission/rejection, important
servo faults and OTA phase/outcome events to the shared event path. WiFi signal
samples, normal HEALTH/STACK samples and heartbeat traces remain serial details
or numeric snapshots/counters; do not fill the event ring with periodic samples.

Introduce one bounded event publisher used by the serial queue and RAM ring.
Refactor existing wrappers around it so an event is stored once and serial
forwarding cannot recursively publish it again. Keep the 20-entry production
allocation and existing entry size. Copy an entry under the short ring lock;
format JSON and perform network I/O after releasing that lock. Retain serial
fallback when ring allocation fails.

Use short event codes and transaction IDs within existing message storage;
report truncation explicitly. The structured OTA snapshot carries complete
phase/error fields so truncated or overwritten text is never the authority for
an update outcome. Count ring overwrites, serial queue drops, truncations and
suppressed trace messages separately. Credential values, functional verifiers,
authentication headers and WiFi/Seestar secrets never enter either sink.

### HTTP contract and reader behavior

Evolve the existing GET `/api/debug?after=<sequence>` endpoint additively. Keep
`entries`, `firmware`, `available` and `capacity` for existing consumers. Add
`schema_version`, random per-boot `boot_id`, oldest/newest available sequence,
loss counters and a continuation cursor. New readers send their observed boot
ID; a mismatch returns the new boot envelope and the oldest available records
with an explicit cursor-reset indication. Handle sequence rollover deliberately.

Retain the existing hard limit of 16 entries per response and also impose a
starting limit of 4 KiB for the whole serialized response, including metadata
and JSON escaping. Return fewer entries when needed and advance the cursor
only over entries actually returned. Measure these limits under load.
Reuse short HTTP requests;
do not add Telnet, a remote shell, a WebSocket task or a second event buffer.
Provide full-log export by iterating bounded batches on the Mac. Readers
detect missing sequences; reading never consumes entries for other clients.

Publish one consistent `ota` object through `/api/status` and the dedicated
OTA status endpoint. Include transaction ID, phase, byte counts, last progress,
error code, source/target ELF identity, selected/running slot, startup-health
state and final outcome where known. An `available=false` value distinguishes
unavailable diagnostics from an empty history.

Read-only diagnostics keep the existing trusted-LAN scope. The web session token
does not authorize updates. Detailed downloads are unavailable on the open AP;
minimum setup/status data remain redacted. Maintain server-side response and
request budgets shared by all readers, so several tabs cannot multiply the
diagnostic workload without bound.

When a diagnostic budget is exhausted, return a short busy response with retry
guidance. Reserve service capacity for Stop/cancel and the lightweight OTA
status snapshot; do not compensate by extending motion supervision. Admission
and cleanup must remain possible when bulk log downloads are suspended.

### Host capture and reconnects

Add `tools/capture_wifi_diagnostics.py`. Reuse the local artifact archival and
redaction helpers from `capture_diagnostics.py` without changing its USB default.
Capture events as JSON Lines plus periodic resource/OTA snapshots, host UTC
timestamps, device uptime, boot IDs and reconnect/gap markers. Record the
controller's reported identity separately from any selected local artifact;
never label them matching without checking. Persist the manifest and cursor
on the Mac, not on the ESP32. Use the existing ignored `diagnostics/` destination.
Archived firmware can contain compiled credentials or functional verifiers;
keep those binaries local and treat them as sensitive. Text redaction does
not sanitize a binary archive.

The initial tuning target is one bounded log batch per second while idle and,
only when metrics are explicitly active, one cached resource snapshot every
five seconds, with finite requests and reconnect
backoff. During transfer, the uploader makes at most one OTA status request per
second and capture pauses bulk log draining. A background collector obeys the
same server budget. These are starting limits to measure, not acceptance claims.

A failed request or absent client records an evidence gap and reconnects.
Neither changes controller state. After restart, reset the cursor by `boot_id`,
fetch the durable update outcome and begin a new capture segment. A random
boot ID is an identifier, not an authentication secret.

## OTA transaction and recovery design

### Admission and authentication

Use an owner plus generation/transaction token for maintenance. Reservation is
tentative until the servo worker validates fresh stationary evidence, drains
queued work and acknowledges clearance. A raced command must either finish
before clearance or be rejected; nothing moves after clearance. Only the
matching owner/generation may release the lease, so a stale network `finish()`
cannot clear an OTA lock.

Initial admission rejects faults, dirty calibration, active operations, moving
or supervised-holding states, missing required memory/log allocations, pending
image acceptance and AP exposure. Release torque only after the operator has
explicitly chosen the supported-cover/OFF policy. Recheck configuration,
position and torque on the worker; ordinary disconnected-servo network setup
is not an OTA admission exception.

### Implemented maintenance contract (package 2)

`maintenance.h` owns one fixed reservation: owner (`network`, `reboot`, `ota`
or reserved `telescope`), monotonically assigned lease generation, phase
(`idle`, `pending`, `ready`, `revoked`), reason and worker acknowledgments.
All mutations and command-queue submissions share the servo worker's short
lock. Hardware, NVS and network I/O stay outside that lock. A reservation blocks
new commands immediately; the servo worker discards queued commands and grants
clearance only after checking current state. Ordinary supervision heartbeats
remain valid while preparation is pending; clearance fences their old control
generation. No queued movement is replayed after release.

The network/reboot owner stores its exact lease and uses it for readiness and
completion. A stale, empty or different-owner completion cannot release another
reservation. Retired telescope helpers with no lease cannot obtain clearance
or release anything. Settings writes and restart phases require live matching
clearance. Stop revokes clearance and cancels further setup/restart work; a
settings record already committed before Stop is not rolled back. The initial
beta-acknowledgment NVS write also reserves the writer lock (it changes no servo
or network state); the worker drains/relinquishes that short reservation.

The internal OTA hook remains inaccessible through HTTP. Its default
requirements prohibit admission: callers must supply supported-cover/OFF
confirmation, accepted startup health and nonzero receiver-specific memory
reserves selected from measurements. No production reserve is invented here.
The worker rechecks ST3215 model/configuration, two stable in-range positions,
confirmed torque OFF, clean calibration, no motion/hold/fault, allocated log
storage and internal free/largest-block memory. It never releases or enables
torque for OTA admission and never applies the disconnected-servo setup
exception. Use explicit Stop with a supported mechanism before an eventual
OFF-policy update. Memory checks are explicit transaction work independent of
the optional metrics panel.

Registered Alpaca/native telemetry workers pause at a request boundary and
invalidate cached telescope/stow/display evidence before acknowledging the OTA
lease. Admission waits for all registered workers; resuming requires new
observations. Fresh stationary evidence is rechecked at most once per 500 ms;
a clearance older than 1,500 ms is unusable and is revoked if the worker
resumes after that gap. Preparation times out after three seconds into a
revoked reservation, without silently unlocking it.

`noteMaintenanceNetwork()` revokes OTA clearance on link/IP/interface changes.
Fallback AP exposure waits for the matching OTA owner's explicit transport
cleanup acknowledgment. AP recovery does not release that lock. The owner must
request release; the worker then requires fresh physically safe OFF evidence
and acknowledged cleanup before unlocking, even following Stop or cancellation.
Loss of STA or memory reserve no longer prevents *cleanup* once the transport
has stopped and physical safety is confirmed. Uncertain physical state retains
the lock and local USB recovery. Bulk event downloads return busy during an OTA
reservation; lightweight status and explicit Stop remain available.

GET `/api/status` now exposes `control_generation` plus the small `maintenance`
snapshot (`owner`, `phase`, lease `generation`, `reason`, `locked`). Updated
mutating requests carry the observed `control_generation`; the worker checks it
again before executing queued work. Missing/stale generations reject commands
and settings requests with 409. Generations saturate instead of wrapping;
exhaustion requires a controller restart, while explicit Stop remains available.
Automatic cleanup Stop carries `automatic=yes`,
a distinct `stop_reason`, and the generation captured by the original operation.
It never borrows a newer status generation after an error. A stale automatic
Stop is rejected; explicit and legacy Stop remain unconditional safety requests
under the existing web-session validation. No supervised hold takeover is
implemented. Legacy motion pages must be reloaded; read-only capture is
unchanged and does not acquire a lease.

The reusable owner-facing hooks are `requestOtaMaintenance()`,
`maintenanceReady()`, `confirmMaintenanceCleanup()` and
`requestMaintenanceRelease()`. Their tokens are internal ownership identifiers,
not authentication credentials. Package 3 must authenticate and own that whole
lifecycle, provide measured reserves and startup acceptance, and recheck
clearance before any flash operation. The OTA snapshot remains
`available=false`; uploads and all receiver/admission endpoints remain disabled.

### Authenticated endpoints (implemented, release-gated)

| Endpoint | Contract |
| --- | --- |
| GET `/api/ota/challenge` | Issue a bounded, expiring challenge tied to this boot; creates no maintenance reservation |
| POST `/api/ota/prepare` | Authenticate image metadata and explicit torque policy; return preparation state, not premature clearance |
| GET `/api/ota/status` | Return the same redacted transaction snapshot as normal status, without granting or renewing motion ownership |
| POST `/api/ota/cancel` | Authenticate the transaction and request cancellation; return pending until the OTA owner confirms cleanup |
| Existing explicit Stop | Remains a servo-worker safety request; also invalidates update clearance |

Use a dedicated strong OTA credential provisioned initially through an ignored
local configuration with a placeholder-only example. For HTTP control, use
HMAC-SHA256 with a separately derived control key and an expiring single-use
nonce, covering method, route, boot ID, request body digest and transaction ID
when assigned. Use existing cryptographic primitives and test replay handling.
Specify canonical signed fields and hash the exact transmitted body bytes;
reject duplicate/ambiguous fields and bound outstanding challenges.
Never send the password itself over HTTP. Preserve espota challenge/response
compatibility for the transfer, pin its sender to the prepared host, and match
the invitation's size/digest to the prepared artifact.

The working deployment scope is a trusted LAN or appropriately routed secure
tunnel. Stock espota is not encrypted and the proposed manifest does not prove
publisher authenticity. A hostile/shared-network deployment requires a separate
transport/signing decision before enabling uploads. Host secrets stay inside
the uploader process, including verbose and failure paths.

### Transfer and activation

Use this state sequence separately from cover states:

```text
IDLE -> PREPARING -> ARMED -> RECEIVING -> VERIFIED
     -> COMMITTING -> REBOOTING -> BOOT_CHECK -> COMPLETE
```

Publish `REJECTED`, `CANCELLED`, `FAILED`, `ROLLED_BACK` or `UNCONFIRMED` outcomes
with machine-readable reasons where appropriate. `COMPLETE` means the expected
firmware booted and passed health acceptance, not just that bytes transferred.

Require a production application manifest with binary length/SHA-256, embedded
ELF identity, chip/product/profile and settings/handoff compatibility versions.
Validate applicable embedded metadata on the receiver as well as on the host;
host-only checks cannot stop an incompatible authenticated sender. Enforce
size/metadata before erase where available, verify streamed digests and image
validity before selection, and reject unsupported image forms and commands.

Keep all transport operations bounded and cancellable between flash calls.
Start testing with a 60-second arming window and 180-second transfer deadline;
also bound challenge/authentication, TCP connection and stalled reads. The
dedicated task checks Stop, fault, link and deadline signals without another
task calling the OTA APIs concurrently. Pause Alpaca at a request boundary,
acknowledge the pause and invalidate stow evidence before arming.

After verification, recheck clearance and persist/read back the versioned
transaction handoff. Serialize a final cancellation check with entry into
`COMMITTING`, then select the boot slot. Report cancellation during/after that
boundary as too late or unconfirmed until boot metadata is reconciled. Do not
claim that a host timeout guarantees the old image remains selected.

Cancel before activation keeps the current boot selection and requires fresh
admission for retry. Explicit Stop/fault still releases torque; plain capture
loss does neither. Retain the maintenance lock while cleanup, activation or
physical safety is uncertain. Never replay queued motion after cleanup or boot.

### Durable summary and startup health

Use a dedicated NVS transaction record with a stable byte layout, schema,
checksum, transaction ID, source/target identities and slots, torque policy and
bounded phase/outcome fields. Limit writes to checkpoints such as activation
intent, a relevant first-boot transition and terminal outcome; no packet/progress
or ordinary-log writes. Test every checkpoint against interrupted power.

The bootstrap and future rollback-compatible images must read the same record.
OTA never relies on the linker-assigned RTC marker used for the existing
same-image manual reboot. Keep those two authorization paths distinct.
Reconcile it with running/selected partitions, pending/invalid OTA image state
and reset cause. Preserve the previous outcome until deliberately replaced.
Only report rollback when boot/image evidence supports it; otherwise expose
`UNCONFIRMED`. A successful retry must not consume stale holding authorization.

Defer Arduino's early acceptance in the first USB bootstrap. Keep movement
locked during bounded health checks for required task/service creation,
settings readability, memory/log allocation and a usable local maintenance or
recovery endpoint. Validate without moving the servo. Missing hardware,
unavailable telescope telemetry and invalid mechanical state produce the
appropriate motion fault/lock, not an endless firmware rollback cycle. Home
WiFi absence is acceptable when local AP recovery is functional; OTA remains
unavailable on that AP. A capture client is never a health prerequisite.

Provide a tested reset/watchdog path for startup hangs, including before the
health coordinator can run. Accept only after the contract passes; expose
failure/rollback results after recovery. Preserve settings compatibility in
both directions and prohibit irreversible first-boot migrations.
Startup acceptance/rollback writes occur before receiver admission is enabled,
so they cannot race a new transfer or its durable checkpoints.

### Browser supervision and retained torque

For the first release, reject browser-supervised holds rather than transferring
them. Add a control generation to the updated browser protocol before enabling
later hold takeover. Automatic Stop messages carry their observed generation
and a distinct automatic-stop reason; an old automatic message cannot revoke
a successfully acknowledged handoff. An explicit Stop remains unconditional.

Suppress browser error/visibility cleanup only after the server acknowledges
transfer of that exact generation. Before acknowledgment, existing heartbeat
and Stop behavior continues. The uploader and capture tool never pretend to
be a supervising browser.

Legacy clients cannot distinguish automatic cleanup from an explicit Stop.
Keep legacy Stop fail-safe; never silently ignore it to preserve holding.
Reject supervised takeover without an updated owner acknowledgment and require
legacy motion clients to be closed/reloaded before retained-torque validation.
If client compatibility cannot be established, use the supported-cover/OFF
workflow. Test delayed starts, heartbeats and automatic Stops across admission.

Enable retained torque only after the candidate and fallback images both
understand the durable schema. Initially support stationary endpoint retention;
supervised-hold takeover is a further opt-in capability. Match handoffs to boot
cause/image evidence and fresh servo validation; power-on/brownout must never
be interpreted as authorization to enable torque. The no-unintended-release
requirement excludes explicit Stop and genuine safety faults, and requires
instrumented software-reboot/rollback testing before a loaded mechanism test.

## Implementation packages and release gates

| Package | Deliverable | Dependencies and completion gate |
| --- | --- | --- |
| 0 Build and resource groundwork | Existing environments, frozen layout, size checks and resource snapshots | Local work complete; supported USB baseline and runtime measurements pending |
| 1A On demand metrics | Default-collapsed Debug disclosure, viewer leases, shared sampler start/stop, and gating of every optional acquisition path | Local implementation and lifecycle/browser tests complete; supported-device timer/scan/overhead measurements remain the hardware acceptance gate |
| 1B Shared diagnostics and capture | Selected event routing, boot/cursor contract, loss counters, bounded HTTP batches and read-only Mac capture | Local implementation and publisher/protocol/capture tests complete; supported-device baseline with this workload remains pending |
| 2 Maintenance arbitration and UI protocol | Owner/generation model, worker clearance, all-route exclusion, control generations and Stop/cancel semantics | Local model, actual worker-loop and browser protocol tests complete; on-device race/latency validation remains pending before a receiver can arm |
| 3 Receiver and bootstrap recovery | Espota-compatible adapter, manifest checks, authentication, durable summary and deferred startup acceptance | Implemented locally with closed release gates; bootstrap and candidate share schemas; hardware bootstrap/failure testing remains pending; uploads stay disabled |
| 4 Operator workflow | Secret-safe host workflow, transfer/progress, capture integration and post-boot identity/health verification | Core implemented and tested locally; offline inspect works; public upload command and PlatformIO target remain disabled until package 5 gates pass |
| 5 Supported cover OTA release | Supervised bootstrap, OFF-policy transfers, alternating slots, rollback and USB recovery | Runtime memory/stack/latency gates, failure injection and NVS preservation pass; USB capture accompanies WiFi capture |
| 6 Retained torque release | Stable cross-image hold reconciliation, compatible fallback and later supervised-owner takeover | Depends on 5; unloaded/supported tests first, instrumented bus/torque checks and real mechanism validation before enabling |
| 7 Later crash recovery | Evaluate flash core-dump capture and authenticated retrieval after reboot | Separate hardening work; not a dependency for the first OTA release; verify framework support and dump size before promising it |

Packages 1A, 1B and 2 are separate reviewable changes, not independent safety
systems. Package 3 includes health recovery before the first application-only
transfer; rollback is not deferred until retained torque. Package 5 enables
routine OFF-policy use only after its hardware gate. Keep the current upload
rejection in place throughout local development of packages 1 through 4.

## Validation and evidence

| Area | Required checks |
| --- | --- |
| Event transport | Important events reach both sinks once; controller ring holds 20 entries with unchanged entry size; no producer waits for serial/network; test overflow, escaping, truncation, unavailable storage and sequence rollover |
| Metrics lifecycle | Boot/page load remain OFF; open acknowledges fresh sampling; collapse, hidden page, navigation, dropped unsubscribe, lease expiry, multi-viewer last-close, stale generations and rapid reopen behave correctly; timer registration and optional heap/stack call counts are zero after OFF acknowledgment |
| Capture | Mock HTTP tests cover gaps, overwritten cursors, same-image reboot, boot changes between requests, disconnects, bounded retry and artifact mismatch; prove zero actuator/maintenance requests and zero implicit metrics subscriptions |
| Disabled overhead | With every panel closed, repeatedly poll ordinary status and fetch logs; verify no optional CPU interrupts, heap/stack scans, sample/history updates or periodic metric output. Confirm motion safety and explicit OTA admission checks still work. |
| Load | Multiple tabs, capture and Alpaca polling; measure total/internal/largest-block minima, all stack headroom, web/cover loop gaps and dropped logs with the full ring; repeat with receiver allocations and flash activity |
| Admission | Race Open/Close, manual/calibration commands, Stop, recovery, settings, reboot and AP fallback; reject active movement/holding and stale owner releases |
| Transfer | Wrong credentials/commands, replay, wrong product/profile/schema, oversized/corrupt/truncated images, blocked host port, sender death, lost WiFi, cancellation and repeated retry; no concurrent OTA API access |
| Commit and reboot | Interrupt around handoff writes, selection, reset and first-boot acceptance; compare running/selected slots and identities; distinguish failed transfer from unknown activation |
| Recovery | Intentional startup-health failure and hang reset select the healthy image; real servo/AP absence does not cause a rollback loop; restore over USB without NVS erase |
| Torque and clients | No movement on admission/boot, verified OFF first; later test no unintended release across new image and fallback, explicit Stop, real faults, old tabs and delayed automatic Stop messages |
| Credentials | Canary absent from command lines, stdout/stderr, verbose logs, text captures/manifests, status and event responses; sensitive binary archives stay local and no sensitive configuration is tracked |

The uploader owns deployment verdicts; the event log is supporting evidence.
Require matching target ELF identity, accepted boot health and reconciled
transaction outcome. Store the binary SHA separately from the embedded ELF
identity. A missing terminal response is `UNCONFIRMED` until subsequent state
establishes success or rollback, even if the byte-transfer command returned zero.

Do not choose a memory reserve or promise Stop latency from desktop tests.
Measure both with transfer traffic and flash operations on a supported
mechanism. Compare metrics OFF against an explicitly opened panel to quantify
observer overhead. Keep USB capture during initial validation because network failure
also removes the WiFi observation path.

## Deferred work and immediate next actions

Keep cloud logging, a general remote console, persistent full event history,
Secure Boot/eFuse changes and filesystem updates outside the initial release.
Flash core dumps may later preserve task state across crashes, but the existing
64 KiB partition alone proves neither SDK enablement nor adequate capacity.
Check the pinned framework and available space before designing downloads.
[ESP-IDF core dump support](https://docs.espressif.com/projects/esp-idf/en/v4.4.7/esp32/api-guides/core_dump.html)

Package 1A is implemented locally: the opt-in disclosure, fixed viewer leases,
serialized timer lifecycle, cached status and all optional acquisition gates.
Host tests cover zero backend calls while OFF, lease expiry, multiple viewers,
reordered requests, modeled timer/scan cleanup acknowledgment and collector
restarts; browser
tests cover default collapse, renewals, close/navigation, visibility, rejected
renewal and reboot. Hardware interrupt/scan counts and timing impact have not
yet been measured.

Local verification on 2026-10-22: both production builds passed, along with
lease/collector, CPU arithmetic, browser lifecycle/renderer, controller safety,
log-buffer and firmware-tool tests, plus the full Chrome UI regression. The
application binary is 1,011,488 bytes with 299,232 bytes of headroom per slot;
static DRAM is 52,808 bytes. No upload or controller access was performed.

Package 1B is implemented locally: selected events share the existing serial
queue and ring; schema-1 boot/epoch cursors, explicit truncation/loss metadata,
16-entry/4-KiB batches and the global read budget are in place. The Mac tool
archives events and optional snapshots without session, actuator, maintenance
or metrics-subscription requests. It persists cursors, marks gaps/reboots and
checks selected ELF identity. The unavailable OTA snapshot is shared by status
and the dedicated read-only endpoint; no transaction receiver exists yet.
See [WiFi capture and endpoint details](DEBUGGING.md#read-only-wifi-capture).

Package-1B local verification on 2026-10-22: both production profiles build;
publisher tests exercise both sinks, queue/ring loss, truncation, unavailable
storage and epoch changes during reads. The actual diagnostics module, with
counted platform stubs, keeps optional acquisitions at zero while OFF. Encoder
output is parsed as JSON and checked against both response bounds. Host tests
cover reconnect/backoff, cursor persistence, boot races, resource gating,
transfer pauses, identity mismatch and text redaction. A loopback CLI capture
and resume recorded three events once, left metrics inactive and kept artifact
matching unknown without a selected build. The Chrome UI regression includes
event-cursor rollover and optional loss counters. No controller was contacted
or flashed; runtime memory, interrupt, RF and Stop-latency measurements remain
pending.

Package 2 is implemented locally: typed owner leases, worker-acknowledged
clearance, all-route/queue exclusion, scoped cleanup/release and controller
control generations. Model and actual worker-loop tests cover stale releases,
queued commands, worker pauses, Stop races, network loss, unsafe cleanup and
stale clearance. Browser protocol tests keep delayed automatic cleanup bound
to the original generation; both live UI and configuration suites pass.
Final package-2 builds on 2026-10-22 measured 1,025,312 bytes with 285,408
bytes remaining per slot and 52,904 bytes static DRAM. All 21 tool tests and the
existing metrics/publisher/controller checks pass. The new control-generation
and maintenance browser tests pass alongside the live/configuration suites.
No hardware was contacted or flashed for this work.

Packages 3 and 4 are implemented locally as documented below, with live host
command wiring deferred until the release gate. Keep supported-device memory/latency and
failure-injection gates; no OTA upload should be enabled merely because local
arbitration and protocol tests pass. Next hardware work includes controlled
USB bootstrap/recovery checks and completion of the supported-cover/OFF
resource baseline with the intended workers and metrics closed/open.

Initial USB deployment on 2026-10-22 (America/Phoenix) succeeded. The deployed
ELF SHA-256 is
`adf620ef262ed40ebecd556f64ff84980763b7e31040a9213cd78598afda5987`.
This working-tree build includes the passive WiFi diagnostics additions:
1,029,056 application bytes, 281,664 bytes remaining per slot and 53,024 bytes
static DRAM. The installed partition table matched the generated table after
normalizing erased padding; partition/NVS backup and matching build artifacts
are retained privately under
`diagnostics/upload-20261022-ota-foundations-013756Z/`.

The running image identity was verified over HTTP. Startup reported CLOSED at
position 494, ready, stationary and torque OFF. Saved calibration, limits and
profiles matched the pre-upload snapshot. No actuator command or servo EEPROM
write was issued. With metrics closed, the first three-minute USB capture
contained no optional metrics records and no dropped logs; sampled free heap
was at least 57,536 bytes and lifetime minimum heap was 53,184 bytes. These
basic health readings do not establish largest-block or OTA allocation margin.

Network verification remains incomplete: RSSI was approximately -91 to -85 dBm,
HTTP requests repeatedly timed out, and the USB log recorded a 10,193 ms web
loop gap. Sampled motion-worker age stayed at or below 4 ms; no motion was
requested, so Stop latency remains untested. A later status request succeeded,
but subsequent session requests timed out before any metrics subscription.
Do not attribute the web stall solely to RF or to metrics without further
evidence. Improve reception, repeat the closed/open metrics comparison, and
investigate web responsiveness before accepting the hardware baseline. OTA
remains unavailable; transfer/recovery, maintenance races and motion tests
have not been hardware-verified.

At the user's request, saved WiFi credentials were subsequently cleared using
a temporary USB recovery application and the exact archived production image
was restored. The helper used the existing validated application-settings
loader/saver, changed only the WiFi fields, and verified the calibration record
byte-for-byte. A fresh NVS backup and USB confirmations are retained with the
deployment evidence. Production boot identity was reconfirmed; startup remained
ready at position 494 with limits 450..2500. USB confirmed the open setup AP
`TelescopeCover-4DFF9C` at `192.168.4.1`. Selecting a replacement network and
completing the stationary metrics comparison remain pending.

Subsequent setup-hotspot investigation captured a client join at uptime
27,952 ms and an `AP_STAIPASSIGNED` event at 29,416 ms, confirming DHCP worked
for that attempt. Web-loop gaps of 10,034 ms and 8,629 ms followed, with repeated
socket-write errno 11 (`EAGAIN`, a retryable send condition; the SDK's displayed
"No more processes" text is misleading). A client disconnect occurred at
72,876 ms. There was no further AP-stop event or controller reboot during this
sequence; sampled motion-worker age remained at or below 4 ms. The pinned
Arduino WiFi client allows ten send retries with one-second select waits,
which can account for long web stalls under backpressure but does not explain
the underlying packet loss. Evidence is retained as `ap-drop-live.log` beside
the deployment artifacts. Determine whether the client leaves the hotspot or
loses traffic while still associated before choosing a networking fix; do not
treat the observed send retries as proof of the radio failure's cause.

The user then correlated the failure with opening the webpage: ping worked
for roughly 20 seconds after joining, then timed out when page loading began.
This makes HTTP traffic a reproducible trigger to investigate. Compare a tiny
read-only `/api/session` response with the full UI before selecting a fix.
The UI uses multiple gzip assets (12,603 bytes HTML, 9,066 bytes CSS and 26,536
bytes JavaScript for this working tree); flash-backed serving still
uses the same retrying WiFi socket writer. A future bounded-send change must
be tested against stalled/partial writes and normal UI loads, and must not be
claimed to fix ICMP loss until hardware reproductions confirm it.

The tiny-response comparison could not be completed: the next user reconnect
fell back to a self-assigned address. USB recorded another AP client join at
220,677 ms, but no new IP-assignment event through capture end near 240 seconds.
During that interval the web loop remained responsive (sampled age 0–1 ms),
with no new send retries. Failure therefore also occurs without a simultaneous
web-loop stall. Test another client against the hotspot to distinguish a
Mac-specific problem from the controller/link before changing the web sender.

Firmware A/B testing changed the priority: the exact pre-update image
`ced01d6d04cf749ca0d1f2a88f354602062e5c88e4719d4f7ff036b4fe073020`
was located and hash-verified in `diagnostics/upload-20261021-settling/` and
restored by application-only USB flashing. The user reported the hotspot and
page worked perfectly, then selected a closer AP. Read-only STA baseline
`sta-prior-checked` completed 24 status/page requests with zero failures,
maximum response time 323.3 ms, sampled minimum free heap 197,996 bytes and
RSSI -86 to -78 dBm. Calibration remained ready at position 494, limits
450..2500. NVS was not erased during this comparison.

The original pre-update and post-update STA snapshots both reported RSSI
-88 dBm, with free heap falling from 194,652 to 63,008 bytes. The older ELF's
diagnostics startup has no debug-ring allocation; its settings loader also
predates newer application-record versions. Thus the plan's "existing ring"
description refers to the development source, not that deployed baseline.
The 124,000-byte ring allocation is a substantial candidate for the regression,
but memory pressure is not yet a proven root cause. At the user's request,
the separate `web_control_wifi_test` environment sets
`COVER_DEBUG_LOG_CAPACITY=50`, leaving the production default at 1,000 for the
controlled experiment. Ring retention/overwrite tests and actual diagnostics
tests pass at both capacities. Compare current firmware in STA mode with this
small ring before changing other networking behavior. Artifacts and a fresh
NVS backup are retained under the deployment evidence's `small-log/` directory.

The 50-entry current-firmware experiment was installed successfully and is the
image left running. ELF SHA-256:
`47a2bcef889482ea6f8533a915e910eb67bebcf8b58fd99b978a3f8deea29f6b`.
Its application is 1,028,944 bytes, leaving 281,776 bytes per slot. It joined
STA at `192.168.1.135`; no settings or servo EEPROM were written by the tests.
The older UI's user-selected network settings were retained on upgrade.

| Stationary measurement | Result |
| --- | --- |
| Repeated current-firmware status/page requests | 24/24 succeeded; slowest 689.5 ms; sampled free heap at least 193,708 bytes; RSSI -90 to -85 dBm |
| Full HTML/CSS/theme/JS transfers, three rounds | 12/12 succeeded; 146,016 bytes total; slowest 1,032.2 ms |
| Metrics OFF baseline | 12 samples; free heap at least 191,336 bytes; slowest status 207.1 ms |
| One deliberate metrics viewer | 25 samples; free heap at least 189,968 bytes; slowest status 286.1 ms; cached internal heap at least 137,260 bytes and largest block at least 110,580 bytes |
| After final viewer closes | 5 samples; free heap at least 190,980 bytes; slowest status 255.8 ms |
| Final controller status | CLOSED, position 494, torque OFF, stationary; free heap 198,224 bytes; metrics OFF, unavailable, zero viewers, epoch zero |

Hardware checks also passed two-viewer sharing, fresh CPU warmup after reopen,
stale start/renew/close handling, abandoned-viewer expiry, bounded event batches
and busy handling, unavailable OTA, and unchanged calibration/motion profiles.
The sampled CPU result was plausible but is not a calibrated accuracy or
collector-overhead measurement. Task minimum free stack bytes included Web
4,924, Cover 1,128 and Diagnostics 1,280; Alpaca was not running in this setup,
so these results do not establish margin with that worker enabled.

Through the first 26 USB health samples there were no socket-write errors,
STA-disconnect events or dropped logs; sampled motion-worker age was at most
5 ms. Some asset sends still occupied the web loop for approximately a second,
so normal HTTP/motion latency acceptance remains open. The prior and current
STA runs associated with different BSSIDs and different RSSI ranges; do not
describe this as a strictly identical RF comparison. Together with the
user-confirmed hotspot recovery on the old image, the small-ring result strongly
implicates the new memory footprint, but does not yet prove the precise failure
mechanism. Do not promote the 1,000-entry default or enable OTA on these results.
Keep the small-ring build for longer STA/browser testing, establish the intended
worker workload, and settle a RAM budget/controller-history policy before
enabling transfers. The browser's existing 1,000-group history
is independent of this 50-entry controller ring.

## Package 3 local implementation and current direction

The user approved keeping **50 controller entries as the production default**
and proceeding with receiver/startup recovery development. `web_control_wifi_test`
remains an equivalent-capacity experiment alias; normal USB/OTA builds now also
default to 50. Determine the memory margin later with the intended Alpaca/native
workers, receiver buffers, metrics OFF/ON and flash traffic. No reserve is
invented from the initial stationary results: zero configured receiver reserves
continue to prohibit OTA admission. This deferred measurement is a release gate,
not a prerequisite for further local implementation.

Log compression is a deferred optimization: repeated messages may permit
repeat counts, event identifiers or dictionary compression. Evaluate those
later while preserving fault visibility, timestamps, sequence/loss semantics
and nonblocking producers. No compression or automatic event coalescing was
added to the controller in this package.

`ota_protocol.h` contains the strict manifest, image-prefix gate, bounded image
stream, stable 160-byte journal codec, startup-health decision and commit
sequence. `ota_auth.h` specifies the control MAC and one outstanding,
peer-bound, single-use challenge. `ota_service.cpp` owns platform crypto,
transport, NVS and startup reconciliation. No stock `ArduinoOTA.handle()` or
`Update` activation path is used: the owner calls `esp_ota_*` so durable handoff
and the final Stop/cancel boundary precede boot selection.

### Control wire contract

Provisioning is optional for builds. Copy the placeholder-only
`include/ota_local.example.h` to ignored `include/ota_local.h` only for a later
supervised release. The secret is a unique 32..128-byte random ASCII value.
`COVER_OTA_RECEIVER_ENABLED` defaults to zero; internal-free and largest-block
reserves also default to zero. A usable receiver additionally requires accepted
startup health, pure STA mode and no active maintenance reservation on prepare.
No UDP listener or OTA owner task is started by the normal unconfigured build.
The PlatformIO OTA upload target remains rejected before device access.

POST bodies use `Content-Type: text/plain`, explicit Content-Length and at most
640 bytes. The declared and parsed byte lengths must match, including protection
against embedded-NUL truncation by the framework. The prepare body is strictly
ordered, ASCII and newline-terminated:

```text
product=telescope-cover
profile=web_control
protocol=1
settings=5
handoff=1
size=<positive decimal binary bytes>
sha256=<64 lowercase hex characters>
md5=<32 lowercase hex characters>
elf=<64 lowercase hex characters>
policy=supported-cover-off
control_generation=<fresh positive decimal generation>
```

Unknown/reordered/duplicate fields, alternate number encodings and trailing
data are rejected. Prepare authenticates before reserving maintenance and
returns 202 for queued preparation, not ready clearance. The cancel body is
exactly `transaction=<32 lowercase hex characters>\n`; cancellation returns
pending until the owner has stopped transport, aborted an open SDK handle and
obtained fresh physically safe cleanup clearance. Cancellation after entry to
the activation boundary returns too late, even if selection subsequently fails.

GET challenge returns schema 1, boot ID, a random 32-hex nonce and a 10-second
lifetime. There is one challenge slot, limited to one issuance per second.
POST uses `X-Ota-Nonce` and `X-Ota-Mac`. Derive the control key as
`HMAC-SHA256(secret, "cover-ota-control-v1")`; the MAC covers these exact ASCII
lines, each terminated by a newline:

```text
COVER-OTA-CONTROL-1
POST
<exact endpoint path>
<boot_id>
<nonce>
<transaction ID; empty line for prepare>
<lowercase SHA-256 hex digest of the exact transmitted body bytes>
```

The challenge is bound to the HTTP peer and consumed on an attempted matching
authentication, including an incorrect MAC. Crypto-library errors reject the
request. Neither credentials nor derived verifiers appear in status or events.
`tools/ota_manifest.py` provides offline image validation and the shared host
canonical-body/MAC helpers. It is not an uploader and accepts no CLI secret.

### Transfer owner and image compatibility

The owner waits up to three seconds for worker clearance, then binds UDP 3232
for a 60-second arming window. Only an application invitation (`0`) from the
prepared HTTP peer with matching binary length/MD5 is accepted. Espota's
`AUTH nonce` / `200 cnonce response` exchange has a five-second deadline, pins
the UDP source port and uses the existing MD5 compatibility calculation. The
TCP callback goes only to that prepared peer and invited port, with a bounded
connect. SHA-256 remains the authenticated artifact-integrity check; MD5 is
present for protocol compatibility. No filesystem, settings, bootloader or
partition-table payload is accepted.

TCP uses a fixed 1-KiB input buffer, a 180-second total deadline, three-second
stall deadline and 200-ms nonblocking ACK/result writes. The separate stream
validator stages the first 352 image bytes before erase and rechecks clearance
before each begin/write/finalize boundary. It requires ESP32/DIO/4-MB headers,
the embedded ELF identity, and the exact 64-byte product/profile/protocol/
settings/handoff descriptor immediately after ESP-IDF's app descriptor.
Heartbeat-test and compile-only profiles carry an incompatible test descriptor.
The inactive slot uses sequential erase/write; both streamed digests and native
image validation must pass before the durable activation intent is written and
read back. The commit cutover shares the servo worker's lock with explicit Stop;
Stop before cutover prevents selection, while Stop afterward remains an
unconditional torque-release request and cannot promise selection was undone.

The initial receiver relied on Arduino's unbounded HTTP parser before its
application checks. The project-owned bounded input adapter described in the
later HTTP-hardening section now replaces that path. Keep its hardware and
full-workload acceptance separate from local parser/adapter tests; the 640-byte
application check alone never established a transport allocation guarantee.

### Startup and durable outcome

The strong **C-linkage** `verifyRollbackLater` override defers Arduino acceptance
and arms a 45-second RTC reset watchdog before `setup()`. The startup coordinator
closes the movement/settings gate before creating workers; explicit Stop remains
available. Pending-image or unresolved-handoff startup discards the unrelated
same-image RTC retained-torque marker. No update handoff enables torque.

After at least four seconds, health requires readable application/NVS records,
the small log allocation, live diagnostics and servo-worker loops, registered
web recovery services and a usable STA or AP interface. Missing servo or
calibration produces its normal motion fault, rather than an automatic firmware
rollback solely for absent hardware. Health waits at most 30 seconds; early
hangs retain the independent RTC reset path. Failed pending-image health asks
the rollback-enabled SDK to select the previous valid app; absent recovery
evidence leaves motion locked and USB recovery available.

Healthy first USB bootstrap seeds the running slot in otadata if needed, then
marks it valid. This intentionally writes **boot-selection metadata**, not
application settings or servo EEPROM. The first OTA must start from this
bootstrap image; the older bench images are not compatible fallback readers.
The dedicated `cover-ota/v1` record has explicit little-endian layout, schema,
CRC32, transaction ID, source/target ELF identities and slots, binary SHA/length,
OFF policy and outcome. Writes occur at activation intent, boot reconciliation
and terminal outcome, never per packet or ordinary event. A further bounded
checkpoint records positive boot-selection evidence after the SDK selects the
target; an observed matching target boot also establishes that evidence. This
prevents an old INVALID/ABORTED marker left on a reused slot from being mistaken
for rollback of a cancelled transaction that never selected that slot. Power
loss between selection and its confirmation checkpoint can remain UNCONFIRMED.

Startup reconciles intent, boot-check and ambiguous activation records against
the running/selected slot and invalid-target image evidence. `COMPLETE` requires
the expected target plus accepted health; `ROLLED_BACK` requires the matching
source, positive selection/target-boot evidence for this transaction, and a
matching invalid/aborted target. Otherwise the result is
`UNCONFIRMED`. Both status endpoints expose the redacted durable `last_update`
separately from a current in-memory transaction. All startup acceptance/journal
writes finish before receiver admission can open. No irreversible settings
migration or retained-torque OTA is implemented.

This package is local only. The known-working 50-entry image on the controller
has not been replaced by the new bootstrap/receiver code. Initial USB bootstrap,
real power interruption/watchdog rollback, radio-loss/Stop timing under flash,
full intended-workload memory margins and authenticated HTTP/espota end-to-end
tests remain supervised hardware gates. Package 4 supplies the secret-safe
operator wrapper; neither a successful build nor offline fault tests enable
routine uploads.

Local package-3 verification on 2026-10-22 (America/Phoenix): production USB and
build-only OTA profiles pass, with no compiler warnings. Each image is
1,040,896 bytes, leaving 269,824 bytes per slot, with 53,304 bytes static DRAM.
An isolated public-fixture build retains the full receiver path: 1,048,816
bytes, 261,904 bytes slot headroom and 53,408 bytes static DRAM. It carries a
non-production descriptor, is rejected by the production manifest validator,
and was not uploaded. No usable credential or guessed memory reserve was
added to production configuration.

All 26 firmware/capture/manifest tool tests pass. Host checks cover canonical
control bodies, shared Python/C++ HMAC vectors, crypto failure, replay/expiry,
espota field parsing, metadata before erase, fragmented/failed/truncated image
streams, digests, journal corruption/torn records, stale invalid-slot rollback
ambiguity, startup deadlines and commit checkpoint failures. Actual worker-loop
tests cover startup gating, explicit Stop and the commit boundary; diagnostics
and ring checks pass at both 50 and 1,000 entries, and event responses parse as
bounded JSON. Existing control-generation, metrics lifecycle, CPU/WiFi renderer
and isolated Chrome maintenance regressions pass. The real PlatformIO OTA upload
target was also confirmed to reject before device access.

The production build hook now validates native image checksums, embedded ELF
identity, the compatibility descriptor and the strong C acceptance hook, and
writes a credential-free `ota-manifest.json`. Test images are labeled
`test_profile`, never silently promoted to production. These checks precede USB
upload too. SDK state semantics follow the
[ESP-IDF 4.4.7 OTA contract](https://docs.espressif.com/projects/esp-idf/en/v4.4.7/esp32/api-reference/system/ota.html).
They are not substitutes for testing the actual installed bootloader, RTC
watchdog and interrupted first boot. Add OTA-worker stack observation when
performing the deferred full-workload memory-margin validation.

## Package 4 local host workflow (2026-10-22)

`tools/ota_upload.py` implements the host workflow core and a deliberately
restricted operator command. Inspect a selected local production build with:

```sh
python3 tools/ota_upload.py inspect .pio/build/web_control_ota
```

`upload` exits with the existing release-gate error **before opening artifacts,
credentials or sockets**. It has no host, raw-password, environment-secret or
bypass option. The PlatformIO OTA target remains separately blocked. Connecting
this core to a live CLI/PlatformIO command is deferred until supervised bootstrap,
receiver HTTP-parser hardening and supported-device memory/latency validation
pass. No controller was contacted or flashed for package 4.

### Artifact, credential and transport handling

The loader verifies the pinned partitions, native image integrity, production
descriptor, ELF identity and strong C startup hook, then retains the exact image
as immutable bytes. It compares that snapshot to the validated build metadata
to detect replacement during validation. Later file changes cannot alter the
bytes sent. A distinct target ELF is required to avoid confusing a same-image
restart with a deployment.

Credentials stay in process memory. The prepared file loader accepts an
owner-only regular file with no symlink or hard-link alias, bounded to 32..128
printable non-space ASCII secret bytes, with one optional terminal LF. It never
prints a filename, file contents, remote response body, control MAC or transfer
verifier on errors. No secret is read by the current public CLI. Do not provision
or enable a receiver merely to exercise these local tools. Python does not
promise erasure of immutable credential objects from process memory.

The engine requires explicit supported-cover/OFF confirmation and a recent
stationary, torque-OFF, clean saved-calibration status with accepted startup.
Receiver admission remains authoritative and rechecks physical clearance. The
host signs the canonical prepare using the current control generation and a
fresh boot-bound challenge, with at most three challenge attempts when globally
rate limited. It never acquires browser ownership, sends motion/torque/settings
commands, subscribes to metrics, or refreshes a motion heartbeat.

The callback listener is bound before preparation. HTTP, UDP invitation and TCP
callback share an explicit local IPv4 interface; the remote IPv4 peer is pinned.
There is no HTTP redirect, DNS or proxy path. Transfer authentication uses the
espota exchange in-process, with no subprocess or credential-bearing command
line. Image blocks are 1,024 bytes with a final shorter block. Progress reports
only acknowledged and total byte counts. The sender handles split ASCII ACKs
and an ACK coalesced with final `OK`, and rejects wrong counts or missing results.

The receiver now limits reads to each sender-block boundary and acknowledges
**one complete block**, rather than every TCP fragment. Espota has no ACK
delimiter; emitting counts for partial reads allowed ambiguous concatenation.
The fixed boundaries preserve the stock 1-KiB stop-and-wait exchange while making
host count validation deterministic. The image-prefix gate still stages and
validates metadata before erase; no controller log capacity changed.

### Verdicts, cancellation and capture

Arming has a ten-second host deadline. Socket operations have short timeouts;
the image stream also has a 180-second total deadline. After transfer, bounded
status polling runs at most once per second for 60 seconds. There is no host
bulk-log or optional metrics traffic during transfer. The existing WiFi capture
tool independently observes OTA state, pauses bulk draining while active, and
resets its event cursor when boot identity changes; those regressions remain in
the tool suite. No new controller sampling is started by the uploader.

`COMPLETE` requires a matching durable schema/transaction/source/target/slot
record with positive selection confirmation, the expected running ELF, a changed
boot ID and accepted startup health. Matching source recovery with the durable
confirmed rollback record produces `ROLLED_BACK`. Transfer `OK`, progress 100%,
an old journal, a missing final ACK or a poll timeout cannot produce `COMPLETE`.
Explicit prepare refusal produces `REJECTED`. Ambiguous activation or a lost
prepare response produces `UNCONFIRMED`; the
uploader does not resend the image automatically. A post-transfer reconnect can
still establish the correct durable result.

Before requesting cancellation after a local transfer/preparation failure, the
host checks that the original transaction and boot are still active before the
commit fence. It obtains a new challenge and signs that exact transaction.
Commit/reboot or unreachable state does not justify guessing that cancellation
is possible. A cancellation request is not terminal: the host waits for cleanup
or a durable outcome. An absent response remains `UNCONFIRMED`.

### Verification and next hardware work

All **49 tool tests** pass, including real loopback UDP authentication and
fragmented multi-block TCP exchanges, HMAC/body checks, protected credential-file
validation, changed artifacts, default-denied upload, admission rejection,
challenge throttling/boot changes, arming timeout, cancellation cleanup, lost
prepare/final ACKs, reboot gaps, rollback and mismatched durable records. Host
C++ protocol tests also pass, including fragmented receiver ACK boundaries.
The test fixtures use public canaries, and the workflow emits no stdout/stderr
or credential-bearing exceptions.

Both production profiles build and validate at **1,040,896 bytes**, with
269,824 bytes remaining in each slot and 53,304 bytes static DRAM. The isolated
receiver-enabled public-fixture build also passes: **1,048,848 bytes**, 261,872
bytes slot headroom and 53,408 bytes static DRAM. That build remains explicitly
`test_profile`, incompatible with production OTA admission, and was not flashed.
These are build measurements, not runtime memory margins.

Next hardware work is a supervised **USB bootstrap/recovery check** while the
cover is supported and torque remains OFF. Verify startup acceptance and native
slot state on the actual bootloader before any OTA attempt. Finish the deferred
full-workload memory/stack/latency measurements (including the OTA worker), harden
the HTTP control parser, and validate failure/rollback/USB recovery before
opening live upload commands. Keep the controller log at **50 entries**; memory
margin determination and possible log compression remain deferred work already
recorded above.

## Twenty-entry ring and initial USB bootstrap (2026-10-22)

The user subsequently reduced the production ring from 50 to **20 entries**.
This supersedes the earlier 50-entry policy while preserving its historical
measurements above. Entries remain 124 bytes: 2,480 bytes of retained messages,
plus pointer/allocation overhead, a reduction of 3,720 entry bytes. Storage now
uses ten-entry blocks, permitting this capacity while retaining bounded
startup-only allocation and the existing cursor/loss semantics. The retained
WiFi experiment alias also uses 20; the browser's 1,000-group history is
unchanged. Compression and full-workload memory-margin determination remain
separate deferred tasks.

The default 20-entry ring and actual diagnostics/OFF-gating tests pass, as do
50/1,000-entry retention checks, the large-history bounded response test, native
OTA protocol and actual servo-worker startup/commit/Stop integration tests.
All 49 tool tests pass. Both production profiles build at **1,040,944 bytes**,
with 269,776 bytes per-slot headroom and 53,304 bytes static DRAM. The isolated
receiver-enabled compile-only test profile builds at 1,048,880 bytes, leaving
261,840 bytes per slot with 53,408 bytes static DRAM; it was not installed.

The user confirmed the cover was mechanically supported and safe to leave
unpowered. Before installation, HTTP confirmed stationary torque OFF, clean
saved calibration and no maintenance lock. A complete 4-MiB flash backup was
saved privately, the installed partition table matched the pinned layout, and
the installed bootloader matched the selected build byte-for-byte. Only app0
contained the current image; app1's inspected header region was erased. The
backup's OTA data had app0 sequence 1 in UNDEFINED state with a valid sequence
CRC. No inactive known-good OTA fallback was established by that observation.

The production USB bootstrap was then installed without erasing NVS. Its
running ELF identity is
`5a284772f34011ffc4d591f94c3c3c345e41ba6b77a9b5c912ba1018642d71cd`.
Read-only HTTP polling observed startup `checking` with UNKNOWN/unknown torque,
then CLOSED with torque OFF, then startup `accepted`. Fifteen candidate status
observations and the event endpoint verified the matching identity, no motion,
receiver unavailable with reason `release_gate`, and allocated capacity 20.
Saved calibration remained 450..2500, CLOSED 493 and OPEN 1531, with no dirty
draft; STA connectivity returned without credential changes. Optional metrics
remained OFF with no viewers. These checks did not issue motion, torque,
settings, metrics-subscription or OTA-control requests.

Private backup, selected artifacts, USB logs and status evidence are under
`diagnostics/usb-bootstrap-20261022-log20/`. Binary backups can contain
credentials and remain local. Native metadata/reboot checks are
recorded below; initial acceptance alone does not prove
rollback, watchdog failure recovery, power-loss tolerance or a safe OTA margin.

The passive USB capture recorded startup acceptance around 4.98 seconds, eight
HEALTH records, no dropped logs, and no panic/backtrace. Sampled free heap was
204,564..206,672 bytes; lifetime minimum reached 190,692 bytes during the short
boot/HTTP workload. A further HTTP observation confirmed accepted startup and
OFF torque at 71,552 ms uptime, beyond the 45-second startup watchdog window.
This checks healthy-path watchdog disarming; it does not exercise a hung boot.

A read-only native metadata check then verified app0 sequence 1 in **VALID**
state (`0x2`) with the expected sequence CRC. The unused other sector remained
sequence 0 / UNDEFINED; it is not a selectable fallback image. A 460800-baud
metadata read encountered serial packet noise; retrying at 115200 succeeded.
The metadata read's reset returned to the same firmware, accepted startup,
normal STA status, torque OFF and metrics OFF. Native app0 validation is now
hardware evidence, rather than inferred solely from HTTP acceptance.

Comparing the NVS snapshots found 107 changed bytes confined to previously
erased entry space and its allocation bitmap; all earlier programmed record
bytes remained intact. The bootstrap creates its OTA namespace and ordinary
WiFi state may append records, so raw NVS equality is not expected. Calibration
values were also verified through status. Parsing the active NVS entries further
confirmed byte-identical `cover-app`, `cover-cal` and `cover-beta` records before
and after installation, including their blob payloads. Existing WiFi records can
be retired in the allocation bitmap as their replacements are appended. The full pre-install backup remains
available for USB restoration.

This completes the initial healthy USB bootstrap check. Next work is receiver
HTTP-parser allocation/deadline hardening and the remaining supervised resource,
watchdog-failure, candidate/rollback, interruption and USB-recovery checks.
There is still no validated inactive fallback, measured full-workload OTA margin,
live upload command or enabled receiver. Do not interpret this check as OTA
release acceptance.

## Bounded HTTP input hardening (2026-10-22)

`http_request.h` now receives input in a fixed arena, and `bounded_web_server.h`
adapts accepted input to the existing Arduino route/response API. The adapter
replaces the framework's input parser for the whole listener, so an alternate
route cannot enter an unbounded multipart/raw parser before OTA authentication.
No installed framework files are modified. Detailed limits are documented in
[the HTTP input contract](WEB.md#bounded-http-input).

The transient arena has a compile-time 4,352-byte upper bound and exists only
while receiving a request. It is freed before invoking a response handler.
Decoding and collected header strings are created only after validation, with
bounded input and argument counts. There is no multipart upload buffer, raw
upload callback, claimed-Content-Length allocation or packet-by-packet realloc.
The controller log remains at 20 entries.

Input consumes at most 256 bytes per web-loop call, with an absolute two-second
acceptance-to-completion deadline that progress cannot extend. Strict CRLF,
canonical lengths, header/line/total/argument limits, NUL/escape checks, and
rejection of duplicate headers, transfer encoding, multipart, compression and
Expect apply before dispatch. OTA POST requires its exact route, no query,
`text/plain` and at most 640 nonempty body bytes. Browser form URL encoding,
query parsing, authentication header collection and exact signed `plain` bytes
retain their existing route interfaces. Rejected input uses a fixed best-effort
nonblocking reply and close, with no reflected values or shared-log publishing.

Native tests pass with address/undefined-behavior sanitizers. The input test
covers bytewise fragmentation, both body limits, line/header/argument limits,
malformed/ambiguous framing, media policies, incomplete input, pipelining,
absolute deadlines, millis rollover, and 10,000 randomized byte streams. The
production adapter is tested against host socket/platform doubles for exact OTA
bytes, form decoding, stale header/argument cleanup, 256-byte loop budget,
timeout/reconnect, disconnect/close and zero handler dispatch for invalid input.
These adapter tests model the Arduino routing API; production compilation and
on-device checks provide separate integration evidence. All 49 tool tests and
control-generation/metrics/WiFi browser protocol regressions also pass.

Both production profiles build and validate at **1,045,328 bytes**, leaving
265,392 bytes per slot, with 53,304 bytes static DRAM. The isolated, incompatible
receiver-enabled compile-only fixture builds at 1,053,248 bytes, leaving 257,472
bytes per slot with 53,416 bytes static DRAM. Only the normal receiver-disabled
USB image is installed for the checks below. Its ELF identity is
`cbce3b3b3243432360ecadaa302fbc5c014389f473fc81f736bc60183f80ff71`.

### Initial stationary hardware verification

A fresh preflight found torque ON, so installation was deferred until the user
confirmed support and released torque through the UI. Fresh telemetry then
showed STOPPED, torque OFF, no motion, clean calibration and no maintenance lock.
Current partition/NVS/native metadata and the selected firmware were archived
privately before USB installation. The previous validated bootstrap artifacts
and complete flash backup remain available. No erase-all or OTA transfer ran.

USB installation succeeded and startup was accepted. Live tests returned the
expected status codes for 26 boundary cases, including oversized bodies/headers,
invalid and duplicate lengths, duplicate MAC headers, multipart, chunked input,
Expect, compression, header folding, long request line, OTA query, NUL, excess
arguments, LF framing and GET bodies. A valid maximum-size 2,048-byte form reached
the unknown-route handler (404); a well-framed HTTP POST to OTA prepare remained
release-gated (403). Slow partial headers and bodies returned 408 after 2.047
and 2.313 seconds host wall time respectively, including connection/RF latency.
These timings do not establish explicit Stop latency.

Normal root/configuration pages, both status endpoints and all three referenced
bundled UI assets returned successfully after the malformed-input tests; gzip
assets decompressed correctly. Twelve further status observations verified the
expected image, accepted startup, unchanged calibration, torque OFF, no movement,
receiver unavailable, and metrics OFF with zero viewers. The event endpoint
confirmed the allocated 20-entry ring. A public credential-canary malformed
request returned 415 without reflection in the response or captured USB output.
Evidence is local under `diagnostics/http-bounds-20261022/`.

The parser allocation/time gap is addressed locally and in this initial STA
check. It does not close the remaining full-workload memory/largest-block/stack
and response-backpressure/Stop-latency gates. Include the transient input arena,
bounded decoded strings, TCP buffers and concurrent response work in those
measurements. Deliberate watchdog hangs, interrupted candidate activation,
alternating slots, rollback and USB recovery still require supervised validation.
The receiver, admission reserves and public OTA upload commands remain disabled.

During the initial 60-second USB capture, 11 HEALTH samples reported no dropped
logs or panic/backtrace. The lowest sampled free heap was 193,960 bytes and the
lifetime minimum reached 171,552 bytes during boot and the malformed-request
burst. Sampled web/motion loop gaps were at most 1/4 ms respectively. These are
sparse idle snapshots, not maximum scheduling or Stop latency; TCP-buffer and
transient-allocation peaks require the planned fuller measurement. A separate
short USB capture checks the canary while logging is active and verifies another
healthy boot with the same OFF policy.

## OTA resource observation groundwork (2026-10-22)

OTA is now included in the existing task-stack metrics and Debug disclosure.
The receiver samples its own lifetime stack headroom at the same five-second
cadence, only during an active metrics epoch. Normal builds create no receiver
while unconfigured, so their OTA stack entry remains null/Unavailable. The
20-entry log capacity, upload guard, empty credential and zero admission
reserves remain unchanged.

`web_control_ota_resources` is a USB-only experiment with the incompatible
`test_profile` descriptor. It allocates the 8,192-byte owner task, unconditionally
blocks receiver admission even if a local configuration tries to enable it,
and never dequeues a transfer. During metrics OFF it only waits/checks the
lifecycle gate; it performs no stack scan, synthetic pass, digest or probe log.
With an explicit viewer, accepted startup, pure STA and stationary clean
calibration/verified OFF torque, it runs at most one 64-KiB synthetic pass per
five seconds. The production prefix/stream validator feeds a digest-only sink
with fixed SHA-256/MD5 vectors. This backend has no SDK writer, transport,
journal/activation checkpoint or invitation. Normal USB startup metadata
validation is separate and still occurs.

Metrics work now has an epoch-checked RAII acquisition guard. The OFF cleanup
barrier waits for in-flight optional work to free its contexts, as well as
stack readers and CPU timer cleanup. A last-close/reopen cannot attach old work
to a new epoch. Native tests cover denied/stale acquisitions, in-flight cleanup,
probe cadence/rollover, deterministic block bounds and the full synthetic
stream/digest vectors. UI tests cover fresh/missing/stale/collapsed OTA stack
values. All 56 tool tests pass, including the new measurement workflow tests.

`tools/measure_ota_resources.py` explicitly subscribes only for its measured
window, renews its own diagnostic lease, records bounded status/event/Alpaca
reads, then unsubscribes and verifies OFF. It checks boot/image identity and
stationary torque-OFF conditions throughout. It never issues an actuator,
settings or OTA-control request and does not impersonate motion supervision.
An ambiguous subscribe response still causes cleanup; unrelated viewers cause
an isolated run to be rejected, rather than closing their lease. Session
credentials remain in memory and are not written to evidence or command lines.
Matching binaries/ELFs and JSON results are archived privately because firmware
can contain local WiFi credentials. See the
[resource-only procedure](DEBUGGING.md#ota-resource-only-usb-experiment).

The user requested that Alpaca monitoring remain disabled. These initial
measurements therefore describe that workload; no telescope settings or state
were changed. The synthetic path allocates the intended owner stack but has a
different call graph from real transfer/flash. TCP/UDP transfer buffers,
authentication allocation, SDK handle/erase/write/finalize peaks, commit,
rollback, native telescope workers and enabled Alpaca monitoring are outside
this measurement. No admission reserve may be selected from these results alone.

### Initial hardware resource results

Fresh preflight confirmed stationary torque OFF, clean saved calibration, metrics
OFF and monitoring disabled. Current partition/NVS/native metadata, the resource
image and the normal production image were archived under
`diagnostics/ota-resources-20261022/`. The resource-only image was installed by
USB, measured, then replaced by the normal production image before the paired
production run. No OTA transfer or invitation ran. The probe's challenge endpoint
returned the expected 503/OTA-unavailable response, with no challenge issued.
The application settings and servo EEPROM were not modified by the experiment.

Each run had eight-second OFF windows around a 30-second explicit metrics
window. The collector read status, bounded events and the disabled Alpaca
snapshot; it did not change the monitoring setting. The resource profile
completed six 64-KiB synthetic passes with both digests verified. All probe log
creation timestamps preceded the first acknowledged OFF status (uptime
46,465 ms), and the subsequent passive observation contained no further probe
work. Both collectors confirmed zero viewers and OFF cleanup.

| HTTP resource observations, bytes | Production, receiver absent | Resource-only worker and synthetic path |
| --- | ---: | ---: |
| Fresh sampled snapshots | 20 | 21 |
| Lowest fetched internal free heap | 148,060 | 142,668 |
| Lowest reported internal minimum heap | 137,816 | 124,348 |
| Smallest fetched largest free block | 110,580 | 110,580 |
| Web minimum free stack | 4,652 | 4,652 |
| Cover minimum free stack | 1,104 | 1,104 |
| Diagnostics minimum free stack | 1,240 | 1,264 |
| OTA minimum free stack | No task / null | 4,400 of 8,192 allocated |
| Alpaca sample | Unavailable, monitoring disabled | Unavailable, monitoring disabled |

These are sampled observations, not an exact subtraction of worker allocation
costs or worst-case OTA bounds. Different polling/response/TCP timing can expose
different points in the same workload. USB serial snapshots also captured lower
instantaneous free values between HTTP fetches, demonstrating why the fetched
minima cannot stand in for every transient peak. The internal-minimum statistic
is the allocator's sum of per-region lifetime minima; it is not proof that all
regions hit their lows simultaneously. Cover and diagnostics stack headroom
need particular attention during later flash/real-transfer and fault handling.

Normal production is restored with ELF identity
`09c8e9f88a242371f76d35da16c82de9cd273d1a0f4aeb8eccf8ee12565fc403`.
Its OTA row is Unavailable because no receiver task exists, not because sampling
failed. The temporary profile identity was
`bb941766fae00f516896040f65bddd5ceb57bc3ee2e33f45f9f930710db8c62b`;
it is rejected by the production artifact validator. Calibration remained
450..2500, CLOSED 493 and OPEN 1531. The controller is left with torque OFF,
metrics OFF, monitoring disabled and OTA unavailable.

Both production profiles validate at **1,045,408 bytes**, leaving 265,312 bytes
per slot with 53,336 bytes static DRAM. The temporary resource profile is
1,045,008 bytes, leaving 265,712 bytes per slot with 53,256 bytes static DRAM;
unreachable transfer/admission code is optimized out, so this is not a complete
receiver-image footprint. The separate full-receiver compile-only fixture also
passes: 1,053,424 bytes, 257,296 bytes slot headroom, 53,440 bytes static DRAM.
That fixture was not installed. Host diagnostics, sanitizer protocol/vector,
metrics lifecycle, OTA stack renderer, CPU/WiFi/control-generation and all
56 tool tests pass.

This step adds repeatable measurements and OTA stack visibility, but does not
close the release memory gate. Keep both production admission reserves at zero.
Next work must exercise the real transport and inactive-slot SDK path without
allowing activation, plus full-workload/fault stack peaks; then separately prove
candidate startup failure, watchdog/rollback, interruption and USB recovery.
Enabled telescope monitoring/native workers remain outside this run by the
user's instruction. Log compression remains deferred.

## Real transport / inactive flash groundwork (2026-10-22)

The next hardware gate uses `web_control_ota_flash_probe`, a separate USB test
profile, rather than enabling production OTA. The real owner task performs
authenticated UDP invitation/TCP callback, stream validation, SHA-256/MD5 and
SDK sequential begin/write/end against app1. Its transfer branch cannot select
a boot partition, save an activation journal checkpoint or reboot. Object
relocation audits confirm SDK writer calls and absence of selection/checkpoint/
restart calls in this branch. The final reply is `NOACT`; the host classifies
success only as `VERIFIED_NOT_ACTIVATED`.

Normal OTA preparation/challenge remain unavailable. Test-only control uses
exact `/api/ota/probe/*` paths under the existing canonical HMAC, nonce and body
bounds. A unique private credential and nonzero experimental abort floors are
required; the unconfigured profile is inert. Preparation is one-shot per boot.
It requires the supported stationary cover, confirmed torque OFF, saved clean
calibration, accepted startup and pure STA. It accepts only app0 running and
selected with an erased app1 prefix. Before USB installation the full inactive
slot must be archived and verified erased, alongside native boot metadata.
These guards protect an existing candidate/fallback from casual overwriting.

`tools/probe_ota_flash.py` validates frozen production and test artifacts and
the full erased-slot backup, holds its secret/session credential in memory,
and binds both transports to one local interface. It explicitly enables metrics
for the measured window, collects one bounded root snapshot per second and
renews its own viewer lease. It fetches no bulk logs while receiving. It checks
the same boot/image and stationary OFF conditions throughout, attempts bounded
cancellation of its original active transaction on failure, then closes its
viewer. A lost viewer expires; cleanup must still be checked independently.
There is no automatic image retry or activation. USB readback/native metadata
comparison and restoration of both production app0 and the original app1 are
separate required hardware steps. See the
[nonactivating procedure](DEBUGGING.md#nonactivating-ota-flash-experiment).

The first hardware attempt stopped after 153,600 bytes. Cleanup returned to
maintenance unlocked, torque OFF and metrics OFF without a reboot. Independent
USB reads confirmed unchanged partition table and native otadata. The generic
failure reason obscured the cause: specific stream/transport errors were
overwritten by the common finalization error. That reporting is corrected, and
clearance revocation now records physical/network status and actual/required
heap/block values once per revocation. A controlled repeat retains the initial
131,072-byte free-heap / 65,536-byte largest-block abort floors. These are
experimental limits, not release reserves; production values remain zero.

### Diagnosed hardware result

The controlled repeat received 90,112 bytes and stopped with
`maintenance_clearance_lost`. USB evidence captured the actual revocation:
physical checks passed, pure STA remained valid, internal free heap was
**130,716 bytes** against the **131,072-byte** experimental floor; largest free
block was **110,580 bytes** against 65,536. No threshold was relaxed. The fetched
snapshots missed this low (minimum fetched free heap 132,124), demonstrating
again that HTTP samples alone cannot bound transient allocation. The reported
per-region lifetime-minimum sum reached 118,000 bytes. Sampled cover/diagnostics
stack minima were 1,104/1,232 bytes; the OTA path has not reached finalization,
so its sampled headroom cannot certify the complete receiver.

The owner aborted its SDK handle/connection and released maintenance; fresh
status confirmed no motion, torque OFF, metrics OFF/zero viewers and no active
OTA. Independent USB reads again confirmed the partition table and complete
native otadata unchanged. Evidence, erased-slot backup, frozen payload/test/
restore artifacts and a safety-abort summary are private under
`diagnostics/ota-flash-probe-20261022/`. One early host invocation was rejected
before preparation while startup was still checking; no image retry occurred
on either prepared boot.

This establishes real authenticated transport, partial inactive SDK writes and
safe heap-floor abort/cleanup under the disabled-monitoring workload. It does
**not** establish a complete verified image, activation, candidate boot,
rollback, interruption recovery or an approved memory budget. Production OTA
and upload commands stay disabled, the log stays at 20 entries, and compression
remains deferred. All 64 tool tests, sanitizer protocol/HTTP tests, actual
maintenance-worker integration tests, and both production builds pass.

The next step is to isolate transient memory use of root status/metrics
serialization, TCP buffers and SDK writes under this workload, then establish
justified experimental headroom before repeating a complete nonactivating
transfer. Reduce unnecessary overlapping allocations/observation overhead
where evidence supports it; do not adopt a lower production reserve merely to
make the transfer pass. Full-workload measurements remain a separate gate,
with monitoring still disabled until the user chooses otherwise. Only after
full transfer/readback proof should activation/startup-failure/rollback testing
advance.

Production was restored by application-only USB flash, with ELF identity
`893a06f89a4eed801dbe0f852a1b9926f79149af63691c192b7faba10de91de0`.
The original full erased app1 backup was restored too; esptool independently
verified both written ranges by device hash. Fresh HTTP status confirmed this
production identity, accepted startup, saved 450..2500 limits / CLOSED 493 /
OPEN 1531, torque OFF, no movement, maintenance unlocked and metrics OFF with
zero viewers. The probe routes/status mode are absent from production, and
normal OTA remains unavailable. The temporary plaintext test key/header were
removed after production restoration; archived test binaries remain private.
The production image is 1,045,744 bytes, with 264,976 bytes per-slot headroom.

## Isolating transient memory use (2026-10-23)

Prepared `web_control_ota_memory_probe`, a separate nonactivating test profile
with fixed boundary evidence and no production instrumentation. Local source
inspection of the pinned Arduino `WString.cpp` shows each non-SSO growth uses
`realloc`, rounded to a 16-byte allocation boundary; the root-status handler
uses repeated `String` concatenations for a large metrics/OTA JSON response.
This motivates observing serialization boundaries but does not establish that
they caused the measured heap-floor revocation. No reservation, serializer,
queue, stack or network-buffer optimization is being selected without evidence.

The recorder separates idle and active-OTA observations of the request arena,
arena release, root-status entry/built/sent, TCP connection, SDK begin/write/end
boundaries. It retains counts, minima, time of the lowest free value and maximum
payload size. It performs no formatting, heap allocation, endpoint polling or
logging per boundary. Internal heap inspection and fixed-storage updates run
only within an accepted diagnostics epoch and existing in-flight-work barrier.
OFF does no heap inspection; a new epoch resets old rows and rejects late work.
Production entry points are no-ops, with no recorder state/route. Frozen evidence
can be reported after cleanup; reporting is refused during active ownership.

The host's `--memory-evidence` mode fetches the fixed-schema test report after
transfer/cancellation, after stopping its observer and before closing its own
metrics lease. It requires the original boot and metrics epoch, bounds rows and
numeric values, excludes unknown fields and performs no automatic transfer
retry. Failure evidence is best-effort; unavailable evidence does not prevent
metrics cleanup. See the
[recorder procedure and limitations](DEBUGGING.md#test-only-allocation-boundary-recorder).

Evidence storage is 484 bytes; mutex/state/padding and additional instrumented
call frames also cost memory. Current offline builds:

| Build | Application bytes | Static DRAM bytes |
| --- | ---: | ---: |
| Production USB / guarded OTA | 1,045,744 | 53,336 |
| Unconfigured memory test | 1,049,376 | 53,824 |
| Configured compile-only memory test | 1,057,360 | 54,080 |

The configured test used a clearly public compile-only canary outside the repo;
it must never be installed. Its worker relocation audit includes SDK writer and
boundary calls, with no boot-selection/journal-save/restart calls. All 67 tool
tests pass, including post-success/failure evidence, cleanup and wrong boot/
epoch/duplicate-row rejection. Sanitizer tests cover the actual runtime recorder
(OFF/denied acquisition means zero heap calls, readers released, active report
refusal, epoch isolation), fixed accumulators and the bounded HTTP adapter.

No hardware was flashed or commanded during this step. Read-only preflight
found the existing production controller online with torque OFF, monitoring
disabled, metrics OFF, but **not ready: FAULT / Safety interlock**. This blocks
another receiver test; the fault was not cleared, torque was not changed and
the controller was not rebooted. The prepared recorder is not a completed
runtime measurement or a demonstrated optimization. Resume supervised testing
only after the underlying fault is understood and fresh status confirms all
normal stationary/OFF/ready preconditions. Keep the 20-entry log, production
admission disabled and experimental floors unchanged.

Next, run one instrumented nonactivating transfer under the same workload and
compare the boundary evidence with the original abort. Intermediate expression
and SDK-internal peaks remain unmeasured, so this narrows allocation candidates
without claiming an exact per-operation memory cost. Select one small change
only after examining the observations, then repeat with identical instrumentation.

## First instrumented hardware run (2026-10-23)

The user cleared the safety-interlock fault, mechanically supported the cover
and released torque. Fresh status confirmed ready/calibrated, clean settings,
stationary torque OFF, metrics OFF/zero viewers, accepted production startup and
monitoring disabled. A private USB backup covered the partition table, NVS,
native otadata, app0 and the entire app1; app1 was verified erased and app0
matched the frozen production binary. No servo/settings commands were sent.

The recorder image (1,057,376 bytes; 54,080 bytes static DRAM) used a fresh
private key and the unchanged 131,072/65,536-byte experimental floors. SDK
writer/boundary calls and activation exclusion were audited before installation.
It received **12,288 bytes**, then maintenance revoked clearance with physical
and STA checks valid: free internal heap **126,944 bytes**, largest block
**110,580 bytes**. The host correctly reported an interrupted transfer, not
verification or activation. The guard is a periodic maintenance validation,
not an atomic guarantee that every transient allocation stays above the floor.

Frozen artifacts, source hashes, raw USB output, JSON boundary evidence and a
measurement summary are private under `diagnostics/ota-memory-probe-20261023/`.
Representative boundary observations from that run:

| Boundary / ownership bucket | Minimum free heap, bytes | Uptime at that minimum, ms |
| --- | ---: | ---: |
| Root status entry, before ownership | 130,356 | 9,546 |
| Root status built, before ownership | 127,332 | 9,552 |
| Root status sent, before ownership | 117,068 | 9,560 |
| TCP connected | 140,488 | 10,693 |
| SDK begin before / after | 133,496 / 133,436 | 10,717 / 10,719 |
| SDK write before / after | 128,852 / 128,864 | 10,828 / 11,806 |
| Root status entry, active ownership | 135,588 | 12,615 |
| Root status built, active ownership | 132,372 | 12,622 |
| Root status sent, active ownership | 117,136 | 12,632 |

The actual revocation was at uptime **12,233 ms**. Thus the lowest active-bucket
HTTP values above were recorded **after the abort**, while the owner was still
cleaning up. They cannot explain that earlier revocation. Before-admission
post-send observations also show brief low heap while no SDK write was active.
The largest status response was 3,198 bytes. The pinned WebServer sends the
body by const reference; its client passes bytes to the socket. The measurements
therefore do not establish an extra full-body copy inside `send`, or distinguish
queued networking allocations from unrelated concurrent work. No serializer
optimization is justified by subtracting these independent minima.

Radio conditions differed: this run used another BSSID and approximately
−86..−88 dBm, versus approximately −73..−75 dBm in the earlier controlled repeat.
The recorder counted eight root-status dispatches, while the observer logged
four snapshots and the tool performs one additional cancellation status read.
This suggests additional HTTP polling, but request origins were not recorded.
The run is not a controlled before/after optimization comparison. SDK
finalization was not reached, and no complete image/activation/rollback proof
was obtained.

Fresh status confirmed torque OFF, ready, no motion, maintenance unlocked and
metrics OFF/zero viewers after the abort. Independent USB readback verified
the received 12-KiB app1 prefix byte-for-byte against the intended production
payload. Partition table and complete native otadata were unchanged.

### Recorder correction and next controlled run

The recorder now freezes the current metrics epoch at transfer exit, before
SDK abort/maintenance release and host cleanup reads can overwrite minima.
It skips further heap inspection in that epoch and rejects publication from a
sample racing freeze. A later explicit metrics epoch can start a fresh baseline.
This correction is locally tested and compiled; it was **not installed** during
the recorded run. It changes no production sampling, memory floors, log capacity,
receiver admission or motion checks. Native runtime tests verify frozen epochs
do no heap scans, retained evidence is unchanged, and the next epoch resets.

Before another transfer, use stable radio conditions and close other controller
pages so the observer workload is controlled. Run the corrected recorder with
the same floors. If HTTP traffic remains the dominant candidate, compare a
deliberately quieter observer workload before changing response serialization
or framework buffers. Preserve read-only boot/transaction checks and firmware
physical validation. Do not lower the floor simply to obtain a completed test.

The corrected recorder passes sanitizer runtime tests (including zero heap scans
after freeze and reset on the next epoch), both production builds, unconfigured
test build and configured full-worker build/audit. The configured correction is
1,057,488 bytes with 54,080 bytes static DRAM and is archived separately as
`prepared-freeze-artifacts/NOT_INSTALLED.txt`. The measured image remains frozen
in `probe-artifacts/`; source hashes distinguish the two revisions.

Known production ELF
`893a06f89a4eed801dbe0f852a1b9926f79149af63691c192b7faba10de91de0`
and the original full erased app1 were restored via USB; both written ranges
passed device hash verification. Final HTTP checks confirmed accepted startup,
ready status, saved calibration/profile unchanged, torque OFF, no movement,
maintenance unlocked, metrics OFF/zero viewers, monitoring disabled and normal
OTA unavailable. Temporary plaintext credential/header were retired afterward;
test binaries remain private. The log remains 20 entries. No complete transfer,
activation or rollback claim follows from this partial-write/abort test.

## OTA paused for USB memory/WiFi characterization (2026-10-23)

Following the user's report of rapid UniFi roaming, the planned corrected OTA
repeat was not installed. Investigation moved to a separate three-minute
USB-only idle baseline with no receiver task, browser polling or metrics viewer.
The callback/collector are excluded from production; the USB profile also
unconditionally disables admission even with a local OTA configuration.

The completed run recorded 173 heap samples, zero HTTP requests, a successfully
registered allocation-failure hook and zero allocation failures/lost metadata.
Settled free internal heap stayed approximately 155.4–155.6 KB with a 110,580-byte
largest free block. There was one startup `ASSOC_FAIL` event, then successful
association and no observed BSSID changes in the capture. This is evidence
against idle heap exhaustion in that workload, not proof about the earlier
UniFi events or OTA/full-traffic peaks. The arbitrary experimental OTA floor
must not be confused with a measured out-of-memory boundary.

Exact artifacts and raw/summary evidence are private under
`diagnostics/usb-memory-baseline-20261023/`. Full native otadata and the partition
table matched before/after; a device digest confirmed app1 remained identical
to its complete erased backup. The collector ended automatically and produced
no further memory frames during the post-window observation. No motion,
configuration, OTA transfer or servo EEPROM command was issued.

See the [memory experiment and next workload](MEMORY_OPTIMIZATION_PLAN.md#usb-idle-memorywifi-baseline--2026-10-23)
and [USB procedure](DEBUGGING.md#usb-only-memory-and-wifi-baseline).
Next, measure one controlled status client with metrics OFF and at least two
minutes of quiet recovery; then measure an explicit metrics viewer separately.
Keep monitoring disabled, log capacity at 20, safety checks intact and OTA
release gates closed. No queue/stack/network tuning or lower reserve is
justified by an idle-only observation.

Normal production was restored and device-hash verified afterward (ELF
`66b9ee23b109e1d94faa9749939f30135f7dcec0ae3a06b910ae48aac33e7b37`).
Independent HTTP checks confirmed accepted startup, ready, calibration/profile
preserved, no motion, torque OFF, metrics OFF/zero viewers, maintenance unlocked,
monitoring disabled and OTA unavailable. The three-minute USB recorder is absent
from normal firmware.

## Controlled HTTP memory result (2026-10-23)

With OTA still disabled and the identical USB baseline image, one controlled
status client completed all 20 requests with metrics OFF, followed by 139.6
seconds without HTTP. Device counters matched the client exactly. Internal free
heap went from a pre-load median of 155,408 bytes to a sampled load low of
146,384 bytes, then a post-recovery median of 155,180 bytes. Most retained memory
returned around two minutes after the requests. There were zero allocation
failures, WiFi disconnects or observed BSSID changes. The 228-byte median
difference is not enough to diagnose a leak; exact allocation ownership was
not traced. The radio used another AP from the previous idle run, so use the
within-run before/load/recovery comparison.

These results do not establish an OTA reserve or reproduce a failure boundary
for bisection. Next, measure one explicit metrics viewer separately; keep all
release gates and the 20-entry log unchanged. Exact captures, request timestamps
and analysis are private under `diagnostics/usb-http-memory-20261023/`; the
[memory plan](MEMORY_OPTIMIZATION_PLAN.md#controlled-status-polling-and-recovery--2026-10-23)
records the full table and limitations. Native boot metadata/partition table
were unchanged, and production was restored/hash verified with ready status,
saved calibration/profile preserved, torque/metrics OFF, monitoring disabled
and OTA unavailable. The read-only client/analysis and existing tool suite
pass all 75 tests. No firmware tuning or lower memory threshold was applied.

### Manual browser exercise: stack margin is the next constraint (2026-10-23)

The user's browser/control exercise recorded no allocation failures, but cover
minimum unused stack reached **512 bytes out of a 6,144-byte task stack**.
A software restart followed network/settings maintenance, and read-only telescope
monitoring became enabled afterward; treat the recording as two partial boot
segments with different workloads/APs, not a completed ten-minute leak test.
The observed AP change spans the restart, rather than connected roaming.
Two motion-settling timeouts were captured with torque OFF confirmed and valid
position reads; track these separately from the resource investigation.

Before resuming OTA admission/flash-reserve work, audit the cover task's deepest
motion/fault/logging paths and validate adequate stack margin under those paths.
Keep the 20-entry log and existing OTA release gate. Do not lower heap thresholds
or shrink task stacks on this evidence. See the
[manual browser findings](MEMORY_OPTIMIZATION_PLAN.md#manual-browsercontrol-exercise--2026-10-23)
for measurements, limitations and restoration status.

The user confirmed the restart was caused by saving Alpaca settings. Production
ELF `66b9ee23…` was subsequently restored and verified with torque OFF,
unchanged saved calibration/profile, metrics OFF and OTA unavailable. Read-only
Alpaca monitoring remains enabled/connected per the user's settings. No firmware
resource sizes or OTA admission limits were changed based on this capture.

### Cover stack audit implemented (2026-10-23)

Removed temporary motion-history copies from the worker/start-move path and
isolated boot-only application-settings storage. Pinned ESP32 compiler reports
show worker frame 2,880 → 2,240 bytes and `beginMove` 624 → 96 bytes, saving
1,168 bytes across those two nested frames without increasing task stack,
static RAM or heap allocation. Safety, worker-maintenance and emergency-cover
host suites pass with ASan/UBSan; normal and USB measurement firmware build.
See the [stack audit](MEMORY_OPTIMIZATION_PLAN.md#cover-task-stack-reduction--2026-10-23)
for the change, measurements and limits. Full supported motion/fault workload
verification remains required before treating the new runtime margin as proven.
OTA release/admission and memory thresholds remain unchanged.

The revised build passed a 35-second stationary USB check: cover minimum unused
stack 1,456 bytes, failure hook registered with zero allocation failures, no HTTP
workload and no actuator commands. This is startup/idle evidence only. Revised
normal production ELF `49c92048…` was then installed and verified with unchanged
calibration/profile, torque OFF, metrics OFF, connected read-only Alpaca and OTA
unavailable. The experimental recorder is no longer installed.

### OTA-inclusive USB measurement: admission guard reached (2026-10-23)

Implemented a separate passive-USB/nonactivating receiver profile and client
`--passive-usb` mode, keeping browser metrics OFF and the original experimental
131,072/65,536-byte guards. With read-only Alpaca configured, receiver-enabled
idle internal heap was approximately 130–133 KB. A single preparation was
rejected at **128,860 bytes**, 2,212 below the guard; physical/STA checks passed,
largest block was 110,580 bytes and no allocation failure was recorded.
Maintenance cleanup completed and Alpaca polling resumed. **Zero firmware bytes
were transferred; the SDK flash phase was not reached.** No retry or lower floor
was applied. This is an admission-budget finding, not proof of out-of-memory.

See the [OTA-inclusive measurement](MEMORY_OPTIMIZATION_PLAN.md#ota-receiver-with-passive-usb-measurement--2026-10-23)
for artifacts, costs and limitations. Next, identify avoidable resident receiver
and status/admission allocations or establish a justified experimental budget;
full transfer peaks are still unknown. Keep the production gate closed. The
new mode and original tool path pass all 80 host tool tests; the USB collector,
configuration guards and production/baseline/probe builds also pass.

USB recorded 136.3 seconds of incoming-HTTP-quiet recovery: median internal free
heap returned to 132,626 bytes versus 132,484 before preparation, with zero
allocation failures. The entire inactive slot matched its original erased
backup by device digest; partition table and native otadata also matched.
The test did not reach SDK begin/write/end and establishes no full-transfer
reserve or activation/rollback claim.

Normal production ELF `49c92048…` was restored/hash verified afterward, with
accepted startup, unchanged saved calibration/profile, stationary torque OFF,
metrics OFF/zero viewers, maintenance idle and enabled/connected read-only
Alpaca. Production OTA remains unavailable. Temporary plaintext credentials were
retired and the full original inactive slot was verified unchanged.

### Supervised nonactivating transfer with revised test guard (2026-10-23)

The user authorized proceeding with supervised OTA work and lowering the
experimental heap guard rather than making further allocation optimization a
prerequisite. The previous 131,072-byte guard was not a measured minimum and
stopped admission without an allocation failure. For this separate experiment,
use **98,304 bytes (96 KiB)** internal free heap, retaining the **65,536-byte**
largest-block guard. The 32 KiB reduction permits exploration past the known
admission budget while retaining a nonzero stop threshold; it is not a certified
reserve or permission to enable production OTA.

Keep the same passive USB collector, 20-entry log, read-only Alpaca configuration,
metrics OFF, authenticated one-shot receiver and inactive-slot-only test branch.
No activation, transfer-journal save or reboot is compiled into that branch.
The complete original erased app1 backup was freshly matched against the device
by digest, current native metadata was backed up, and the normal production
recovery image was frozen before installation. Private evidence lives under
`diagnostics/ota-usb-transfer-96k-20261023/`.

Record the actual transfer outcome and memory evidence below. Afterward, verify
the written image if complete, compare boot metadata, restore the original
inactive slot and normal firmware, verify calibration/monitoring and retire the
temporary plaintext credential. Full transfer, activation and rollback remain
separate claims; this experiment addresses only the first.

**Result: complete authenticated transfer, verified without activation.**
The receiver accepted all 1,045,600 bytes, ran SDK begin/write/end and returned
`NOACT` / `VERIFIED_NOT_ACTIVATED`. Receiving-to-verified took 43.64 seconds.
Periodic USB samples recorded a 119,148-byte minimum free internal heap and
110,580-byte minimum largest block. Allocation hook was registered, with zero
failures/lost metadata and no guard revocation. Cover/OTA minimum unused stacks
were 1,464/3,532 bytes; this does not bound unexercised failure paths.

After 147.7 seconds without incoming controller HTTP, median internal free heap
returned to the pre-attempt 132,426 bytes. Metrics stayed OFF; configured Alpaca
polling paused under maintenance and resumed after cleanup. USB digest matched
the entire written payload, and native otadata/partition table remained unchanged.
Evidence is in `diagnostics/ota-usb-transfer-96k-20261023/`; see the
[complete transfer measurements](MEMORY_OPTIMIZATION_PLAN.md#first-complete-nonactivating-ota-transfer--2026-10-23).

This establishes one successful supervised transfer at a **test-only** 96 KiB
heap floor. It does not approve that floor for production, establish candidate
boot health, prove activation/journal handoff or exercise rollback/power loss.
The next OTA package is controlled activation, startup acceptance and recovery
validation with USB recovery available and the same supported-cover/torque-OFF
preconditions. Normal OTA release stays gated while that work is designed/tested.

Cleanup is complete. Both normal app0 (`49c92048…`) and the full original erased
app1 backup were restored with device hash verification. USB/HTTP checks verified
accepted production startup, unchanged calibration/profile, stationary torque
OFF, maintenance idle, metrics OFF and read-only Alpaca reconnected. Normal OTA
remains unavailable. Temporary plaintext credentials/header were retired.

## Controlled activation and pending-first-boot recovery (2026-10-23)

The next supervised experiment exercises the real production commit/journal and
startup paths, with the general upload CLI still disabled. Two temporary
receiver-enabled, production-compatible builds have separate private credentials
and distinct ELF identities: USB source A in app0 and healthy candidate B for
app1. Both use the previously exercised 98,304/65,536-byte **test** guards. No
production defaults, safety policy or settings schema is changed.

`tools/probe_ota_activation.py` is an explicit experiment runner requiring both
supported-cover/OFF confirmation and an activation/recovery flag. It uses the
existing authenticated `Uploader` engine, records USB and redacted status,
and performs no actuator/settings/metrics request. First expect COMPLETE for
A → B with accepted startup and a matching durable transaction. Then upload the
normal recovery image from B into app0 and issue one EN reset after that image's
BOOT, the source's reboot event and a final selection ACK, before the startup
acceptance window. Expect bootloader rollback to B and a matching ROLLED_BACK
record. A missed gate or any different verdict stops without retry; no guessed
rollback success is reported. This tests reset during pending first boot, not a
watchdog hang or actual power interruption.

The installed bootloader was freshly device-digest matched to the pinned SDK
build, whose rollback configuration is enabled. Both application builds pass
manifest/layout checks; the full erased app1 backup was freshly device-matched.
Original native metadata was backed up separately from application NVS; app0 was
VALID (sequence 1) before testing. The reset gate and existing host workflows pass
all 83 tool tests. Evidence/builds/credentials remain private under
`diagnostics/ota-activation-20261023/`.

After testing, back up the resulting native slot state, then restore only the
original native otadata, normal app0 and original erased app1 over USB. Preserve
live application NVS and the bounded historical OTA result; do not overwrite
settings with an old NVS backup. Verify safe normal startup and monitoring and
retire both temporary plaintext credentials. Activation/recovery outcomes follow
below; production release remains gated on the remaining failure/latency tests.

### Activation and pending-reset rollback hardware results

Both supervised stages passed on 2026-10-23 (America/Phoenix):

| Stage | Actual result |
| --- | --- |
| Healthy A/app0 → B/app1 | `COMPLETE`; different candidate ELF/boot ID, accepted startup, matched durable source/target/transaction and positive selection evidence |
| B/app1 → normal image/app0, reset before acceptance | Exactly one EN reset after the expected target BOOT and final selection ACK; automatic return to B/app1, accepted startup and matched `ROLLED_BACK` record |
| Native slot metadata after rollback | app0 sequence 3 `ABORTED` (4); app1 sequence 2 `VALID` (2) |
| Independent image verification | Both transferred binaries matched by USB device digest |
| Physical/controller state after recovery | Ready/calibrated CLOSED, unchanged saved limits/endpoints/profile, stationary torque OFF, no maintenance owner and metrics OFF |

USB recorded precisely four experiment boots: initial source A, healthy B,
interrupted normal candidate, and recovered B. The candidate BOOT line reported
34 ms uptime; the host issued its single bounded 100 ms EN pulse immediately
following that line, before acceptance. Native ABORTED/VALID states and the
matched durable transaction establish recovery; a reboot alone was not accepted
as proof. Healthy activation occurred around **16:51:33 Arizona time**; the
reset/rollback occurred around **16:52:24–16:52:29**. SDK-compatible bootloader
bytes were verified before the experiment. No bootloader or partition-table
update was made.

The temporary A/B builds have production-compatible descriptors and private
credentials so they exercise the real commit/journal path; they are private
bench artifacts and must not be distributed. The test driver does not turn on
browser metrics or move the cover. Allocation-failure recording was not enabled
in this run, so it adds no new failure-count/memory-reserve claim beyond the
preceding passive-USB transfer experiment.

This validates healthy acceptance and **reset during pending first boot**. It
does not validate RTC/watchdog hangs, actual power interruption/torn-write
recovery, Stop/radio-loss races during flash, or a final production memory and
latency budget. Those remain release checks. Restoration status follows below.

Restoration completed with device hash verification for **all three ranges**:
original 8 KiB native otadata, normal app0 and the full original erased app1.
Only boot-selection metadata was restored; live NVS/settings were preserved.
Follow-up USB/HTTP checks confirmed normal ELF `49c92048…`, accepted startup,
unchanged saved limits/endpoints/profile, ready/calibrated CLOSED, stationary
torque OFF, maintenance idle, metrics OFF/zero viewers and read-only Alpaca
connected. Normal OTA is again unavailable. Both temporary plaintext credentials
and headers were retired; credential-bearing build artifacts remain private.

The bounded historical journal intentionally retains the test's ROLLED_BACK
result. It describes the proven recovery before USB restoration, not a new fault
in the currently running normal image. No historical record or application
settings were erased to hide the experiment. The next hardware checks should
cover interrupted uploads/cancellation/Stop and startup watchdog failure, with
power-loss/torn-write tests still distinguished from the EN-reset evidence.

## Interrupted stream, authenticated cancellation and retry (2026-10-23)

The next explicit bench experiment uses the existing production receiver with a
temporary private credential and the previously exercised 98,304/65,536-byte
**test** guards. No firmware receiver behavior or production default is changed.
The full original inactive slot is freshly digest-matched and native otadata
backed up separately from live NVS before installation.

`tools/probe_ota_interruption.py` requires explicit experiment and supported-cover/
OFF flags, records USB/status and performs three planned transactions:

1. After exactly **65,536 acknowledged bytes**, close only the TCP sender. The
   driver suppresses the ordinary uploader's automatic cancellation after this
   deliberate fault, so the receiver's incomplete-stream failure is tested on
   its own. Require FAILED, matching unselected durable record, unchanged
   running firmware/boot, torque OFF and released maintenance.
2. At the same offset, send a boot/transaction-bound authenticated cancellation.
   Keep the data socket open until the receiver reports cancellation and cleanup,
   then close it. Require CANCELLED with the same identity/safety checks.
3. Without resetting the source between those attempts, upload the full image.
   Require COMPLETE and healthy candidate startup. This planned next transaction
   proves retry/re-arm usability; it is not an automatic repeat of an ambiguous
   attempt.

The callback validates receiving phase/boot/transaction/byte count before any
injection. Only deliberate injections suppress the normal failure cleanup;
unexpected transport failures retain the regular cancellation behavior. A
terminal journal checkpoint can precede maintenance release, so the driver
waits a bounded interval for actual safe cleanup before asserting success.
No serial reset injection is armed for this experiment. This is a TCP failure
case, not an AP/WiFi outage, Stop test or power interruption. Results follow below.

### Interrupted upload and cancellation hardware results

All three stages passed on **2026-10-23, approximately 17:01–17:02 Arizona time**:

| Stage | Observed result |
| --- | --- |
| TCP sender disconnected after 65,536 acknowledged bytes | FAILED, `transfer_incomplete_or_invalid`; matching durable unselected transaction, original source boot retained |
| Authenticated cancellation after 65,536 acknowledged bytes | CANCELLED while the data connection was still open; matching durable unselected transaction, original source boot retained |
| Full subsequent upload from the same source boot | All 1,045,600 bytes transferred; healthy target startup and matched durable COMPLETE with selection confirmed |
| Controller cleanup after both injected failures | Stationary torque OFF, maintenance unlocked, metrics OFF; a fresh transaction could arm without resetting the source |
| Independent USB verification | Source app0 and target app1 both digest-matched; native app0 sequence 1 VALID and app1 sequence 2 VALID; partition table unchanged |

The three transactions were distinct. USB recorded only the initial source boot
and the final healthy candidate boot; no reset injection was armed. Cancellation
returned HTTP 202, and cancellation/inactive state was observed before closing
the TCP socket. The subsequent full transfer establishes receiver reusability
after both failures, rather than merely observing a terminal status.

The temporary source ELF was `b8f9e9d7…`; the final target was normal ELF
`49c92048…`. Browser metrics remained OFF, the controller log remained at 20
entries, and configured read-only Alpaca monitoring remained enabled. These
runs used the previously authorized **98,304-byte internal-heap / 65,536-byte
largest-block test guards**. They do not establish a production memory reserve;
no allocation-failure collector was active in this run.

The new bench driver and its safety/identity/cleanup checks pass the host tool
suite (**91 tests**). Whole-radio loss, explicit Stop during flash, watchdog
startup hangs and actual power interruption/torn writes remain separate release
checks. The general upload CLI and normal firmware receiver remain disabled.

Restoration completed with USB hash verification for all three ranges: original
native otadata, normal app0 and the full original erased app1. Live NVS was
preserved. Follow-up USB/HTTP checks confirmed accepted normal startup, unchanged
saved limits/endpoints/profile, ready/calibrated CLOSED, stationary torque OFF,
maintenance idle, metrics OFF/zero viewers, normal OTA unavailable and read-only
Alpaca connected. Temporary plaintext credential/header were retired; compiled
credential-bearing artifacts remain private. The historical COMPLETE record is
retained as evidence of the successful test, without rewriting application NVS.

## Explicit Stop during transfer (2026-10-23)

The next supervised stage extends `tools/probe_ota_interruption.py` with
`--stop-experiment`. It sends one explicit authenticated browser-style Stop at
65,536 acknowledged bytes, with the data socket still open and no automatic
signed OTA cancellation. Require exactly one Stop-epoch increment, torque OFF,
no movement, loss-of-maintenance-clearance failure, released maintenance and a
matched unselected durable record on the unchanged source boot. A distinct full
upload then checks re-arming and healthy activation without resetting the source.

The driver uses the boot-bound UI session only in memory, discards response
text, and records no tokens. Normal firmware/OTA defaults are unchanged. Current
native otadata and the full erased inactive slot are backed up/verified before
installing the temporary private source, using the same 98,304/65,536-byte test
guards. The cover remains supported and already torque OFF; this is not a test
of release under mechanical load. Injection at an acknowledged block boundary
proves Stop handling during an active flash transaction, but does not establish
worst-case latency during a blocking flash call or at the final commit boundary.
Results and restoration status follow below.

### Stop hardware result

The injected Stop passed at approximately **17:12:18 Arizona time**. It returned
HTTP 202, incremented the Stop epoch from 0 to 1 and produced the matching durable
FAILED record with `maintenance_clearance_lost` and selection unconfirmed. The
source boot/image remained unchanged, position remained 496, state became
STOPPED, torque stayed OFF and maintenance returned to idle while the sender's
data socket remained open. No OTA cancel request or reset injection was used.

Device timestamps show Stop worker handling at 11,610 ms uptime, confirmed
STOPPED/torque OFF at 11,613 ms, OTA failure at 11,620 ms and maintenance idle at
11,817 ms. These are single-run event observations, not an HTTP-to-actuator
latency bound or a blocking-flash worst case. The driver passed **95 host tool
tests**, including Stop identity/epoch checks and terminal-record cleanup races.
The subsequent full-upload result and restoration are recorded below.

The following full upload also passed on the **same source boot**, with a fresh
transaction: 1,045,600 bytes transferred and durable COMPLETE after healthy
normal-image startup at approximately 17:13:18 Arizona time. USB recorded only
the initial source and final candidate boots. Source ELF was `69fe5d2d…`, target
`49c92048…`; log capacity stayed 20, metrics stayed OFF and read-only Alpaca
remained configured. No allocation-failure collector was enabled, so this adds
no new allocation-failure-count or production reserve claim. The source's
subsequent upload proves re-arming after explicit Stop without a source reset.

Independent USB verification matched both the temporary source in app0 and the
normal target in app1. Native slot metadata was app0 sequence 1 VALID (2), app1
sequence 2 VALID (2), with the partition table unchanged. The only activation
was the complete follow-up transaction; the Stop-aborted partial image was
never selected. Normal receiver defaults remain disabled. Worst-case flash/
commit Stop timing, whole-radio outage, startup watchdog hangs and actual
power-loss/torn-write recovery remain outstanding release checks.

Restoration completed with device hash verification of original native otadata,
normal app0 and the full original erased app1. Live NVS and the historical
COMPLETE record were preserved. Final USB/HTTP checks confirmed accepted normal
startup, ready/calibrated CLOSED, torque OFF, no movement, unchanged saved
limits/endpoints/profile, maintenance idle, metrics OFF/zero viewers, normal
OTA unavailable and read-only Alpaca connected. Temporary plaintext credential
and header were retired; compiled credential-bearing artifacts remain private.

## Autonomous RTC watchdog startup recovery (2026-10-23)

`tools/probe_ota_watchdog.py` prepares isolated source snapshots and runs an
explicit bench experiment with a private healthy receiver-enabled source.
Production `src/` is never edited to inject hangs. The normal receiver/CLI
release gates stay closed. Two startup locations are investigated:

1. Before `setup()`, inside the strong `verifyRollbackLater()` hook, immediately
   after the unchanged production 45-second RTC watchdog is armed. The hang
   yields to the scheduler but never returns to Arduino or initializes workers.
2. During `setup()`, after the existing journal/startup coordinator and
   diagnostics initialize, before cover worker/network setup and acceptance.

Both candidates print their actual runtime ELF and hang stage through ROM UART.
They do not feed/disable the RTC watchdog, issue motion or accept themselves.
The host owns passive USB with the reset gate unarmed and allows 90 seconds for
reconciliation: the 45-second watchdog plus network/startup recovery. Missing
recovery is UNCONFIRMED, never authorization for an automatic repeat/reset.
Require one matching candidate hang marker, an autonomous RTCWDT reset followed
by accepted source startup, and a matching durable ROLLED_BACK transaction with
selection confirmed. Independently verify candidate bytes and native ABORTED/
VALID states over USB before overwriting a candidate with another test image.

Use the supported-cover/torque-OFF policy and the previously exercised
98,304/65,536-byte test guards, with browser metrics OFF and the 20-entry log.
Fresh full-slot/native backups and device verification of the rollback-enabled
bootloader precede installation. Restore original native otadata, normal app0
and full original inactive slot afterward; preserve live NVS and retire the
private source credential/header. Hardware results follow below.

### Before-setup watchdog hardware result

The earliest hang passed on 2026-10-23 at approximately **17:23–17:24 Arizona
time**. Candidate `1c44993f…` printed its sole hang marker inside
`verifyRollbackLater()`, before Arduino setup and before any candidate BOOT/
worker/network initialization. Approximately **44.010 seconds** later the ROM
reported `rst:0x10 (RTCWDT_RTC_RESET)`. The healthy source `cd258e8d…` returned,
accepted startup and recorded the matching ROLLED_BACK transaction
`3c15f3e73f988284c4354ec6d65b9fdd`. The configured watchdog remains 45 seconds;
the UART interval is a host-observed single-run interval, not a timer accuracy
specification. The host gate stayed unarmed and injected no reset.

Independent USB digest checks matched source app0 and candidate app1. Native
metadata showed app0 sequence 1 VALID (2), candidate app1 sequence 2 ABORTED (4),
and the partition table was unchanged. These checks completed before overwriting
the failed candidate for the next stage. The source remained stationary torque
OFF, ready/calibrated, with unchanged settings, idle maintenance and metrics OFF.

### Setup-hang watchdog hardware result

The second candidate `eb803328…` also recovered autonomously, at approximately
**17:25–17:26 Arizona time**. It reached `beginOtaStartup()` and diagnostics,
printed its setup-stage marker, then yielded forever before the cover worker,
web services and startup acceptance. The ROM reported RTCWDT_RTC_RESET; source
`cd258e8d…` returned with the matching durable ROLLED_BACK transaction
`e53127d76dfaf59cb9ef4352aeb341de`. The host reset gate remained unarmed. This
separately tests a pending candidate that loaded the durable journal before
hanging, in addition to the earlier pre-setup hang.

Both source snapshots leave the watchdog configuration and bootloader unchanged.
Only private snapshot files contain hang injections; production firmware source
is unchanged. Their application descriptors are intentionally compatible for
the real OTA admission/commit path. These private hang images must never be
published or used as recovery firmware. They establish startup reset/rollback
behavior, not a runtime memory reserve or torque-release test under load. Normal
production OTA remains disabled. The host tool suite passes **101 tests**.

### Remaining physical test dependencies

The next recovery gate is **actual power interruption**, distinct from EN reset
and RTC watchdog reset. The present host has USB serial/flash control but no
established controller-power switch. A useful power-loss test needs controlled
switching of every ESP32 supply path, including USB back-power, while retaining
an independent way to observe/recover the device. Keep the cover supported and
torque OFF. Do not treat disconnecting only servo power or pulsing EN as an
ESP32 power-loss test.

With that fixture available, test interruption during inactive-image writes,
durable journal checkpoints/final selection and pending startup. Verify original
settings, safe nonmoving boot, native slot metadata and an honest durable
outcome after each attempt; preserve and independently verify both slots before
restoration. Narrow checkpoint/torn-write windows need controlled triggering,
not an assumption that a manually timed unplug hit a particular flash write.

Whole-radio/AP loss also needs a controlled outage of the controller's STA
connection and independent USB observation; closing the sender's TCP socket is
not that test. No authorization or tooling to switch the shared AP has been
established. Blocking-flash/final-commit Stop timing and the production memory/
latency reserve remain separate release gates. Do not enable the general OTA
uploader or call OTA production-ready based on the completed reset tests.

USB verification also matched the second source/candidate binaries and native
app0 sequence 1 VALID (2), app1 sequence 2 ABORTED (4), with the partition table
unchanged. The second hang-to-RTC-reset UART interval was **44.004 seconds**.
Both stages preserved stationary torque OFF, saved settings and metrics OFF.
Original-firmware restoration and final verification follow below.

### Watchdog experiment restoration

Normal firmware restoration completed with device hash verification for all
three ranges: original native otadata, normal app0 and the full original erased
app1. Live NVS was preserved. Follow-up USB/HTTP checks confirmed accepted normal
ELF `49c92048…`, ready/calibrated CLOSED, stationary torque OFF, unchanged saved
limits/endpoints/profile, idle maintenance, metrics OFF/zero viewers, normal OTA
unavailable and read-only Alpaca connected. The temporary plaintext source
credential and header were retired; private hang snapshots and compiled artifacts
remain excluded from distribution. The final historical ROLLED_BACK result is
retained as test evidence, not a new fault in the restored normal image.

Work is blocked at the next physical recovery test dependency: no controlled
ESP32 power switching fixture or AP outage control has been established for this
session. EN reset and RTC watchdog recovery are now proven independently;
actual supply interruption/torn writes and whole-radio-loss recovery are not.

## Manual power loss during partial transfer (2026-10-23)

The operator confirmed both USB and 12 V are attached and can be disconnected.
`tools/probe_ota_power_loss.py` uses the real receiver and upload transport,
slowed by 80 ms between acknowledged blocks. At 65,536 acknowledged bytes it
validates the active transaction/boot, receiving state and torque OFF, then
opens the manual disconnect window. An independent hard cap at 524,288 bytes
stops the sender before image completion, so a delayed response cannot activate
an image. Reaching the cap invalidates the test rather than automatically
retrying. The private source uses the established 98,304/65,536-byte test guards;
normal firmware defaults remain unchanged.

The operator is instructed to unplug USB, immediately disconnect 12 V, observe
the controller off for 10 seconds, then restore 12 V before USB. Serial loss
after the cue is expected and never itself cancels the WiFi transfer. No host
reset, serial reconnect or signed cancellation is sent after the cue. TCP
interruption alone remains UNCONFIRMED until actual all-power-off is confirmed.

Archive the **first recovered HTTP status before reopening USB**, requiring a
new POWERON source boot, safe stationary torque OFF, unchanged settings and idle
maintenance. The current receiver persists this transaction only at commit;
a power cut while receiving can legitimately leave the previous historical
journal unchanged. A matching unselected FAILED record can also be persisted
if the receiver detects failure before all supply energy disappears. Distinguish
that orderly failure from an uncheckpointed power loss. Never relabel an old
historical outcome as this transaction's FAILED/ROLLED_BACK result. Independently verify unchanged native selection,
source bytes and a nonempty incomplete target slot over USB after first-boot
capture. A manual cut establishes a broad transfer interruption case, not that
power was removed during a particular flash instruction, journal checkpoint or
commit. Restore original otadata, normal app0 and full original inactive slot,
preserve live NVS and retire the temporary credential afterward.

### First manual disconnect observations

The operator confirmed USB and 12 V were removed and all controller lights were
off for 10 seconds. The source returned with a new POWERON boot before any host
USB reopen: unchanged settings, stationary torque OFF, idle maintenance and
metrics OFF. A matching unselected FAILED journal was already present in the
first recovered response. This establishes safe power-cycle recovery around a
partial transfer, but the failure was persisted before complete shutdown; it
does not prove recovery from an uncheckpointed write. A servo read failure was
logged just before serial capture ended, consistent with staggered supply loss.

The host wrapper exposed a missing `mode` bookkeeping attribute while suppressing
its expected-disconnect cancellation. It failed before any cancel request; no
reset/cancel or automatic repeat was sent. The original traceback and cue are
preserved. Final ACK count was not saved, so evidence states **at least 65,536
acknowledged bytes**, without inventing an exact interruption offset. The
wrapper was fixed and an integrated cleanup regression check added.

USB verification independently matched the source image, original native
selection and partition table. Target first 65,536 bytes matched the payload;
an unsent target page remained erased. Native app0 stayed sequence 1 VALID (2),
with the other entry sequence 0/UNDEFINED. No partial-image activation occurred.

For a cleaner second attempt, USB is removed while idle and the continued
12 V-powered source is verified before OTA starts. The refined driver uses
`--without-usb`: no serial port is opened, no reset gate is armed, and cutting
12 V removes the sole confirmed supply. Restore only 12 V first and capture the
first POWERON HTTP boot before reconnecting USB for device verification. The
same pacing and partial-image cap apply. This remains a manually timed transfer
case, not a journal/commit-window torn-write test.


### Second attempt: USB removal only, no 12 V cut

The operator subsequently clarified: **only USB was unplugged during the second
attempt**. The controller remained healthy on 12 V with the same boot ID and
continuous ACKs. This was expected for USB removal, not evidence of an unknown
power source. The earlier response reporting uncertain 12 V off-state/timing
was superseded by that clarification. This attempt is not counted as power-loss
validation. It reached the 524,288-byte cap, failed safely and never activated.
Original status/action records are preserved with the clarification attached.

The first attempt established a confirmed full power cycle and safe source
recovery, with a failure checkpoint already persisted. A new explicit 12 V cut
with USB already isolated is needed for the intended sole-supply interruption.
The host suite passes **110 tests**, including network-only observation and
honest classification of historical versus matching pre-shutdown FAILED records.

### Explicit sole-supply cut procedure

Following the operator's USB-only clarification, a separate third transaction
is prepared with one physical action per cue. USB is removed while idle; confirm
the same safe source boot on 12 V. During the capped transfer, explicitly ask the
operator to unplug the **12 V plug at the controller** and leave it disconnected.
Require observed lights off and a network outage, wait at least 10 seconds, then
ask for 12 V restoration alone. Capture the first recovered POWERON boot before
requesting USB reconnection for independent checks. No prior USB-only action is
counted as the 12 V cut, and no automatic retry is issued after an expired window.

### Explicit cut: first recovered boot

The third transfer was physically interrupted after **132,096 acknowledged
bytes**. USB data remained unplugged. The operator explicitly confirmed the
12 V plug was out and all controller lights were off; the host then timed an
additional 10-second off period before requesting power restoration.

The operator later clarified that the initial power reconnection had not worked;
a working **USB power supply** was then verified and the controller came on.
The long host-observed outage therefore includes failed/delayed restoration,
not a demonstrated WiFi/startup delay. The exact adapter path is not assumed:
this result must not be described as a proven cold boot from 12 V alone.

Before any Mac USB data reconnection/open, HTTP captured original private source
`82ea0f64…` on a new POWERON boot (`bc3c01cd…`), first seen at 4,783 ms uptime and
accepted by the next 6,069 ms sample. It was ready, stationary torque OFF, with
unchanged saved settings, idle maintenance and metrics OFF. The previous
historical FAILED journal remained **unchanged**; it belongs to the capped
second attempt, not this interrupted transaction `dbe9e0eb9625891ef6b4ba0adaf74213`.
This distinguishes uncheckpointed transfer interruption from the first attempt's
failure record saved before shutdown. Exact flash-instruction/journal/commit
power-loss windows remain untested. Device verification and restoration follow.

### Explicit-cut independent flash verification

USB device checks after the first recovered HTTP boot matched the full source
image and **all 132,096 acknowledged target bytes** against the payload. A target
page beyond the sender's cap remained erased. Original native otadata and the
partition table were byte-for-byte unchanged: app0 sequence 1 VALID (2), other
entry sequence 0/UNDEFINED. The interrupted partial image was never selected.

This validates manually timed **receiving-phase power-loss recovery without a
new failure checkpoint**: physical lights-off observation, timed off period,
network outage, recovered POWERON original source, unchanged saved settings/
historical journal, safe OFF state, unchanged native selection and independent
partial-flash verification. No host reset/USB reopen occurred before the first
recovery evidence. It does not establish an interruption inside a flash
instruction, durable journal update, boot-selection write or pending startup.
Those narrowly triggered power-loss/torn-write cases remain release checks,
along with whole-radio loss, worst-case Stop/commit latency and the deferred
production memory reserve. Normal receiver/CLI defaults remain disabled.

### Manual power-loss experiment restoration

Final restoration completed with device hash verification for original native
otadata, normal app0 and the full original erased app1. Live NVS was preserved.
USB/HTTP checks confirmed accepted normal ELF `49c92048…`, ready/calibrated
CLOSED, stationary torque OFF, unchanged saved limits/endpoints/profile, idle
maintenance, metrics OFF/zero viewers, normal OTA unavailable and read-only
Alpaca connected. Temporary plaintext credential/header were retired; compiled
credential-bearing artifacts remain private. The bounded historical FAILED
record from the capped second attempt is retained; it is not a current controller
fault and is not misattributed to the third power-loss attempt. No settings or
historical journal were erased to hide the tests. Final host tool suite: **110
passing tests**; no new allocation-failure collector/memory-margin claim.

## Power loss after durable intent, before selection (2026-10-23)

The next supervised manual test uses `tools/probe_ota_checkpoint.py`. Its
snapshot helper copies `src/` into a fresh private directory and changes only
Commit.persist there: call the real `saveRecord()` (including NVS readback),
then publish a distinct test reason and yield for at most 90 seconds. The test
method **always returns false**, so a missed power-cut cue cannot select an
image. The live production source, normal receiver defaults and bootloader are
unchanged. The private compatible-profile source/credential must not be shipped.

The full normal image is uploaded through the real receiver. After the final
ACK, the driver waits for the exact test reason, full byte count, matching
durable activation_intent with selection unconfirmed, source/target/transaction/
boot identity, ready OTA maintenance lease, stationary torque OFF and metrics
OFF. Only then issue a cut cue. The host allows 70 seconds, leaving margin
before the 90-second source barrier. It opens no USB port, sends no reset and
suppresses automatic cancellation only after this verified deliberate injection.
A network interruption alone remains unconfirmed until physical off-state and
the first recovered POWERON boot are reconciled. Timeout/status mismatch stops
the experiment without automatically repeating it.

Expected recovery is the **original source with an honest UNCONFIRMED journal**
for the matching transaction: the image was not selected and no positive
selection evidence exists. Do not call this COMPLETE or ROLLED_BACK. Require
safe accepted startup and unchanged settings, then independently digest-match
both full images and unchanged native otadata over USB. This is a power cut
**between completed journal persistence and selection**, not inside a journal
write, CRC/torn-write atomicity test or selected-candidate power-loss test.
The supported cover stays stationary torque OFF; the log remains 20 entries,
metrics OFF, read-only Alpaca configured and the established 98,304/65,536-byte
test guards in use. Current host tool suite: 115 tests; native protocol tests
also pass address/undefined sanitizers, including persist failure preventing
selection. Hardware result and restoration follow below.

### Post-intent/pre-selection manual power-loss hardware result

The checkpoint was established for transaction
`7e2db5311824003869006c2a82bc76a3`: all **1,045,600 bytes** received/verified,
matching durable activation_intent with selection unconfirmed, OTA maintenance
READY, metrics OFF and stationary torque OFF. Private source ELF was
`ded4bed1…`, target normal ELF `49c92048…`. The host then issued the cut cue;
network reachability was lost before the bounded barrier timed out, with no
signed cancellation or host reset.

The operator confirmed the controller's 12 V input was unplugged and all lights
were out. The host timed 10 additional seconds before requesting restoration;
the operator confirmed 12 V restored/lights on, with Mac USB still unplugged.
The first recovered HTTP response, **before Mac USB reconnection**, showed new
POWERON source boot `022ff0f4…`, accepted startup at 5,309 ms uptime, unchanged
saved settings, stationary torque OFF, idle maintenance and metrics OFF.
The matching durable record reconciled to **UNCONFIRMED, selection false**.
This is the correct conservative result for a saved intent without evidence of
selection; no COMPLETE or ROLLED_BACK verdict was invented. Device digest/native
metadata checks and normal-firmware restoration follow below.

Independent USB verification matched **both full binaries**: private source in
app0 and the complete normal candidate in app1. Native otadata was byte-for-byte
unchanged from before the experiment: app0 sequence 1 VALID (2), other entry
sequence 0/UNDEFINED. The partition table was unchanged. The completed image
remained unselected; the saved intent survived the physical cut and reconciled
conservatively without a false deployment verdict. This validates the named
checkpoint boundary only. Precise cuts inside NVS/selection writes, selected
pending-image power interruption, whole-radio loss, worst-case Stop/commit
latency and the deferred production memory reserve remain release checks.
Normal receiver and general uploader remain disabled.

### Checkpoint experiment restoration

Normal restoration completed with device hash verification of original native
otadata, normal app0 and the full original erased inactive slot. Live NVS was
preserved. Final USB/HTTP checks confirmed normal ELF `49c92048…`, accepted
startup, ready/calibrated CLOSED, stationary torque OFF, unchanged saved
limits/endpoints/profile, maintenance idle, metrics OFF/zero viewers, normal
OTA unavailable and read-only Alpaca connected. Temporary plaintext credential
and header were retired; the private barrier source and credential-bearing
artifacts remain excluded from distribution. The matching historical UNCONFIRMED
record/selection false is retained as honest evidence of the interrupted test;
the restored controller has no motion fault. Production firmware source was not
changed to add the pause. Host tool suite: **115 passing tests**, plus the native
protocol suite under address/undefined sanitizers. This run adds no allocation-
failure collector or production memory-margin claim.

## Persistent development OTA hardware result (2026-10-23)

The user-directed development scope is now implemented and exercised. USB
installed development bootstrap `fc867675…` in app0, followed by **one actual OTA
transaction** `b063d6b45405df9e3e1c38503ad2362c` to a distinct clean-rebuilt
candidate `47da0d03…` in app1. Both images use the real production-compatible
manifest/settings/slot layout and contain no fault-injection pauses or test reset
injections. The real new CLI command returned COMPLETE after candidate startup.

The full **1,053,808-byte** development image transferred over WiFi, reached
verified/rebooting and booted with reset reason SOFTWARE. Matched durable source/
target/transaction/slot and positive selection evidence, accepted target startup
and a changed boot identity corroborate completion. Final checks confirmed
ready/calibrated CLOSED, stationary torque OFF, unchanged saved limits/endpoints/
profile, no controller fault, maintenance idle, metrics OFF/zero viewers and
read-only Alpaca connected. Crucially, `ota.development=true`, availability true
and idle state persist on the candidate: the next change can use OTA directly.
Both valid application images are retained for fallback; normal firmware was
**intentionally not restored** after this successful development deployment.

The first STA startup precheck failed association and opened the recovery AP;
it issued no challenge/prepare/transfer. A single USB startup/precheck retry
connected, then ran the CLI once. The link remained weak (roughly −87..−90 dBm)
and the receive-to-verified interval was about **76.3 seconds**. This is not a
new WiFi reliability or production memory-reserve claim. Passive USB captured
source/candidate identities; its reset gate stayed unarmed. No host reset,
actuator command, implicit browser-metrics activation or automatic OTA retry
occurred during the transaction. Independent USB flash readback was not repeated
for this unchanged transfer engine; normal-image/inactive-slot backups and
native metadata were verified before bootstrap and retained privately.

Final host tool suite: **125 passing tests**. Both development and normal USB
builds pass size/layout/descriptor/strong-startup checks. Normal image bytes were
checked to exclude the development marker and credential despite the local dev
header being present. Default production artifact validation rejects marked
development images; the development build/uploader opt in explicitly. Workspace
candidate identity matches the running image. Normal firmware defaults and the
reserved production upload command remain disabled.

The paired ignored owner-only `.ota-dev/secret` and `include/ota_dev_local.h`
are intentionally **retained**, allowing future updates with the same credential.
Dev build artifacts are private; `.ota-dev/recovery/` retains the previous normal
image, full original inactive-slot backup and original native otadata. Preserve
live application NVS if recovery is needed. The 20-entry log and provisional
98,304/65,536-byte guards remain unchanged. The user has deferred the outstanding
production power-write, timing, radio-loss and memory-margin gates for this
supervised local-development facility; they are not reported as tested.

## AP/channel comparison baseline — 2026-10-23

After the user reported separating channels and locking the client to the nearby
AP, the read-only baseline failed before an OTA attempt. Evidence is retained in
`diagnostics/ota-ap-lock-20261023/`. Opening passive USB capture reset the source
development image (`47da0d03…`); startup initially reported ASSOC_FAIL, then
connected to BSSID `74:83:c2:c4:77:7c`, channel 1, at `192.168.1.135`.
The AP identity/lock as applied in UniFi has not been independently confirmed.

The two-minute workload sent status requests at approximately 1 Hz and periodically
fetched the root page, without actuator commands or optional metrics activation.
There were 84 successful status requests (median 67 ms, maximum 164 ms), followed
by 24 failed requests. Successful samples ranged from -82 to -75 dBm. At source
uptime 92.759 seconds (19:29:56 Arizona time), USB reported disconnect reason 8,
ASSOC_LEAVE, on the same BSSID. The controller remained running and started its
fallback setup AP after 20 seconds. No further association was observed during
the immediate capture interval. The user subsequently confirmed changing WiFi
settings during this interval. This run is therefore confounded by a network
configuration change and does not establish a spontaneous connectivity failure;
the disconnect reason alone does not establish its cause.

Free heap was about 183 KB immediately after disconnection; the reported minimum
was 154,624 bytes. These aggregate values neither demonstrate exhaustion nor rule
out allocation/fragmentation problems; no allocation-failure collector was enabled.
The initial status was ready, stationary, fault-free and torque OFF. No OTA upload
was started and no firmware, settings, memory guards or log capacity were changed
on the controller. A same-source candidate (`6e18fc29…`) was built successfully
but remains uninstalled. Restore stable STA connectivity and repeat the baseline
before drawing an OTA comparison from this run.

### Repeat baseline and OTA result after configuration settled

After the user confirmed the concurrent WiFi change, a reboot and repeat baseline
passed all 120 status requests without a disconnect (59.5 ms median, 176 ms maximum).
The following uploader invocation stopped in local artifact validation because
the archived candidate lacked `partitions.bin`; it did not read the credential,
contact the OTA receiver or begin a transaction. This was corrected in the private
test harness, without changing firmware source or uploader behavior.

The completed run is in `diagnostics/ota-ap-lock-20261023/retry-complete/`:

- A fresh reboot had one initial ASSOC_FAIL, then recovered. The subsequent
  two-minute baseline passed all 120 status requests, with root-page fetches
  every 15 samples. Median status response was **50 ms**, maximum **153 ms**,
  RSSI ranged **-85 to -78 dBm**, and minimum reported heap was **155,612 bytes**.
- **One actual OTA transaction**, `c2effd52a541f3e0143df7e0ba739bb4`, transferred the
  same-source, timestamp-refreshed **1,053,808-byte** candidate from source
  `47da0d03…` to `6e18fc29…`. Receiving to verified took **26.768 seconds**, versus
  approximately 76.3 seconds in the preceding development run. This is a single
  observed comparison, not proof that AP locking or channel separation alone
  caused the improvement.
- USB recorded only radio BSSID `74:83:c2:c4:77:7c`, channel 1. There was no AP
  switch or disconnect during the baseline or transfer. The ASSOC_LEAVE at the
  planned software reboot is expected. The AP name and intended UniFi lock target
  were not independently confirmed.
- The new image booted, accepted startup, and reported matching durable
  **COMPLETE** with selection confirmed. Thirty subsequent status checks passed.
  Calibration limits/positions and saved motion profile were preserved; final
  state was CLOSED, ready, fault-free, stationary and torque OFF. Optional metrics
  stayed OFF with no viewers; read-only Alpaca was enabled and connected.
- The private development state now identifies the running `6e18fc29…` image,
  matching the workspace build. USB capture closed normally; no reset injection,
  automatic OTA retry, actuator command or firmware-source change occurred during
  transfer. Persistent development OTA remains available with the same credential.

The signal remains marginal and startup association is not yet consistently clean.
This successful functional comparison does not establish production memory margin
or long-duration WiFi reliability. Memory guards and the 20-entry log remain unchanged.

### One-hour standby follow-up

The subsequent stationary hour did **not** pass network stability: STA disconnected
at 19:59:42 Arizona time, approximately five minutes into the run, with ASSOC_LEAVE
and never recovered during the capture. The user confirmed no network changes.
USB continued for the hour without a subsequent reboot; final free heap was
180,564 bytes and historical minimum 155,088 bytes. This is not evidence of
aggregate heap exhaustion, nor does it rule out allocation/fragmentation faults.
No OTA transaction ran during standby, and the prior successful update remains
valid. Investigate bounded STA reconnection before further long connected runs;
the installed Arduino framework skips auto-reconnect on ASSOC_LEAVE and the idle
application loop currently only opens fallback AP. See the
[full standby result](MEMORY_OPTIMIZATION_PLAN.md#one-hour-stationary-standby-result--2026-10-23).

The bounded STA recovery follow-up is implemented and host-tested as of
2026-10-24; both development and normal USB profiles build. It suppresses
application retries throughout any maintenance lease, including OTA cleanup,
and returns an automatically opened recovery AP to STA-only after stable recovery.
Installation, outage/recovery checks and the repeat hour remain pending. See
[the retry policy](DEBUGGING.md#bounded-saved-sta-recovery).

### Saved-STA recovery firmware installation — 2026-10-24

Installed the reconnection build through one normal development OTA transaction,
`e70e32e2c77a5e8511b48aed9f07e057`, with passive USB capture retained in
`diagnostics/sta-recovery-20261024/`. The previous image was unreachable on STA;
opening USB capture reset it and restored access. Its status was then verified
ready, CLOSED, stationary, fault-free and torque OFF before admission.

The 1,054,240-byte candidate `4fbb7b8a…` transferred from `6e18fc29…`, reached
verified in approximately 26.0 seconds, rebooted, accepted startup and reported
matching durable COMPLETE with selection confirmed. Limits, endpoints and saved
motion profile were preserved. Final installation checks showed torque OFF,
no fault, optional metrics OFF, and read-only Alpaca connected. The running image
matches the workspace build and private development state. No automatic upload
retry or actuator command occurred.

This verifies installation and healthy startup, **not** outage recovery or the
repeat hour. The operator has been asked to identify the locked AP and confirm
availability for a controlled 2.4 GHz radio outage; no AP change has yet been cued.

### Reconnection checks and hotspot cleanup correction — 2026-10-24

The operator clarified that AP locking is disabled; roaming remains allowed.
For controlled STA loss, the operator blocked/unblocked only the Telescope cover
client in UniFi. No AP radio or credential change was made by the test tools.
The first run on `4fbb7b8a…` recorded application retry requests about 20 seconds
after disconnection, followed by intervals of 40.001 and 80.099 seconds, advancing
the next-wait value to the 120-second cap. Fallback AP opened. After unblocking,
STA and HTTP recovered without a reboot, with torque OFF and settings preserved.

This exposed a cleanup defect: the radio stopped AP mode after 30 connected
seconds, but `ap` stayed true because the pinned Arduino core's
`WiFiAPClass::softAPdisconnect(true)` compares the boolean result of
`enableAP(false)` with `ESP_OK` and returns false on success. The stale flag could
prevent future fallback startup and make maintenance's STA-only state incorrect.
The application now calls the boolean `WiFi.enableAP(false)` API directly.

Both normal USB and development profiles built. Because the stale application
flag made OTA admission unreliable, the correction was installed through explicit
USB upload, with stationary/fault-free/torque-OFF status verified immediately
before flashing. Esptool verified written hashes. Corrected development image
`47e279e6…` is **1,054,128 bytes**; accepted startup, saved limits/endpoints/profile
and torque OFF were verified. Initial and corrected candidate artifacts, USB
upload log and first-test evidence are retained in `diagnostics/sta-recovery-20261024/`.

The operator repeated block/unblock on this corrected image. Evidence under
`cleanup-check/` shows recovery on the same boot (`b6bf941d…`), no fault or motion,
torque OFF, settings preserved and read-only Alpaca connected. Thirty seconds
after recovered IP, the radio reported AP_STOP and `setup-AP-closed` at uptime
137.278 seconds; `/api/network` then reported an empty AP name and connected STA.
The corrected image and boot match the updated private development state.

Both block tests triggered AUTH_LEAVE/AUTH_EXPIRE and Arduino's independent
authentication retries. Observed application requests returned 12295
(`ESP_ERR_WIFI_CONN`); these runs demonstrate bounded request timing and
same-boot recovery/cleanup while the driver is also retrying. They do **not**
isolate an idle-driver ASSOC_LEAVE recovery, prove the initial spontaneous
disconnect's cause, or measure production Stop latency during reconnection.

A continuous one-hour standby retest has started under
`cleanup-check/standby-hour/`, reusing the existing USB monitor without resetting
the controller. HTTP status is sampled every five seconds, root page every 30
seconds, and read-only Alpaca every minute; optional metrics are not enabled.
The collector writes its summary and copies
the matching USB segment when finished, then closes the shared monitor.

### Completed connected standby hour — 2026-10-24

The retest completed from **09:06:37 to 10:06:39 Arizona time**, 3,602.6 seconds,
on corrected reconnection image `47e279e6…`. Evidence and `reviewed-results.json`
are in `diagnostics/sta-recovery-20261024/cleanup-check/standby-hour/`.

- All **720** five-second status samples succeeded; **zero request errors**.
  Median response was **55 ms**, maximum **236 ms**.
- USB recorded **no WiFi disconnects** or subsequent boot. All samples used the
  initial boot `b6bf941d…`; BSSID stayed `74:83:c2:c4:77:7c`.
- All **60** read-only Alpaca checks were connected with no reported error;
  final read-only Alpaca status was also connected.
- RSSI ranged **-90 to -73 dBm**. Connectivity passed despite weak readings;
  this does not establish adequate outdoor RF coverage.
- Sampled free heap ranged **166,460–177,436 bytes**. Ten-minute median values
  stayed around 177 KB without sustained decline. First/last-minute medians were
  177,194 / 176,814 bytes (380 bytes lower). Final free heap was **176,788 bytes**;
  historical minimum **145,072 bytes**.
- Final state was CLOSED, ready, stationary, fault-free and torque OFF. Saved
  calibration/endpoints/profile were preserved. Optional metrics were OFF in
  every sample. USB capture completed without error and closed normally.

This passes the stationary status/root-page/read-only-Alpaca workload for this
hour. No allocation-failure collector was active, so it does not certify zero
allocation failures, production memory reserve, motion workload or outdoor RF
reliability. The retained-failure-summary feature was developed concurrently
and **was not installed in this tested image**; its hardware retention/UI checks
remain pending. No reset or upload occurred when reviewing these results.

### Combined NTP and retained-summary hardware tests — 2026-10-24

Installed combined development image `58202622…` (**1,076,896 bytes**) through
OTA transaction `f380455174f2658eaeeef46911b35edf`, with matched COMPLETE and
accepted startup. Evidence is in `diagnostics/ntp-retained-20261024/`; the exact
image/ELF and matching manifest are archived in `candidate/`.

NTP tests passed on hardware:

- Migrated existing settings with NTP initially disabled, preserving calibration
  and other application settings. Enabled `unreachable.invalid` and `MST7` using
  the normal time-settings maintenance/restart route. Startup accepted normally;
  35 seconds of polling stayed responsive with synchronization false, epoch zero
  and null local time. Maximum combined status/network poll time was 173 ms.
- Changed to `pool.ntp.org` / `UTC0`, synchronized, and checked the reported UTC
  offset and calendar time against the Mac clock within five seconds. Shared
  event JSON and USB logs carried synchronized UTC timestamps.
- Changed to `pool.ntp.org` / `MST7`, synchronized again after a warm settings
  reboot, and verified UTC-07:00 and calendar time against the Mac clock.
  The installed Configuration page displayed enabled NTP, the saved server/zone,
  and synchronized Arizona local time. Host tests also cover DST formatting.

Retained-summary tests passed on hardware:

- Reconnected to the existing SSID through the normal setup route using the
  saved password; no AP block or credential replacement was needed. This
  deliberately generated reason 8 / ASSOC_LEAVE and a completed 139-ms outage,
  with the preceding action `setup-connect-candidate` recorded.
- The incident included its source firmware/boot identity, event uptime, RSSI,
  BSSID and memory snapshot: 165,196 free heap, 157,808 historical minimum and
  110,580-byte largest internal block. No application retry was needed for this
  brief setup-controlled reconnect; retry count zero was correctly reported.
- The subsequent time-settings reboot preserved the incident payload exactly,
  apart from the response's `same_boot` interpretation becoming false. Retained
  boot count advanced by one and current reset cause was SOFTWARE. Expected
  reboot disconnection did not replace the saved incident. Both RTC integrity
  and retained-summary API behavior were therefore exercised on the real board.
- Isolated Chrome visited the actual controller: Debug displayed the previous
  boot's incident and heap snapshot, the optional metrics disclosure stayed
  closed/OFF, and no control requests or JavaScript exceptions occurred. A
  deliberate cover fault was not induced; cover-fault paths remain host-tested.

A final five-minute NTP-enabled stationary workload produced **299 successful
status samples**, median **49 ms**, maximum **187 ms**, with no disconnect or
unexpected reboot in USB logs. Sampled free heap was **166,572–172,060 bytes**,
final **171,124**, historical minimum **145,464**. Optional metrics stayed OFF.
Final controller status was CLOSED, ready, fault-free, stationary and torque OFF;
saved calibration/profile, WiFi and telescope settings were preserved. Read-only
Alpaca was connected. This is a short functional/load check, not a new production
memory-margin or all-day/outdoor reliability claim.

Both firmware profiles build; time-sync/settings/diagnostic host tests, existing
125 tooling tests and live-browser checks pass. The running image and private
development state match `58202622…`. NTP is intentionally left **enabled** with
`pool.ntp.org` and **MST7**. Application settings are now v6; archived pre-NTP
firmware does not support that application record (see current USB recovery).
