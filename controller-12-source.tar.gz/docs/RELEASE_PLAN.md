# Release plan

Keep `main` as the complete development repository. Release a curated firmware
package from an exact tested commit; keep tests, tools, and development documents
in Git. This is the execution checklist for
[FIRMWARE_DISTRIBUTION_PLAN.md](FIRMWARE_DISTRIBUTION_PLAN.md), which supplies the
technical requirements. As of 2026-11-11, build identity, isolated USB candidate
packaging, the guarded browser installer and a manual candidate CI workflow are
implemented. See [installation and packaging](INSTALLATION.md). Hardware/browser
acceptance, dependency clearance, public hosting and public distribution
remain pending. A private pipeline-test prerelease was published on 2026-11-12;
see the publication record below. Project licenses were selected on 2026-11-12. The
execution steps below remain acceptance gates, not claims that a release exists.

## Agreed first beta scope — 2026-11-12

| Decision | Agreed scope |
| --- | --- |
| Version/tag | `0.1.0-beta.1` / annotated `v0.1.0-beta.1` |
| Audience | Everyone; make the GitHub repository public only during an explicitly authorized publication step |
| Firmware | Multi-turn, matching the current mechanism; `web_control_multiturn_usb` implemented, physical qualification still required |
| Software / hardware / documentation | MIT / CERN-OHL-S-2.0 / CC BY 4.0; see [coverage and exceptions](../LICENSING.md) |
| Downloads / browser installer | GitHub Releases / GitHub Pages over HTTPS |
| Initial host qualification | macOS with Chrome/Edge; test each advertised browser; Windows and Linux explicitly unverified |
| Destructive installation/recovery tests | Spare Waveshare controller and ST3215; exact configuration must be read and verified before setup |
| Support claim | Supervised prototype only; unattended weather protection remains unqualified |
| Install/update policy | Destructive USB clean installation; settings-preserving updates, downgrades and public OTA remain outside the first beta |

These choices authorize preparation, not hardware operation, repository visibility
changes, tagging or publication. The existing local factory-profile candidate at
commit `60ae029` remains unpublished historical evidence. Preserve it unchanged;
use a distinct output directory for a newly built multi-turn candidate even if
it uses the same intended version. Once a candidate is accepted/frozen, fixes
require a replacement candidate and acceptance; published tags/assets are immutable.

### Remaining acceptance work

- [x] Record version, audience, licensing, hosting, test hardware and beta scope.
- [x] Add project license texts and explicit third-party exceptions.
- [x] Package the scoped project license texts and embedded font notices.
- [ ] Complete framework/browser dependency notices and source/relinking obligations.
- [ ] Review manufacturer CAD, mixed assemblies/media, and tracked repository history
      before public visibility or source-archive distribution.
- [x] Implement `web_control_multiturn_usb` without development OTA credentials
      or commissioning routes; update version/profile checks, notice packaging
      and tests. Its distinct `multiturn_usb` descriptor requires explicit USB
      validation and is rejected by default OTA inspection. Hardware acceptance
      and dependency clearance remain separate gates.
- [ ] Complete startup/profile-loss/replacement guidance and the qualification in
      [MULTITURN_STARTUP_QUALIFICATION.md](MULTITURN_STARTUP_QUALIFICATION.md),
      including power cycles, both crossing directions and full loaded travel.
- [ ] Freeze a clean commit, finalize notes, run CI/offline gates, retain package
      hashes and private debugging artifacts beyond CI retention.
- [ ] Test the exact package on spare hardware: macOS browsers, clean/vendor
      install, cancellation, interrupted flash/recovery, onboarding, calibration,
      Stop/faults, settings persistence and startup without unexpected motion.
- [ ] Prepare and test GitHub Pages installer/versioned download URLs.
- [ ] After acceptance, prepare an annotated tag and draft prerelease using the
      unchanged tested assets, then publish under explicit owner instruction.

The packager now selects `web_control_multiturn_usb`, rejects factory/probe/
development release identities, includes scoped project/font notices and still
marks publication blocked. The local firmware compiles and offline regressions
pass; no hardware acceptance or production multi-turn release exists yet. Public
visibility is an intended destination, not evidence that third-party redistribution
or hardware acceptance has passed.

### Offline implementation evidence — 2026-11-12

`tools/validate_release.py` passed 136 Python artifact tests, eight installer
scenarios, dashboard/model checks and five C++ regression groups (controller,
worker, commissioning driver, production driver and production worker).
`web_control_multiturn_usb` compiled successfully. Production tests cover exact
cold/warm preparation, lost/ignored writes, profile loss, wrong identity, native
turn preservation, both signed crossings, hold staging and absent commissioning
APIs. Default OTA validation rejects the new binary descriptor; five incompatible
production/probe build-flag combinations were also checked to fail compilation.

An end-to-end isolated packaging check used a **temporary validation snapshot**,
not a commit on project `main`: `f2b7463ec8bffac88b5799aa01db7f0990075e6c`.
The unchanged historical factory-profile candidate was retained. New ignored
local outputs are under
`dist/telescope-cover-0.1.0-beta.1-multiturn-validation-20261112*`; the maintainer
directory contains its `source.tar`, `validation-source.bundle`, ELF/map, logs
and explicit snapshot warning. This snapshot must not be promoted or tagged;
build a fresh candidate from a clean committed project revision before acceptance.

The validation application was 1,127,664 bytes, leaving 183,056 bytes in each
pinned slot. All 19 packaged file checksums, ZIP contents/hash, descriptor and
credential/probe exclusions passed; the browser's `validateAssets` accepted the
actual image/partition/manifest. ZIP SHA-256:
`b217a2c4026b538ea0992eb5c93d049c2fe94626260d49113c50ab9454b358e7`.
These are offline checks only. No flashing, servo configuration/motion, remote
push, tag, visibility change or publication was performed.

## Private pipeline-test exception — owner authorized 2026-11-12

The owner explicitly requested an official GitHub firmware image prerelease to
inspect, download and flash later, while intentionally skipping hardware testing
for this run. This authorizes committing/pushing the release implementation,
CI build, annotated tag and publication of **v0.1.0-beta.1** as a pipeline-test
prerelease in the existing **private** repository. It does not authorize hardware
access or changing repository visibility. Public/qualified release gates remain
open; no acceptance checkbox may be marked passed based on this exception.

The manual candidate workflow accepts explicit `pipeline_test` and
`publish_prerelease` inputs, both false by default. With both true, it builds
from the exact workflow commit, labels metadata/notes **NOT HARDWARE TESTED**,
retains acceptance as `not-performed`, and promotes those same artifacts without
rebuilding. `publication_allowed=false` continues to block ordinary/public
promotion; only `private_pipeline_publication_allowed=true` permits this scoped
exception. The publisher checks actual repository privacy, source commit,
prerelease version, complete package/ZIP checksums and image descriptors before
creating an annotated tag and draft. It verifies downloaded draft assets before
publishing as a prerelease, never as the latest stable release. Existing tags
are never replaced. Failed runs may leave a tag/draft for inspection; do not
blindly retry or move that tag.

Example authorized invocation after committing/pushing the intended source:

```sh
gh workflow run firmware-candidate.yml --ref main \
  -f version=0.1.0-beta.1 -F pipeline_test=true -F publish_prerelease=true
```

This tests the GitHub build/artifact/tag/release path. Browser USB installation,
servo RAM startup setup, motion, calibration, power-cycle/recovery behavior,
loaded-cover operation, dependency clearance and public distribution remain
unqualified. A later fix uses a new version/tag; the image published by this
run is immutable even if later hardware tests fail.

### Published pipeline-test record — 2026-11-12

- Release: [v0.1.0-beta.1 — Pipeline test (not hardware tested)](https://github.com/Kbdavis/Telescope-Cover/releases/tag/v0.1.0-beta.1).
- Exact firmware/tag commit: `9cc56f36c677fe333eac5817d018a1de14f93d98`.
  Annotated tag fetched and verified against that commit.
- [GitHub run 43267740100](https://github.com/Kbdavis/Telescope-Cover/actions/runs/43267740100):
  candidate and pipeline-prerelease jobs succeeded. The initial run stopped on
  GCC misleading-indentation diagnostics; formatting was clarified without
  changing motion behavior or disabling compiler warnings.
- Repository remains private. Release is published as a prerelease, not latest
  stable. Hardware/browser acceptance is explicitly `not-performed`.
- Release includes complete `factory.bin` (clean install at address `0x0`), USB
  installer ZIP, manifest/build metadata, installation/notes, pipeline-test warning
  and a checksum list covering the seven other loose release assets.
- Published ZIP SHA-256:
  `ceabcc7c19dc9ca2ab06392ba96e08297b58d9a6eb3a73277168ac735f8233e8`.
- Published factory image SHA-256:
  `e39799abcd39783f10d9f7b32685edb3e4552996a257d165dd7daa8401497b05`.
- Downloaded published assets passed all seven loose-asset hashes and matched
  the candidate job's files/ZIP exactly. The complete package verifier passed.
- Ignored local retained artifacts: `dist/github-release-v0.1.0-beta.1/` and
  `dist/github-run-43267740100/`, including the matching maintainer ELF/map,
  source archive, build log and build-input records beyond CI retention.

No controller or servo was contacted, flashed, configured or moved. Next physical
work is the separately supervised spare-hardware acceptance sequence. Public
hosting/distribution and dependency clearance remain pending. Do not rebuild or
replace these release assets; fixes use a new version/tag.

## Planned next release feature

[Status display and Manual tab mirror](STATUS_DISPLAY_PLAN.md) proposes one
OLED screen refreshed once per second, a live Manual-tab copy, and a virtual
panel button. This is preliminary design only. Additional screens and physical
button Open/Close control are a later increment.

## Release policy

- Use optional short-lived feature branches, merged into `main` before release.
  No permanent release branch or stripped-down copy of the source is needed.
- Use immutable version tags: start with `v0.1.0-beta.1`; increment the beta
  number for replacement candidates. Use `v0.1.0` only when its stated support
  requirements pass. Later versions use patch/minor/major for fixes, compatible
  features, and breaking changes, with migration implications documented.
- First distribution: supervised USB installation on the verified Waveshare
  ESP32/ST3215 hardware, built with `web_control_multiturn_usb`.
  The existing `web_control_usb` candidate is factory-profile only. Plan a browser installer
  as the primary end-user path, with a downloadable complete installation image
  and recovery instructions. Public OTA remains a separate milestone.
  Development OTA credentials stay local.
- GitHub's automatic source archives contain the tracked source at the tag.
  The curated download is a separate release attachment. Publishing a release
  does not change repository visibility; private releases require repository access.
- A beta label does not excuse failed motion-safety or USB-recovery checks.
  Do not claim unattended weather protection without corresponding validation.

## Browser USB installation and complete image

Decision recorded 2026-10-27; browser hardware validation remains pending.
The 2026-11-11 implementation uses pinned **esptool-js 0.7.1** directly so layout
inspection, confirmation, flashing and verification share one USB connection.
An ESP Web Tools-compatible manifest is also packaged, but its generic flow
does not provide the guarded partition preflight. Host the guarded installer
on an HTTPS project page with an **Install Telescope Cover** button. Initially
target desktop Chrome and Edge, subject to testing on the supported host systems.
Users should need only the supported board, a USB data cable, and a browser;
installation must not depend on Codex, PlatformIO, or compiling the repository.

Publish one versioned, merged factory installation image containing the matching
bootloader, project partition table, boot-selection initialization data, and
application from the selected build/toolchain. Derive offsets and flash settings
from that build and validate the installer manifest against the exact image.
The web UI is already embedded in the application: this does not add a separate
filesystem image or require writing a full 4 MB image. Exclude local credentials
and calibration from public artifacts.

The planned installer flow is:

1. Show the supported hardware, release, and physical setup requirements. The
   user clicks Connect and grants access to the selected USB port. Verify chip
   family and flash capacity; chip detection alone cannot identify board wiring.
2. Read and validate the existing partition table, then compare its layout with
   the selected release. Distinguish blank, recognized compatible, and
   incompatible/unrecognized layouts. A failed read is an error, not evidence
   of a blank board. Do not call a layout "old" unless it is positively identified.
3. For fresh installation, explain settings loss and require an explicit choice
   before erasing or writing. For an incompatible layout, use wording such as:

   > **This controller needs a different storage layout**
   >
   > Installing Telescope Cover will replace the existing firmware and storage
   > layout. Existing settings, including Wi-Fi and calibration, will be erased.
   >
   > **[Cancel] [Erase and install Telescope Cover]**

4. On confirmation, erase flash, install the complete matching image, verify the
   written data, and restart. Check startup separately from write verification,
   then guide the user through the setup hotspot, Wi-Fi, and calibration.

Partition inspection belongs in the USB installer after connection, not on the
controller's own webpage: an incompatible layout can prevent that page from
booting. The guarded installer uses
[esptool-js flash reads](https://espressif.github.io/esptool-js/docs/classes/ESPLoader.html#readFlash)
and an explicit destructive confirmation on the same connection.
Cancellation must leave flash unchanged. A compatible table alone does not
establish settings-schema compatibility or authorize a destructive reinstall.
Offer settings-preserving updates only through a separately validated path;
never present the merged factory image as a settings-preserving update.

Retain a downloadable image and instructions for an alternative such as
[Espressif's browser flasher](https://espressif.github.io/esptool-js/), including
the exact image start address and erase behavior. An original-firmware backup
can be optional; do not make a full-flash backup a mandatory first-install step.

### Installation time budget

The 2026-10-27 bench upload at 115200 baud provides this baseline. These figures
describe the current development image, not a measured public browser release:

| Package | Compressed data | Flash-writing time |
| --- | ---: | --- |
| Application only | 722,520 bytes | 63.6 seconds measured |
| Proposed complete image | 734,664 bytes, calculated | About 65–68 seconds estimated |

The offline merged-image calculation adds 12,144 compressed bytes, about 1.7%.
The additional boot files took about 1.3 seconds of writing in the separate
repair upload; neither that upload nor the calculation measures a complete
browser installation. Allow roughly 1–2 minutes as a provisional end-user time
budget including connection, erase, verification, and restart. Measure each
phase on the actual browser installer before publishing a timing claim.

The earlier 372.6-second operation was a full 4 MB backup read, separate from
installation. Including the partition table does not incur that backup cost.
Private evidence is retained under `backups/new-controller-20261027-c2a994/`;
these credential-bearing artifacts are excluded from release packages.

### Prevent incomplete first installs

The initial 2026-10-27 `nobuild` upload wrote only the application, leaving the
vendor partition table and causing a boot loop. Installing the matching boot
components resolved it. Add a guard that checks the actual first-install image
or upload manifest contains every required component. Validating a local
`partitions.bin` without ensuring it will be written is insufficient. Reject
application-only first installs, including the current incomplete `nobuild`
USB path, before contacting hardware. This `nobuild` upload rejection is now
implemented; the candidate packager also rejects missing boot components.

## Release execution

Run steps 1–3 once, revisiting them when requirements change. Repeat steps 4–7
for every release. Replace `<VERSION>` and `<COMMIT>` in prompts with actual
values. Each prompt authorizes only its numbered step.

## 1. Define the first release

**Status:** Owner decisions recorded above on 2026-11-12. Remaining scope work
is reconciling supported hardware evidence, multi-turn implementation and
third-party clearance with that USB beta contract.

**Done when:** The distribution plan identifies supported board/flash/servo,
included features, known limitations, license/notices, and install/update/recovery
paths. Factory installation is explicitly destructive unless preservation has
been proved. Unsupported updates and downgrades are identified. Any missing
hardware evidence remains a named blocker.

**Prompt:**

> Execute step 1 of docs/RELEASE_PLAN.md for <VERSION>. Reconcile the distribution
> plan with current code and measured hardware evidence. Record the initial USB
> release scope, audience, compatibility, erase policy, limitations, and acceptance
> criteria. Ask only for owner decisions or evidence you cannot obtain. Keep
> unresolved decisions explicit. Change documentation only.

## 2. Build repeatable release tooling

**Your action:** Request implementation of the packaging and automated checks.

**Done when:** One documented command builds from an isolated clean commit with
pinned dependencies and produces `telescope-cover-<VERSION>-usb.zip` plus
`SHA256SUMS`. A manually triggered CI workflow runs the same checks and retains
candidate artifacts without publishing. Package contents are selected by an
explicit allowlist:

| Include | Exclude |
| --- | --- |
| USB installation image/components and exact flash instructions | Development, diagnostic, and experimental firmware |
| Browser installer assets and versioned installation manifest | Personal Wi-Fi credentials and saved calibration |
| Standalone setup/recovery guide and release notes | Local headers, secrets, backups, NVS dumps, diagnostics |
| Version/commit/build/layout metadata and component hashes | Tests, mockups, planning documents, build caches |
| Required license and dependency notices | ELF/map files and private maintainer evidence |

Version and source identity must be visible in the running firmware. Preserve
existing ELF identity checks. Derive image offsets and flash parameters from
the actual build. The embedded UI needs no separate filesystem upload.
Prepare the browser flow above with explicit erase confirmation and partition
inspection. Keep candidate hosting separate from public release promotion.

**Prompt:**

> Execute step 2 of docs/RELEASE_PLAN.md. Implement isolated production packaging,
> version identification, a documented validation command, and a manual candidate
> CI workflow. Implement the planned browser installer and its installation
> manifest, partition inspection, and explicit erase confirmation. Reuse
> tools/check_firmware.py and strict tools/ota_manifest.py
> validation; reject development/test profiles. Prevent local credentials and
> bench-specific defaults from entering builds, scan outputs without exposing
> secrets, and test rejected inputs, image layout, hashes, and package contents.
> Reject incomplete first-install images/upload manifests; test blank,
> compatible, incompatible, unreadable, and cancelled installer paths without
> hardware. Keep settings-preserving updates gated on their own validation.
> Run the existing host, tool, and browser suites. Keep generated release output
> ignored. Do not flash hardware, tag, or publish.

## 3. Finish installation and recovery instructions

**Your action:** Review the instructions as someone who has only the download.

**Done when:** The package explains supported hardware and host tools, checksum
verification, USB port selection, power/mechanical precautions, settings loss,
first-boot networking, calibration, and recovery. It distinguishes successful
flashing from healthy startup and a physically safe enclosure. It requires no
repository, compiler, or developer credentials.
Lead with the browser workflow, keep backup optional, and label installation
times as estimates until browser hardware measurements are available.

**Prompt:**

> Execute step 3 of docs/RELEASE_PLAN.md. Write the standalone installation and
> recovery guide and release-notes template used by the packager. Match commands
> to the implemented tooling and supported host platforms. Cover missing/invalid
> servo configuration, failed Wi-Fi setup, interrupted flashing, settings and
> downgrade compatibility, and supervised calibration. Preserve the ST3215 safety
> invariants. Validate the assembled documentation and links; mark untested
> hardware procedures clearly. Do not operate hardware or publish.

## 4. Freeze and build a candidate

**Your action:** Select `<VERSION>` and the changes to include. Finish and commit
release inputs to `main`; development may continue after the candidate is frozen.

**Done when:** A release record identifies one clean source commit, version,
tool/dependency versions, test results, artifact hashes, and remaining hardware
checks. All automated checks pass, including credential and license checks.
The exact candidate package and matching ELF/map files are retained.

**Prompt:**

> Execute step 4 of docs/RELEASE_PLAN.md for <VERSION>. Review pending changes,
> finalize version and release notes, commit the intended release inputs to main,
> and record the candidate commit. Build through the isolated release workflow,
> run all release checks, and retain the exact package and private debugging
> artifacts. Record failures as blockers. Do not create a release tag, flash,
> or publish. If CI needs a push, push only the intended candidate history.

## 5. Validate the exact package on hardware

**Your action:** Provide supported hardware, a safe supervised mechanism, and
USB recovery access. Authorize the prepared hardware procedure when ready.

**Done when:** Recorded results cover clean installation, onboarding/AP recovery,
no unexpected startup motion, servo/configuration rejection, calibration and
settings persistence, OPEN/CLOSE/STOP, timeout/communication faults, reboot,
and interrupted-flash recovery. Validate every advertised update/downgrade path
and host platform. Simulate unsafe faults without corrupting working servo EEPROM.
Include sustained network/UI operation and measured memory/stability evidence.
No required result may be inferred from a successful build.
Exercise the browser installer on blank and vendor-programmed boards, partition
mismatch confirmation/cancellation, and interrupted-install recovery. Record
actual connection, erase, transfer, verification, and restart times for the
supported browser/OS combinations before publishing the installation estimate.

**Prompt:**

> Execute step 5 of docs/RELEASE_PLAN.md for <VERSION>, commit <COMMIT>. Prepare
> the concrete hardware acceptance sequence for the exact hashed package and
> identify which actions need my supervision. Execute hardware operations only
> within my explicit authorization. Record actual results, firmware identity,
> evidence locations, and blockers. Do not publish. If a fix is needed, return
> to step 4 with a new candidate; never substitute untested binaries.

## 6. Tag and prepare the GitHub release

**Your action:** Request a draft after candidate acceptance passes.

**Done when:** An annotated tag points to the accepted commit. A GitHub draft
contains the unchanged tested package, checksums, installation guidance, release
notes, and validation/compatibility summary. Beta versions are marked prerelease.
Downloaded draft assets match retained hashes. No build occurs during promotion.

**Prompt:**

> Execute step 6 of docs/RELEASE_PLAN.md for <VERSION>, commit <COMMIT>. Verify
> acceptance evidence and artifact hashes. Create and push the annotated tag to
> the accepted commit and prepare a GitHub draft release using the exact tested
> assets. Check downloaded draft assets and prerelease status. Never replace an
> existing tag or rebuild the firmware. Leave the draft unpublished and return
> its link and any blockers for review.

## 7. Publish, verify, and retain

**Your action:** Review the draft, then explicitly request publication.

**Done when:** The release is published with working download links and matching
hashes, accessible to its intended audience. Keep the tag, package, build inputs,
ELF/map files, and sanitized acceptance record for every published version;
maintainer artifacts need storage beyond temporary CI retention. Keep credentials
and private hardware captures separate. Record the supported version in the README.

**Prompt:**

> Execute step 7 of docs/RELEASE_PLAN.md: publish the reviewed draft <VERSION>
> without rebuilding or changing its assets. Download the published files,
> verify their hashes and intended access, and check the installation links.
> Archive the exact maintainer artifacts and acceptance record, and update the
> README release link. Report the release URL and verification results. Stop
> publication if the draft or evidence no longer matches what was accepted.

If a published release is defective, mark it withdrawn with recovery guidance
and direct users to a verified compatible version. Never silently replace its
bytes or move its tag. Fix forward through steps 4–7 with a new version. Create
a maintenance branch from an old tag only when that version needs a fix that
cannot reasonably ship from `main`; carry the fix back to `main` as applicable.
