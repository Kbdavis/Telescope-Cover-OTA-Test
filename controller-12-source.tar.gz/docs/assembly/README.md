# Telescope Cover assembly manual

**Best-effort placeholder — November 11, 2026.** This draft describes a proposed
build sequence from the repository's CAD and hardware notes. It has not been
verified by following it through a complete physical build. Photos, final cover
and base files, wiring diagrams and measured fit results will be added later.

[Project README](../../README.md) · [Bill of materials](../bom/) ·
[V10 assembly notes](../../cad/v10_controller_enclosure_large/horizontal_90mm/README.md)

## Before you start

This manual targets the **V10 controller enclosure / horizontal 90 mm revision**
dated October 31, 2026, with a Waveshare Servo Driver with ESP32 and a 12 V
ST3215 servo. The mounting CAD uses a 112.5 mm radius and a 90 mm base-height
band; check your actual base before printing or drilling. The 19-part export
covers the servo/controller modules and attachments, not the complete cover
shell and circular base.

**Cable choice:** the [300 mm servo cable listed in the BOM](../bom/#power-and-cabling)
is **strongly recommended** for this V10 build. If using the **150 mm cable
included with the servo**, use the [V9 servo assembly](../../cad/controller_case_v1/README.md)
instead; **V9 is not waterproof**. The V10 cable-routing steps below do not apply
to that fallback. The project owner will add further details later.

Keep the telescope out of the mechanism during initial assembly and testing.
Support the cover independently whenever servicing it: **Stop, communication
loss and faults can release servo torque.** Reduction gearing is not a positive
mechanical support. Keep power disconnected while fitting hardware or cables.

For this cover design, **stow the Seestar fully before closing** and visually
check the path. Telescope integration does not replace clearance checks during
commissioning. This prototype is not yet qualified for unattended weather
protection.

## 1. Gather parts and tools

Use the [BOM](../bom/) to sort screws by diameter, length and head type. Keep the
provisional servo screws and spacers separate until their fit is measured.

Useful tools include metric hex keys, the drivers matching your self-tapping
screws, calipers, a ruler, deburring tools, a multimeter, and temporary supports
for the cover. Have a computer and USB data cable available for firmware setup.
No tightening torque is specified yet; avoid crushing printed seats, stripping
pilots or bottoming screws in blind holes.

## 2. Print and inspect the module parts

Download the current [print exports and orientation notes](../../cad/v10_controller_enclosure_large/horizontal_90mm/export/README.md).
Import the two plate STLs separately in **millimeters**. They are laid out for
the Bambu X1C's 256 × 256 mm bed. Review supports and bridges in the slicer;
the export has not been physically print-qualified.

| Plate | Parts | Purpose |
| --- | --- | --- |
| 1 | 01 base carrier, 02 front plate, 03 rear plate, 04 cap | Servo cradle |
| 1 | 05 front arm, 06 rear arm, 07 crossbar | Moving arm assembly |
| 1 | 08–11 cap screw seal plugs | Removable screw covers |
| 1 | 12 cover mount, 13 base mount | Cover/base attachment interfaces |
| 2 | 14 controller bottom, 15 controller lid | Electronics enclosure |
| 2 | 16 curved mount, 19 mount carrier | Detachable controller mounting |
| 2 | 17 cable bridge tray, 18 cable bridge cover | Covered servo cable route |

When upgrading the preceding horizontal revision, reprint **02, 14, 17, 18 and
19** for the current hardware clearances. Use one matching revision throughout.

Remove supports and loose material. Dry-fit mating parts, captive nuts and
screw heads before fitting electronics. Check cable openings for sharp edges.
PLA can serve for early fit checks; PETG and ASA have been discussed for later
prototypes/outdoor parts. Final material and slicer settings remain to be
validated for heat, load and weather exposure.

## 3. Prepare the base and cover

The exact shell/base revision and quarter-joining procedure are still missing
from this manual. Confirm the authoritative CAD before building these parts.
Check the assembled base for flatness and inspect each seam and water path.
The cover should seat on the base's angled seating surface; verify that it
rests evenly rather than hanging loosely around the outside wall.

Dry-position the servo module and controller shoe using the current assembly
as the placement reference. The modeled stationary height is **86.75 mm** within
the 90 mm band. This does not establish moving-cover or telescope clearance.
Wall-fixing hardware is deliberately absent from the BOM: establish the actual
wall thickness, backing and fasteners before attaching loaded modules. Do not
drill using an older controller revision's placement.

## 4. Assemble the servo cradle and arms

Use the current [hardware locations](../../cad/v10_controller_enclosure_large/horizontal_90mm/hardware/hardware_locations.csv)
and editable assembly to identify each joint. The
[interior hardware view](../../cad/v10_controller_enclosure_large/horizontal_90mm/hardware/hardware_interior.png)
and [transparent view](../../cad/v10_controller_enclosure_large/horizontal_90mm/hardware/hardware_xray.png)
help locate hidden fasteners.

1. Load captive nuts while their pockets are accessible. Dry-fit the servo in
   part 01 and check connector access. Preserve the modeled servo axis and arm
   orientation; the mechanism is intended to lift the cover back and away.
2. Confirm the real horn threads, screw depth and servo case mounting points.
   The reference geometry does not qualify the actual ST3215 interface. The
   eight M3 × 12 horn screws, rear M3 × 6 retaining screw, two PA2 × 8 screws
   and two spacers remain **provisional**. Do not force them into mismatched
   threads or use the front center access opening as an assumed screw seat.
3. Route the servo lead through its opening before closing the cradle. Keep
   the base-floor drain holes open.
4. Fit the front and rear plates using the modeled sets of four M3 × 20 and
   four M3 × 16 screws with captive M3 nuts. Fit the cap with its four M3 × 16
   screws and nuts after access-dependent work is complete.
5. Dry-fit the front/rear arms and crossbar in the source assembly orientation.
   The crossbar uses four **#6 × 15.875 mm self-tapping pan screws**, not #6-32
   machine screws. Confirm the printed pilots before driving them.
6. Leave the moving arm disconnected from the cover for the initial powered
   checks. Final horn indexing and attachment follow the clearance check below.

## 5. Assemble the controller case and mount

1. Load the curved shoe's captive M4 nuts. Fit the empty controller bottom to
   carrier 19 with **two M3 × 6 button-head screws**. The low heads are required
   by the floor recess; measure engagement before tightening.
2. Register the carrier on shoe 16 and fit **two M4 × 16 screws**, flat washers
   and nuts. Confirm the detachable carrier can still be serviced with the case
   in place. The shoe's attachment to the actual base remains a separate design
   and fitting task.
3. Install the controller PCB with **four M2.5 × 6 screws**. Check that it seats
   without bending and that screw tips and loose hardware cannot contact the PCB.
   Keep the lid off for cable routing and electrical checks.

## 6. Fit the cable bridge and seals

1. With the front plate and lids removed, thread the servo connector through
   the base opening. The CAD opening is 11.5 × 6.5 mm for a modeled 10 × 5 mm
   connector; confirm the real plug fits without forcing it.
2. Cut the [servo outlet gasket](../../cad/v10_controller_enclosure_large/horizontal_90mm/servo_outlet_gasket.svg)
   at 100% scale from a suitable compliant sealing sheet. The template is
   14.5 × 10 mm outside with an 11.5 × 6.5 mm opening. CAD assumes 1 mm installed
   compressed thickness; material and compression remain to be established.
3. Fit tray 17 to the servo carrier with **two M3 × 20 screws and 0.5 mm flat
   washers**. Fit its controller end with **two M3 × 10 button-head screws and
   1 mm sealing washers** through the top-access seats.
4. Lay the cable in the tray. The route budgets approximately 200 mm of a
   300 mm lead, leaving roughly 100 mm for a loop in the controller case.
   Secure the real slack clear of the PCB and lid; retention hardware is not
   designed yet. Check bend flexibility and provide strain relief.
5. Fit bridge cover 18 with **two M3 × 8 screws and sealing washers**. Check the
   controller-end joint for a thin compliant seal or removable sealing bead
   after dry-fitting. Do not block drains or fill serviceable joints blindly.
6. After electrical inspection, fit the controller lid with **four M3 × 30
   screws**, reinstall access caps and the four cradle screw-seal plugs.

These seals and covers are prototype rain-shedding features. Printed porosity,
power-cable entry and screw penetrations still need attention and water testing.

## 7. Connect power and install firmware

With power disconnected, connect the servo's compatible bus lead to the board's
servo interface. Confirm pin labels, polarity and connector orientation against
the actual board and cable; a final illustrated pinout is still needed. Use a
regulated 12 V supply selected for the servo load and the controller's
5.5 × 2.1 mm input. Verify voltage and polarity with a meter before connecting.
The final supply current rating and product selection remain to be documented.

Keep the cover detached and the shaft clear for first power-up. USB is used for
programming; it does not replace the servo's external supply. Keep USB recovery
access available after enclosure assembly.

Follow the [firmware installation and USB recovery guide](../INSTALLATION.md).
It describes the guarded browser installer, complete download-and-flash image,
explicit settings erase, startup checks and version verification. Release tooling
is implemented, but a public release, hosted installer and physical browser
qualification are still pending. A GitHub source archive is not a firmware image.
Use the [build instructions](../../README.md#build), [web setup notes](../WEB.md)
and [recovery notes](../RECOVERY.md) for development-specific details.

**Choose firmware that understands the servo's current configuration.** Factory
and native multi-turn profiles have different requirements. Do not install a
factory-only build over an active multi-turn profile. The automatic RAM-setup
build remains a [qualification candidate](../MULTITURN_STARTUP_QUALIFICATION.md).
Do not use the older Waveshare web UI to configure this servo, rewrite EEPROM,
or reapply the rejected offset-1328 reference as an assembly shortcut.

After boot, confirm communication, supported identity/configuration, plausible
position and telemetry, and the reported torque state before requesting motion.
A configuration fault needs investigation; it is not a prompt to bypass checks.

## 8. Check orientation and teach travel

1. With the arm clear, perform only bounded supervised checks permitted by the
   selected firmware. Begin at **speed 100, acceleration 10**. Confirm Stop and
   torque release while nothing can fall. Stop after any unexplained motion;
   do not retry until the cause is understood.
2. Disconnect power and independently support the cover before attaching the
   arms and cover mount. Establish positive retention and inspect the fasteners.
   The modeled existing cover/base module joints use six M4 × 25 screws with
   six washers and nuts; consult the assembly for their exact placement.
3. Arrange the horn/arm position so the required travel avoids an unqualified
   encoder boundary crossing. Do not force the geared shaft by hand. The current
   assembly direction is **decreasing counts toward OPEN, increasing toward
   CLOSED**. If observed motion disagrees, stop and inspect the assembly and
   configuration; do not reverse labels or relax direction checks.
4. Check clearance with the real stowed S30 Pro, cables and mounting arrangement.
   Support the cover throughout. CAD samples omit the actual telescope, shell
   deflection and wind load. Do not attempt loaded full travel until the path
   and attachment are established.
5. Follow **Prepare → Teach → Review & save → Test** in
   [Calibration](../CALIBRATION.md). Use small supervised steps, capture physical
   CLOSED and OPEN, review the travel/profile and explicitly save. Never copy
   another assembly's encoder positions or an old reference's coordinates.
6. Request OPEN and CLOSE separately while watching the whole mechanism. Confirm
   seating, telescope clearance, cable freedom and retention at both ends.
   Position feedback proves shaft position; independently inspect the cover.

Manual Control defaults to keeping torque enabled after each move, with browser
supervision. Support the cover before Stop or leaving the page. The overview's
manual stow override is a supervised recovery feature, not part of routine
assembly or evidence that closing is safe.

## 9. Record the initial checks

Record results rather than assuming these checks passed because firmware builds.

| Check | Result / evidence |
| --- | --- |
| Printed revision, material and slicer settings recorded | Pending |
| Real servo threads, screw lengths and spacer seats verified | Pending |
| Wall mounting and positive cover retention established | Pending |
| Supply rating, measured voltage and polarity recorded | Pending |
| Firmware identity and servo profile recorded | Pending |
| Detached movement direction and Stop verified | Pending |
| Fresh endpoints taught and saved | Pending |
| Supervised loaded OPEN/CLOSE and cable clearance verified | Pending |
| Settings/restart and supported power-loss behavior checked with cover supported | Pending |
| Seams, cable entries, drainage and unpowered water test inspected | Pending |

Water-test the enclosure separately with electronics and telescope removed.
Dry and inspect it before reconnecting power. Rain sensors, physical endpoint
sensors, reliable telescope interlocks, wind retention and power-loss recovery
still require validation before unattended use.

## What this placeholder still needs

- An authoritative complete cover/base revision and shell assembly sequence.
- Numbered assembly photos, exploded drawings and an illustrated wiring diagram.
- Final wall fasteners, servo-interface hardware, tightening guidance and seals.
- A measured power-supply specification and final cable retention arrangement.
- Verified print settings, physical build corrections and installation instructions
  tied to a released firmware version.
- Recorded loaded, weather, restart and power-loss acceptance results.

Use these gaps as the capture list for the build-instructions video. Match its
CAD revision and firmware release to the eventual verified manual.
