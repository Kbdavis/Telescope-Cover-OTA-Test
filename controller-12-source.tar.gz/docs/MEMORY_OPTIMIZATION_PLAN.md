# Memory analysis and optimization plan

Original analysis date: 2026-10-22. The original source/build inspection below
was offline and performed no firmware changes or hardware operation. Subsequent
USB instrumentation and hardware measurements are recorded in the dated
experiment section at the end; they do not make the proposed optimizations
completed work.

## Conclusions

The strongest initial RAM candidates are diagnostics queue storage, measured
task-stack reductions, and temporary HTTP/JSON allocations. The UI is already
gzip-compressed and served from flash; deleting unused HTML files from the
repository will not meaningfully reduce controller RAM.

Measure before changing allocations. Preserve servo checks, bounded retries,
motion supervision, fault reporting, Stop responsiveness, and recovery paths.
More free memory is not a successful optimization if it weakens those behaviors.

## Baseline and limitations

The inspected artifact was `.pio/build/web_control_usb/firmware.bin`, with its
ELF and map files. It was an existing local build, not a fresh build of a clean
commit. Source findings and artifact numbers must be reconciled in a fresh
build before comparing optimization results. Local development can change
defaults; do not treat these numbers as universal release specifications.

| Item | Observed value or source-derived allocation |
| --- | --- |
| Application image | 1,045,408 bytes |
| Capacity of each pinned application slot | 1,310,720 bytes (`0x140000`) |
| Application-slot utilization | 79.8% |
| Remaining space in each slot | 265,312 bytes |
| ELF `.dram0.data` | 25,680 bytes |
| ELF `.dram0.bss` | 27,656 bytes |
| Combined static DRAM sections above | 53,336 bytes, approximately 52.1 KiB |
| Compressed embedded UI assets | 48,827 bytes, approximately 47.7 KiB, in flash |
| Cover worker stack | 6,144 bytes |
| Alpaca worker stack | 12,288 bytes |
| Diagnostics worker stack | 4,096 bytes |
| Sum of those three explicit worker stacks | 22,528 bytes, or 22 KiB |
| Diagnostics queue payload | 24 × 324 = 7,776 bytes, plus queue overhead |
| Debug history at current 20-entry default | 2,480 bytes of entries, plus allocation/object overhead |
| Incoming HTTP arena | 4,097-byte text buffer plus fields and parser metadata |
| Debug response allocation | Up to 4,097 bytes, temporarily |

The explicit stack total excludes Arduino/framework tasks, Wi-Fi, TCP/IP,
FreeRTOS control structures, and other runtime allocations. Static DRAM does
not include heap-allocated stacks, queues, buffers, sockets, or JSON trees.
Transient allocations are not necessarily all live together; do not sum them
as though they establish a measured runtime peak.

The ELF file's disk size includes debug information and is not flash usage.
Likewise, symbol letters alone do not determine physical RAM placement: the
embedded UI symbols appear as data symbols but reside in mapped flash.

## Distinguish the memory budgets

- **Application flash:** compiled code and constants must fit each OTA slot.
  Two slots do not combine into one larger application capacity.
- **Static DRAM:** globals and statics occupy memory before runtime allocations.
- **Heap:** tasks, queues, networking, strings, and parsing consume memory at
  runtime. Track internal memory explicitly, not only a generic total.
- **Largest free block:** a large allocation can fail even when total free heap
  seems sufficient. Fragmentation and capability requirements matter.
- **Task stacks:** allocated memory remains reserved even when a task is idle.
  Stack overflow is a correctness/safety problem, not just a performance issue.
- **IRAM and other constrained regions:** linker placement can fail independently
  of total flash or apparent heap headroom. Inspect section growth as needed.
- **Browser memory:** JavaScript history and charts run on the user's device;
  they do not consume equivalent ESP32 RAM. Their requests can still increase
  network activity and temporary controller allocations.
- **NVS/filesystem capacity:** persistent storage is separate from runtime RAM.
  Enlarging a partition will not increase RAM.

Do not assume this board provides usable PSRAM. A future PSRAM-capable board
would require explicit hardware/framework support and validation; not all
allocations can safely or practically move out of internal RAM.

## Priority 1 — Diagnostics queue

Source: `src/diagnostics.cpp`. Each queue entry contains a 32-bit timestamp and
320-byte message buffer. `xQueueCreate(24, sizeof(Entry))` reserves 7,776 bytes
of payload. The retained debug log uses a separate 112-byte message field.

Candidate alternatives:

| Change | Payload saving | Tradeoff |
| --- | --- | --- |
| Queue depth 24 → 12 | 3,888 bytes | Less tolerance for bursts or slow serial output |
| Message buffer 320 → 160, depth stays 24 | 3,840 bytes | More truncation of serial/log messages |

These are alternatives calculated against the baseline, not additive savings.
Changing both would require a fresh calculation and separate validation.

Before choosing:

- Measure peak queue occupancy, dropped records, and truncation during fault
  bursts, reconnects, setup, and slow/disconnected serial monitoring.
- Inventory maximum useful message lengths; long messages may carry essential
  details even when the retained ring stores only a shorter version.
- Preserve bounded, nonblocking logging from time-critical paths.
- Keep drop and truncation counters visible. Consider priority handling only
  if its concurrency/ordering behavior is clearly defined and tested.
- Keep recent faults available even when the Debug tab is hidden. Tab
  visibility is not permission to remove operational fault evidence.

The 20-entry retained ring is already small. Reducing it to 10 saves only about
1,240 bytes of entry storage, so it is a lower priority than the queue.

## Priority 2 — Task-stack sizing

Sources: `src/web_control.cpp`, `src/alpaca_transport.cpp`, and
`src/diagnostics.cpp`.

The Alpaca worker has the largest active application stack in the inspected
startup path. Its HTTP routine has 480- and 80-byte request buffers plus
1,025-byte header and 2,049-byte body buffers, and invokes JSON parsing.
Actual peak stack use includes call frames, library functions, error paths,
and parser recursion; array sizes alone are insufficient to choose a stack.

Use existing stack diagnostics to observe lifetime minimum free space under
representative worst-case paths. Confirm units against the pinned framework;
the current project diagnostics document values as bytes.

- Exercise successful and failed requests, deep/malformed JSON within permitted
  limits, reconnects, timeouts, startup, calibration, and faults.
- Ensure metrics sampling covers every active task under consideration.
- Keep a documented margin for unobserved paths and future library changes.
- Reduce one task at a time and repeat the same stress workload.
- Use overflow detection/canary evidence where supported; passing one idle run
  does not demonstrate stack safety.

Moving stack arrays onto the heap does not alone save total RAM. It can even
increase allocation overhead and fragmentation. Savings require reducing the
reserved stack afterward or eliminating/reusing storage with proven lifetimes.
Never share scratch buffers across concurrent workers without explicit ownership.

## Priority 3 — HTTP response allocations

Source: `src/web_server.cpp`. Several endpoints build JSON with repeated Arduino
`String` concatenation, potentially allocating temporary strings and repeatedly
growing response buffers.

Recommended sequence:

1. Measure response size and allocation behavior for the busiest endpoints.
2. Reserve an appropriate bounded capacity where this avoids repeated growth.
3. Reduce unnecessary temporary conversions and copies.
4. Consider a bounded serializer for selected endpoints if measured benefit
   justifies the additional implementation complexity.

`reserve()` does not guarantee allocation success or eliminate every temporary.
Oversized reservations can increase peak RAM. Define graceful failure behavior.
If streaming responses, retain bounded send times and do not monopolize the
web loop or delay Stop/heartbeat handling. Avoid moving a large response buffer
onto an already constrained task stack.

The debug endpoint already has bounded output. Smaller response batches could
reduce transient allocation but increase request count and network overhead.
Compare both peak memory and end-to-end responsiveness.

## Priority 4 — Parsing and network buffers

Sources: `src/http_request.h`, `src/bounded_web_server.h`,
`src/alpaca_transport.cpp`.

The HTTP adapter already frees its input arena before running a response
handler. Preserve that separation rather than introducing a permanent buffer
without evidence of net benefit.

Possible follow-up work:

- Reduce unnecessary copies between the bounded request arena and framework
  argument strings, preserving ownership and request-lifetime rules.
- Inventory actual required request/header/body lengths before changing limits.
- Evaluate selective or bounded parsing for Alpaca responses only after
  profiling the existing cJSON allocation peak.
- Preserve duplicate-member rejection, JSON nesting limits, length checks,
  timeout behavior, and clean failure on malformed/truncated data.
- Confirm sockets and JSON trees release resources on every early exit.

Do not reduce network limits merely because happy-path messages are short.
Errors and legitimate responses with additional fields need defined handling.
Switching parsers is a larger protocol change, not a first-line optimization.

## Optional and future features

### Native Seestar transport

`src/seestar_power_transport.cpp` contains a 12,288-byte worker stack and a
client with an 8,193-byte heap frame buffer, plus JSON/cryptographic costs.
The inspected `src/main.cpp` does not start the native authenticated worker.
These are potential future costs, not reclaimable current runtime allocations.

The native worker is also absent from the current diagnostic-task enumeration.
If enabled in a future configuration, add stack visibility before tuning it.
Measure authentication, error, reconnect, and shutdown paths, not just idle use.

### OTA

`src/ota_service.cpp` conditionally creates an 8,192-byte worker stack when
configured, or for a resource-probe build. It is not an unconditional startup
cost. Budget OTA networking, authentication, buffers, flash-update internals,
and concurrent services as well as its stack before opening release gates.

Do not choose OTA admission thresholds from static-size arithmetic. Use actual
internal heap and largest-block evidence with reserve margins. Follow
[OTA_IMPLEMENTATION_PLAN.md](OTA_IMPLEMENTATION_PLAN.md).

### Wi-Fi/framework tuning

Investigate framework network buffers only after application-level savings and
runtime measurement. Changes may require rebuilding framework components,
and can affect throughput, reconnect reliability, and control latency. Do not
disable recovery AP behavior merely to improve an idle memory number.

## Flash-size opportunities

- The four compressed UI assets total about 47.7 KiB. They are already gzip
  compressed deterministically by `tools/embed_ui.py` and sent using `send_P`.
- Remove genuinely unused embedded code/assets after map-file analysis, not
  merely files present in the repository. Legacy HTML may not be linked at all.
- Measure minification benefit after gzip; source-text reduction does not map
  directly to compressed-image savings. Preserve debugging and license needs.
- Inspect large linked code and constant sections before changing features.
  Unreferenced functions may already be removed by linker garbage collection.
- External hosting of the UI would trade local recovery/offline availability
  for flash space and is not the preferred initial approach.
- A partition redesign could increase slot capacity but does not save RAM and
  introduces installation/update compatibility issues. Treat it as a separate
  migration under [FIRMWARE_DISTRIBUTION_PLAN.md](FIRMWARE_DISTRIBUTION_PLAN.md).

## Measurement procedure

1. Record source commit and dirty-worktree status, build environment, dependency
   versions, enabled features, log capacity, board, and firmware identity.
2. Produce a fresh build, without uploading automatically. Preserve binary,
   ELF, map, image size, and section-size output with the experiment record.
3. Arrange a supervised hardware session and explicitly authorize flashing or
   motion if needed. Support/disconnect the mechanism for failure testing.
4. Record idle baseline after network services settle, then repeat a fixed
   workload with metrics off and on to identify measurement overhead.
5. Sample internal free heap, internal minimum free heap, largest free block,
   stack minima, loop/heartbeat latency, queue occupancy, and dropped logs.
6. Correlate peaks with operations. Periodic polling can miss brief allocation
   peaks; add targeted instrumentation when necessary.
7. Run one change at a time and compare identical builds/workloads/settings.
8. Repeat long enough to distinguish stable allocations from continued growth
   or fragmentation, including reconnect and error cycles.

See [DEBUGGING.md](DEBUGGING.md) for current field definitions and capture
procedures. Optional metrics require an active collection session; do not
interpret an unavailable or stale sample as zero memory usage.

Minimum internal heap is a lifetime statistic and can aggregate minima from
regions at different times. A falling minimum alone does not prove a leak.
Compare current free heap, largest block, operation history, and recovery after
the workload. If using heap tracing, account for its own overhead and timing.

Suggested workload matrix:

| Workload | What it exposes |
| --- | --- |
| Cold boot, absent servo, missing settings | Initialization and recovery allocation paths |
| STA connection, failed credentials, fallback AP, reconnects | Wi-Fi and setup peaks |
| Overview polling and multiple browser tabs | Repeated allocation and socket pressure |
| Debug downloads and optional metrics | Diagnostics overhead and response peaks |
| Settings forms and network scans | Request parsing and temporary result storage |
| Alpaca success, timeout, malformed/oversized response | Stack and JSON/error-path peaks |
| Supervised calibration/motion and fault handling | Control responsiveness under load |
| Extended repeated request/reconnect cycles | Leaks, fragmentation, resource cleanup |
| OTA probe/transfer when separately authorized | Future worst-case concurrent memory demand |

## Acceptance criteria for an optimization

- Demonstrated saving in the relevant budget: persistent RAM, peak RAM,
  contiguous-block requirement, or application flash.
- No loss of servo/interlock validation, retry robustness, or fault recovery.
- No increase in unbounded waits or unacceptable Stop/heartbeat latency.
- No new overflow, watchdog reset, heap corruption, or allocation-failure crash.
- Logging remains useful and losses/truncation remain observable.
- Existing relevant tests pass, plus targeted error/limit tests for changed
  serializers, queues, parsers, or memory ownership.
- Hardware before/after evidence covers the affected runtime paths.

Avoid claiming combined savings from overlapping alternatives. Keep stack
reductions and temporary-buffer reductions distinct, and include framework
allocation overhead where measured rather than silently treating it as zero.

## Recommended work sequence

1. Establish a fresh artifact baseline and reproducible runtime workload.
2. Add missing measurements, especially queue occupancy and any newly enabled
   task stacks, without changing safety behavior.
3. Trial diagnostics queue reduction and validate burst handling.
4. Tune stacks individually from measured evidence.
5. Optimize high-frequency JSON response construction.
6. Consider deeper parser/network changes only if a remaining budget requires
   them; reserve capacity for future OTA and optional integrations.
7. Add build-size regression reporting and document runtime budgets once
   measured. Thresholds should be evidence-based, not arbitrary percentages.

Suggested follow-up prompt:

> Follow MEMORY_OPTIMIZATION_PLAN.md. Establish a fresh offline build baseline
> and identify the measurements needed for the first diagnostics-queue trial.
> Preserve unrelated work and all motion safeguards. Do not flash or operate
> hardware without explicit authorization. Report measured values separately
> from estimates and propose the smallest reviewable optimization.

## Experiment record template

For each trial record: date, commit/worktree, firmware identity, hardware,
enabled features, exact change, expected saving, workload duration, initial
and worst internal heap, largest block, task minima, log drops/truncation,
latency, failures, recovery behavior, and accept/revert decision. Link raw
captures and artifacts where appropriate without including credentials.

Original status: offline analysis complete. See the subsequent experiment below
for baseline progress; optimization and full-workload validation remain open.

## USB idle memory/WiFi baseline — 2026-10-23

The user requested a memory investigation after UniFi showed rapid roaming
around earlier OTA aborts, then closed controller tabs for a quiet baseline.
OTA testing was paused. Read-only preflight confirmed the supported cover ready,
stationary with torque OFF, clean saved calibration, metrics OFF/zero viewers
and telescope monitoring disabled. Existing production/app1 backups were
verified against device digests and native metadata archived before installation.

Implemented `web_control_usb_memory`, a USB-only `test_profile` with production
OTA admission forcibly disabled and no linked receiver task or SDK begin/write
symbols. A three-minute window registers the allocator failure callback,
records internal 8-bit/DMA heap observations, self-sampled stack headroom,
sampled diagnostics-queue occupancy/drop/truncation counts and HTTP dispatches.
Existing USB WiFi records supply the common timeline. The callback performs
no allocation, logging, clock access or waiting; contention loses metadata
with an explicit counter while preserving failure totals. Fixed-buffer USB
output bypasses the diagnostics queue. This is test instrumentation, not a
new always-on production feature. See the
[procedure and limitations](DEBUGGING.md#usb-only-memory-and-wifi-baseline).

The exact measured image was 1,044,464 bytes, with 53,688 bytes static DRAM and
ELF identity `c6481049e7a9273b136a640faa90a059e6a3fc5f8b7aa2dc167380267fe14de4`.
Normal production builds remain 1,045,744 bytes / 53,336 bytes static DRAM.
Source hashes, exact test/restore artifacts, timestamped raw USB capture and
offline summary are private in `diagnostics/usb-memory-baseline-20261023/`.
No actuator, setting, monitoring or OTA-transfer request was sent.

| Observed result | Value |
| --- | ---: |
| Collection duration | 180,025 ms |
| Heap samples | 173 |
| HTTP requests during collection | 0 |
| Allocation failures / lost failure metadata | 0 / 0; hook registered |
| Lowest sampled internal free heap, whole window | 153,820 bytes |
| Lowest sampled internal free heap after 20-second settling | 155,416 bytes |
| Settled first ten / last ten median free heap | 155,552 / 155,416 bytes |
| Internal allocator per-region lifetime-minimum sum | 144,420 bytes |
| Lowest sampled internal largest block | 110,580 bytes |
| Internal DMA free/block observations | Same as internal 8-bit in this run; overlapping budgets |
| Web / cover / diagnostics stack minimum free bytes | 5,276 / 1,104 / 1,272 |
| Sampled queue peak / capacity | 4 / 24 entries |
| Dropped / truncated operational logs | 0 / 1 |
| Settled RSSI range | −89..−83 dBm |
| Link BSSID changes | 0 |

USB captured one startup association failure at uptime 4,169 ms
(`reason=203`, firmware label `ASSOC_FAIL`), followed by successful association
and IP acquisition around 5.8 seconds. No repeated connected roaming was
observed in this capture. The failure callback recorded no allocation failure
around it or elsewhere in the window. This does not explain or invalidate the
earlier UniFi observations, and a heap callback cannot diagnose every kind of
driver buffer-pool exhaustion. AP/network/RF causes remain possible.

The collector emitted its end marker, and subsequent passive observation
contained no further USB memory samples. Final metadata/inactive-slot and
production-recovery checks are recorded with the experiment artifacts.

### Interpretation and next memory experiment

This workload shows **no observed allocation exhaustion or progressive large
heap loss at idle**, despite weak signal. A 136-byte difference between endpoint
medians is not a demonstrated leak. Stable largest-block observations do not
certify arbitrary allocation sizes/types or prove fragmentation never occurs.
The previous 131,072-byte OTA floor was an experimental protection threshold,
not evidence that an abort at 126,944 bytes was out-of-memory. The baseline has
no OTA owner, active browser metrics, flash write or motion/fault workload, so
its free memory is not an OTA admission budget.

Do not shrink the cover/diagnostics stacks from these results. Their measured
headroom is already limited and unexercised fault paths remain. Likewise, the
idle queue peak of four does not justify reducing depth before fault/reconnect
burst measurements. Keep the log at 20 and leave compression deferred.

Next, repeat this recorder with one controlled root-status client, metrics OFF:
settle for about 20 seconds, poll once per second for about 20 seconds, then
stop HTTP and observe at least two minutes of recovery. Keep the firmware,
radio conditions and monitoring setting constant. The pinned SDK has
`CONFIG_LWIP_TCP_MSL=60000`; connection state can persist beyond a response,
so short recovery intervals can misidentify retained networking state as a leak.
This is a hypothesis to test, not attribution of the earlier drops to TCP.
Then test one explicit metrics viewer as a separate workload, followed by
reconnect stress. Only resume OTA after these costs and recovery behavior are
understood. Use the resulting evidence to choose one small optimization and
an eventual reserve, rather than lowering the guard to make a transfer finish.

Local validation: concurrent failure-recorder and actual USB collector native
tests pass under ASan/UBSan, including callback contention, coherent metadata,
zero HTTP/stack updates after the timed window and no subsequent heap samples.
Existing diagnostics/metrics gate tests and all 71 host tool tests pass. All
three production USB, guarded OTA and USB-recorder builds pass. No production
queue, stack, network-buffer or admission threshold was changed.

Production was restored by application-only USB flash, with device hash
verification and ELF identity
`66b9ee23b109e1d94faa9749939f30135f7dcec0ae3a06b910ae48aac33e7b37`.
Fresh HTTP checks confirmed accepted startup, ready/calibrated, saved limits,
positions and motion profile unchanged, no movement, torque OFF, maintenance
unlocked, metrics OFF/zero viewers, telescope monitoring disabled and OTA
unavailable. The USB test recorder/hook are absent from this normal build.

## Controlled status polling and recovery — 2026-10-23

Reused the **identical** `c6481049…` USB recorder image and the same settings,
20-entry log, disabled monitoring and browser metrics OFF. The user had closed
controller pages. Fresh preflight confirmed ready/calibrated, stationary torque
OFF and no maintenance owner. `tools/probe_usb_http.py` waited for approximately
20 seconds uptime, sent one sequential root-status request per second for
20 seconds, then used the USB file only until collection ended. Every response
confirmed the expected image/boot and unchanged OFF/safety conditions. No
metrics subscription, settings, actuator or OTA command was issued.

The firmware counted exactly the 20 root requests attempted by the client;
all 20 succeeded. There were no other HTTP dispatches in the collection window.
Request responses were recorded at approximately **15:43:33–15:43:52 Arizona
time (UTC−07:00)** for correlation with UniFi history.
The client then observed **139.6 seconds of quiet recovery**. Evidence and
timestamped requests are private under `diagnostics/usb-http-memory-20261023/`.
The recorded binary/ELF match the quiet baseline, and native metadata matched
before/after. This was a controlled status-only workload, not a full browser
page download, metrics workload, reconnect stress, motion or OTA transfer.

| Internal memory / behavior | Observed result |
| --- | ---: |
| Pre-load median free heap | 155,408 bytes |
| Lowest sampled free heap during load | 146,384 bytes |
| Free heap just after polling stopped | Approximately 151,784 bytes |
| Final ten-sample median after recovery | 155,180 bytes |
| Median change from pre-load | −228 bytes |
| Lowest sampled largest free block | 110,580 bytes |
| Allocation failures / lost failure metadata | 0 / 0 |
| WiFi disconnects / observed BSSID changes | 0 / 0 |
| Web / cover / diagnostics minimum free stack | 4,716 / 1,104 / 1,320 bytes |
| Sampled queue peak / dropped / truncated logs | 4 / 0 / 0 |

The radio chose a different AP from the previous idle run: BSSID
`74:83:c2:c4:77:7c`, with settled RSSI −82..−78 dBm. It stayed on that AP
throughout this capture. Therefore the stronger comparison is **within this
run** (before/load/recovery), not an assumption that radio conditions matched
the previous run at −89..−83 dBm.

Much of the retained memory was released around uptime **146–160 seconds**,
approximately two minutes after the requests, frequently in 224-byte steps.
This timing is consistent with connection-state expiration under the pinned
TCP MSL configuration. Allocation ownership was not traced, so this is an
inference rather than proof that each block was a TCP control block. The
temporary drop recovered substantially without changing firmware or reducing
the workload after its scheduled stop. A 228-byte median difference after one
cycle is not sufficient evidence of a leak; it also does not prove zero leaks.
Sampling can miss shorter peaks, and the allocator's minimum statistic is not
an exact simultaneous peak measurement.

**Result:** no allocation failure, WiFi disconnect or BSSID change was recorded
under 20 status requests with metrics OFF, and most retained memory recovered.
This workload does not provide a failure boundary to bisect or justify lowering
the OTA floor.
If persistent growth becomes the question, repeat pulses in one boot and check
whether the post-recovery level ratchets down. The next feature-cost experiment
should enable one explicit metrics viewer as the only workload change, with
the same bounded client and long quiet recovery. Keep OTA paused until those
costs and full-workload reserves are characterized.

The new read-only client and analysis pass all 75 host tool tests. They reject
wrong boot/image, torque ON, active metrics, dirty/not-ready state and insufficient
recovery, and flag unexpected HTTP activity. The unchanged recorder firmware
required no new build for this paired experiment. See the
[controlled procedure](DEBUGGING.md#controlled-status-polling-and-recovery).

Production was restored by app0-only USB flashing with device hash verification.
Fresh HTTP checks confirmed ELF `66b9ee23…`, accepted startup, ready/calibrated,
saved limits/positions/profile preserved, stationary torque OFF, maintenance
unlocked, metrics OFF/zero viewers, monitoring disabled and OTA unavailable.
No experimental USB recorder remains active on the controller.

## Manual browser/control exercise — 2026-10-23

The user exercised the normal browser controls while the USB-only recorder ran
in the ten-minute `web_control_usb_memory_manual` profile, ELF `ec9ee6ad…`.
The assistant issued no actuator commands. Private evidence is in
`diagnostics/usb-browser-memory-20261023/`, including timestamped serial output,
matching firmware/ELF, status snapshots and `partial-analysis.json`.

This is **two partial boot segments**, not one completed ten-minute run. At
**16:02:20 Arizona / 23:02:20 UTC**, the device reported `SOFTWARE` reset.
Network maintenance became ready approximately two seconds earlier, followed
by `ASSOC_LEAVE` and `STA_STOP`. This matches the application's settings/restart
path; the user confirmed saving settings to start Alpaca. No panic, watchdog
or allocation-failure message was recorded. The AP changed across that reboot, from
`78:8a:20:d4:30:f2` to `74:83:c2:c4:77:7c`; neither individual boot showed an
observed connected BSSID change. Do not count this as evidence of memory-driven
roaming. Opening USB at the start of a capture can itself reset the board, and
esptool operations deliberately reset it; correlate UniFi events with BOOT times.

Read-only telescope monitoring was disabled initially and enabled/connected after
the restart, as confirmed by a read-only Alpaca status request. Therefore the
heap difference between boots cannot establish a leak or isolate monitoring's
cost. Preserve the user's current settings when restoring the production image.

| Observation | Before software restart | After software restart (partial capture) |
| --- | ---: | ---: |
| Lowest sampled internal free heap | 131,040 bytes | 124,544 bytes |
| Allocator internal per-region minimum sum | 122,940 bytes | 104,604 bytes |
| Lowest sampled largest internal block | 110,580 bytes | 110,580 bytes |
| Recorded allocation failures / lost failure metadata | 0 / 0 | 0 / 0 |
| Cover minimum unused stack (6,144-byte allocation) | **512 bytes** | 740 bytes |
| Web / diagnostics minimum unused stack | 4,412 / 1,240 bytes | 4,364 / 1,240 bytes |
| Alpaca minimum unused stack | Not running | 5,432 bytes |
| Sampled log queue peak / dropped / truncated | 6 / 0 / 0 | 4 / 0 / 0 |

These are sampled instrumented observations, not a certified memory reserve.
The allocator's per-region minima are not an exact simultaneous heap low-water
mark. Instrumentation adds its own work, stack high-water marks may not account
for all reserved-but-unwritten frames, and unexercised paths remain unknown.
There is no observed allocation failure to bisect in this workload. The strongest
new constraint is the cover task's **512-byte** unused stack margin; do not shrink
that task. The first report of 512 bytes was at 22:59:41 UTC, after the
initial successful open, well before either timeout. This does not isolate the
exact stack-consuming function. Audit its deepest motion/fault/logging call chains and local objects,
then test a narrowly justified stack adjustment or reduction in stack use before
adding further OTA workload. Heap headroom alone cannot certify task-stack safety.

The test also exposed two motion timeouts, both with confirmed torque OFF:
a ten-count jog ended four counts short with tolerance zero, and an open command
ended six counts short with tolerance five. Both had 97 valid position reads and
zero failed reads in their motion evidence; heartbeat ages at timeout were 165
and 73 ms. These are separate settling/tolerance findings, not evidence of WiFi
or allocation failure. Review calibration and settling policy separately; do not
relax safety limits or hide the faults to make a memory test pass.

At the user's finish marker the controller was stationary, CLOSED and torque ON,
with browser metrics OFF/zero viewers, maintenance idle and OTA unavailable.
The user subsequently supported/released the cover and closed the tab; fresh
status confirmed torque OFF, stationary, ready and maintenance unlocked before
restoration began.
The recorder has a bounded sampling window and does not activate OTA or move
the cover when the window ends. The host capture stopped at 23:08:30 UTC.
The user returned to release torque near the end, so HTTP resumed: no completed
quiet-recovery comparison is claimed. Neither boot reached its ten-minute
USBMEM end marker. Later restoration verification is recorded below.

Production restoration completed by app0-only USB write with device hash
verification, ELF `66b9ee23…`. The first HTTP verification timed out; a short
USB follow-up capture (opening USB caused another observed startup) confirmed
the production image, and subsequent HTTP verification succeeded. Fresh checks
confirmed accepted startup, ready/calibrated CLOSED, stationary torque OFF,
maintenance idle/unlocked, browser metrics OFF/zero viewers and OTA unavailable.
Saved limits, endpoints and motion profile matched the pre-restoration snapshot.
Read-only Alpaca monitoring remained enabled and connected, as requested by the
user's settings change. Partition table and native otadata matched the original
metadata; NVS changed during the user's settings save and was preserved, not
rolled back. The bounded experimental USB recorder is absent from production.

## Cover-task stack reduction — 2026-10-23

The stack audit identified avoidable motion-history temporaries on the live
motion call path, plus application settings retained in the worker's lifelong
frame. The controller now copies history directly into the existing `WebStatus`
snapshot through `copyTrace()`. Fault logging reads that same current snapshot.
New moves clear the history in place, including unused samples, rather than
constructing a full temporary history. A non-inlined startup helper reads the
application settings and returns only the torque policy, so WiFi/telescope
settings storage is not retained throughout the control loop.

Measurements use the exact pinned ESP32 production compiler commands, adding
`-fstack-usage`; private reports, object files, compile commands and both
firmware artifacts are in `diagnostics/cover-stack-audit-20261023/`.

| Compiler-reported frame | Before | After |
| --- | ---: | ---: |
| Cover worker | 2,880 bytes | 2,240 bytes |
| Move startup (`beginMove`) | 624 bytes | 96 bytes |
| Separate boot settings helper | Included in worker | 288 bytes while called |

The worker-plus-move-startup path therefore reserves **1,168 fewer bytes** in
these two frames. This is not a measurement of the entire nested call chain or
a prediction that every runtime high-water mark improves by exactly that amount.
The settings helper still consumes stack during startup. The pinned SDK already
has compiler stack checks, FreeRTOS canaries and the end-of-stack watchpoint
enabled; those detect some overruns but do not establish adequate working margin.

The task still allocates 6,144 bytes; production static RAM remains 53,336 bytes.
No extra heap allocation, static history buffer, queue space or log capacity was
added. Motion tolerances, timeout, settling, heartbeat and interlock behavior
are unchanged. The 20-entry log and closed OTA release gate remain in place.

Host controller tests now verify independent snapshots, current settling counts
and complete sample/counter reset on the next operation. These pass with
ASan/UBSan, as do the actual servo-worker maintenance integration and emergency
cover integration suites. Normal production and bounded USB recorder builds
pass the firmware descriptor, layout and manifest checks. Production binary
size is 1,045,600 bytes, ELF `49c92048…`; recorder ELF is `4f7b1651…`.

A stationary USB startup check was performed before normal firmware installation.
Repeating the user's supported browser/motion exercise remains necessary to
measure the revised stack margin under successful motion and fault paths.
No automatic physical movement is part of this stack audit, and the compiler
results alone do not open the OTA gate or resolve the separate settling faults.

The revised recorder passed a **35-second stationary startup/idle USB check**
with read-only Alpaca monitoring enabled. Cover minimum unused stack was
**1,456 bytes**; web 5,276, diagnostics 1,240 and Alpaca 5,460 bytes. The
allocation-failure hook was registered, with zero failures/lost metadata and
zero HTTP requests during capture. No actuator command was sent. This was not
a full ten-minute run and did not exercise motion. Boot/helper/library paths
can dominate the idle minimum, so do not substitute the compiler frame savings
for a task-wide measured margin or compare this idle result directly to the
previous 512-byte motion minimum.

There was one initial `ASSOC_FAIL` (203), followed by association to the weaker
AP `78:8a:20:d4:30:f2`; do not report the startup as zero WiFi events. The first
status check after capture succeeded and confirmed the revised image, accepted
startup, ready/calibrated CLOSED, stationary torque OFF and maintenance idle.
Partition table and native otadata were byte-identical before/after the probe.
NVS differed by 28 bytes, so byte-identical NVS preservation is not claimed;
keep the live NVS rather than restoring an older image, and compare exposed
application settings and calibration after normal firmware installation.

Revised normal production ELF `49c92048…` was installed app0-only over USB with
flash hash verification. Follow-up USB/HTTP checks confirmed accepted startup,
ready/calibrated CLOSED, stationary torque OFF, saved limits/endpoints/profile
unchanged, metrics OFF/zero viewers, maintenance idle, read-only Alpaca enabled
and connected, and OTA unavailable. No experimental USB recorder remains active.
The next hardware step is a supervised repeat of the browser/motion exercise,
including explicit fault recovery, with settings/AP held stable where practical;
measure its stack margin rather than declaring the idle value a motion result.

## OTA receiver with passive USB measurement — 2026-10-23

The user requested an OTA-inclusive measurement. Added the explicit
`web_control_ota_usb_memory_probe` test profile: the real receiver task and SDK
flash backend are linked, production OTA admission stays disabled, and the
inactive-slot test branch cannot select a boot image, save a transfer journal
or reboot. Its USB collector runs independently of metrics. The client now
supports `--passive-usb`, which makes no metrics-session/subscription requests
and rejects a metrics viewer appearing during observation. The one-per-second
root safety checks remain part of the workload. The original metrics-observed
mode is retained for separate comparisons.

Current supported-cover/torque-OFF checks passed, the complete app1 backup was
verified erased, and the probe was installed into app0 only. Read-only Alpaca
was enabled/connected before preparation; maintenance paused its polling as
it does for the production receiver and polling resumed after cleanup. Browser
metrics stayed OFF, with no CPU-load sampling epoch. The 20-entry log, task
allocations and existing **131,072/65,536-byte experimental guards** were kept.
Private evidence, current backups and matching binaries are under
`diagnostics/ota-usb-memory-20261023/`; probe ELF is `a56c7d37…`.

At **16:27:38 Arizona / 23:27:38 UTC**, the single attempt was rejected during
admission: physical and STA checks passed, but free internal heap was
**128,860 bytes**, **2,212 below** the guard. Largest free block was 110,580 bytes,
comfortably above its 65,536-byte guard. Maintenance was released and Alpaca
resumed. **No firmware bytes were transferred and SDK flash begin/write/end
were not reached.** There was no automatic retry or lower guard.

| Observation | Result |
| --- | ---: |
| Pre-attempt receiver-enabled internal free heap (12 samples after 20 s uptime, no HTTP yet) | 130,332–133,104 bytes; median 132,484 |
| Admission check internal free heap | 128,860 bytes |
| Lowest periodically sampled internal free heap | 125,876 bytes |
| Allocator per-region internal minimum sum | 111,544 bytes |
| Lowest sampled largest free block | 110,580 bytes |
| Registered allocation hook / allocation failures / lost failure metadata | Yes / 0 / 0 |
| Cover / OTA minimum unused stack | 1,464 / 3,744 bytes |
| Web / diagnostics / Alpaca minimum unused stack | 4,412 / 1,232 / 5,352 bytes |
| Sampled queue peak / dropped / truncated | 4 / 0 / 1 |

The receiver-enabled idle range already straddles the experimental floor; the
status/admission work then exceeded that guard budget. This measures receiver
presence, admission and cleanup costs, **not flash-transfer peak usage** and not
an allocation-failure boundary. Do not call the guard a measured RAM requirement.
The allocator minima are per-region statistics, and periodic samples can miss
short-lived dips. No connected BSSID change was observed; one startup
`ASSOC_FAIL` occurred before successful connection to `74:83:c2:c4:77:7c`.
Recovery and restoration verification are recorded below.

The next resource investigation should account separately for the resident
receiver task, control/status response allocations and paused-but-resident
monitoring workers. Reduce demonstrated avoidable costs or justify an explicit
experimental budget before repeating a guarded transfer. Do not lower the floor
merely to obtain a successful transfer, and keep production release blocked.

All 80 host tool tests pass, including the new passive-mode success/cancellation,
metrics-OFF enforcement and incompatible measurement checks. Native USB collector
sanitizer tests and five compile-time profile guard combinations pass. Configured
OTA/USB, ordinary production and ordinary USB-baseline builds pass; production
behavior and baseline receiver exclusion are preserved. The configured experiment
uses 54,032 bytes static DRAM and a 1,056,480-byte test image. Compiled receiver
code has no calls to boot selection, restart or transaction save; startup
reconciliation still links boot-selection code, so native metadata must also
be compared after the attempt.

The passive capture recorded **136.3 seconds without incoming controller HTTP**
after cleanup. Final ten-sample median internal free heap was **132,626 bytes**,
versus 132,484 before the attempt (+142 bytes). With outgoing Alpaca monitoring
still running, this single recovered interval is not evidence of a persistent
leak or proof of no leaks. USB recorded zero allocation failures/lost metadata
through recovery. The observed allocator minimum fell further during recovery,
to 111,544 bytes, illustrating that other background work can establish the
whole-run low-water statistic after the OTA attempt has ended. The capture was
stopped deliberately before the ten-minute sampler ended; no completed timed
window is claimed.

Fresh status confirmed ready, stationary torque OFF, maintenance idle, metrics
OFF/zero viewers, admission failure with zero received bytes and unchanged boot.
USB digest verification confirmed **all 1,310,720 bytes of app1 still match the
original erased backup**, so no inactive-slot rewrite is needed during cleanup.

The partition table and native otadata were byte-identical before/after the
attempt. NVS bytes differed, so raw byte-identical NVS preservation is not
claimed; the current NVS is retained and exposed application settings are
compared after restoration. No backup is written over the live user settings.

Normal production ELF `49c92048…` was restored by app0-only USB flashing with
device hash verification; no app1 rewrite was needed. Follow-up USB/HTTP checks
confirmed accepted startup, ready/calibrated CLOSED, stationary torque OFF,
saved limits/endpoints/profile unchanged, maintenance idle/unlocked, browser
metrics OFF/zero viewers, read-only Alpaca enabled/connected and production OTA
unavailable. The temporary plaintext credential/header were retired; archived
test binaries remain private. No experimental collector or receiver is left
running in normal firmware.

## First complete nonactivating OTA transfer — 2026-10-23

The user authorized a supervised repeat with a lower **test-only** internal-heap
guard, deferring the broader allocation audit. Set 98,304 bytes (96 KiB), a
32 KiB reduction from the previous arbitrary 131,072-byte guard; retain the
65,536-byte largest-block guard. This permits measuring the real flash path
past the previous admission threshold and does not establish a production
minimum. No task stack, queue, log capacity or production admission setting changed.

The same passive-USB/nonactivating experiment was used, with read-only Alpaca
enabled, normal maintenance polling pauses and browser metrics OFF. The original
complete erased app1 backup was freshly matched to the device by digest before
installation, and current native metadata/settings were backed up. The temporary
receiver image passed build/manifest checks and the disassembly check excluding
boot selection, restart and transaction save from the transfer branch.
Evidence and matching artifacts are private under
`diagnostics/ota-usb-transfer-96k-20261023/`; probe ELF `ae841151…`, payload and
normal recovery ELF `49c92048…`.

**The full 1,045,600-byte upload completed**, including authenticated transport,
streaming image/digest validation and SDK `esp_ota_begin/write/end`.
The receiver reported `VERIFIED_NOT_ACTIVATED` and the distinct `NOACT` reply;
app0 remained selected and no reboot occurred during the recording. SDK/image
verification does not establish that the candidate boots. Receiving-to-verified
time was **43.64 seconds**, approximately **16:38:43–16:39:27 Arizona time**
(23:38:43–23:39:27 UTC). Maintenance was released and monitoring resumed.

| Measurement | Observed result |
| --- | ---: |
| Pre-attempt free internal heap (eight settled, HTTP-quiet samples) | Median 132,426 bytes; range 130,768–133,080 |
| Lowest periodic free-heap sample during transfer | 119,148 bytes |
| Lowest sampled largest free block | 110,580 bytes |
| Allocation hook / recorded failures / lost failure metadata | Registered / 0 / 0 |
| Cover / OTA minimum unused stack | 1,464 / 3,532 bytes |
| Web / diagnostics minimum unused stack | 4,380 / 1,232 bytes |
| Sampled log queue peak / dropped / truncated | 4 / 0 / 1 |

No memory guard revocation occurred. The active transfer stayed on
`74:83:c2:c4:77:7c` at −77..−73 dBm with no transfer-time disconnect. There was
one startup `ASSOC_FAIL` on the weaker AP before successful association; do not
report the entire capture as zero WiFi events. There was no panic or allocation
failure in the transfer or observed cleanup. USB statistics are sampled, and
stack watermarks do not bound unexercised error paths. The lower guard remains
an experimental choice; one successful run is not a production reserve proof.
Recovery statistics and independent flash/boot-metadata checks follow below.

After **147.7 seconds without incoming controller HTTP**, the final ten-sample
median internal free heap was **132,426 bytes**, matching the pre-attempt median.
The whole-run allocator per-region minimum sum was 105,740 bytes; this is not
an exact simultaneous low-water mark. All 57 incoming HTTP dispatches (54 root
status) belonged to the documented precheck/client workload; no browser metrics
session was opened. Alpaca's minimum unused stack was 5,416 bytes. The bounded
collector was stopped before its ten-minute end; the **transfer** completed,
while no completed ten-minute sampler window is claimed.

Fresh status again confirmed the verified/no-activation outcome, zero movement,
torque OFF, metrics OFF/zero viewers and maintenance released. USB device-digest
verification matched **every one of the 1,045,600 OTA-written payload bytes** to
the intended binary. The native otadata and partition table were byte-identical
before/after the transfer. NVS bytes differed, so preserve the live NVS and check
exposed application settings rather than claiming raw NVS equality. Normal app0
and the complete original erased app1 are restored as cleanup; the candidate is
not booted as part of this experiment.

Cleanup completed: normal production app0 and the original **entire erased app1**
were restored over USB, with independent device hash verification for both
written ranges. Follow-up USB/HTTP checks confirmed production ELF `49c92048…`,
accepted startup, ready/calibrated CLOSED, unchanged saved limits/endpoints/profile,
stationary torque OFF, maintenance idle, metrics OFF/zero viewers and production
OTA unavailable. Read-only Alpaca reconnected after startup. Temporary plaintext
credentials/header were retired; private test artifacts are retained. Neither
experimental receiver nor collector remains active in normal firmware.

## Activation/recovery follow-up — 2026-10-23

The subsequent supervised test also passed healthy OTA activation and automatic
rollback after a reset during pending first boot, using the same 96 KiB test
heap guard. Matched durable records, USB image digests and native ABORTED/VALID
slot states corroborated both outcomes. No allocation-failure collector was
active in that run, so it adds no new memory-failure count or production reserve
claim. Normal firmware, original boot metadata and erased app1 were restored;
settings/read-only Alpaca were preserved. See the
[activation/recovery evidence](OTA_IMPLEMENTATION_PLAN.md#activation-and-pending-reset-rollback-hardware-results).

## Development OTA scope — 2026-10-23

The user elected to use OTA as a supervised development facility and defer the
remaining production reserve/timing work. `web_control_dev` now has a persistent
receiver and a real full upload/healthy activation passed; a subsequent update
can use the same local development credential without another USB bootstrap.
Normal builds keep their disabled defaults and ignore the dev-only header.
The 20-entry ring and previously exercised 98,304-byte internal / 65,536-byte
largest-block guards remain provisional. No allocation-failure collector was
active for this functional update, so it does not replace the earlier sampled
memory evidence or establish a production reserve. Log compression and broader
workload margin remain deferred. See the [development result](OTA_IMPLEMENTATION_PLAN.md#persistent-development-ota-hardware-result-2026-10-23).

## One-hour stationary standby result — 2026-10-23

The first roughly 13-minute capture was superseded when the user requested a
continuous hour. It had no request errors during the timed interval. A fresh
one-hour capture ran from approximately **19:54:49 to 20:54:52 Arizona time**,
with development firmware `6e18fc29…`, torque OFF at admission, no actuator
commands, status requests every five seconds, periodic root-page reads and
read-only Alpaca checks. Optional metrics remained OFF in all connected samples.
Evidence: `diagnostics/standby-hour-20261023/`, particularly `results.json`,
`samples.jsonl`, and `serial.log`.

**The network stability test did not pass.** After one recovered startup
ASSOC_FAIL, the controller disconnected at **19:59:42**, source uptime 303.304
seconds, with reason 8 / ASSOC_LEAVE. The user confirmed no WiFi changes or AP
restart during this interval. There were 59 successful status samples (median
50 ms, maximum 322 ms), followed by 661 request errors; no STA recovery was
observed. Fallback AP started 20 seconds after loss. USB logging continued for
the full hour with one initial boot and no subsequent reboot. The final HTTP
snapshot failed, so the harness records `stopped` rather than `complete`; this
was a failure to obtain the final snapshot, not an early end to USB observation.

Connected RSSI samples ranged from -86 to -75 dBm. Connected sampled free heap
was 174,184–181,684 bytes; first-minute median was 179,916 bytes and last connected
minute median 179,726 bytes. Final USB health reported 180,564 free bytes and a
155,088-byte historical minimum. This shows no aggregate heap exhaustion or
clear sustained loss before disconnection. It does not rule out allocation or
fragmentation problems: no allocation-failure collector was active, and the last
55 minutes lacked the intended connected browser/Alpaca workload. No full-hour
connected workload or production memory margin is established.

Source inspection found a recovery gap: the installed Arduino `WiFiGeneric.cpp`
explicitly skips automatic reconnect for ASSOC_LEAVE. The application's idle
network loop starts fallback AP after 20 seconds, but has no periodic saved-STA
retry. This explains why recovery may stop for this reason; it does not explain
what triggered the disconnect. Next work should add bounded, nonblocking saved-STA
recovery that respects intentional network setup/disconnection and OTA/maintenance
ownership, then repeat the connected standby test. Leave log capacity and memory
guards unchanged while isolating this behavior. No firmware was changed or
rebooted while checking these results.

### Saved-STA recovery implementation — 2026-10-24

Implemented an allocation-free application retry policy with 20/40/80/120-second
capped backoff, suppression during setup/maintenance and associated AP-client
use, and delayed closure of an automatically opened recovery AP after STA
returns. Connection requests use the existing RAM WiFi configuration and do not
force disconnect, reset the radio, reboot, write settings or drive actuators.
The policy supplements existing Arduino reconnect behavior. No log capacity or
memory guard changed. New native policy tests, including ASan/UBSan, and existing
maintenance/WiFi diagnostics tests pass; development and normal USB firmware
builds pass. The development image is 1,054,240 bytes, 432 bytes larger than the
preceding build. It has **not been installed or hardware-verified** in this step.
See [behavior and hardware checks](DEBUGGING.md#bounded-saved-sta-recovery).

Follow-up installation succeeded on 2026-10-24: development image `4fbb7b8a…`
booted and accepted startup after one full OTA update. Settings and torque OFF
were preserved, and read-only Alpaca reconnected. Outage recovery and the repeat
hour remain pending; this adds no memory-margin or reconnection-success claim.
See the [installation evidence](OTA_IMPLEMENTATION_PLAN.md#saved-sta-recovery-firmware-installation--2026-10-24).

Controlled client block/unblock subsequently verified application backoff timing,
same-boot reconnection and fallback cleanup. A discovered Arduino helper
return-value defect required a small correction and USB installation; corrected
image `47e279e6…` passed the repeated reconnection/cleanup check with preserved
settings and torque OFF. The connected hour retest is now running in
`diagnostics/sta-recovery-20261024/cleanup-check/standby-hour/`, sharing continuous
USB capture. Driver-level retries were also active, so these checks do not isolate
the original ASSOC_LEAVE failure or establish memory margin. No log capacity,
memory guard or optional metrics setting changed.

## Retained failure evidence — 2026-10-24

Implemented independent WiFi-incident and controller-fault summaries in 896 bytes
of checksum-validated RTC storage (two committed copies). There are no new flash
writes, tasks or expanded log ring. The event snapshot includes free/minimum heap
and largest internal block; repeated disconnect notifications/retries do not
repeat the largest-block scan. Optional CPU/stack metrics stay off unless their
existing viewer lease is active. The separate Debug disclosure reads saved
evidence on demand, at most every five seconds while visible, without enabling
those metrics. A bounded read-only endpoint makes the same evidence available
after WiFi recovery, including prior-boot identity and reset information.

RTC retention is conditional on the reset preserving that memory. Full power loss,
brownout/unknown reset or invalid/incompatible records clears the history. There
is no claim of power-loss persistence, panic backtrace capture or a production
memory reserve. Host storage/serializer/diagnostic/maintenance tests, UI lifecycle
and real-browser checks pass. Installation and hardware retention checks remain
pending; the concurrent standby capture remained uninterrupted. See
[details and limitations](DEBUGGING.md#retained-failure-summary).

## Successful connected standby hour — 2026-10-24

The 09:06–10:06 Arizona-time retest completed on `47e279e6…`: 720/720 status
samples, 60/60 connected read-only Alpaca checks, zero request errors, no WiFi
disconnect or unexpected reboot. Median/maximum response was 55/236 ms. Free
heap stayed around 177 KB without a sustained downward trend; first/last-minute
medians differed by only -380 bytes. Final free heap was 176,788 bytes and
historical minimum 145,072 bytes. RSSI was -90 to -73 dBm. Final calibration and
profile were preserved, with CLOSED/ready/fault-free/stationary/torque OFF and
optional metrics OFF. USB capture completed and closed without error.

This passes that stationary connected workload for one hour; no allocation-failure
collector was active and it does not establish production memory margin or outdoor
RF reliability. The retained-summary feature was **not** in that running build.
See [full results](OTA_IMPLEMENTATION_PLAN.md#completed-connected-standby-hour--2026-10-24).

## Combined NTP/retained-summary check — 2026-10-24

Installed `58202622…` with both features. Unavailable NTP did not block startup or
HTTP; real UTC and Arizona synchronization, shared event timestamps and actual
Configuration display passed. A real WiFi incident/heap snapshot survived a warm
reboot and appeared in Debug, without enabling optional metrics.

The final five-minute NTP-enabled workload passed 299 status requests: median
49 ms, maximum 187 ms, no WiFi disconnect or unexpected reboot. Free heap samples
were 166,572–172,060 bytes; final 171,124 and historical minimum 145,464 bytes.
The incident snapshot also exposed a 110,580-byte largest internal block. These
are distinct event/run observations, not simultaneous worst-case reserves or
an isolated measurement of NTP overhead. No allocation-failure collector was
active. Log capacity remains 20 entries (NTP adds numeric timestamp storage as
documented); existing OTA memory guards remain unchanged. Calibration/profile
were preserved, with torque OFF and read-only Alpaca connected. See
[full combined results](OTA_IMPLEMENTATION_PLAN.md#combined-ntp-and-retained-summary-hardware-tests--2026-10-24).

## Klingon appearance — 2026-10-25

The optional browser appearance adds 5,789 bytes (5.65 KiB) to the gzip-packed
UI assets relative to the preceding source revision. This is flash growth,
not a measured heap increase. Assets continue through the existing PROGMEM
serving path; there are no new controller buffers, tasks, or endpoints.

The inline WOFF2 font is 4,308 bytes, subset to the five pIqaD characters
spelling `tlhIngan`. It derives from Klingon pIqaD HaSta 2.03 by Mike Neff
and Michael Everson: https://www.evertype.com/fonts/tlh/ . The derivative
is named Cover Warrior Display; copyright and the full OFL license are
retained in its metadata and `docs/licenses/klingon-font.txt`. FontTools
subsetting retained name records and removed unused glyphs; Brotli supplies
WOFF2 compression. The font is embedded in `data/ui/live.css`, so ordinary
firmware builds need no font tools or network access.

Klingon lettering is decorative and hidden from assistive technology.
English headings, actions, faults, and numeric readings remain readable;
this is an appearance, not a translation. Selection persists in the browser.
Local Chrome checks covered font loading under CSP, both selector states,
reload persistence, desktop/mobile overflow, and switching back to Light.
No firmware was flashed or hardware operated for this change.

### Best-effort translated labels

The appearance now includes a small static phrase table and the complete
26-letter pIqaD alphabet (6,896-byte WOFF2), replacing the repeated decorative
word. Total compressed appearance overhead is approximately 10.3 KiB versus
the source revision before the appearance feature. Translations run entirely
in the browser; no translation API or firmware RAM buffer was added. A browser
MutationObserver updates changing labels only while Klingon is selected;
unmapped states remove stale translations. English stays visible and supplies
accessible labels. See `docs/licenses/klingon-translations.txt` for translation
limits and sources, and `tools/subset_klingon_font.py` to regenerate the font.

Checked font loading, live label changes, unknown-message fallback, reload
persistence, switching back to English, and desktop/mobile rendering in Chrome.
