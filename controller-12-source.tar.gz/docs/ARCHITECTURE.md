# Architecture

The scaffold uses PlatformIO with Arduino on ESP32. Module boundaries follow
AGENTS.md:

- `main`: startup and loop orchestration for the selected build environment.
- `servo_controller`: first ST3215 driver with configuration validation, telemetry,
  and guarded RAM commands. The default build leaves it unused; the separate
  `servo_diagnostic` build exercises read-only communication on real hardware.
- `servo_diagnostic`: finite read-only bench test, with USB logs and a
  compile-time guard rejecting servo write instructions.
- `cover_controller`: supervised manual jog state machine, travel limits,
  timeout, repeated-sample fault detection, torque release, and explicit recovery.
  Saved endpoint OPEN/CLOSE uses the same checks; physical sensor integration
  remains pending.
- `motion_bench`: separate command-triggered +20-count/return test harness with
  a 500 ms host heartbeat; no automatic motion at boot.
- `settings`: validated, versioned endpoint/limit/direction/arc calibration in Preferences/NVS.
- `travel_model`: raw-to-continuous actuator coordinates, explicit linear/circular allowed arcs,
  guarded direct paths and planning duration; UI equivalents live in `data/ui/travel.js`.
- `sensors`: physical cover verification and weather inputs (pending).
- `web_server`: Arduino WebServer routes, home Wi-Fi and fallback AP.
- `web_control`: exclusive driver/controller task, queued jog/Stop commands,
  browser heartbeat supervision, and protected status snapshots.
- `data/ui`: embedded live interface; `tools/embed_ui.py` packages deterministic
  compressed flash assets. Retired HTML/mockups remain available in Git history.

The default application exposes no motion. The bench and web_control builds
use the cover layer to authorize supervised jog commands; see WEB.md.
See [manual motion and bench results](MOTION.md).
See [driver details and bench checks](SERVO.md).

See [endpoint calibration](CALIBRATION.md) for capture, save, and test behavior.
