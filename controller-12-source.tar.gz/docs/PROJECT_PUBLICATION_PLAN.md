# Public project and builder documentation plan

Status: planning, 2026-10-22. This document describes future work, not a claim
that the enclosure is ready for reproduction or unattended operation.

## Goal

Create a coherent GitHub repository and GitHub Pages website that let someone
understand, source, print, assemble, wire, install, calibrate, operate, and
maintain their own telescope cover for the Seestar S30 Pro.

The reader's path is:

**Understand → choose a supported build → get parts → print → assemble → wire
→ install firmware → commission → operate → maintain or troubleshoot.**

Version the complete build: CAD, printable files, hardware list, wiring,
firmware, and instructions must identify which revisions work together.
An attractive website must accurately distinguish demonstrated behavior,
experimental features, historical designs, and future work.

## How to work through this plan with Codex

1. Start with the inventory phase below. Existing documentation and current
   CAD are inputs; avoid commissioning parallel rewrites of the same material.
2. Work on one bounded phase at a time. Use its starter prompt and add any
   new measurements, photos, files, or preferences you have.
3. Ask Codex to inspect the repository first, preserve unrelated changes, and
   implement the deliverables rather than only describe them.
4. Let Codex draft, organize, cross-reference, and check the work. Resolve
   factual gaps with measurements and actual hardware evidence, not guesses.
5. Review the concrete result. Complete the relevant physical checks before
   accepting a phase that depends on them.
6. Have Codex record completed work, unresolved questions, evidence, and the
   next action in this plan. A later session should resume from that record.
7. Request publishing, releases, hardware flashing, or motion explicitly when
   ready. Preparing documentation does not itself authorize those actions.

Useful standing instruction for each work session:

> Follow docs/PROJECT_PUBLICATION_PLAN.md and AGENTS.md. Work on the named
> phase using current repository evidence. Preserve unrelated work. Complete
> useful independent work before asking for missing information. Mark unknowns
> clearly, validate links and relevant artifacts, and finish with what changed,
> what I must verify, and the next step. Do not publish or operate hardware
> unless I explicitly request it.

Keep a single source of truth for each fact. Generate website pages from the
maintained documentation where practical; avoid manually maintaining separate
website, README, and PDF versions of the same assembly procedure.

## Phase 1 — Inventory, scope, and readiness

**Purpose:** establish what actually exists before designing the public story.

Codex deliverables:

- Inventory firmware features, documents, CAD, printable exports, photos,
  diagrams, tests, and existing bench evidence.
- Identify stale statements and contradictions, especially historical
  dimensions, default firmware environments, and planned versus implemented work.
- Draft a status matrix: implemented, bench-tested, mechanically tested,
  experimental, or planned, with supporting evidence where available.
- Propose the initial supported build and identify missing proof.
- Create a prioritized gap list and documentation navigation map.

Your inputs: current CAD location/revision, photos of the actual assembly,
hardware labels, known working configuration, and intended first audience.
Decide whether the first public milestone is a developer prototype or a
reproducible builder release.

Starter prompt:

> Execute Phase 1 of the publication plan. Audit the repository and available
> design files, produce an evidence-backed readiness matrix and gap list, and
> recommend the smallest honest public milestone. Do not infer final dimensions
> from historical notes.

Exit condition: a clear scope, identified authoritative inputs, and a list of
unknowns with owners or next verification steps.

## Phase 2 — Define and version a reproducible build

Codex deliverables:

- A build-revision record linking mechanical revision, board, servo, sensors,
  wiring, firmware version, and print files.
- Supported-hardware and compatibility matrix; unsupported combinations are
  clearly identified rather than implied to work.
- Bill of materials with quantities, exact specifications, fasteners,
  connectors, tools, consumables, tested substitutions, and sourcing notes.
- Estimated costs with currency/date/region and a distinction between parts
  and tools. Verify current supplier information when writing these entries.
- Consistent part names and identifiers used across CAD, BOM, and assembly.

Your inputs: actual purchased parts, measurements, screw lengths, horn
dimensions, supply rating, and confirmed substitutions. Historical AGENTS.md
dimensions are not a substitute for the current assembly.

Starter prompt:

> Execute Phase 2 for the chosen prototype revision. Create the build record,
> BOM, and compatibility matrix from verified inputs. Flag missing measurements
> and distinguish tested alternatives from merely possible substitutes.

Exit condition: every necessary item is identifiable, and the chosen revision
has no ambiguous mix of incompatible mechanical or electrical parts.

## Phase 3 — Printable files and mechanical instructions

Codex deliverables:

- Organized editable CAD and versioned STL/3MF release inventory, with units,
  revision, part counts, and export provenance.
- Printing guide: printer envelope, segmentation, orientation, supports,
  tolerances, material choices, settings, and approximate print requirements.
- Illustrated assembly sequence for base, cover, cradle, horn, arm, seals,
  cable entry, drainage, and service access.
- Inspection points for fit, fasteners, weather paths, cover seating,
  retention, telescope clearance, and manual movement checks.
- Explicit unresolved mechanical validation items, including wind loading,
  power loss, falling-cover risk, and outdoor material durability.

Your inputs: current CAD and exports, actual print settings, fit measurements,
assembly photos, and observed failures. Supply photographs of hidden joints
before assembly makes them inaccessible.

Use annotated real photos or CAD views for technical assembly. Generated
illustrations must not be treated as evidence of geometry, wiring, or fit.

Starter prompt:

> Execute Phase 3 using the selected CAD revision and print evidence. Organize
> the printable-part inventory and write a step-by-step mechanical build guide.
> List the exact photos and measurements still needed; do not invent them.

Exit condition: someone can identify and assemble the correct parts, with
unvalidated details plainly marked. A physical build review is still required.

## Phase 4 — Electrical assembly and commissioning

Codex deliverables:

- Wiring diagram and pin/connector table for the supported board revision.
- Power, polarity, cable routing, strain relief, enclosure penetration, and
  service/disconnection instructions based on actual hardware.
- First-power-on checklist with no automatic movement.
- Servo startup-check guide: expected values, communication failures,
  configuration mismatch, torque state, and read-only diagnostics.
- Safe-limit and endpoint-teaching guide, including replacement-servo setup.
- Commissioning checklist for sensor agreement, telescope clearance,
  interrupted movement, restart behavior, and supervised functional tests.

Your inputs: clear board/connector photos, measured wiring, supply details,
and supervised hardware observations. Codex can prepare tests and interpret
logs; physical clearance and wiring still need direct verification.

Starter prompt:

> Execute Phase 4. Reconcile existing HARDWARE, SERVO, CALIBRATION, and RECOVERY
> documentation into a builder workflow. Create diagrams only from verified
> pin assignments. Keep EEPROM repair separate from normal commissioning.

Exit condition: the instructions safely separate flashing, electrical checks,
servo validation, and mechanical motion, with a practical recovery path.

## Phase 5 — Downloadable firmware and installation

Follow [FIRMWARE_DISTRIBUTION_PLAN.md](FIRMWARE_DISTRIBUTION_PLAN.md) as the
detailed implementation checklist for this phase. Do not duplicate its technical
requirements in a competing specification.

Codex deliverables:

- Clean production build and complete USB installation-image packager.
- Versioned artifacts, checksums, metadata, standalone installation guide,
  and recovery instructions.
- Browser installer and its manifest, if selected for the first release.
- Credential-exclusion checks, packaging tests, and release automation.
- Explicit clean-install versus settings-preserving update policy.

Your inputs: supported hardware decision, hosting destination, release naming,
and a fresh/recoverable controller for supervised acceptance tests.

Starter prompt:

> Start Phase 5 using FIRMWARE_DISTRIBUTION_PLAN.md. Implement the offline
> production image packager and tests first. Prepare reviewable artifacts
> without flashing hardware or publishing a release.

Exit condition: a user can install the selected release without the repository,
and clean installation plus USB recovery have passed real hardware tests.
OTA remains subject to its separate release gates.

## Phase 6 — Everyday use, troubleshooting, and maintenance

Codex deliverables:

- Quick-start guide linking the full build and setup instructions.
- User manual covering controls, telemetry, settings, calibration, and fault
  recovery using current UI screenshots and terminology.
- Symptom-based troubleshooting: what to check, expected observations, safe
  next steps, and when to stop rather than repeatedly retry movement.
- Maintenance schedule/checklist for seals, drains, fasteners, cables,
  printed parts, mechanism wear, and recalibration after mechanical changes.
- Support-log collection instructions with privacy guidance.
- Known limitations and an explicit boundary between supervised prototype use
  and validated unattended weather protection.

Your inputs: common problems encountered, current screenshots, real logs with
secrets removed, and maintenance observations.

Starter prompt:

> Execute Phase 6. Produce the quick start, user manual, troubleshooting, and
> maintenance guides from current behavior. Reuse existing technical documents
> as references and flag any UI/documentation contradictions for correction.

Exit condition: ordinary users can find answers without reading source code,
and every troubleshooting action respects the motion and recovery safeguards.

## Phase 7 — Repository presentation and contribution support

Codex deliverables:

- README with overview image, purpose, supported telescope, capabilities,
  readiness, quick links, installation entry point, and limitations.
- Architecture/development guide with correct environments and test commands.
- Contribution guide, issue templates for build/firmware/mechanical problems,
  pull-request template, security reporting guidance, and support expectations.
- License/attribution inventory covering software, CAD, documentation, fonts,
  images, and third-party components.
- Roadmap separating committed milestones from exploratory ideas.
- Gallery and demonstration shot list or scripts; use real evidence to support
  claims and get permission for third-party/user-submitted media.

Recorded 2026-11-12: MIT software, CERN-OHL-S-2.0 hardware and CC BY 4.0
documentation; see [coverage and exceptions](../LICENSING.md). The first public
firmware beta is supervised multi-turn v0.1.0-beta.1, with GitHub Releases/Pages
and macOS-first installation qualification. Dependency clearance, reference-asset
rights and physical acceptance remain pending.

Your remaining decisions: project name, ownership/branding, contribution
expectations, and public support details within that supervised beta scope. Codex can explain
options and draft files; do not silently choose licensing on your behalf.

Starter prompt:

> Execute Phase 7. Refresh the README and contributor-facing files around the
> supported build and honest readiness status. Prepare license options and
> attribution gaps for my decision. Do not publish repository changes yet.

Exit condition: the repository is understandable to builders and contributors,
with no misleading badges, unsupported claims, or unresolved redistribution
questions in release content.

## Phase 8 — GitHub Pages website

Build the website after the core content is stable enough to populate it.
The requested destination is GitHub Pages; preserve that choice when selecting
tools rather than silently switching hosting providers.

Proposed navigation:

- Home: purpose, real photos, readiness, and Start building.
- Build: compatibility, BOM, printing, assembly, wiring, commissioning.
- Downloads: matching build revisions, firmware, CAD/prints, checksums, notes.
- Install: USB installer and standalone instructions.
- Use and maintain: manual, troubleshooting, maintenance, recovery.
- Project: roadmap, validation evidence, contribution, licenses, source links.

Codex deliverables:

- Static documentation/site structure and a maintainable theme.
- Responsive layouts, accessible navigation, readable diagrams, image alt text,
  useful page titles, and search if the content volume warrants it.
- Build pipeline, local preview, broken-link checks, and GitHub Pages deployment
  configuration suitable for the selected repository/domain.
- Correct project-subpath URLs, downloadable asset paths, version labels,
  HTTPS behavior, and a helpful 404 page.
- A content maintenance approach that avoids duplicated instructions.

Your inputs: GitHub owner/repository, branding preferences, approved media,
domain choice if any, and preferred public milestone.

Starter prompt:

> Execute Phase 8. Prepare a GitHub Pages site using the maintained project
> documents and approved media. Show a local preview and check mobile layout,
> accessibility, links, and downloads. Prepare deployment without publishing.

Exit condition: a reviewable site works locally and in its intended URL layout,
and all visible claims and downloads correspond to documented build revisions.

## Phase 9 — Independent builder review and publication

Codex deliverables:

- End-to-end audit of README → website → downloads → installation → setup.
- Checklist and feedback form for a builder unfamiliar with the development
  history; prioritize confusing or missing steps over cosmetic changes.
- Release notes, compatibility statement, known issues, and publication checklist.
- Verification that published images match checksums and installer manifests,
  and that public documentation refers to the released revision.
- A withdrawal/correction procedure for unsafe instructions or broken releases.

Your role: arrange or perform an independent build review, provide test results,
resolve blockers, and explicitly request publication when the result is ready.

Starter prompt:

> Execute the Phase 9 release-readiness audit against the chosen build revision.
> Check every public path and identify blockers separately from improvements.
> Prepare the exact release and deployment changes for review; do not publish.

After acceptance, a separate instruction can authorize publishing the specified
release and site. Run public URL/download checks after deployment.

Exit condition: public content, artifacts, and support expectations agree, and
the milestone is clearly labeled prototype/beta/supported according to evidence.

## Phase 10 — Ongoing upkeep

- For every firmware or mechanical change, identify affected build revisions,
  instructions, screenshots, BOM entries, compatibility, and migration guidance.
- Keep old release artifacts immutable and preserve their matching instructions.
- Record newly verified behavior and failures; update readiness claims only
  when evidence changes.
- Periodically review sourcing links, documentation links, installer dependencies,
  and unresolved builder issues. Schedule this only when requested.
- Keep experimental work out of the stable download path until validated.

Recurring prompt:

> Review changes since the last published build and update the affected project
> documentation and compatibility records. Propose release notes and identify
> required validation before the next release. Preserve historical release files.

## Recommended first three work sessions

1. **Audit and scope:** complete Phase 1 and agree on the first public milestone.
2. **Build identity and missing evidence:** start Phase 2, inventory current CAD,
   and produce the exact photo/measurement list needed for Phases 3–4.
3. **Useful public foundation:** draft the README/navigation around verified
   status and begin the BOM/build guides while physical evidence is collected.

Do not wait for final cosmetics to prepare useful documents. Conversely, do
not let a polished site become a substitute for a reproducible physical build.

## Progress record

Update this table as work is completed. Preparation is not acceptance.

| Phase | Status | Evidence / next action |
| --- | --- | --- |
| 1 Inventory and scope | Not started | Audit current repository and CAD |
| 2 Build revision and BOM | Not started | Choose authoritative mechanical revision |
| 3 Printing and assembly | Not started | Gather CAD exports and assembly photos |
| 4 Wiring and commissioning | Not started | Reconcile existing technical guides |
| 5 Firmware distribution | In progress | Candidate tooling implemented; 2026-11-12 scope/licenses agreed in RELEASE_PLAN.md; production multi-turn USB packaging implemented; dependency clearance and hardware acceptance pending |
| 6 User and maintenance guides | Not started | Inventory current UI and common faults |
| 7 Repository presentation | Not started | Refresh after readiness audit |
| 8 GitHub Pages | Not started | Select structure after core content inventory |
| 9 Builder review and publication | Not started | Depends on accepted build and artifacts |
| 10 Upkeep | Not started | Establish after initial publication |

## Definition of a complete public milestone

A new reader can identify what is supported, understand the readiness limits,
choose a matching build revision, obtain all required files and parts, follow
the assembly and setup steps, recognize unsafe or failed checks, and recover
without private development knowledge. Contributors can find source, tests,
licenses, and a clear way to report problems. Unproven weather and mechanical
behavior remains visibly unproven.
