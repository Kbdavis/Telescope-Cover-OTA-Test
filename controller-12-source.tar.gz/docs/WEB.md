# First live web controls

2026-11-11 software identity: the footer shows the installed firmware version.
Configuration → About firmware shows the same version with source commit,
build time (UTC), build profile, ELF identity and a release-notes link. Session
JSON and diagnostic downloads retain this metadata; startup logs report version,
profile and commit. Unreleased builds show `dev`, with `dirty` for uncommitted
source changes. See [installation and release packaging](INSTALLATION.md).

2026-11-11 recovery controls: the overview provides a red **Override** checkbox
for one supervised close after visual confirmation that the telescope is fully
stowed and the path clear. It expires after 60 seconds, is cleared on focus/page
loss and maintenance generation changes, and is consumed before sending the
request. It is not a saved preference. Missing/stale status may be overridden;
fresh connected reports of an unstowed, slewing or tracking telescope still
block the request and stop an override closure if received during movement.
The HTTP handler and servo worker both enforce that policy. Normal Close still
requires its usual reported stow evidence. No automatic/unattended override is
provided. Motion limits, heartbeat supervision, Stop and fault handling remain
unchanged.

Controller settings no longer require CLOSED or valid saved calibration.
OPEN, STOPPED, UNKNOWN and FAULT positions can save settings when idle, with
fresh stable servo/torque readback (or the existing verified communication-loss
recovery). Movement, supervised holding, concurrent telescope operations and
maintenance still block saves. Settings preserve the existing torque, and
changes that require restart never resume an interrupted movement. Position
drift during maintenance revokes clearance. Unsaved teaching remains volatile
across a settings-triggered restart.

The overview's confirmed OPEN/CLOSED display allows a 25-count endpoint
difference before reporting outside travel. Raw feedback remains visible;
unknown/moving estimates, mechanical limits and motion fault tolerances are not
widened by this display allowance. Boundary tests cover 25 versus 26 counts.

A STOPPED cover within 25 encoder counts of either taught endpoint displays
**Stopped near CLOSED/OPEN**, with the count difference and whether it is beyond
the endpoint or inside the taught arc. For example, CLOSED 397 / current 412
with decreasing opening direction displays “Stopped near CLOSED · 15 counts
beyond taught CLOSED endpoint.” It remains unconfirmed: no 0/100% progress or
OPEN/CLOSED state is inferred. Beyond 25 counts, existing range warnings remain.
The display itself does not change mechanical admission or fault tolerances.
This display follow-up is installed with the motion update recorded below.

Endpoint recovery update: explicit saved endpoint commands may recover
inward from up to 25 counts beyond either end of a circular taught arc. Two
stable starting reads, supported servo configuration, raw mechanical bounds,
qualified crossing, less-than-half-turn displacement, existing timeout, speed,
stow and supervision checks still apply. Recovery admits only the starting
excursion, not additional outward travel; after entering the taught interval,
normal travel guards apply again. Jogging and target settling retain their
existing tolerances. Saved calibration is not widened. Rejected requests now
describe the failing preflight check rather than referring generically to
Calibration Step 4.

Manual Control now has a default-on **Keep torque enabled after each move**
checkbox. Each step settles into the existing supervised HOLDING state. The
same owner can issue another retained step without releasing torque. Unchecking
before a move keeps the old release-after-step behavior. The checkbox is locked
while moving or holding; support the cover and use Stop / release torque before
changing it. Holding still requires active browser heartbeats: Stop, disabling
manual control, leaving the page, supervision loss and faults release torque.
This is not an unattended mechanical retention mechanism.

Installed 2026-11-11 after the user requested firmware upload: authenticated OTA
transaction `87919ee3e0133737eecc0d82581541e5`, ELF
`5bdab9d858f9cfffa5966e35ff535602be36f66805ab320a23ce89eec70ea1cd`.
Startup accepted and serving the default-checked manual torque option was
verified. CLOSED position 394, torque ON, saved CLOSED 397 / OPEN 2704,
1789-count arc and motion profile were preserved. The active native profile
and lock 1 remained valid; no startup configuration write was attempted. No
motion command or hardware recovery/hold test was issued during this upload.
Local driver, controller, worker and UI regressions cover bounded recovery,
retained manual steps, ownership and Stop. Evidence is retained under ignored
`diagnostics/2026-11-11-manual-hold-recovery-upload/`.

Recovery OTA (2026-10-29): new development receivers advertise
`development-recovery`. A fault, unfinished calibration or saved-range mismatch
does not prevent a firmware update when the mechanism is idle, torque is freshly
verified OFF and raw servo feedback is stable. Admission does not clear faults,
move the servo or save a calibration; reboot runs normal startup checks without
resuming movement. Support the cover before releasing torque.
Use the updated `tools/ota_upload.py upload-dev` client; see
[OTA implementation](OTA_IMPLEMENTATION_PLAN.md) for admission and bootstrap details.

> Monitoring-only revision (2026-10-21, deployed): use the Seestar app
> for telescope arm movement. Arm controls and emergency shutdown are removed;
> legacy telescope-control POST endpoints return 410. Cover controls and cover
> Stop remain. Closing requires fresh stow confirmation. See ALPACA.md for the
> current integration policy; historical arm/shutdown instructions are retired.
> Session recovery (2026-10-26): enabled monitoring now reconnects logical Alpaca
> sessions after a confirmed disconnect. Only `Connected=true` writes are allowed;
> the Seestar app still owns telescope movement. See ALPACA.md for deployment status.


The current workspace calibration has four steps: Prepare → Teach → Review & save
→ Test. Raw Safe travel setup is removed. Begin teaching validates fresh stable
feedback and torque OFF, then opens a supervised temporary teaching domain without
movement. Explicit opening direction and taught circular travel keep progress
continuous through zero. Production boundary motion remains gated pending physical
qualification; the detached-shaft bench build allows only small crossings. See
[CALIBRATION.md](CALIBRATION.md) for current verification and deployment evidence.

Build `web_control` for Arduino WebServer with a dedicated motion-supervision
FreeRTOS task. The normal, read-only diagnostic, and serial bench builds remain
separate. The live UI is now `data/ui/`: Overview, Calibration, and Configuration
share one persistent document, retained form drafts, and Light/Dark/System appearance.
`/`, `/calibration`, `/control`, and `/configuration` load that document with the
appropriate view. Tab switches use browser history without loading another page.
Setup AP requests still open Configuration and cannot move the cover.

`tools/embed_ui.py` builds deterministic gzip assets into an ignored generated
header, streamed directly from flash. `/api/session` supplies the boot token,
beta acceptance, and setup-interface restriction. One shared live polling layer
serves all views; unchanged displayed values are not rewritten. Motion heartbeat
supervision remains independent of view rendering. The legacy HTML files remain
as development references and are no longer embedded.

Overview includes an expandable Telescope telemetry section for reported position,
motion/tracking, camera state/temperature, dew heater, battery/charging/external
power, connection details, and arm/stow operation status. Its open/closed state
survives tab switches. The visible battery bar beneath the telescope drawing is
green above 10% and red at or below 10%, with a numeric percentage and low-battery
label. Missing, invalid, or expired battery readings show Unavailable rather than
zero charge. These displays use the existing polling data and add no requests.

The bottom dock also provides Emergency shutdown: stop capture/plans, verify
idle, stow the telescope, verify stow, then close. It requires connected Alpaca
and native Seestar control and confirmation of clear movement paths. Progress
comes from the controller and continues across tab changes or browser loss.
Stop cancels further shutdown steps and releases cover torque; an already-sent
telescope command may still finish. Failures retain an inspection lock. See
[ALPACA.md](ALPACA.md#emergency-shutdown--2026-10-17) for guards and test limits.

The live calibration flow now starts with 10-count steps and supports 10/100/500-count jogs, a controller-managed supervised
teaching domain, explicit draft discard, and separate opening/closing/jog speed,
acceleration, and timeout settings. Fine jogs require stable target-count feedback;
100/500-count jogs retain the existing 20-count band and stable-window check. Endpoint
tolerance is ±10 encoder counts with stable settling. Jog speed stays capped at 100; endpoint speeds
allow 1–1600, acceleration 1–100, and timeout 500–30000 ms.

Calibration records use version 4 under the existing `cover-cal/v1` key (32 bytes).
Legacy v3 and unambiguous v1/v2 records retain their linear endpoints, limits and motion
profile in RAM; loading never rewrites NVS. Ambiguous long or rollover-looking
records require explicit direction/path review. Saving persists explicit direction
and travel length with readback. Beginning teaching or applying a profile never starts a move
or clears a motion fault. The exact migration gates and nullable travel fields
are documented in [CALIBRATION.md](CALIBRATION.md). No action writes servo EEPROM.

`/api/calibration/profile` and `/api/calibration/discard` use the same authenticated,
stationary, torque-OFF calibration gates. Jog requests accept `step=10|100|500`.
Commands may carry `request_id`; status reports `command_id`, `command_client`,
and `command_ok` after worker processing. A queued HTTP response is not completion.
Status includes saved/draft profiles and age-bounded servo voltage, temperature,
relative load, and raw current. The UI never substitutes preview telemetry.

An Open/Close movement timeout keeps the fault and recovery controls active. A
notice across all tabs asks the user to inspect for binding or an obstruction
and points to **Calibration → Step 3 — Review & save → Movement settings → Move
timeout**. It does not change the timeout, clear the fault, or retry movement.

In Calibration Step 4, when both tests are blocked by unconfirmed torque OFF,
a prominent message instructs the user to physically support the cover first.
The fixed Stop / release torque button is outlined with a downward arrow above
it. The guidance disappears after confirmed torque OFF, when another blocker
takes priority, or when leaving Step 5. It never releases torque automatically.

The live UI retains the beta acknowledgment, setup-only AP policy, motion ownership,
100 ms browser heartbeat/500 ms worker expiry, focus-loss Stop, manual stow when
monitoring is disabled, continuous telescope stow checks during Close, arm-operation
locks and inspection recovery, and disconnected-servo settings recovery. Browser
navigation during cover motion requires Stop & switch; a delayed Close preflight
is cancelled if the user leaves Overview. Settings saves are read back from live
network status, with restart/reconnection handled explicitly.

Validation: PlatformIO build, host migration/profile/fine-step/fault-latch tests,
and `tests/web/live_ui_browser_test.cjs` against the isolated
`tests/web/live_ui_server.py` fixture. Tests cover API requests, command outcomes,
heartbeat and Stop races, save failures, retained drafts, unchanged idle DOM,
light/dark layouts, and connection loss. Hardware motion is not exercised during
UI deployment.

Deployed over USB on 2026-10-17 (`db9b0a3025b2d477` firmware prefix). Readback
confirmed the saved 1–2075 travel range, OPEN 1531, CLOSED 493, and the legacy
motion profile were retained; the cover remained stationary with torque off.
All compressed assets and live telescope/power telemetry were verified. Browser
checks on the controller measured 5–11 ms local tab switches without document
reloads or JavaScript errors. The development Mac showed a separate five-second
`cover.local` lookup delay; using `http://192.168.1.135/` avoided that lookup.
No hardware movement commands were sent during deployment verification.

The redesigned calibration **mockup** is separate from that live page. See
[CALIBRATION_UX.md](CALIBRATION_UX.md) for its guided workflow, local preview
command, simulated fault scenarios, and proposed API changes. It is not embedded
in firmware and cannot send hardware requests.

On the live Overview, **Last valid status** is hidden during normal Alpaca
updates. It appears only after more than 60 seconds without a valid reading,
using whole minutes rather than a continuously changing seconds counter. A fresh
reading hides it again. This is presentation only: five-second safety freshness,
the ten-second display grace and disconnected/error indications are unchanged.

## Local hostname

The firmware advertises `cover.local` through ESPmDNS and publishes the HTTP
service on TCP port 80. Open `http://cover.local/` from the same local network.
The responder follows Wi-Fi interface/address changes; captive-portal DNS
remains separate. Multicast filtering, client support, or a conflicting hostname
can prevent name resolution; the numeric IP remains available. Configuration → Local network name changes the persisted hostname (default
`cover`). Enter 1–31 lowercase letters, digits or hyphens, without `.local` or
leading/trailing hyphens. Save applies immediately; an old browser address may
need updating. The existing setup maintenance interlock applies. Factory reset
restores `cover` while preserving calibration. Choose a unique name for each
controller.

## Beta acknowledgment

Overview, Calibration and Configuration display the same modal acknowledgment
over a gray backdrop until the user checks “I accept.” The dialog uses the
requested beta disclaimer verbatim. Native modal focus handling blocks the
underlying page; Escape does not dismiss it. A failed save leaves it open with
a retry message.

Acceptance is a verified, versioned NVS record in `cover-beta/accepted`, shared
across browsers and retained across reboot and ordinary settings changes.
Missing, corrupt or unreadable records require acknowledgment. Factory reset
removes the record; calibration-only clearing preserves it. The application
settings schema and existing credentials/calibration records are unchanged.

The boot-token-protected `POST /api/beta/accept` requires `accepted=yes` and an
idle controller. Other configuration and control writes require acceptance;
Stop remains available for recovery. Status reads remain available. This records
acknowledgment for the controller, not individual user identities.

Host persistence/reset tests and browser modal/save-failure tests cover this
behavior. Firmware compilation verifies integration. The dialog is included in the
stow-only test firmware; visual browser testing remains to be completed.

The application record is now schema v2 (250 bytes) under the existing NVS key.
Valid schema v1 records (218 bytes) load with hostname `cover`, preserving Wi-Fi
and other preferences. A hostname save preserves the other settings and imports
legacy compiled Wi-Fi credentials if they are still the active configuration.

## Local networking configuration

The live Wi-Fi page is `/configuration` (the Configuration tab in `data/ui/`,
embedded in firmware). Cover controls are available at `/control`; `/` shows controls over
home Wi-Fi and redirects to configuration when accessed through the setup AP.

Startup prefers validated credentials in `cover-app/v1`. Only if that record is
missing does it use optional legacy `include/wifi_local.h` credentials. An
explicit unconfigured record, corrupt record, or unavailable storage starts
setup instead. Legacy credentials remain compiled into the binary if that local
header exists; do not share such binaries publicly. Existing calibration is
preserved in `cover-cal/v1`.

```sh
pio run -e web_control
pio run -e web_control -t upload --upload-port /dev/cu.usbserial-0001
pio device monitor -p /dev/cu.usbserial-0001 -b 115200
```

The serial log prints the home-network URL. Setup starts immediately when
unconfigured, or after 20 seconds without a home connection. Its open AP
is named `TelescopeCover-XXXXXX`, using the final three bytes of the STA MAC.
No AP password is required. Its address is printed over USB. After a successful
connection and verified credential save, the AP closes after 30 seconds of
connectivity. Failed setup retains the AP for retry. Restarting changes the page
token. Cover commands over the open AP are blocked except Stop; use home Wi-Fi
for motion control.

## First-time Wi-Fi setup implementation

A wildcard DNS service and HTTP redirects attempt to open `/configuration`
through the connecting device's captive-portal detection. Automatic display is
not guaranteed; manually open `http://192.168.4.1` while on the setup AP if needed.
Redirects apply only to the AP interface, with API routes excluded. The page is
self-contained and requires no internet assets.

The page lists up to 20 scan results with signal strength and security state,
allows manual entry of hidden SSIDs, and supports open networks, WPA passwords,
or hexadecimal PSKs. Scan and connect are asynchronous, with 15-second scan
and 20-second connection deadlines. Both operations first request a pause from
the motion worker. Current clearance requires a stationary, non-holding cover
with stable CLOSED feedback, or worker-confirmed loss of servo communication
as described under [configuration recovery](#configuration-recovery-and-session-debug).
Torque may be ON or OFF while CLOSED. Other commands are blocked during setup;
Stop and heartbeat handling remain available. No motion or torque-release
command is issued by the setup page. The former physical-disconnection checkbox
and `servo_disconnected` request flag are no longer used for clearance.

Before changing networks the controller starts its recovery AP. Credentials
are saved only after connection to the requested SSID and acquisition of an IP.
Connection timeout retains saved credentials and attempts the previous network.
Write/read-back failure reports an error. The setup AP remains accessible for
retry. A user joining a different network may need to reconnect manually.
Saved passwords are never returned to the browser or logged; NVS records are
not encrypted by this settings layer.

Versioned settings validate bounded strings, ranges and record integrity, and
verify writes by reading back. A saved `wifiConfigured=false` record explicitly
means setup mode, never legacy-credential fallback. Existing calibration and
its Open/Close interlock retain their prior storage format and behavior.

The initial setup page implemented Wi-Fi only; saved Alpaca monitoring and the
live main dashboard have since been added. Cover-name editing and configurable
motion profiles remain future work. Firmware compilation, settings host tests, and browser
logic tests pass. Hardware scanning, credential persistence across reboot,
recovery, and Mac/iPad captive-portal behavior still need live testing. This
implementation was uploaded on 2026-10-04; see the verification note below.

## Factory reset (application settings only)

The live Configuration page includes a separate reset confirmation. Authenticated
POST `/api/settings/reset` requires `confirm=reset-preserve-calibration` and the
same motion-worker maintenance acknowledgement as network setup. Reset is
blocked during motion or holding and requires stable CLOSED feedback or
worker-confirmed loss of servo communication, as described above.

Reset writes and verifies a default `cover-app/v1` record, clearing saved Wi-Fi
credentials, cover name and Alpaca preferences. It deliberately preserves the
entire `cover-cal/v1` record, including endpoints and travel limits. It does not
change firmware, motion constants, or servo EEPROM. Calibration is not marked
invalid by this version of reset. Existing calibration checks still apply.

After a verified write, the controller keeps motion commands blocked and
restarts after two seconds into setup AP mode. The explicit unconfigured record
prevents fallback to compiled Wi-Fi credentials. A failed write/read-back reports
an error without restarting. Join the open setup AP after reboot; no password is required.
This resets runtime application settings; any legacy credentials compiled into
the firmware image remain in that image but are not used after reset.

Host tests verify that reset yields a loaded, unconfigured application record
and preserves calibration. Browser tests cover confirmation/cancel and the reset
request. Hardware reset/reboot behavior remains untested; no reset was executed
on the controller during development.

## Clear calibration (separate action)

Factory reset permanently preserves calibration by design. The separate Clear
calibration button requires its own confirmation and the same worker maintenance
interlock (stationary and CLOSED, or confirmed loss of servo communication).
Authenticated POST `/api/settings/clear-calibration` with
`confirm=clear-calibration` removes only `cover-cal/v1` and verifies absence.
Wi-Fi credentials, mDNS name, other preferences, firmware, and servo EEPROM are
preserved. The worker remains paused until the controller restarts two seconds
later, discarding cached calibration. Open/Close then require newly saved valid
endpoints. Startup may require mechanical inspection/recommissioning because the
uncalibrated bench limits revert to 2015–2075; it never moves automatically.
Storage failure reports an error without restarting. Host tests cover calibration
removal, failure, idempotence and preservation of application settings. No real
calibration has been erased during development.

## Behavior

- Startup is read-only and requires model 777, valid ST3215 configuration,
  torque OFF, and consistent positions inside fixed bench limits 2015–2075.
- Explicit ±100-count buttons use speed 100, acceleration 10 and a 5-second
  timeout. The operator presence checkbox stays checked for the current page session; reloading resets it.
- Stop queues torque release; status reports actual torque readback. Unknown
  or stale readings are not displayed as fresh measurements.
- The browser polls every 250 ms and sends a heartbeat every 100 ms while its
  requested move is active. Only the command owner's client ID can renew its
  lease. Missing heartbeat for 500 ms faults the controller and attempts release.
- Hiding/leaving the page requests Stop; heartbeat expiry is the fallback when
  the browser cannot send that request. Stop is available to every page client.
- Faults remain latched until inspected and explicitly cleared with the recovery
  control. No continuous jog or physical sensors are
  enabled. Saved calibration and endpoint tests were added subsequently; see
  CALIBRATION.md.

## Architecture and access

Web handlers only enqueue commands and read a protected status snapshot. The
motion task exclusively owns UART/driver/controller calls, so Arduino WebServer
client waits do not block servo supervision. Queue entries older than 400 ms
are discarded. Stop uses a separate priority flag and clears queued commands.
Driver transactions and task scheduling still add latency to stop processing;
this is not an emergency power cutoff or unattended safety certification.

GET `/` serves the tool page; GET `/api/status` serves JSON. POST endpoints are
`/api/jog-plus`, `/api/jog-minus`, `/api/heartbeat`, and `/api/stop`.
POST requests require a per-boot `X-Cover-Token` from the page and a numeric
`X-Cover-Client` identifier. Jog requests also require `clear=yes`. Commands are
asynchronous: HTTP 202 means queued, not proof of motion. No CORS access is
provided. The token prevents ordinary cross-origin form commands; it is not
user authentication. This first version is for a trusted local network only.

Host UI tests: `node tests/web/control_page_test.cjs`. Controller safety tests
remain in `tests/host/cover_controller_test.cpp`. Hardware browser-disconnect
and slow-client motion tests remain to be performed in a supervised session.

## Bench verification — 2026-09-30

All four firmware environments built successfully, and the offline page-control
tests passed. The web build was uploaded and joined home Wi-Fi. Live HTTP checks
confirmed the page and JSON status, per-boot token substitution, rejection of
missing-token and missing-clearance jog requests, idle heartbeat handling, and
Stop with torque-OFF readback. Position remained 2046, with no fault. No valid
web jog was issued during these checks. The page was opened for the user's
supervised button testing. Browser-driven motion/disconnect testing remains
pending. The home address observed for this session was 192.168.1.135; DHCP may
assign a different address after reconnecting.

## Supervised motion checks — 2026-09-30

The user confirmed the mechanism was clear for ±10-count, Stop, and heartbeat
loss tests. `tools/test_web_motion.py` exercises the HTTP endpoints and requires
an explicit `--mechanism-clear` flag. This script moves real hardware; do not run
it as an unattended test suite.

At normal speed 100:

- +10 request: position 2037, target 2047, settled 2045, torque OFF.
- −10 request: position 2045, target 2035, settled 2037, torque OFF.
- Stop sent while MANUAL during a +10 request: stopped at 2044, torque OFF.
- Initial missing-heartbeat test: the −10 step completed before 500 ms, so the
  result was inconclusive for heartbeat expiry (position 2035, torque OFF).

Temporary slower builds retained the same limits and 10-count commands, but
still did not reliably keep the command active beyond the deadline. They were
replaced by the extended-settling test described below. The page displays the
build's actual speed.

Example invocation (only with mechanism clearance and an operator present):

```sh
python3 tools/test_web_motion.py --url http://192.168.1.135 \
  --case heartbeat-loss --mechanism-clear
```

The test checks torque OFF, a latched Safety interlock fault, refusal of a further
jog, and preservation of FAULT when Stop is pressed. The host does not
explicitly issue a successful recovery or movement after a fault.

A speed-20 heartbeat-loss attempt also completed before expiry (2035 to 2043),
so it was recorded as inconclusive and the temporary test speed was reduced to 1.

The speed-1 attempt also completed before expiry (2043 toward 2033, ending
at 2034). Very small movements did not reliably lengthen with these requested
speeds; this observed behavior must not be used to infer calibrated speed units.
The historical test environment was `web_heartbeat_test` (retired during release cleanup): normal speed 100, but twenty
settling samples instead of five. This keeps the command active for one second
after reaching tolerance, allowing heartbeat expiry to be tested during settling
without increasing travel. It does not establish mid-travel fault stopping.

The extended-settling test passed: starting 2034 toward 2044, the controller
latched `FAULT: Safety interlock` at position 2043 and read torque OFF. A further
jog was rejected (HTTP 409), and Stop preserved FAULT. No automatic recovery
or resume occurred. This verifies missing-heartbeat response during the active
settling phase; actual browser-close/Wi-Fi-drop and mid-travel tests remain
separate checks.

After the expected fault test, the normal speed-100/five-sample `web_control`
build was restored and verified through HTTP: ready, UNKNOWN, position 2043,
torque OFF, no fault, no motion. Reload the browser page to obtain its new boot
token. No further movement was performed after restoring normal firmware.

Current UI adds calibration capture/save and OPEN/CLOSE tests. See
[CALIBRATION.md](CALIBRATION.md) for the current workflow and limitations.

Current range editor accepts 0–4095; the 2015–2075 range described in initial
bench tests is only the unchanged first-use default. Existing NVS calibration
is retained and movement bounds widen only after an explicit successful save.

Current manual jog size is ±100 counts. Earlier 10-count measurements above
are historical and do not validate longer travel. The historical web-motion
script now exits without sending commands to prevent accidentally using those
old test assumptions against the updated API. UI/worker checks enforce the
full 100-count target against saved limits. No automatic widening is performed.

### Hold-to-jog controls

Hold either direction button to repeat supervised 100-count steps. Release
to request Stop. Space and Enter also support holding while the button has
focus. Each step retains the existing speed, timeout, limits, and heartbeat
checks, with torque released between steps. A full step must fit inside the
configured limits; holding does not extend them.

Stop, pointer cancellation, loss of focus, hiding/leaving the page, unchecking
presence, communication failure, or a controller fault cancels the hold.
A new press is required to restart. Presence remains checked until explicitly
unset or the page is reloaded; it does not bypass heartbeat supervision.
These UI changes have local checks only; hardware testing is pending.

## Responsive layout and local preview

The current responsive interface lives in `data/ui/`. Preview those exact assets
against the in-memory API with `python3 tools/debug_server.py --port 8083`, then
open **http://127.0.0.1:8083/**. See [UI_PREVIEW.md](UI_PREVIEW.md) for limits
and test fixtures. No firmware upload or hardware connection is involved.

The earlier standalone calibration page and preview server were retired during
release cleanup on 2026-11-12. Their source and historical checks remain in Git.

Before deploying, check widths 320, 390, 768, and 1280 pixels, touch controls,
text scaling, scrolling with Stop visible, and portrait/landscape on a real phone.

## Clearing a motion fault

The status panel shows **Clear fault · no movement** during a latched motion
fault. Inspect the mechanism and the fault cause, then tick the separate
inspection acknowledgement. This action posts `/api/recover` with `inspect=yes`
and the usual page token/client headers. The motion worker clears queued
commands and heartbeat ownership, checks servo model 777, and calls controller
recovery. Recovery confirms torque release, validates critical configuration,
and requires two consistent positions inside active mechanical limits. Failure
leaves the fault latched. Success enters UNKNOWN with torque off and never
resumes a move; request any subsequent movement explicitly.

The web controller's `Safety interlock` fault means its movement heartbeat
expired (500 ms). It does not mean a physical limit sensor activated. In the
reported incident, position 1068 remained inside saved limits 1000–2075, with
torque confirmed off. The specific cause of the heartbeat gap was not captured.
The page now explains this fault; the watchdog threshold remains unchanged.
Startup check failures still require diagnosis and a controller reset.

## Repeated Close failure investigation

A read-only status check after the reported repeat failure found FAULT / Safety
interlock, position 2854, torque OFF, endpoints CLOSED=1084 and OPEN=3893,
and allowed limits 0–4000. The operator reported the Mac page remained visible.
This establishes heartbeat expiry, not a mechanical limit or movement timeout;
it does not establish why the heartbeat stopped arriving.

The UI now assigns a generation to each movement request. Status replies/errors
from before that movement and heartbeat errors from a previous movement cannot
cancel its supervision. Previously these asynchronous completions could clear
`active`, silently stopping heartbeat transmission. Regression checks reproduce
that cancellation with the old code and pass with the fix. The live incident
has not yet been reproduced under instrumentation, so causation is unconfirmed.

Status now includes `target`, `motion_ms`, `heartbeat_age_ms`, and `timeout_ms`.
The status panel displays them, and the worker logs fault cause/target/timing
once over USB. Timing freezes when motion ends, so it can be inspected after a
fault. The 500-ms heartbeat deadline, 5-second motion timeout, configured speed,
and travel limits are unchanged. Long endpoint moves can still hit the separate
movement timeout; measure elapsed travel before tuning that setting.

These changes passed local tests and compilation, then were uploaded over USB.
The live page and diagnostic fields were verified after reboot: ready, UNKNOWN,
position 2854, torque OFF, no fault, limits 0–4000. No motion commands were sent.
A supervised physical Close test is still needed to validate the incident fix.

## Heartbeat latency follow-up

The generation fix did not eliminate the reported fault. The next captured
fault was at position 1704, target OPEN=3893, elapsed 1019 ms, heartbeat age
501 ms, torque OFF. This confirms expiry of the 500-ms lease rather than the
5-second movement timeout.

A non-motion probe sent 30 inert heartbeats from a separate client and 12 status
requests concurrently, using 100-ms and 250-ms delays between completed requests.
Before changing Wi-Fi settings, heartbeat response times were 23–443 ms and
status response times 28–439 ms, with no HTTP failures. Browser heartbeats wait
for the preceding response, so this latency leaves little margin for a 500-ms
lease. Round-trip time alone is not a measurement of worker receipt gaps.

The firmware now explicitly disables ESP32 Wi-Fi modem sleep with
`WiFi.setSleep(false)`. Successful browser POST responses also have their bodies
consumed before completion. No heartbeat deadline, speed, limits, or motion
timeout was increased. Status includes `wifi_power_save` and `wifi_rssi`.

After compilation, UI checks, and USB upload, the identical non-motion probe
measured heartbeat responses of 25–233 ms and status responses of 32–254 ms,
with no HTTP failures. Status confirmed power saving disabled, RSSI −77 dBm,
position 1704, ready, torque OFF. This is evidence of improved network latency,
not proof that the intermittent motion fault is eliminated. Weak Wi-Fi remains
a possible contributor. Supervised movement validation is pending; no servo
movement commands were sent during this investigation.

## 2026-10-04 upload verification

Uploaded `web_control` successfully over `/dev/cu.usbserial-0001`; flash hashes
verified. Running firmware ID:
`e6a12d798717d864e9015606af55743e94559c94514dc8919ea58d3a2e1e2f63`.
The controller rejoined home Wi-Fi at `192.168.1.135`. Read-only status confirmed
saved calibration loaded: CLOSED=532, OPEN=1975, limits 0–4000.
Startup readiness failed with unavailable position and torque feedback; no
movement commands were sent. Network setup and reset require torque feedback
before proceeding. RSSI was approximately −94 dBm during verification.
Passive diagnostics resumed in `diagnostics/20261004T192958616602Z/`.
Factory reset was not executed; captive portal and credential changes still
require supervised hardware testing.

## Controller-only setup verification

With the servo physically disconnected, the explicit testing acknowledgment
allowed a live network scan while motion remained disabled. The original
Arduino scan timeout (6 seconds) expired twice; using 600 ms maximum channel
dwell also raises its derived timeout to 12 seconds, inside our 15-second
outer deadline. After upload, scanning completed and returned 10 networks.
Calibration remained CLOSED=532 / OPEN=1975. No factory reset, credential
change, or motion command was sent. Final running firmware ID:
`08ae9d4318c445d04c2a2a7dea2da50b82bb9321c348bf271f3174f05431f8d0`.
Passive capture: `diagnostics/20261004T193613815408Z/`.

## Read-only Alpaca monitoring

Configuration now provides a saved, opt-in monitoring setting for numeric IPv4,
port and telescope device number. Saving restarts through the existing worker
maintenance interlock. `/api/alpaca/status` exposes fresh read-only diagnostics;
unknown readings are null. `close_authorized` now reports readiness for
supervised Close with an already stowed telescope. See [ALPACA.md](ALPACA.md) for implementation, tests and live
verification. The separate main-page mockup remains simulated.

## Live main dashboard

The dashboard polls cover status and the read-only Alpaca endpoint. Telescope
home, slewing and tracking observations require fresh verified data. Pointing,
telephoto camera activity/temperature, and the verified dew-heater switch state
are polled independently. Battery/charging/power source remain unavailable;
heater control is disabled. Wi-Fi signal strength comes from controller status.

Open uses the existing supervised cover controller and heartbeat lease. Close
requires manual stow confirmation when Alpaca monitoring is disabled. While
monitoring is enabled, Close requires two fresh stowed observations and no
tracking/slewing. The worker rechecks before and throughout closing; lost stow
confirmation faults and releases torque. No checkbox bypasses servo readiness
or motion safety checks. Calibration endpoint Close uses the same telescope
guard. A raised telescope still requires the separate stow test first.

Browser logic tests cover missing/stale feedback, presence confirmation, Close
gating, heartbeat handling and stale response rejection.

Uploaded and verified on 2026-10-04, firmware
`5f937ff1a57a03e5e7aceb441b1c6df10b5db5f196785a8e22ba8ee50dffc971`.
GET checks through `cover.local` returned HTTP 200 for Overview, Calibration,
Configuration, shared CSS and both status endpoints. Disconnected servo reported
ready=false and position=null. Alpaca reported connected, home, stationary and
tracking off, with close_authorized=false. No motion commands were sent.
Passive serial capture: `diagnostics/20261004T203958266528Z/`.

## Stow-only commissioning

Overview now includes an explicitly supervised Seestar S30 Pro stow-only test.
It requires fresh stationary telescope feedback, imaging/path confirmation,
and a cover-worker maintenance interlock. The servo-disconnected checkbox is
only for physical disconnection after failed startup. Cover motion is locked
throughout the test and until the operator inspects the stopped telescope and
finishes the test. No automatic Close is implemented. See [ALPACA.md](ALPACA.md)
for command, timeout and recovery semantics.

The additional **Dry run: stow then check Close** button rehearses the sequence
with the servo disconnected and cover feedback explicitly simulated. It obtains
a new final telescope sweep after stow completes and stops at dry-run readiness.
It never closes the cover; Finish test still requires operator inspection.

## Telescope status display grace

The Overview telescope card retains the last valid readings for up to ten seconds
from their original sample time while refreshing, labeled as last reported data.
After five seconds, the display says Updating status; motion controls still use
the unchanged five-second freshness gate. Failed polls do not reset the cached
sample age. At ten seconds, readings become unknown. Disabling monitoring clears
the cached display immediately. Status text has reserved space to reduce layout
jumps. This is display smoothing only; stow/dry-run timeout and cancellation rules
are unchanged.

## Telescope side-view graphic

The live Telescope card includes a responsive bright-yellow inline SVG side view
with a rotating arm, matching the cover card's line-art treatment. Stationary
home feedback displays a folded arm; non-home feedback displays a representative
raised pose. Opening from home and explicitly commanded stowing animate using
illustrative motion, labeled as such. Fresh numeric Alpaca altitude drives the arm rotation when available (−90°
folded to +90° raised in the upright Seestar side view). The fallback is explicitly
illustrative; it must not be interpreted as a measured angle. Equatorial wedge
orientation is not represented. Unknown
motion direction is labeled without inventing an opening/closing direction.

In the schematic fallback, AtHome while Slewing remains true cannot display fully folded. Stale readings
freeze the graphic during the display grace period; unavailable state is dashed
and labeled unknown. Reduced-motion preference disables continuous animation.
This graphic is display-only and has no control or clearance effect.

## Repeatable local design preview

The original dashboard scenario prototype was retired during release cleanup.
Use the [current live UI simulation](UI_PREVIEW.md) for local review. Historical
prototype results do not establish physical motion or telescope clearance.

## Startup retry and calibration-only mode

Overview now shows an inspection checkbox and Retry startup / recover when the
controller is not ready; Calibration also exposes recovery outside the FAULT
state. Missing calibration can permit Set limits after verified read-only servo
checks, while jogging/capture remain disabled. The operator supplies safe limits;
applying them initializes manual calibration without moving. See
[RECOVERY.md](RECOVERY.md) for the flow and torque-release distinction. The status
minimum/maximum now reflect the controller's active range, including explicitly
applied initial commissioning limits before endpoint calibration is saved.


## Startup position recognition — 2026-10-17

On controller startup, two stable servo readings within three counts of a saved
endpoint establish OPEN or CLOSED after configuration, bounds and torque-off
checks. An intermediate position remains UNKNOWN. This does not move the servo
and is encoder-based inference, not physical limit-sensor confirmation.

## Overview power readings and reduced flashing — 2026-10-17

Overview includes native Seestar battery percentage, charging state, external
power presence, battery temperature and overtemperature. See ALPACA.md for the
field mapping, local authentication setup and freshness behavior. The completed
stow-only test card and its browser handlers have been removed. Close continues
to require confirmed stow; the Seestar app can stow a raised telescope.

Repeated polling no longer rewrites unchanged labels or graphic attributes.
Brief status gaps retain the existing display for up to ten seconds; optional
pointing readings expire separately after 60 seconds. The motion authorization
rules remain at their existing stricter deadlines. The initial controller
connection message now clears on a successful status response.

## Local Overview polish — 2026-10-17 (not uploaded)

The open cover illustration now rotates to 90 degrees. The telescope state label
reads “Telescope stowed reported” when home is reported and slewing is false.
The local dashboard preview uses the same 90-degree fully open endpoint.

Close readiness presentation can retain a previously confirmed stow through the
existing ten-second display grace, avoiding a brief gray button/readiness-text
change when an otherwise unchanged sample crosses five seconds between polls.
Explicit disconnection, raised-arm, slewing, tracking or interlock reports still
revoke displayed readiness immediately. Sustained loss expires the display.
Clicking Close with telescope integration enabled first fetches status again;
no movement request is sent without fresh, repeated stow evidence under the
unchanged five-second deadline. Server-side motion checks remain unchanged.
Stop or leaving the page cancels a pending click-time verification by generation.

Dashboard and preview tests pass, including stale-click rejection, unchanged
readiness across brief gaps, explicit contradictions and sustained expiry.
These changes are local only; no firmware upload was requested or performed.

## Telescope arm buttons — local implementation, not uploaded

The Telescope card now provides **Open arm** and **Close arm**, with a separate
confirmation for presence, a physically open/supported cover, clear telescope
path and stopped imaging. Both actions require fresh stationary telescope
status, an idle camera, and fresh calibrated OPEN cover feedback with torque OFF.
Cover controls lock while the arm operation runs. Verified completion releases
the lock; an uncertain outcome exposes an inspected recovery control instead.
See ALPACA.md for command mappings, completion rules and hardware validation
limitations. These changes have not been uploaded or physically exercised.

## Saved network prefill — local change, not uploaded

Configuration preselects the saved SSID on its first successful status load,
including a saved/hidden network not present in scan results. Later refreshes
preserve edits. The password input shows a fixed `********` placeholder when
that network has a saved password; the credential itself is never returned.
Submitting the unchanged field sends `keep_password=yes`. The server only
accepts reuse for the exact saved SSID and rejects a simultaneous replacement
password. Typing a password replaces it; selecting a different network clears
the placeholder. Saved open networks have no password placeholder. Legacy
compiled Wi-Fi credentials follow the same display/reuse rules.

Configuration tests cover initial prefill, scan-independent selection, preserving
edits, password replacement/reuse, changing networks and open-network behavior.

## Deployment verification — 2026-10-17

The user requested upload of the accumulated local changes above. USB upload
succeeded and flash hashes verified. Running firmware ELF SHA-256:
`ebbc3af925e17a968394310b33bea85f85a5883c654914945f2ddff8a3240247`.
Read-only checks confirmed OPEN, ready, no fault, torque OFF, saved OPEN=1531
and CLOSED=493; native arm support enabled with idle phase, unlocked and operation
0. Saved Wi-Fi SSID matches the connected network, and password_saved=true.
Both updated pages are served. No cover or telescope movement test was performed;
physical validation of the new arm controls remains pending.

### Advanced: endpoint holding torque

Configuration → Advanced → **Disable torque after move** defaults to unchecked,
including when older application settings are loaded. Successful Open/Close
moves (including endpoint tests) retain servo torque; checking the option restores
automatic release on completion. Save & restart persists this application setting;
support the cover and explicitly release torque before changing configuration.
Calibration jogs retain their separate supervised hold behavior. Stops, motion
faults, and startup release behavior are unchanged. Completed endpoint holding
is independent of the browser heartbeat; the next endpoint move preserves torque
during preflight. No servo EEPROM is changed. Encoder endpoints still do not prove
physical seating or mechanical retention during power loss.

### Optional Debug tab

Configuration → Advanced → **Enable debug tab** defaults to unchecked. Save &
restart persists the choice; enabling it shows Debug in the main navigation.
The log includes controller uptime and browser-local timestamps (different clocks).

- The servo endpoint observer consumes existing 500 ms position reads while OPEN
  or CLOSED. Each changed valid encoder reading reports previous/new counts and
  signed delta. Failed/out-of-range reads are ignored. Entering an endpoint sets a
  new baseline; travel and fault states reset it. This is observation only, not a
  wind detector or an extra motion-safety decision.
- Alpaca availability/error transitions report connection loss/recovery, error,
  failed request, request duration and driver code when available. An unavailable
  status may be a timeout rather than a confirmed telescope-side disconnect.
- Browser request failures, slow responses and recovery are recorded locally,
  including while the controller is unreachable. No credentials or request bodies
  are logged. Repeated request failures are limited to one per path per five seconds.

Controller debug messages are kept in a 50-entry RAM ring, also printed to serial;
reboot clears them. `/api/debug?after=<sequence>` returns up to 16 entries. The
browser retains 1,000 messages until reload, reports overwritten controller entries,
resets its cursor on controller restart, and polls every three seconds only while
Debug is enabled and the cover is neither moving nor in supervised hold. The
checkbox controls visibility and download, not collection of controller events.

### Manual Control and reboot

Manual Control is always visible; its movement fieldset is disabled by default.
Checking **Enable manual control** opens an equipment-damage warning. Explicit
acknowledgment grants this browser a temporary server-side manual permission for
15 minutes. Leaving the tab, disabling it, lost browser communication, or reboot
locks the UI again. A reload starts locked. Manual requests require the existing
session/client credentials and the manual grant; ordinary jog routes retain their
existing telescope checks.

Manual ±10/100/500-count jogs use the cover worker and configured jog profile.
They bypass configured cover limits and the taught arc, so recovery is possible
from outside the saved range. Each manual move uses raw bounds 0–4095 and cannot
cross encoder zero. Normal and teaching routes keep configured limits. Each step stops and releases torque automatically; another step
requires no intervening Stop click. The motion card groups live travel/torque,
permission, step selection and movement buttons, with raw diagnostics collapsed.
Torque remains enabled during movement. Stop and faults still release torque. Manual commands bypass telescope-stow and calibration workflow
confirmations, including unsaved draft/endpoints gating. This is **not an all-checks-
disabled raw servo interface**: servo configuration/feedback validation, raw encoder
limits, heartbeat, ownership, timeout, wrong-direction protection, Stop, and fault
handling remain. No EEPROM writes or automatic fault recovery are added.

**Reboot controller** has its own confirmation and a separate **Release motor
before restart** checkbox, checked by default. It does not affect manual moves.
Finish movement first. Unchecked prepares a stable current-position
hold and keeps torque enabled through an ESP32 software restart, provided servo
power remains on. Checked releases torque before reboot. The worker verifies the
requested torque state before granting reboot clearance; Stop cancels clearance.

A one-use RTC marker authorizes powered startup only after this deliberate
software reboot. Startup validates servo configuration and position without a
release/enable cycle. Other reset causes retain the existing conservative startup
behavior. No interrupted move resumes, manual UI authorization is cleared, and
settings/calibration are preserved. Failures during preparation prevent reboot.
A stationary retained hold is independent of the browser heartbeat during restart.
This behavior requires hardware verification; host tests cover the no-release
handoff, powered startup, failed preparation and both torque choices.

### Debug severity and filters

The independent **Err**, **Warn**, and **Log (Info)** checkboxes start checked.
Only selected levels are displayed; filtering never deletes retained entries.
Error is red, Warn amber, and Info blue, with text labels in both themes.
Servo position changes, movement/state transitions and faults are Error. Alpaca
and browser/controller communication events are Warn. General debug information
is Info. The controller retains 50 messages; the browser retains 1,000 groups.

Controller storage uses a one-time heap allocation of approximately 124 KB in small blocks;
messages are bounded to 111 characters and end in `...` when truncated. Allocation
failure is reported in the Debug tab, while serial and browser logging continue.
Firmware build size does not include this runtime allocation; hardware memory
headroom still needs verification before deploying this larger buffer.


## Configuration layout and saving

Configuration groups settings into Network & address, Telescope connection,
Cover behavior, Appearance, and Troubleshooting & recovery. A mobile section
selector replaces the desktop index. Settings lock reasons remain visible above
forms, and the existing Stop control remains available.

Each controller form has its own save, unsaved indicator, and discard action.
Before a restart or Wi-Fi change, a dialog identifies other unsaved configuration
sections and offers returning to edits or discarding those other drafts. Appearance
applies immediately in this browser. Unconfirmed saves retain drafts in memory;
passwords are never stored in browser storage or returned by the controller.
The explicit Replace saved password option permits intentionally clearing a saved
password for an open network; otherwise an unchanged blank field retains it only
for the same saved SSID.

Cover behavior uses Keep motor holding / Release motor choices. Diagnostics has
its own save. Both use the existing advanced-settings endpoint while preserving
the other section's confirmed value. No motor operation is performed by saving.
Telescope monitoring On/Off is separate from connection status. Disabling retains
saved connection details and permits an unconfigured address. Telescope saves
preserve the existing connection mode; this form does not enable a new mode.

Recovery controls describe the complete application reset and calibration-clear
scope. The physical-disconnection acknowledgment is temporary, applies only to
settings recovery, and retains all existing server maintenance checks.
`/configuration` serves the live tab in `data/ui/`; the standalone legacy page
was removed during release cleanup. The layout plan is in `CONFIGURATION_UX_PLAN.md`.

Validation uses the local fixture and `tests/web/configuration_ux_browser_test.cjs`
(port 8094, isolated Chrome CDP 9226), plus the existing live UI regression. These
checks exercise simulated settings; they do not move or flash hardware.


## Maintenance and control generations

Normal status exposes `control_generation` and `maintenance` (owner, phase,
lease generation, reason and locked). Updated mutation requests include their
observed `control_generation`; stale/missing generations receive 409. Reload
legacy motion pages. Explicit Stop keeps its existing session validation and
remains unconditional, including for legacy clients.

Browser error/visibility cleanup uses `automatic=yes`, a `stop_reason`, and the
original operation's generation. Delayed cleanup cannot revoke a later
acknowledged maintenance generation. Preparation still permits existing
heartbeats and Stop until clearance; supervised hold takeover is not available.
Maintenance blocks controls in all views and is rechecked on the servo worker,
including queued commands, calibration/recovery, settings and manual enable.

Network/reboot operations own exact leases and cannot clear OTA reservations.
Settings/restart phases cancel on revoked clearance; already committed settings
are preserved. Internal OTA groundwork requires fresh verified OFF state and
worker pause acknowledgments. The authenticated receiver and startup coordinator
are implemented locally behind closed release gates. The normal build keeps
OTA unavailable and uploads disabled. The shared OTA snapshot adds startup
health and a redacted durable `last_update` (transaction, outcome, image/slot
identities and positive selection evidence). No OTA UI/uploader is enabled.
Startup movement/settings requests remain locked until bounded health checks
finish; explicit Stop remains available. Failed startup requires recovery and
never resumes an interrupted move. See the
[implemented maintenance contract](OTA_IMPLEMENTATION_PLAN.md#implemented-maintenance-contract-package-2).
The [package-3 protocol and recovery contract](OTA_IMPLEMENTATION_PLAN.md#package-3-local-implementation-and-current-direction)
documents the gated challenge/prepare/cancel endpoints and bootstrap behavior.

## Bounded HTTP input

The controller uses a project-owned incremental input adapter around the pinned
Arduino `WebServer` routing/response API. It does not call the framework's
blocking request, raw-upload or multipart parsers. Registered routes, collected
authentication headers, form arguments and exact OTA `plain` bodies retain their
existing handler interfaces.

Each accepted connection has one transient input arena, bounded to 4,352 bytes
including parser metadata. It is freed before building a handler's response and
when input fails, times out or disconnects. Input parsing reads at most 256 bytes
per main-loop call and has an absolute 2,000-ms deadline from client acceptance;
new bytes do not renew that deadline. There is no request-error event publishing
or reflection of request data. Rejection uses one best-effort nonblocking write
followed by close, so malformed clients cannot enter the normal response writer's
retry loop.

| Input | Limit / policy |
| --- | --- |
| Request line | 1,024 bytes including CRLF; GET or POST, origin-form literal path, HTTP/1.0 or 1.1 |
| Headers including request line | 2,048 bytes total; at most 32 fields; each header line at most 512 bytes including CRLF |
| General POST body | 2,048 bytes; form URL encoding; explicit canonical decimal Content-Length, including zero |
| OTA prepare/cancel | Exact literal route without query; POST requires nonempty `text/plain` body, at most 640 bytes |
| Form/query arguments | At most 32 combined; percent escapes must be complete hexadecimal and cannot decode to NUL |
| Connection | One request, then close; no pipelining or trailing buffered bytes |

Duplicate headers (including identical Content-Length), folded headers, bare LF,
transfer encoding, compressed request bodies, Expect/100-continue, multipart,
GET bodies, raw NUL and unsupported body media types are rejected before routing.
Unsupported methods return 405; malformed framing 400; missing POST length 411;
body limits 413; oversized request line 414; unsupported media/encoding 415;
Expect 417; oversized headers 431; incomplete/slow input 408. The connection may
close without a full error response when the socket cannot accept the immediate
nonblocking write. No request handler runs for rejected input.

This bounds input reception and its allocation; it does not establish a complete
HTTP response or explicit Stop latency under RF loss, output backpressure or
concurrent workloads. The existing response writer is still the Arduino API.
The independent servo worker and heartbeat fail-safe remain unchanged. Malicious
client floods can still delay HTTP access; finite per-request input is not a
network denial-of-service guarantee. The temporary arena and bounded decoded
strings must be included in the remaining runtime OTA memory-margin tests.


### Date and time configuration

The live Configuration tab includes Date & time: optional NTP (off by default),
editable server (`pool.ntp.org`), and editable POSIX time zone (`MST7`, Arizona).
Settings are saved through the guarded `POST /api/settings/time` route with
`enabled=true|false`, `server`, and `time_zone`, plus the existing token, control
generation. Saving restarts
the controller after maintenance clearance. Other application settings and
calibration are preserved. Old settings acquire disabled NTP defaults.

Synchronization runs in the background and never waits for a reachable server.
Controller logs show configured local time with a numeric UTC offset when known,
and always retain uptime. Before synchronization, calendar time is unknown.
See [network time and logging behavior](DEBUGGING.md#optional-network-time-and-local-log-timestamps)
for timezone examples, API status fields, offline behavior, and validation limits.

## Bounded browser connection recovery

The live page checks for stale controller status independently of its awaited
polling loop. After 10 seconds without fresh status while visible, it may reload
itself up to twice. Returning to a hidden or restored history page starts a fresh
10-second grace period. Telescope-only outages do not trigger page reloads.

The attempt count lives in per-tab `sessionStorage`, so a reload cannot reset
the limit. Thirty seconds of continuously observed healthy controller status
clears it for a later outage; a brief successful request does not. If storage is
unavailable or cannot retain the count, automatic reloads are disabled. After
two attempts, the page explains that automatic reloads stopped. Normal polling
continues and can still recover without another reload.

Automatic reloads wait while there are unsaved calibration/configuration edits,
active commands or supervision, reported movement/holding, maintenance, OTA,
settings/manual operations, or an open dialog. Page loads and history restores
clear supervision and temporary physical acknowledgments. Recovery sends no
movement command and does not reboot the controller. A successful status poll
clears its own unavailable warning without erasing unrelated command errors.

Validation: `tests/web/connection_recovery_test.cjs` covers timing, persistent
limits, hidden/history pages, storage failures, safety/draft guards, a stranded
startup request, and warning recovery. `connection_recovery_browser_test.cjs`
uses the real embedded UI and fixture (port 8095, isolated Chrome CDP 9226) to
verify retained edits, exactly two actual reloads, cleared supervision, locked
offline controls, and resumed polling with no actuator requests. The observed
return-to-page failure is intermittent; this is bounded recovery rather than
proof of its underlying browser/network cause.

Deployed on 2026-10-26 (Arizona) to `192.168.1.135` using closed-cover development
OTA, firmware `c9164a0324348026ae83057c5bb30d224baae1306d76918b3edebf31ac884a0d`,
transaction `b69190189bc9dfee55f2e3a1fdafc621`. Both recovery tests, the existing
control-generation/debug tests, the live UI/configuration browser regressions,
and the development firmware build passed. Post-update reads confirmed accepted
startup, CLOSED at position 495 with torque ON, preserved calibration/network
settings, valid connected Alpaca monitoring, and the new script served by the
controller. Private local evidence is under
`diagnostics/browser-recovery-20261027T020226Z/`. Existing open pages need one
manual reload to load this revision.

## Configuration recovery and session Debug

A board running without a servo displays **Servo not connected** once per
disconnected period in the current browser tab. Dismissing the notice leaves
Configuration and Debug usable; polling and page reloads do not restore it when
session storage is available. Valid position and torque feedback reset the notice
for a later disconnection. Startup **Recheck servo** lives in Calibration and can
request fresh worker checks even while feedback is missing. Actual motion faults
keep their global recovery controls; dismissing the setup notice never clears one.

All Configuration settings, Wi-Fi scan/connect, and the two confirmed reset
actions can proceed when the idle controller cannot communicate with its servo.
This applies both to a fresh board and to communication loss after startup.
The worker requires three consecutive position/torque poll cycles with transport
failures, spaced at least 500 ms apart, then a failed read-only model probe before
granting settings maintenance. Valid replies, including device-error replies,
do not count as communication loss. Returning feedback revokes offline clearance.
The API publishes `settings_offline_allowed`; the browser requires fresh controller
status and shows that position and torque are unknown. A controller/network outage
does not unlock saving. A responding servo still requires stable CLOSED feedback.

This is permission to change application settings, not proof that a mechanism is
safe or that torque is OFF. Movement/holding, maintenance ownership, Stop,
validation and NVS read-back checks remain enforced. Calibration motion/capture/
save, manual reboot and OTA retain their separate requirements. No configuration
save writes servo EEPROM or starts cover movement.

Under **Configuration → Troubleshooting & recovery**, **Open Debug for this
session** immediately opens Debug without saving or restarting, even when the
cover is open or servo feedback is unavailable. It preserves configuration drafts.
The selection lives in this tab's `sessionStorage` and survives reloads; use
**End session Debug** or close the tab to end it. **Always show Debug tab** is the
separate saved preference. Logs and retained summaries retain their existing
access/polling guards; optional metrics still require explicitly opening their
panel. If browser session storage is unavailable, the selection lasts only until
the page reloads.

**Download diagnostics** in the same section saves a timestamped JSON support
report. It includes controller state/fault, firmware and boot identity, uptime,
available servo telemetry, saved calibration and controller calibration draft,
motion profiles, network/time/telescope settings, telescope status, retained
failure evidence, recent controller event pages, motion and heartbeat traces,
cached servo validation/communication evidence, and this tab's browser messages.
The report does not include unsaved settings form inputs, Wi-Fi scan results,
passwords, authentication fields, firmware binaries, or a fresh servo register
dump. Network names, local addresses and event text remain visible; review the
file before sharing. The browser downloads locally; nothing is sent to support.

Collection uses existing read-only endpoints sequentially and assembles the file
in browser memory. It does not activate optional metrics or change settings,
torque, calibration, or servo configuration. Existing home-network restrictions
still apply to detailed logs and retained evidence; setup-hotspot downloads can
include basic controller status and configuration. During motion, holding or
maintenance, collection uses cached browser data. If communication fails, available
sections still download with per-section errors and labeled cached data/ages.
Missing evidence stays null. A disconnected tab can only export evidence it
already received, so save the report before closing the tab.

Report schema v1 records browser UTC capture times, per-section provenance,
`partial`, and a `consistency` result from beginning/ending boot identity checks.
Collection is not atomic; `same_boot` does not imply all values were sampled at
once. Cached sections retain their original session identity. Controller log
reads are spaced by 1.1 seconds, stop after eight bounded pages, and preserve
page loss/cursor metadata. Restart, paging, access or communication failures
produce a partial report. Browser reload recovery waits for an in-progress
download to finish. No Debug preference or settings save is
required to use this read-only download.

Run `node tests/web/diagnostics_download_test.cjs` for offline export, privacy,
partial failures, restart/paging bounds and motion/maintenance access checks.
`tests/web/diagnostics_download_browser_test.cjs` verifies a real browser download
against the local live UI fixture and isolated Chrome CDP (defaults: ports 8091
and 9226; override with `FIXTURE_URL` and `CDP_URL`).

Servo support evidence (`/api/diagnostics/servo`) is a passive, bounded cache
published by the servo worker. It records transaction failures/retries, failed
logical reads, driver-rejected positions, last successful communication and last
transport error (including register and device-status byte), observed model,
critical configuration values, last validation result and timestamps. The full
40-byte profile is included only if existing validation already read it. Absent
observations remain null. Observed values and snapshot matches may be older than
the most recent failed validation; use their timestamps and the overall validation
result rather than treating old values as a fresh pass. A false legacy phase/offset
check is expected for an accepted exact factory/fixed-reference profile; the
compiled policy and overall validation result identify the applicable rule.

The latest controller fault freezes its reason, prior state, accepted position,
elapsed time, consecutive failure/rejection counters, heartbeat context, cached
servo observations and torque-release confirmation. Motion faults capture driver
evidence before release; a Stop release failure records the failed release itself.
The frozen motion ring holds up to 64 samples at at most 10 Hz (approximately the
last 6.4 seconds of a continuously polled move). Each sample distinguishes valid
transport data from controller acceptance: outside-limit, discontinuity,
wrong-direction and holding-drift observations are explicitly rejected; failed
reads have null position. Counters include reads omitted by the sampling limit.
Preflight/startup failures can have no motion trace, which is reported as null.
Recovery and later movement do not erase the frozen fault; the next fault replaces
it. Detailed fault evidence is ordinary RAM and is lost on restart/power loss;
download before rebooting. The existing retained failure summary remains separate.

No extra servo polling, persistent writes, automatic recovery or optional metrics
are introduced. Load/current/voltage/temperature come from the existing polling
cadence, which normally pauses secondary telemetry during movement; their fault-time
ages are included and may be old. The support endpoint shares the bounded log-read
budget and is denied during motion/holding/OTA and on the setup hotspot. It uses
temporary heap buffers (12 KiB JSON capacity plus roughly 1 KiB snapshot), separate
from ordinary status responses. The frozen shared cache is roughly 1 KiB; driver
and controller evidence add roughly 0.4 KiB to their existing worker objects.

The servo-evidence expansion was verified locally on 2026-10-28 with driver,
controller, fixed-reference, read-only-guard, actual-worker integration, bounded
JSON and browser-download tests. The frozen-fault test exercises a later recovery
and new move without overwriting the recorded fault. Both production and
fixed-reference development builds pass. Compiler stack reporting gives a
2,784-byte static cover-worker frame within its existing 6,144-byte allocation;
this is a compiler measurement, not a new hardware fault-path watermark.
The expansion has not been deployed: the read-only OTA precheck found the controller
actively OPENING and running a newer firmware installed outside this task
(`a29fae8252080852f3812cf6a86e4fae8a33e3c2e92781dff56bce97c69959a8`).
No upload, actuator command or settings change was sent. Local stack reports and
precheck evidence are under `diagnostics/servo-fault-evidence-20261028/`.

Diagnostics download deployed by OTA on 2026-10-28 to `cover-dev.local`
(`192.168.1.43`) using the matching `web_control_reference_dev` build, firmware
`eb373b9283e32ebe23be749db10528a6aac445400cb1ac615347c4cba112cbd4`,
transaction `e15685fa6996d3ef3892845fe37b2458`. The uploader confirmed COMPLETE;
startup was accepted and durable boot selection confirmed. Read-only checks
verified exact embedded HTML/JavaScript/CSS, preserved calibration (CLOSED 1148,
OPEN 2837, reference 1328 and saved profile), application settings, and torque ON.
The controller stayed CLOSED at raw 1153. Download/privacy checks passed against
the local browser fixture; no hardware movement was requested for deployment.
Private installation evidence is in
`diagnostics/diagnostics-download-ota-20261028T204106Z/`.

Validation uses the actual worker host integration test and the live UI browser
fixture: repeated/transient failures, reconnect revocation, device-error replies,
settings forms, stale status and motion gates, session Debug without settings
writes, retained diagnostics, metrics and reload behavior.

Deployed over USB on 2026-10-27 to the new board at `192.168.1.43`, MAC
`28:05:a5:c2:a9:94`, firmware
`7b4dc6af8e984a54050ccc96ff59f35b8867576baeef8dbd7f20c1611811124e`.
The board reported UNKNOWN with null position/torque, no calibration and
`settings_offline_allowed=true`. Saving its existing hostname unchanged completed
with verified NVS persistence and no restart. An isolated browser opened session
Debug and received controller logs with the saved Debug preference still false,
no POST requests and no restart. No movement commands were sent. Build, host
safety/maintenance tests and browser regressions passed; communication-return
and motion cases used the host/HTTP fixtures. Private evidence is under
`diagnostics/offline-settings-20261027/`. Reload existing pages to load the update.

The USB-only setup follow-up on 2026-10-27 installed firmware
`e55b1267c60dcc1bc8f4f1535e647acd246d9c17e33cd2c8b45c6d7205d17fe2`
on the same new board. Its real browser page showed the servo notice once,
kept it dismissed through polling and reload, left Configuration/Debug usable,
and exposed inspected Recheck servo in Calibration. Verification sent no POST
requests or motion commands. `servo_setup_browser_test.cjs`, the configuration
browser regression, worker/startup-recovery and existing motion safety tests passed.
Reconnection and genuine motion-fault cases used fixtures; the board has no servo.
Private startup/browser evidence is under `diagnostics/servo-setup-20261027/`.

### Overcurrent recovery and remounted direction (2026-10-29)

An ST3215 device status with bit 3 set (`0x08`, including combined statuses)
is reported as servo overcurrent. Motion faults immediately on that device error;
transport failures without overcurrent retain the repeated-read policy. Failed
read values remain invalid, and torque release is best effort until verified.
The recovery dock on every view and the calibration issue panel instruct users to
support the cover, inspect for binding/obstruction, switch the servo's external
power OFF and ON, then acknowledge inspection and Clear fault / Recheck servo.
Restarting only the ESP32 does not clear this servo fault. Recovery never resumes
a move or bypasses configuration/feedback/torque checks.

`manual_ready` reports worker-validated manual eligibility independently of normal
`ready`, including startup outside cover limits or without saved endpoints.
Explicit recovery may clear a fault while outside the saved range; normal moves
stay unavailable there. Manual requests never change calibration or servo EEPROM.

`assembly_opening_direction=-1` reports the remounted assembly mapping. Both Manual
and calibration step/hold controls use it ahead of any old draft direction. Saved
+1 calibration is preserved for review and must be retaught before normal movement.
