# Calibration interaction

The live interface in `data/ui/` uses **Prepare → Teach → Review & save → Test**.
The static mockups were retired during release cleanup; Git retains their history.
The fixed opening direction and single movement-button pair described below
are built, browser-tested and installed on cover-dev.local (2026-10-28).
The controller starts teaching with direction +1, so OPEN capture no longer
depends on an unanswered direction question. The browser regression captures
OPEN at 2890 after moving beyond the former boundary at 2853.
See [CALIBRATION.md](CALIBRATION.md) for coordinates, persistence, API and qualification.

There is no Safe travel step and no raw minimum/maximum form. Beginning teaching
requires presence, mechanical support, a stowed telescope and stable torque-OFF
feedback. It opens the controller-managed temporary teaching domain without
movement. The operator remains responsible for each supervised step or manual
positioning. Normal endpoint operation stays blocked until the draft is saved.

Opening Teach directly does not start a session. When movement is locked, a
prominent explanation links to Prepare and its explicit Begin teaching action.
After a browser reload, Resume teaching requires the physical confirmations again
and preserves the existing worker draft without sending another begin/reset.

Teach uses one pair of movement buttons labeled “Toward open” / “Toward closed”.
The assembly fixes increasing encoder counts as opening, so Begin teaching
records direction +1 automatically. There is no direction question or separate
confirmation required to enable OPEN capture. Capture CLOSED, move toward open,
stop and capture OPEN. Recapturing CLOSED selects the OPEN task automatically.
CLOSED is application zero; OPEN completes the explicit arc. Shaft rotation is
distinct from physical cover angle. The validated fixed reference moves the
former boundary inside the raw range; actual new raw-zero crossing stays gated.

Review shows normalized endpoints, taught length, endpoint settling margin,
movement profile and timing. “Review both positions” automatically increases an
insufficient applied draft timeout to the planning recommendation (up to the
existing 30-second limit). It preserves speeds, acceleration and longer timeouts;
Save calibration is still required for persistence. Recommendations beyond the
limit require a review of speed/travel. This local change is not yet deployed.
Manual profile suggestions edit only the form. Apply, save
and test are distinct explicit actions. Recapturing CLOSED invalidates
OPEN; changing calibration invalidates browser test results.

Pending local interaction changes (not deployed): Calibration and Manual Control
offer 10, 100 and 500-count steps; the 1-count option is removed. Held movement
waits briefly for delayed completion/torque feedback between steps instead of
dropping the held input. Release, lost supervision, faults and ownership changes
cancel repetition; delayed feedback never triggers a move before it is confirmed.

Stop remains visible on every viewport. Releasing torque requires mechanical
support. Endpoint tests accept confirmed torque ON or OFF, allowing the next test
to preserve an existing endpoint hold. Unconfirmed torque, active supervised
holding, faults and other motion gates still block testing. The torque-OFF lock
message and highlighted Stop pointer have been removed. Faults stay latched through profile or teaching changes;
recovery requires inspection and never repeats movement automatically.

Production boundary motion remains gated pending physical qualification of the
exact servo profile. The detached-shaft bench build is separate and bounded;
a successful software simulation does not qualify hardware.
