# GitHub release discovery and approved firmware updates

Planning baseline: **2026-11-12, America/Phoenix**, source commit
`fb2f4ae94756b36c9e80746c8bed4e499c01a38e`. This document proposes work; it
does not authorize implementation, hardware operations, servo writes, tagging,
pushes, hosting, publication or GitHub settings changes. Leave it uncommitted
for review. Phase prompts below are future, separately scoped requests.

Owner requirement confirmed in the follow-up conversation: **USB is acceptable
for the first installation; thereafter offer automatic release discovery and an
optional complete download/install/reboot workflow directly in the controller's
webpage.** Installation remains user initiated and explicitly confirmed. USB
remains a recovery option. Discovery-only delivery is an incremental milestone,
not completion of this requirement. This confirmation does not authorize
hardware operations or publication, and does not approve the outstanding
security/key-custody or servo-startup policy choices.

## Recommended sequence

Keep Arduino-on-ESP32, PlatformIO and the pinned partition layout. Deliver
read-only discovery, an **Update available** footer link, release selection and
USB instructions first. Gate production wireless installation independently.
Before enabling it, establish authenticated releases, device authorization,
multi-turn compatibility, bounded transfer memory, settings compatibility and
verified startup/rollback. Bootstrap existing USB-only installations once by
USB; subsequent compatible releases may use wireless updates.

The first beta remains a supervised prototype. Updating never proves enclosure
safety, grants unattended operation, moves the cover, resumes interrupted motion
or grants permission to program the servo. Do not reinterpret the already
published private pipeline test as a qualified beta.

## 1. Current-state audit and reconciliation

| Area and inspected files | Evidence and consequence |
| --- | --- |
| `tools/version_info.py`, `src/firmware_version.h`, `VERSION` | Generated identity includes version, full commit, profile, release/dirty flags and UTC build time; dirty worktrees also have a fingerprint. Release version syntax is currently restricted to the base version with optional `alpha.N`, `beta.N`, `rc.N`, and release identity requires clean `web_control_multiturn_usb` source. Development is `<base>-dev+<sha>[.dirty]`. Extend this deliberately for a future production OTA profile. |
| `src/web_server.cpp`, `data/ui/app.js`, `data/ui/index.html` | `/api/session` already supplies firmware metadata; `/api/status` supplies ELF identity, boot identity, torque, motion/holding and maintenance/OTA state. Footer `sessionNote` and Configuration → About firmware already render identity and release links. There is no release discovery or selection service. Add a separate Configuration section and navigation entry while preserving About. |
| `tools/package_release.py`, `tools/validate_release.py`, `installer/` | Isolated clean-commit USB packaging, pinned build inputs, four boot components, identity/profile/layout checks, source/output allowlists, credential marker checks, checksums and selected Python/Node/C++ regressions exist. Output includes merged `factory.bin`, installer `manifest.json`, separate ESP Web Tools manifest, `release.json`, notes and notices. No signed update catalog or supported public application OTA package exists. |
| `installer/core.mjs`, `docs/INSTALLATION.md` | Guarded browser flow inspects ESP32/4 MB and partition bytes, asks for destructive installation confirmation, erases flash, writes at zero, verifies digest and restarts. It reports `startupConfirmed:false`. USB installation/recovery currently erases settings; there is no qualified preservation shortcut. macOS Chrome/Edge physical qualification and dependency clearance remain pending. |
| `platformio.ini`, `src/servo_build_config.h`, `src/ota_service.cpp` | Public candidate is `web_control_multiturn_usb`; descriptor `multiturn_usb`, native goals, exact RAM startup policy, no commissioning routes or development secret. Static assertion forbids its OTA receiver/secret. `web_control_ota` upload is explicitly blocked. Two slots do not make the public candidate receive updates. |
| `tools/ota_upload.py`, `tools/ota_manifest.py`, `src/ota_auth.h`, `src/ota_protocol.h` | Production CLI upload is gated; explicit `upload-dev` uses ignored local credentials. Boot-bound HMAC challenge/prepare/cancel control precedes espota UDP invitation on 3232 and an ESP32 reverse TCP connection to the desktop listener. MD5 challenge/ACK framing is transport compatibility, SHA-256 verifies transfer integrity, and ELF identity verifies the expected build. These are not publisher signatures. A browser cannot use this UDP/listening-TCP protocol directly. |
| Existing image compatibility | Receiver `otaPrefixValid()` and canonical control body accept `web_control`, protocol 1/settings 5/handoff 1. Python permits `multiturn_usb` only under an explicit USB inspection flag; desktop `Artifact` uses the narrower inspector. **Existing updater is not an end-user multi-turn OTA path.** Do not weaken descriptor checks to accept every image. |
| `src/maintenance.h`, `src/maintenance_worker.h`, `src/web_control.cpp` | Exclusive owner/generation lease, queue fencing, worker pause, periodic physical/memory validation, Stop revocation, cleanup acknowledgment and serialized commit exist. Production requires CLOSED and clean calibrated readiness; private development recovery can admit faulted/uncalibrated stationary hardware. Ordinary admission currently accepts a valid torque read even when ON; OFF is required by recovery and certain cleanup paths. Older OTA prose describing universal OFF admission is stronger than the code. Tighten production admission explicitly rather than relying on that prose. |
| `src/http_request.h`, `src/bounded_web_server.h` | General input is bounded to 2 KiB body, OTA control to 640 bytes, with a two-second request deadline; parser rejects binary NULs, unsupported content types and transfer encodings. A large HTTP upload cannot be added as an ordinary form or by globally increasing limits. It needs an isolated bounded streaming adapter. |
| Startup and transaction record | `verifyRollbackLater()` defers Arduino acceptance and arms a 45-second RTC watchdog. `pollOtaStartup()` waits at least four seconds, evaluates health for up to 30 seconds, checks tasks/web/settings/journal/local recovery/receiver and reconciles durable transaction/slot/image evidence. Missing home Wi-Fi can be acceptable with local AP recovery. Existing check treats application settings as readable unless `Unavailable`; malformed data is not automatically a rollback failure. Review semantic compatibility separately. |
| Actual rollback evidence | Installed local SDK `dio_qspi/include/sdkconfig.h` enables `CONFIG_BOOTLOADER_APP_ROLLBACK_ENABLE`; Arduino core has the weak deferral hook overridden by this project. `docs/OTA_IMPLEMENTATION_PLAN.md` records device-digest-matched bootloader, healthy A→B activation, pending-first-boot reset rollback, autonomous pre-/during-setup watchdog rollback, receiving-phase interruption and post-intent/pre-selection power loss in October. This is measured historical support, not just two slots. It is not a fresh verification of the active controller or future public package. |
| Memory and failure limits | Historical development guards of 98,304 bytes free internal heap and 65,536 largest block are test/development values, not an accepted production budget. Full workload, current native workers, signing, HTTP/TLS peaks, flash/Stop latency, radio loss, cuts inside journal/selection writes and new production startup need qualification. Build size/static DRAM are not runtime reserve. |
| `docs/RELEASE_PLAN.md`, `docs/FIRMWARE_DISTRIBUTION_PLAN.md` | USB first, destructive recovery, separate public OTA milestone and immutable tested assets remain the baseline. Private `v0.1.0-beta.1` at `9cc56f3…` is recorded as pipeline-test/not hardware tested; publication and hardware acceptance are distinct. Do not reuse that version for different bytes. Hosting/public distribution and dependency clearance remain gated. |

Read the dated implementation results in
[OTA_IMPLEMENTATION_PLAN.md](OTA_IMPLEMENTATION_PLAN.md) before the older
[OTA_INVESTIGATION.md](OTA_INVESTIGATION.md): the latter's statements that no
receiver or health rollback exists are historical and superseded. Use
[INSTALLATION.md](INSTALLATION.md), [RELEASE_PLAN.md](RELEASE_PLAN.md) and
[FIRMWARE_DISTRIBUTION_PLAN.md](FIRMWARE_DISTRIBUTION_PLAN.md) for current USB
policy. Update their applicable sections during implementation, preserving
historical measurements.

### Servo profile is a release compatibility boundary

AGENTS.md records the commissioned native profile (model 777, offset 85, mode 0,
max angle 0, phase 28, exact supported identity bytes, lock 1), continuous signed
native feedback/goals and modulo-4096 display. Factory-only firmware and the
disqualified offset-1328 reference must never be offered for that configuration.
Opening direction is -1; do not ask the owner which button opens it.

Later evidence in [MULTITURN_STARTUP_QUALIFICATION.md](MULTITURN_STARTUP_QUALIFICATION.md)
records a November 9 development startup candidate installed with separately
approved exact RAM setup; public USB target now includes that startup capability.
Attached-cover startup, external power-cycle restoration and loaded travel remain
unqualified in that record. Do not assume the last October probe is still the
installed image, or claim that November qualification is complete. This planning
task did not contact the controller.

Additional local bootloader evidence: the existing
`.pio/build/web_control_multiturn_usb/bootloader.bin` is the build-selected
0x1000 input and hashes to
`3d234a7471f67b013686dabd4dee7c1fa915c9928463616a94bc9297acf1abf8`.
The pinned SDK bootloader ELF includes OTA selection/validation and otadata
writer symbols. Combined with the enabled SDK option and recorded physical
pending-image rollback, this supports the pinned bootloader's rollback
capability; it does not identify the bytes currently flashed on any device.
Reverify the exact bootstrap's bootloader and actual VALID fallback on hardware.

Update preflight/transfer/health/recovery must only inspect servo configuration;
they must not restore a profile, change offset, reset native turns or save
calibration. Existing automatic RAM setup is a separate commissioned application
startup behavior: it cannot become an update-side repair action. The first OTA
path must require an already exact native profile and ensure OTA candidate and
fallback startup inspect it without writes. An unexpected factory/partial profile
after restart locks movement for inspected recovery; do not fix it automatically
under update authorization. If retaining cold-start RAM preparation in an
OTA-capable release, isolate it from update startup and obtain separate exact-write
approval/qualification before claiming support. This unresolved integration is a
release blocker, not a reason to silently remove existing safeguards.

## 2. Architecture and externally verified constraints

### Discovery in the browser

Use the local embedded UI for discovery and selection. Fetch published releases
from `https://api.github.com/repos/Kbdavis/Telescope-Cover/releases`, anonymously,
with credentials omitted. No polling task or GitHub JSON/TLS allocation belongs
on the ESP32 for discovery. No shared private GitHub token goes into firmware,
JavaScript, installer, artifacts or logs. The current private repository will not
be anonymously discoverable; report unavailable/access restricted, with manual
release-page guidance. Do not change visibility or treat a 404 as an empty list.
Private evaluation can use fixtures and maintainer downloads outside the product.

The GitHub Releases API lists releases rather than bare tags, supports pagination
and public unauthenticated access. Filter drafts even if future authenticated
tools return them; require a publication timestamp. Do not use `/latest` as the
selection algorithm: compatibility and channel policy require a release list.
GitHub's list order and latest designation are not semantic version order.
[GitHub Releases API](https://docs.github.com/en/rest/releases/releases).

The REST API documents CORS for any origin and exposes ETag, pagination and rate
headers. It does **not establish a CORS contract for every release download
redirect/CDN response**. Asset download documentation permits direct responses
or redirects and identifies `browser_download_url` for browsers.
[GitHub API CORS](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests),
[release asset downloads](https://docs.github.com/en/rest/releases/assets).

A read-only public espressif/esptool API GET with `Origin: http://cover-dev.local`
on the audit date returned `Access-Control-Allow-Origin: *` and exposed ETag,
Link, Retry-After and rate headers. A public release asset HEAD followed 302→200;
neither observed response included Access-Control-Allow-Origin. This is a
third-party endpoint observation, not a project/browser acceptance test. Python's
default local CA store failed that preliminary HTTPS probe; system curl worked
with normal verification. No TLS verification was disabled. Do not extrapolate
HEAD behavior to all GETs or persist expiring CDN redirect URLs.

Consequently, navigation/download links are the reliable initial fallback;
script-readable metadata/assets need real browser GET/preflight/redirect tests
from the local HTTP hostname and IP. `no-cors` yields an unreadable response and
is not a solution. Credential stripping and redirect CORS rules must be respected.
[Fetch redirect standard](https://fetch.spec.whatwg.org/#http-redirect-fetch).

For compatibility metadata, recommend a bounded, generated public catalog on
the planned HTTPS project hosting, with explicit CORS for credential-free reads.
It mirrors only **published, approved** releases, identifies GitHub release/asset
IDs and immutable hashes, and is signed before OTA use. Require intersection
with the published GitHub list so drafts/removed releases are not offered from
an old mirror. Catalog deployment is a separately authorized publication action.
Until an accessible catalog or per-release manifest path exists, show release
notes with **Compatibility unknown — installation unavailable**. Never infer
compatibility from a title, Markdown keyword or successful source ZIP download.

### Polling, caching and UI contract

- On a visible page, check once if cache is older than 60 minutes; otherwise
  render cached data. Poll hourly with small jitter only while visible. On
  visibility return or network recovery, check once if due; no closed-page
  background service or ESP32 polling. A user may disable automatic checks.
- Use one in-flight request sequence. Cache by repository/API/catalog schema,
  with ETags per page and manifest; store channel preference separately. Share
  same-origin tabs with a bounded leader lease/BroadcastChannel where available.
  Recompute compatibility from the current device snapshot, never from a cached
  device verdict. Different hostname/IP origins cannot share local storage.
- Proposed bounds: 30 releases/page, at most three sequential pages/check,
  1 MiB total decoded release data, 256 KiB signed catalog, 16 KiB notes/release,
  ten-second request timeout. Mark truncated history explicitly; do not say
  “no compatible releases” when older pages are unexamined. Check now can request
  a bounded additional history page after the normal cooldown.
- Use conditional GET/ETag, `304` with a matching cached body only, and honor
  cache/poll headers. Manual **Check now** bypasses the hourly freshness timer
  but not an in-flight request, a 60-second debounce or rate-limit/backoff deadline.
  Anonymous GitHub requests share a 60/hour originating-IP budget; do not assume
  unauthenticated 304s are free. Respect Retry-After/reset when readable; on
  secondary limits wait at least a minute and exponentially back off, capped
  at six hours. If headers are hidden, use conservative fallback delays.
  [GitHub rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api),
  [GitHub request practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api).
- Show installed version/profile/identity; highest compatible version for the
  selected channel; available USB/wireless paths; notes and compatibility reasons;
  last attempt and last successful check times; cache age and next retry.
  Use browser time for discovery, label timezone and reject future/invalid cache
  timestamps after a clock jump. One failure never becomes “up to date”.
- Explicit states: checking, current, compatible update, no published releases,
  no stable releases, only incompatible releases, compatibility unknown, offline,
  rate limited, malformed metadata, access unavailable, stale and incomplete list.
  Proposed cache becomes stale at 24 hours. Stale results remain visibly dated;
  never enable installation from them. Revalidate selection immediately before
  confirmation, then freeze its authenticated identity/hash for the transaction.
- Footer link sits beside installed version and says **Update available** only
  for a newer compatible release in the selected channel. Click opens
  Configuration → Firmware updates, with keyboard focus and navigation/dropdown
  support. Keep installed version visible through errors. A cached notification
  must carry a stale qualifier. Development builds show “Releases available —
  development build installed” instead of asserting a newer official build.
- Stable is default, even on beta firmware. Explicit **Include beta releases**
  enables approved alpha/beta/RC prereleases with visible labels. No stable
  release means an honest empty stable state, not silent beta opt-in.
  Pipeline tests, unqualified experiments, withdrawn versions and missing
  compatibility metadata remain unselectable even when betas are enabled.
- Render notes as bounded plain text initially; no remote HTML/script execution.
  Allow only validated HTTPS links to expected project locations. Cache contains
  no credentials, controller secrets, calibration or device backups.

### Download and transfer choices

| Option | Benefits | Costs and disposition |
| --- | --- | --- |
| Browser discovery → release/USB installer link | Minimal device footprint; independent of OTA; normal navigation avoids script-readable binary CORS requirement | **First delivery.** Explicit erase warning and current qualified USB scope. Existing installed pages need a firmware installation to gain the new UI. |
| Browser downloads app → same-origin bounded chunks to ESP32 | Keeps GitHub TLS off controller; familiar progress UI | **Recommended first integrated wireless transport**, with manual signed-package file selection as a CORS fallback. Needs bounded authenticated chunk endpoints/worker adapter and cancellation. Page/tab loss aborts. The existing parser can carry bounded encoded chunks, not a complete image. |
| Browser chooses release → ESP32 pulls GitHub HTTPS | Browser can close after submission; avoids binary CORS in browser | Defer until measured: TLS handshake/cert chains, time trust, redirects, certificate maintenance, memory/stack and worker scheduling are new burdens. Restrict source/redirect destinations, never accept arbitrary URLs or forward device/GitHub credentials. |
| Desktop helper downloads/verifies then existing espota push | Reuses tested framing and transaction workflow; avoids asset CORS and browser sockets | Useful optional recovery/maintainer path after production adaptation. Not a browser implementation, requires local software/reverse TCP/firewall acceptance. Current development secret/path must not be shipped. |
| Hosted HTTPS updater → local HTTP controller | Central hosting and easy release assets | Defer: mixed-content/local-network permissions and cross-origin authorization complicate browsers. Do not weaken local endpoint origin checks or expose an unauthenticated bridge to make it work. |

Use an application-only inactive-slot writer behind the existing maintenance
owner and transaction engine. For browser push, propose at most 1 KiB chunks,
one bounded producer queue, explicit backpressure, transaction/offset checking,
incremental hash and worker-owned SDK calls. Phase-1 review below selects bounded
form-encoded chunk requests for the first implementation, avoiding a new large
binary request parser. No whole-image ESP32 buffer, global request-limit increase,
multipart buffering or `Update` calls from web handlers. Stage/download in browser before acquiring
maintenance; acquire exclusive clearance only for the actual update transaction.
An explicit install request and confirmation are required before admission/flash.
Read-only polling never downloads a complete image or reserves maintenance.

ESP-IDF 4.4.7 offers TLS server validation and HTTPS OTA, including redirect
handling and partial downloads. TLS buffers and certificate handling must be
measured with the pinned Arduino package: documented buffer reductions are not
proof that this precompiled SDK has a smaller buffer configuration. Never use
insecure TLS or assume a second core eliminates flash stalls.
[Matching ESP-TLS documentation](https://docs.espressif.com/projects/esp-idf/en/v4.4.7/esp32/api-reference/protocols/esp_tls.html),
[matching HTTPS OTA documentation](https://docs.espressif.com/projects/esp-idf/en/v4.4.7/esp32/api-reference/system/esp_https_ota.html).

## 3. Artifact, compatibility and trust contract

Define a versioned bounded schema before UI installation controls. Keep legacy
USB manifests readable by their existing installer; introduce a distinct signed
update manifest/envelope and catalog rather than changing their meaning.

| Contract field | Required meaning |
| --- | --- |
| Identity | Product, normalized release version, channel, exact source commit, firmware ELF/build identity, GitHub release/tag/asset IDs and published status. Validate agreement with embedded binary identity; `target_commitish` alone is insufficient. |
| Artifact | Explicit `factory-install` versus `application-ota`, exact length/SHA-256, name, permitted source URL, content format and signature binding. Do not accept a ZIP, merged image or source archive as an app. |
| Hardware/layout | Board family and qualified revisions, ESP32 chip constraints, 4 MB flash, pinned partition-layout ID/hash, slot size `0x140000` (1,310,720 bytes), minimum bootloader capability/version and current OTA protocol. Unknown is not compatible. |
| Servo/motion | Explicit native signed multi-turn capability, exact profile ID/digest derived from supported 40 bytes plus lock requirements, offset/reference basis, calibration direction/arc semantics and startup policy. Runtime read-only verification must match; firmware filename alone is insufficient. |
| Settings and fallback | Separate calibration schema (currently v5), application-record compatibility, network settings, transaction/handoff schema (currently 1), authentication storage and migration policies. List tested source release/profile ranges and fallback readers/writers, not just one generic “settings=5”. |
| Qualification | Supported installation paths, acceptance record/hashed artifact linkage, supervised-prototype limitations, withdrawals, known faults and explicit USB/bootstrap requirement. Current `publication_allowed:false`/pipeline-test metadata cannot become an eligible update. |
| Trust/freshness | Signing key ID, signature algorithm/envelope, catalog sequence/expiry policy, supported key rotation/revocation, authenticated release withdrawal and metadata size limits. Unknown key/schema/critical field fails closed. |

`factory.bin` is a complete initial-install image starting at **0x0**, assembled
from bootloader at 0x1000, partitions at 0x8000, boot-selection data at 0xe000 and
app0 at 0x10000. Current USB flow erases settings. OTA artifact is **only the
application**, written to the inactive slot; it never includes bootloader,
partitions, otadata initialization, NVS or filesystem. Embedded UI travels with
the application. A partition/bootloader change requires a separately qualified
USB migration, not an OTA exception.

Use Semantic Versioning precedence, with an optional leading `v` on tags only:
numeric components, stable above prerelease, numeric prerelease identifiers
compared numerically (`beta.10 > beta.2`), build metadata ignored for ordering.
Enforce release/tag/channel agreement. Current build syntax can remain narrower
than the comparator but reject malformed inputs. Equal version/different
identity is a conflict, not an update. Dirty/dev/unversioned builds are not
official release baselines, even when their numeric prefix is larger; offer
review of a supported release only through an explicit supported transition or
destructive USB installation. [SemVer specification](https://semver.org/spec/v2.0.0.html).

Only newer, tested compatible transitions are installable normally. Older
versions can have read-only notes; no arbitrary downgrade picker. Automatic
bootloader fallback is a different operation and must target the immediately
previous verified image with compatible settings/journal/profile behavior.
Do not use publication time, lexicographic strings or ESP32 `secure_version` as
the user-version comparator. No eFuse anti-rollback changes are proposed.

### Publisher trust is separate from authorization and integrity

SHA256SUMS, image SHA-256, ESP image checksum, ELF hash and espota MD5 cannot
prove who authorized a release. A checksum served beside a malicious image can
be replaced with it. GitHub HTTPS authenticates the service, not an independent
project signing authority. A tag signature or CI attestation is useful provenance
but insufficient unless the actual consumer verifies its binding to the bytes.

Recommend a detached signature over exact manifest bytes (avoid ambiguous JSON
canonicalization), containing the full application hash and all compatibility
constraints. Use a vetted algorithm/library already supportable by pinned
mbedTLS, provisionally ECDSA P-256/SHA-256, with explicit encoding and fixed test
vectors. Pin public keys in the USB bootstrap firmware; keep private signing
keys outside repository/artifacts and in a protected signing process. ESP32
must verify the signature and the streamed artifact hash **before boot selection**,
even when the browser/helper already verified them. Enforce signed compatibility
before erase; do not treat browser-supplied booleans as evidence. Unknown/revoked
keys or a mismatched digest cannot activate an image. Review key rotation,
compromise recovery and catalog replay policy before shipping.

IDF also supports signed-app checking without hardware secure boot. Assess it
against the custom envelope: enabling framework signing may require rebuilding
the Arduino SDK, and current image inspector rejects extra signature trailers.
Do not assume configuration macros activate a feature in precompiled libraries.
Hardware secure boot/flash encryption would alter provisioning and USB recovery;
defer those irreversible choices to separate authorization. Detached verification
protects the supported update entry point, not physical flash access or a
compromised running application.
[ESP32 signed-app options](https://docs.espressif.com/projects/esp-idf/en/v4.4.7/esp32/security/secure-boot.html).

Public release authenticity and permission to update one controller are distinct.
Replace compiled shared/private development secrets with unique device credentials
provisioned locally after USB install. Define rotation/reset/recovery, rate limits,
boot-bound nonces, single-use confirmation, expiry and transaction binding to the
exact signed image/source identity. Pairing must not use a universal default
password. A normal UI session token is not update authorization. Require trusted
LAN/STA, strict origin/host/session checks, CSRF protection and no setup-AP upload.
Document that the current HTTP UI is not confidential or protected against an
active LAN attacker changing delivered JavaScript; do not claim signatures solve
credential theft or hostile local commands. Phase 1 must approve the LAN threat
model or select a stronger transport before production integration.

WebCrypto is a secure-context API: local `http://cover.local`/LAN IP must not be
assumed to have `crypto.subtle`. Browser verification is advisory; require device
verification, and feature-detect browser capabilities or use a reviewed bundled
implementation. The HTTPS USB installer has a different context.
[WebCrypto secure-context requirement](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto).

## 4. Exact first production maintenance policy

Use a deliberately narrower first policy than existing development recovery or
ordinary torque-ON admission. No retained-torque update or supervised-hold
takeover in this milestone.

| State/evidence | First production wireless admission |
| --- | --- |
| CLOSED | Eligible only with clean saved compatible calibration, valid exact native profile, fresh model/configuration/position reads, stable native position near the taught CLOSED endpoint and fresh torque OFF. Encoder CLOSED is not proof of physical closure; owner confirms independently supported safe mechanism, stowed telescope/path and recovery access. Use physical closed sensor if installed; contradiction blocks. |
| OPEN, STOPPED, UNKNOWN, FAULT, uncalibrated/review-required | Discovery and USB guidance remain available; production wireless installation disabled. Separate development recovery policy remains private. Do not fabricate CLOSED or calibration to obtain admission. |
| OPENING, CLOSING, any jog/teaching/test/operation, supervised holding/torque test | Reject before reserving transfer or writing flash. UI eligibility is advisory; worker rechecks atomically. |
| Torque ON, unknown or stale | Reject. No implicit release, no prompt that combines installation with Stop/close. Owner must independently support and explicitly Stop/release through the existing control flow, then request update again. |
| Another maintenance owner, dirty settings, stale generation, emergency reservation, startup pending, AP/AP+STA/setup active | Reject. Do not steal a lease, clear faults or suspend safety supervision to make progress. |

The CLOSED/OFF restriction follows current production position policy, avoids
unqualified load retention through reboot and limits the first hardware matrix.
It is not automatically suitable for a cover that falls when torque is removed:
that installation must stay on USB with mechanical support until a separately
designed maintenance policy is commissioned. Never close automatically to make
an update eligible.

Retain existing owner/generation fencing, required worker pause acknowledgment,
three-second preparation timeout, periodic validation (currently 500 ms) and
1,500 ms maximum clearance age. Add native position/speed/moving-flag evidence
so modulo-equivalent positions a turn apart cannot pass stationary checks.
Retries may reject bad samples; failed reads never establish clearance. Measure
these timing bounds through flash; do not relax them without new evidence.

After confirmation, reserve OTA maintenance atomically, drain/fence queued work,
pause telescope workers and invalidate cached stow evidence. Deny motion,
settings/calibration saves, network setup/reconnect, reboot, other writers and
bulk diagnostic allocation throughout the lease. Keep bounded status, explicit
Stop and authenticated cancel. Stop revokes clearance; precommit cancellation
aborts transfer without selecting the target. Serialize final cancel/clearance,
verified hash/signature and durable intent before boot selection. At/after commit,
report “too late/awaiting startup” or “unconfirmed” rather than claiming rollback.

Only the matching OTA owner acknowledges transport/SDK cleanup and requests
release. Require fresh stationary torque-OFF evidence before unlocking; retain
the lock if uncertain. Network loss must not prevent cleanup once hardware is
safe, nor expose a fallback AP while transport still owns flash. No retry,
command replay or motion resume after abort/reboot. New manual authorization and
fresh telescope evidence are required for later motion.

## 5. Staged execution and gates

Every phase produces a short evidence ledger: source/artifact identity, checks
run and results, unresolved items, decision owner and gate outcome. Code changes
stay uncommitted unless separately requested. Passing one phase never authorizes
hardware or publication in another. An objective gate can be evaluated by tests;
an owner gate requires an actual decision. Hardware and publication gates always
need explicit scope-specific authorization.

### Phase 1 — Freeze requirements and architecture decisions

**Objective/deliverables:** Recheck this audit against current source; produce
ADRs for discovery/catalog hosting, browser binary transport, device credentials,
publisher trust/key lifecycle, exact CLOSED/OFF policy and startup profile
behavior. Map existing functions/tests to reuse and record capability/API schema.
Choose quantified hardware measurement targets before experiments.

**Dependencies/decisions:** This plan; owner decisions listed below; no hardware
required to prepare design. Keep USB-only delivery viable even if OTA decisions
remain unresolved.

**Acceptance/tests:** Source references resolve; sample compatible/incompatible
transition tables cover factory/native, v5 calibration, legacy app records and
dev identities; primary-document constraints and offline parser design are
recorded. Documentation/fixture review only; hardware evidence is not claimed.

**Blockers/go-no-go:** Go to phase 2 when owner accepts trust, maintenance and
profile decisions. Discovery-only requirements may be approved separately from
OTA. Missing owner security decisions block OTA design, not read-only audit.
**Gate:** objective audit plus owner architecture decision.

**Execution prompt:**

> Execute only phase 1 of docs/FIRMWARE_UPDATE_PLAN.md. Reinspect current source
> and documentation, write concrete ADRs/capability and compatibility contracts,
> and identify owner decisions and missing hardware evidence. Recommend choices
> and prepare the next gate; do not implement firmware/UI/tooling, access hardware,
> change servo registers, commit, push, tag, publish or change GitHub settings.

### Phase 2 — Metadata, compatibility, version and trust primitives

**Objective/deliverables:** Implement bounded update manifest/catalog schema and
validators, pure version/compatibility logic, capability reporting and fixtures.
Define signed exact-byte envelope, offline signer/verifier, public-key format,
rotation/revocation contract and matching device verification tests. Extend
release identity tooling only for explicitly identified production profiles;
retain development/USB distinctions. Do not enable transfer.

**Dependencies/decisions:** Phase 1 for the applicable scope; real production key
custody is an owner decision. Test keys must be clearly nonproduction and excluded
from publishable builds. Discovery fixtures may precede production signing.

**Acceptance/tests:** Numeric prereleases, build metadata, dirty/dev/unknown and
equal-version identity conflicts; mismatched tag/channel; duplicate/unknown
critical fields, oversized metadata, bad signature, wrong key, altered signed
constraints, rollback schema and factory/native mismatches all tested. Cross-check
device/JS/Python decisions using shared vectors. No hardware evidence required.

**Blockers/go-no-go:** No permissive unknown defaults or broadened legacy image
parser. Production signing strategy/capability blockers keep OTA disabled.
**Gate:** objective tests and owner approval of trust-root lifecycle before a
production trust root is provisioned; phase 3 discovery can use labeled fixtures.

**Execution prompt:**

> Execute only phase 2 of docs/FIRMWARE_UPDATE_PLAN.md using the accepted phase-1
> decisions. Implement and test metadata, version/compatibility and offline trust
> primitives plus read-only capability reporting. Preserve all existing upload
> gates. Use test keys only; never read or distribute development credentials.
> No hardware, servo writes, commit, push, tags, hosting or publication.

### Phase 3 — Read-only discovery and USB-first selection

**Objective/deliverables:** New discovery module, cache/rate scheduler, footer
notification and Configuration → Firmware updates. Show notes, versions,
compatibility and error states; stable default with explicit beta option. Provide
version-specific release/qualified installer links and clear destructive USB
guidance. No wireless Install control. Add public catalog generation/previews
without deploying hosting.

**Dependencies/decisions:** Read-only phase-2 contract; no production receiver,
signing private key or hardware required for fixture-based UI completion. Public
metadata access requires separately authorized hosting/repository availability.

**Acceptance/tests:** Fake clock/network/cache tests for all discovery rows in
the matrix below; real browser navigation/focus tests, storage denied and multiple
tabs. CORS test from an ordinary local HTTP origin to public API; separately test
actual metadata GET path. No unexpected controller mutation/lease/firmware fetch
on poll, click or release selection. Existing About/version tests stay green.
Hardware: none for UI logic; deployment of embedded UI to any controller is a
separate authorized action and requires its real profile admission.

**Blockers/go-no-go:** Do not label unknown or pipeline-test releases compatible;
do not show stable “current” on offline/404/rate limits. No CORS workaround
proxy/token. **Gate:** objective software/browser checks release this as the
smallest useful delivery; owner decides whether to distribute it through the
existing USB release process. This gate does not open OTA.

**Execution prompt:**

> Execute only phase 3 of docs/FIRMWARE_UPDATE_PLAN.md. Implement read-only
> release discovery, bounded caching/polling, footer navigation and release
> selection with explicit beta opt-in and USB guidance. Test browser failures,
> compatibility and absence of device mutations. Use fixtures where public
> metadata is unavailable. Do not add/enable wireless installation, contact
> hardware, commit, push, tag, deploy hosting, publish or change GitHub settings.

### Phase 4 — Startup, settings and recoverable bootstrap foundation

**Objective/deliverables:** Specify and implement production bootstrap/candidate/
fallback health contract and durable outcome compatibility. Gate all motion
during validation. Add explicit settings compatibility checks to existing
readability checks; preserve calibration/reference review state. Define fallback
and USB recovery UI/log outcomes. Require prior accepted valid app before OTA
admission; report missing rollback capability explicitly.

**Dependencies/decisions:** Phases 1–2 OTA decisions; measured historical recovery
is reusable background, not current acceptance. Keep current layout. No irreversible
migration on first boot: preserve old bytes or copy-on-write records so both
images can read them. Confirm authentication storage remains usable by fallback.

**Acceptance/tests:** Fault injection for absent/corrupt/torn journal, missing/
invalid/unsupported application settings, calibration v1–v5 and offset-1328
review evidence, mismatched transaction/ELF/slots, unknown bootloader, failed
service/task/allocation, AP fallback and watchdog deadlines. Unsupported settings
must not be overwritten with defaults or erase evidence. Healthy software with
missing servo/telescope locks motion without endless rollback. Device startup
tests assert no goal, torque-enable or profile-write calls in OTA startup.
Hardware: actual pending states, watchdog reset and bootloader behavior remain
phase 7, not simulated-test conclusions.

**Blockers/go-no-go:** A fallback cannot read candidate settings/journal, startup
accepts too early, firmware repairs profile, or no reset path for a startup hang.
**Gate:** objective offline recovery contract/tests; hardware gate remains closed.

**Execution prompt:**

> Execute only phase 4 of docs/FIRMWARE_UPDATE_PLAN.md. Implement/test production
> startup acceptance, settings/fallback compatibility and durable outcome logic
> without enabling OTA transfer. Preserve old settings and review evidence;
> prevent update startup from moving or programming the servo. Prepare hardware
> validation requirements. No hardware operations, register writes, commit, push,
> tags, publication or GitHub settings changes.

### Phase 5 — Production authorization, bounded transfer and maintenance

**Objective/deliverables:** Separate multi-turn-aware production receiver profile,
unique-device authorization/pairing, explicit release selection → review →
confirm transaction UI, isolated streaming adapter and existing worker/journal
integration. Receiver revalidates signed compatibility/hash, current profile,
source identity and permitted newer transition; no UI-only admission. Report
receiving, verified, activating, reconnecting, accepted, failed, rolled back and
unconfirmed separately. Keep production defaults disabled pending hardware gate.

**Dependencies/decisions:** Phases 2 and 4; phase 3 for integrated UI. Approved
LAN threat model, auth provisioning and startup RAM-policy resolution. Existing
desktop dev uploader remains private; optional production adaptation is separately
named and must accept signed multi-turn artifacts without using dev credentials.

**Acceptance/tests:** End-to-end mocked browser/worker transfer, signing/hash
failure, exact offset/length/backpressure, insufficient memory, command/Stop/
cancel races, stale nonce/generation, duplicate chunks, auth replay, hostile
origin, lost client and cleanup faults. Assert no servo configuration/goal writes,
no implicit torque release, no admission during holding, torque ON, fault or
unknown. Measure static app/queue/stack bounds offline; hardware reserve and
flash latency remain pending. No automatic install/retry/reboot outside confirmed
transaction. A browser reconnection must match boot, ELF and durable transaction.

**Blockers/go-no-go:** Any bypass of device-side authorization, signed policy,
exclusive writer or OFF/maintenance checks. No guessed production memory floors.
**Gate:** objective offline checks and owner review of auth/UI; experimental
hardware use requires separate phase-7 authorization. Production install stays
disabled in distributed defaults.

**Execution prompt:**

> Execute only phase 5 of docs/FIRMWARE_UPDATE_PLAN.md using approved architecture
> and startup contracts. Implement the separately gated multi-turn production
> authorization/streaming path, explicit confirmation UI and maintenance
> integration. Run meaningful offline race/failure/security tests. Keep public
> installation disabled pending hardware evidence; do not reuse private dev
> secrets. No hardware, servo writes, commit, push, tags, hosting or publication.

### Phase 6 — Release packaging and automated candidate gates

**Objective/deliverables:** Extend isolated packaging to generate distinct USB
bootstrap and application-only signed update packages from a frozen commit, with
identical intended application bytes/identity where applicable. Include schema,
key IDs, dependencies, compatibility transitions, source evidence, notices,
acceptance placeholders and catalog preview. Extend `validate_release.py` and
manual CI to run update/version/browser/startup/maintenance/parser/signing tests
currently outside its selected suites. Keep signing/promotion separate from
untrusted PR workflows and compilation.

**Dependencies/decisions:** Phase 2 suffices for discovery-only packaging; phases
4–5 for OTA packaging. Owner chooses production signing custody and retention.
Exact candidate freeze is explicit; this phase does not grant commit/push rights.

**Acceptance/tests:** Unpack and independently validate every output, compare
binary identity against manifest, descriptor/layout/slot capacity, clean-source
provenance, public allowlists and sanitized canary-secret scans. Reject development,
probe, factory-only-for-native, dirty, test-key and pipeline-test artifacts from
OTA eligibility. Verify factory/app type confusion fails before erase; signed
envelope size/trailers pass compatible inspectors. Negative publication checks
must reject pending hardware/license status. Private keys never enter artifacts
or logs. Existing destructive installer tests pass unchanged.

**Blockers/go-no-go:** Dependencies/license clearance incomplete for public
distribution, mismatched signer/package bytes, missing recovery artifact or
unstated settings behavior. **Gate:** objective package/CI gates permit a frozen
unpublished candidate; hardware and publication are separate owner gates.

**Execution prompt:**

> Execute only phase 6 of docs/FIRMWARE_UPDATE_PLAN.md. Extend isolated packaging
> and offline/CI checks for distinct bootstrap and app-only update artifacts and
> signed metadata using authorized key handling. Prepare an unpublished candidate
> and catalog preview from an explicitly selected frozen commit; if none is
> selected, stop at tooling/tests and report that dependency. Never commit, push,
> tag, flash, publish, deploy hosting or change GitHub settings.

### Phase 7 — Supervised hardware acceptance of exact artifacts

**Objective/deliverables:** Prepare a hashed test procedure and evidence ledger
for spare supported hardware, detached arm, independent support, safe power
control and USB access. Separate destructive tests from later loaded mechanism
acceptance. Verify actual device bootloader digest/configuration, partition table,
flash size, valid fallback and exact profile using approved read methods; USB
connections can reset hardware, so they need authorization too.

**Dependencies/decisions:** Phase-6 exact artifacts and phases 4–5 offline gates;
owner explicitly authorizes each hardware session, installation, reset/power cut
and any distinct movement test. Servo programming is not part of update acceptance.
If testing preexisting cold-start profile setup requires writes, prepare a
separate exact-register proposal and wait for approval; never bundle it here.

**Acceptance/tests:** Execute hardware rows below with source/target hashes,
native/physical observations, measured heap/largest block/task stack, web/Stop
latency and durable outcomes. A→B→A covers both slots; acceptance needs new boot
and exact target identity plus health/journal result. Verify old settings and
fallback authentication, startup no-motion/no-profile-write behavior, failed boot
rollback and watchdog reset without host rescue. Confirm current public-browser
USB recovery and explicit settings-loss disclosure. Establish justified production
reserves under worst supported telemetry/UI/log/signature/transfer workload,
including allocation failure and fragmentation; do not transplant dev floors.

**Blockers/go-no-go:** Any unexpected motion/torque/profile write, failed rollback,
uncertain power cut, identity mismatch, memory/latency bound violation or unsupported
settings. Preserve evidence, stop, return to phase 4/5/6 and freeze a new candidate;
do not repeat blindly or rebuild under the old evidence. **Gate:** explicit
hardware authorization, objective measured acceptance and owner acceptance of
scope/remaining limitations. No publication follows automatically.

**Execution prompt:**

> Execute only phase 7 preparation in docs/FIRMWARE_UPDATE_PLAN.md for candidate
> <VERSION>, commit <COMMIT>, artifact hashes <HASHES>. Review offline gates and
> produce a concrete spare-hardware procedure with exact installs, resets,
> power-cut windows, recovery and measurement bounds. Perform hardware actions
> only within my subsequent explicit session authorization. Do not move or
> program the servo, commit, push, tag, publish or change GitHub settings. Report
> no-go conditions without retrying or substituting a new binary.

### Phase 8 — First OTA-capable release and USB bootstrap

**Objective/deliverables:** Choose a new version after the occupied pipeline-test
beta; package an accepted OTA-capable USB bootstrap with trust roots, per-device
credential onboarding, native-profile support, deferred health and rollback.
Document one-time destructive USB installation for existing USB-only users and
the supported first wireless transition. Publish only exact accepted artifacts
through separately approved release steps. Retain current USB recovery.

**Dependencies/decisions:** Phase 7, dependency/license and advertised-browser
clearance, owner selection of audience/version/channel and explicit release/
hosting authorization. Public discovery may ship earlier through phases 1–3/6
and the existing USB release gates; it does not need this OTA milestone.

**Acceptance/tests:** Verify approved package equals hardware-tested bytes and
signed metadata, release/tag/prerelease agreement, links/access/CORS/catalog
intersection and downloaded hashes. On separately authorized spare hardware,
install bootstrap over USB, provision unique credentials, verify accepted valid
baseline and perform its first supported app OTA. USB-only firmware must clearly
show “USB installation required to enable wireless updates”; it cannot receive
the receiver over a nonexistent OTA path. Private development receiver bootstrap
remains a separate supervised workflow, not public installation advice.

**Blockers/go-no-go:** No qualified bootstrap/first transition, public access not
approved, changed bytes, missing key custody or incomplete licenses. Clean USB
erase may leave only one valid application; make it valid before the first update
and never promise an immutable rescue slot. **Gate:** owner release decision and
explicit per-step tag/push/draft/hosting/publication authorization after review.

**Execution prompt:**

> Execute only phase 8 release preparation of docs/FIRMWARE_UPDATE_PLAN.md for
> <VERSION>/<COMMIT>/<HASHES>. Verify hardware and licensing evidence, prepare
> exact release notes/assets/catalog and one-time USB bootstrap instructions,
> and report a concrete go/no-go decision. Do not rebuild accepted bytes or
> operate hardware. Tagging, pushing, hosting deployment, repository visibility
> changes and publication require my separate explicit instructions; stop at
> reviewable preparation until those instructions arrive.

### Phase 9 — Later release promotion and continued recovery qualification

**Objective/deliverables:** A repeatable signed release process with explicit
tested source→target and fallback compatibility. Freeze, test, supervise,
prepare draft, review and promote the same bytes. Retain source/tool inputs,
ELF/map, bootloader identity, signed metadata and sanitized hardware evidence
beyond the existing 30-day CI retention. Provide signed withdrawal/recovery
guidance; never replace published assets or move tags.

**Dependencies/decisions:** Accepted bootstrap and first OTA path. Re-run relevant
hardware gates on memory/task/driver/settings/auth/boot changes; stable promotion
requires owner approval of support claims. More permissive recovery states,
retained torque or HTTPS device pull are future independent commissioning work.

**Acceptance/tests:** Full contract regression plus representative exact-artifact
OTA/rollback/settings/USB recovery evidence for every advertised transition.
Verified revoked key/withdrawn release behavior and staged channel promotion.
No silent reinstall, downgrade, upgrade during holding or auto-update. Older
schema/bootloader/profile devices are directed to an explicit compatible USB path.

**Blockers/go-no-go:** Untested source/fallback pair, irreversible migration,
failed trust checks, uncertain rollback or artifact/evidence drift. **Gate:**
objective regression/evidence and owner approval; each hardware/publication
operation needs its explicit scope. Beta eligibility never implies stable approval.

**Execution prompt:**

> Execute only phase 9 preparation in docs/FIRMWARE_UPDATE_PLAN.md for proposed
> <SOURCE_RELEASE> → <TARGET_RELEASE>. Audit signed compatibility, fallback and
> exact-artifact evidence, prepare candidate validation and promotion records,
> and identify any required return to earlier gates. Do not commit, push, tag,
> flash, change servo registers, deploy hosting, publish or alter GitHub settings
> without separately scoped explicit authorization.

## 6. Test matrix

Software tests below are necessary but never substitute for the hardware column.
An empty hardware column requirement means the case can be established offline;
it does not waive hardware acceptance of the feature as a whole.

| Case | Automated acceptance | Separate physical/browser evidence |
| --- | --- | --- |
| Empty releases / stable empty / beta opt-in | Distinguish HTTP 200 empty, prerelease-only, drafts and pipeline tests; default never selects beta | Browser renders/focuses correct states; no controller operation |
| Rate limits / pagination | 403/429, Retry-After/reset, missing headers, ETag/304 without body, bounded pages and incomplete list; Check now cannot bypass limits | Real local-origin API/preflight headers; multiple tabs behind one IP |
| Offline/private/unavailable | Network timeout, DNS/CORS/404 and malformed payload have distinct useful messages; normal controls unaffected | Browser without internet, controller reachable on LAN/AP; no indefinite spinner |
| Stale/replayed catalog | Age/clock-jump handling, bad sequence/expiry, revoked/withdrawn entry, published-list mismatch; no stale install | Validate actual hosting caches/redirects; no inferred fresh result from local cache |
| Version ordering | beta.2/10, rc/stable, differing cores, +metadata, dirty/dev/unknown, equal-version different hash, old versions | None beyond UI integration |
| Wrong hardware/layout/profile | Missing capability, factory/native mismatch, offset1328, exact-byte mismatch, wrong flash/chip/slot/protocol | Read actual board/layout/native profile without rewriting; reject mismatched package before erase |
| Settings/fallback incompatibility | Legacy valid, invalid, unsupported, torn, calibration reference/direction and record migration vectors | Seed representative supported records; verify source/candidate/fallback, Wi-Fi and teaching remain readable; no claim for untested pairs |
| Tampered artifact/metadata | Modified hash/signature/key/size/constraints, stale auth nonce, wrong transaction, image/ZIP/factory confusion fail | Device rejects exact corrupt streams without selection; running image unaffected |
| Insufficient memory/storage | Admission zero/low floors, allocation failures, queue exhaustion, slot overflow, cleanup retained | Worst workload free internal heap/largest block/stack minima and flash stalls; no threshold lowering to pass |
| Concurrent commands/holds | OPEN/CLOSE/jog/teach/torque/settings/network/reboot, old clients/generations, Stop/cancel races | Detached stationary attempts show zero actuator commands after admission; reject active motion/holding without interrupting supervision |
| Transfer interrupted | Duplicate/wrong offset, truncation, no progress, browser closes, lost Wi-Fi, cancel before commit, retry with fresh auth | Interrupt at early/middle/final transfer, verify unchanged boot selection and safe cleanup, same-boot retry where supported |
| Commit uncertainty | Stop/timeout at verification/intent/selection; durable result never fabricated | Measure commit/Stop timing and selection evidence; postcommit UI waits for actual result |
| Power loss | Fault-injected torn checkpoints, reboot reconciliation, journal corruption | Controlled actual sole-supply cuts during receiving, verified-before-intent, inside journal write, selection write and pending first boot; distinguish USB-only removal from true power loss |
| Failed startup/hang | Services/settings/task failures, pending reset, watchdog deadline and recovery-required without fallback | Digest-match bootloader; A→B→A, pending reset, autonomous hangs before/during setup, actual invalid/aborted/valid metadata and native feedback/torque observations |
| Accepted image later fails | Do not promise automatic rollback of already VALID firmware; diagnostics and USB recovery path | Recover accepted broken network/UI image through tested USB route with independently supported mechanism |
| Recovery/bootstrap | No receiver means USB bootstrap; bad/absent rollback slot blocks OTA; explicit erase disclosure | Spare board clean/vendor/compatible/mismatched/unreadable USB cases, interrupted flash, onboarding, actual healthy startup |

Use the matching IDF recovery model: a pending image can fall back on reset with
a rollback-enabled bootloader and a usable previous app. Once accepted VALID,
later faults do not automatically unaccept it. There is no immutable factory
recovery application in this layout. Verify actual bootloader bytes and slot
state for each supported bootstrap rather than inferring behavior from dual
slots or local SDK macros.
[IDF 4.4.7 rollback contract](https://docs.espressif.com/projects/esp-idf/en/v4.4.7/esp32/api-reference/system/ota.html#app-rollback).

## 7. Relative effort, critical path and owner decisions

Indicative focused engineering effort, excluding review turnaround, hardware
availability and release/licensing work; refine after phase 1:

| Work | Relative size / rough effort |
| --- | --- |
| Phase 1 audit/ADRs | Small, 0.5–1.5 days |
| Phase 2 metadata/compatibility/trust foundations | Medium, 2–4 days; trust review/key setup may extend it |
| Phase 3 discovery/selection/USB fallback | Medium, 1–3 days after metadata; smallest delivery roughly 4–8 days total depending on trust scope |
| Phase 4 settings/startup reconciliation | Medium/high, 2–4 days |
| Phase 5 new browser transfer/auth/maintenance | High, 4–7 days; parser/security and concurrency dominate |
| Phase 6 packaging/CI | Medium, 1–3 days, reusable for discovery-only release |
| Phase 7 supervised acceptance | High uncertainty, several bench sessions / 3–6+ days plus fixes |
| Phase 8 first release/bootstrap | 1–2 days preparation plus approval/qualification calendar time |
| Phase 9 later promotion | Usually 0.5–2 days per compatible release plus required bench sessions; schema/boot/auth changes reopen earlier work |

Production wireless is a multi-week effort, not a footer enhancement. Critical
path: owner trust/maintenance/profile decisions → signed compatibility contract →
settings/fallback/startup → production authorization/streaming → exact candidate
→ actual bootloader/memory/failure/USB evidence → separately approved bootstrap
publication. Discovery UI and catalog/USB packaging can advance independently
once their own contract is settled. No framework migration is currently justified.

Only these decisions/evidence require the owner or unavailable external hardware:

1. Approve the proposed independent discovery delivery and, for first production
   OTA, supported CLOSED plus verified torque OFF only. If the installed mechanism
   cannot be independently supported in that state, retain USB-only updates;
   specify an alternative commissioning project rather than weakening admission.
2. Approve the trusted-LAN authorization threat model versus requiring confidential
   local transport; choose unique-device pairing/recovery ownership and publisher
   signing-key custody/rotation. Recommend detached device-verified manifests,
   reviewed P-256 implementation and protected signing separate from PR builds.
3. Approve resolution of automatic RAM startup setup versus update no-write policy:
   recommend existing-native-only OTA startup with no writes, and separately
   commissioned cold-start preparation. Evidence for external servo power-cycle,
   attached startup and full loaded travel is still missing from repository records.
4. Provide spare supported hardware, independent mechanical support, actual
   bootloader/slot/profile evidence, controlled power interruption and supervised
   session authorization when phase 7 is ready. Do not infer live state from old
   diagnostics or contact hardware during planning.
5. At release time choose the new version/channel and explicitly authorize
   audience/hosting/publication. Existing decisions already select GitHub
   Releases/Pages, the multi-turn supervised beta and macOS qualification first;
   do not ask those questions again without a changed requirement. Private
   pipeline-test publication is not authorization to make the repository public.

## 8. Next action

Phase-1 review, offline compatibility/signing prototypes and local read-only
discovery UI are implemented; see sections 10–11. Production trust/capability
integration uses the accepted owner decisions in section 12, followed by
exact-artifact hardware qualification. No production installation or deployment
is authorized by the local test results.
Keep production wireless gated until multi-turn descriptor/startup integration,
device credentials, publisher signing, settings/fallback compatibility and exact
hardware memory/rollback/recovery evidence pass. USB-only users will need one
explicit USB bootstrap; an old page cannot acquire a receiver by discovering a
release. Do not reuse the published pipeline-test version for new firmware.

Execution prompt used for the first metadata subset:

> Work in /Users/kirkdavis/src/telescope-cover. Read AGENTS.md and
> docs/FIRMWARE_UPDATE_PLAN.md, including its phase-1 decision record. Execute
> only the phase-2 offline metadata/version/compatibility subset. Implement pure
> validators and shared test vectors, keeping wire schemas explicitly provisional
> where security decisions remain open. Keep existing release and upload gates
> closed. Do not provision real keys/credentials, enable production updates,
> contact hardware, modify servo registers, commit, push, tag, publish, deploy
> hosting or change GitHub settings. Report tests and remaining phase-2 gates.

## 9. Phase-1 decision record and implementation handoff

Status: documentation review completed against the source baseline above and
rechecked local files. No firmware, UI, tools, device, credential or GitHub state
was changed. These are engineering choices for the next implementation increment;
the owner-approved product requirement is distinguished from proposed security
and hardware policies below.

### A. Product flow and delivery boundary

The agreed end state is first USB install → automatic discovery while the local
webpage is open → Update available → release review → explicit Install and
confirmation → download/transfer progress → reboot → reconnect → verified startup
result. No compiler, desktop helper or manual file download is required on the
normal supported wireless path. Optional manual package selection and USB are
recovery alternatives. “Automatic” applies to discovery only.

Confirmation identifies source and target version, channel, compatibility,
settings implications and required maintenance conditions. Revalidate identity
and release eligibility before starting; a changed selection, source firmware or
boot identity invalidates confirmation. A successful upload cannot display
“Update complete” until target identity and accepted startup are confirmed.

Discovery-only UI remains useful and independently testable. If distributed
before the OTA-capable bootstrap, disclose that a further USB install will be
needed; do not market that interim version as “USB once, then wireless.” The
first release making that promise must contain the complete qualified receiver,
trust roots, device authorization, startup and recovery capability.

### B. Discovery and download decision

Keep discovery in embedded browser JavaScript; reuse `/api/session` identity,
footer `sessionNote`, Configuration section navigation and existing About fields.
Use the polling/cache limits in section 2. Keep GitHub access anonymous for the
public product, with no private token provisioned to controllers or pages.

Use a generated, CORS-enabled project-hosted catalog and application download
mirror for the seamless browser path. Mirror bytes must match the immutable
GitHub release assets exactly and remain covered by the same signed manifest.
Discovery intersects catalog entries with the published GitHub release list.
Publish the GitHub release first; publish its catalog entry only after release
and mirror hashes are verified. Withdrawals must remove eligibility in both.
Hosting is a future deployment action requiring separate authorization; fixtures
and a local preview suffice during implementation.

Do not depend on a browser-readable GitHub redirect chain for the normal binary
path. Test the actual hosted GET and preflight responses from local HTTP hostname
and IP before promotion. If that path is unavailable, show an actionable download
error and USB/manual-package alternatives. Do not silently change to device HTTPS
pull, an arbitrary proxy or a shared-token solution. Direct device pull remains
a future alternative requiring its own TLS/memory evidence.

### C. Transport decision: bounded chunk requests

Select sequential form-encoded chunk requests for the first implementation.
`src/http_request.h` already admits bounded form bodies, rejects NUL/binary input
and limits the body to 2,048 bytes with a two-second request deadline. Preserve
those limits and avoid introducing a general binary/multipart upload parser.

Proposed protocol contract, to formalize in phase 2 and implement only in phase 5:

| Operation | Required behavior |
| --- | --- |
| Read capabilities/status | Return bounded read-only identity/capability data; never acquire maintenance or access GitHub from the ESP32. |
| Stage signed manifest | After explicit user action, stage at most 8 KiB in bounded chunks; no image erase. Verify signed constraints and source transition before accepting image bytes. Staged data expires and grants no motion/update authority. |
| Confirm/start | Bind a single-use authorized request to source boot/firmware, manifest hash and target image; atomically reserve maintenance and validate fresh native/OFF evidence. Reject busy rather than waiting to interrupt another operation. |
| Send image chunk | Initially at most 384 decoded bytes, strict base64 inside a form body; transaction, exact byte offset and authentication fields keep the complete percent-encoded body within 2,048 bytes. Reject ambiguous encoding, oversize, wrong offset or wrong transaction. |
| Acknowledge/status | One chunk in flight, one fixed worker mailbox. Acknowledge consumed offset only after worker processing; HTTP acceptance into the mailbox is not proof of a flash write. A lost response is reconciled through bounded status, not blind replay. |
| Finish/activate | Worker verifies exact total/hash/signature and current clearance; serialized commit writes durable intent and selects the inactive app. No handler calls flash/servo APIs directly. |
| Cancel/failure | Stop transport and abort SDK handle before cleanup acknowledgment; retain maintenance if physical evidence is uncertain. No automatic retry, movement or queued-command replay. |

Encode base64 characters correctly in forms; `+` must never silently decode as
a space. At 384 decoded bytes, base64 is at most 512 characters and worst-case
percent encoding is at most 1,536 bytes; reserve at most 512 additional encoded
bytes for all field names, separators, transaction and authorization fields.
Phase-2 size vectors must enforce the complete encoded limit, including metadata
chunks. Larger chunks require a revised bounded contract, not a global parser
limit increase. An 8 KiB manifest staging budget is a
design ceiling, not a demonstrated production heap reserve.

The browser downloads the bounded app into browser memory after confirmation,
before reserving maintenance; device reception then uses the inactive slot and
small fixed buffers. Downloads and metadata staging have no servo side effects.
Page closure or network failure aborts the transaction safely; there is no
background automatic install or automatic continuation after reboot. Chunk
round-trip overhead is the accepted tradeoff for reusing the bounded parser;
throughput and deadline feasibility must be measured before release.

### D. Capability and compatibility contract

Add a small versioned read-only capability object; field names below are proposed,
not an existing API. Keep identity, persistent compatibility and transient
maintenance eligibility distinct so a cached verdict cannot authorize flashing.

| Capability group | Required fields/evidence |
| --- | --- |
| Firmware identity | Version/release/dirty flags, full source commit, build profile, ELF identity and current boot ID. Reuse existing generated values rather than inventing a second version source. |
| Update implementation | Capability schema version, receiver protocol, supported transport, `receiver_enabled`, trust-key IDs and diagnostic reason when unavailable. The present USB candidate reports disabled. |
| Storage | Layout ID, chip/flash constraints, current/next slot capacity and rollback capability evidence level: unknown, build-supported or device-verified. No boolean inferred only from dual slots. |
| Motion compatibility | Native multi-turn capability, exact servo profile/reference ID, read validity, signed native position and startup policy ID. Never publish arbitrary profile writes as update options. |
| Settings | Independent calibration, application, network/auth and journal reader/writer schema IDs; tested source/fallback transition IDs. Do not collapse them into descriptor `settings=5`. |
| Eligibility | Eligible/busy/blocked/unknown plus bounded reason codes, observed control generation and evidence freshness. Worker must recheck all evidence before flash. |

Initial pure compatibility vectors for phase 2:

| Source and target | Required verdict |
| --- | --- |
| Official native USB-only → qualified native OTA-capable release | USB bootstrap required; never offer wireless on the source. |
| Qualified native receiver A → newer native B, same validated layout/settings/journal pair | Potentially compatible; install still depends on fresh maintenance/auth/signature checks. |
| Native controller → factory-only `web_control` image | Incompatible, regardless of version. |
| Offset-1328 or +1 calibration retained for review → native offset85/-1 active path | Review required; do not reinterpret coordinates or manufacture clean calibration. |
| Dirty/dev/unknown source → official release | No normal newer-release assertion or automatic wireless transition; require an explicitly tested source transition or USB. |
| Equal version with different commit/hash; unknown schema; untested settings fallback | Block normal install with a specific reason. |
| Older target | Read-only notes allowed; normal install disabled. Health rollback remains a separate verified recovery operation. |

### E. Security and servo policy dispositions

Recommended trust contract remains device-verified signed manifest bytes binding
the image hash and compatibility fields; real key custody/rotation and trusted-LAN
authorization are **owner decisions still open**, not implied by approval of the
webpage experience. Phase 2 may build validators/test vectors with synthetic keys;
it must not provision production keys or credentials or label that test path safe
for distribution. Recommend unique device credentials established during first
USB setup and retained across validated app updates, with deliberate local reset
and rotation. No credential value is chosen in this document.

Initial maintenance recommendation remains supported CLOSED, clean calibration,
fresh stable native feedback and verified torque OFF. Unknown/ON torque, motion,
holding, fault, stale evidence or another maintenance owner blocks installation.
This is a proposed first production policy; it is not an authorization to release
torque or move a cover. The application must never close itself to enable OTA.

Preserve existing multi-turn behavior while designing a distinct update-startup
policy. `COVER_MULTITURN_USB` currently also defines `COVER_MULTITURN_STARTUP`;
`web_control.cpp` calls `prepareMultiTurnStartup()` during worker initialization.
Simply enabling a receiver in that build could therefore carry automatic RAM
setup into update startup. Resolve that explicitly before phase 4/5 integration.
Recommend update/rollback startup inspect an already exact native profile with
no register writes; factory/partial profile after a power event locks motion.
Cold-start setup remains separately approved and qualified behavior. No update
prompt grants permission to change those registers.

### F. Measurement and gate ledger

| Check | Phase-1 result / remaining gate |
| --- | --- |
| Source audit | Reconfirmed current production receiver static prohibition, descriptor mismatch, bounded parser, About/footer hooks, ordinary torque-ON admission and startup RAM coupling. No live controller inspected. |
| Discovery implementation scope | Ready for phase-2 pure metadata/version/compatibility work using fixtures; UI depends on those results. Existing hourly/24-hour cache and request limits remain explicit design targets. |
| Transport design | Bounded form chunks selected; serialized worker mailbox and strict encoded-size vectors required. Device parser limits remain unchanged. |
| Security readiness | No-go for production auth/signing provisioning until owner security/key-custody choices are recorded. Offline schema and rejection tests can proceed. |
| Servo/startup readiness | No-go for production update admission until exact native profile and no-write update/rollback startup are integrated and qualified. |
| Memory acceptance | Measure minimum free internal heap/largest block, stack headroom, queue/staging allocations and fragmentation across supported workload and cleanup. Choose documented reserves above observed peaks before opening production admission; no inherited dev threshold. |
| Timing acceptance | Preserve three-second preparation timeout, 500 ms validation interval and 1,500 ms clearance-age limit in design. Measure chunk processing, erase/write/commit stalls and explicit Stop latency; any violation reopens design. Do not claim the ordinary motion watchdog deadline is an OTA guarantee. |
| Boot/recovery acceptance | Exact bootstrap bootloader/partition and valid fallback evidence plus both-slot, failed-startup and power-loss tests remain phase-7 hardware gates. |
| Public access | Hosting/CORS, repository access, release promotion and licensing remain publication gates. No change is authorized by this record. |

**Phase-1 conclusion:** go for the offline phase-2 metadata/version/compatibility
subset. Production security provisioning, update integration, hardware and
publication remain gated as specified above. The next implementation should
produce a shared compatibility model and tests, not enable an upload button.

## 10. Phase-2 offline metadata subset — implementation record

Implemented after explicit authorization to perform the offline subset (subsequent
discovery and offline signing work is recorded in section 11):

- `data/ui/release_metadata.js`: one dependency-free pure model used by Node
  tooling and the browser global `CoverReleaseMetadata`. The subsequent discovery
  increment includes it in the embedded UI bundle; the model performs no I/O.
- `tools/release_metadata.cjs`: bounded local-file inspection CLI using that same
  implementation; no network, device access, signing or installation.
- `tests/fixtures/release_metadata.json`: synthetic shared source/target and
  compatibility/version vectors. The fixture's qualification/rollback values
  do not represent an actual qualified release or verified controller.
- `tests/web/release_metadata_test.cjs`: runs the same vectors in Node and a
  DOM-free browser-global VM context, plus parser/CLI/profile-binding cases.
  `tools/validate_release.py` now includes this test in its offline gate.

### Preview contract and use

The schema identifiers are deliberately `telescope-cover-release-preview/1` and
`telescope-cover-device-preview/1`, distinct from every existing USB/release/OTA
manifest. These are not the final signed wire format. No generated release
identity, legacy manifest parser, current packager, firmware endpoint or upload
guard is broadened. Consumers must treat the preview as untrusted claims.

For incoming text, call `parseReleaseJson(text)` / `parseDeviceJson(text)` rather
than plain `JSON.parse()`: the bounded decoder rejects duplicate fields (including
escaped equivalents), unknown fields, excessive nesting/collections, unsafe or
noncanonical JSON integers and payloads over 8 KiB UTF-8. Object validators are
also exported for already-decoded internal objects. Version comparison handles
the full SemVer ordering rules with numeric identifiers represented as strings
to avoid JavaScript precision loss. Publishable preview release versions retain
the project's narrower stable/alpha.N/beta.N/rc.N syntax and exact `v` tag match.

`assessRelease(release, device, {include_beta:false})` returns a reason `code`,
`compatible`, `update_available`, `method` (`usb`, `ota` or null) and always
**`installable:false`**. `ota-candidate` means only that the synthetic/offline
compatibility checks passed. It is not signature verification, actual hardware
acceptance, live maintenance admission or settings-preservation evidence.
Validation errors throw; discovery must display invalid/unknown compatibility,
never silently treat them as current firmware or an empty release list.

Release records contain identity, channel, qualification, published flag, protocol,
hardware/layout, motion/reference/startup semantics, independent settings IDs,
typed artifacts and exact source transitions. Transition identity includes full
commit/ELF/build profile/version and source settings; unsupported downgrades and
duplicate/ambiguous transitions are rejected. Artifact entries include type,
filename, size and SHA-256. URLs, GitHub IDs, signatures, expiry/revocation and
catalog publication belong to later contract integration; this subset does not
authenticate flags such as `published` or `qualified` or inspect binary bytes.

The only preview hardware family/layout is Waveshare 21593 / ESP32 / 4 MB /
`cover-4mb-v1`, with a 1,310,720-byte app slot. Unknown hardware/layouts fail
validation rather than becoming implicitly supported. Profile compatibility is
pinned to SHA-256 of the commissioned native 40 identity/configuration bytes
(indices 11–12 zero, 18 = 28) followed by lock register 55 = 1. The digest is
checked against `src/servo_factory_profile.h` by a regression test. This binds
the metadata convention, not a live hardware observation.

Initial settings allowlist: calibration 5, `cover-app-382-v1`,
`network-preview-v1`, `device-auth-preview-v1`, handoff 1. Network and auth IDs
are explicitly synthetic placeholders; no deployed device is claimed to expose
them. Unknown IDs, retained calibration review, offset 1328, reversed direction,
unqualified/pipeline releases, missing exact source transitions or unverified
rollback cannot yield an OTA candidate. A tested USB transition is separately
identified and implies a destructive clean install, not settings preservation.

Offline inspection (requires Node, already required by the release test gate):

```sh
node tools/release_metadata.cjs <release-preview.json> [device-preview.json] [--include-beta]
node --test tests/web/release_metadata_test.cjs
python3 tools/validate_release.py
```

The optional device file is a future capability snapshot in the preview schema,
not today's `/api/status` output. CLI output always says `preview:true` and
`authenticated:false`. No real secret/key provisioning, signing, discovery
poller/UI, preservation claim, hardware test, firmware build, flash or publication
is included in this increment. Full phase-2 signing/key-lifecycle/capability API
work and later production safety/recovery gates remain outstanding.

## 11. Discovery and offline signing — implementation handoff

Continued under the owner's instruction to work through the plan until blocked.
Changes are local and uncommitted; no hardware or publication authorization was
inferred from that instruction.

### Implemented software

`data/ui/release_discovery.js` adds an injectable read-only discovery engine.
It checks the fixed public GitHub Releases endpoint, defaults to stable releases,
supports explicit beta opt-in and manual checking, caches bounded results/ETags,
and polls hourly with jitter while visible. Failed checks retain last-success
time and dated cached data. Rate/backoff deadlines gate manual checks too.
Three sequential pages of 30 releases are the current history limit; a remaining
page link marks the history incomplete. Fetches have ten-second deadlines and
decoded-byte limits; notes are bounded to 16 KiB and shown as text.

Storage denial is recoverable. A bounded same-origin storage lease reduces
duplicate requests across tabs, but localStorage is not an atomic cross-process
lock or a safety/authentication mechanism. Compatibility is recomputed from
current capabilities and never cached as installation permission. Discovery
never downloads a firmware binary.

`data/ui/firmware_updates.js`, HTML/CSS and the embedding hook add Configuration
→ Firmware updates, section navigation, the footer notification, versions,
browser-local check times, release selection/notes, compatibility reasons, errors
and USB guidance. CSP allows only the existing controller origin plus
`api.github.com` and `kbdavis.github.io` for connections. There is no wireless
Install button or mutation route in this increment.

The preview catalog path is
`https://kbdavis.github.io/Telescope-Cover/firmware/catalog-preview.json`. It is a
future deployment contract, not an assertion that a service is hosted there.
Schema `telescope-cover-catalog-preview/1` has `releases` entries with `release_id`
and validated preview `metadata`, limited to 256 KiB and 90 records. Entries must
match published GitHub ID/tag/channel. Duplicate fields/IDs/versions and unknown
schemas fail closed. Repository visibility/hosting were not changed.

The UI accepts an optional `session.update_capabilities` preview report.
**The firmware does not yet produce that report.** It never infers supported
board/profile/settings or rollback qualification from a build name. Without a
report and matching accessible catalog it shows compatibility unknown and no
compatible-update notification. Fixture-based success is not completed public
discovery/compatibility deployment.

`tools/release_signing.cjs` is an offline P-256/SHA-256 prototype. Exact raw UTF-8
preview manifest text, up to 4 KiB, is signed. P1363 64-byte r||s signatures,
canonical base64 and a key ID form `telescope-cover-signature-preview/1`; the
envelope fits the proposed 8 KiB metadata staging ceiling. Verification uses a
caller-supplied trusted public-key map and revoked-key set, never an envelope key.
Tests generate ephemeral in-memory keys only. No production key, key file,
signer CLI or device trust root is created; results retain `installable:false`.
Final signed catalogs, key lifecycle and ESP32 verification remain unimplemented.
Browser discovery does not authenticate the preview catalog and cannot authorize
installation. Device interoperability/memory must be tested with pinned mbedTLS.
[Node signing](https://nodejs.org/api/crypto.html#cryptosignalgorithm-data-key-callback),
[Node verification](https://nodejs.org/api/crypto.html#cryptoverifyalgorithm-data-key-signature-callback).
API constraints were rechecked against [GitHub CORS documentation](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
and [GitHub API practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api).

### Verification evidence and limits

| Check | Result |
| --- | --- |
| `python3 tools/validate_release.py` | Passed: 136 Python tests; installer tests; 66 metadata tests; 17 discovery tests; four signing tests; existing version/diagnostics/manual/travel checks and five selected C++ safety/maintenance/multi-turn executables. |
| `node tests/web/firmware_updates_browser_test.cjs` | Passed in isolated headless Chrome with loopback fixture 8098 / CDP 9234. GitHub/catalog responses were intercepted. Tested absent capabilities, compatible notification/focus, stable/beta, literal untrusted notes, 1440/390 px layout, access errors and GET-only page requests. |
| PlatformIO `web_control_multiturn_usb` | Passed with pinned framework/layout and OTA prohibition. Binary 1,138,432 bytes, slot headroom 172,288 bytes (13.14%), static DRAM 56,184 bytes. Dirty development build, not a frozen release or runtime memory qualification. |
| Hardware/USB/OTA/registers/motion | Not exercised or changed. No live profile/bootloader state inferred. |

The real-browser test remains separate from the offline gate because it requires
an isolated local browser/fixture server. Intercepted responses and compilation
do not establish production CORS/hosting, live native behavior or startup safety.

### Prior gates and next work (decisions superseded by section 12)

Phase 2 is partial: offline compatibility/signing experiments pass; final trust,
device verifier and capability API remain open. Phase 3's local UI/scheduler is
implemented/tested; real capability/catalog deployment remains gated. Production
integration in phases 4–5 needs these pending owner decisions:

1. Trusted-home-LAN authorization with unique device credentials versus requiring
   encrypted controller access before production updates.
2. Offline local maintainer key custody versus protected CI signing; no production
   key provisioning before this decision.
3. Inspect-only servo configuration on update/rollback startup versus retaining
   separately approved RAM setup. Cold-start preparation cannot silently become
   updater permission to program the servo.

These were presented as owner questions. Recommendations are trusted LAN, offline
signing and inspect-only update startup. No answer is inferred from elapsed time.
Settle them before encoding production credential schemas, trust roots and startup
behavior. Then implement device verification/authorization, capability reporting,
settings/fallback startup and chunk transfer. Keep installation disabled until
exact clean artifacts pass supervised memory/timing/bootloader/power-loss/rollback
and USB-recovery gates. Phase 6 includes the new offline suites, but an accepted
release needs a frozen clean commit. Hardware session scope, hosting, tag/push
and publication remain separate gates.

## 12. Owner decisions accepted and device foundations

Owner confirmed on 2026-11-12: trusted home LAN; offline local maintainer signing;
inspect-only servo configuration after updates and rollback. These choices settle
the three questions in section 11. They do not authorize a flash, motion, servo
register programming, key publication or release publication.

Implemented read-only startup integration: pending images, unresolved durable
handoffs (including rollback recovery), or an unreadable journal pass an explicit
inspection-only policy to the servo worker. For multi-turn firmware this calls
`ServoController::inspectMultiTurnStartup()` rather than RAM preparation. It checks
model, exact native profile/lock, torque OFF and two stationary native samples;
it sends no write/torque/goal commands. Native-only configuration remains required
for that driver lifetime, including Recheck. Normal cold-start preparation remains
separate. Driver tests cover retained positive/negative native turns, factory and
partial profiles, invalid identity/lock, energized/moving hardware and failed reads.
Worker tests verify that update inspection never invokes RAM preparation, even
on failure. Older installed fallback images do not acquire this behavior until
bootstrapped; supported transitions must account for that.

`src/release_signature.h/.cpp` adds bounded P-256/SHA-256 verification using pinned
mbedTLS, fixed 64-byte P1363 signatures and trusted public SEC1 points. It rejects
unknown/revoked/duplicate keys and malformed input before crypto. Signature
verification alone does not validate compatibility, grant maintenance or enable
installation. No production trust keys are provisioned. A public test vector
signed by Node is independently exercised through C++/OpenSSL by
`tests/web/release_signature_interop_test.cjs`; the target backend compiles with
the pinned SDK. The offline release gate now includes this test and requires
OpenSSL development headers/library (pkg-config or the existing Homebrew path).

A dedicated `release_signature_selftest` environment is prepared for the next
target-crypto evidence check. It runs only the public test vector, modified
signature rejection, revocation and repeated verification with timing/heap
observations. It does not start the controller, UART1, Wi-Fi, servo, telescope or
settings flows. Default uploads are denied. Generated `selftest-factory.bin` and
`selftest-inputs.json` are separate uninstalled test artifacts with hashes, not
production releases. Use only a separately authorized spare-board procedure;
never substitute this firmware on the active cover controller. No hardware test
has been performed. A passing standalone crypto test will not establish the
full controller's production memory reserve or update safety.

### Prepared spare-board crypto check — authorization pending

The frozen local test package is
`dist/release-signature-selftest-0c42e0dd09cf/`. Its complete `factory.bin` is
373,504 bytes, SHA-256
`0c42e0dd09cfbcec3b4191a95c56d92f8576fe4083ecd16c1294a00e95438107`.
It contains the matched bootloader, pinned partition table, boot-selection data
and self-test application; `selftest-inputs.json` and `SHA256SUMS` record all
components. Independent ELF inspection confirmed the target crypto backend is
linked and controller/network/servo operating entry points are absent. This is
an uncommitted development test artifact, not a production release candidate.

The concrete proposed session is limited to:

1. Owner identifies the **spare** supported ESP32 board and confirms its arm is
   detached and external servo power disconnected. Do not use the active cover
   controller. Agree the actual USB port; no historical port suffix is assumed.
2. After explicit authorization, identify chip/flash and install only the frozen
   complete test image at 0x0 using the pinned esptool, then verify written bytes.
   USB connection/flashing resets the board and the merged image erases its
   existing application settings/calibration area. This is not settings-preserving.
3. Capture the self-test UART0 output at 115200. If the first output was missed,
   a separately agreed reset of this isolated spare may capture it; do not
   substitute resets or installs on the active controller.
4. Require the exact test banner and `result=PASS`, with elapsed/heap observations
   recorded. A timeout, reset loop, cryptographic failure or any unexpected servo/
   network activity is no-go. Stop and preserve evidence rather than repeat blindly.
5. Do not teach, move, energize the servo, write its configuration, install normal
   cover firmware, create production keys or publish artifacts in this session.
   Keep the spare isolated after testing; any restoration is a separately agreed
   image/operation.

This early physical check validates the cryptographic implementation before
production verification/transfer integration, rather than assuming host crypto
and a target build prove execution on the ESP32. It is an added prerequisite,
not a substitute for phase 7's full-controller acceptance. No hardware operation
or port access has occurred during preparation.

## 13. Spare-controller hardware evidence — 2026-11-12

The owner identified the USB-connected board as the spare and authorized work
on it ("the spare controller do what you want to it"). Only
`/dev/cu.usbserial-0001` was accessed; the active controller was not contacted.

The spare reported ESP32-D0WD-V3 revision v3.1, 40 MHz crystal and 4 MB flash.
The frozen crypto factory image from section 12 was written at 0x0, passed the
write-time hash check and a separate `verify_flash`, and was booted with one
UART0 RTS reset. Actual target output:

```text
RELEASE_SIGNATURE_SELFTEST result=PASS elapsed_ms=3977 before=279092 baseline=278792 after=278792 largest=114676
```

This establishes valid-signature acceptance, modified-signature rejection,
revocation and repeated verification on the pinned ESP32/mBedTLS implementation.
No free-heap decrease was observed between the post-initialization baseline and
the end of repeated checks. The initial before/baseline difference was 300 bytes.
These are standalone observations, not peak crypto allocation, full-controller
memory reserves, OTA acceptance, startup/rollback safety or weather qualification.
No servo or network operating entry points ran in this test firmware.

Private evidence: `diagnostics/2026-11-12-release-signature-selftest-01/`, including
session authorization, identity excerpt, write/verify transcripts, UART0 capture
and parsed result. The installed factory hash was
`0c42e0dd09cfbcec3b4191a95c56d92f8576fe4083ecd16c1294a00e95438107`.

To inspect the spare's servo prerequisites, the existing `servo_backup` firmware
was prepared with the enforced `COVER_SERVO_READ_ONLY` guard. Its bootloader and
partition table were checked byte-identical to the installed spare test layout.
The application hash is
`3b4267509ea933868c46d92ed5b319d9dc1c594247bad1ba59043f3c1c59262f`.
This controlled application-only USB laboratory write uses the known installed
layout; it is not a new end-user installation or settings-preservation workflow.
The diagnostic only requests model, torque and repeated identity/configuration
reads, then stops. It cannot issue motion, torque changes or EEPROM writes.
The diagnostic write completed and passed esptool's write-time hash verification.
The initial separate verification could not configure the USB port because the
owner unplugged the spare to attach a servo. After the owner reconnected USB,
separate `verify_flash` passed and one UART0 RTS reset captured the exact
read-only diagnostic banner. Model reads timed out (`error=2`), and the diagnostic
reported `BACKUP FAILED; no servo writes performed`. The owner confirmed that
external servo power was absent. This is insufficient to identify or qualify the
attached servo; it is not evidence of a defective servo. No configuration snapshot
was obtained. Private evidence:
`diagnostics/2026-11-12-spare-servo-readonly-01/`, including the resumed verification,
UART0 capture and `result-reconnected.json`. The active controller and all servo
registers remain untouched.

## 14. USB-powered read-only web preview — 2026-11-12

To exercise the web UI while the spare's servo supply is absent, the new
`web_control_readonly` development environment excludes private Wi-Fi, telescope
and OTA credentials, disables the OTA receiver, rejects protected mutating
controller routes, and enforces the existing read-only driver packet guard.
Only servo ping/read packets are permitted. Compile-time checks prohibit combining
this environment with startup reference/multi-turn configuration preparation,
probe or developer-OTA profiles. Native multi-turn feedback reads remain supported;
no servo reference, mode, range, phase, torque or position is written.

The UI identifies this session as read-only and disables overview motion controls
and the Stop dock. Network setup and beta acknowledgement retain their existing
separate authorization and maintenance checks, including the existing offline
servo policy. Firmware discovery is available, but installation is disabled.
This development preview is not a production release or OTA acceptance test.

The frozen application is 1,138,096 bytes, SHA-256
`06d9530249e0af4aa0134ef18b0913f0884a0f98355b24b925960e45d68d2cc2`,
ELF identity
`209a377d860b8bacfb629c0898c6399681fde406472d720e52a4fffeddeeb631`.
Its bootloader and partition table were checked byte-identical to the installed
spare layout. Application-only USB write at 0x10000 passed its write-time hash
check and a separate `verify_flash`. One UART0 RTS reset confirmed the exact ELF
and `web_control_readonly` profile, startup acceptance and setup hotspot:

```text
SETUP AP: TelescopeCover-4DFF9C open (no password) address=192.168.4.1
OTA phase=unavailable reason=release_gate
OTA startup=accepted
```

Startup and subsequent servo reads timed out, consistent with the owner-reported
absence of external servo power. No browser-to-hardware request has yet been
verified: the development Mac's Wi-Fi was not changed. Join the setup hotspot
and visit `http://192.168.4.1/` to inspect the preview. Accept the beta notice,
then use Configuration → Firmware updates. Home-Wi-Fi onboarding is required
for controller LAN access; the viewing browser also needs internet access for
GitHub/catalog discovery. A public test feed and real device capabilities are
still missing, so the actual spare cannot yet demonstrate a compatible update
notification or seamless installation. The fixture browser tests exercise those
notification states without treating them as hardware evidence.

The full local validation gate passed, including the new host check that read-only
native feedback succeeds while torque/motion commands cannot emit write packets.
The target build passed with 56,096 bytes static DRAM and 172,624 bytes OTA slot
headroom. These are build observations, not peak-runtime/full-update memory proof.
Private frozen artifacts, write/verify transcripts and boot capture are in
`diagnostics/2026-11-12-spare-web-readonly-01/`. All changes remain local and
uncommitted; no repository visibility, release or active-controller change occurred.

## 15. Live device capability reporting — implementation increment

A distinct `telescope-cover-device/1` runtime report is now included in
`/api/session` as `update_capabilities`. It reuses the generated firmware identity
and actual running ELF, measures flash size, validates the exact pinned partition
layout and reports the smaller running/next slot capacity. Compiled native motion
support is separate from `servo_profile_verified`: only fresh cached model,
validation, exact 40-byte profile, lock and native-position evidence can set that
flag. The accessor performs no servo transaction, maintenance reservation or
settings write. An unavailable or stale servo therefore never becomes verified
merely because a native-aware binary is installed.

The report identifies the deployed calibration v5/application 382-byte format,
network settings embedded in that application record, legacy session-token auth
and existing handoff v1. It does not substitute the synthetic fixture's proposed
network/device-auth schema IDs. The signed browser receiver remains explicitly
disabled, and exact-device rollback qualification remains `unknown`; neither the
private desktop uploader nor prior hardware experiments promotes those fields.
Legacy absolute builds report no native motion contract. Read-only test firmware
is explicitly marked. This report describes support and observations, not an
installation authorization or a completed production capability protocol.

The browser accepts the runtime schema separately from the synthetic preview
schema, binds it to the current session identity, and blocks unsupported hardware,
legacy settings/auth, unverified servo evidence and read-only firmware. Development
identity still prevents an official-compatible update claim. The Firmware updates
panel reports current device support even when no public catalog is reachable.
All compatibility results remain `installable:false`.

New tests exercise strict runtime fields, stale identity, read-only/dev blocks,
actual-versus-synthetic settings IDs and exact/fresh passive profile evidence
(including invalid flags, changed bytes, stale timestamps and uptime wrap). The
full offline release gate passed: 136 Python tests, 68 metadata tests, 18 discovery
tests and the other signing/installer/JavaScript/C++ gates. The read-only target
build passed at 1,140,928 bytes with 169,792 bytes slot headroom and 56,096 bytes
static DRAM. Hardware/browser evidence for this increment is recorded below once
collected; build success is not evidence of full update memory/flash safety.

`tests/web/device_updates_browser_test.cjs` is an explicit spare-board acceptance
check, separate from offline validation. It requires an isolated Chrome CDP
session, an explicit private-LAN spare address, an existing evidence directory,
and a live session reporting read-only firmware. It visits the actual device page
and checks real device identity/capabilities. GitHub/catalog responses and the
compatible-source identity needed to demonstrate the notification are simulated
in browser memory only. It asserts no controller mutation requests and no firmware
or boot identity change. No release artifact is downloaded or installed. The
saved result distinguishes these simulations from actual hardware evidence.

### Spare LAN check and browser dependency correction

The owner supplied `192.168.1.135` after onboarding. GET requests confirmed the
spare's expected first read-only ELF, accepted beta notice, home-LAN access,
UNKNOWN/nonmoving/nonholding cover state and unavailable OTA receiver. The first
capability-report candidate passed app-only USB write/independent verification,
reconnected at the same address, retained Wi-Fi/beta settings and returned a valid
runtime capability object. Servo profile verification remained false with the
unpowered servo, and signed browser receiver/rollback qualification stayed disabled/
unknown as designed. Evidence is in
`diagnostics/2026-11-12-spare-web-capabilities-01/`.

That candidate failed the actual-browser gate: some reloads reset the stylesheet
and theme-script connections, then `previewAppearance` was undefined and app
initialization stopped before session polling. The cause of those concurrent
connection resets is not established. Changing CDP interception/cache settings did
not remove the reproducible missing-dependency failure. Preserve that failure;
do not describe the first candidate as browser-accepted.

The corrected embedded page includes CSS in the HTML and theme initialization at
the start of the main deferred script. Essential startup therefore has no separate
stylesheet/theme request dependency. Existing asset routes remain for already
loaded clients. The full offline gate passed again. The corrected read-only app
is 1,162,224 bytes, static DRAM 56,096 bytes, leaving 148,496 bytes (11.33%) in each
OTA slot. The duplicate compatibility asset paths increase flash use; production
receiver integration must remeasure headroom rather than reuse this build's limit.
The frozen second candidate and verification evidence are in
`diagnostics/2026-11-12-spare-web-capabilities-02/`. Its actual browser acceptance
must pass before treating the dependency correction as verified.

The second candidate passed app-only USB write and independent verification, then
one RTS reset booted ELF
`c651937c0219c08e1d4d42f78c7596570a2f2dcac5514d86c3922aa3deed4917`.
Application SHA-256:
`a95f37eecb6213d5f87c8f2976afd801a86e9bf055d1dca0058cae9ae55be244`.
Startup was accepted and home Wi-Fi reconnected at `192.168.1.135`; beta acceptance
and Wi-Fi settings survived both app-only writes. The exact runtime report was
captured with the session token removed.

Actual Chrome acceptance then passed: real LAN page/session/capability report,
read-only banner, inaccessible release-service state, development-build blocking,
browser-only simulated compatible notification/focus and 1440/390-pixel layout.
The test loaded and reloaded the corrected page successfully. It recorded zero
controller mutation requests and unchanged firmware/boot identity. Remote release
responses and the compatible source identity were simulated in browser memory;
this proves notification rendering, not discovery of a genuinely published
compatible artifact or OTA installation. The browser result and both real-state
and clearly named simulated-notification screenshots are preserved alongside
`result.json`. The isolated test browser was terminated afterward.

Current user-visible behavior is intentionally no compatible update notice on
this dirty development firmware. A published compatible release/catalog, clean
qualified source/target transition, signed receiver with production authorization
and transfer integration, and remaining hardware acceptance are still required
for real end-to-end installation. Servo-dependent checks remain untested without
external servo power. No main-repository visibility change, publication, signing
key provisioning, commit, active-controller access or servo register write occurred.

## 16. Manual release-check retry correction — 2026-11-12

The owner reported Last successful check = Never and a disabled Check now button,
then provided the actual inaccessible-release message. Authenticated read-only
GitHub metadata confirmed the repository is private; a separate anonymous release
API request returned HTTP 404. No visibility or publication setting was changed.
The prior UI did not distinguish its one-minute manual cooldown, server rate-limit
wait and increasing automatic failure backoff. All three could disable the manual
button with no adjacent explanation. A controller connection failure could also
leave the last rendered disabled state unchanged after its deadline elapsed.

Ordinary failed checks now preserve automatic backoff while permitting manual
retry after the one-minute request cooldown. Explicit HTTP 403/429 rate-limit
waits, including secondary-limit backoff, continue to gate both paths. Cache schema
2 preserves the server wait separately; older cached ordinary failures do not
inherit a manual lock, while old cached rate limits remain enforced. Server waits
up to the existing 24-hour bound survive reload. No retry clears maintenance,
changes firmware, writes settings or acquires update authority.

The button shows Checking or Check in … with an adjacent reason and retry time.
A visible-page one-second render timer updates and reenables it independently of
controller polling. Last successful check now says No successful check yet until
an actual successful list check. Last attempt remains separately dated. Automatic
checks off is displayed consistently with the preference.

Validation: 22 discovery tests and the actual-renderer retry regression pass;
metadata's 68 tests also passed. The renderer test advances injected time without
controller emits and verifies first-use eligibility, countdown/reason, one-minute
manual retry despite automatic backoff, and server-limit enforcement. The final
read-only build is 1,162,576 bytes. Both app-only USB writes passed independent
flash verification; the preliminary candidate was not booted. The final candidate
includes the long server-wait cache correction and was booted once, retained home
Wi-Fi/beta settings, and reconnected at `192.168.1.135`. Frozen application ELF:
`9d3ade82f10a3cfc687f95f02c6afb530cdb1b75a173e2a9c2dfade08cd19feb`.

`tests/web/device_update_retry_browser_test.cjs` passed on that actual spare page.
Injected browser time and responses verified first-use Check now, countdown/reason,
manual retry and explicit server waiting. Those injections were then removed and
a real anonymous GitHub check returned the private/inaccessible state with a dated
attempt, No successful check yet, and Check in 60s plus the reason. Firmware/boot
identity stayed unchanged during the browser test, with zero controller mutation
requests. No OTA transfer or servo operation was performed. Evidence and screenshot:
`diagnostics/2026-11-12-check-now-02/`; the isolated test browser was closed afterward.

## 17. Public OTA test repository created — 2026-11-12

At the owner's explicit request, created
`https://github.com/Kbdavis/Telescope-Cover-OTA-Test` as a public repository with
an initial README and experimental-testing description. Authenticated metadata
verified PUBLIC visibility; the main `Kbdavis/Telescope-Cover` repository remains
PRIVATE. No project firmware, signing key, release artifact or source checkout
was uploaded. This action establishes the public test destination only.

The installed webpage still uses the main repository URLs. A separate bench
feed/channel configuration, signed metadata/artifact hosting and actual web OTA
receiver/transfer remain to be implemented before the happy-path test. Anonymous
release-list verification returned HTTP 403 with X-RateLimit-Remaining 0 rather
than an access/visibility result; do not treat that rate-limit response as evidence
that the new repository is private. No releases have been published to the new
repository by this session.

## 18. Real public-repository bench happy-path implementation — 2026-11-12

The owner authorized all steps necessary to attempt the full happy path against
`Kbdavis/Telescope-Cover-OTA-Test`, including publishing the experimental artifacts
and operating the spare. Main-project source changes remain uncommitted. No
production key, active-controller access or servo programming is authorized by
this bench implementation.

Implemented a separate `bench_ota` PlatformIO environment. Its source filter links
only main/bench updater, settings record reader and the target signature verifier;
no servo/controller/telescope worker or UART1 startup is linked. Compile-time
checks forbid combining this environment with controller/development/startup
configuration modes. The existing production and read-only receiver gates remain.
The bench page clearly identifies the isolated experiment and exposes no movement
controls. Existing configured home Wi-Fi is required; USB remains its recovery
path if Wi-Fi/startup fails. This standalone test UI is not integration into the
operational cover UI or production OTA qualification.

The new bounded canonical manifest binds a dedicated bench product/profile,
pinned 4 MB layout, preserved cover-app record, exact source build/ELF, strictly
newer target build/ELF, application size and whole-image SHA-256. P-256/SHA-256
P1363 signatures use a test-only public point compiled into A/B; the private key
is stored outside the repository with restrictive permissions. Device admission
checks the signed source transition before any image erase. The complete bench
image prefix/ELF/embedded build marker is required before `esp_ota_begin`.

Each spare generates a unique 32-byte NVS update key and prints it to USB only.
Mutation routes require that key, the current boot nonce, exact home-LAN Host/
Origin and accepted STA startup. The key is not embedded in downloadable binaries
or returned by status. HTTP requests remain under the existing bounded parser;
image chunks contain at most 384 decoded bytes as strict hex, with exact offsets,
a transaction ID, one fixed worker mailbox and consumed-offset acknowledgement.
Only the dedicated worker calls flash/NVS handoff/boot-selection APIs. Cancellation,
wrong transaction/offset, source changes, Wi-Fi loss, idle/total timeout and hash/
image failures prevent successful activation. Commit selection has an explicit
noncancellable boundary. No whole-image ESP32 buffer or controller HTTPS download
is used. The initial bench-only heap guard is an experimental conservative floor,
not a qualified production resource threshold.

The browser downloads from the public HTTPS Pages host before requesting a flash
transaction. It checks size/ELF, while the ESP32 enforces the signature and full
hash. After complete validation, durable intent precedes selection of the inactive
slot and reboot. A strong deferred-acceptance hook enables the startup RTC watchdog.
A pending target must reconcile the exact journal target/slot and unchanged raw
application-settings record before acceptance. The original bootloader/table were
verified byte-identical on the spare; the pinned SDK enables rollback. Completion
requires a new boot ID, exact B ELF, durable matching transaction/target, accepted
startup and settings preservation. A failed/ambiguous reboot is not labeled success.

Frozen artifacts in private `diagnostics/2026-11-12-bench-happy-path-01/`:

| Build | Bytes | ELF SHA-256 | Application SHA-256 |
| --- | ---: | --- | --- |
| A, 0.1.0-beta.1 | 839,440 | `194f8b974f3790a171eee7538dfb3d45213d17548c3d85e51e5dbc1b1d36801d` | `bce8ffb8c854c34fd33ad2adb84d3bb69311c17c6b5ab1d0583ece22f16406d6` |
| B, 0.1.0-beta.2 | 839,440 | `b974c4969af32919d6c2f06c3a67b7a74c07a31bcad3b1a77b3885c63e6c8d7a` | `137539eca7cd32948f39a39c672cd411b9c5be8b059e585e3296c2fb39cb3218` |

Both fit with 471,280 bytes slot headroom and 47,488 bytes static RAM. ELF inspection
confirmed the strong rollback hook and absence of servo/controller/telescope
entry points. The full offline release gate passed, including the new canonical
manifest/source/prefix namespace rejection test. A private source snapshot and
hash inventory preserve the actual uncommitted implementation.

Public artifact commit `1bce16fd2d4c622a291dacd855644de67e5ebe11` contains only
allowlisted bench images, public verification key, signed metadata, checksums,
license and explanatory pages. Published experimental prerelease:
`https://github.com/Kbdavis/Telescope-Cover-OTA-Test/releases/tag/v0.1.0-beta.2`.
GitHub Pages was enabled on main/root at
`https://kbdavis.github.io/Telescope-Cover-OTA-Test/`. Actual anonymous release
API, catalog and binary requests returned HTTP 200; catalog/binary responses
included `Access-Control-Allow-Origin: *`, and the publicly downloaded B size/hash
matched the frozen artifact. No private checkout, device update key, Wi-Fi settings,
NVS backup or private signing key was published. The main repository remains private.

On the spare (MAC checked against 28:05:a5:4d:ff:9c), the first 460800-baud NVS read
failed with serial noise before any firmware write. A deliberate read-only retry
at the previously reliable 115200 baud succeeded. Private NVS and otadata backups
were saved with restrictive permissions; accepted app0 selection was confirmed.
A was installed application-only at 0x10000 at 115200, passed independent flash
verification, and was booted with one RTS reset. Its accepted startup on
192.168.1.135 was observed. The console authorization key and continuous A/B UART
capture are private evidence, not release assets.

`tests/web/bench_happy_path_browser_test.cjs` visits the real spare and real public
release/catalog/binary endpoints in isolated Chrome with ordinary browser security.
It does not mock release data, source identity, image downloads or controller
responses. Before installation it checks wrong-key rejection (403) and invalid-
signature rejection (400), with the worker still idle and zero bytes received.
It then enters the private USB key and explicit confirmation in the actual UI,
clicks Download and install, and observes progress plus reboot/transaction/settings
confirmation. Final measured outcome is recorded below after the attempt completes.

### Actual happy-path outcome: PASS

The real browser test completed successfully with **no mocked release, identity,
download, controller response or reboot result**. It discovered B from the public
GitHub release list intersected with the Pages catalog, displayed Update available,
downloaded the actual 839,440-byte public B application, transferred it through
2,187 bounded chunk requests, and confirmed activation/reboot. Download through
confirmed reboot took **254,291 ms**. Browser trace contains 4,391 actual requests
and matching responses, including the expected wrong-key/signature rejections.

Independent continuous UART evidence:

```text
BENCH phase=verified reason=none
BENCH phase=rebooting reason=none
BENCH activated target_slot=0x150000 bytes=839440
BENCH accepted version=0.1.0-beta.2 build=2 ip=192.168.1.135 slot=0x150000 outcome=complete settings_preserved=1
```

The source ran from app0 (`0x10000`); B ran from app1 (`0x150000`), with a new boot
ID, exact frozen B ELF, accepted startup, matching durable transaction/target and
unchanged raw application-settings record. The same private per-device update key
was observed before and after reboot. Wrong key returned HTTP 403; invalid
signature returned HTTP 400 while still idle/zero bytes, before actual transfer.
No servo operation or external servo supply was required. The spare is left
running B on its home-LAN address. Main controller and repository visibility remain
untouched. These observations do not qualify production motion admission, full
controller memory reserves, power-loss/rollback fault injection or unattended OTA.

Private evidence includes source snapshots, A/B binaries/ELFs, hashes, backup and
verification transcripts, restricted NVS/otadata backups, restricted USB key/UART
capture, exact before/after status, real browser request/response summary, outcome
JSON and screenshots. Public sanitized acceptance and screenshots are in the test
repository (evidence commit `5e20bc2`), with private settings, key, local address and
session/transaction identifiers excluded. The passing report is also attached to
the beta.2 prerelease. Test-specific GitHub publication was explicitly authorized;
main-workspace source remains uncommitted.

## 19. Owner-selected automatic update authorization — 2026-11-12

The owner explicitly rejected manual key entry/browser pairing and requested
that authorization be obtained automatically. This supersedes the earlier
per-device USB-key/pairing UX recommendation for the trusted home LAN. The page
now has no key field and does not read saved browser credentials. It obtains a
fresh boot-scoped authorization token from `/api/bench/session`, binds it to the
current boot/nonce, and supplies it internally on update requests. No pairing,
Remember this controller option or USB-console lookup is required.

The session endpoint requires accepted STA startup, the exact local Host, no
foreign Origin and the dedicated same-origin request header. It returns no CORS
permission and has `Cache-Control: no-store`. Mutation requests retain exact
Host/Origin, boot nonce, token and transaction checks. Tokens rotate at reboot
and are not printed to USB or stored in browser storage. The legacy NVS key is
left untouched for rollback to beta.2. Firmware signatures, source/target/image
validation, worker-owned inactive-slot writes, timeout/cancellation and startup/
settings reconciliation remain. Start additionally requires explicit `confirm=
install`, matching the user confirmation control. Servo operations remain excluded.

This intentionally authorizes visitors who can access the controller's home-LAN
page; it is not independent per-user authentication. That tradeoff is the owner's
explicit trusted-LAN UX choice. Neither runtime session tokens nor offline
signing private keys are embedded in published artifacts. Operational motion
maintenance and production qualification gates are unchanged.

New actual-renderer tests verify automatic session acquisition with browser
credential storage unavailable, no manual-key DOM access, install disabled until
confirmation, rejected stale-boot sessions and failed authorization. The complete
offline regression gate passed. Frozen beta.3 and beta.4 each occupy 840,720 bytes,
leaving 470,000 bytes in the existing OTA slot. Both exclude servo/control workers.

| Build | ELF SHA-256 | Application SHA-256 |
| --- | --- | --- |
| C, beta.3 | `a19afb15b8cbe7a0d87095b98cddd91e59f20ca3cc2fbda7a708e86a3e9c8439` | `5a98fd9fa1372a1033d43560b5c05d0a06a0074206dfc21716563e376f42d5dc` |
| D, beta.4 | `ed3f7046be0ee332161f0a5b7c165b1c853ae5662242150c50a649c0eab0be42` | `4b8c25b67ea88c562a07d4173aa095818ccbe12257c8abc80b45da3526a84869` |

Published test candidates in commit `2a249a0` extend the existing public catalog
with exact signed beta.2 → beta.3 and beta.3 → beta.4 transitions; prior artifacts
were not replaced. The Pages catalog was compared with frozen metadata before
hardware use. `tests/web/bench_auto_update_browser_test.cjs` has a legacy migration
mode using the already privately captured beta.2 key, and a separate automatic
mode that refuses any key-file argument. Both use real public release/image and
controller endpoints, explicit UI installation and exact reboot/transaction/settings
verification. Automatic mode additionally checks missing/cross-origin session
requests, wrong tokens, missing install confirmation, invalid signature, token
rotation and rejection of the old token after reboot. A fresh target-page visit
must contain no password/key input. Runtime tokens are omitted from saved reports.

Private exact source snapshots, frozen B/C/D artifacts and evidence are under
`diagnostics/2026-11-12-auto-update-auth-01/`. The USB observer opened the existing
spare console (a beta.2 startup was observed) and records subsequent OTA boots;
it does not program firmware or provide authorization to automatic mode. Final
hardware results are appended after completion. Main-project changes remain
uncommitted; the main repository remains private.

### Automatic-auth hardware attempt notes

The legacy beta.2 → beta.3 migration passed real OTA in 261,956 ms, moving from
app1 to app0 with accepted startup, matching journal transaction and unchanged
application settings. A fresh beta.3 page contained no key/password field and its
automatic session endpoint worked. The migration test used only the already saved
legacy credential; no user console lookup was required.

The first automatic beta.3 → beta.4 attempt passed its keyless session/confirmation/
signature admission checks and reached 8,064 consumed bytes, then the browser
reported a request timeout. Independent UART recorded
`BENCH phase=failed reason=cancelled_network_or_timeout`. No verification, boot
selection or beta.4 startup was observed. The controller's known LAN address
failed HTTP and ICMP checks while USB remained responsive; the underlying cause
of the connection loss is unestablished. The failure and original trace remain in
`c-to-d-attempt-01/`, not overwritten by a successful result.

After the abort was independently confirmed, a single deliberate RTS restart of
the isolated spare recovered accepted beta.3 with settings preserved and an idle
worker. The partial update did not resume. A fresh browser action then began a
second keyless attempt, using the same frozen signed beta.4 bytes. That test's
source status and outcome are in `recovered-status.json` and `c-to-d/`. Do not
infer that automatic authorization caused or repaired the network failure, or
claim first-attempt reliability from a subsequent passing retry.

Owner context during the retry: the owner reported refreshing the telescope/
controller screen around the first failure and suggested that as a possible
cause. Refreshing the page that owns an upload can discard its transfer session.
The automated attempt used an isolated browser, so the reported refresh does not
by itself establish the cause of that attempt's timeout. Retain the observation
without promoting it to a diagnosed firmware/network root cause.

### Automatic flow result: PASS after recorded network-abort recovery

The second keyless attempt passed with real public release/catalog/binary traffic
and controller flash/reboot responses. It received no key-file argument, performed
no password/key DOM entry, and completed beta.3/app0 → beta.4/app1 in **257,186 ms**.
Exact frozen D ELF, new boot, accepted startup, matching durable transaction and
unchanged application-settings record were confirmed. A fresh D page also had no
key/password field. Independent USB observed D's accepted startup with
`outcome=complete settings_preserved=1`, with no key printed by C or D.

The automatic session tests returned HTTP 403 for missing session-request header,
foreign Origin, wrong token and a pre-reboot token supplied with the new boot's
nonce. Missing install confirmation and an invalid signature returned HTTP 400
while the worker remained idle. The actual UI required confirmation but no key
entry, browser pairing, persistent browser storage or USB-console access. Session
tokens were not included in reports. The successful retry does not establish a
root cause or fix for the first connection loss; its separate failure evidence
and owner's refresh observation remain recorded above.

The spare is left running beta.4 with automatic home-LAN authorization, servo
operations excluded and its saved Wi-Fi/application record preserved. The main
repository remains private and local source changes remain uncommitted. Sanitized
public results/screenshots are in `acceptance-auto-auth.json`,
`automatic-update-complete.png` and `automatic-update-page.png` in the public test
repository and beta.4 prerelease. This remains bench validation, with operational
cover integration and power-loss/rollback qualification separate.

## 20. Configuration layout and global update badge — beta.5, 2026-11-12

The owner requested firmware updates integrated into Configuration, a compact blue
Update available badge between the Telescope Cover brand and menu on every page,
default-on automatic checking with a disable checkbox, and publication for the
owner to install using current beta.4. No controller update was authorized for
this increment; the board was explicitly left for owner installation.

The isolated OTA test UI now has shared Overview, Calibration, Configuration and
Manual Control navigation. The updater is in Configuration → Firmware updates,
alongside honest connection/about/recovery sections. The test build still excludes
servo/telescope workers: Calibration and Manual Control explain their unavailability;
no fake hardware telemetry or operational settings editor was added. This restores
the familiar navigation around the working updater, not operational motion control.

A single shared header badge contains exactly Update available, styled as a small
blue box around its text. It is centered between brand and menu at desktop sizes,
adapts to small screens and is shown only for a compatible newer candidate. Its
click opens Configuration, selects Firmware updates and focuses/scrolls that panel.
All navigation uses one page and preserves an in-progress update session. A
before-unload confirmation is requested during active installation.

The automatic-check checkbox defaults enabled and remembers a browser-only
preference (`cover.bench.autoCheck.v1`). Disabling it stops automatic release
requests, including on reload, while manual Check now remains available. Storage
failure leaves a working default-on session rather than an authorization requirement.
The boot-scoped authorization, signed manifest/hash, explicit confirmation and
worker/journal/startup behavior are unchanged. No key/pairing UI was reintroduced.

`tools/bench_assets.py` builds the same inline-CSS HTML and combined navigation/
updater script for target firmware and the loopback browser fixture. Updated unit
tests cover automatic preference default/persistence, manual checks while disabled
and no key storage. The full offline release gate passed. Isolated Chrome tests
at 1440, 1024 and 390 px passed badge size/color/centering, presence across all four
views, Configuration navigation/focus/dropdown, preference persistence/re-enable,
no-update badge hiding, and zero write requests. The measured desktop badge was
120.4 × 28 px centered at x=720 in a 1440 px viewport. A hypothetical beta.6 was
simulated only in that UI fixture; no beta.6 artifact was created or published.

Frozen beta.5 application: 845,072 bytes; 465,648 bytes OTA slot headroom;
ELF `328881ff669f7f1c6ab227a214ffcf2d5d6385fdf83a6937cea7211a33efa084`;
application SHA-256
`b9aa415f21d36de43db738cf49dd4604864bfa5e41fc92db436fea120064ac3f`.
The signed exact beta.4 (`ed3f7046…`) → beta.5 transition was published to the
public test repository in artifact commit `220c66f`, with the prerelease
`https://github.com/Kbdavis/Telescope-Cover-OTA-Test/releases/tag/v0.1.0-beta.5`.
Actual hosted binary size/hash matched the frozen artifact.

A separate read-only real-browser check then loaded the actual beta.4 page and
observed Update available for beta.5 from real public GitHub/Pages responses.
Confirmation remained unchecked, Install remained disabled and all requests were
GET. The controller retained beta.4, its original boot ID/ELF and idle state. No
flash, installation, USB access, reboot or motion was performed. The new beta.5
UI has not been accepted on hardware; the owner will perform that installation.
Private frozen source/artifacts, fixture screenshots, exact board-before status,
readiness screenshot and result are in
`diagnostics/2026-11-12-config-update-ui-01/`. Public validation explicitly separates
fixture testing from current-receiver discovery and pending owner installation.

Owner handoff: open the controller's current page, let it check or use Check now,
confirm beta.5 and choose Download and install. Keep that uploading page open until
it confirms the reboot; then refresh to load the Configuration/header layout. Once
beta.5 is installed it is the latest published candidate, so the blue header badge
will appear when a later compatible release is published, not merely because this
UI feature exists. Main source remains uncommitted and the main repository private.

Final handoff observation: after the passing GET-only readiness check and public
handoff publication, the controller reported Receiving with total 845,072 bytes
matching beta.5. Another client had started the installation before final handoff.
Automation did not click confirmation/install or send POST/start/chunk/finish
requests. The initial expectation of an idle board therefore no longer held;
this was recorded in `board-handoff.json` and the transfer was left untouched.
The owner was told to keep the uploading page open until confirmed reboot, then
refresh for the new layout. Only our isolated read-only browser and loopback fixture
were closed. Do not confuse the owner's transfer with automated hardware acceptance
of the new beta.5 UI.

## 21. Complete-controller candidate and transfer reduction (2026-11-12)

The owner requested the first two transfer improvements, then expanded the task
to a full controller release while explicitly leaving production `192.168.1.43`
unchanged. The complete `web_control_multiturn_ota` candidate now integrates signed
browser updates into the operational maintenance/startup/journal path and retains
the normal controller UI and functionality. See
[FULL_CONTROLLER_RELEASE_CANDIDATE.md](FULL_CONTROLLER_RELEASE_CANDIDATE.md) for
frozen beta.9 identity, acceptance evidence and remaining gates.

Chunks are 768 bytes and the same POST returns worker-completed transaction/offset
acknowledgement. No per-chunk status polling is needed. The bounded HTTP adapter
supports nonblocking deferred responses with a fixed timeout; existing request
limits remain unchanged. New tests cover premature completion, connection loss,
timeout, stale/incorrect acknowledgements and no blind replay. Bench clients retain
capability-negotiated compatibility with the older receiver. Hardware throughput
has not been measured for the complete controller.

The full candidate was bootstrapped on the backed-up spare by USB because the
bench-only receiver cannot accept an operational product image. The production
controller was inspected using GET only and has an available idle development
receiver, but currently reports torque ON. The owner left the spare servo without
external power; full OTA admission correctly refuses that state. Powered full-path,
interruption/rollback, cold-start/profile recovery and loaded-workload memory
qualification remain blocked. Neither bench success nor compilation substitutes
for these gates. No full-controller binary/tag was publicly released, and the
production controller was not changed. The public complete-controller catalog is
intentionally empty while qualification is pending.
