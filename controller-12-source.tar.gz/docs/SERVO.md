# ST3215 driver, first version

## Estimated cover travel — 2026-10-28

Based on experiments with the covers, the user estimates the largest required
travel between CLOSED and OPEN to be approximately **2,000 encoder counts**
(about **176° of servo-shaft rotation**). This is the travel in either direction,
not the sum of an opening and closing cycle. It describes actuator rotation,
not necessarily the cover's opening angle.

Treat this as a mechanical planning estimate, not a validated maximum or a
firmware travel limit. Calibrate and verify each assembly's actual endpoints
and safe path. If travel crosses the encoder's 4095 → 0 boundary, the intended
path must be accounted for; simply subtracting the two raw readings does not
necessarily give the physical travel.

## Rollover release gate — local implementation, 2026-10-28

Subsequent approved commissioning validated a fixed locked RAM reference
85 → 1328, shifting the required physical path away from raw zero. This build
is now installed on cover-dev.local. The detached crossing-and-return test
passed; controller restart and calibration-basis migration passed. No EEPROM
unlock occurred. See [measured results and current behavior](SERVO_REFERENCE_COMMISSIONING.md).
The following gate describes actual raw-zero crossing, which remains disabled.

The commissioned phase-12/offset-85 unit has demonstrated only the documented
small unloaded bidirectional moves, not physical 4095/0 crossing. The exact
40-byte configuration validation remains unchanged. Production crossing goals remain gated pending physical qualification. Circular
application coordinates now preserve the explicitly taught opening arc through
zero; the detached bench build admits only ≤100-count crossing segments at speed
≤100 / acceleration ≤10 on the exact factory profile. No mode, phase, resolution, offset,
limits or other persistent servo register is rewritten. This gate is not a
2,000-count mechanical maximum and does not certify shorter loaded paths.

Application CLOSED zero, explicit opening direction, continuous actuator travel,
0–100% travel estimates, legacy migration and qualification guidance are described
in [CALIBRATION.md](CALIBRATION.md). The user does not select raw travel limits or manage rollover. Any later
hardware-reference adjustment requires a baseline, exact proposed writes and
approval. The new duration model is a planning estimate; speed scaling,
acceleration, full travel and loaded behavior still need bench validation.
Implementation used offline checks. The later authorized development OTA
installation is documented in [CALIBRATION.md](CALIBRATION.md#development-installation--2026-10-28);
it changed no servo EEPROM and did not movement-test the new firmware.

The detached-shaft boundary test on 2026-10-28 requested 4050 → 54 at speed
100 / acceleration 10. Valid feedback decreased to 4029 before FAULT and verified
torque OFF (stationary read afterward: 4027). No return test or automatic recovery
was performed. This exact mode-0 profile takes the wrong route for a wrapped
absolute goal; it is not qualified for transparent boundary motion. See the
[measured test evidence](CALIBRATION.md#detached-shaft-boundary-test--2026-10-28).

## New hardware commissioning with the web-control firmware

The web-control firmware automatically runs read-only startup checks on every
boot, including first setup. At configured servo ID 1 it requires model 777,
mode 0, minimum 0, maximum 4095, and resolution 1. The legacy profile requires
phase 0 and offset 0; the commissioned factory profile instead requires an exact
40-byte identity/configuration match (firmware 3/9, model 777, phase 12, offset 85). Failed
communication is not accepted as valid configuration. It also checks torque
and consistent position feedback before allowing setup or normal control.
An ordinary cold boot requires torque OFF; an explicitly prepared software
restart has a separate retained-torque path.

A configuration failure blocks motion and appears as a startup fault. The web
status names the mismatched fields with their observed and required values.
These required values describe the controller's supported profile, not a claim
that every other value means a defective servo. A recheck repeats validation;
it cannot bypass a mismatch or reprogram the servo.
The web firmware logs the rejected values as `SERVO CONFIG invalid` on USB and in the
Debug event log, with the expected values on USB. A failed register read instead
logs `SERVO READ failed`; do not interpret it as a confirmed configuration mismatch.
The read-only diagnostic build below can also inspect the register values. The
software does not reset, center, or rewrite servo EEPROM automatically.
Repair requires deliberate inspection; do not use the old Waveshare SC-series
configuration interface with this servo.

For a new servo/controller, verify board wiring and keep the mechanism
disconnected during initial checks. A passing servo with no saved cover
calibration enters calibration-only setup: begin supervised teaching,
then teach and save the physical endpoints under supervision. If replacing
a servo on a controller with saved settings, re-establish those limits and
endpoints; existing settings do not prove the new assembly is safe. Passing
startup checks never starts an automatic test movement or proves cover clearance.

### Fresh-servo inspection, 2026-10-27

Supervised detached-mechanism commissioning later that day confirmed a small
bidirectional move with the factory profile unchanged. The isolated
`factory_motion_bench` build required an exact match to all 40 documented
identity/configuration bytes in the backup before permitting motion. At speed
100 and acceleration 10, the starting position was 3429; the +20-count command
targeted 3449 and settled at 3446 in approximately 0.53 seconds, including
settling confirmation. The return targeted 3429 and settled at 3430 in
approximately 0.43 seconds. Torque was confirmed OFF after each move, and the
post-test configuration still matched the backup exactly. Evidence is retained
locally in `diagnostics/factory-bench-20261027T232141Z/`.
The prior OTA-enabled controller firmware was restored and verified afterward;
OTA reported available with startup accepted, and servo torque remained OFF.

This proves small unloaded bidirectional motion for this unit's phase 12 /
offset 85 profile; it does not establish loaded cover operation, speed scaling,
full-range behavior, or compatibility with other units. Production validation now accepts this exact backed-up profile as well as the
legacy profile. This does not establish higher-speed or loaded-cover performance;
start calibration with the tested speed 100 and acceleration 10. The bench build has no automatic boot movement,
uses limits of starting position ±30 counts, and requires a USB heartbeat within
500 ms during movement, with a five-second movement timeout. It writes only
temporary torque and motion registers, never persistent configuration.

A servo confirmed by the user to be brand-new and never configured reported
ID 1, model 777, mode 0, limits 0–4095, phase 12, resolution 1, and offset 85.
It responded with position 2420, torque OFF, and approximately 12.2 V. The
original validator rejected its phase and offset; the angle limits are valid.
This differs from the earlier servo's invalid limits of 5120 and 60163.
Phase 12 and offset 85 alone must not be described as proof of corruption.
The user initially clarified that the servo was hot-plugged and its power
had not been cycled. After the small bench test, the user confirmed cycling
the external servo supply. The controller also reported a fresh POWERON boot;
its startup configuration check again reported phase 12 and offset 85.
Fresh telemetry showed position 3429, torque OFF, 12.2 V and 36 °C, with OTA
startup accepted. This confirms those rejected settings survived the power
cycle; it is not a second full 40-byte capture. The read-only observation is
saved in `diagnostics/factory-bench-20261027T232141Z/post-power-cycle.json`.

Waveshare's [ST memory table](https://docs.waveshare.com/Memory_Map_Explanation/ST_Servo_Memory_Map_Explanation)
describes phase as a special-function bitmask, including speed behavior/units,
and offset as a position-reference adjustment. It advises against changing
phase without a specific need. Do not reset these fields merely to silence
the warning or relax validation without verifying the motion implications.
Support for an additional profile needs controlled commissioning and fresh
cover calibration. Only the exact commissioned snapshot is now additionally
accepted; failed reads, other profiles, and invalid mode/ranges remain blocked.

The production web firmware was updated to report the rejected values, and
startup inspection left servo EEPROM and torque unchanged. That initial inspection
did not include movement. Local evidence and the matching build are archived under
`diagnostics/servo-config-20261027/`.

Before any approved programming, capture a read-only baseline of the readable
persistent servo configuration and identity/version fields, saving both raw
bytes and decoded values. Require matching repeated successful reads and keep
the original baseline separate from later test captures. The existing startup
logs contain only selected fields; they are not a complete configuration backup.
An ESP32 flash backup does not include the servo's separate stored settings.
Restoration should use a reviewed list of changed writable configuration
registers, with read-back verification and explicit approval. Never replay a
whole register dump: it can include read-only fields and live control registers.

The `servo_backup` environment is a temporary USB-only collector. It retains
the production partition layout and compiles with `COVER_SERVO_READ_ONLY`,
which rejects servo write instructions before transmission. It requires model
777, ID 1, and torque OFF, then captures registers 0–39 three times and reports
success only when all copies match and torque remains OFF. A configuration
mismatch does not prevent this read-only backup. Collection stops afterward;
there is no web server, USB forwarding, or restore command. Preserve the current
controller firmware/boot metadata before installing it and restore them after
capture. This captures documented configuration, not the servo's internal
firmware or undocumented storage. An ESP32 reset does not cycle servo power,
so the capture alone does not prove persistence across a servo power cycle.

Verified backup on 2026-10-27: three identical captures of registers 0–39,
zero retries, model 777, firmware bytes 3/9, ID 1, phase 12, offset 85, mode 0,
limits 0–4095, resolution 1, and P/D gains 32/32. Torque was OFF before and
after collection. Raw bytes, decoded JSON, capture log, and a readable report
are stored locally in `backups/new-servo-20261027T230952Z/`. No servo programming
or movement commands were performed.

`ServoController` uses an already initialized Arduino `Stream`. Constructing it
does no I/O. The default `esp32dev` build leaves it unused. The separate
`servo_diagnostic` build initializes UART1 and invokes read-only diagnostics;
see HARDWARE.md for board wiring and bus baud rate.

Implemented operations:

- Ping the configured ID (default 1) and read the ID/configuration registers.
- Validate mode 0, minimum 0, maximum 4095, resolution 1, and either the legacy
  phase 0 / offset 0 profile or the exact commissioned factory snapshot.
- Read position separately for frequent polling, or a full telemetry snapshot.
- Decode signed speed, relative load, and raw current. Voltage is in decivolts;
  temperature is in degrees C. Current remains raw pending bench verification.
- Release torque, or enable it after validating configuration and staging the
  measured position as the goal after two consistent successful reads. An isolated
  valid-looking zero cannot become a staged rollover goal. Enabling torque can still physically move a
  loaded mechanism; the controller must authorize it.
- Command absolute position with speed and acceleration. Torque must already
  be enabled. Both measured and target positions must lie inside the caller's
  mechanical limits. Zero speed/acceleration are rejected in this version.

There is no public arbitrary-register write, EEPROM unlock, mode change, or
automatic configuration repair. Only RAM goal registers 41–47 and torque
register 40 are written. Writes require a status response and are not retried:
a lost acknowledgement does not prove the command was not executed.

## Communication and limits

Replies are checked for ID, length, checksum, and device error status before
data is accepted. Output arguments remain unchanged on failure; callers must
check every result and never present an old value as a fresh sample.
Read/ping communication failures get at most three attempts, each with a 20 ms
receive deadline. Device-reported faults are returned immediately.

This is a synchronous first driver, intended for one caller on a dedicated bus.
Read waits are bounded and yield to the scheduler. Compound operations include several bounded read/response deadlines; torque
enable now requires two consistent position reads before staging a goal.
The Stream implementation must provide bounded writes. Before integrating
web controls, evaluate scheduling and stop latency; do not run these operations
concurrently from request handlers.

The serial protocol has no transaction sequence number. Delayed replies and
adapter echo behavior require bench testing; draining queued bytes alone cannot
guarantee a reply belongs to the latest request. A valid but anomalous encoder
sample still requires filtering by the cover controller.

The caller remains responsible for sensor/interlock checks, motion timeout,
direction monitoring, torque release on unexplained faults, and FAULT state.
Acknowledgement confirms protocol success, not physical motion or cover state.
No automatic fault recovery or movement monitoring is implemented here.

## Offline verification

```sh
pio run
c++ -std=c++11 -Wall -Wextra -Werror -Itests/host -Isrc \
  tests/host/servo_driver_test.cpp src/servo_controller.cpp \
  -o /tmp/telescope-servo-driver-test
/tmp/telescope-servo-driver-test
```

The fake-bus checks exercise retries/timeouts, checksum and device-error
rejection, unchanged outputs on failure, configuration and travel guards,
torque staging, command encoding, signed telemetry, and no write retries.
They do not replace physical testing.

## Next bench session

Confirm UART pins, bus circuitry, baud rate, and status-return behavior before
initializing transport. Start with ping and read-only configuration/telemetry.
ID and model-number readback are implemented.
Compare the results with the known-good configuration in AGENTS.md. Verify
torque behavior and conservative short moves only after mechanical clearance
and controller-level safety handling have been established.

Protocol references: Feetech's
[packet implementation](https://github.com/ftservo/FTServo_Arduino/blob/main/src/SCS.cpp)
and [STS operations](https://github.com/ftservo/FTServo_Arduino/blob/main/src/SMS_STS.cpp).
The project driver is ST3215-specific and contains no SC-series setup logic.

## Read-only diagnostic build

```sh
pio run -e servo_diagnostic
pio run -e servo_diagnostic -t upload --upload-port /dev/cu.usbserial-0001
pio device monitor -b 115200 -p /dev/cu.usbserial-0001
```

Complete the backup in RECOVERY.md before uploading. `COVER_SERVO_READ_ONLY`
rejects every instruction except ping and read before transmission. The firmware
waits three seconds at startup, requires model 777 and valid configuration,
then reads position once per second and telemetry every five seconds for 60
samples. Initial failures halt the run; sample errors are counted without using
stale data. A final configuration check and cumulative retry count are printed.
Polling stops at completion. Reset restarts the test; there is no movement,
torque change, web interface, or USB forwarding in this build.

The offline read-only guard test can be run with:

```sh
c++ -std=c++11 -Wall -Wextra -Werror -DCOVER_SERVO_READ_ONLY \
  -Itests/host -Isrc tests/host/servo_read_only_test.cpp src/servo_controller.cpp \
  -o /tmp/telescope-servo-read-only-test
/tmp/telescope-servo-read-only-test
```

## Bench result — 2026-09-30

The `servo_diagnostic` build was uploaded at 115200 baud after creating and
verifying the complete recovery image described in RECOVERY.md. The new driver
communicated directly over UART1 at 1 Mbps:

- ID 1, model 777; all critical configuration checks passed at start and finish.
- Torque read OFF at startup; no servo write instructions sent.
- 60 position reads over approximately one minute, all at 2045 counts.
- 12 telemetry snapshots: 12.2–12.3 V, 33–34 C, zero speed/load/current,
  moving flag false.
- Zero failed operations and zero retries throughout the run.
- Polling stopped at completion. The diagnostic firmware remains installed.

The capture is stored locally in `backups/diagnostic-20260930.log`.
This validates read-only communication for this short bench run. Torque and
motion methods, sensor interlocks, controller safety, and web integration still
require implementation/integration and separate tests. Both PlatformIO build
variants and the host driver/read-only guard tests passed. The diagnostic build
emitted an unused scaffold-controller warning in main.cpp during that test;
the subsequent motion-controller change removed that unused instance.

Subsequent status: the motion bench firmware replaced the diagnostic build and
passed the supervised forward/return test recorded in [MOTION.md](MOTION.md).
