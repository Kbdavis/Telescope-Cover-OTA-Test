# Hardware assumptions

Target: Waveshare Servo Driver with ESP32, observed ESP32-D0WD-V3 revision 3.1,
and ST3215 servo ID 1. These observations come from AGENTS.md; no hardware was
queried during scaffolding.

The build uses PlatformIO's generic
[`esp32dev` Arduino target](https://docs.platformio.org/en/latest/boards/espressif32/esp32dev.html).
On 2026-09-30, esptool identified the connected ESP32-D0WD-V3 revision 3.1,
40 MHz crystal, and 4 MB flash, matching this target's flash size.

The diagnostic uses UART1 RX GPIO 18, TX GPIO 19, and 1,000,000 baud, following
Waveshare's [board source](https://github.com/waveshare/Servo-Driver-with-ESP32/blob/main/ServoDriver/ServoDriver.ino)
and [UART initialization](https://github.com/waveshare/Servo-Driver-with-ESP32/blob/main/ServoDriver/STSCTRL.h).
Only the wiring and UART setup are referenced; the SC configuration code is not
used. The board provides the servo bus interface; no extra direction GPIO is
configured in its reference initialization. Sensor pins remain unassigned.

The historical Mac serial-forwarding link ran at 115200 baud. That does not
establish the servo bus baud rate. `monitor_speed` is for USB diagnostic logs.

ST3215 absolute positions are 0–4095. Before motion, validate mode 0, minimum 0,
maximum 4095, and phase/config 0. Never apply SC-series configuration or silently
repair EEPROM. Mechanical endpoints remain uncalibrated.

## Controller enclosure prototype

The [horizontal controller enclosure](../cad/controller_case_v1/README.md) uses
the earlier Fusion RevD case and the user's edited V8 servo assembly as fit
references. It contains the barrel plug, provides a split exit for the measured
4 × 2 mm flat power lead, and adds a removable curved mount and covered servo
cable bridge. The proposed path budgets approximately 132 mm of the user's
140 mm servo lead, including a 4 mm bend/fit allowance. This is CAD-checked
prototype geometry; actual cable fit, print tolerances, and sealing remain
unverified. See its build notes before printing or mounting.
