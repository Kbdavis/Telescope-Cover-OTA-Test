# Exhibited bugs — investigation handoff

## Latest evidence: 2026-10-09, servo feedback loss

This update supersedes the older deployment/calibration snapshot below.
Four manual moves starting at 477/490 toward 577/590 failed after roughly
2.7 seconds with repeated position-read failures, while heartbeat timing
remained healthy. After the user manually relocated the arm to about 3482,
recovery was also blocked by the active 450–2075 commissioning limits.
These are distinct issues; widening limits does not fix communication failure.

New firmware adds guarded faulted commissioning-limit revision and detailed
servo diagnostics (see RECOVERY.md). After upload, repeated passive servo
telemetry reported **5.2 V**, despite the intended external 12 V supply.
Position remained 3482 and torque OFF. Supply/power-path trouble is now a
leading hypothesis, not a confirmed component diagnosis. The supervised
torque test was withheld on this evidence; no torque or movement command was
sent. Verify actual supply voltage and connections before repeating it.
Current calibration is missing; do not restore historical endpoints blindly.

Evidence: `diagnostics/20261009T222830912880Z/serial.log`; deployed ELF hash
`da14bc741771573f28aa281dc73b862d1f68182d363f8e28ce097c4c9300f544`.

Updated: 2026-10-01, approximately 19:08 UTC (12:08 Arizona time).

## Current disposition

The user reports the bugs are not currently showing up and is moving on to
other work. Do not treat the investigation as proof of permanent resolution.
Do not start movement tests, clear faults, reset, or flash merely to refresh
this document. Read AGENTS.md before changing safety or architecture.

The latest capture, reviewed for this handoff, contains **43 completed OPEN/CLOSE
endpoint moves and no motion faults**. It contains an initial association failure
(reason 203), followed by successful connection; no recurrence of reason 8 was
recorded in the reviewed portion. Recent health lines showed both loops running,
no dropped diagnostic logs, and signal around −81 to −83 dBm. This is a limited
bench observation, not unattended-reliability validation.

| Issue | What is established | Status |
| --- | --- | --- |
| Heartbeat expiry during movement | Response-gated browser scheduling added avoidable delay to already-slow HTTP round trips | Correction deployed; no recurrence in latest reviewed capture |
| Wi-Fi remains disconnected | Arduino skips automatic reconnect for reason 8; application has no independent retry policy | Recovery gap identified; reconnect/backoff fix **not implemented** |
| Original Wi-Fi disconnect | Reason 8 observed twice while firmware continued running | Origin unresolved; expanded instrumentation deployed |
| Apparent firmware crash | Webpage outages were observed; continuous captures showed functioning firmware during later outages | No captured panic/backtrace proving a firmware crash |
| No web fault recovery | Earlier web interface could not clear a latched motion fault | Explicit checked recovery deployed |

## Hardware, software and deployment snapshot

- Waveshare ESP32 servo controller, ST3215 ID 1/model 777; PlatformIO Arduino
  environment `web_control`, espressif32@7.1.3.
- USB `/dev/cu.usbserial-0001`, console/upload 115200 baud. Servo bus is separate.
- Last verified home-network URL: `http://192.168.1.135/`; DHCP can change it.
- Latest deployed ELF SHA-256:
  `f2ca990ac9e5594d011d890158e45200a034c178e2f896631a902c56b946558a`.
- Motion heartbeat lease: **500 ms**. Movement timeout: **5000 ms**. Web speed:
  100; acceleration: 10. These safety limits were not relaxed during debugging.
- Last observed saved calibration: allowed domain 0–4000, OPEN=3893, CLOSED=8.
  These are user-adjusted bench settings, not validated mechanical limits.
  Earlier captures used CLOSED=1084 and narrower bounds; do not silently restore
  old values. Re-read settings when needed.
- Recent changes remain uncommitted at this handoff, including UI, recovery,
  diagnostics, capture/preview tools, tests, and documentation. Preserve this
  work; do not reset the working tree. Local build artifacts may differ after
  a future compile—use archived ELF files for old crash decoding.

## 1. Heartbeat expiry: confirmed timing mechanism

The user initially observed faults around 2800 during Close, sometimes during
Open or manual jogs, while the Mac browser stayed in the foreground. Raw firmware
fault text `Safety interlock` means that the web movement lease expired; there
are no physical limit sensors producing this message. It was not evidence of a
travel limit being reached or the five-second movement timeout expiring.

The conclusive correlated example was a +100 manual step from 3595 toward 3695,
client 86117353, browser generation 79:

| Event | Browser monotonic time | ESP32 uptime |
| --- | --- | --- |
| Heartbeat 1089 sent | 230901 ms | — |
| 1089 HTTP handler / worker renewal | — | 280445 / 280449 ms |
| 1089 response completed (410 ms round trip) | 231311 ms | — |
| Heartbeat 1090 sent | 231406 ms | — |
| Fault, heartbeat age 501 ms | — | 280947 ms |
| 1090 HTTP handler / worker handling | — | 280977 / 280982 ms |

The browser waited **95 ms after completion** for its next interval tick, making
its send gap **505 ms**. HTTP handling times were **532 ms apart**. Worker delays
were only 4–5 ms. The page remained visible and timer callbacks continued normally.
Heartbeat 1090 arrived after the fault and correctly did not restart movement.
Browser and ESP32 timestamps have different origins; compare intervals or match
sequence numbers, not absolute times between clocks.

The underlying source of the slow HTTP round trip is not conclusively established.
Weak Wi-Fi is a plausible contributor. There was no recorded web-loop stall at
this particular fault, and it was not caused by a motion-worker queue backlog.

### Deployed corrections and their limits

1. Movement generations prevent delayed responses/errors from earlier activity
   from cancelling a newer movement's heartbeat. Regression tests demonstrated
   the defect; this correction alone did **not** resolve the observed failures.
2. `WiFi.setSleep(false)` disables ESP32 modem sleep. In paired non-motion probes,
   maximum heartbeat response time fell from 443 to 233 ms. It improved latency
   but did **not** eliminate every subsequent expiry.
3. After a successful slow heartbeat response, the browser now schedules another
   send immediately if 100 ms have elapsed since the previous send. It does not
   wait for the next interval tick. There is still at most one heartbeat in
   flight. Stop, failure and generation guards remain in place.
4. Heartbeat diagnostic form bodies no longer start with an empty `&` field.
   That instrumentation error caused Arduino parser messages on each heartbeat;
   it was not present in the original pre-instrumentation failures.

The final two corrections are in the latest deployed build. The first-failure
snapshot/export and per-heartbeat instrumentation are also still enabled.
A genuine connection loss can still correctly expire the lease; this fix does
not make an unreliable network reliable. Do not simply increase the watchdog
threshold or remove supervision to hide the symptom.

## 2. Wi-Fi disconnect and failure to reconnect

Two continuous captures showed disconnect reason **8 (`ASSOC_LEAVE`)**, later
followed by lost IP. The installed Arduino SDK source explicitly skips reconnect
for this reason, even with auto-reconnect enabled:

`~/.platformio/packages/framework-arduinoespressif32/libraries/WiFi/src/WiFiGeneric.cpp`

The reason is defined in the installed SDK's `esp_wifi_types.h`. Our
`src/web_server.cpp` starts the fallback AP after 20 seconds but has no separate
STA reconnect/backoff loop. Consequently the controller can remain unavailable
on its home IP until restarted, while still running normally and serving its
setup network. A bounded reconnect policy was proposed but **has not been added**.
Any future reconnect policy must preserve setup access and latched motion faults,
and must never resume an interrupted movement.

In the second capture, heartbeat fault uptime was 280947 ms; Wi-Fi disconnected
at 302520 ms, about 22 seconds later. The later event is not proof of the cause
of the earlier heartbeat delay. A similar separation occurred in the first
continuous capture.

Reason 8 alone does not prove that the application intentionally disconnected,
or identify which device originated the disassociation. The application has no
routine disconnect call. SDK-internal actions, access-point behavior, and radio
conditions remain possibilities, not established causes.

### Instrumentation deployed for the next occurrence

- `WIFI LINK` once per second: BSSID, channel, RSSI, Wi-Fi mode, sleep and
  auto-reconnect settings. No scanning or promiscuous mode is enabled.
- `WIFI DISCONNECT`: reason number/name, BSSID, driver-provided disconnect RSSI,
  prior sampled RSSI/age and association age. Check `sample_valid`.
- `WIFI EVENT`: station start/stop, association, authentication changes, IP
  acquisition/loss and AP events; IP acquisition includes gateway/netmask.
- `WIFI LOCAL`: marker immediately before every application-controlled mode,
  modem-sleep, STA-start or fallback-AP operation. Events show the last action
  and its age. Proximity is evidence for correlation, not proof of causation.

The SDK event has no frame-origin/local-origin flag. If these logs do not
establish the trigger, correlate the BSSID and timestamp with router logs or an
external wireless management-frame capture. Do not instrument the motion
controller with disruptive scans simply to gather more data.

## 3. Suspected crash versus network outage

Users saw a disconnected webpage and initially suspected a crash. Before
continuous capture, USB monitoring showed POWERON_RESET followed by reconnection.
That observation was inconclusive: opening or reconnecting a serial port can
reset this board despite setting DTR/RTS false in software.

Later continuous captures showed uptime and HEALTH logs continuing across Wi-Fi
outages, stable heap, and small web/motion loop ages. No panic or reboot was
recorded during those outages. They are confirmed network availability failures,
not evidence of a firmware crash. This does not rule out an uncaptured earlier
crash or a future power problem.

Diagnostics run in a separate task. HEALTH appears every five seconds with
uptime, heap/minimum heap, Wi-Fi/RSSI, loop ages, and dropped-log count. A bounded
queue keeps UART output out of the motion task. Completed loop stalls of at
least 100 ms are logged separately. Monitor logging overhead and `log_dropped`;
per-heartbeat logging is temporary diagnostic instrumentation.

## 4. Fault recovery already implemented

The page exposes **Clear fault · no movement** during a motion fault, with a
separate inspection acknowledgement. `/api/recover` checks authorization and
inspection; the worker clears queued commands/ownership and checks model 777.
Controller recovery confirms torque release, critical servo configuration, and
two consistent in-range positions. Success enters UNKNOWN with torque off;
it does not resume the old command. Failed checks leave the fault latched.
Startup validation failures still require diagnosis/reset. No EEPROM repair or
travel-limit widening is part of recovery.

## Evidence locations and capture state

All captures are local and Git-ignored under `diagnostics/`. Each includes
`serial.log`, `manifest.json`, and copies of `firmware.elf`/`firmware.bin`.
The firmware files contain compiled Wi-Fi credentials; keep them private.

| Capture folder | Contents |
| --- | --- |
| `20261001T183454666661Z` | Initial continuous capture; successful cycles, heartbeat fault and later reason-8 outage |
| `20261001T184441027593Z` | Correlated heartbeat HTTP/worker timing; later Wi-Fi loss; saved `cover-browser-trace.json` |
| `20261001T190000302914Z` | Latest deployed build; expanded Wi-Fi instrumentation and immediate heartbeat scheduling |

The browser export originally came from
`/Users/kirkdavis/Downloads/cover-browser-trace.json`; a preserved copy is in the
second capture folder, so future downloads need not overwrite the evidence.

At handoff, continuous capture was still running for the third folder through
`tools/capture_diagnostics.py` (agent terminal session 73984). Verify process
state rather than assuming that session remains alive in a later environment.
Stop the existing capture before uploads or opening another serial monitor;
archive its log and ELF first. No capture stop, firmware upload, reset or servo
command was performed merely to create this handoff.

## If the bug returns

1. Keep the controller powered and the browser tab open; avoid resetting first.
2. Download **Connection diagnostics → Download browser trace** before refreshing.
   It freezes the first failure and retains a bounded recent-event ring; reload
   discards the browser-only evidence.
3. Preserve the ongoing USB capture and matching ELF. Confirm its hash against
   BOOT `elf_sha256` or status `firmware_id` before decoding a backtrace.
4. Match client/sequence between browser request timing, `HB HTTP`, and `HB WORK`.
   Check whether the delay was browser scheduling, HTTP/network handling, or
   worker queueing. HTTP handler time is after parsing, not radio packet arrival.
5. For a network outage, compare signal/BSSID/channel history, reason and local
   action markers; check whether both loops kept running. Repeated reason-8
   non-reconnection is the known unimplemented recovery gap.
6. Only perform further motion tests with the operator supervising and the
   mechanism clear. Preserve the current safety deadline and fault latch unless
   a deliberate, reviewed design change is justified.

For capture commands and backtrace decoding see [DEBUGGING.md](DEBUGGING.md).
Relevant source: `data/control.html`, `src/web_control.cpp`, `src/web_server.cpp`,
`src/diagnostics.cpp`, `src/cover_controller.cpp`, and
`tools/capture_diagnostics.py`.

Validation already performed: web control regression tests (including replay of
a 410-ms heartbeat response and suppression after Stop), host controller safety
tests, capture/redaction/artifact tests, successful firmware compile/upload,
and live build-identity checks. Re-run checks appropriate to any future changes;
passing these checks does not establish long-duration unattended reliability.

## Follow-up: loaded-cover manual positioning

After attaching the real cover, the operator reported full OPEN/CLOSE working
but 100-count jogs timing out. Measurements before torque release were target
583 / actual 569 and target 584 / actual 571: repeatable 14/13-count shortfalls.
A separate live snapshot confirmed Movement timeout at 5008 ms with a healthy
147-ms heartbeat age; its post-release position cannot establish pre-release
error. The cause of loaded settling error is not yet proven.

The requested change accepts manual targets within 20 counts only after five
valid readings spanning at most 3 counts. OPEN/CLOSE remain at 3-count tolerance.
The change does not add holding torque or modify safety deadlines. See MOTION.md
for details. Loaded-cover physical retesting is required after deployment.

Manual-jog tolerance deployment verified on 2026-10-01 at approximately 21:39 UTC:
controller ready, UNKNOWN, position 484, torque OFF. The running ELF matches
`diagnostics/20261001T213914481012Z/` (SHA-256
`565d9794bf98124c0f59bcd60aa0e2aa389727bdd987a3b90a2c42eeb7f72354`).
Capture resumed in agent terminal session 55183; the earlier capture was stopped
and preserved. This supersedes the earlier deployment/capture snapshot above.
No movement commands were sent during deployment; user physical testing remains.

## Follow-up: cover drops after successful jog

After the 20-count tolerance upload, the user reported the cover rising then
dropping sooner. Earlier acceptance followed by the existing torque release
is a plausible explanation; no powered holding measurement was collected to
prove it. A separate, default-off supervised holding mode has now been added
locally: it retains torque after single manual steps and between subsequent
owner-issued steps. See MOTION.md for exact behavior and limitations.

This holding change was uploaded on 2026-10-01; **physical testing remains pending**. Tests/builds do
not authorize unattended loaded operation. Stop, page loss and faults still
release torque; the software cannot prevent a gravity-driven fall on power loss.
The user must mechanically support the cover for first testing. No hardware
commands or reset were issued while implementing this change, and the existing
capture/running firmware were left alone. OPEN/CLOSE behavior is unchanged.


Holding-mode deployment verified at approximately 21:51 UTC on 2026-10-01:
ready, UNKNOWN, position 483, torque OFF, no fault; Home Wi-Fi connected.
The served page contains the new holding option and the running firmware matches
ELF SHA-256 `a289c018ff9f1c1893f670e383a3037f6e63761c3308ad272b7cb520af6e8cef`.
Passive USB capture resumed in `diagnostics/20261001T215127082390Z/`
(agent terminal session 9708), with matching archived firmware. Opening capture
coincided with a POWERON boot, as previously observed with this USB driver.
No movement commands were sent during deployment verification.
