/* Fixed retained evidence is fetched only while its Debug disclosure is open. */
(() => {
 'use strict';
 const api=window.coverAPI,{state}=api,panel=document.getElementById('debug-retained');
 let data=null,error='',receivedAt=0,attemptAt=-Infinity,pending=false,ticket=0;
 const visible=()=>panel.open && state.view==='debug' && !document.hidden &&
  (state.debugSession || state.network?.enable_debug_tab) && !state.session?.setup_only && api.freshCover() &&
  !state.cover?.moving && !state.cover?.holding && state.cover?.maintenance?.owner!=='ota';
 const text=(id,value)=>{document.getElementById(id).textContent=value;};
 const number=v=>Number.isFinite(v)&&v>=0;
 const seconds=v=>number(v)?(v/1000).toFixed(1)+' s':'Unavailable';
 const heap=c=>c&&number(c.free_heap)&&number(c.minimum_heap)?`${c.free_heap} / ${c.minimum_heap} bytes`:'Unavailable';
 const brief=(s,n)=>typeof s==='string'?s.slice(0,n):'?';
 const identity=c=>c?`${brief(c.firmware,12)} · boot ${brief(c.boot_id,8)}`:'None recorded';
 function render(){
  text('retained-status',error || (!data?'Open to read saved failure evidence.':
   !api.freshCover()?'Controller offline — showing the last downloaded summary.':
   api.now()-receivedAt>10000?'Saved summary has not refreshed recently.':'Saved evidence, separate from live metrics.'));
  text('retained-reset',data?`${data.reset_reason} · ${data.retained_boots} boot(s) in this retention period`:'Unavailable');
  const w=data?.wifi,f=data?.fault;
  text('retained-wifi',!w?'None recorded':w.active_in_recorded_boot?
   (w.same_boot?'Unrecovered in this boot':'Unresolved in an earlier boot'):'Recovered in the recorded boot');
  text('retained-reason',w?`${w.first_reason} / ${w.last_reason}`:'None recorded');
  text('retained-link',w?`${w.rssi<0?w.rssi+' dBm':'RSSI unavailable'} · ${w.bssid==='00:00:00:00:00:00'?'AP unavailable':w.bssid}`:'None recorded');
  text('retained-action',w?`${w.local_action||'Unknown'} · ${seconds(w.action_age_ms)} before incident`:'None recorded');
  text('retained-retries',w?`${w.retries} · last result ${w.retry_result??'none'} · recorded delay ${seconds(w.next_wait_ms)}`:'None recorded');
  text('retained-retry-when',w?seconds(w.last_retry_uptime_ms):'None recorded');
  text('retained-outage',w?seconds(w.outage_ms):'None recorded');
  text('retained-wifi-when',w?seconds(w.context?.uptime_ms):'None recorded');
  text('retained-wifi-heap',heap(w?.context));text('retained-wifi-build',identity(w?.context));
  text('retained-wifi-largest',number(w?.context?.largest_internal_block)?w.context.largest_internal_block+' bytes':'Unavailable');
  text('retained-fault',f?.message||'None recorded');
  text('retained-fault-position',f?`${f.position??'Unknown'} / ${f.target??'Unknown'}`:'None recorded');
  text('retained-fault-when',f?seconds(f.context?.uptime_ms):'None recorded');
  text('retained-fault-heap',heap(f?.context));text('retained-fault-build',identity(f?.context));
  text('retained-fault-largest',number(f?.context?.largest_internal_block)?f.context.largest_internal_block+' bytes':'Unavailable');
 }
 async function poll(){
  if(!visible() || pending || api.now()-attemptAt<5000)return;
  attemptAt=api.now();pending=true;const current=++ticket,boot=state.session?.boot_id;
  try{
   const reply=await api.request('debug/retained');
   if(current!==ticket || state.session?.boot_id!==boot)return;
   if(reply.schema_version!==1 || reply.available!==true || reply.current_boot!==boot)throw Error('Retained evidence unavailable');
   data=reply;receivedAt=api.now();error='';
  }catch(e){if(current===ticket)error='Saved summary unavailable or paused. Previously downloaded evidence remains below.';}
  finally{if(current===ticket)pending=false;render();}
 }
 panel.open=false;
 panel.addEventListener('toggle',()=>{if(panel.open){attemptAt=-Infinity;poll();}render();});
 document.addEventListener('controllerrestart',()=>{++ticket;pending=false;data=null;error='';attemptAt=-Infinity;render();});
 api.retained={poll,render};
})();
