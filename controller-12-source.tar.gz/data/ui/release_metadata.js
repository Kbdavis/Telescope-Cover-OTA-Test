/* Release preview and passive device report contracts. Never installation authority. */
(function(root,factory){
 const api=factory();
 if(typeof module==='object' && module.exports)module.exports=api;
 else root.CoverReleaseMetadata=api;
})(typeof globalThis==='object'?globalThis:this,function(){
 'use strict';
 const RELEASE_SCHEMA='telescope-cover-release-preview/1';
 const DEVICE_SCHEMA='telescope-cover-device-preview/1';
 const LIVE_DEVICE_SCHEMA='telescope-cover-device/1';
 const MAX_BYTES=8192,MAX_NUMBER=Number.MAX_SAFE_INTEGER;
 // SHA-256 of exact native bytes 0..39, followed by EEPROM lock register 55 = 1.
 const NATIVE_PROFILE_SHA256='11ec86b5a32010e63a62d009d190685f05bafdf5118df74612991a7e20971470';
 const PREVIEW_SETTINGS=Object.freeze({calibration:5,application:'cover-app-382-v1',
  network:'network-preview-v1',auth:'device-auth-preview-v1',handoff:1});
 const fail=reason=>{throw new Error(reason);};
 const plain=v=>v!==null && typeof v==='object' && !Array.isArray(v);
 function fields(value,names){
  if(!plain(value) || Object.keys(value).length!==names.length ||
     names.some(key=>!Object.prototype.hasOwnProperty.call(value,key)))fail('Invalid or unknown fields');
 }
 function text(value,pattern){
  if(typeof value!=='string' || value.length>160)fail('Invalid string');
  const match=pattern.exec(value);if(!match || match[0]!==value)fail('Invalid string');
 }
 function integer(value,min,max){if(!Number.isSafeInteger(value) || value<min || value>max)fail('Invalid integer');}
 function boolean(value){if(typeof value!=='boolean')fail('Invalid boolean');}
 function oneOf(value,choices){if(!choices.includes(value))fail('Unsupported value');}
 const token=v=>text(v,/^[a-z][a-z0-9_-]{0,63}$/);
 const sha=v=>text(v,/^[a-f0-9]{64}$/);
 const commit=v=>text(v,/^[a-f0-9]{40}$/);
 // Keep numeric identifiers as strings: SemVer integers have no JS precision limit.
 function numeric(a,b){return a.length===b.length?(a===b?0:a<b?-1:1):a.length<b.length?-1:1;}
 function parseVersion(value){
  if(typeof value!=='string' || value.length>160)fail('Invalid version');
  const m=/^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?$/.exec(value);
  if(!m || m[0]!==value)fail('Invalid version');
  const prerelease=m[4]?m[4].split('.'):[];
  if(prerelease.some(id=>/^\d+$/.test(id) && id.length>1 && id[0]==='0'))fail('Invalid prerelease integer');
  return {core:m.slice(1,4),prerelease,build:m[5]||''};
 }
 function compareVersions(a,b){
  const x=parseVersion(a),y=parseVersion(b);
  for(let i=0;i<3;i++){const c=numeric(x.core[i],y.core[i]);if(c)return c;}
  if(!x.prerelease.length || !y.prerelease.length)return x.prerelease.length?-1:y.prerelease.length?1:0;
  for(let i=0;i<Math.min(x.prerelease.length,y.prerelease.length);i++){
   const a=x.prerelease[i],b=y.prerelease[i];if(a===b)continue;
   const an=/^\d+$/.test(a),bn=/^\d+$/.test(b);
   return an&&bn?numeric(a,b):an?-1:bn?1:a<b?-1:1;
  }
  return Math.sign(x.prerelease.length-y.prerelease.length);
 }
 function officialVersion(value){
  parseVersion(value);
  if(!/^\d+\.\d+\.\d+(?:-(?:alpha|beta|rc)\.[1-9]\d*)?$/.test(value))fail('Unsupported release version');
 }
 function hardware(value){
  fields(value,['board','chip','flash_bytes','layout','slot_bytes']);
  oneOf(value.board,['waveshare-21593']);oneOf(value.chip,['esp32']);
  oneOf(value.flash_bytes,[4194304]);oneOf(value.layout,['cover-4mb-v1']);oneOf(value.slot_bytes,[1310720]);
 }
 function motion(value){
  fields(value,['capability','profile_sha256','reference_offset','opening_direction','startup_policy']);
  oneOf(value.capability,['native-multiturn-v1','absolute-v1']);sha(value.profile_sha256);
  integer(value.reference_offset,0,4095);oneOf(value.opening_direction,[-1,1]);
  oneOf(value.startup_policy,['inspect-only-v1','ram-setup-v1']);
 }
 function settings(value){
  fields(value,['calibration','application','network','auth','handoff']);
  integer(value.calibration,1,65535);integer(value.handoff,1,65535);
  for(const key of ['application','network','auth'])token(value[key]);
 }
 function identity(value){
  fields(value,['version','commit','elf','build_profile','release','dirty']);
  text(value.version,/^[A-Za-z0-9.+-]+$/);
  commit(value.commit);sha(value.elf);token(value.build_profile);boolean(value.release);boolean(value.dirty);
 }
 function array(value,max){if(!Array.isArray(value) || value.length>max)fail('Invalid array');}
 function validateRelease(value){
  fields(value,['schema','product','version','tag','commit','elf','build_profile','channel',
   'qualification','published','protocol','hardware','motion','settings','artifacts','transitions']);
  oneOf(value.schema,[RELEASE_SCHEMA]);oneOf(value.product,['telescope-cover']);
  officialVersion(value.version);
  if(value.tag!=='v'+value.version)fail('Release tag mismatch');
  commit(value.commit);sha(value.elf);token(value.build_profile);
  if(value.channel!==(parseVersion(value.version).prerelease.length?'beta':'stable'))fail('Release channel mismatch');
  oneOf(value.qualification,['candidate','pipeline-test','qualified','withdrawn']);boolean(value.published);
  oneOf(value.protocol,[1]);hardware(value.hardware);motion(value.motion);settings(value.settings);
  array(value.artifacts,2);if(!value.artifacts.length)fail('Missing artifact');
  const kinds=new Set(),names=new Set();
  for(const a of value.artifacts){
   fields(a,['kind','filename','size','sha256']);oneOf(a.kind,['factory-install','application-ota']);
   text(a.filename,/^[a-zA-Z0-9][a-zA-Z0-9._-]{0,127}\.bin$/);
   integer(a.size,352,a.kind==='application-ota'?value.hardware.slot_bytes:1376256);sha(a.sha256);
   if(kinds.has(a.kind) || names.has(a.filename))fail('Duplicate artifact');
   kinds.add(a.kind);names.add(a.filename);
  }
  array(value.transitions,32);const sources=new Set();
  for(const t of value.transitions){
   fields(t,['version','commit','elf','build_profile','settings','method','rollback_compatible']);
   officialVersion(t.version);commit(t.commit);sha(t.elf);token(t.build_profile);settings(t.settings);
   oneOf(t.method,['usb','ota']);boolean(t.rollback_compatible);
   if(!kinds.has(t.method==='ota'?'application-ota':'factory-install'))fail('Transition artifact missing');
   if(compareVersions(t.version,value.version)>=0)fail('Transition must upgrade');
   const key=[t.commit,t.elf,t.build_profile,t.method].join(':');
   if(sources.has(key))fail('Duplicate source transition');sources.add(key);
  }
  return value;
 }
 function validateDevice(value){
  const live=value?.schema===LIVE_DEVICE_SCHEMA;
  fields(value,['schema','firmware','hardware','motion','settings','receiver','calibration_review_required',
   ...(live?['read_only_test','servo_profile_verified']:[])]);
  oneOf(value.schema,[DEVICE_SCHEMA,LIVE_DEVICE_SCHEMA]);identity(value.firmware);
  if(live){
   fields(value.hardware,['board','chip','flash_bytes','layout','slot_bytes']);
   oneOf(value.hardware.board,['waveshare-21593']);oneOf(value.hardware.chip,['esp32']);
   integer(value.hardware.flash_bytes,0,16777216);oneOf(value.hardware.layout,['cover-4mb-v1','unknown']);
   integer(value.hardware.slot_bytes,0,16777216);
   if(value.motion!==null)motion(value.motion);
   boolean(value.read_only_test);boolean(value.servo_profile_verified);
  }else {hardware(value.hardware);motion(value.motion);}
  settings(value.settings);boolean(value.calibration_review_required);
  fields(value.receiver,['enabled','protocol','rollback']);boolean(value.receiver.enabled);
  oneOf(value.receiver.protocol,[1]);oneOf(value.receiver.rollback,['unknown','build-supported','device-verified']);
  return value;
 }
 function same(a,b,keys){return keys.every(key=>a[key]===b[key]);}
 function assessRelease(release,device,options={}){
  validateRelease(release);validateDevice(device);
  if(!plain(options) || Object.keys(options).some(k=>k!=='include_beta'))fail('Invalid options');
  if(options.include_beta!==undefined)boolean(options.include_beta);
  // No result from this preview can authorize an installation.
  const result=(code,compatible=false,update=false,method=null)=>({code,compatible,update_available:update,method,installable:false});
  if(!release.published)return result('unpublished');
  if(release.qualification!=='qualified')return result('unqualified');
  if(release.channel==='beta' && options.include_beta!==true)return result('beta-disabled');
  const f=device.firmware;
  let official=f.release && !f.dirty;
  try{officialVersion(f.version);}catch(_){official=false;}
  if(!official)return result('development-build');
  if(device.schema===LIVE_DEVICE_SCHEMA){
   if(device.read_only_test)return result('read-only-test');
   if(!device.motion || !device.servo_profile_verified)return result('servo-unverified');
  }
  const order=compareVersions(release.version,f.version);
  if(order===0)return result(release.commit===f.commit && release.elf===f.elf && release.build_profile===f.build_profile?'current':'identity-conflict');
  if(order<0)return result('downgrade');
  if(!same(release.hardware,device.hardware,['board','chip','flash_bytes','layout','slot_bytes']))return result('hardware-mismatch');
  if(!same(release.motion,device.motion,['capability','profile_sha256','reference_offset','opening_direction']) ||
     release.motion.capability!=='native-multiturn-v1' || release.motion.profile_sha256!==NATIVE_PROFILE_SHA256 ||
     release.motion.reference_offset!==85 || release.motion.opening_direction!==-1)return result('motion-mismatch');
  if(device.calibration_review_required)return result('calibration-review');
  const settingKeys=['calibration','application','network','auth','handoff'];
  if(!same(release.settings,PREVIEW_SETTINGS,settingKeys) || !same(device.settings,PREVIEW_SETTINGS,settingKeys))return result('settings-unsupported');
  const matching=release.transitions.filter(t=>t.version===f.version && t.commit===f.commit && t.elf===f.elf &&
   t.build_profile===f.build_profile && same(t.settings,device.settings,['calibration','application','network','auth','handoff']));
  const ota=matching.find(t=>t.method==='ota'),usb=matching.find(t=>t.method==='usb');
  if(device.receiver.enabled && ota){
   if(!ota.rollback_compatible)return result('fallback-incompatible');
   if(device.receiver.rollback!=='device-verified')return result('rollback-unverified');
   if(release.protocol!==device.receiver.protocol)return result('protocol-mismatch');
   if(release.motion.startup_policy!=='inspect-only-v1')return result('startup-policy');
   return result('ota-candidate',true,true,'ota');
  }
  if(usb)return result(device.receiver.enabled?'usb-install-only':'usb-bootstrap-required',true,true,'usb');
  if(ota && !device.receiver.enabled)return result('receiver-disabled');
  return result('source-unsupported');
 }
 // JSON.parse alone loses duplicate fields. This bounded decoder rejects them
 // before schema validation, including escaped spellings of the same key.
 function decodeJson(source,byteLimit=MAX_BYTES,collectionLimit=32){
  if(typeof source!=='string' || source.length>byteLimit || new TextEncoder().encode(source).length>byteLimit)fail('Metadata exceeds byte limit');
  let at=0;
  function ws(){while(at<source.length && /[\t\n\r ]/.test(source[at]))at++;}
  function string(){
   const match=/^"(?:[^"\\\x00-\x1f]|\\(?:["\\/bfnrt]|u[0-9a-fA-F]{4}))*"/.exec(source.slice(at));
   if(!match)fail('Invalid JSON string');at+=match[0].length;return JSON.parse(match[0]);
  }
  function value(depth){
   if(depth>8)fail('JSON nesting limit');ws();const c=source[at];
   if(c==='"')return string();
   if(c==='{' || c==='['){
    at++;ws();const object=c==='{',out=object?Object.create(null):[],end=object?'}':']';
    if(source[at]===end){at++;return out;}
    let count=0;
    while(true){
     if(++count>(object?32:collectionLimit))fail('JSON collection limit');ws();
     if(object){const key=string();ws();if(source[at++]!==':')fail('Invalid JSON object');
      if(Object.prototype.hasOwnProperty.call(out,key))fail('Duplicate JSON field');out[key]=value(depth+1);
     }else out.push(value(depth+1));
     ws();const next=source[at++];if(next===end)return out;if(next!==',')fail('Invalid JSON separator');
    }
   }
   for(const [literal,result] of [['true',true],['false',false],['null',null]]){
    if(source.startsWith(literal,at)){at+=literal.length;return result;}
   }
   const number=/^-?(?:0|[1-9]\d*)/.exec(source.slice(at));
   if(!number)fail('Invalid JSON value');at+=number[0].length;
   const result=Number(number[0]);if(!Number.isSafeInteger(result) || Math.abs(result)>MAX_NUMBER || Object.is(result,-0))fail('Invalid JSON integer');return result;
  }
  const result=value(0);ws();if(at!==source.length)fail('Trailing JSON data');return result;
 }
 function parseCatalogJson(source){
  const catalog=decodeJson(source,262144,90);fields(catalog,['schema','releases']);
  oneOf(catalog.schema,['telescope-cover-catalog-preview/1']);array(catalog.releases,90);
  const ids=new Set(),versions=new Set();
  for(const entry of catalog.releases){
   fields(entry,['release_id','metadata']);integer(entry.release_id,1,MAX_NUMBER);
   validateRelease(entry.metadata);
   if(new TextEncoder().encode(JSON.stringify(entry.metadata)).length>MAX_BYTES)fail('Release exceeds byte limit');
   if(ids.has(entry.release_id) || versions.has(entry.metadata.version))fail('Duplicate catalog release');
   ids.add(entry.release_id);versions.add(entry.metadata.version);
  }
  return catalog;
 }
 return Object.freeze({RELEASE_SCHEMA,DEVICE_SCHEMA,LIVE_DEVICE_SCHEMA,MAX_BYTES,NATIVE_PROFILE_SHA256,PREVIEW_SETTINGS,parseVersion,compareVersions,parseCatalogJson,
  validateRelease,validateDevice,assessRelease,
  parseReleaseJson:source=>validateRelease(decodeJson(source)),
  parseDeviceJson:source=>validateDevice(decodeJson(source))});
});
