/* Guided live calibration view. Hardware actions use the shared transport. */
(()=>{

'use strict';
const api=window.coverAPI,travel=coverTravel;
const arcOf=d=>({circular:d.circular,closed:d.closed,open:d.open,direction:d.direction,length:d.length,minimum:d.minimum,maximum:d.maximum});
const local={present:false,supported:false,stowed:false,inspected:false,retain:false,stepSize:10};
const profileFrom=p=>({openSpeed:p?.open_speed,closeSpeed:p?.close_speed,jogSpeed:p?.jog_speed,acceleration:p?.acceleration,timeoutMs:p?.timeout_ms});
const calibrationFrom=(c,saved=false)=>({minimum:c[saved?'saved_minimum':'draft_minimum']??c.minimum,maximum:c[saved?'saved_maximum':'draft_maximum']??c.maximum,
  circular:!!c[saved?'circular':'draft_circular'],direction:c[saved?'opening_direction':'draft_direction'],length:c[saved?'travel_counts':'draft_travel_counts'],closed:c[saved?'closed':'draft_closed'],open:c[saved?'open':'draft_open'],...profileFrom(c[saved?'saved_profile':'draft_profile'])});
const tested={open:false,closed:false};
let initialized=false, resumeTeaching=false;
let recoveryFault='';
const sim={
 get s(){const c=api.state.cover||{};return {...local,connected:api.freshCover(),servoOnline:Number.isFinite(c.position),configValid:!!(c.ready||c.calibration_only||c.state==='FAULT'),
  voltage:c.servo_voltage??NaN,pos:c.position??0,fresh:api.freshPosition(),moving:!!c.moving,holding:!!c.holding,torque:c.torque!==false,
  fault:c.calibration_only?'':c.fault||'',notice:c.notice||'',limitsApplied:!!(c.ready||c.calibrated||c.dirty),saved:c.calibrated?calibrationFrom(c,true):null,
  draft:calibrationFrom(c),active:{minimum:c.minimum??0,maximum:c.maximum??0},dirty:!!c.dirty,elapsedMs:c.motion_ms||0,target:c.moving?c.target:null,tested};},
 blockers(action){
  if(action==='stop')return [];
  const c=api.state.cover, reasons=[];
  if(!api.freshCover())return ['Reconnect to the controller.'];
  if(!api.state.session?.beta_accepted)reasons.push('Accept the beta notice first.');
  if(api.state.session?.setup_only)reasons.push('Connect through home Wi-Fi for calibration.');
  if(api.state.busy)reasons.push('Waiting for the controller to confirm the request.');
  if(api.state.cover?.maintenance?.locked)reasons.push('Controller maintenance is active.');
  if(api.state.network?.busy)reasons.push('Wait for network setup to finish.');
  if(api.state.scope?.arm_locked||api.state.scope?.stow_locked||api.state.cover?.emergency?.locked)reasons.push('Finish the telescope operation first.');
  if(c.moving)reasons.push('Stop the current movement before continuing.');
  if(c.holding && (action!=='jog'||!local.retain||c.owner!==Number(api.id)))reasons.push('Support the cover and release torque before continuing.');
  // Recovery gathers fresh evidence in the worker. Requiring it here would
  // prevent retrying the very communication failure the user is inspecting.
  if(action!=='recover' && action!=='test' && !c.holding && c.torque!==false)reasons.push('Require confirmed torque OFF. Support the cover and use Stop.');
  if(action!=='recover' && !api.freshPosition())reasons.push('Wait for fresh position feedback.');
  if(!c.ready && !(action==='begin'&&c.calibration_only||['begin','profile'].includes(action)&&c.state==='FAULT'||action==='recover'))reasons.push(c.fault||'Complete startup checks first.');
  if(c.state==='FAULT'&&!['begin','profile','recover'].includes(action))reasons.push('Inspect and clear the fault first.');
  if(['direction','jog','capture'].includes(action)&&!c.teaching)reasons.push('Return to Prepare and begin supervised teaching first.');
  if(['direction','jog','capture','save','test'].includes(action)){
   if(!local.present||!local.supported||!local.stowed)reasons.push('Complete the three Prepare confirmations.');
   if(!c.ready)reasons.push('Begin teaching from Prepare before movement.');
   if(api.state.scope?.enabled&&!api.freshStow())reasons.push('Wait for fresh telescope stow confirmation.');
  }
  if(action==='begin'){
   if(!local.present||!local.supported||!local.stowed)reasons.push('Complete the three Prepare confirmations.');
   if(c.state==='FAULT'&&!local.inspected)reasons.push('Inspect the mechanism before changing a faulted range.');
  }
  if(action==='recover'&&!local.inspected)reasons.push('Confirm inspection and support before recovery.');
  if(action==='recover'&&c.ready&&c.state!=='FAULT')reasons.push('There is no startup failure or fault to clear.');
  if(action==='save'&&!travel.supported(travel.calibration(c,true)))reasons.push('Teach CLOSED zero and OPEN along the recorded direction, more than 20 counts apart along the observed opening direction.');
  if(action==='profile'&&c.state==='FAULT'&&!local.inspected)reasons.push('Inspect and support the mechanism before applying timing changes. The fault stays latched.');
  if(action==='test'&&typeof c.torque!=='boolean')reasons.push('Wait for confirmed torque feedback.');
  if(action==='test'&&(!c.calibrated||c.dirty))reasons.push('Save valid calibration before testing.');
  if(action==='discard'&&!c.calibrated)reasons.push('No verified saved calibration is available.');
  return reasons;
 },
 confirm(key,value){local[key]=value;if(!value&&['present','supported','stowed'].includes(key)&&(api.state.active||api.state.cover?.holding))api.stop();return {ok:true,message:value?'Confirmation recorded.':'Confirmation cleared.'};},
 setStep(value){local.stepSize=value;return {ok:true,message:'Step size set to '+value+' counts.'};},
 setRetain(value){local.retain=value;return {ok:true,message:value?'Single steps retain supervised torque. Stay with the cover.':'Single steps release torque on completion.'};},
 async run(action,path,body={},motion=false){const why=this.blockers(action)[0];if(why)return {ok:false,message:why};
  try{const result=await api.command(path,{calibrate:'yes',inspect:local.inspected?'yes':'no',...body},{motion});if(['begin','profile','capture','direction'].includes(action))tested.open=tested.closed=false;return {ok:true,message:result.notice};}
  catch(error){return {ok:false,message:error.message};}},
 begin(){return this.run('begin','calibration/begin',{present:'yes',supported:'yes',stowed:'yes',resume:resumeTeaching||(api.state.cover?.calibrated&&api.state.cover.draft_closed!==null&&api.state.cover.draft_open!==null)?'yes':'no'});},
 updateProfile(p){return this.run('profile','calibration/profile',{open_speed:p.openSpeed,close_speed:p.closeSpeed,jog_speed:p.jogSpeed,acceleration:p.acceleration,timeout_ms:p.timeoutMs});},
 capture(endpoint){return this.run('capture','calibration/'+endpoint);},save(){return this.run('save','calibration/save');},discard(){return this.run('discard','calibration/discard');},
 recover(){return this.run('recover','recover',{inspect:'yes'});},
 jog(direction){const rawDirection=direction*travel.openingDirection(api.state.cover);return this.run('jog','jog-'+(rawDirection>0?'plus':'minus'),{clear:'yes',step:local.stepSize,hold:local.retain?'yes':'no'},true);},
 test(endpoint){return this.run('test',endpoint==='open'?'open':'close',{clear:'yes',stowed:local.stowed?'yes':'no'},true);},
 async stop(message){await api.stop(message?{automatic:true,reason:'calibration_cleanup'}:{});return {ok:!api.state.error,message:api.state.message};}
};
const liveUI={get view(){return api.state.view;},get armMoving(){return api.state.scope?.arm_locked||api.state.cover?.emergency?.locked;},get settingsBusy(){return api.state.network?.busy;},
 get scopeState(){return api.freshStow()?'stowed':'unknown';},get config(){return {enabled:api.state.scope?.enabled!==false};}};
const $ = id => document.getElementById(id);
const all = selector => [...document.querySelectorAll(selector)];
let currentStep = 0, endpoint = 'closed', held = null, settlingUntil = 0;
let recent = [], lastNotice = '';
const text = (id, value) => { if ($(id).textContent !== String(value)) $(id).textContent = value; };
const bounds = range => `${range.minimum}–${range.maximum}`;
const number = id => $(id).value.trim() === '' ? NaN : Number($(id).value);
const stable = () => !sim.s.moving && performance.now() >= settlingUntil;
const profile = () => ({openSpeed:number('openSpeed'),closeSpeed:number('closeSpeed'),
  jogSpeed:number('jogSpeed'),acceleration:number('acceleration'),timeoutMs:number('timeout')*1000});
const profileEdited = () => Object.entries(profile()).some(([key,value]) => value !== sim.s.draft[key]);
const confirmations = () => sim.s.present && sim.s.supported && sim.s.stowed;
function healthReason() {
  const s=sim.s;
  if(!s.connected)return 'Reconnect to the controller. Last-known readings are not live.';
  if(!s.servoOnline)return 'Check servo power and the servo cable before continuing.';
  if(!s.configValid)return 'Servo configuration needs attention before movement.';
  if(Number.isFinite(s.voltage)&&s.voltage<6)return 'Check the servo supply before moving.';
  if(!s.fresh)return 'Wait for fresh position feedback.';
  return '';
}
function reasons(action) {
  const result=sim.blockers(action);
  if(liveUI.settingsBusy && action!=='stop')result.unshift('Wait for settings to finish saving.');
  if(liveUI.armMoving && action!=='stop')result.unshift('Wait for telescope arm movement to finish.');
  if(liveUI.view==='calibration' && liveUI.config.enabled && liveUI.scopeState!=='stowed' && ['jog','capture','save','test'].includes(action))result.unshift('Stow the telescope from Overview before calibrating.');
  if(['capture','save','begin','recover'].includes(action) && !stable())result.unshift('Waiting for the position to settle.');
  return result;
}
function record(message, error=false) {
  text('message',message);$('feedback').dataset.error=String(error);
  if(message!==lastNotice){
    recent.unshift(message);recent=recent.slice(0,6);
    $('activity').replaceChildren(...recent.map(value=>{const li=document.createElement('li');li.textContent=value;return li;}));
  }
  lastNotice=message;
}
async function act(result) {
  const outcome=await result;record(outcome.message,!outcome.ok);render();return outcome.ok;
}
function loadFields() {
  const d=sim.s.draft;
  for(const id of ['openSpeed','closeSpeed','jogSpeed','acceleration'])$(id).value=d[id];
  $('timeout').value=d.timeoutMs/1000;
}
async function reviewPositions() {
  const d=sim.s.draft, timing=travel.duration(arcOf(d),d);
  if(timing && d.timeoutMs<timing.recommended && timing.recommended<=30000){
    // Increase only the applied draft timeout. Other form edits still need Apply.
    if(!await act(sim.updateProfile({...d,timeoutMs:timing.recommended})))return;
    if(!Number.isFinite(number('timeout')) || number('timeout')*1000<timing.recommended)$('timeout').value=timing.recommended/1000;
    record(`Move timeout increased to ${timing.recommended/1000} seconds for the taught travel. Save calibration to keep it.`);
  }
  navigate(2);
}
function navigate(step, focus=true) {
  if(held || sim.s.moving || sim.s.holding) stop('Stopped before changing steps. Motor torque released.');
  currentStep=step;render();
  if(focus){const heading=document.querySelector(`[data-panel="${step}"] h2`);heading.focus({preventScroll:true});heading.scrollIntoView({block:'nearest',behavior:'auto'});}
}
function stop(message) {
  const active=!!held || sim.s.moving || sim.s.holding;
  held=null;api.state.repeats=null;
  if(active)settlingUntil=performance.now()+450;
  act(sim.stop(message));
}
function setDisabled(id, why) {
  $(id).disabled=!!why;$(id).title=why||'';
}
function render() {
  const fault=sim.s.fault;
  const cover=api.state.cover;
  $('calibrationReviewNotice').hidden=!cover?.calibration_review;
  text('calibrationReviewNotice',`Stored calibration needs explicit review. Raw CLOSED ${cover?.review_closed_raw??'—'} / OPEN ${cover?.review_open_raw??'—'}. Its physical path is ambiguous or unsupported. Inspect the range and teach fresh endpoints. No movement or settings rewrite occurs on load.`);
  // Show endpoint-specific guidance on every tab, including after a reload.
  $('endpointTimeoutNotice').hidden=!(cover?.state==='FAULT' && fault==='Movement timeout' && cover.calibrated &&
    Number.isInteger(cover.target) && (cover.target===cover.open || cover.target===cover.closed));
  if(fault!==recoveryFault){local.inspected=false;recoveryFault=fault;}
  $('inspected').checked=local.inspected;
  const startupFailure=!api.state.cover?.ready && api.state.cover?.state!=='FAULT';
  $('recoveryControls').hidden=!(fault || api.servoSetupOnly()) || (startupFailure && liveUI.view!=='calibration');
  text('dockFault',api.servoSetupOnly()?'Connect a powered servo, then recheck.':fault);$('dockFault').title=fault;
  const overcurrent=fault.startsWith('Servo overcurrent');
  const powerCycleHelp='Support the cover and inspect for binding or obstruction. Turn the servo’s external power supply OFF, then ON. Restarting the controller alone does not clear this fault. After servo power is restored, confirm inspection and use Clear fault / Recheck servo. No movement resumes automatically.';
  text('faultPowerCycleHelp',overcurrent?powerCycleHelp:'');$('faultPowerCycleHelp').hidden=!overcurrent;
  text('recover',startupFailure?'Recheck servo':'Clear fault');
  const recoverWhy=reasons('recover')[0]||'';setDisabled('recover',recoverWhy);const recoveryHint=recoverWhy==='Confirm inspection and support before recovery.'?'':recoverWhy;
  text('recoverReason',recoveryHint);$('recoverReason').hidden=!recoveryHint;
  if(liveUI.view!=='calibration'){
    return;
  }
  const s=sim.s,d=s.draft,healthy=!healthReason(),still=stable(),pos=Math.round(s.pos);
  for(const id of ['present','supported','stowed','inspected'])$(id).checked=s[id];
  $('retain').checked=s.retain;$('retain').disabled=s.moving||s.holding;
  all('[data-panel]').forEach(panel=>panel.hidden=Number(panel.dataset.panel)!==currentStep);
  const completed=[healthy&&confirmations(),d.closed!==null&&d.open!==null,!!s.saved&&!s.dirty,s.tested.open&&s.tested.closed];
  all('[data-step]').forEach(button=>{
    const step=Number(button.dataset.step);
    if(step===currentStep)button.setAttribute('aria-current','step');else button.removeAttribute('aria-current');
    button.querySelector('.step-check').textContent=completed[step]?'✓':'';
  });
  const edited=s.dirty||profileEdited();
  text('saveState',!s.saved?'Not calibrated':edited?'Unsaved changes':'Calibration saved');
  $('saveState').className='pill '+(edited?'neutral':'');
  text('connectionCheck',s.connected?'Connected':'Disconnected');
  text('servoCheck',!s.connected?'Unknown':s.servoOnline&&s.configValid?'ST3215 · verified':s.servoOnline?'Check configuration':'Not responding');
  text('supplyCheck',s.connected&&s.servoOnline?`${(Number.isFinite(s.voltage)?s.voltage.toFixed(1):'—')} V`:'Unavailable');
  text('positionCheck',!s.fresh?'Unavailable':!still?'Settling…':'Fresh & stable');
  for(const [id,ok] of [['connectionDot',s.connected],['servoDot',s.connected&&s.servoOnline&&s.configValid],['supplyDot',healthy],['positionDot',s.fresh&&still]])$(id).classList.toggle('bad',!ok);
  const prep=(api.state.session?.setup_only?'Use home Wi-Fi for calibration.':'')||healthReason()||(!confirmations()?'Confirm all three checks to begin.':'Checks complete. Begin supervised teaching.');
  text('prepareReason',prep);setDisabled('prepareNext',!healthy?prep:reasons('begin')[0]||(!confirmations()?prep:''));
  text('prepareNext',cover?.teaching||resumeTeaching||cover?.calibrated?'Resume teaching →':'Begin teaching →');
  $('teachStartNotice').hidden=!!cover?.teaching&&confirmations();
  text('teachStartHeading',cover?.teaching?'Confirm the setup checks to resume.':'Start teaching to unlock movement.');
  text('teachStartReason',cover?.teaching?'Your taught positions are kept. Go to Prepare, confirm the three checks, then choose Resume teaching.':'Opening this step does not start a teaching session. Go to Prepare, confirm the three checks, then choose Begin teaching. This unlocks the buttons without moving the cover.');
  const jogReason=reasons('jog')[0]||(!still?'Waiting for stable feedback.':'');
  const openingStep=s.stepSize*travel.openingDirection(cover);
  const minusWhy=jogReason||travel.jogReason(cover,-openingStep),plusWhy=jogReason||travel.jogReason(cover,openingStep);
  const minusEdge=!!travel.jogReason(cover,-openingStep),plusEdge=!!travel.jogReason(cover,openingStep);
  setDisabled('minus',minusWhy);setDisabled('plus',plusWhy);
  const minusName='Toward closed',plusName='Toward open';
  text('minusLabel',minusName);text('plusLabel',plusName);
  text('holdMinus','Hold: '+minusName.toLowerCase());text('holdPlus','Hold: '+plusName.toLowerCase());
  const holdReason=s.retain||s.holding?'Turn off supervised holding to use repeated moves.':'';
  setDisabled('holdMinus',held?.dir===-1?'':holdReason||minusWhy);setDisabled('holdPlus',held?.dir===1?'':holdReason||plusWhy);
  $('holdMinus').dataset.active=String(held?.dir===-1);$('holdPlus').dataset.active=String(held?.dir===1);
  const motionReason=s.moving?`Actuator moving${travel.supported(arcOf(d))?' toward '+travel.label(travel.estimate(arcOf(d),s.target)):' under your supervision'}. Release a held button or use Stop to end the move.`:jogReason||
    (minusEdge||plusEdge?'A full step reaches the taught travel limit or needs boundary commissioning. Choose a smaller step.':holdReason||`Each step moves ${s.stepSize} encoder counts along the recorded direction. Watch the mechanism.`);
  text('motionReason',motionReason);
  $('minus').setAttribute('aria-label',`${minusName} by ${s.stepSize} encoder counts`);
  $('plus').setAttribute('aria-label',`${plusName} by ${s.stepSize} encoder counts`);
  all('[data-count]').forEach(button=>{button.setAttribute('aria-pressed',String(Number(button.dataset.count)===s.stepSize));button.disabled=s.moving||!!held;});
  text('closedValue',d.closed===null?'Not captured':'0% travel · zero captured');text('openValue',d.open===null?'Not captured':'100% travel · captured');
  $('chooseClosed').setAttribute('aria-pressed',String(endpoint==='closed'));$('chooseOpen').setAttribute('aria-pressed',String(endpoint==='open'));
  text('endpointIcon',endpoint==='closed'?'↓':'↑');text('endpointHeading',endpoint==='closed'?'Bring the cover gently to closed.':'Move the cover fully clear of the telescope.');
  text('endpointInstruction',endpoint==='closed'?'Stop at its resting seat. Don’t drive it into a hard stop.':'Use small steps to move fully clear. Increasing position moves toward open. Stop, then set OPEN.');

  const intended=d.circular?travel.wrap(d.direction*(pos-d.closed)):d.direction*(pos-d.closed);
  const captureWhy=reasons('capture')[0]||(endpoint==='open'&&(d.closed===null?'Set CLOSED as application zero first.':intended<=20?'Move toward OPEN to more than 20 counts from CLOSED.':intended>=2048?'This controller supports less than a half-turn of taught travel. Check direction and endpoints.':'') );
  text('capture',`Set current position as ${endpoint.toUpperCase()}${endpoint==='closed'?' zero':''} · no movement`);setDisabled('capture',captureWhy);
  text('captureReason',captureWhy||'Capture records the measured position. It does not move the cover.');$('captureRelease').hidden=!s.holding;
  setDisabled('teachNext',d.closed===null||d.open===null?'Capture both endpoints before reviewing.':'');
  text('reviewClosed',d.closed===null?'—':'0%');text('reviewOpen',d.open===null?'—':'100%');text('reviewBounds',d.closed===null||!d.direction?'Set CLOSED zero first':(d.circular?`−10 to ${d.length+10} counts · endpoint settling margin`:`${Math.min(d.direction*(d.minimum-d.closed),d.direction*(d.maximum-d.closed))} to ${Math.max(d.direction*(d.minimum-d.closed),d.direction*(d.maximum-d.closed))} counts`));
  text('reviewDirection',d.closed===null||d.open===null?'Teach both endpoints':d.direction===1?'Increasing encoder counts':'Decreasing encoder counts');
  text('reviewSpan',d.closed===null||d.open===null?'—':`${d.length} counts · ${(d.length*360/4096).toFixed(1)}° actuator rotation`);
  text('previousSaved',s.saved?`0–100% travel · ${s.saved.length} counts`:'No saved calibration');
  const timing=travel.duration(arcOf(d),profile()),timingWarning=travel.timeoutReason(arcOf(d),profile());
  text('durationEstimate',timing?`Planning estimate: OPEN ${(timing.opening.expected/1000).toFixed(1)} s / CLOSE ${(timing.closing.expected/1000).toFixed(1)} s, including ramp allowance and settling. Recommended timeout ${timing.recommended/1000} s with preflight and margin.`:'Teach a supported travel arc to estimate duration.');
  text('timeoutWarning',timingWarning);$('adjustTimeout').hidden=!timingWarning;
  setDisabled('adjustTimeout',!timing||timing.recommended>30000?'Review speed and travel; recommended timeout is above 30 seconds.':'');
  const profileWhy=reasons('profile')[0]||'';setDisabled('applyProfile',profileWhy);
  text('profileReason',profileWhy|| (profileEdited()?'Edited values are not applied yet. Apply to draft to use them.':'Profile matches the draft.'));
  const saveWhy=reasons('save')[0]||timingWarning||(profileEdited()?'Apply the movement settings to the draft first.':'');
  setDisabled('save',saveWhy||(!s.dirty&&s.saved?'This calibration is already saved.':''));
  text('saveReason',saveWhy||(!s.dirty&&s.saved?'Saved. You can now test one endpoint at a time.':'Ready to save both endpoints and the working range.'));
  text('save',s.saved&&!s.dirty?'Calibration saved ✓':'Save calibration');
  setDisabled('reviewNext',!s.saved||s.dirty?'Save your calibration before testing.':profileEdited()?'Apply and save your edited fields first.':'');
  const testWhy=reasons('test')[0]||travel.timeoutReason(arcOf(s.saved||d),s.saved||d)||(profileEdited()?'Apply and save your edited fields first.':'');
  for(const id of ['testOpen','testClose'])setDisabled(id,testWhy);
  text('testReason',testWhy||'Choose either test. Nothing starts automatically.');$('testSaved').hidden=!s.saved||s.dirty;
  text('testOpenTarget',s.saved?'To 100% travel · encoder estimate':'Save an open position');text('testCloseTarget',s.saved?'To 0% travel · encoder estimate':'Save a closed position');
  for(const key of ['open','closed']){text(key+'TestIcon',s.tested[key]?'✓':'○');text(key+'TestResult',s.tested[key]?'Reached · servo feedback':'Not tested');}
  $('testComplete').hidden=!(s.tested.open&&s.tested.closed);
  const discardWhy=reasons('discard')[0]||(!s.dirty&&!profileEdited()?'No unsaved changes.':'');
  setDisabled('discard',discardWhy);text('discardReason',edited?discardWhy:'');
  const issue=healthReason()||s.fault;
  $('issue').hidden=!issue;
  let issueTitle=s.fault?'Movement needs attention.':'Setup needs attention.';
  let issueText=issue;
  if(!s.connected){issueTitle='The controller connection is lost.';issueText='Position is last known; torque release cannot be confirmed. On hardware, support the cover and check power or local Wi-Fi. Reconnect to home Wi-Fi and verify fresh feedback.';}
  else if(overcurrent){issueTitle='Servo overcurrent — cycle servo power';issueText=powerCycleHelp;}
  else if(!s.servoOnline){issueTitle=api.state.cover?.state==='FAULT'?'Servo feedback unavailable':'Servo setup';issueText=api.state.cover?.state==='FAULT'?'The fault remains latched. Inspect and support the mechanism, then use Clear fault to retry communication and verified torque release. Recovery never repeats the failed move.':'Without a connected, powered servo, movement and calibration are unavailable. Configuration and Debug still work. After connecting the servo, inspect and support the mechanism, then use Recheck servo below.';}
  else if(s.voltage<6){issueTitle='Check the servo’s power source.';issueText='The reported servo supply is low. Check power and wiring before movement.';}
  else if(s.fault.startsWith('ST3215 configuration mismatch')||s.fault.startsWith('Invalid ST3215 configuration')){
   issueTitle=s.fault;issueText='The servo’s internal settings do not match the supported controller profile. Application calibration cannot fix this. Review the reported differences in Debug before commissioning the servo. Recheck only reads and validates the settings; it cannot override this check or rewrite the servo.';
  }
  else if(s.fault){
   issueTitle=s.fault;
   const outside=s.fresh&&s.limitsApplied&&(s.pos<s.active.minimum||s.pos>s.active.maximum);
   const rangeRecovery=outside&&(api.state.cover?.state==='FAULT'||s.fault.startsWith('Position outside saved travel limits'));
   issueText=rangeRecovery?`The position is ${pos}; active limits are ${bounds(s.active)}. Inspect and support the cover, then return to Prepare and begin supervised teaching. Clear any latched fault after inspection; nothing will move automatically.`:
    startupFailure?'This startup check must pass before calibration. Inspect the reported cause, then use Recheck servo. Rechecking does not override a failed check, change the working range, or start movement.':'Movement stopped and the fault remains latched. Inspect the mechanism and support the cover, then recheck. Recovery never repeats the failed move.';
  }
  text('issueTitle',issueTitle);text('issueText',issueText);
  const observed=s.connected&&s.servoOnline&&s.fresh;
  const reading=travel.estimate(arcOf(d),s.fresh?s.pos:null);
  text('position',reading.valid?Number(reading.percent.toFixed(1)):'—');
  text('positionUnit','% travel');text('rawPosition',s.fresh?`${pos} counts`:'Unavailable');text('rawBounds',bounds(s.active)+' counts');text('rawEndpoints',`${d.closed??'—'} / ${d.open??'—'} counts`);
  text('actuatorRotation',s.fresh&&d.closed!==null&&d.direction?`${(travel.coordinate(arcOf(d),s.pos)*360/4096).toFixed(1)}° · shaft, not cover angle`:'Set CLOSED zero first');
  text('positionCaption',s.fresh&&!reading.valid?reading.reason:!s.connected?'Last known · not live':!s.fresh?'No valid feedback':s.moving?'Feedback updating':!still?'Waiting for stable feedback…':'Fresh feedback · stable');
  text('liveState',!s.connected?'Disconnected':s.fault?'Fault':s.moving?'Moving':s.holding?'Holding':!healthy?'Check setup':'Stationary');
  $('liveState').className='pill '+(!healthy||s.fault?'bad':s.moving||s.holding?'warn':'');
  text('liveBounds',d.closed!==null&&d.direction?(d.circular?(d.open===null?'Supervised teaching':`−10 to ${d.length+10} counts from CLOSED`):`${Math.min(d.direction*(s.active.minimum-d.closed),d.direction*(s.active.maximum-d.closed))} to ${Math.max(d.direction*(s.active.minimum-d.closed),d.direction*(s.active.maximum-d.closed))} counts from CLOSED`):'Set CLOSED zero first');text('liveTorque',!observed||api.state.cover?.torque===null?'Unconfirmed':s.torque?(s.moving||s.holding?'On · supervised':'On · endpoint hold'):'Released · confirmed');
  text('liveTarget',s.target===null?'—':travel.label(travel.estimate(arcOf(d),s.target)));text('liveSupply',observed?`${(Number.isFinite(s.voltage)?s.voltage.toFixed(1):'—')} V / ${api.state.cover?.servo_temperature??'—'} °C`:'Unavailable');
  text('liveLoad',observed?`${api.state.cover?.servo_load??'—'} · relative`:'Unavailable');text('liveCurrent',observed?String(api.state.cover?.servo_current_raw??'Unavailable'):'Unavailable');text('liveElapsed',(s.elapsedMs/1000).toFixed(1)+' s');
  $('rangeBand').style.left='0%';$('rangeBand').style.width='100%';
  $('rangeBand').style.opacity=travel.supported(arcOf(d))?'1':'.25';
  $('positionMark').style.left=(reading.valid?reading.percent:0)+'%';$('positionMark').hidden=!reading.valid;
  for(const [id,key] of [['closedMark','closed'],['openMark','open']]){$(id).hidden=!travel.supported(arcOf(d));$(id).style.left=key==='closed'?'0%':'100%';}
  $('coverLid').style.transform=reading.valid?`rotate(${reading.percent*.9}deg)`:'rotate(0deg)';
  $('coverLid').style.opacity=reading.valid?'1':'.15';

}

for(const id of ['present','supported','stowed','inspected'])$(id).addEventListener('change',()=>{
  if(!$(id).checked&&held)held=null;
  if(id==='stowed' && $('stowed').checked && liveUI.config.enabled && liveUI.scopeState!=='stowed'){ $('stowed').checked=false;record('Stow the telescope in Overview first.',true);return;}
  act(sim.confirm(id,$(id).checked));
});
async function enterTeaching(){
 const c=api.state.cover;
 if(c?.teaching&&confirmations()){navigate(1);return;}
 resumeTeaching=!!(c?.calibrated&&c.draft_closed!==null&&c.draft_open!==null);
 if(reasons('begin').length){navigate(0);record(reasons('begin')[0]||'Complete Prepare before teaching.',true);return;}
 if(await act(sim.begin())){resumeTeaching=false;loadFields();navigate(1);}
}
all('[data-step]').forEach(button=>button.addEventListener('click',()=>Number(button.dataset.step)===1?enterTeaching():navigate(Number(button.dataset.step))));
$('prepareNext').onclick=async()=>{if(reasons('begin').length)return;if(api.state.cover?.teaching){navigate(1);return;}if(await act(sim.begin())){if(!resumeTeaching)endpoint='closed';resumeTeaching=false;loadFields();navigate(1);}};$('teachPrepare').onclick=()=>navigate(0);$('teachNext').onclick=reviewPositions;$('reviewNext').onclick=()=>navigate(3);$('backToTeach').onclick=enterTeaching;
for(const id of ['openSpeed','closeSpeed','jogSpeed','acceleration','timeout'])$(id).addEventListener('input',render);
$('applyProfile').onclick=()=>act(sim.updateProfile(profile()));
$('adjustTimeout').onclick=()=>{const timing=travel.duration(arcOf(sim.s.draft),profile());if(timing&&timing.recommended<=30000){$('timeout').value=timing.recommended/1000;record('Timeout edited in form only. Apply to draft and save explicitly. Any fault remains latched.');render();}};
for(const name of ['closed','open'])$('choose'+(name==='closed'?'Closed':'Open')).onclick=()=>{endpoint=name;render();};
all('[data-count]').forEach(button=>button.onclick=()=>act(sim.setStep(Number(button.dataset.count))));
$('minus').onclick=()=>{if(!reasons('jog').length)act(sim.jog(-1));};$('plus').onclick=()=>{if(!reasons('jog').length)act(sim.jog(1));};
$('retain').onchange=()=>act(sim.setRetain($('retain').checked));
$('capture').onclick=async()=>{
  if(!stable()||reasons('capture').length)return;
  const which=endpoint;
  if(await act(sim.capture(which))&&which==='closed'&&sim.s.draft.open===null){endpoint='open';render();record('CLOSED zero captured. Now move toward OPEN along the observed safe path.');}
};
$('save').onclick=()=>{if(!reasons('save').length)act(sim.save());};$('testOpen').onclick=()=>{if(!reasons('test').length)act(sim.test('open'));};$('testClose').onclick=()=>{if(!reasons('test').length)act(sim.test('closed'));};
$('stop').onclick=()=>stop();
$('recover').onclick=async()=>{await act(sim.recover());local.inspected=false;render();};
$('discard').onclick=()=>{$('discardDialog').showModal();};$('cancelDiscard').onclick=()=>$('discardDialog').close();
$('confirmDiscard').onclick=async()=>{if(await act(sim.discard())){loadFields();render();}$('discardDialog').close();};
function beginHold(button,dir,input) {
  if(button.disabled||held||reasons('jog').length)return false;
  held={dir,button,input,controlGeneration:api.state.cover.control_generation};api.state.repeats=dir;
  act(sim.jog(dir)).then(ok=>{if(!ok){held=null;api.state.repeats=null;}render();});return true;
}
function scheduleRepeat(session,deadline=performance.now()+2000,commandId=api.state.cover.command_id) {
  clearTimeout(session.timer);
  session.timer=setTimeout(()=>{
    if(held!==session||!api.state.repeats)return;
    const c=api.state.cover,reason=reasons('jog')[0];
    if(c.control_generation!==session.controlGeneration || c.command_client!==Number(api.id) || c.command_id!==commandId){stop('Repeated movement interrupted by another controller request.');return;}
    // Completion can precede the next torque read or the command acknowledgement.
    // Wait for those transient states; never resume after lost supervision/fault.
    const supervised=api.freshCover()&&api.freshPosition()&&c.ready&&c.state!=='FAULT'&&
      !c.maintenance?.locked&&confirmations()&&(!api.state.scope?.enabled||api.freshStow());
    if(reason || !stable()){
      const transient=api.state.busy || !stable() || (!c.holding && c.torque!==false);
      if(supervised&&transient&&performance.now()<deadline){scheduleRepeat(session,deadline,commandId);return;}
      stop(reason||'Repeated movement could not confirm a settled position.');return;
    }
    act(sim.jog(session.dir)).then(ok=>{if(!ok&&held===session){held=null;api.state.repeats=null;}render();});
  },Math.max(100,settlingUntil-performance.now()+50));
}
function endHold(input) {if(held&&(!input||held.input===input))stop('Repeated movement stopped. Motor torque released.');}
for(const [id,dir] of [['holdMinus',-1],['holdPlus',1]]){
  const button=$(id);
  button.addEventListener('pointerdown',event=>{if(event.button!==0)return;event.preventDefault();if(beginHold(button,dir,'pointer'))button.setPointerCapture(event.pointerId);});
  for(const name of ['pointerup','pointercancel','lostpointercapture'])button.addEventListener(name,()=>endHold('pointer'));
  button.addEventListener('keydown',event=>{if([' ','Enter'].includes(event.key)){event.preventDefault();if(!event.repeat)beginHold(button,dir,'keyboard');}});
  button.addEventListener('keyup',event=>{if([' ','Enter'].includes(event.key)){event.preventDefault();endHold('keyboard');}});
  button.addEventListener('blur',()=>endHold());button.addEventListener('contextmenu',event=>event.preventDefault());
}
window.addEventListener('keydown',event=>{if(event.key==='Escape'&&!document.querySelector('dialog[open]'))stop();});
let lastSignature='';
api.subscribe(()=>{
 if(!initialized && api.state.cover?.notice && api.state.cover.fault!=='Starting'){initialized=true;if(api.state.cover.teaching&&api.state.cover.draft_closed!==null&&api.state.cover.draft_open===null)endpoint='open';loadFields();}
 if(!api.state.repeats)held=null;
 const c=api.state.cover||{};const visibleState=Object.fromEntries(['state','fault','ready','teaching','draft_circular','rollover_supported','moving','holding','owner','position','torque','calibration_only','calibrated','dirty','notice','minimum','maximum','draft_minimum','draft_maximum','draft_open','draft_closed','open','closed','saved_minimum','saved_maximum','draft_profile','saved_profile','draft_direction','opening_direction','draft_travel_counts','travel_counts','calibration_review','review_closed_raw','review_open_raw','servo_voltage','servo_temperature','servo_load','servo_current_raw','target','motion_ms'].map(key=>[key,c[key]]));
 const signature=JSON.stringify([visibleState,c.settings_offline_allowed,c.maintenance?.locked,api.freshCover(),api.freshPosition(),api.freshStow(),api.state.busy,api.state.network?.busy,api.state.scope?.arm_locked,api.state.scope?.stow_locked,api.state.cover?.emergency?.locked,api.state.session?.beta_accepted,api.state.session?.setup_only,stable(),local]);
 if(signature!==lastSignature){lastSignature=signature;if(sim.s.notice!==lastNotice)record(sim.s.notice,!!sim.s.fault);render();}
});
document.addEventListener('controllerrestart',()=>{initialized=false;resumeTeaching=false;held=null;Object.assign(local,{present:false,supported:false,stowed:false,inspected:false,retain:false});tested.open=tested.closed=false;});
document.addEventListener('coverfinished',event=>{
 const c=event.detail;settlingUntil=performance.now()+350;
 if(c.command_ok&&c.state==='OPEN'&&!c.dirty)tested.open=true;
 if(c.command_ok&&c.state==='CLOSED')tested.closed=true;
 if(held && api.state.repeats && c.command_ok && c.state!=='FAULT')scheduleRepeat(held);
});
window.calibrationState=sim;
window.calibrationUI={render,loadFields,stop,navigate,dirty:()=>initialized&&(sim.s.dirty||profileEdited())};
render();
})();
