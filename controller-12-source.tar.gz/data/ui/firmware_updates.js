/* Release browsing only. Installation is independently release-gated. */
window.CoverLegacyFirmwareUpdates=() => {
 'use strict';
 const api=window.coverAPI,$=id=>document.getElementById(id);
 if(!api || !$('cfg-updates'))return;
 const set=(id,value)=>{if($(id).textContent!==String(value))$(id).textContent=String(value);};
 const labels={
  'compatibility-unknown':'Compatibility unknown — review the release notes.',
  'ota-candidate':'Compatible update metadata; wireless installation is not enabled yet.',
  'usb-bootstrap-required':'USB installation required to enable wireless updates.',
  'usb-install-only':'USB clean installation only; existing settings will be erased.',
  'receiver-disabled':'This firmware cannot receive wireless updates.',
  'source-unsupported':'No tested upgrade path from this installed build.',
  'motion-mismatch':'Incompatible servo profile or calibration reference.',
  'settings-unsupported':'Settings compatibility has not been established.',
  'calibration-review':'Saved calibration requires review before an update.',
  'rollback-unverified':'Startup recovery has not been verified for this controller.',
  'fallback-incompatible':'The previous firmware cannot safely read these settings.',
  'startup-policy':'Update startup behavior is not qualified.',
  'development-build':'Development build installed; review an official release.',
  'read-only-test':'Read-only test firmware; wireless installation is disabled.',
  'servo-unverified':'Servo identity and configuration have not been verified for this update.',
  'identity-conflict':'Version matches but firmware identity differs; installation blocked.',
  'downgrade':'Older release — normal downgrade installation is unavailable.',
  'current':'This exact release is installed.',
  'unqualified':'This release is unqualified or withdrawn; installation unavailable.',
  'unpublished':'This release is unpublished; installation unavailable.'
 };
 const errors={
  'offline':'Release check failed. Check internet access; browser network or CORS restrictions may also prevent access.',
  'rate-limited':'GitHub denied or rate-limited the request. Wait until the next permitted check.',
  'access-unavailable':'Releases are unavailable. The repository may be private or inaccessible.',
  'server-error':'The release service returned an error. Previously checked results may still be shown.',
  'invalid-metadata':'Release data is invalid. Compatibility cannot be established.',
  'invalid-pagination':'The release service returned an unsupported page link.',
  'response-too-large':'Release data exceeded the browser’s configured limits.',
  'invalid-cache':'Cached release data could not be revalidated.',
  'browser-unsupported':'This browser cannot read bounded release responses.',
  'paused':'Release checks paused while this page was hidden.',
  'clock-changed':'The browser clock changed. Check again to refresh release information.'
 };
 let storage=null;try{storage=window.localStorage;}catch(_){}
 const engine=new CoverReleaseDiscovery.Discovery({fetch:window.fetch.bind(window),storage,
  visible:()=>!document.hidden,onChange:render,
  getFirmware:()=>{const s=api.state.session,f=s?.firmware;return f?{...f,elf:s.firmware_id,build_profile:f.profile}:null;},
  // An absent capability report is unknown, never inferred from a build name.
  getDevice:()=>api.state.session?.update_capabilities||null});
 let optionsKey='';
 const time=value=>value?new Date(value).toLocaleString(undefined,{timeZoneName:'short'}):'Never';
 function render(){
  const s=engine.snapshot(),firmware=api.state.session?.firmware;
  set('updates-installed',firmware?.version||'Unavailable');
  const device=api.state.session?.update_capabilities;
  let deviceMessage='Controller update support is unknown.';
  try {
   CoverReleaseMetadata.validateDevice(device);
   deviceMessage=device.read_only_test?'Read-only test firmware. Wireless installation is disabled.':
    !device.receiver.enabled?'Wireless installation is unavailable in this firmware.':
    device.servo_profile_verified===false?'Servo identity and configuration require verification.':
    'Controller update support reported. Release compatibility still requires checking.';
  } catch (_) {}
  set('updates-device',deviceMessage);
  let message=errors[s.status]||(!s.last_success?'No release check completed.':s.rows.length?
   s.suggested?'A compatible update is available.':s.catalog_status==='unavailable'?'Release notes are available. Compatibility metadata is unavailable.':
   s.rows.every(r=>r.assessment.code==='current')?'The checked release matches the installed firmware.':'Review release compatibility below.':
   s.releases.length?'No stable releases found. Enable beta releases to review prereleases.':'No published releases found.');
  if(s.checking)message='Checking published releases…';
  if(s.stale)message+=' Cached results are stale; check again before making installation decisions.';
  if(s.incomplete)message+=' Release history is incomplete; older pages were not checked.';
  if(s.metadata_error)message+=' Some compatibility data could not be validated.';
  set('updates-status',message);set('updates-last-attempt',time(s.last_attempt));set('updates-last-success',s.last_success?time(s.last_success):'No successful check yet');
  set('updates-next-check',s.preferences.automatic?time(s.next_check):'Automatic checks off');
  const seconds=Math.max(0,Math.ceil((s.manual_check_at-Date.now())/1000));
  const wait=seconds>=3600?Math.ceil(seconds/3600)+'h':seconds>=90?Math.ceil(seconds/60)+'m':seconds+'s';
  const reason=s.check_block==='checking'?'A release check is in progress.':
   s.check_block==='rate-limited'?'The release service requested a wait. You can check again at '+time(s.manual_check_at)+'.':
   s.check_block==='cooldown'?'A check was attempted recently. You can check again at '+time(s.manual_check_at)+'.':'';
  set('updates-check',s.checking?'Checking…':s.can_check?'Check now':'Check in '+wait);
  set('updates-check-reason',reason);$('updates-check-reason').hidden=!reason;
  $('updates-check').title=reason;$('updates-check').disabled=!s.can_check;$('updates-auto').checked=s.preferences.automatic;$('updates-beta').checked=s.preferences.include_beta;
  const key=s.rows.map(r=>`${r.id}:${r.assessment.code}`).join('|');
  if(key!==optionsKey){
   const selected=$('updates-release').value;optionsKey=key;$('updates-release').replaceChildren();
   for(const row of s.rows){const option=document.createElement('option');option.value=String(row.id);option.textContent=row.version+(row.beta?' · Beta':' · Stable');$('updates-release').append(option);}
   if(s.rows.some(r=>String(r.id)===selected))$('updates-release').value=selected;
   else if(s.suggested)$('updates-release').value=String(s.suggested.id);
  }
  const selected=s.rows.find(r=>String(r.id)===$('updates-release').value)||s.rows[0];
  $('updates-release').disabled=!s.rows.length;
  set('updates-available',s.suggested?.version||'No compatible update identified');
  set('updates-compatibility',selected?labels[selected.assessment.code]||'Compatibility unknown.':'Select an available release after checking.');
  set('updates-notes',selected?.notes||'Release notes will appear here.');
  $('updates-notes-link').href=selected?.url||CoverReleaseDiscovery.RELEASES;
  const notification=s.notification;
  $('firmware-update-link').hidden=!notification;
  set('firmware-update-link',notification||'Update available');
 }
 $('updates-check').onclick=()=>engine.check();
 $('updates-auto').onchange=()=>{engine.setPreferences({automatic:$('updates-auto').checked});engine.tick();};
 $('updates-beta').onchange=()=>engine.setPreferences({include_beta:$('updates-beta').checked});
 $('updates-release').onchange=render;
 const tick=()=>engine.tick();
 document.addEventListener('visibilitychange',tick);window.addEventListener('online',tick);
 window.addEventListener('storage',event=>{if(event.key===CoverReleaseDiscovery.CACHE){engine.restore();render();}});
 api.subscribe(render);setInterval(tick,10000);setInterval(()=>{if(!document.hidden)render();},1000);render();tick();
 };
(() => {
 const api=window.coverAPI;if(!api)return;
 let initialized=false;
 function initialize(){
  if(initialized)return;
  if(!window.CoverSignedUpdates){initialized=true;window.CoverLegacyFirmwareUpdates();return;}
  if(!api.state.session)return;
  initialized=true;
  if(api.state.session.browser_update?.protocol==='browser-signed-v1')window.CoverSignedUpdates.init();
  else window.CoverLegacyFirmwareUpdates();
 }
 api.subscribe(initialize);initialize();
})();
