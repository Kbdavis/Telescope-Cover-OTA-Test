/* Explicit, temporary manual authorization; all motion still uses the cover worker. */
(() => {
 'use strict';
 const api=coverAPI,$=id=>document.getElementById(id);
 let enabled=false,enabledAt=0,enabling=false,rebooting=false,epoch=0,permissionGeneration=0;
 const setText=(id,value)=>{if($(id).textContent!==value)$(id).textContent=value;};
 function disable(){
  const hadPermission=enabled||enabling;++epoch;enabled=false;enabling=false;$('manual-enable').checked=false;
  if($('manualWarning').open)$('manualWarning').close();
  if(hadPermission){
   if(api.state.active || api.state.cover?.holding)api.stop({automatic:true,reason:'manual_disabled',controlGeneration:permissionGeneration});
   api.request('manual/disable',{body:{automatic:'yes',control_generation:permissionGeneration},timeout:900}).catch(()=>{});
  }
  render();
 }
 function reason(){
  const s=api.state,c=s.cover;
  if(!enabled)return 'Manual controls are disabled.';
  if(c?.state==='FAULT')return c.fault||'Inspect and clear the fault first.';
  if(!api.freshCover()||!api.freshPosition())return 'Wait for fresh controller and position feedback.';
  if(!s.session?.beta_accepted||s.session?.setup_only)return 'Accept the beta notice and connect through home Wi-Fi.';
  if(rebooting||s.network?.busy||s.busy||c.maintenance?.locked)return 'Wait for the current request to finish.';
  if(c.moving||s.active&&!c.holding)return 'Servo moving. Use Stop to end movement.';
  if(!(c.manual_ready??c.ready))return c.fault||'Servo startup validation is required.';
  if(c.holding && (!$('manual-hold-torque').checked || c.owner!==Number(api.id)))return 'Holding belongs to another client or torque retention is off. Support the cover, then Stop / release torque.';
  return '';
 }
 function render(){
  if(enabled && (api.now()-enabledAt>=900000 || !api.freshCover())){disable();return;}
  const why=reason();$('manual-fields').disabled=!!why;
  $('manual-enable').checked=enabled;
  $('manual-enable').disabled=enabling||rebooting||!!api.state.cover?.maintenance?.locked;
  $('manual-disable-torque').disabled=rebooting||!!api.state.cover?.maintenance?.locked;
  $('manual-hold-torque').disabled=!!(api.state.cover?.moving||api.state.cover?.holding||enabling||rebooting||api.state.busy||api.state.cover?.maintenance?.locked);
  $('manual-reboot').disabled=rebooting||!api.state.session||api.state.network?.busy||api.state.cover?.moving||!!api.state.cover?.maintenance?.locked;
  setText('manual-reason',why||'Manual control enabled. Saved travel limits and telescope-stow checks are bypassed. Watch the mechanism.');
  const c=api.state.cover;
  for(const option of $('manual-step').options)option.disabled=Number(option.value)>(c?.jog_step_limit??500);
  const a=c?coverTravel.calibration(c,true):{},direction=coverTravel.openingDirection(c);
  setText('manual-minus',direction?'Toward closed':'Decrease raw encoder count');setText('manual-plus',direction?'Toward open':'Increase raw encoder count');
  const reading=coverTravel.estimate(a,c?.position);
  setText('manual-position',api.freshPosition()?(reading.valid?coverTravel.label(reading):`${c.position} counts`):'Travel unavailable');
  setText('manual-torque',c?.torque===true?'Motor holding':c?.torque===false?'Motor released':'Torque unconfirmed');
  setText('manual-state',!api.freshCover()?'Disconnected':c?.fault?'Fault':c?.moving?'Moving':c?.holding?'Holding':'Stationary');
  setText('manual-raw',api.freshPosition()?`${c.position} counts · manual interval 0–4095 · configured interval ${c.minimum}–${c.maximum}`:'Unavailable');
  for(const [id,toward] of [['manual-plus',1],['manual-minus',-1]]){
   const boundary=c?coverTravel.jogReason(c,toward*(direction||1)*Number($('manual-step').value),true):'';
   $(id).disabled=!!boundary;$(id).title=boundary;

  }
 }
 $('manual-enable').onchange=()=>{
  if(!$('manual-enable').checked){disable();return;}
  $('manual-enable').checked=false;$('manualWarning').showModal();
 };
 $('manual-cancel').onclick=disable;
 $('manualWarning').addEventListener('cancel',disable);
 $('manual-accept').onclick=async()=>{
  if(enabling)return;const attempt=++epoch,grantGeneration=api.state.cover?.control_generation;permissionGeneration=grantGeneration;enabling=true;render();
  try{
   await api.request('manual/enable',{body:{acknowledge:'equipment-damage',control_generation:grantGeneration}});
   if(epoch!==attempt||api.state.view!=='manual'){
    await api.request('manual/disable',{body:{automatic:'yes',control_generation:grantGeneration}});return;
   }
   enabled=true;enabledAt=api.now();$('manualWarning').close();api.note('Manual control enabled. Watch the mechanism.');
  }catch(error){api.note(error.message,true);}
  finally{enabling=false;render();}
 };
 async function jog(direction){
  const why=reason();if(why){api.note(why,true);return;}
  const openingDirection=coverTravel.openingDirection(api.state.cover);
  const rawDirection=openingDirection===-1?(direction==='plus'?'minus':'plus'):direction;
  try{await api.command('manual/jog-'+rawDirection,{step:$('manual-step').value,hold:$('manual-hold-torque').checked?'yes':'no'},{motion:true});}
  catch(error){api.note(error.message,true);}
 }
 $('manual-plus').onclick=()=>jog('plus');$('manual-minus').onclick=()=>jog('minus');
 $('manual-step').onchange=render;$('manual-disable-torque').onchange=render;$('manual-stop').onclick=()=>api.stop();
 $('manual-hold-torque').onchange=render;
 $('manual-reboot').onclick=()=>{setText('reboot-torque-warning',$('manual-disable-torque').checked?'Torque will be released before reboot. Support the cover.':'Torque will remain enabled through this controller restart while servo power remains available. No movement will resume automatically.');$('rebootWarning').showModal();};
 $('reboot-cancel').onclick=()=>$('rebootWarning').close();
 $('reboot-accept').onclick=async()=>{
  if(rebooting)return;rebooting=true;$('rebootWarning').close();render();
  setText('manual-reboot-message','Preparing servo torque for reboot…');
  try{
   const token=api.state.session.token;api.expectRestart();
   await api.request('controller/reboot',{body:{confirm:'reboot',disable_torque:$('manual-disable-torque').checked}});
   // The worker takes over holding before reset. Do not send Stop or manual/disable here.
   enabled=false;enabling=false;++epoch;$('manual-enable').checked=false;
   api.state.active=false;api.state.repeats=null;++api.state.generation;
   setText('manual-reboot-message','Restart requested. Waiting for the controller…');
   const deadline=api.now()+25000;
   while(api.now()<deadline){
    await new Promise(resolve=>setTimeout(resolve,750));
    try{await api.boot();}catch(_){continue;}
    if(api.state.session.token!==token){setText('manual-reboot-message','Controller restarted. Manual control is disabled.');return;}
   }
   throw Error('Restart not yet confirmed. Check the controller connection.');
  }catch(error){setText('manual-reboot-message',error.message);api.note(error.message,true);}
  finally{rebooting=false;render();}
 };
 document.addEventListener('controllerrestart',disable);
 window.addEventListener('pagehide',()=>{enabled=false;++epoch;});
 window.manualUI={render,disable,busy:()=>enabling||rebooting};
})();
