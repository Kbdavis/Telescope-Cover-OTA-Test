/* Explicit taught direction defines the continuous travel arc. */
(()=>{
 'use strict';
 const raw=value=>Number.isInteger(value)&&value>=0&&value<4096;
 const wrap=value=>((value%4096)+4096)%4096;
 const openingDirection=c=>[1,-1].includes(c?.assembly_opening_direction)?c.assembly_opening_direction:[1,-1].includes(c?.draft_direction)?c.draft_direction:-1;
 const coordinate=(a,value,margin=10)=>{const n=a.direction*(value-a.closed);if(!a.circular)return n;const p=wrap(n);return p<=a.length+margin?p:p-4096;};
 const contains=(a,value)=>raw(value)&&value>=a.minimum&&value<=a.maximum&&(!a.circular||(coordinate(a,value)>=-10&&coordinate(a,value)<=a.length+10));
 const directPath=(from,to)=>raw(from)&&raw(to)&&Math.abs(to-from)<2048;
 const calibration=(c,draft=false)=>({closed:c[draft?'draft_closed':'closed'],open:c[draft?'draft_open':'open'],
  circular:!!c[draft?'draft_circular':'circular'],direction:c[draft?'draft_direction':'opening_direction'],length:c[draft?'draft_travel_counts':'travel_counts'],
  minimum:c[draft?'draft_minimum':'saved_minimum'],maximum:c[draft?'draft_maximum':'saved_maximum']});
 function supported(a){return raw(a.closed)&&raw(a.open)&&[1,-1].includes(a.direction)&&
  Number.isInteger(a.length)&&a.length>20&&a.length<2048&&a.open===(a.circular?wrap(a.closed+a.direction*a.length):a.closed+a.direction*a.length)&&
  raw(a.minimum)&&raw(a.maximum)&&a.minimum<a.maximum&&(!a.circular||(a.minimum===0&&a.maximum===4095))&&a.closed>=a.minimum&&a.closed<=a.maximum&&a.open>=a.minimum&&a.open<=a.maximum;}
 function estimate(a,value,endpointState=null){
  if(!supported(a))return {valid:false,reason:'Calibration needs review'};
  if(!raw(value))return {valid:false,reason:'Encoder feedback unavailable'};
  if(value<a.minimum||value>a.maximum)return {valid:false,reason:'Outside allowed travel'};
  // The endpoint display allowance is independent of motion safety margins.
  // Use a signed modular coordinate so it also works across encoder zero.
  const counts=coordinate(a,value,endpointState?25:10)||0;
  if(endpointState==='STOPPED'){
   const nearClosed=Math.abs(counts)<=Math.abs(counts-a.length);
   const distance=Math.abs(counts-(nearClosed?0:a.length));
   if(distance<=25){
    const nearEndpoint=nearClosed?'CLOSED':'OPEN';
    const beyond=nearClosed?counts<0:counts>a.length;
    return {valid:false,nearEndpoint,rawCounts:counts,distance,
     reason:`Stopped near ${nearEndpoint}`,
     detail:`${distance} counts ${beyond?'beyond':'from'} taught ${nearEndpoint} endpoint`};
   }
  }
  const endpoint=endpointState==='CLOSED'?0:endpointState==='OPEN'?a.length:null;
  if(endpoint!==null&&Math.abs(counts-endpoint)<=25)
   return {valid:true,counts:endpoint,rawCounts:counts,percent:100*endpoint/a.length,degrees:endpoint*360/4096};
  if(!contains(a,value))return {valid:false,reason:'Outside allowed travel'};
  if(counts<0||counts>a.length)return {valid:false,reason:'Outside taught endpoints',counts};
  return {valid:true,counts,percent:100*counts/a.length,degrees:counts*360/4096};
 }
 function timing(counts,speed,acceleration){
  if(!Number.isInteger(counts)||counts<=0||!Number.isInteger(speed)||speed<=0||!Number.isInteger(acceleration)||acceleration<=0)return null;
  const nominal=Math.ceil(counts*1000/speed),expected=nominal+Math.ceil(20000/acceleration)+500;
  return {nominal,expected,recommended:Math.ceil((expected+Math.max(1500,Math.floor(nominal/4))+1000)/1000)*1000};
 }
 function duration(a,p){
  if(!supported(a))return null;
  const opening=timing(a.length,p.openSpeed,p.acceleration),closing=timing(a.length,p.closeSpeed,p.acceleration);
  return opening&&closing?{opening,closing,recommended:Math.max(opening.recommended,closing.recommended)}:null;
 }
 function timeoutReason(a,p){
  const d=duration(a,p);if(!d)return '';
  return p.timeoutMs<d.recommended?`Timeout ${p.timeoutMs/1000} s is too short for this travel. ${d.recommended<=30000?'Use at least '+d.recommended/1000+' s':'Review speed and travel; the planning recommendation exceeds the 30 s timeout limit'}. Review Calibration → Step 3 → Movement settings.`:'';
 }
 const label=result=>result.nearEndpoint?`${result.reason} · ${result.detail}`:result.valid?`${Number(result.percent.toFixed(1))}% travel`:result.reason;
 function jogReason(c,step,manual=false){
  if(!c||!raw(c.position))return 'Wait for fresh position feedback.';
  if(Math.abs(step)>(c.jog_step_limit??500))return `This firmware limits jogs to ${c.jog_step_limit} counts per step.`;
  if(manual){
   if(raw(c.position+step))return '';
   if(!c.rollover_supported)return 'This step crosses the raw encoder boundary (0–4095). Servo crossing commissioning is required.';
   return ''; // The advertised jog limit was checked above.
  }
  const a=calibration(c,true),target=wrap(c.position+step);
  if(!directPath(c.position,target)&&!c.rollover_supported)return 'Servo reference commissioning is required before crossing encoder zero.';
  if(target<c.minimum||target>c.maximum)return 'This step reaches the allowed travel limit.';
  if(!c.teaching&&supported(a)&&(!contains(a,c.position)||!contains(a,target)||coordinate(a,target)-coordinate(a,c.position)!==a.direction*step))return 'This step reaches the taught travel limit.';
  return '';
 }
 window.coverTravel={raw,wrap,openingDirection,coordinate,contains,jogReason,directPath,calibration,supported,estimate,timing,duration,timeoutReason,label};
})();
