/* Optional diagnostics have their own lease; they never issue motion commands. */
(() => {
  'use strict';
  const api=window.coverAPI,{state}=api,panel=document.getElementById('debug-metrics');
  let generation=0,current=null;
  panel.open=false;
  const allowed=()=>state.view==='debug' && !document.hidden && (state.debugSession || state.network?.enable_debug_tab) &&
    state.session?.beta_accepted && !state.session.setup_only && api.freshCover() &&
    state.cover?.resources?.boot_id===state.session.boot_id;
  const send=(action,session,extra={},keepalive=false)=>api.request('diagnostics/metrics/'+action,
    {body:{boot_id:session.boot,generation:session.generation,...extra},keepalive}).then(JSON.parse);
  function release(session){send('unsubscribe',session,{},true).catch(()=>{});}
  function close(){
    const old=current;current=null;panel.open=false;
    if(old)release(old);
  }
  function sync(){
    if(current && (!panel.open || !allowed() || current.boot!==state.session?.boot_id ||
      (current.subscribed && api.now()-current.ackAt>=5000)))close();
  }
  function open(){
    if(current)return;
    if(!allowed()){panel.open=false;return;}
    const session=current={generation:++generation,boot:state.session.boot_id,subscribed:false,
      openedAt:api.now(),ackAt:0,renewAt:0,pending:false};
    send('subscribe',session,{observed_uptime_ms:state.cover.uptime_ms}).then(reply=>{
      if(current!==session){release(session);return;}
      if(!reply.accepted)throw Error('Subscription rejected');
      session.subscribed=true;session.ackAt=api.now();session.renewAt=api.now();api.emit();
    }).catch(()=>{if(current===session)close();});
  }
  function poll(){
    sync();const session=current;
    if(!session?.subscribed || session.pending || api.now()-session.renewAt<2000)return;
    session.renewAt=api.now();session.pending=true;
    send('renew',session).then(reply=>{
      if(current!==session)return;
      if(!reply.accepted)throw Error('Renewal rejected');
      session.ackAt=api.now();
    }).catch(()=>{if(current===session)close();}).finally(()=>{session.pending=false;});
  }
  panel.addEventListener('toggle',()=>{if(panel.open)open();else close();api.emit();});
  document.addEventListener('visibilitychange',()=>{if(document.hidden)close();});
  window.addEventListener('pagehide',close);
  document.addEventListener('controllerrestart',close);
  api.metrics={sync,poll,isOpen:()=>!!current && panel.open && allowed(),
    hasSnapshot:()=>!!current?.subscribed && state.coverAt>current.openedAt && state.cover?.resources?.available===true};
})();
