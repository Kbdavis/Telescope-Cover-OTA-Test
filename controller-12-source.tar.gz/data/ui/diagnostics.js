/* Assemble support reports in the browser so the ESP32 never buffers an archive. */
(() => {
 'use strict';
 const api=window.coverAPI,{state}=api;
 const button=document.getElementById('cfg-download-diagnostics');
 const feedback=document.getElementById('cfg-download-message');
 let busy=false;
 const stamp=()=>new Date().toISOString();
 const clone=value=>value==null?null:JSON.parse(JSON.stringify(value));
 const identity=s=>s?{boot_id:s.boot_id,firmware_id:s.firmware_id,firmware:s.firmware,setup_only:s.setup_only,beta_accepted:s.beta_accepted}:null;
 function sanitize(value,privateValues){
  if(Array.isArray(value))return value.map(item=>sanitize(item,privateValues));
  if(value && typeof value==='object')return Object.fromEntries(Object.entries(value).map(([key,item])=>
   [key,/password|passphrase|secret|token|verifier|credential|authorization|^(?:api|auth|seestar)[_-]?key$/i.test(key)?'[redacted]':sanitize(item,privateValues)]));
  if(typeof value!=='string')return value;
  // Free-text events and errors can contain assignments, too. Never export the session token.
  for(const token of privateValues)if(token)value=value.split(token).join('[redacted]');
  return value.replace(/\bauthorization\s*[=:]\s*[^\r\n]+/gi,'authorization=[redacted]')
   .replace(/(\b[\w-]*(?:password|passphrase|secret|token|verifier|credential|api[_-]?key|auth[_-]?key|seestar[_-]?key)\s*[=:]\s*)(?:"[^"\r\n]*"|'[^'\r\n]*'|[^\s,;}]+)/gi,'$1[redacted]');
 }
 function paused(){
  const c=state.cover;
  return state.active || state.busy || state.repeats || c?.moving || c?.holding ||
   c?.maintenance?.locked || c?.ota?.active || state.network?.busy;
 }
 async function collect(){
  // Freeze fallback evidence before requests or background polling can replace it.
  const start=stamp(),mono=api.now(),session=identity(state.session);
  const privateValues=new Set([state.session?.token]);
  const report={schema_version:1,kind:'telescope-cover-diagnostics',started_at_utc:start,
   session,consistency:'unverified',partial:false,notes:[
    'Sections are collected sequentially, not as an atomic snapshot. Times ending in _utc use the browser clock.',
    'Cached data is last known browser evidence, not proof of current controller or cover state.',
    'Includes network names, local addresses and event messages. Review before sharing.',
    'Passwords and authentication fields are redacted. Unsaved form inputs are excluded.',
    'Saved calibration and controller draft are in controller data. No servo registers are read or written.',
    'Optional metrics are included only if already active; downloading does not enable them.'
   ],sections:{}};
  const cached={controller:clone(state.cover),configuration:clone(state.network),telescope:clone(state.scope)};
  // Nearby scan results are unrelated to this controller's configuration.
  if(cached.configuration)delete cached.configuration.networks;
  const ages={controller:state.coverAt,configuration:state.networkAt,telescope:state.scopeAt};
  const safe=()=>!paused();
  let sessionOk=false,boot=null,setupOnly=!!state.session?.setup_only;
  if(safe()){
   try{const current=await api.request('session');privateValues.add(current.token);report.session=identity(current);boot=current.boot_id;sessionOk=!!boot;setupOnly=!!current.setup_only;}
   catch(_){report.notes.push('Controller session could not be verified; only cached evidence is exported.');}
  }
  async function section(name,path){
   const item={source:'/api/'+path,captured_at_utc:stamp(),cached:false,data:null};
   report.sections[name]=item;
   try{
    if(!sessionOk || !safe())throw Error('Live collection paused or unavailable; cached evidence only.');
    if(setupOnly && (path.startsWith('debug') || path==='diagnostics/servo' || path.endsWith('/trace')))throw Error('Detailed diagnostics require home Wi-Fi.');
    item.data=await api.request(path);
    if(name==='configuration')delete item.data.networks;
   }catch(error){
    item.error=error.message;item.data=cached[name]??null;item.cached=item.data!==null;
    if(item.cached){item.cache_age_ms=Math.max(0,Math.round(mono-ages[name]));item.cached_session=session;}
    report.partial=true;
   }
   item.completed_at_utc=stamp();return item;
  }
  await section('controller','status');
  // A fresh response can revoke the initial clearance even before normal polling sees it.
  const current=report.sections.controller;
  if(!current.cached && (current.data?.moving || current.data?.holding || current.data?.maintenance?.locked || current.data?.ota?.active))sessionOk=false;
  await section('configuration','network');
  if(report.sections.configuration.data?.busy)sessionOk=false;
  await section('telescope','alpaca/status');
  await section('motion_trace','motion/trace');
  await section('heartbeat_trace','heartbeat/trace');
  await section('servo_evidence','diagnostics/servo');
  if(sessionOk && safe() && !setupOnly)await new Promise(resolve=>setTimeout(resolve,1100));
  await section('retained_failure','debug/retained');
  if(sessionOk && safe() && !setupOnly)await new Promise(resolve=>setTimeout(resolve,1100));
  const logs=await section('controller_events','debug');
  if(logs.data && !logs.cached){
   // The endpoint returns bounded pages and shares a two-reads/second budget.
   // Keep every envelope (including loss counters); bound collection to eight pages.
   logs.data={pages:[logs.data],complete:!logs.data.more};
   let page=logs.data.pages[0];
   for(let n=1;page.more && n<8;n++){
    if(!safe() || page.boot_id!==boot){logs.error='Event collection interrupted or controller restarted.';break;}
    await new Promise(resolve=>setTimeout(resolve,1100));
    try{
     if(!safe())throw Error('Event collection paused.');
     const next=await api.request('debug?after='+page.next_after+'&boot_id='+encodeURIComponent(page.boot_id)+'&sequence_epoch='+page.sequence_epoch);
     logs.data.pages.push(next);
     if(next.boot_id!==boot || next.cursor_reset || next.sequence_epoch!==page.sequence_epoch || next.more && next.next_after<=page.next_after){
      throw Error('Controller event window changed during collection.');
     }
     page=next;logs.data.complete=!page.more;
    }catch(error){logs.error=error.message;logs.data.complete=false;break;}
   }
   if(!logs.data.complete){logs.error ||= 'Event download reached its bounded page limit.';report.partial=true;}
   if(logs.data.pages.some(p=>p.available===false))report.partial=true;
   logs.completed_at_utc=stamp();
  }
  if(sessionOk && safe()){
   try{
    const reply=await api.request('session');privateValues.add(reply.token);
    const end=identity(reply);report.ending_session=end;
    const eventBoots=logs.data?.pages?.map(page=>page.boot_id)??[];
    const retainedBoot=report.sections.retained_failure.data?.current_boot;
    const traceBoots=['motion_trace','heartbeat_trace','servo_evidence'].map(name=>report.sections[name].data?.boot_id);
    report.consistency=[end.boot_id,current.data?.resources?.boot_id,...eventBoots,retainedBoot,...traceBoots].filter(Boolean).every(value=>value===boot)?'same_boot':'controller_restarted';
   }catch(_){report.notes.push('Ending controller session could not be verified.');}
  }
  if(report.consistency!=='same_boot')report.partial=true;
  report.sections.browser={captured_at_utc:stamp(),data:{
   view:state.view,online:navigator.onLine,user_agent:navigator.userAgent,
   events:clone(state.events),messages:clone(state.debugMessages)
  }};
  report.completed_at_utc=stamp();privateValues.add(state.session?.token);return sanitize(report,privateValues);
 }
 async function download(){
  if(busy)return;
  busy=true;button.disabled=true;feedback.textContent='Collecting diagnostics…';
  try{
   const report=await collect();
   const blob=new Blob([JSON.stringify(report,null,2)+'\n'],{type:'application/json'});
   const url=URL.createObjectURL(blob),link=document.createElement('a');
   try{
    link.href=url;link.download='telescope-cover-diagnostics-'+report.started_at_utc.replace(/[:.]/g,'-')+'.json';
    document.body.append(link);link.click();
   }finally{link.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);}
   feedback.textContent=report.partial?'Diagnostics download started. Some sections are cached or unavailable; details are included in the file.':'Diagnostics download started.';
  }catch(_){feedback.textContent='Could not prepare diagnostics. Try downloading again.';}
  finally{busy=false;button.disabled=false;}
 }
 button.onclick=download;
 api.diagnostics={collect,download,busy:()=>busy};
})();
