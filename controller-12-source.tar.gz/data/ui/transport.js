/* Live controller transport. One shared state/polling layer for all three views. */
(() => {
  'use strict';
  const id = String(crypto.getRandomValues(new Uint32Array(1))[0] % 999999999 + 1);
  const state = {cover:null, scope:null, network:null, session:null, coverAt:0, scopeAt:0, networkAt:0,
    view:'overview', active:false, busy:false, generation:0, command:0, message:'Connecting to controller…',
    error:false, debugMessages:[], debugRevision:0, debugAvailable:true, events:[], scopeLast:null, scopeLastAt:0, scopeLastReceived:0, repeats:null};
  const listeners = new Set();
  const debugSessionKey='cover.debugSession.v1';
  try{state.debugSession=window.sessionStorage.getItem(debugSessionKey)==='true';}catch(_){state.debugSession=false;}
  function setSessionDebug(enabled){
    state.debugSession=!!enabled;
    try{if(enabled)window.sessionStorage.setItem(debugSessionKey,'true');else window.sessionStorage.removeItem(debugSessionKey);}catch(_){}
    emit();
  }
  const emit = () => listeners.forEach(fn => fn());
  const now = () => performance.now();
  const traceEvents=[];let frozenTrace=null;
  function trace(kind,detail={}){traceEvents.push({ms:Math.round(now()),kind,...detail});if(traceEvents.length>200)traceEvents.shift();}
  function freezeTrace(reason){if(!frozenTrace)frozenTrace={reason,ms:Math.round(now()),events:traceEvents.slice()};}
  function exportTrace(){
    const payload={client:id,firmware:state.cover?.firmware_id,frozen:frozenTrace,events:traceEvents.slice()};
    const url=URL.createObjectURL(new Blob([JSON.stringify(payload,null,2)],{type:'application/json'}));
    const link=document.createElement('a');link.href=url;link.download='cover-heartbeat-trace.json';link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
  }
  const note = (message, error=false) => {
    state.message=message;state.error=error;
    if (state.events[0]?.message!==message) {
      state.events.unshift({message,receivedAt:Date.now(),receivedMono:now(),time:new Date().toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'})});
      state.events.length=Math.min(6,state.events.length);
    }
    emit();
  };
  function freshCover() { return !!(state.cover && now()-state.coverAt<1500); }
  function freshPosition() {return freshCover() && Number.isFinite(state.cover.position) && state.cover.age_ms+now()-state.coverAt<1500;}
  function servoSetupOnly() {const c=state.cover;return freshCover() && c.settings_offline_allowed===true && !c.ready && c.state!=='FAULT' && !c.moving && !c.holding;}
  function freshScope() {const a=state.scope;return !!(a?.enabled && a.valid && a.connected && a.age_ms+now()-state.scopeAt<=5000);}
  function freshStow() {const a=state.scope;return freshScope() && a.at_home===true && a.stowed_observation===true && !a.slewing && !a.tracking && !a.stow_locked && !a.arm_locked;}
  function displayedScope() {
    if(freshScope())return state.scope;
    const a=state.scope;
    if(a && (!a.enabled || a.connected===false || a.slewing===true || a.at_home===false))return a.valid?a:null;
    return state.scopeLast && now()-state.scopeLastAt<10000?state.scopeLast:null;
  }
  function displayedStow() {
    if(freshStow())return true;
    const a=state.scope;
    if(a && (!a.enabled || a.connected===false || a.at_home===false || a.slewing || a.tracking || a.arm_locked || a.stow_locked))return false;
    return !!(state.scopeLast?.stowed_observation && now()-state.scopeLastAt<10000);
  }
  function metric(key) {
    const a=state.scope;
    return a && a[key]!==null && a[key]!==undefined && Number.isFinite(a[key+'_age_ms']) && a[key+'_age_ms']+now()-state.scopeAt<=60000 ? a[key] : null;
  }
  // Persist only the per-tab attempt count. A short-lived successful request
  // must not turn a failing page into an endless reload loop.
  const reloadKey='cover.connectionReloads.v1',reloadLimit=2,reloadDelay=10000,healthyResetDelay=30000;
  let visibleSince=now(),lastFreshAt=now(),healthySince=null,lastHealthyTick=0,reloading=false,connectionNotice=null;
  function reloadAttempts(){
    try {
      const stored=window.sessionStorage.getItem(reloadKey);
      return stored===null?0:/^[0-2]$/.test(stored)?Number(stored):reloadLimit;
    } catch(_){return null;} // No persistent budget means no automatic reload.
  }
  function connectionUnavailable(){
    const attempts=reloadAttempts();
    const message=attempts===reloadLimit?'Controller connection unavailable. Automatic reloads stopped after two attempts; check its network and reload manually. Controls stay locked.':
      'Controller connection unavailable. Reconnect to its network; controls stay locked.';
    connectionNotice=message;note(message,true);
  }
  function connectionRestored(){
    if(connectionNotice && state.message===connectionNotice)note('Controller connection restored. Check status before moving.');
    connectionNotice=null;
  }
  function recoveryTick(){
    if(window.coverFirmwareUpdateActive){lastFreshAt=now();healthySince=null;return;}
    const time=now();
    if(reloading)return;
    if(document.hidden){visibleSince=time;healthySince=null;return;}
    if(freshCover() && state.session){
      lastFreshAt=time;
      if(healthySince===null || time-lastHealthyTick>2000)healthySince=time;
      lastHealthyTick=time;
      if(time-healthySince>=healthyResetDelay && reloadAttempts()>0){
        try{window.sessionStorage.removeItem(reloadKey);}catch(_){}
      }
      return;
    }
    healthySince=null;
    if(time-Math.max(visibleSince,lastFreshAt)<reloadDelay)return;
    // Do not discard drafts, interrupt maintenance, or obscure an unresolved move.
    if(state.active || state.repeats || state.busy || state.cover?.moving || state.cover?.holding || state.cover?.dirty ||
       state.cover?.maintenance?.locked || state.cover?.ota?.active || state.network?.busy)return;
    try{if(api.canAutoReload?.()!==true)return;}catch(_){return;}
    const attempts=reloadAttempts();
    if(attempts===null || attempts>=reloadLimit){
      if(state.message!==connectionNotice || !connectionNotice)connectionUnavailable();
      return;
    }
    // Verify the count was saved before navigating, including after a restored
    // history page. Storage failure cannot silently reset the retry budget.
    try{
      window.sessionStorage.setItem(reloadKey,String(attempts+1));
      if(window.sessionStorage.getItem(reloadKey)!==String(attempts+1))return;
    }catch(_){return;}
    reloading=true;
    state.generation++;state.active=false;state.repeats=null;activeRequest=0;
    try{note(`Controller connection unavailable. Reloading page (${attempts+1} of ${reloadLimit})…`,true);}catch(_){}
    window.location.reload();
  }
  function returnedToPage(){if(!document.hidden){visibleSince=now();healthySince=null;}}
  window.addEventListener('pageshow',returnedToPage);
  document.addEventListener('visibilitychange',returnedToPage);
  let debugCursor=0,debugBoot='',debugEpoch=0,debugAt=0;const requestFailures=new Map();
  function debugMessage(source,message,time=new Date().toLocaleTimeString(),level='warn',coalesceKey=null){
    level=['error','warn','info'].includes(level)?level:'info';
    const last=state.debugMessages[state.debugMessages.length-1];
    // Request incidents have a stable key even after recovery updates their text.
    // Intervening events still retain their order.
    if(last && last.source===source && last.level===level && (coalesceKey ? last.coalesceKey===coalesceKey : !last.coalesceKey && last.message===message)){
      last.message=message;
      ++last.count;last.lastTime=time;last.lastReceivedAt=Date.now();last.lastReceivedMono=now();
    }else{
      state.debugMessages.push({source,message,time,lastTime:time,level,coalesceKey,count:1,receivedAt:Date.now(),receivedMono:now(),lastReceivedAt:Date.now(),lastReceivedMono:now()});
      if(state.debugMessages.length>1000)state.debugMessages.shift();
    }
    ++state.debugRevision;
    return state.debugMessages[state.debugMessages.length-1];
  }
  async function debugPoll(){
    debugAt=now();const data=await request('debug?after='+debugCursor+(debugBoot?'&boot_id='+encodeURIComponent(debugBoot)+'&sequence_epoch='+debugEpoch:''));
    state.debugAvailable=data.available!==false;
    if(data.schema_version===1){
      if(data.cursor_reset || debugBoot && (debugBoot!==data.boot_id || debugEpoch!==data.sequence_epoch)){
        debugCursor=0;debugMessage('Controller','Controller event cursor reset; a new boot or sequence epoch started.');
      }
      debugBoot=data.boot_id;debugEpoch=data.sequence_epoch;
    }
    for(const entry of data.entries){
      if(entry.sequence<=debugCursor)continue;
      if(entry.sequence>debugCursor+1)debugMessage('Controller','Earlier messages were overwritten in the controller log.');
      const seconds=Math.floor(Math.max(0,entry.ms)/1000);
      const uptime=[Math.floor(seconds/3600),Math.floor(seconds/60)%60,seconds%60].map(v=>String(v).padStart(2,'0')).join(':');
      debugCursor=entry.sequence;debugMessage('Controller',entry.message+(entry.truncated?' [truncated]':''),`${entry.local_time || 'Time unsynchronized'} · uptime ${uptime}`,entry.level);
    }
    if(data.schema_version===1 && Number.isInteger(data.next_after))debugCursor=data.next_after;
  }

  async function request(path, {body=null, timeout=1200, keepalive=false}={}) {
    const headers = body===null ? {} : {'X-Cover-Token':state.session?.token || '', 'X-Cover-Client':id, 'Content-Type':'application/x-www-form-urlencoded'};
    const key=path.split('?')[0];const began=now();
    try {
    const response = await fetch('/api/'+path,{method:body===null?'GET':'POST',headers,body:body===null?undefined:new URLSearchParams({control_generation:state.cover?.control_generation,...body}),cache:'no-store',keepalive,signal:keepalive?undefined:AbortSignal.timeout(timeout)});
    const content=await response.text();
    if(!response.ok)throw Error('HTTP '+response.status+(content?' — '+content:''));
    const result=body===null ? JSON.parse(content) : content;
    const failure=requestFailures.get(key);
    if(failure){
      failure.entry.message+=` Communication recovered at ${new Date().toLocaleTimeString()}.`;
      ++state.debugRevision;
      requestFailures.delete(key);
    }
    if(now()-began>1000)debugMessage('Browser',`Slow controller response (${key}): ${Math.round(now()-began)} ms.`);
    return result;
    }catch(error){
      const last=requestFailures.get(key);
      if(last===undefined || now()-last.at>=5000){
        const message=`Controller request failed (${key}): ${error.name==='TimeoutError'?'timeout':error.message.startsWith('HTTP ')?error.message.split(' — ')[0]:error.name}.`;
        const entry=debugMessage('Browser',message,undefined,'warn',message);
        requestFailures.set(key,{at:now(),entry});
      }
      throw error;
    }
  }
  let coverRequest=null,scopeRequest=null,networkRequest=null,bootRequest=null;
  let previousUptime=0, previousNotice='', activeRequest=0, activeControlGeneration=0, started=0, expectedBoot=false;
  async function boot() {
    if(bootRequest)return bootRequest;
    bootRequest=(async()=>{
      const session=await request('session');
      if(state.session && session.token!==state.session.token){
        debugCursor=0;debugBoot='';debugEpoch=0;debugMessage("Browser","Controller restarted; controller debug log reset.");
        state.generation++;state.active=false;state.repeats=null;activeRequest=0;
        note(expectedBoot?'Controller restarted. Checking saved settings…':'Controller restarted. Supervision cleared; inspect status before moving.');
        document.dispatchEvent(new Event('controllerrestart'));expectedBoot=false;
      }
      state.session=session;emit();
    })().finally(()=>bootRequest=null);
    return bootRequest;
  }
  async function cover() {
    if(coverRequest)return coverRequest;
    coverRequest=(async()=>{
      const statusStart=now();
      let reading;try{reading=await request('status');trace('status',{duration:Math.round(now()-statusStart),state:reading.state,heartbeat_age:reading.heartbeat_age_ms});}
      catch(error){trace('status-error',{duration:Math.round(now()-statusStart)});throw error;}
      if(reading.state==='FAULT')freezeTrace(reading.fault);

      if(previousUptime && reading.uptime_ms<previousUptime || reading.resources?.boot_id && reading.resources.boot_id!==state.session?.boot_id)await boot();
      previousUptime=reading.uptime_ms;state.cover=reading;state.coverAt=now();
      connectionRestored();
      if(state.active && activeControlGeneration && reading.control_generation!==activeControlGeneration){
        state.generation++;state.active=false;state.repeats=null;activeRequest=0;
        note('Controller control generation changed. Supervision cleared; no movement will resume automatically.');
      }
      if(reading.notice && reading.notice!==previousNotice){previousNotice=reading.notice;note(reading.notice,reading.state==='FAULT');}
      if(state.active && activeRequest && reading.command_client===Number(id) && reading.command_id===activeRequest) {
        if(!reading.command_ok || reading.state==='FAULT' || (!reading.moving && !reading.holding)) {
          state.active=false;
          if(!reading.command_ok || reading.state==='FAULT')state.repeats=null;
          document.dispatchEvent(new CustomEvent('coverfinished',{detail:reading}));
        }
      }
      if(state.active && reading.owner && reading.owner!==Number(id)){state.active=false;state.repeats=null;note('Another client owns this movement. Supervision was not transferred.',true);}
      emit();return reading;
    })().finally(()=>coverRequest=null);
    return coverRequest;
  }
  async function scope() {
    if(scopeRequest)return scopeRequest;
    scopeRequest=(async()=>{
      const reading=await request('alpaca/status');state.scope=reading;state.scopeAt=now();
      if(!reading.enabled || reading.connected===false){state.scopeLast=null;}
      else if(freshScope()) {state.scopeLast={...reading};state.scopeLastAt=state.scopeAt-reading.age_ms;state.scopeLastReceived=state.scopeAt;}
      emit();return reading;
    })().finally(()=>scopeRequest=null);
    return scopeRequest;
  }
  async function network() {
    if(networkRequest)return networkRequest;
    networkRequest=request('network',{timeout:1800}).then(async reading=>{if(state.network?.busy && !reading.busy)await cover();state.network=reading;state.networkAt=now();emit();return reading;}).finally(()=>networkRequest=null);
    return networkRequest;
  }
  const pause=ms=>new Promise(resolve=>setTimeout(resolve,ms));
  async function command(path, parameters={}, {motion=false}={}) {
    if(state.busy)throw Error('Wait for the current request to finish.');
    if(!state.session)throw Error('Wait for the controller connection.');
    const generation=++state.generation, requestId=++state.command,controlGeneration=state.cover?.control_generation;
    state.busy=true;
    if(motion){state.active=true;activeRequest=requestId;activeControlGeneration=controlGeneration;started=now();}
    emit();
    try {
      await request(path,{body:{...parameters,request_id:requestId,control_generation:controlGeneration},timeout:900});
      const deadline=now()+3500;
      while(now()<deadline) {
        if(generation!==state.generation)throw Error('Request interrupted. No movement will resume automatically.');
        const reading=await cover();
        if(reading.command_client===Number(id) && reading.command_id===requestId) {
          if(!reading.command_ok)throw Error(reading.notice || 'Controller rejected the command.');
          note(reading.notice || 'Command applied.');return reading;
        }
        await pause(90);
      }
      throw Error('Command outcome unconfirmed. Inspect status before retrying.');
    } catch(error) {
      if(motion){state.active=false;state.repeats=null;await automaticStop('command_cleanup',controlGeneration).catch(()=>{});}
      note(error.message,true);throw error;
    } finally {
      // A release can overtake an in-flight start; send Stop after the start settles.
      if(motion && generation!==state.generation)await automaticStop('command_cleanup',controlGeneration).catch(()=>{});
      state.busy=false;emit();
    }
  }
  function automaticStop(reason,controlGeneration=activeControlGeneration || state.cover?.control_generation,keepalive=false){
    return request('stop',{body:{automatic:'yes',stop_reason:reason,control_generation:controlGeneration},timeout:900,keepalive});
  }
  async function stop({automatic=false,reason='supervision',controlGeneration=activeControlGeneration || state.cover?.control_generation}={}) {
    trace('stop',{automatic});
    state.generation++;state.active=false;state.repeats=null;activeRequest=0;emit();
    try {await (automatic?automaticStop(reason,controlGeneration):request('stop',{body:{},timeout:900}));note('Stop requested. Confirm torque release in the status bar.');await cover();}
    catch(error){note('Stop delivery unconfirmed. Heartbeat stopped; inspect the controller and support the cover.',true);}
  }
  let beating=false,beatSequence=0,lastTimer=0,lastSend=0,lastRtt=0,skipped=0;
  async function heartbeat() {
    if(!state.active)return;
    const timerAt=now(),timerGap=lastTimer?timerAt-lastTimer:0;lastTimer=timerAt;
    if(beating){++skipped;trace('heartbeat-skipped',{timer_gap:Math.round(timerGap)});return;}
    if(document.hidden || !freshCover() || now()-started>(state.cover?.timeout_ms || 5000)+2000 && !state.cover?.holding){await stop({automatic:true,reason:'supervision'});return;}
    beating=true;const generation=state.generation,controlGeneration=activeControlGeneration;
    const sent=now(),seq=++beatSequence;
    const detail={control_generation:controlGeneration,seq,b_ms:Math.round(sent),gen:generation,send_gap:Math.round(lastSend?sent-lastSend:0),timer_gap:Math.round(timerGap),skipped,prev_rtt:Math.round(lastRtt),status_age:Math.round(sent-state.coverAt)};
    lastSend=sent;skipped=0;trace('heartbeat-send',detail);
    try {await request('heartbeat',{body:detail,timeout:700});lastRtt=now()-sent;trace('heartbeat-response',{seq,rtt:Math.round(lastRtt)});}
    catch(error){trace('heartbeat-error',{seq,elapsed:Math.round(now()-sent)});freezeTrace('heartbeat request failed');if(generation===state.generation){state.generation++;state.active=false;state.repeats=null;note('Supervision heartbeat lost. Movement will not resume; inspect status.',true);automaticStop('heartbeat_lost',controlGeneration).catch(()=>{});}}
    finally {beating=false;}
  }
  function leave() {
    if(!state.active && !state.repeats)return;
    state.generation++;state.active=false;state.repeats=null;activeRequest=0;
    automaticStop('page_hidden',activeControlGeneration || state.cover?.control_generation,true).catch(()=>{});emit();
  }
  window.addEventListener('pagehide',()=>{trace('pagehide');leave();});
  window.addEventListener('blur',()=>trace('blur'));
  document.addEventListener('visibilitychange',()=>trace('visibility',{hidden:document.hidden}));
  window.addEventListener('blur',()=>{if(state.active || state.repeats)stop({automatic:true,reason:'window_blur'});});
  document.addEventListener('visibilitychange',()=>{if(document.hidden)leave();});
  const api=window.coverAPI={state,id,now,emit,note,request,command,stop,automaticStop,cover,scope,network,boot,freshCover,freshPosition,servoSetupOnly,freshScope,freshStow,displayedScope,displayedStow,metric,exportTrace,setSessionDebug,
    subscribe:fn=>listeners.add(fn), expectRestart:()=>{expectedBoot=true;}, start};
  async function start() {
    // Independent of the awaited polling chain: it can recover a stranded
    // request after the browser suspends/restores this page, including startup.
    setInterval(recoveryTick,1000);
    try {await boot();await cover();await network();await scope();}
    catch(error){note('Connecting to controller. '+error.message,true);}
    setInterval(heartbeat,100);
    async function poll() {
      try {
        if(window.coverFirmwareUpdateActive)return;
        if(!state.session)await boot();
        await cover();
        api.metrics?.poll();
        api.retained?.poll();
        if(now()-state.scopeAt>=1200)await scope().catch(()=>{});
        if(!state.active && now()-state.networkAt>=2500)await network().catch(()=>{});
        if((state.debugSession || state.network?.enable_debug_tab) && !state.active && !state.cover?.moving && !state.cover?.holding && now()-debugAt>=3000)await debugPoll().catch(()=>{});
      } catch(error) {
        if(!freshCover()) {if(state.active)leave();connectionUnavailable();}
      } finally {setTimeout(poll,state.active?170:400);emit();}
    }
    poll();setInterval(emit,250);
  }
})();
