/* Read-only public release discovery. Never calls controller mutation routes. */
(function(root,factory){
 if(typeof module==='object' && module.exports)module.exports=factory(require('./release_metadata.js'));
 else root.CoverReleaseDiscovery=factory(root.CoverReleaseMetadata);
})(typeof globalThis==='object'?globalThis:this,function(model){
 'use strict';
 const API='https://api.github.com/repos/Kbdavis/Telescope-Cover/releases?per_page=30';
 const CATALOG='https://kbdavis.github.io/Telescope-Cover/firmware/catalog-preview.json';
 const RELEASES='https://github.com/Kbdavis/Telescope-Cover/releases';
 const HOUR=3600000,STALE=24*HOUR,COOLDOWN=60000,MAX_TOTAL=1048576;
 const CACHE='cover.releaseDiscovery.preview.v1',PREF='cover.releasePreferences.v1',LEASE=CACHE+'.lease';
 const safeJson=text=>{try{return JSON.parse(text);}catch(_){return null;}};
 function normalize(raw){
  if(!raw || typeof raw!=='object' || !Number.isSafeInteger(raw.id) || raw.id<=0 ||
     typeof raw.draft!=='boolean' || typeof raw.prerelease!=='boolean')throw Error('invalid-metadata');
  if(raw.draft || raw.published_at===null)return null;
  if(typeof raw.published_at!=='string' || !/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\dZ$/.test(raw.published_at) ||
     !Number.isFinite(Date.parse(raw.published_at)))throw Error('invalid-metadata');
  if(typeof raw.tag_name!=='string' || !/^v\d+\.\d+\.\d+(?:-(?:alpha|beta|rc)\.[1-9]\d*)?$/.test(raw.tag_name))throw Error('invalid-metadata');
  const version=raw.tag_name.slice(1);let parsed;
  try{parsed=model.parseVersion(version);}catch(_){throw Error('invalid-metadata');}
  if(Boolean(parsed.prerelease.length)!==raw.prerelease)throw Error('invalid-metadata');
  if(raw.body!==null && typeof raw.body!=='string')throw Error('invalid-metadata');
  return {id:raw.id,tag:raw.tag_name,version,beta:raw.prerelease,published_at:raw.published_at,
   notes:new TextDecoder().decode(new TextEncoder().encode((raw.body||'No release notes provided.').slice(0,16384)).subarray(0,16384),{stream:true}),
   url:RELEASES+'/tag/'+encodeURIComponent(raw.tag_name)};
 }
 function nextPage(link){
  const match=/<([^>]+)>\s*;\s*rel="next"/.exec(link||'');if(!match)return null;
  const url=new URL(match[1]);
  if(url.origin!=='https://api.github.com' || url.username || url.password || url.hash ||
     !(/^\/repos\/Kbdavis\/Telescope-Cover\/releases$/i.test(url.pathname) || /^\/repositories\/\d+\/releases$/.test(url.pathname)) ||
     [...url.searchParams.keys()].some(k=>!['page','per_page'].includes(k)) ||
     url.searchParams.get('per_page')!=='30' || !/^[1-9]\d*$/.test(url.searchParams.get('page')||''))throw Error('invalid-pagination');
  return url.href;
 }
 class Discovery {
  constructor({fetch,clock=Date.now,storage=null,visible=()=>true,random=Math.random,onChange=()=>{},getDevice=()=>null,getFirmware=()=>null}){
   Object.assign(this,{fetch,clock,storage,visible,random,onChange,getDevice,getFirmware});
   this.owner=String(random());this.inflight=false;this.failures=0;this.pages={};
   this.state={status:'unchecked',catalog_status:'unavailable',releases:[],catalog:null,
    last_attempt:0,last_success:0,next_check:0,retry_at:0,rate_limit_until:0,incomplete:false};
   this.preferences={automatic:true,include_beta:false};
   const preferences=this.read(PREF);
   if(preferences && typeof preferences.automatic==='boolean' && typeof preferences.include_beta==='boolean')this.preferences=preferences;
   this.restore();
  }
  read(key){try{const s=this.storage?.getItem(key);return s && s.length<=1500000?safeJson(s):null;}catch(_){return null;}}
  write(key,value){try{const encoded=JSON.stringify(value);if(encoded.length<=1500000)this.storage?.setItem(key,encoded);}catch(_){}}
  restore(){
   const cache=this.read(CACHE),now=this.clock();
   if(!cache || ![1,2].includes(cache.schema) || !Number.isFinite(cache.saved_at) || cache.saved_at>now || now-cache.saved_at>7*STALE)return;
   const s=cache.state;
   const rateLimit=cache.schema===1?(s?.status==='rate-limited'?s.retry_at:0):s?.rate_limit_until;
   if(!s || !Number.isFinite(s.last_attempt) || !Number.isFinite(s.last_success) || !Number.isFinite(s.retry_at) ||
      !Number.isFinite(s.next_check) || [s.last_attempt,s.last_success].some(t=>t<0||t>now) ||
      !Number.isFinite(rateLimit) || rateLimit<0 || rateLimit>now+STALE ||
      s.retry_at>now+STALE || s.next_check>now+STALE || !Array.isArray(s.releases) || s.releases.length>90)return;
   try{
    // Revalidate cached provider data instead of trusting stored compatibility verdicts.
    const pages={};
    for(const [url,p] of Object.entries(cache.pages||{})){
     if(url!==API && nextPage('<'+url+'>; rel="next"')!==url)throw Error('invalid-cache');
     if(!p || typeof p.etag!=='string' || p.etag.length>200 || !Array.isArray(p.raw) || p.raw.length>30)throw Error('invalid-cache');
     p.raw.forEach(normalize);pages[url]=p;
    }
    if(Object.keys(pages).length>3)throw Error('invalid-cache');
    const catalog=s.catalog?model.parseCatalogJson(JSON.stringify(s.catalog)):null;
    const releases=Object.values(pages).flatMap(p=>p.raw.map(normalize).filter(Boolean));
    if(new Set(releases.map(r=>r.id)).size!==releases.length)throw Error('invalid-cache');
    const errors=['rate-limited','offline','access-unavailable','server-error','invalid-metadata','invalid-pagination','response-too-large','invalid-cache','browser-unsupported','paused'];
    this.pages=pages;this.state={...this.state,last_attempt:s.last_attempt,last_success:s.last_success,
     retry_at:s.retry_at,rate_limit_until:rateLimit,next_check:s.next_check,incomplete:s.incomplete===true,releases,catalog,
     status:errors.includes(s.status)?s.status:s.last_success?'cached':'unchecked',catalog_status:catalog?'cached':'unavailable'};
   }catch(_){/* Corrupt cache is discarded; it never becomes current firmware. */}
  }
  save(){this.write(CACHE,{schema:2,saved_at:this.clock(),state:{...this.state,releases:[]},pages:this.pages});}
  setPreferences(changes){
   for(const k of ['automatic','include_beta'])if(typeof changes[k]==='boolean')this.preferences[k]=changes[k];
   this.write(PREF,this.preferences);this.onChange();
  }
  snapshot(){
   const now=this.clock(),s=this.state,device=this.getDevice(),firmware=this.getFirmware();
   if(s.last_attempt>now || s.last_success>now){
    Object.assign(s,{status:'clock-changed',last_attempt:0,last_success:0,next_check:0,retry_at:0,rate_limit_until:0,releases:[],catalog:null});this.pages={};
   }
   const stale=Boolean(s.last_success && (now<s.last_success || now-s.last_success>=STALE));
   let metadataError=false;
   const rows=s.releases.filter(r=>this.preferences.include_beta || !r.beta).map(release=>{
    const entry=s.catalog?.releases.find(e=>e.release_id===release.id && e.metadata.tag===release.tag && e.metadata.channel===(release.beta?'beta':'stable'));
    let assessment={code:'compatibility-unknown',compatible:false,update_available:false,method:null,installable:false};
    if(entry && device){try{
     model.validateDevice(device);
     const matches=firmware && ['version','commit','elf','build_profile','release','dirty'].every(k=>firmware[k]===device.firmware[k]);
     if(matches)assessment=model.assessRelease(entry.metadata,device,{include_beta:this.preferences.include_beta});
    }catch(_){metadataError=true;}}
    return {...release,assessment};
   }).sort((a,b)=>-model.compareVersions(a.version,b.version));
   const suggested=rows.find(r=>r.assessment.update_available);
   const development=Boolean(firmware && (!firmware.release || firmware.dirty || /-dev(?:[.+-]|$)/.test(firmware.version||'')));
   const manualAt=Math.max(s.rate_limit_until,s.last_attempt?s.last_attempt+COOLDOWN:0);
   const checkBlock=this.inflight?'checking':now<s.rate_limit_until?'rate-limited':now<manualAt?'cooldown':null;
   return {...s,check_block:checkBlock,manual_check_at:manualAt,preferences:{...this.preferences},rows,stale,metadata_error:metadataError,development,
    suggested,checking:this.inflight,can_check:checkBlock===null,
    notification:suggested?(stale?'Update available · stale check':'Update available'):development&&rows.length?'Releases available · development build installed':null};
  }
  async tick(){
   if(this.preferences.automatic && this.visible() && !this.inflight && this.clock()>=this.state.next_check)await this.check();
  }
  acquire(){
   const now=this.clock(),lease=this.read(LEASE);
   if(lease && lease.until>now && lease.until<=now+COOLDOWN && lease.owner!==this.owner)return false;
   this.write(LEASE,{owner:this.owner,until:now+COOLDOWN});
   const mine=this.read(LEASE);return !mine || mine.owner===this.owner;
  }
  release(){try{if(this.read(LEASE)?.owner===this.owner)this.storage?.removeItem(LEASE);}catch(_){}}
  async response(url,cached,limit){
   if(!this.visible())throw Error('paused');
   const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),10000);
   try{
    const headers={Accept:url===CATALOG?'application/json':'application/vnd.github+json'};
    if(cached?.etag)headers['If-None-Match']=cached.etag;
    const response=await this.fetch(url,{method:'GET',headers,credentials:'omit',referrerPolicy:'no-referrer',signal:controller.signal});
    const now=this.clock(),retry=response.headers.get('Retry-After');
    if(response.status===429 || response.status===403){
     const seconds=retry && /^\d+$/.test(retry)?Number(retry)*1000:0;
     const date=retry && !/^\d+$/.test(retry)?Date.parse(retry):NaN,reset=Number(response.headers.get('X-RateLimit-Reset'))*1000;
     this.state.rate_limit_until=Math.max(this.state.rate_limit_until,now+COOLDOWN,
      Math.min(now+STALE,now+seconds),Number.isFinite(date)?Math.min(now+STALE,date):0,
      response.headers.get('X-RateLimit-Remaining')==='0'&&Number.isFinite(reset)?Math.min(now+STALE,reset):0);
     this.state.retry_at=Math.max(this.state.retry_at,this.state.rate_limit_until);
     throw Error('rate-limited');
    }
    const poll=Number(response.headers.get('X-Poll-Interval'))*1000;
    if(Number.isFinite(poll) && poll>0)this.state.next_check=Math.max(this.state.next_check,now+Math.min(poll,6*HOUR));
    if(response.status===304){if(!cached)throw Error('invalid-cache');return cached;}
    if(response.status===404)throw Error('access-unavailable');
    if(!response.ok)throw Error('server-error');
    const chunks=[];let bytes=0;
    if(!response.body?.getReader)throw Error('browser-unsupported');
    const reader=response.body.getReader();
    try{
     while(true){const {done,value}=await reader.read();if(done)break;bytes+=value.byteLength;
      if(bytes>limit){await reader.cancel();throw Error('response-too-large');}chunks.push(value);}
    }finally{reader.releaseLock();}
    this.total+=bytes;if(this.total>MAX_TOTAL)throw Error('response-too-large');
    const data=new Uint8Array(bytes);let offset=0;for(const chunk of chunks){data.set(chunk,offset);offset+=chunk.length;}
    return {text:new TextDecoder('utf-8',{fatal:true}).decode(data),etag:(response.headers.get('ETag')||'').slice(0,200),link:response.headers.get('Link')||''};
   }finally{clearTimeout(timer);}
  }
  async check(){
   if(!this.visible() || !this.snapshot().can_check)return false;
   if(!this.acquire()){this.restore();this.onChange();return false;}
   this.inflight=true;this.total=0;this.state.last_attempt=this.clock();this.state.status='checking';this.onChange();
   try{
    let url=API;const pages={},releases=[];
    for(let n=0;url && n<3;n++){
     const previous=this.pages[url],response=await this.response(url,previous,MAX_TOTAL-this.total);
     let raw=response.raw;
     if(!raw){try{raw=JSON.parse(response.text);}catch(_){throw Error('invalid-metadata');}}
     if(!Array.isArray(raw) || raw.length>30)throw Error('invalid-metadata');
     const normalized=raw.map(normalize).filter(Boolean);releases.push(...normalized);
     const bounded=normalized.map(r=>({id:r.id,tag_name:r.tag,prerelease:r.beta,draft:false,published_at:r.published_at,body:r.notes}));
     pages[url]={raw:bounded,etag:response.etag,link:response.link};
     const next=nextPage(response.link);
     if(next && (pages[next] || Number(new URL(next).searchParams.get('page'))!==n+2))throw Error('invalid-pagination');
     url=next;
    }
    if(new Set(releases.map(r=>r.id)).size!==releases.length)throw Error('invalid-metadata');
    // Publish the new list only after all bounded pages pass validation.
    this.pages=pages;this.state.releases=releases;this.state.incomplete=Boolean(url);
    this.state.catalog=null;this.state.catalog_status='unavailable';
    if(releases.length){
     try{
      const response=await this.response(CATALOG,null,262144);
      this.state.catalog=model.parseCatalogJson(response.text);this.state.catalog_status='available';
     }catch(error){this.state.catalog_status=error.message==='rate-limited'?'rate-limited':'unavailable';}
    }
    this.state.status='checked';this.state.last_success=this.clock();this.failures=0;
    this.state.next_check=Math.max(this.state.next_check,this.clock()+HOUR+Math.floor(this.random()*300000));
   }catch(error){
    const known=['rate-limited','access-unavailable','server-error','invalid-metadata','invalid-pagination','response-too-large','invalid-cache','browser-unsupported','paused'];
    this.state.status=known.includes(error.message)?error.message:'offline';
    const delay=Math.min(6*HOUR,COOLDOWN*2**Math.min(this.failures++,9));
    if(this.state.status==='rate-limited')this.state.rate_limit_until=Math.max(this.state.rate_limit_until,this.clock()+delay);
    this.state.retry_at=Math.max(this.state.retry_at,this.clock()+delay);this.state.next_check=this.state.retry_at;
   }finally{this.inflight=false;this.save();this.release();this.onChange();}
   return true;
  }
 }
 return Object.freeze({Discovery,API,CATALOG,RELEASES,CACHE,PREF,LEASE,HOUR,STALE,COOLDOWN,normalize,nextPage});
});
