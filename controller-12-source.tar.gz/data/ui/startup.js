/* Retry only a failed script download. Never reexecute a partially started app. */
(() => {
 'use strict';
 let attempts=0;
 function failed(){
  const message=document.createElement('p');message.id='page-load-error';message.className='config-notice';message.setAttribute('role','alert');
  message.textContent='The controller page could not load. Check the connection and reload this page. No movement was started by page loading.';
  document.getElementById('mainContent').prepend(message);
 }
 function load(){
  if(++attempts>3){failed();return;}
  const script=document.createElement('script');script.src='/ui/app.js';script.async=false;let settled=false;
  script.onerror=()=>{if(settled)return;settled=true;script.remove();setTimeout(load,500);};
  script.onload=()=>{if(settled)return;settled=true;if(!window.coverAPI)failed();};
  document.head.append(script);
 }
 load();
})();
