/* Appearance is the only preference persisted by the controller UI. */
(() => {
  const key = 'telescope-cover-appearance';
  const media = matchMedia('(prefers-color-scheme: dark)');
  let mode = 'system';
  try { mode = localStorage.getItem(key) || mode; } catch (_) { /* Private browser storage can be disabled. */ }
  const apply = value => {
    mode = ['light', 'dark', 'system', 'red', 'klingon'].includes(value) ? value : 'system';
    document.documentElement.classList.toggle('night', mode === 'dark' || mode === 'red' || mode === 'klingon' || (mode === 'system' && media.matches));
    document.documentElement.dataset.appearance = mode;
    try { localStorage.setItem(key, mode); } catch (_) { /* Session appearance still works. */ }
    document.dispatchEvent(new Event('appearancechange'));
  };
  window.previewAppearance = {apply, get: () => mode};
  media.addEventListener('change', () => apply(mode));
  apply(mode);
})();

/* Best-effort Klingon labels, not machine translation at runtime.
 * English remains the accessible label and a visible gloss. See docs/licenses/
 * klingon-translations.txt for sources and intentionally approximate terms. */
(() => {
  const words = {
    'Overview': 'Dotlh', 'Calibration': 'chov', 'Configuration': 'pat cher',
    'Manual Control': "SeHwI'", 'Debug': "Qagh nej", 'Appearance': "HaSta",
    'Ready when you are.': 'SuH', 'Cover': "yuvtlhe'", 'Your cover': "yuvtlhe'lIj",
    'Telescope': "Hov bejmeH jan", 'Telescope power': "Hov bejmeH jan HoS",
    'Open cover': "yuvtlhe' yIpoSmoH", 'Close cover': "yuvtlhe' yISoQmoH",
    'Stop cover / release torque': "yImev", 'Open': 'poS', 'Closed': 'SoQ',
    'Opening': 'poSchoHtaH', 'Closing': 'SoQchoHtaH', 'Stopped': 'mevpu\u0027',
    'Unknown': "Sovbe'lu'", 'Fault': 'Qagh', 'Stationary': "vIHbe'",
    'Connected': 'rar', 'Disconnected': "rarHa'", 'Connection': 'rar',
    'Controller': "SeHwI'", 'Motion': 'vIH', 'Tracking': 'ghoch',
    'Camera': 'mIllogh qonwI\u0027', 'Camera state': "mIllogh qonwI' Dotlh",
    'Camera temperature': "mIllogh qonwI' Hat", 'Battery temperature': "'ul 'aplo' Hat",
    'Battery charge': "'ul 'aplo' HoS", 'Temperature': 'Hat', 'Status readings': 'Dotlh De\u0027',
    'Recent activity': "wanI'mey", 'Date & time': 'poH', 'Network & address': "De'wI' pat",
    'Telescope connection': 'Hov bejmeH jan rar', 'Cover behavior': "yuvtlhe' vang",
    'Light': 'wov', 'Dark': 'Hurgh', 'System': 'pat', 'Night vision': 'ram legh',
    'Klingon': 'tlhIngan', 'Show': "yI'ang", 'Hide': "yISo'", 'Cancel': 'yIqIl',
    'Save calibration': 'chov De\u0027 yIpol', 'Discard changes': "choHmey yIqIl",
    'Discard edits': "choHmey yIqIl", 'Keep editing': "yIchoHtaH", 'Clear fault': "Qagh yIteq",
    'Test OPEN': 'poSmoH yIwaH', 'Test CLOSE': 'SoQmoH yIwaH',
    'Set safe travel': 'He yIcher', 'Teach positions': "Daqmey yIghojmoH",
    'Review both positions': "Daqmey yInuD", 'Test saved positions': "Daqmey yIwaH",
    'Apply working range': 'He yIcher', 'Save address': "Quv yIpol",
    'Reset settings': "pat yIcherqa'", 'Reboot controller': "SeHwI' yIchu'qa'",
    'Stop & switch': "yImev 'ej yIchoH", 'Stay here': 'naDev yIratlh'
  };
  // ConScript Unicode Registry order; longest tokens must be matched first.
  const alphabet = ['a','b','ch','D','e','gh','H','I','j','l','m','n','ng','o','p','q','Q','r','S','t','tlh','u','v','w','y',"'"];
  const glyphs = Object.fromEntries(alphabet.map((letter, i) => [letter, String.fromCharCode(0xf8d0 + i)]));
  const piqad = text => text.replace(/tlh|ch|gh|ng|[abDeHIjlmnopqQrStuvwy']/g, letter => glyphs[letter]);
  const labels = new Map(Object.entries(words).map(([en, tlh]) => [en.toLowerCase(), piqad(tlh)]));
  const selector = 'h1,h2,h3,button,nav a,dt,.pill,.big-state';
  let observer, queued = false;
  const translate = () => {
    queued = false;
    if (window.previewAppearance.get() !== 'klingon') return;
    document.querySelectorAll(selector).forEach(element => {
      const english = element.textContent.replace(/[↗↙■]/g, '').replace(/\s+/g, ' ').trim().toLowerCase();
      const translation = labels.get(english);
      if (translation) element.dataset.piqad = translation;
      else element.removeAttribute('data-piqad'); // Dynamic state must never keep a stale translation.
    });
  };
  const sync = () => {
    observer.disconnect();
    if (window.previewAppearance.get() !== 'klingon') return;
    translate();
    observer.observe(document.body, {subtree: true, childList: true, characterData: true});
  };
  const start = () => {
    observer = new MutationObserver(() => {
      if (!queued) { queued = true; requestAnimationFrame(translate); }
    });
    document.addEventListener('appearancechange', sync);
    sync();
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, {once: true});
  else start();
})();
