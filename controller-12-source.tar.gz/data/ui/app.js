/* Live views: retained forms, explicit operations, and change-only DOM rendering. */
(() => {
 'use strict';
 const api=coverAPI, state=api.state, cal=calibrationUI, sim=calibrationState;
 const $=id=>document.getElementById(id), all=selector=>[...document.querySelectorAll(selector)];
 const text=(id,value)=>{if($(id).textContent!==String(value))$(id).textContent=value;};
 const prop=(id,key,value)=>{if($(id)[key]!==value)$(id)[key]=value;};
 const attr=(el,key,value)=>{if(el.getAttribute(key)!==String(value))el.setAttribute(key,value);};
 const style=(id,key,value)=>{if($(id).style[key]!==value)$(id).style[key]=value;};
 const disable=(id,reason)=>{prop(id,'disabled',!!reason);prop(id,'title',reason||'');};
 const badge=(id,label,kind='')=>{text(id,label);prop(id,'className','pill'+(kind?' '+kind:''));};
 const feedback=(id,message,error=false)=>{text(id,message);attr($(id),'data-error',error);};
 // Receipt age is monotonic; calendar labels use the browser's local date.
 function receiptLabel(receivedAt,receivedMono,wall=Date.now(),mono=performance.now()){
  const date=new Date(receivedAt),today=new Date(wall);
  const day=date.toDateString()===today.toDateString()?'Today':date.toLocaleDateString(undefined,{year:'numeric',month:'short',day:'numeric'});
  const seconds=Math.max(0,Math.floor((mono-receivedMono)/1000));
  const value=seconds<60?seconds:Math.floor(seconds/60),unit=seconds<60?'second':'minute';
  return `${day} · received ${value} ${unit}${value===1?'':'s'} ago`;
 }
 function receiptTime(entry,latest=false){
  const el=document.createElement('time');
  const at=latest?entry.lastReceivedAt:entry.receivedAt,mono=latest?entry.lastReceivedMono:entry.receivedMono;
  el.title=`Original event time: ${latest?entry.lastTime:entry.time}`;
  if(Number.isFinite(at)&&Number.isFinite(mono)){
   el.dataset.receivedAt=at;el.dataset.receivedMono=mono;el.dateTime=new Date(at).toISOString();
   el.title+=` · Browser receipt: ${new Date(at).toISOString()}`;
   el.dataset.originalTime=latest?entry.lastTime:entry.time;
   el.textContent=$('debug-live-time').checked?receiptLabel(at,mono):el.dataset.originalTime;
  }else el.textContent=latest?entry.lastTime:entry.time;
  return el;
 }
 function formatUptime(ms){
  const seconds=Math.floor(Math.max(0,ms)/1000),days=Math.floor(seconds/86400);
  const clock=[Math.floor(seconds/3600)%24,Math.floor(seconds/60)%60,seconds%60].map(v=>String(v).padStart(2,'0')).join(':');
  return (days?days+'d ':'')+clock;
 }
 function renderLogUptime(){
  const uptime=state.cover?.uptime_ms;
  const fresh=api.freshCover();
  text('debug-uptime',Number.isFinite(uptime)?'Uptime: '+formatUptime(uptime+(fresh?Math.max(0,api.now()-state.coverAt):0))+(fresh?'':' (stale)'):'Uptime: —');
 }
 function refreshReceiptTimes(){
  if(document.hidden)return;
  if(state.view==='debug')renderLogUptime();
  const wall=Date.now(),mono=performance.now();
  for(const el of document.querySelectorAll('[data-received-at]')){
   if(el.closest('[hidden]'))continue;
   const label=$('debug-live-time').checked?receiptLabel(Number(el.dataset.receivedAt),Number(el.dataset.receivedMono),wall,mono):el.dataset.originalTime;
   if(el.textContent!==label)el.textContent=label;
  }
 }
 setInterval(refreshReceiptTimes,1000);
 document.addEventListener('visibilitychange',refreshReceiptTimes);
 const routes=['overview','calibration','configuration','manual','debug'],scrolls={};
 let pendingRoute=null,resetKind=null,configLoaded=false,configBusy=false,lastActivity='',lastNetworks='',settingsOperation=null;
 const freshNetwork=()=>state.network&&api.now()-state.networkAt<6000;
 const config=()=>state.network||{};
 const debugEnabled=()=>state.debugSession || !!config().enable_debug_tab;
 const servoNoticeKey='cover.servoSetupNotice.v1';
 let servoNoticeSeen=false,servoNoticeOpen=false;
 try{servoNoticeSeen=sessionStorage.getItem(servoNoticeKey)==='seen';}catch(_){}
 function renderServoNotice(){
  if(api.freshPosition() && typeof state.cover.torque==='boolean'){
   if(servoNoticeSeen){try{sessionStorage.removeItem(servoNoticeKey);}catch(_){}}
   servoNoticeSeen=false;servoNoticeOpen=false;
  }else if(api.servoSetupOnly() && !servoNoticeSeen){
   servoNoticeSeen=true;servoNoticeOpen=true;
   try{sessionStorage.setItem(servoNoticeKey,'seen');}catch(_){}
  }
  if(state.cover?.state==='FAULT')servoNoticeOpen=false;
  prop('servoSetupNotice','hidden',!servoNoticeOpen || !api.freshCover());
 }
 $('dismissServoNotice').onclick=()=>{servoNoticeOpen=false;renderServoNotice();};
 const name=()=>config().mdns_name||'cover';
 const ssid=()=>$('cfg-ssid').value==='__hidden'?$('cfg-hidden-ssid').value.trim():$('cfg-ssid').value;
 const wifiDirty=()=>configLoaded&&(ssid()!==(config().saved_ssid||'')||$('cfg-password').value.length>0||$('cfg-replace-password').checked);
 const scopeDraft=()=>({enabled:$('cfg-enabled').checked,read_only:config().alpaca_read_only!==false,host:$('cfg-ip').value.trim(),port:Number($('cfg-port').value),device:Number($('cfg-device-number').value)});
 const scopeDirty=()=>configLoaded&&Object.entries(scopeDraft()).some(([key,value])=>value!==config()['alpaca_'+key]);
 const nameDirty=()=>configLoaded&&$('cfg-hostname').value!==name();
 const timeDraft=()=>({enabled:$('cfg-ntp-enabled').checked,server:$('cfg-ntp-server').value.trim(),time_zone:$('cfg-time-zone').value.trim()});
 const timeDirty=()=>{const d=timeDraft(),n=config();return d.enabled!==!!n.ntp_enabled||d.server!==(n.ntp_server||'pool.ntp.org')||d.time_zone!==(n.time_zone||'MST7');};
 const sectionNames={time:'Date & time',wifi:'Home Wi-Fi',name:'Controller address',alpaca:'Telescope connection',advanced:'Cover behavior',diagnostics:'Diagnostics'};
 const sectionDirty=kind=>configLoaded&&({time:timeDirty,wifi:wifiDirty,name:nameDirty,alpaca:scopeDirty,advanced:()=>$('cfg-disable-torque').checked!==!!config().disable_torque_after_move,diagnostics:()=>$('cfg-enable-debug').checked!==!!config().enable_debug_tab})[kind]();
 const dirtySections=()=>Object.keys(sectionNames).filter(sectionDirty);
 const configDirty=()=>dirtySections().length>0;
 let pendingSettings=null;

 const moving=()=>!!(state.cover?.moving||state.cover?.holding||state.active);
 const armLocked=()=>!!(state.scope?.arm_locked||state.scope?.stow_locked||state.cover?.emergency?.locked);
 const position=()=>api.freshPosition()?state.cover.position:null;
 const displayedTravel=(c,value)=>coverTravel.estimate(coverTravel.calibration(c),value,!c.moving&&!c.holding?c.state:null);
 function coverState(){const c=state.cover;if(!api.freshCover())return 'Disconnected';if(c.state==='FAULT')return 'Fault';if(position()===null)return 'Unknown';if(!c.calibrated)return 'Not calibrated';const travel=displayedTravel(c,c.position);if(!travel.valid)return travel.reason;return ({OPEN:'Open',CLOSED:'Closed',OPENING:'Opening',CLOSING:'Closing',MANUAL:'Moving',HOLDING:'Holding',RETAINED:'Holding torque',STOPPED:'Stopped',UNKNOWN:'Unknown position'})[c.state]||c.state;}
 function commonReason(){
  if(state.session?.read_only_test)return 'Read-only test firmware: servo and telescope controls are disabled.';
  if(!state.session?.beta_accepted)return 'Accept the beta acknowledgment first.';
  if(state.session.setup_only)return 'Use the home Wi-Fi connection for cover controls.';
  if(state.cover?.maintenance?.locked)return 'Controller maintenance is active.';
  if(!api.freshCover())return 'Reconnect to the controller.';
  if(state.busy||configBusy)return 'Waiting for the controller to confirm the request.';
  if(state.network?.busy)return 'Wait for settings or network setup to finish.';
  if(armLocked())return 'Finish the telescope operation before moving the cover.';
  const c=state.cover;
  if(c.moving||state.active)return 'Cover moving. Use Stop to end the movement.';
  if(c.holding)return 'Support the cover and release torque before another action.';
  if(!c.ready)return api.servoSetupOnly()?'Connect and power the servo before using motion controls.':c.fault||'Complete startup checks in Calibration.';
  if(!api.freshPosition())return 'Wait for fresh servo feedback.';
  if(c.torque!==false && !(c.torque===true && ['OPEN','CLOSED'].includes(c.state)))return 'Confirm torque OFF before starting another operation.';
  if(!c.calibrated)return 'Teach and save both positions in Calibration.';
  if(c.dirty||cal.dirty())return 'Save or discard your calibration edits before moving the cover.';
  if(!coverTravel.supported(coverTravel.calibration(c)))return 'Review the saved travel arc in Calibration; rollover is not supported.';
  return coverTravel.timeoutReason(coverTravel.calibration(c),{openSpeed:c.saved_profile?.open_speed,closeSpeed:c.saved_profile?.close_speed,acceleration:c.saved_profile?.acceleration,timeoutMs:c.saved_profile?.timeout_ms});
 }
 let overrideUntil=0,overrideGeneration=0;
 function clearStowOverride(){overrideUntil=0;$('ov-override').checked=false;}
 function stowOverride(){
  if($('ov-override').checked&&(api.now()>=overrideUntil||state.cover?.control_generation!==overrideGeneration))clearStowOverride();
  return $('ov-override').checked;
 }
 function unsafeScope(){const a=state.scope;return api.freshScope()&&(a.at_home===false||a.slewing===true||a.tracking===true);}
 function coverReason(endpoint,strict=false){
  const common=commonReason();if(common)return common;
  if(!coverTravel.directPath(state.cover.position,endpoint==='open'?state.cover.open:state.cover.closed)&&!(state.cover.circular&&state.cover.rollover_supported))return 'This direct path is not commissioned. Inspect alignment and the travel arc in Calibration.';
  if(state.cover.state===(endpoint==='open'?'OPEN':'CLOSED'))return 'The cover is already '+endpoint+'.';
  if(!$('ov-supervised').checked)return 'Confirm that you are present and the mechanism is clear.';
  if(endpoint==='closed'){
   if(stowOverride())return unsafeScope()?'Override blocked: telescope reports an unstowed or moving state.':'';
   if(!state.scope||api.now()-state.scopeAt>4000)return 'Telescope integration status is unavailable.';
   if(state.scope.enabled && !api.freshStow())return 'Stow the telescope in the Seestar app and wait for confirmed clearance before closing.';
   if(!state.scope.enabled&&!$('ov-manual').checked)return 'Visually confirm telescope stow and the closing path.';
  }
  return '';
 }
 function settingsReason(){
  if(!state.session?.beta_accepted)return 'Accept the beta acknowledgment first.';
  if(!freshNetwork()||!api.freshCover())return 'Restore the controller connection.';
  if(configBusy||state.network.busy||state.busy||state.cover?.maintenance?.locked)return 'Wait for the current operation to finish.';
  if(moving()||armLocked())return 'Finish the current movement before saving settings.';
  return '';
 }
 function syncTheme(){prop('appearance','value',previewAppearance.get());all('[data-theme]').forEach(button=>attr(button,'aria-pressed',button.dataset.theme===previewAppearance.get()));}
 $('appearance').onchange=()=>previewAppearance.apply($('appearance').value);
 all('[data-theme]').forEach(button=>button.onclick=()=>previewAppearance.apply(button.dataset.theme));
 document.addEventListener('appearancechange',syncTheme);syncTheme();
 function activate(view,historyMode='push',focus=true){
  if(view!=='overview')clearStowOverride();
  if(view==='debug' && state.network && !debugEnabled())view='overview';
  if(state.view==='manual' && view!=='manual')manualUI.disable();
  scrolls[state.view]=window.scrollY;state.view=view;
  all('[data-view]').forEach(section=>prop(section.id,'hidden',section.dataset.view!==view));
  for(const route of routes){const link=$('nav-'+route);if(route===view)attr(link,'aria-current','page');else if(link.hasAttribute('aria-current'))link.removeAttribute('aria-current');}
  if(historyMode!=='none')history[historyMode+'State']({view},'', '#'+view);
  document.title=view[0].toUpperCase()+view.slice(1)+' · Telescope Cover';
  cal.render();render();if(focus)$(view+'Heading').focus({preventScroll:true});window.scrollTo({top:scrolls[view]||0,behavior:'instant'});
 }
 function route(view,fromHistory=false){
  if(!routes.includes(view))view='overview';if(view===state.view)return;
  if(moving()){pendingRoute=view;if(fromHistory)history.replaceState({view:state.view},'','#'+state.view);if(!$('navigationDialog').open)$('navigationDialog').showModal();return;}
  activate(view,fromHistory?'none':'push');
 }
 all('a[href^="#"]').forEach(link=>link.addEventListener('click',event=>{
  if(event.metaKey||event.ctrlKey||event.shiftKey||event.altKey)return;
  const view=link.getAttribute('href').slice(1);if(!routes.includes(view))return;event.preventDefault();route(view);
  if(link.dataset.scroll){const section=$(link.dataset.scroll);section.tabIndex=-1;section.focus({preventScroll:true});section.scrollIntoView({block:'start',behavior:'instant'});}
 }));
 window.addEventListener('popstate',()=>route(location.hash.slice(1),true));window.addEventListener('hashchange',()=>route(location.hash.slice(1),true));
 $('navigationCancel').onclick=()=>{pendingRoute=null;$('navigationDialog').close();};
 $('navigationDialog').addEventListener('cancel',()=>pendingRoute=null);
 $('navigationConfirm').onclick=async()=>{await api.stop();$('navigationDialog').close();const view=pendingRoute;pendingRoute=null;if(view)activate(view);};
 $('stop').onclick=()=>api.stop();
 $('download-heartbeat-trace').onclick=()=>api.exportTrace();
 async function moveCover(endpoint){
  render();const reason=coverReason(endpoint);if(reason){api.note(reason,true);return;}
  if(endpoint==='closed'&&state.scope?.enabled){
   const generation=state.generation;state.busy=true;render();
   try{await api.scope();}catch(_){if(!stowOverride()){api.note('Close not sent: telescope status could not be refreshed.',true);return;}}
   finally{state.busy=false;render();}
   if(generation!==state.generation||state.view!=='overview'||document.hidden||!document.hasFocus()){api.note('Close cancelled before it was sent.');return;}
  }
  const strict=coverReason(endpoint,true);if(strict){api.note(strict,true);return;}
  const override=endpoint==='closed'&&stowOverride();
  clearStowOverride();
  try{await api.command('dashboard/'+(endpoint==='closed'?'close':'open'),{clear:'yes',stowed:override||$('ov-manual').checked?'yes':'no',override:override?'yes':'no'},{motion:true});}catch(_){}
 }
 $('ov-open').onclick=()=>moveCover('open');$('ov-close').onclick=()=>moveCover('closed');
 for(const id of ['ov-supervised','ov-manual'])$(id).onchange=()=>{if(id==='ov-supervised'&&!$(id).checked){clearStowOverride();if(state.active)api.stop();}render();};
 $('ov-override').onchange=()=>{overrideUntil=$('ov-override').checked?api.now()+60000:0;overrideGeneration=state.cover?.control_generation;render();};
 window.addEventListener('blur',clearStowOverride);
 document.addEventListener('visibilitychange',()=>{if(document.hidden)clearStowOverride();});
 function metricText(key,format){
  const value=api.metric(key),a=state.scope;
  if(value!==null)return format(value);
  const last=a?.[key+'_last_value'],age=a?.[key+'_last_age_ms'];
  if(last===null||last===undefined||!Number.isFinite(age))return 'Unavailable';
  return format(last)+' · stale, '+Math.floor((age+api.now()-state.scopeAt)/1000)+'s ago';
 }
 function waitingForScopeStatus(){
  const a=state.scope;
  return !a || (a.enabled && !a.sequence && (a.error==='none' ||
   (a.error==='disconnected' && config().connected===false)));
 }
 function renderOverview(){
  const c=state.cover||{},s=sim.s,a=state.scope,display=api.displayedScope(),live=api.freshCover(),fresh=api.freshPosition(),kind=coverState(),reading=displayedTravel(c,fresh?c.position:null);
  badge('ov-connection',live?'Controller connected':'Controller unavailable',live?'':'bad');
  const health=!live?'Reconnect to the controller.':api.servoSetupOnly()?'Configuration and Debug are available. Connect a powered servo before calibrating.':!c.ready?c.fault||'Complete Calibration checks.':!c.calibrated?'Teach and save the cover positions.':c.dirty||cal.dirty()?'Finish or discard the calibration draft.':'';
  text('ov-health',api.servoSetupOnly()?'Controller setup':health?'Setup needs attention':moving()||armLocked()?'Operation in progress':'Ready for supervised operation');
  text('ov-health-detail',health||(armLocked()?'Telescope operation active · cover locked':'Saved positions loaded · verify physical clearance'));
  $('ov-health-dot').classList.toggle('bad',!!health);
  text('ov-cover-state',kind);badge('ov-cover-tag',!fresh?'Unconfirmed':c.moving?'Moving':c.holding?'Holding':c.state==='FAULT'?'Needs attention':'Stationary',c.state==='FAULT'?'bad':c.moving||c.holding?'warn':'neutral');
  text('ov-cover-description',c.calibrated&&fresh&&reading.nearEndpoint?reading.detail+'. Stopped, with endpoint status unconfirmed. Visually check the cover before moving.':c.calibrated&&fresh&&!reading.valid?reading.reason+'. Inspect calibration and the mechanism before movement.':kind==='Closed'?'At the saved closed position. Check physical seating.':kind==='Open'?'At the saved open position. Check physical clearance.':c.moving?'Watching servo feedback as the cover moves.':health||'Between saved endpoints. Choose a supervised move.');
  text('ov-travel',fresh&&c.calibrated?coverTravel.label(reading):'Travel unavailable');
  style('ov-lid','transform',reading.valid?`rotate(${Math.round(reading.percent*9)/10}deg)`:'rotate(0deg)');style('ov-lid','opacity',reading.valid?'1':'.15');
  disable('ov-open',coverReason('open'));disable('ov-close',coverReason('closed'));
  text('ov-cover-reason',coverReason(kind==='Closed'?'open':'closed')||(kind==='Closed'?'Ready to open. Stay with the cover.':'Telescope stowed. Ready for supervised close.'));
  prop('ov-manual-row','hidden',!a||a.enabled!==false);
  if(c.state==='CLOSED'||c.moving||c.holding)clearStowOverride();
  prop('ov-override-row','hidden',c.state==='CLOSED'||a?.enabled===false||(api.freshStow()&&!stowOverride()));
  feedback('ov-action-feedback',state.message,state.error);
  text('ov-position-summary',fresh&&c.calibrated?coverTravel.label(reading):'Feedback unavailable');
  text('ov-position',fresh?c.position+' counts':'Unknown');text('ov-endpoints',c.calibrated?`${c.closed} closed / ${c.open} open`:'Not calibrated');
  text('ov-torque',!live||c.torque===null?'Unconfirmed':c.torque?'On · supervised':'Released');
  text('ov-supply',live&&c.servo_voltage!==null?`${c.servo_voltage} V / ${c.servo_temperature} °C`:'Unavailable');
  badge('ov-scope-tag',waitingForScopeStatus()?'Waiting for status':!a.enabled?'Not configured':display?'Connected':'Disconnected or stale',display?'':'neutral');
  text('ov-scope-state',waitingForScopeStatus()?'Waiting for status':!a?.enabled?'Manual stow required':!display?'Status unavailable':display.slewing?'Telescope moving':display.at_home?'Telescope stowed reported':'Telescope arm raised');
  const altitude=api.metric('altitude');
  style('ov-scope-arm','transform',`rotate(${altitude!==null?-altitude-90:display?.at_home&&!display.slewing?0:-90}deg)`);style('ov-scope-arm','opacity',display?'1':'.3');
  text('ov-altitude',altitude!==null?'Reported altitude '+altitude.toFixed(1)+'°':display?.at_home&&!display.slewing?'Telescope stowed reported':'Reported altitude unavailable');
  text('ov-motion',!display?'Unknown':display.slewing?'Moving':'Stationary');text('ov-tracking',!display?'Unknown':display.tracking?'On':'Off');
  const camera=api.metric('camera_state');text('ov-camera',camera===null?'Unknown':['Idle','Waiting','Exposing','Reading','Downloading','Error'][camera]||'Unknown');
  const power=!!a?.power_valid&&Number.isFinite(a.power_age_ms)&&a.power_age_ms>=0&&a.power_age_ms+api.now()-state.scopeAt<=60000;
  const battery=power&&Number.isFinite(a.battery_percent)&&a.battery_percent>=0&&a.battery_percent<=100?a.battery_percent:null;
  const batteryState=battery===null?'unavailable':battery<=10?'low':'normal';
  const powerStatus=a?.power_telemetry_supported===false?'Use the Seestar app for battery readings':a?.power_paused?'Paused during arm movement':a?.power_retrying?'Retrying automatically':power?'Available':'Waiting for readings';
  text('ov-power-status',a?.power_retrying?(power?'Showing the last reading. Retrying power updates automatically.':'Power readings unavailable. Retrying automatically.'):
   a?.power_paused?'Power updates resume when arm movement ends.':power?'Power readings update automatically.':powerStatus+'.');
  text('ov-battery',battery===null?'—':battery+'%');badge('ov-charging',power&&a.charging_state?a.charging_state:'Unavailable','neutral');
  for(const id of ['ov-battery-fill','ov-scope-battery-fill']){style(id,'width',battery===null?'0%':battery+'%');attr($(id),'data-state',batteryState);}
  attr($('ov-scope-battery'),'data-state',batteryState);
  text('ov-scope-battery-value',battery===null?'Unavailable':battery+'%'+(battery<=10?' · Low battery':''));
  const batteryTrack=$('ov-scope-battery-track');
  if(battery===null){if(batteryTrack.hasAttribute('aria-valuenow'))batteryTrack.removeAttribute('aria-valuenow');}
  else attr(batteryTrack,'aria-valuenow',battery);
  attr(batteryTrack,'aria-valuetext',battery===null?'Battery level unavailable':battery+' percent'+(battery<=10?', low battery':''));
  text('ov-external',power&&typeof a.external_power==='boolean'?a.external_power?'Yes':'No':'Unknown');
  text('ov-battery-temp',power&&a.battery_temperature!==null?a.battery_temperature+' °C':'Unknown');
  text('ov-battery-hot',power&&typeof a.battery_overtemp==='boolean'?a.battery_overtemp?'Yes':'No':'Unknown');
  text('ov-network-name',config().ssid||config().ap||'Unavailable');text('ov-network-quality',live?`${c.wifi} · ${c.wifi_rssi} dBm`:'Controller connection unavailable');
  text('ov-host',name()+'.local');text('ov-controller-link',live?'Connected':'Disconnected');
  text('ov-azimuth',metricText('azimuth',v=>v.toFixed(1)+'°'));
  text('ov-camera-temp',metricText('camera_temperature',v=>v.toFixed(1)+' °C'));
  text('ov-heater',metricText('heater_on',v=>v?'On':'Off'));
  text('ov-scope-summary',battery===null?'Battery unavailable':battery+'% battery'+(battery<=10?' · Low':''));
  text('ov-tel-altitude',metricText('altitude',v=>v.toFixed(1)+'°'));
  if(altitude===null)text('ov-altitude',metricText('altitude',v=>'Reported altitude '+v.toFixed(1)+'°'));
  text('ov-tel-stowed',typeof display?.at_home==='boolean'?(display.at_home?'Yes':'No'):'Unknown');
  for(const [detail,source] of [['azimuth','azimuth'],['motion','motion'],['tracking','tracking'],['camera','camera'],['camera-temp','camera-temp'],['heater','heater'],['charging','charging'],['external','external'],['battery-temp','battery-temp'],['battery-hot','battery-hot']])text('ov-tel-'+detail,$('ov-'+source).textContent);
  text('ov-tel-battery',battery===null?'Unavailable':battery+'%'+(battery<=10?' · Low battery':''));
  text('ov-tel-power-status',powerStatus);
  const n=config(),scopeCurrent=!!a&&api.now()-state.scopeAt<6000,yesNo=value=>typeof value==='boolean'?(value?'Yes':'No'):'Unknown';
  text('ov-tel-address',n.alpaca_host?`${n.alpaca_host}:${n.alpaca_port}`:'Unavailable');
  text('ov-tel-device',Number.isInteger(n.alpaca_device)?n.alpaca_device:'Unavailable');
  text('ov-tel-mode',n.alpaca_enabled===false?'Disabled':typeof n.alpaca_read_only==='boolean'?(n.alpaca_read_only?'Use existing connection':'Connect automatically'):'Unavailable');
  text('ov-tel-status',a?.enabled===false?'Monitoring disabled':waitingForScopeStatus()?'Waiting for status':api.freshScope()?'Available':display?.connected?'Stale · reconnecting':scopeCurrent&&a.connected===false?'Disconnected':'Unavailable');
  const errors=[];
  for(const [key,label] of [['error','Status'],['altitude_error','Altitude'],['azimuth_error','Azimuth'],['camera_state_error','Camera'],['camera_temperature_error','Camera temperature'],['heater_on_error','Dew heater'],['stow_error','Stow']])if(a?.[key]&&a[key]!=='none')errors.push(label+': '+a[key]);
  if(a?.error&&a.error!=='none'&&a.failed_request)errors.push(a.failed_request+' · '+a.request_ms+' ms');
  if(a?.driver_error)errors.push('Driver: '+a.driver_error);
  text('ov-tel-error',!scopeCurrent?'Unavailable':errors.join(' · ')||(a.error==='none'?'None reported':'Unavailable'));
  const activity=JSON.stringify(state.events);if(activity!==lastActivity){lastActivity=activity;$('ov-activity').replaceChildren(...state.events.map(event=>{const li=document.createElement('li'),time=receiptTime(event);li.append(document.createTextNode(event.message));li.append(time);return li;}));}
  prop('connectionAlert','hidden',live&&!state.session?.setup_only);
  text('connectionAlertTitle',state.session?.setup_only?'Setup hotspot · configuration only':'Controller unavailable');
  text('connectionAlertText',state.session?.setup_only?'Configure home Wi-Fi, then reconnect through the home network for movement controls.':'Readings may be stale. Reconnect to the controller’s network. Movement will never restart automatically.');
 }
 function updateNetworks(force=false){
  const n=config(),selection=$('cfg-ssid').value,rows=n.networks||[],key=JSON.stringify([rows,n.saved_ssid]);
  if(!force&&key===lastNetworks)return;lastNetworks=key;
  const options=[new Option('Choose a network…','')];
  const names=new Set();for(const row of rows){if(!row.ssid||names.has(row.ssid))continue;names.add(row.ssid);options.push(new Option(`${row.ssid} · ${row.rssi>=-60?'Strong signal':row.rssi>=-75?'Fair signal':'Weak signal'} · ${row.secure?'secured':'open'}`,row.ssid));}
  for(const value of [n.saved_ssid,selection])if(value&&value!=='__hidden'&&!names.has(value)){names.add(value);options.push(new Option(value+(value===n.saved_ssid?' · saved':''),value));}
  options.push(new Option('Enter network name manually…','__hidden'));$('cfg-ssid').replaceChildren(...options);$('cfg-ssid').value=selection;
 }
 function loadConfig(section='all'){
  const n=config();if(section==='all'||section==='wifi'){updateNetworks(true);$('cfg-ssid').value=n.saved_ssid||'';$('cfg-hidden-ssid').value='';$('cfg-password').value='';$('cfg-replace-password').checked=false;passwordVisibility(false);}
  if(section==='all'||section==='alpaca'){$('cfg-enabled').checked=!!n.alpaca_enabled;$('cfg-ip').value=n.alpaca_host||'';$('cfg-port').value=n.alpaca_port||32323;$('cfg-device-number').value=n.alpaca_device??0;}
  if(section==='all'||section==='time'){$('cfg-ntp-enabled').checked=!!n.ntp_enabled;$('cfg-ntp-server').value=n.ntp_server||'pool.ntp.org';const zone=$('cfg-time-zone'),savedZone=n.time_zone||'MST7';
   zone.querySelector('[data-custom-zone]')?.remove();
   if(!Array.from(zone.options).some(option=>option.value===savedZone)){
    const option=new Option('Current custom time zone (saved)',savedZone);option.dataset.customZone='true';zone.add(option);
   }
   zone.value=savedZone;}
  if(section==='all'||section==='name')$('cfg-hostname').value=name();
  if(section==='all'||section==='advanced'){$('cfg-disable-torque').checked=!!n.disable_torque_after_move;$('cfg-keep-torque').checked=!n.disable_torque_after_move;}
  if(section==='all'||section==='diagnostics')$('cfg-enable-debug').checked=!!n.enable_debug_tab;
  configLoaded=true;
 }
 function passwordVisibility(show){prop('cfg-password','type',show?'text':'password');text('cfg-show-password',show?'Hide':'Show');attr($('cfg-show-password'),'aria-pressed',show);attr($('cfg-show-password'),'aria-label',show?'Hide newly entered password':'Show newly entered password');}
 $('cfg-show-password').onclick=()=>passwordVisibility($('cfg-password').type==='password');
 function renderConfig(){
  const n=config(),reason=settingsReason();
  // Draft edits stay local; only submitting them requires controller clearance.
  const editReason=!configLoaded?'Loading settings…':configBusy||n.busy?'Wait for settings to finish saving.':'';
  for(const id of ['cfg-time-fields','cfg-diagnostics-fields','cfg-advanced-fields','cfg-wifi-fields','cfg-alpaca-fields','cfg-name-fields'])disable(id,editReason);
  for(const id of ['cfg-reset-network','cfg-reset-calibration'])disable(id,reason);
  text('cfg-lock-reason',reason?(reason.startsWith('The cover must be closed')?reason:'Saving is unavailable. '+reason)+(!editReason?' You can still edit settings; your changes will remain on this page until saved.':''):'');prop('cfg-lock-reason','hidden',!reason);
  const dirty=dirtySections();badge('cfg-summary',!configLoaded?'Loading settings…':configBusy||n.busy?'Operation in progress':dirty.length?`${dirty.length} section${dirty.length===1?' has':'s have'} unsaved changes`:'All changes saved','neutral');
  for(const kind of Object.keys(sectionNames)){prop('cfg-'+kind+'-dirty','hidden',!sectionDirty(kind));const button=document.querySelector('[data-discard="'+kind+'"]');button.disabled=configBusy||!sectionDirty(kind);}
  prop('cfg-recovery-active','hidden',!api.freshCover() || state.cover.settings_offline_allowed!==true);
  disable('cfg-scope-connection',!$('cfg-enabled').checked?'Monitoring is off. Saved connection details will be retained.':'');
  text('cfg-mode',n.alpaca_read_only===false?'Automatically reconnects monitoring after a telescope restart. Telescope movement stays in the Seestar app.':'Uses an existing Alpaca session. Connecting the Seestar app may not establish that session.');
  const a=state.scope; text('cfg-scope-status','Connection: '+(!n.alpaca_enabled?'Monitoring off':waitingForScopeStatus()?'Waiting for status':api.now()-state.scopeAt>=6000?'Status outdated':api.freshScope()&&a.connected===true?'Connected':'Unavailable'));
  const local='http://'+name()+'.local/';text('cfg-local-address',local);attr($('cfg-local-address'),'href',local);
  text('cfg-address-preview','Address after saving: http://'+$('cfg-hostname').value+'.local/');
  text('cfg-reconnect-help','Connect to '+(n.ap||'TelescopeCover-XXXXXX')+' and open http://192.168.4.1. Use the controller IP address if its local name is unavailable.');
  badge('cfg-wifi-tag',!freshNetwork()?'Connection status unavailable':n.connected?'Connected to home Wi-Fi':n.ap?'Using setup hotspot':'Home Wi-Fi disconnected',n.connected?'':'neutral');
  text('cfg-current-ssid',!freshNetwork()?'Last reported connection':n.connected?n.ssid:n.ap||'Home network disconnected');text('cfg-current-ip',n.connected?n.ip:n.ap?'192.168.4.1 · setup hotspot':'Unavailable');
  prop('cfg-hidden-row','hidden',$('cfg-ssid').value!=='__hidden');
  const saved=n.password_saved&&ssid()===n.saved_ssid;
  prop('cfg-replace-row','hidden',!saved);prop('cfg-password','placeholder',saved&&!$('cfg-replace-password').checked?'********':'Network password');
  text('cfg-password-help',saved&&!$('cfg-replace-password').checked&&!$('cfg-password').value?'Saved password will be kept.':'Enter a replacement password. Leave blank only for an open network.');
  disable('cfg-connect',reason||(!wifiDirty()?'Saved Wi-Fi selection is unchanged.':''));disable('cfg-scan',reason);
  disable('cfg-name-save',reason||(!nameDirty()?'The local name is unchanged.':''));disable('cfg-alpaca-save',reason||(!scopeDirty()?'Telescope settings are unchanged.':''));
  disable('cfg-advanced-save',reason||(!sectionDirty('advanced')?'Cover behavior is unchanged.':''));
  text('cfg-time-status',!freshNetwork()?'Time status unavailable':!n.ntp_enabled?'Time synchronization off':n.time_synchronized?'Clock synchronized · '+(n.local_time||'Local time unavailable')+' · continues keeping time between updates':'Waiting for time synchronization · controller operation continues');
  disable('cfg-time-save',reason||(!sectionDirty('time')?'Time settings are unchanged.':''));
  disable('cfg-diagnostics-save',reason||(!sectionDirty('diagnostics')?'Diagnostics are unchanged.':''));
  badge('cfg-scope-tag',n.alpaca_enabled?'Monitoring: On':'Monitoring: Off',n.alpaca_enabled?'':'neutral');
 }
 function renderDock(){
  const c=state.cover||{},fresh=api.freshCover();
  disable('stop',state.session?.read_only_test?'Read-only test firmware: servo commands disabled.':fresh && c.state==='FAULT'?'Cover faulted. Inspect the mechanism, then use Clear fault.':'');
  document.querySelector('.stop-dock').classList.toggle('fault-active',c.state==='FAULT');
  text('dockState',api.servoSetupOnly()?'Controller setup · no servo feedback':!fresh||c.torque===null?'Cover torque unconfirmed':`${c.calibrated?coverTravel.label(displayedTravel(c,api.freshPosition()?c.position:null)):'Travel not calibrated'} · cover ${c.moving?'moving':c.holding?'holding':c.torque?'torque ON':'torque released'}`);
  text('dockHint',api.servoSetupOnly()?'Configuration and Debug are available.':!fresh||c.torque===null?'Support the cover and check the connection.':c.torque?'Stay with the cover. Stop releases motor support.':'Support the cover whenever torque is off.');
  $('dockDot').classList.toggle('bad',!fresh||c.torque===null||c.state==='FAULT');
  const firmware=state.session?.firmware;
  text('sessionNote',state.session?`Firmware ${firmware?.version||'version unavailable'} · ${state.session.setup_only?'setup hotspot':'home network'}`:'Connecting to controller…');
  text('cfg-firmware-version',firmware?.version||'Unavailable');
  text('cfg-firmware-commit',firmware?.commit||'Unavailable');
  text('cfg-firmware-profile',firmware?.profile||'Unavailable');
  text('cfg-firmware-built',firmware?.built_at||'Unavailable');
  text('cfg-firmware-id',state.cover?.firmware_id||state.session?.firmware_id||'Unavailable');
  const notes=$('cfg-firmware-notes');
  notes.href=firmware?.release && /^\d+\.\d+\.\d+(?:-(?:alpha|beta|rc)\.[1-9]\d*)?$/.test(firmware.version)?
   `https://github.com/Kbdavis/Telescope-Cover/releases/tag/v${firmware.version}`:'https://github.com/Kbdavis/Telescope-Cover/releases';
 }
 function renderCpuLoad(){
  const cpu=api.metrics.hasSnapshot()?state.cover?.resources?.cpu_load:null;
  const age=cpu?.age_ms+api.now()-state.coverAt;
  const valid=api.freshCover() && cpu?.available===true && cpu.method==='timer_sampled' &&
   Number.isFinite(age) && age>=0 && age<=5000 && Number.isFinite(cpu.window_ms) && cpu.window_ms>=1000 && cpu.window_ms<=5000 &&
   ['core0_percent','core1_percent','average_percent'].every(key=>Number.isFinite(cpu[key]) && cpu[key]>=0 && cpu[key]<=100);
  for(const [id,key] of [['debug-cpu-core0','core0_percent'],['debug-cpu-core1','core1_percent'],['debug-cpu-average','average_percent']])
   text(id,valid?cpu[key].toFixed(1)+'%':'Unavailable');
  text('debug-cpu-status',valid?'Sample window '+(cpu.window_ms/1000).toFixed(1)+' s. Both cores fully busy = 100% average.':'Waiting for a fresh CPU load sample.');
 }
 function renderWifiMetrics(w){
  const number=value=>Number.isFinite(value)&&value>=0;
  const count=key=>w&&number(w[key])?String(w[key]):'Unavailable';
  const signal=value=>Number.isFinite(value)&&value<0&&value>=-127?value+' dBm':'Unavailable';
  const seconds=value=>number(value)?(value/1000).toFixed(1)+' s':'Unavailable';
  text('debug-wifi-link',w&&typeof w.connected==='boolean'?(w.connected?'Connected':'Disconnected'):'Unavailable');
  text('debug-wifi-rssi',w?.connected?signal(w.rssi):'Unavailable');
  text('debug-wifi-minimum',signal(w?.minimum_rssi));
  for(const [id,key] of [['disconnects','disconnects'],['reconnects','reconnects'],['requests','alpaca_requests'],['failures','alpaca_failures'],['timeouts','alpaca_timeouts']])text('debug-wifi-'+id,count(key));
  text('debug-wifi-reason',!w?'Unavailable':w.last_reason===null?'None recorded':number(w.last_reason)?`${w.last_reason_name||'Unknown reason'} (${w.last_reason})`:'Unavailable');
  text('debug-wifi-when',w?.last_disconnect_uptime_ms===null?'None recorded':seconds(w?.last_disconnect_uptime_ms));
  text('debug-wifi-outage',w?seconds(w.current_outage_ms)+' / '+seconds(w.last_outage_ms):'Unavailable');
  text('debug-wifi-latency',w&&w.alpaca_requests>0?count('last_request_ms')+' / '+count('max_request_ms')+' ms':w?'No requests yet':'Unavailable');
  text('debug-wifi-packets','Unavailable — not exposed by this controller');
 }
 function renderMetrics(){
  const r=api.metrics.hasSnapshot()?state.cover?.resources:null;
  const age=r?.age_ms+api.now()-state.coverAt;
  const fresh=r && api.freshCover() && Number.isFinite(age) && age>=0 && age<=5000;
  const bytes=value=>Number.isFinite(value)?value.toLocaleString()+' bytes':'Unavailable';
  text('debug-metrics-status',fresh?'Live metrics · '+r.viewers+' viewer'+(r.viewers===1?'':'s')+'.':
   state.cover?.resources?.state==='unavailable'?'Metrics unavailable. Close and reopen to retry.':'Waiting for fresh controller metrics…');
  for(const [id,key] of [['free','internal_free_heap_bytes'],['min','internal_min_free_heap_bytes'],['largest','internal_largest_free_block_bytes']])
   text('debug-heap-'+id,bytes(fresh?r[key]:null));
  for(const task of ['web','cover','alpaca','diagnostics','ota']){
   const stack=fresh?r.task_stacks?.[task]:null;
   text('debug-stack-'+task,bytes(stack && stack.sample_age_ms+api.now()-state.coverAt<=10000?stack.min_free_bytes:null));
  }
  text('debug-log-capacity',fresh?(r.debug_log_available?r.debug_log_capacity+' entries':'Unavailable'):'Unavailable');
  text('debug-log-dropped',fresh?String(r.log_dropped):'Unavailable');
  for(const [id,key] of [['overwrites','ring_overwrites'],['truncated','log_truncated'],['suppressed','suppressed_trace']])
   text('debug-log-'+id,fresh && Number.isFinite(r[key])?String(r[key]):'Unavailable');
  text('debug-loop-ages',fresh?r.web_gap_ms+' / '+r.motion_gap_ms+' ms':'Unavailable');
  renderWifiMetrics(fresh?r.wifi:null);
  renderCpuLoad();
 }
 $('debug-live-time').onchange=refreshReceiptTimes;
 let debugRendered='';
 for(const level of ['error','warn','info'])$('debug-'+level).onchange=()=>render();
 function render(){
  prop('readOnlyTestNotice','hidden',!state.session?.read_only_test);
  renderServoNotice();
  manualUI.render();
  api.metrics.sync();
  prop('nav-debug','hidden',!debugEnabled());
  prop('debug-end-session','hidden',!state.debugSession);
  if(state.network && !debugEnabled() && state.view==='debug'){activate('overview','replace');return;}
  if(state.view==='debug'){
   renderLogUptime();
   api.retained?.render();
   if(api.metrics.isOpen())renderMetrics();
   const levels=['error','warn','info'].filter(level=>$('debug-'+level).checked);
   const key=state.debugRevision+':'+levels.join(',');
   if(key!==debugRendered){
    debugRendered=key;const box=$('debug-log'),bottom=box.scrollHeight-box.scrollTop-box.clientHeight<30;
    const entries=state.debugMessages.filter(e=>levels.includes(e.level));
    const rows=entries.map(e=>{const row=document.createElement('div');row.className='debug-entry debug-'+e.level;row.append(receiptTime(e),document.createTextNode(` [${e.level.toUpperCase()}] [${e.source}] ${e.message}`));if(e.count>1)row.append(document.createTextNode(` — repeated ${e.count-1} more time${e.count===2?'':'s'} (${e.count} total; latest `),receiptTime(e,true),document.createTextNode(')'));return row;});
    box.replaceChildren(...rows);if(!rows.length)box.textContent=state.debugMessages.length?'No messages match the selected levels.':'No debug messages yet.';
    if(bottom)box.scrollTop=box.scrollHeight;
   }
   text('debug-status',!state.debugAvailable?'Controller log storage unavailable; browser messages are still recorded.':!api.freshCover()?'Controller unavailable — browser diagnostics remain visible.':state.active?'Controller log download paused during movement.':'Showing recent controller and browser messages.');
  }
  if(!configLoaded&&state.network)loadConfig();else if(state.network)updateNetworks();
  if(state.session&&!state.session.beta_accepted&&!$('betaNotice').open)$('betaNotice').showModal();
  if(state.session?.beta_accepted&&$('betaNotice').open)$('betaNotice').close();
  prop('calibrationDraftDot','hidden',!cal.dirty());prop('configDraftDot','hidden',!configDirty());
  if(state.view==='overview')renderOverview();if(state.view==='configuration')renderConfig();renderDock();
 }
 $('betaNotice').addEventListener('cancel',event=>event.preventDefault());
 $('betaAccept').onchange=async()=>{
  if(!$('betaAccept').checked)return;$('betaAccept').disabled=true;text('betaNoticeStatus','Saving acknowledgment…');
  try{await api.request('beta/accept',{body:{accepted:'yes'},timeout:5000});state.session.beta_accepted=true;$('betaNotice').close();api.emit();}
  catch(error){$('betaAccept').checked=false;text('betaNoticeStatus','Acknowledgment was not confirmed. '+error.message);}
  finally{$('betaAccept').disabled=false;}
 };
 function clearFieldError(input){input.setCustomValidity('');input.removeAttribute('aria-invalid');const error=$(input.id+'-error');if(error)error.hidden=true;}
 function showFieldError(input,message){
  for(let parent=input.parentElement;parent;parent=parent.parentElement)if(parent.tagName==='DETAILS')parent.open=true;
  let error=$(input.id+'-error');if(!error){error=document.createElement('small');error.id=input.id+'-error';error.className='config-field-error';input.closest('label').append(error);const description=input.getAttribute('aria-describedby');input.setAttribute('aria-describedby',(description?description+' ':'')+error.id);}
  error.textContent=message;error.hidden=false;input.setAttribute('aria-invalid','true');
 }
 all('.config-panels input,.config-panels select').forEach(input=>{input.addEventListener('input',()=>{clearFieldError(input);render();});input.addEventListener('change',()=>{clearFieldError(input);render();});input.addEventListener('invalid',()=>showFieldError(input,input.validationMessage));});
 $('cfg-ssid').addEventListener('change',()=>{$('cfg-password').value='';$('cfg-replace-password').checked=false;passwordVisibility(false);render();});
 const invalid=(id,message,feedbackId)=>{for(let el=$(id).parentElement;el;el=el.parentElement)if(el.tagName==='DETAILS')el.open=true;$(id).setCustomValidity(message);showFieldError($(id),message);$(id).focus();$(id).reportValidity();feedback(feedbackId,message,true);};
 all('[data-discard]').forEach(button=>button.onclick=()=>{loadConfig(button.dataset.discard);all('#cfg-'+button.dataset.discard+'-form input').forEach(clearFieldError);feedback('cfg-'+button.dataset.discard+'-message','Changes discarded.');render();});
 $('cfg-jump').onchange=()=>{const target=$($('cfg-jump').value);target.tabIndex=-1;target.focus();target.scrollIntoView({block:'start'});};
 $('cfg-retry').onclick=async()=>{try{await api.network();feedback('cfg-wifi-message','Connection status refreshed.');}catch(_){feedback('cfg-wifi-message','Connection result not confirmed. Check the network or setup hotspot.',true);}render();};
 $('settingsDraftCancel').onclick=()=>{pendingSettings=null;$('settingsDraftDialog').close();};
 $('settingsDraftDialog').addEventListener('cancel',()=>pendingSettings=null);
 $('settingsDraftConfirm').onclick=()=>{const pending=pendingSettings;pendingSettings=null;$('settingsDraftDialog').close();if(!pending)return;for(const kind of pending.others)loadConfig(kind);render();settingsAction(...pending.args,true);};
 async function settingsAction(kind,path,body={},expected=null,restart=false,confirmed=false){
  const why=settingsReason();if(why)return api.note(why,true);
  const others=dirtySections().filter(section=>section!==kind);
  if(!confirmed&&(restart||path==='network/connect')&&others.length){pendingSettings={args:[kind,path,body,expected,restart],others};text('settingsDraftDescription','Continuing may disconnect this page. Unsaved changes in '+others.map(section=>sectionNames[section]).join(', ')+' will be discarded.');$('settingsDraftDialog').showModal();$('settingsDraftCancel').focus();return;}
  if(path==='network/connect')$('cfg-network-help').open=true;
  const scan=path==='network/scan',previousMessage=config().message;
  configBusy=true;settingsOperation={kind,expected,restart};const feedbackId='cfg-'+kind+'-message';
  feedback(feedbackId,'Waiting for controller clearance…');render();
  const initialToken=state.session.token;
  try{
   if(restart)api.expectRestart();
   const response=await api.request(path,{body,timeout:4000});feedback(feedbackId,response);
   // Retain an unconfirmed password draft only in page memory until save succeeds.
   const deadline=api.now()+(kind==='wifi'?35000:restart?25000:18000);
   let sawBusy=false;
   while(api.now()<deadline){
    await new Promise(resolve=>setTimeout(resolve,500));
    let n;try{n=await api.network();}catch(_){continue;}
    sawBusy=sawBusy||n.busy;
    if(!n.busy && n.message!==previousMessage && /fail|rejected|timed out|could not|unavailable/i.test(n.message))throw Error(n.message);
    if(restart){try{await api.boot();}catch(_){}if(state.session.token===initialToken)continue;}
    if(n.busy)continue;
    if(expected&&expected(n) || !expected&&(sawBusy||kind==='scan')){
     if(!scan&&(kind==='time'||kind==='wifi'||kind==='alpaca'||kind==='name'||kind==='advanced'||kind==='diagnostics'))loadConfig(kind);
     if(kind==='reset')loadConfig();
     feedback(feedbackId,'Saved. '+(n.message||'Settings confirmed.'));api.note(n.message||'Settings confirmed.');return;
    }
    if(sawBusy)throw Error(n.message||'Operation was not applied. Previous settings remain active.');
   }
   throw Error('Completion unconfirmed. Reconnect using the new network or setup hotspot, then inspect saved settings.');
  }catch(error){feedback(feedbackId,error.message,true);api.note(error.message,true);}
  finally{configBusy=false;settingsOperation=null;render();}
 }
 $('cfg-scan').onclick=()=>settingsAction('wifi','network/scan',{},n=>!n.busy&&/Scan complete/i.test(n.message));
 $('cfg-wifi-form').onsubmit=event=>{
  event.preventDefault();if(!wifiDirty())return;
  const network=ssid(),password=$('cfg-password').value;
  if(!network||new TextEncoder().encode(network).length>32)return invalid($('cfg-ssid').value==='__hidden'?'cfg-hidden-ssid':'cfg-ssid','Enter a network name of 1–32 bytes.','cfg-wifi-message');
  if(password&&!(password.length>=8&&password.length<=63||/^[a-fA-F0-9]{64}$/.test(password)))return invalid('cfg-password','Enter 8–63 characters, a 64-digit hexadecimal key, or leave blank for an open network.','cfg-wifi-message');
  const body={ssid:network,password};if(!password&&!$('cfg-replace-password').checked&&config().password_saved&&network===config().saved_ssid)body.keep_password='yes';
  settingsAction('wifi','network/connect',body,n=>n.connected&&n.saved_ssid===network&&!n.busy);
 };
 $('cfg-alpaca-form').onsubmit=event=>{
  event.preventDefault();if(!scopeDirty())return;const draft=scopeDraft();if(!draft.enabled){draft.host=config().alpaca_host||'';draft.port=config().alpaca_port||32323;draft.device=config().alpaca_device??0;}const pieces=draft.host.split('.');
  if(draft.enabled&&(pieces.length!==4||pieces.some(p=>!/^\d{1,3}$/.test(p)||Number(p)>255)))return invalid('cfg-ip','Enter a numeric IPv4 address.','cfg-alpaca-message');
  settingsAction('alpaca','settings/alpaca',draft,n=>Object.entries(draft).every(([key,value])=>n['alpaca_'+key]===value),true);
 };
 $('cfg-time-form').onsubmit=event=>{event.preventDefault();const draft=timeDraft();if(timeDirty())settingsAction('time','settings/time',draft,n=>n.ntp_enabled===draft.enabled&&n.ntp_server===draft.server&&n.time_zone===draft.time_zone,true);};
 $('cfg-advanced-form').onsubmit=event=>{event.preventDefault();const value=$('cfg-disable-torque').checked,debug=!!config().enable_debug_tab;settingsAction('advanced','settings/advanced',{disable_torque_after_move:value,enable_debug_tab:debug},n=>n.disable_torque_after_move===value && n.enable_debug_tab===debug,true);};
 $('cfg-diagnostics-form').onsubmit=event=>{event.preventDefault();const value=!!config().disable_torque_after_move,debug=$('cfg-enable-debug').checked;settingsAction('diagnostics','settings/advanced',{disable_torque_after_move:value,enable_debug_tab:debug},n=>n.disable_torque_after_move===value&&n.enable_debug_tab===debug,true);};
 $('cfg-disable-torque').onchange=()=>render();
 $('cfg-enable-debug').onchange=()=>render();
 $('cfg-debug-session').onclick=()=>{api.setSessionDebug(true);route('debug');};
 $('debug-end-session').onclick=()=>api.setSessionDebug(false);
 $('cfg-name-form').onsubmit=event=>{event.preventDefault();const value=$('cfg-hostname').value;if(nameDirty())settingsAction('name','settings/hostname',{hostname:value},n=>n.mdns_name===value);};
 for(const kind of ['network','calibration'])$('cfg-reset-'+kind).onclick=()=>{
  if(settingsReason())return;resetKind=kind;text('resetTitle',kind==='network'?'Reset controller settings?':'Clear calibration?');
  text('resetDescription',kind==='network'?'Reset Wi-Fi, local name, telescope settings, motor holding preference, date and time settings, Debug visibility, and beta acknowledgment. Calibration and browser appearance are kept. The controller restarts into its setup hotspot. Join the controller hotspot and open http://192.168.4.1.':'Erase saved travel limits, endpoints, and motion profile. Controller settings are kept. The controller restarts; calibrate again before moving.');
  text('resetConfirm',kind==='network'?'Reset settings & restart':'Clear calibration & restart');$('resetDialog').showModal();$('resetCancel').focus();
 };
 $('resetCancel').onclick=()=>$('resetDialog').close();
 $('resetConfirm').onclick=()=>{$('resetDialog').close();settingsAction('reset',resetKind==='network'?'settings/reset':'settings/clear-calibration',{confirm:resetKind==='network'?'reset-preserve-calibration':'clear-calibration'},resetKind==='network'?n=>!n.saved_ssid:()=>!state.cover?.calibrated,true);};
 const clearPageConfirmations=()=>{clearStowOverride();for(const id of ['ov-supervised','ov-manual'])$(id).checked=false;};
 clearPageConfirmations();window.addEventListener('pageshow',clearPageConfirmations);
 document.addEventListener('controllerrestart',()=>{
  clearPageConfirmations();
  if(!configDirty())configLoaded=false;
 });
 window.addEventListener('beforeunload',event=>{if(cal.dirty()||configDirty()){event.preventDefault();event.returnValue='';}});
 api.canAutoReload=()=>!api.diagnostics?.busy()&&!cal.dirty()&&!configDirty()&&!configBusy&&!settingsOperation&&!manualUI.busy()&&!document.querySelector('dialog[open]');
 api.subscribe(render);
 const initial=routes.includes(location.hash.slice(1))?location.hash.slice(1):location.pathname==='/configuration'?'configuration':['/control','/calibration'].includes(location.pathname)?'calibration':'overview';
 activate(initial,'replace',false);api.start();
})();
