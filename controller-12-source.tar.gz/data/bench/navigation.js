/* One shared header survives view changes; updates stay inside Configuration. */
(() => {
 'use strict';
 const views=['overview','calibration','configuration','manual'];
 const sections={'cfg-network':'','cfg-updates':'firmware','cfg-about':'about','cfg-recovery':'recovery'};
 function show(view='overview',section=null,{historyMode='push',focus=true}={}){
  if(!views.includes(view))view='overview';
  document.querySelectorAll('[data-view]').forEach(el=>{el.hidden=el.dataset.view!==view;});
  document.querySelectorAll('nav [data-view-link]').forEach(el=>{if(el.dataset.viewLink===view)el.setAttribute('aria-current','page');else el.removeAttribute('aria-current');});
  const suffix=view==='configuration'&&sections[section]?'/'+sections[section]:'';
  const hash='#'+view+suffix;
  if(historyMode!=='none'&&location.hash!==hash)history[historyMode==='replace'?'replaceState':'pushState'](null,'',hash);
  if(view==='configuration')document.getElementById('cfg-jump').value=section||'cfg-network';
  const target=document.getElementById(section||view+'-heading');
  if(focus&&target){target.focus({preventScroll:true});if(section)target.scrollIntoView({block:'start'});else window.scrollTo({top:0,behavior:'instant'});}
 }
 function restore(options={}){
  const [view,suffix]=location.hash.replace(/^#/,'').split('/');
  const section=Object.keys(sections).find(key=>sections[key]===suffix);
  show(view||'overview',section,{historyMode:'none',...options});
 }
 document.querySelectorAll('[data-view-link]').forEach(el=>{el.onclick=event=>{event.preventDefault();show(el.dataset.viewLink);};});
 document.querySelectorAll('[data-firmware-link],#header-update').forEach(el=>{el.onclick=event=>{event.preventDefault();show('configuration','cfg-updates');};});
 document.querySelectorAll('[data-config-link]').forEach(el=>{el.onclick=event=>{event.preventDefault();show('configuration',el.dataset.configLink);};});
 document.getElementById('cfg-jump').onchange=()=>show('configuration',document.getElementById('cfg-jump').value);
 window.addEventListener('hashchange',()=>restore());window.addEventListener('popstate',()=>restore());
 restore({focus:false});
 window.coverBenchNavigation={showFirmware:()=>show('configuration','cfg-updates'),show};
})();
