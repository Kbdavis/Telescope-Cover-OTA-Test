/* Isolated bench pipeline. No production-motion or ordinary release authority. */
(() => {
'use strict';
const $=id=>document.getElementById(id);
const API='https://api.github.com/repos/Kbdavis/Telescope-Cover-OTA-Test/releases?per_page=10';
const HOST='https://kbdavis.github.io/Telescope-Cover-OTA-Test/';
const hex=bytes=>Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join('');
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
let updateSession=null;
const preferenceKey='cover.bench.autoCheck.v1';
let automatic=true;try{automatic=window.localStorage.getItem(preferenceKey)!=='false';}catch(_){}
let lastCheck=0;
let current=null,selected=null,active=false,transaction='',cancelled=false,checking=false,permittedAt=0,nextAuto=0;
const text=(id,value)=>{$(id).textContent=String(value);};
async function bounded(url,max,options={}){
 const r=await fetch(url,{cache:'no-store',credentials:'omit',referrerPolicy:'no-referrer',signal:AbortSignal.timeout(15000),...options});
 if(!r.ok){if(r.status===403||r.status===429){const retry=Number(r.headers.get('Retry-After'))*1000;permittedAt=Math.max(permittedAt,Date.now()+Math.max(60000,Math.min(retry||60000,86400000)));}throw Error('HTTP '+r.status+' while reading '+new URL(url,location.href).pathname);}
 if(!r.body?.getReader)throw Error('This browser cannot read bounded firmware responses');
 const reader=r.body.getReader(),chunks=[];let size=0;
 try{for(;;){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>max){await reader.cancel();throw Error('Response exceeds bench limit');}chunks.push(value);}}finally{reader.releaseLock();}
 const out=new Uint8Array(size);let at=0;for(const c of chunks){out.set(c,at);at+=c.length;}return out;
}
const json=async(url,max)=>JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(await bounded(url,max)));
async function status(){const s=await json('/api/bench/status',4096);if(s.profile!=='bench-ota-v1'||s.servo_operations!==false)throw Error('Expected isolated bench controller');return s;}
async function loadUpdateSession(controller){
 updateSession=null;
 const bytes=await bounded('/api/bench/session',1024,{headers:{'X-Bench-Session':'1'}});
 const session=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));
 if(session.boot!==controller.boot||session.nonce!==controller.nonce||!/^[a-f0-9]{64}$/.test(session.update_token))throw Error('Refresh this controller page to renew update authorization');
 updateSession=session;
}
function render(){
 const remaining=Math.max(0,Math.ceil((permittedAt-Date.now())/1000));
 $('check').disabled=checking||active||remaining>0;
 text('check',checking?'Checking…':remaining?'Check in '+remaining+'s':'Check now');
 text('check-reason',remaining?'Please wait before another release request.':'');
 const anotherUpdate=!active&&['preparing','receiving','verified','committing','rebooting'].includes(current?.phase);
 $('install').disabled=active||anotherUpdate||!selected||!current?.accepted||!$('confirm').checked||!updateSession||updateSession.boot!==current.boot;
 $('cancel').disabled=!active||!transaction;
 $('automatic-check').checked=automatic;
 $('header-update').hidden=!selected||active;
 text('last-check',lastCheck?new Date(lastCheck).toLocaleString(undefined,{timeZoneName:'short'}):'Not checked yet');
 text('controller-address',location.host);text('config-address',location.host);
 if(current){
  text('installed',current.version);text('identity',current.elf);text('health',current.accepted?'Startup accepted':'Startup not accepted');
  text('overview-version',current.version);text('footer-version','Firmware '+current.version);
  text('overview-health',current.accepted?'Controller ready':'Startup check required');
  text('overview-detail',anotherUpdate?'An update is in progress on another page.':'Firmware updates are available in Configuration.');
  text('network-status','Connected through the controller’s home network.');
 }

}
function manifestFields(text){
 const pattern=/^product=telescope-cover-ota-bench\nprotocol=1\nlayout=cover-4mb-v1\nsettings=preserve-cover-app-v1\nsource_build=([1-9]\d*)\nsource_elf=([a-f0-9]{64})\ntarget_build=([1-9]\d*)\ntarget_elf=([a-f0-9]{64})\nsize=([1-9]\d*)\nsha256=([a-f0-9]{64})\n$/;
 const m=pattern.exec(text);if(!m||m[0]!==text)throw Error('Invalid bench manifest');
 const out={sourceBuild:Number(m[1]),sourceElf:m[2],build:Number(m[3]),elf:m[4],size:Number(m[5]),sha:m[6]};
 if(out.build>9999||out.sourceBuild>=out.build||out.size<352||out.size>1310720)throw Error('Invalid bench version/size');return out;
}
async function check(){
 if(checking||active||Date.now()<permittedAt)return;
 checking=true;permittedAt=Date.now()+60000;selected=null;text('discovery','Checking published test releases…');render();
 try{
  current=await status();await loadUpdateSession(current);const releases=await json(API,262144);
  if(!Array.isArray(releases)||releases.length>10)throw Error('Invalid release list');
  const index=await json(HOST+'index.json?check='+Date.now(),32768);
  if(index.schema!=='telescope-cover-bench-catalog/1'||!Array.isArray(index.releases)||index.releases.length>10)throw Error('Invalid bench catalog');
  for(const r of [...index.releases].sort((a,b)=>b.build-a.build)){
   if(!Number.isInteger(r.build)||r.build<=current.build||r.build>9999||!releases.some(g=>g.tag_name===r.tag&&g.draft===false&&g.prerelease===true&&g.published_at))continue;
   if(r.tag!=='v0.1.0-beta.'+r.build||r.application!=='bench-'+r.build+'.bin'||typeof r.manifest!=='string'||!/^([a-f0-9]{128})$/.test(r.signature))throw Error('Invalid test release entry');
   const m=manifestFields(r.manifest);
   if(m.build!==r.build||m.sourceBuild!==current.build||m.sourceElf!==current.elf)continue;
   selected={...r,parsed:m};break;
  }
  text('available',selected?'Update available · 0.1.0-beta.'+selected.build:'No compatible newer bench release found.');
  $('release').href=selected?'https://github.com/Kbdavis/Telescope-Cover-OTA-Test/releases/tag/'+encodeURIComponent(selected.tag):'https://github.com/Kbdavis/Telescope-Cover-OTA-Test/releases';
  text('notes',selected?'Public bench release '+selected.tag+'\n'+String(selected.notes||'').slice(0,4096):'');
  text('discovery','Checked the public test repository and bench catalog.');
  lastCheck=Date.now();nextAuto=lastCheck+3600000;
 }catch(e){text('discovery','Release check failed: '+e.message);text('available','Compatibility unavailable.');nextAuto=Date.now()+300000;}
 finally{checking=false;render();}
}
async function post(path,body){
 if(!updateSession||updateSession.boot!==current.boot||updateSession.nonce!==current.nonce)throw Error('Controller restarted; refresh the page');
 const bytes=await bounded('/api/bench/'+path,4096,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded','X-Bench-Key':updateSession.update_token,'X-Bench-Nonce':current.nonce},body:new URLSearchParams(body)});
 return new TextDecoder().decode(bytes);
}
async function waitFor(test,timeout=15000){
 const until=performance.now()+timeout;
 while(performance.now()<until){const s=await status();if(s.boot!==current.boot)throw Error('Controller restarted before activation');
  if(['failed','cancelled'].includes(s.phase))throw Error(s.phase+': '+s.reason);
  if(s.transaction!==transaction)throw Error('Controller transaction changed');if(test(s))return s;await sleep(10);}
 throw Error('Timed out waiting for controller');
}
async function install(){
 if($('install').disabled||!selected)return;
 const release=selected,source=current;active=true;cancelled=false;transaction='';render();
 try{
  text('operation','Downloading '+release.tag+'…');
  // All remote download completes before the controller acquires a flash transaction.
  const image=await bounded(HOST+release.application,1310720);
  if(cancelled)throw Error('Cancelled before transfer');
  if(image.length!==release.parsed.size||hex(image.slice(176,208))!==release.parsed.elf)throw Error('Downloaded image size/identity mismatch');
  const fresh=await status();if(fresh.boot!==source.boot||fresh.elf!==source.elf||!fresh.accepted)throw Error('Source controller changed');
  current=fresh;await loadUpdateSession(fresh);
  transaction=await post('start',{manifest:release.manifest,signature:release.signature,confirm:'install'});
  if(!/^[a-f0-9]{32}$/.test(transaction))throw Error('Invalid transaction response');render();
  await waitFor(s=>s.phase==='receiving');
  const completedAck=fresh.chunk_ack==='consumed-offset-v1'&&fresh.chunk_bytes===768;
  const chunkBytes=completedAck?768:384;
  for(let offset=0;offset<image.length;){
   if(cancelled)throw Error('Cancelled by user');
   const chunk=image.slice(offset,offset+chunkBytes),expected=offset+chunk.length;
   const reply=await post('chunk',{transaction,offset:String(offset),data:hex(chunk)});
   if(completedAck){
    const ack=JSON.parse(reply);
    if(ack.transaction!==transaction||ack.received!==expected)throw Error('Invalid completed-write acknowledgement');
   }else await waitFor(s=>s.received===expected);
   offset=expected;
   $('progress').value=100*offset/image.length;text('operation','Installing: '+offset+' / '+image.length+' bytes');
  }
  await post('finish',{transaction});text('operation','Verifying and rebooting…');$('cancel').disabled=true;
  const until=performance.now()+60000;let result=null;
  while(performance.now()<until){
   await sleep(750);
   let s;try{s=await status();}catch(_){continue;}
   if(s.boot===source.boot){if(s.phase==='failed')throw Error(s.reason);continue;}
   if(s.elf!==release.parsed.elf||s.build!==release.build||s.outcome!=='complete'||s.journal_transaction!==transaction||s.journal_target!==release.parsed.elf||!s.accepted||!s.settings_preserved)throw Error('Reboot outcome is unconfirmed or settings differ');
   result=s;break;
  }
  if(!result)throw Error('New firmware did not confirm startup; inspect the controller before retrying');
  current=result;updateSession=null;selected=null;text('available','Installed '+result.version);text('operation','Update installed successfully. Reboot and saved settings verified.');
  window.benchLastResult={source:source.elf,target:result.elf,transaction,boot:result.boot,settings_preserved:true};
 }catch(e){
  if(transaction){try{await post('cancel',{transaction});}catch(_){} }
  text('operation','Update stopped: '+e.message+'. Inspect the reported outcome before trying again.');
 }finally{active=false;transaction='';$('confirm').checked=false;render();}
}
$('check').onclick=check;$('install').onclick=install;
$('confirm').onchange=render;
$('automatic-check').onchange=()=>{
 automatic=$('automatic-check').checked;
 try{window.localStorage.setItem(preferenceKey,String(automatic));}catch(_){}
 if(automatic&&!active&&!checking&&Date.now()>=nextAuto)check();else render();
};
$('cancel').onclick=()=>{cancelled=true;if(transaction)post('cancel',{transaction}).catch(()=>{});};
window.addEventListener('beforeunload',event=>{if(active){event.preventDefault();event.returnValue='';}});
document.addEventListener('visibilitychange',()=>{if(!document.hidden&&automatic&&!active&&!checking&&Date.now()>=nextAuto)check();});
setInterval(()=>{render();if(automatic&&!document.hidden&&!active&&!checking&&Date.now()>=nextAuto)check();},1000);
async function connect(){
 text('discovery','Preparing controller update information…');
 try{
  current=await status();await loadUpdateSession(current);render();
  if(automatic)await check();else text('discovery','Automatic checks are off. Use Check now to look for an update.');
 }catch(e){text('discovery','Controller connection failed: '+e.message);nextAuto=Date.now()+300000;render();}
}
connect();
})();
