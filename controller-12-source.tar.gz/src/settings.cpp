#include "settings.h"
#include "time_settings.h"
#include "motion_limits.h"
#include <Preferences.h>
#include <string.h>
namespace cover {
namespace {
uint16_t checksum(const uint16_t* words,size_t count) {
 uint16_t value=0x5a39;
 for(size_t i=0;i<count;++i)value=static_cast<uint16_t>((value*31U)^words[i]);
 return value;
}
}
bool validMotionProfile(const MotionProfile& p) {
 return p.openSpeed>=1 && p.openSpeed<=1600 && p.closeSpeed>=1 && p.closeSpeed<=1600 &&
  p.jogSpeed>=1 && p.jogSpeed<=100 && p.acceleration>=1 && p.acceleration<=100 &&
  p.timeoutMs>=500 && p.timeoutMs<=30000;
}
bool validCalibration(const Calibration& c) {
 if((c.referenceOffset!=85 && c.referenceOffset!=1328) || !validMotionProfile(c.profile) || c.maximum>kAllowedMaximum || c.minimum>=c.maximum ||
    !c.hasClosed || !c.hasOpen || c.closed<c.minimum || c.closed>c.maximum ||
    c.open<c.minimum || c.open>c.maximum)return false;
 const auto arc=calibrationArc(c);
 return arc.valid() && arc.rawTarget(c.travelCounts)==c.open && c.travelCounts>2*kEndpointTolerance;
}
SettingsLoad loadCalibration(Calibration& output) {
 Preferences prefs;
 if(!prefs.begin("cover-cal",false))return SettingsLoad::Unavailable;
 if(!prefs.isKey("v1")){prefs.end();return SettingsLoad::Missing;}
 // Read-only migration: v1 (16), v2 (26), v3 (30 bytes), existing NVS key.
 uint16_t words[17]={};const size_t size=prefs.getBytesLength("v1");
 const size_t count=size/2;
 const bool ok=(size==16 || size==26 || size==30 || size==32 || size==34) && prefs.getBytes("v1",words,size)==size;
 prefs.end();
 if(!ok || words[0]!=0xca11 || words[1]!=(size==16?1:size==26?2:size==30?3:size==32?4:5) || words[6]!=3 ||
    words[count-1]!=checksum(words,count-1))return SettingsLoad::Invalid;
 Calibration c;c.referenceOffset=size==34?words[15]:kFactoryReferenceOffset;c.minimum=words[2];c.maximum=words[3];c.closed=words[4];c.open=words[5];c.hasClosed=c.hasOpen=true;
 if(size!=16){
  if(words[10]>100)return SettingsLoad::Invalid;
  c.profile.openSpeed=words[7];c.profile.closeSpeed=words[8];c.profile.jogSpeed=words[9];
  c.profile.acceleration=words[10];c.profile.timeoutMs=words[11];
 }
 if(!validMotionProfile(c.profile) || c.minimum>=c.maximum || c.maximum>4095 ||
    c.closed<c.minimum || c.closed>c.maximum || c.open<c.minimum || c.open>c.maximum ||
    abs(int(c.open)-int(c.closed))<=2*kEndpointTolerance)return SettingsLoad::Invalid;
 if(size>=30){
  if(size>=32){if(words[14]>1)return SettingsLoad::Invalid;c.circular=words[14];}
  if(words[12]!=1 && words[12]!=2)return SettingsLoad::Invalid;
  c.openingDirection=words[12]==1?1:-1;c.travelCounts=words[13];
  if(!validCalibration(c))return SettingsLoad::Invalid;
 }else{
  // Preserve the old explicitly linear interval only when a direct path is
  // unambiguous. Do not reinterpret endpoints via shortest circular distance.
  c.openingDirection=c.open>c.closed?1:-1;c.travelCounts=abs(int(c.open)-int(c.closed));
  if(!supportedDirectPath(c.closed,c.open)){output=c;return SettingsLoad::ReviewRequired;}
  if(!validCalibration(c))return SettingsLoad::Invalid;
 }
 if(!convertCalibrationReference(c,kApplicationReferenceOffset)){output=c;return SettingsLoad::ReviewRequired;}
 output=c;return SettingsLoad::Loaded;
}
bool saveCalibration(const Calibration& c) {
 if(c.referenceOffset!=kApplicationReferenceOffset || !validCalibration(c))return false;
 uint16_t words[17]={0xca11,5,c.minimum,c.maximum,c.closed,c.open,3,
  c.profile.openSpeed,c.profile.closeSpeed,c.profile.jogSpeed,c.profile.acceleration,c.profile.timeoutMs,
  uint16_t(c.openingDirection==1?1:2),c.travelCounts,uint16_t(c.circular),c.referenceOffset,0};
 words[16]=checksum(words,16);
 Preferences prefs;if(!prefs.begin("cover-cal",false))return false;
 bool ok=prefs.putBytes("v1",words,sizeof(words))==sizeof(words);
 uint16_t readback[17]={};
 ok=ok && prefs.getBytes("v1",readback,sizeof(readback))==sizeof(readback) && memcmp(words,readback,sizeof(words))==0;
 prefs.end();return ok;
}
}

namespace cover {
namespace {
// Fixed byte layout, independent of compiler padding and native endianness.
constexpr size_t kRecordSize=382;
size_t boundedLength(const char* value,size_t size) {
 const void* end=memchr(value,0,size);
 return end?static_cast<const char*>(end)-value:size;
}
uint32_t recordChecksum(const uint8_t* bytes,size_t size=kRecordSize) {
 uint32_t hash=2166136261UL;
 for(size_t i=0;i<size-4;++i)hash=(hash^bytes[i])*16777619UL;
 return hash;
}
void put16(uint8_t* p,uint16_t value){p[0]=value&255;p[1]=value>>8;}
uint16_t get16(const uint8_t* p){return uint16_t(p[0])|(uint16_t(p[1])<<8);}
void encodeApplication(const ApplicationSettings& s,uint8_t* b) {
 memset(b,0,kRecordSize);
 b[0]='C';b[1]='F';b[2]=6;b[3]=s.wifiConfigured;b[4]=s.alpacaEnabled;
 memcpy(b+5,s.ssid,strlen(s.ssid));
 memcpy(b+38,s.password,strlen(s.password));
 memcpy(b+103,s.name,strlen(s.name));
 memcpy(b+144,s.alpacaHost,strlen(s.alpacaHost));
 put16(b+208,s.alpacaPort);put16(b+210,s.alpacaDevice);put16(b+212,s.stowTimeoutSeconds);
 memcpy(b+214,s.mdnsName,strlen(s.mdnsName));
 b[246]=s.alpacaReadOnly;
 b[247]=s.disableTorqueAfterMove;
 b[248]=s.enableDebugTab;
 b[249]=s.ntpEnabled;
 memcpy(b+250,s.ntpServer,strlen(s.ntpServer));
 memcpy(b+314,s.timeZone,strlen(s.timeZone));
 uint32_t hash=recordChecksum(b);
 for(unsigned i=0;i<4;++i)b[kRecordSize-4+i]=hash>>(8*i);
}
}
bool validMdnsName(const char* value) {
 size_t n=boundedLength(value,32);
 if(!n || n>31 || value[0]=='-' || value[n-1]=='-')return false;
 for(size_t i=0;i<n;++i)if(!((value[i]>='a' && value[i]<='z') ||
  (value[i]>='0' && value[i]<='9') || value[i]=='-'))return false;
 return true;
}
bool validApplicationSettings(const ApplicationSettings& s) {
 if(!validMdnsName(s.mdnsName) || !validTimeServer(s.ntpServer,sizeof(s.ntpServer)) ||
    !validTimeZone(s.timeZone,sizeof(s.timeZone)))return false;
 const auto ssid=boundedLength(s.ssid,sizeof(s.ssid));
 const auto pass=boundedLength(s.password,sizeof(s.password));
 const auto name=boundedLength(s.name,sizeof(s.name));
 const auto host=boundedLength(s.alpacaHost,sizeof(s.alpacaHost));
 if(ssid>=sizeof(s.ssid) || pass>=sizeof(s.password) || !name || name>=sizeof(s.name) ||
    host>=sizeof(s.alpacaHost) || !s.alpacaPort || s.alpacaDevice>255 ||
    s.stowTimeoutSeconds<10 || s.stowTimeoutSeconds>180)return false;
 if(s.wifiConfigured && !ssid)return false;
 if(!s.wifiConfigured && (ssid || pass))return false;
 // Open networks, WPA passphrases, or an exact 64-digit hexadecimal PSK.
 if(pass && pass<8)return false;
 if(pass==64)for(size_t i=0;i<pass;++i)
  if(!((s.password[i]>='0' && s.password[i]<='9') ||
       (s.password[i]>='a' && s.password[i]<='f') ||
       (s.password[i]>='A' && s.password[i]<='F')))return false;
 if(s.alpacaEnabled && !host)return false;
 for(size_t i=0;i<host;++i) {
  char c=s.alpacaHost[i];
  if(!((c>='a' && c<='z') || (c>='A' && c<='Z') ||
       (c>='0' && c<='9') || c=='.' || c=='-'))return false;
 }
 return true;
}
SettingsLoad loadApplicationSettings(ApplicationSettings& output) {
 Preferences prefs;
 if(!prefs.begin("cover-app",false))return SettingsLoad::Unavailable;
 if(!prefs.isKey("v1")){prefs.end();return SettingsLoad::Missing;}
 uint8_t b[kRecordSize]={};
 size_t size=prefs.getBytesLength("v1");
 bool ok=(size==218 || size==250 || size==251 || size==252 || size==253 || size==sizeof(b)) && prefs.getBytes("v1",b,size)==size;
 prefs.end();
 if(!ok)return SettingsLoad::Invalid;
 uint32_t hash=0;for(unsigned i=0;i<4;++i)hash|=uint32_t(b[size-4+i])<<(8*i);
 if(b[0]!='C' || b[1]!='F' || b[2]!=(size==218?1:size==250?2:size==251?3:size==252?4:size==253?5:6) || b[3]>1 || b[4]>1 ||
    (size>=251 && b[246]>1) || (size>=252 && b[247]>1) || (size>=253 && b[248]>1) || (size==kRecordSize && b[249]>1) || hash!=recordChecksum(b,size))return SettingsLoad::Invalid;
 ApplicationSettings s;
 if(size>=250)memcpy(s.mdnsName,b+214,sizeof(s.mdnsName));
 if(size>=253)s.enableDebugTab=b[248];
 if(size==kRecordSize){s.ntpEnabled=b[249];memcpy(s.ntpServer,b+250,sizeof(s.ntpServer));memcpy(s.timeZone,b+314,sizeof(s.timeZone));}
 if(size>=252)s.disableTorqueAfterMove=b[247];
 if(size>=251)s.alpacaReadOnly=b[246]; // Preserve legacy storage; current firmware chooses session recovery.
 s.wifiConfigured=b[3];s.alpacaEnabled=b[4];
 memcpy(s.ssid,b+5,sizeof(s.ssid));memcpy(s.password,b+38,sizeof(s.password));
 memcpy(s.name,b+103,sizeof(s.name));memcpy(s.alpacaHost,b+144,sizeof(s.alpacaHost));
 s.alpacaPort=get16(b+208);s.alpacaDevice=get16(b+210);s.stowTimeoutSeconds=get16(b+212);
 if(!validApplicationSettings(s))return SettingsLoad::Invalid;
 output=s;return SettingsLoad::Loaded;
}
bool saveApplicationSettings(const ApplicationSettings& s) {
 if(!validApplicationSettings(s))return false;
 uint8_t b[kRecordSize],readback[kRecordSize]={};encodeApplication(s,b);
 Preferences prefs;if(!prefs.begin("cover-app",false))return false;
 bool ok=prefs.putBytes("v1",b,sizeof(b))==sizeof(b) &&
  prefs.getBytes("v1",readback,sizeof(readback))==sizeof(readback) && memcmp(b,readback,sizeof(b))==0;
 prefs.end();return ok;
}
}

namespace cover {
namespace {
constexpr uint8_t kBetaAcceptance[]={0x42,0x45,0x54,0x41,1};
}
bool betaNoticeAccepted() {
 Preferences prefs;if(!prefs.begin("cover-beta",false))return false;
 uint8_t record[sizeof(kBetaAcceptance)]={};
 bool ok=prefs.getBytesLength("accepted")==sizeof(record) &&
  prefs.getBytes("accepted",record,sizeof(record))==sizeof(record) &&
  memcmp(record,kBetaAcceptance,sizeof(record))==0;
 prefs.end();return ok;
}
bool acceptBetaNotice() {
 if(betaNoticeAccepted())return true;
 Preferences prefs;if(!prefs.begin("cover-beta",false))return false;
 bool ok=prefs.putBytes("accepted",kBetaAcceptance,sizeof(kBetaAcceptance))==sizeof(kBetaAcceptance);
 prefs.end();return ok && betaNoticeAccepted();
}
bool resetApplicationSettingsPreservingCalibration() {
 Preferences prefs;if(!prefs.begin("cover-beta",false))return false;
 bool ok=!prefs.isKey("accepted") || prefs.remove("accepted");
 ok=ok && !prefs.isKey("accepted");prefs.end();
 if(!ok)return false;
 return saveApplicationSettings(ApplicationSettings{});
}
}

namespace cover {
bool clearCalibration() {
 Preferences prefs;
 if(!prefs.begin("cover-cal",false))return false;
 bool ok=!prefs.isKey("v1") || prefs.remove("v1");
 ok=ok && !prefs.isKey("v1");
 prefs.end();return ok;
}
}
