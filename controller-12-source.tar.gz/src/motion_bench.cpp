#ifdef COVER_MOTION_BENCH
#include <Arduino.h>
#include "cover_controller.h"
#include "motion_bench.h"
#ifdef COVER_FACTORY_MOTION_BENCH
#include "factory_motion_bench.h"
#endif
namespace cover {
namespace {
#ifdef COVER_FACTORY_MOTION_BENCH
FactoryBenchServo servo(Serial1);
#else
ServoController servo(Serial1);
#endif
CoverController controller(servo);
uint32_t boot, heartbeat = 0, lastLog = 0;
uint16_t origin = 0;
bool ready = false, initialized = false, forward = false, returned = false;
State previous = State::Unknown;
void status() {
  Serial.printf("STATE %s position=%u target=%u torque_off=%u fault=%s\n",
    stateName(controller.state()), controller.position(), controller.target(),
    controller.torqueOffConfirmed(), controller.fault());
}
}
void beginMotionBench() {
  Serial1.begin(1000000, SERIAL_8N1, 18, 19);
  boot = millis();
  Serial.println("MOTION BENCH: no movement on boot. j=+20 r=return x=STOP h=heartbeat v=verify");
}
void pollMotionBench() {
  const uint32_t now = millis();
  if (!initialized) {
    if (now - boot < 3000) return;
    initialized = true;
    uint16_t model = 0, confirm = 0;
    bool torque = true;
    if (!servo.readModel(model) || model != 777 || !servo.validateConfiguration() ||
        !servo.readTorque(torque) || torque || !servo.readPosition(origin) ||
        !servo.readPosition(confirm) || abs(int(origin)-int(confirm)) > 3 ||
        origin < 30 || origin > 4065) {
      Serial.println("NOT READY: identity/configuration/torque/position check failed"); return;
    }
    MotionSettings s;
    s.minimum = origin - 30; s.maximum = origin + 30;
    s.speed = 100; s.acceleration = 10; s.timeoutMs = 5000;
    ready = controller.configure(s);
    if (!ready) { Serial.println("NOT READY: motion settings rejected"); return; }
    Serial.printf("READY origin=%u limits=%u..%u speed=100 acceleration=10\n",origin,s.minimum,s.maximum);
  }
  // Bound USB work so a stream of commands cannot starve motion supervision.
  for (unsigned n = 0; n < 16 && Serial.available(); ++n) {
    const int command = Serial.read();
    if (command == 'v' && !controller.moving()) {
      bool torque = true;
      const bool configuration = bool(servo.validateConfiguration());
      const bool torqueRead = bool(servo.readTorque(torque));
      Serial.printf("VERIFY configuration=%u torque_off=%u\n", configuration, torqueRead && !torque);
    }
    if (command == 'x') { controller.stop(); ready = false; status(); }
    if (command == 'h') heartbeat = millis();
    if (command == 'j' && ready && !forward && controller.state() != State::Fault) {
      uint16_t p;
      if (!servo.readPosition(p) || abs(int(p)-int(origin)) > 3) {
        ready = false; Serial.println("REJECT starting position changed"); continue;
      }
      forward = true; heartbeat = millis();
      Serial.printf("COMMAND forward accepted=%u\n", controller.jog(20, true)); status();
    }
    if (command == 'r' && ready && forward && !returned && controller.state() == State::Stopped) {
      uint16_t p;
      if (!servo.readPosition(p) || abs(int(p)-int(origin+20)) > 3) {
        ready = false; Serial.println("REJECT forward target not reached"); continue;
      }
      returned = true; heartbeat = millis();
      Serial.printf("COMMAND return accepted=%u\n", controller.jog(int(origin)-int(p), true)); status();
    }
  }
  controller.tick(ready && millis() - heartbeat < 500);
  if (controller.state() != previous || (controller.moving() && now - lastLog >= 100)) {
    previous = controller.state(); lastLog = now; status();
  }
}
}
#endif
