#ifdef COVER_WEB_CONTROL
#include "web_control.h"
#include "servo_support.h"
#include "cover_controller.h"
#include "diagnostics.h"
#include "endpoint_observer.h"
#include "maintenance_worker.h"
#include "manual_stow.h"
#include "telescope_arm.h"
#include <esp_heap_caps.h>
#include "alpaca_client.h"
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/queue.h>
#include <esp_system.h>
#include <esp_attr.h>
namespace cover {
namespace {
QueueHandle_t commands=nullptr;
portMUX_TYPE mux=portMUX_INITIALIZER_UNLOCKED;
WebStatus shared;
ServoSupportSnapshot supportShared;
bool stopRequested=false;
bool stopAutomatic=false;uint32_t stopControlGeneration=0;
RTC_NOINIT_ATTR uint32_t retainedRebootMarker;
bool rebootRequested=false,rebootRetain=false;
MaintenanceArbiter maintenance;
bool maintenanceStaOnly=false;
uint8_t maintenanceWorkers=0;
OtaMaintenanceRequirements otaRequirements;
bool closedOtaStartup=false,poweredOtaStartup=false;
bool inspectOtaServoStartup=false;
bool startupAccepted=true; // main() closes this gate before creating workers.
bool emergencyReserved=false,emergencyStart=false,emergencyFinish=false,emergencyCancelled=false;
uint32_t stopEpoch=0;
void publish(const WebStatus& s) {portENTER_CRITICAL(&mux);shared=s;portEXIT_CRITICAL(&mux);}
bool noServoReply(const ServoResult& result){
 return result.error==ServoError::Timeout || result.error==ServoError::WriteFailed || result.error==ServoError::InvalidPacket;
}
void describeConfigurationMismatch(char* output,size_t capacity,const ServoConfiguration& c){
 if(c.phase==12 && c.offset==85 && c.id==st3215::kServoId && c.mode==0 &&
    c.minimum==0 && c.maximum==4095 && c.resolution==1){
  snprintf(output,capacity,"ST3215 factory profile mismatch; inspect USB diagnostics");return;
 }
 snprintf(output,capacity,"ST3215 configuration mismatch");
 const auto field=[&](const char* name,unsigned actual,unsigned expected){
  if(actual==expected)return;
  const size_t used=strlen(output);
  if(used<capacity)snprintf(output+used,capacity-used,"; %s=%u (need %u)",name,actual,expected);
 };
 field("id",c.id,st3215::kServoId);field("mode",c.mode,0);
 field("min",c.minimum,0);field("max",c.maximum,4095);
 field("phase",c.phase,0);field("res",c.resolution,1);field("offset",c.offset,0);
}
// These strings/credentials are needed only during startup. Keep their storage
// out of the worker's lifelong frame, including with size optimization enabled.
__attribute__((noinline)) bool loadDisableTorqueAfterMove(){
 ApplicationSettings application;loadApplicationSettings(application);
 return application.disableTorqueAfterMove;
}
void worker(void*) {
 Serial1.begin(1000000,SERIAL_8N1,18,19);
 ServoController servo(Serial1); CoverController controller(servo);
 EmergencyShutdown emergency;bool emergencyClosing=false;
 WebStatus s;EndpointObserver endpointObserver;
 auto loaded=loadCalibration(s.saved);
 // Preserve NVS and its diagnostic endpoints after a physical remount. Old
 // direction must be explicitly retaught, never silently swapped or reused.
 if(loaded==SettingsLoad::Loaded && !calibrationMatchesAssembly(s.saved))loaded=SettingsLoad::ReviewRequired;
 s.calibrated=loaded==SettingsLoad::Loaded;
 s.calibrationReview=loaded==SettingsLoad::ReviewRequired;
 s.draft=(s.calibrated||s.calibrationReview)?s.saved:Calibration{};
 if(s.calibrationReview){if(s.draft.referenceOffset!=kApplicationReferenceOffset)s.draft=Calibration{};s.draft.hasOpen=false;s.draft.openingDirection=0;s.draft.travelCounts=0;}
 snprintf(s.notice,sizeof(s.notice),"%s",s.calibrationReview?"Saved arc needs review; direction and safe path must be taught":s.calibrated?"Saved calibration loaded":loaded==SettingsLoad::Missing?"Capture and save both endpoints":"Stored calibration invalid or unavailable; recalibrate");
 vTaskDelay(pdMS_TO_TICKS(3000));
 uint16_t model=0,p=0,confirm=0;bool torque=true;
 MotionSettings config;config.disableTorqueAfterMove=loadDisableTorqueAfterMove();config.minimum=s.draft.minimum;config.maximum=s.draft.maximum;config.speed=s.draft.profile.jogSpeed;config.acceleration=s.draft.profile.acceleration;config.timeoutMs=s.draft.profile.timeoutMs;
 config.hasTravelArc=s.calibrated;config.arc=calibrationArc(s.draft);
 bool initialized=false,torqueTestRequested=false,rebootPrepared=false,rebootSucceeded=false;
 uint8_t unavailableSamples=0;
 const bool otaClosedStartup=closedOtaStartup;
 const bool inspectOnlyStartup=inspectOtaServoStartup;
 (void)inspectOnlyStartup; // Single-turn builds have no RAM startup preparation.
 const bool poweredStartup=poweredOtaStartup || otaClosedStartup || (esp_reset_reason()==ESP_RST_SW && retainedRebootMarker==0x48524f54);
 retainedRebootMarker=0;
 auto checkStartup=[&](){
  s.ready=false;s.manualReady=false;s.calibrationOnly=false;unavailableSamples=0;s.settingsOfflineAllowed=false;
  const char* reason=nullptr;
  ServoConfiguration observedConfiguration;ServoResult configurationResult;
  char configurationReason[sizeof(s.fault)]={};
#ifdef COVER_FIXED_REFERENCE
  if(!inspectOnlyStartup && !servo.prepareFixedReference())reason="Approved RAM reference unavailable; support cover, Stop, then Recheck";
  else
#endif
  if(!servo.readModel(model))reason="Servo not responding; check servo power and bus cable";
  else if(model!=777)reason="Unexpected servo model; ST3215 model 777 required";
#ifdef COVER_MULTITURN
  else if(inspectOnlyStartup && !servo.inspectMultiTurnStartup())
   reason="Update startup inspection failed; support cover and inspect servo diagnostics";
#endif
#ifdef COVER_MULTITURN_STARTUP
  else if(!inspectOnlyStartup && !servo.prepareMultiTurnStartup(s.referenceProbe))
   reason="RAM servo setup blocked; support cover and inspect servo diagnostics before retrying";
#endif
  else if(!(configurationResult=servo.validateConfiguration(observedConfiguration))){
   if(configurationResult.error==ServoError::InvalidConfiguration){
    describeConfigurationMismatch(configurationReason,sizeof(configurationReason),observedConfiguration);
    reason=configurationReason;
   }else reason="Cannot read ST3215 configuration; check servo communication";
  }
  else if(!servo.readTorque(torque))reason="Cannot read servo torque state; check servo communication";
  else if(torque && !poweredStartup)reason="Servo torque is ON; support cover, then Stop / release torque";
  else if(!servo.readPosition(p) || !servo.readPosition(confirm))reason="Cannot read servo position; check servo communication";
  else if(p>4095 || confirm>4095 || abs(encoderDelta(p,confirm))>3)reason="Invalid or unstable servo position; inspect mechanism";
#ifdef COVER_REFERENCE_PROBE
  else if(observedConfiguration.offset==1328){
   s.calibrated=false;s.calibrationReview=true;s.calibrationOnly=true;
   reason="Reference probe active; begin fresh calibration before movement";
  }
#endif
  else if(!s.calibrated){
   s.calibrationOnly=true;
   reason="Calibration missing/invalid; begin teaching on Calibration page";
   initialized=controller.initializeStationary(config,-1,-1,poweredStartup,true);
   if(!initialized){s.calibrationOnly=false;reason="Stationary startup validation failed; retry after inspection";}
  }else if(p<config.minimum || p>config.maximum || confirm<config.minimum || confirm>config.maximum ||
    (config.hasTravelArc && (!config.arc.endpointStartAllowed(p) || !config.arc.endpointStartAllowed(confirm)))){
   s.calibrationOnly=true;reason="Outside saved travel; use supervised Manual Control to return";
   initialized=controller.initializeStationary(config,s.saved.closed,s.saved.open,poweredStartup,true);
   if(!initialized){s.calibrationOnly=false;reason="Stationary startup validation failed; retry after inspection";}
  }
  else if(otaClosedStartup && (abs(encoderDelta(p,s.saved.closed))>kEndpointTolerance || abs(encoderDelta(confirm,s.saved.closed))>kEndpointTolerance))
   reason="OTA startup requires closed cover; inspect mechanism";
  else if(!controller.initializeStationary(config,s.saved.closed,s.saved.open,poweredStartup,true))reason="Stationary startup validation failed; retry after inspection";
  else if(otaClosedStartup && controller.state()!=State::Closed)reason="OTA startup closed position unconfirmed";
  else {s.ready=true;initialized=true;}
  s.manualReady=initialized && controller.state()!=State::Fault;
  if(reason)reason=servoFaultReason(servo.lastResult(),reason);
  snprintf(s.fault,sizeof(s.fault),"%s",reason?reason:"");
  if(reason && !s.calibrationOnly){
   noteRetainedFault(reason);
   portENTER_CRITICAL(&mux);
   ++supportShared.faultRevision;supportShared.startupFault=true;
   supportShared.heartbeatAgeMs=supportShared.heartbeatReceivedAt=supportShared.heartbeatProcessedAt=supportShared.heartbeatSequence=0;
   supportShared.fault.at=millis();supportShared.fault.traceAvailable=false;
   supportShared.fault.positionKnown=false;supportShared.fault.releaseConfirmed=false;
   supportShared.fault.elapsedMs=0;supportShared.fault.stateBefore=State::Unknown;
   supportShared.fault.consecutiveReadFailures=supportShared.fault.wrongSamples=supportShared.fault.limitSamples=0;
   snprintf(supportShared.fault.reason,sizeof(supportShared.fault.reason),"%s",reason);
   servo.copyDiagnostics(supportShared.fault.servo);
   portEXIT_CRITICAL(&mux);
  }
  diagnosticEvent("STARTUP CHECK ready=%d calibration_only=%d load=%d position=%u reason=%s",s.ready,s.calibrationOnly,int(loaded),p,s.fault);
 };
 checkStartup();
 diagnosticEvent("STARTUP ready=%d limits=%u..%u",s.ready,config.minimum,config.maximum);
 MaintenanceSnapshot loggedMaintenance;
 uint32_t maintenanceReadAt=0,maintenanceObserved=0;
 bool settingsStationaryConfirmed=false,settingsOfflineConfirmed=false;
 uint16_t settingsStationaryPosition=0;
 uint32_t beat=0,lastRead=0; uint32_t owner=0,motionStarted=0,lastTelemetry=0;
 bool requireStowed=false,manualStowClose=false;
 auto emergencyEvidence=[&](){
  ShutdownEvidence e;
  e.coverReady=s.ready&&controller.state()!=State::Fault;
  e.positionFresh=s.positionValid&&millis()-s.positionAt<1500;
  e.calibrationClean=s.calibrated&&!s.dirty;
  e.coverMoving=controller.moving();e.coverStationary=!controller.moving()&&!controller.holding();
  e.torqueOff=s.torqueValid&&!s.torque&&controller.torqueOffConfirmed();
  e.coverOpen=controller.state()==State::Open&&abs(encoderDelta(s.position,s.saved.open))<=kEndpointTolerance;
  e.coverClosed=controller.state()==State::Closed&&abs(encoderDelta(s.position,s.saved.closed))<=kEndpointTolerance;
  e.scope=alpacaStatus();e.native=shutdownNativeStatus();e.reply=shutdownNativeReply();return e;
 };
 auto supervise=[&]() {
  if(controller.moving() || controller.holding()) {
   if(controller.moving())s.motionMs=millis()-motionStarted;
   s.heartbeatAgeMs=millis()-beat;
   if(s.heartbeatAgeMs>s.maxHeartbeatGapMs)s.maxHeartbeatGapMs=s.heartbeatAgeMs;
  }
  const auto scope=alpacaStatus();
  const bool stowed=manualStowClose?!manualStowContradicted(scope,millis()):!requireStowed || scope.stowedCandidate(millis());
  if((requireStowed || manualStowClose) && controller.moving() && !stowed)
   snprintf(s.notice,sizeof(s.notice),"Telescope stow confirmation lost; stopping cover");
  bool cancelled;portENTER_CRITICAL(&mux);cancelled=emergencyCancelled;portEXIT_CRITICAL(&mux);
  const bool supervised=emergencyClosing?(!cancelled&&emergency.closePermitted(millis(),emergencyEvidence())):owner&&millis()-beat<500;
  const bool wasFault=controller.state()==State::Fault;
  controller.tick(supervised,stowed);
  if(!wasFault && controller.state()==State::Fault){
   s.heartbeatAtFault=s.heartbeatLast;s.heartbeatFaultAt=millis();s.heartbeatFaultAge=s.heartbeatAgeMs;
  }
  if(!controller.moving()){requireStowed=false;manualStowClose=false;}
 };
 State previousState=controller.state();uint32_t publishedFault=0;
 auto freezeFault=[&](){
  if(controller.faultSequence()==publishedFault)return;
  portENTER_CRITICAL(&mux);
  publishedFault=controller.faultSequence();++supportShared.faultRevision;supportShared.startupFault=false;
  controller.copyFault(supportShared.fault);
  if(supportShared.fault.traceAvailable)controller.copyTrace(supportShared.frozenTrace);
  supportShared.heartbeatAgeMs=s.heartbeatAgeMs;supportShared.heartbeatReceivedAt=s.heartbeatLast.received;
  supportShared.heartbeatProcessedAt=s.heartbeatLast.processed;supportShared.heartbeatSequence=s.heartbeatLast.sequence;
  portEXIT_CRITICAL(&mux);
 };
 for(;;) {
  noteMotionLoop();
  bool stop,startEmergency,finishEmergency,automatic;uint32_t stoppedGeneration;
  portENTER_CRITICAL(&mux);stop=stopRequested;stopRequested=false;startEmergency=emergencyStart;emergencyStart=false;
  automatic=stopAutomatic;stoppedGeneration=stopControlGeneration;
  finishEmergency=emergencyFinish;emergencyFinish=false;portEXIT_CRITICAL(&mux);
  if(stop) {diagnosticEvent("STOP automatic=%d generation=%lu",automatic,(unsigned long)stoppedGeneration);controller.stop();owner=0;emergency.cancel(millis());emergencyClosing=false;xQueueReset(commands);}
  bool reboot,retain;
  portENTER_CRITICAL(&mux);reboot=rebootRequested;retain=rebootRetain;portEXIT_CRITICAL(&mux);
  if(reboot && !rebootPrepared){
   rebootPrepared=true;
   if(!stop && controller.prepareReboot(retain)){rebootSucceeded=true;owner=0;xQueueReset(commands);}
   else debugLog(DebugLevel::Warn,"Manual reboot preparation failed or cancelled by Stop");
  }
  if(stop)rebootSucceeded=false;
  if(!reboot){rebootPrepared=false;rebootSucceeded=false;}
  if(startEmergency){
   bool cancelled;portENTER_CRITICAL(&mux);cancelled=emergencyCancelled;portEXIT_CRITICAL(&mux);
   if(cancelled||!emergency.start(millis(),emergencyEvidence())){
    emergency.fail(millis(),cancelled?"Shutdown cancelled before starting":"Shutdown preflight failed; inspect telescope and cover");
   }
  }
  if(finishEmergency)emergency.finish(millis(),emergencyEvidence());
  const auto beforeEmergency=emergency.status();
  emergency.tick(millis(),emergencyEvidence());
  if(emergency.status().phase==ShutdownPhase::Closing&&!emergencyClosing&&!emergencyEvidence().coverClosed){
   bool cancelled;portENTER_CRITICAL(&mux);cancelled=emergencyCancelled;portEXIT_CRITICAL(&mux);
   const auto& profile=s.saved.profile;
   if(!cancelled&&emergency.closePermitted(millis(),emergencyEvidence())&&controller.setMotionProfile(profile.closeSpeed,profile.acceleration,profile.timeoutMs)&&
      controller.moveEndpoint(s.saved.closed,false,true)){
    emergencyClosing=true;requireStowed=true;owner=0;beat=millis();motionStarted=millis();
    s.target=s.saved.closed;s.timeoutMs=profile.timeoutMs;s.motionMs=0;
   }else emergency.fail(millis(),"Cover rejected emergency closure; inspect mechanism");
  }
  if(emergencyClosing&&!emergency.status().active()){
   if(controller.moving())controller.tick(false,false);
   emergencyClosing=false;
  }
  s.shutdown=emergency.status();
  if(s.shutdown.phase!=beforeEmergency.phase||s.shutdown.recovering!=beforeEmergency.recovering||startEmergency||finishEmergency){
   diagnosticLog("EMERGENCY op=%lu phase=%s message=%s",(unsigned long)s.shutdown.operation,shutdownPhaseName(s.shutdown.phase),s.shutdown.message);
   snprintf(s.notice,sizeof(s.notice),"%s",s.shutdown.message);
  }
  if(s.shutdown.diagnostic.sequence!=beforeEmergency.diagnostic.sequence){
   const auto& d=s.shutdown.diagnostic;
   diagnosticLog("EMERGENCY issue op=%lu phase=%s source=%s request=%s error=%s code=%ld tx=%lu request_ms=%lu age_ms=%lu",
    (unsigned long)s.shutdown.operation,shutdownPhaseName(d.phase),d.source,d.detail.request,d.detail.error,(long)d.detail.code,
    (unsigned long)d.detail.transaction,(unsigned long)d.detail.elapsedMs,(unsigned long)d.sampleAgeMs);
  }
  portENTER_CRITICAL(&mux);if(!emergencyStart)emergencyReserved=s.shutdown.locked();portEXIT_CRITICAL(&mux);
  WebCommand cmd;
  // A stalled web server cannot delay this task's heartbeat enforcement.
  supervise();
  for(int n=0;n<8 && xQueueReceive(commands,&cmd,0)==pdTRUE;++n) {
   freezeFault(); // Preserve a fault before a queued Recover or new move can replace its trace.
   if(!(cmd.type==WebCommandType::Heartbeat?heartbeatRequestAllowed(cmd.controlGeneration):controlRequestAllowed(cmd.controlGeneration))){
    if(cmd.type!=WebCommandType::Heartbeat){s.commandId=cmd.sequence;s.commandClient=cmd.client;s.commandOk=false;
     snprintf(s.notice,sizeof(s.notice),"Command cancelled by maintenance or control generation change");}
    continue;
   }
   if(cmd.type==WebCommandType::Heartbeat){
    auto& h=s.heartbeatLast;h.client=cmd.client;h.sequence=cmd.sequence;h.received=cmd.received;h.processed=millis();h.previousAge=millis()-beat;
    h.renewed=millis()-cmd.received<400 && owner==cmd.client;
   }
   if(millis()-cmd.received>=400) {if(cmd.type!=WebCommandType::Heartbeat && cmd.sequence){s.commandId=cmd.sequence;s.commandClient=cmd.client;s.commandOk=false;snprintf(s.notice,sizeof(s.notice),"Command expired before execution; nothing started");}diagnosticEvent("COMMAND expired type=%d client=%lu seq=%lu age_ms=%lu",int(cmd.type),(unsigned long)cmd.client,(unsigned long)cmd.sequence,(unsigned long)(millis()-cmd.received));continue;}
   if(cmd.type==WebCommandType::Heartbeat) {
    diagnosticLog("HB WORK client=%lu seq=%lu queue_ms=%lu owner=%lu renew=%d prev_age_ms=%lu state=%s",
     (unsigned long)cmd.client,(unsigned long)cmd.sequence,(unsigned long)(millis()-cmd.received),(unsigned long)owner,owner==cmd.client,(unsigned long)(millis()-beat),stateName(controller.state()));
    if(owner==cmd.client) beat=cmd.received;
    continue;
   }
   s.commandId=cmd.sequence;s.commandClient=cmd.client;s.commandOk=false;
   snprintf(s.notice,sizeof(s.notice),"Command rejected: controller state changed; review status");
   bool blocked;
   portENTER_CRITICAL(&mux);blocked=!maintenance.commandsAllowed(cmd.controlGeneration)||emergencyReserved;portEXIT_CRITICAL(&mux);
   if(blocked)continue;
   diagnosticEvent("COMMAND type=%d client=%lu queue_age_ms=%lu",int(cmd.type),(unsigned long)cmd.client,(unsigned long)(millis()-cmd.received));
   if(s.settingsOfflineAllowed && cmd.type!=WebCommandType::Recover){
    snprintf(s.notice,sizeof(s.notice),"Servo unavailable; controller settings recovery only");continue;
   }
   if(cmd.type==WebCommandType::TorqueTest){
    if(controller.moving() || controller.holding())continue;
    torqueTestRequested=true;uint16_t id=0;owner=0;xQueueReset(commands);
    const bool ok=servo.readModel(id) && id==777 && controller.startTorqueTest();
    diagnosticEvent("TORQUE TEST started=%d position=%u max_ms=750",ok,controller.position());
    s.commandOk=ok;snprintf(s.notice,sizeof(s.notice),"%s",ok?"Supervised current-position torque test; automatic release within 750 ms":"Torque test rejected or failed; inspect diagnostics");
    continue;
   }
#ifdef COVER_REFERENCE_PROBE
   if(cmd.type==WebCommandType::ProbeReference || cmd.type==WebCommandType::RestoreReference){
    if(controller.moving() || controller.holding() ||
       (cmd.type==WebCommandType::ProbeReference && (!s.ready || !s.teaching || controller.state()==State::Fault)))continue;
#ifdef COVER_MULTITURN_PROBE
    const auto result=servo.probeLockedMultiTurn(cmd.type==WebCommandType::RestoreReference,s.referenceProbe);
#else
    const auto result=servo.probeLockedReference(cmd.type==WebCommandType::RestoreReference,s.referenceProbe);
#endif
    // A reference write invalidates all coordinates, even if acknowledgement or
    // readback failed. Preserve old evidence/NVS; never reinterpret endpoints.
    if(s.referenceProbe.writeAttempted){
     owner=0;beat=0;xQueueReset(commands);controller.invalidateReference();
     initialized=true;s.calibrated=false;s.calibrationReview=true;s.dirty=true;s.ready=false;
    }
    s.commandOk=bool(result);
    diagnosticEvent("REFERENCE PROBE restore=%d result=%u attempted=%d lock=%d before=%u after=%u",
     cmd.type==WebCommandType::RestoreReference,unsigned(result.error),s.referenceProbe.writeAttempted,
     s.referenceProbe.lockConfirmed,s.referenceProbe.positionBefore,s.referenceProbe.positionAfter);
#ifdef COVER_MULTITURN_PROBE
    snprintf(s.notice,sizeof(s.notice),"Multi-turn configuration %s; torque OFF; inspect before recovery",result?"verified":"rejected/failed");
#else
    snprintf(s.notice,sizeof(s.notice),"Reference probe %s; torque OFF; inspect evidence before any recovery",result?"verified":"rejected/failed");
#endif
    continue;
   }
#endif
   if(cmd.type==WebCommandType::Recover) {
    if(controller.moving() || controller.holding()) continue;
    if(!initialized){checkStartup();s.commandOk=s.ready||s.calibrationOnly;snprintf(s.notice,sizeof(s.notice),"%s",s.ready?"Startup checks passed; no movement":s.calibrationOnly?"Servo checks passed; calibrate before movement":s.fault);continue;}
    if(controller.state()!=State::Fault)continue;
    owner=0;beat=0;xQueueReset(commands);
    uint16_t recoveredModel=0;
    bool referenceReady=true;
#ifdef COVER_FIXED_REFERENCE
    referenceReady=bool(servo.prepareFixedReference());
#endif
    if(referenceReady && servo.readModel(recoveredModel) && recoveredModel==777 && controller.recover(true)) {
     s.ready=(controller.positionInRange() || (s.calibrated && calibrationArc(s.saved).endpointStartAllowed(controller.position()))) && (s.calibrated || s.teaching);s.manualReady=true;
     s.calibrationOnly=!s.ready;s.commandOk=true;s.fault[0]='\0';
     snprintf(s.notice,sizeof(s.notice),"Fault cleared; torque OFF. Inspect before requesting a new move.");
    } else {
     snprintf(s.notice,sizeof(s.notice),"%s",servoFaultReason(servo.lastResult(),"Recovery rejected: check communication, configuration, position and torque release"));
    }
    continue;
   }
   const bool startupLimits=((cmd.type==WebCommandType::SetLimits || cmd.type==WebCommandType::BeginTeaching) && (s.calibrationOnly || controller.state()==State::Fault || !s.ready)) ||
    (cmd.type==WebCommandType::SetProfile && controller.state()==State::Fault);
   const bool manual=cmd.type==WebCommandType::ManualJogPlus || cmd.type==WebCommandType::ManualJogMinus;
   if(((!s.ready && !(manual && s.manualReady)) || controller.state()==State::Fault) && !startupLimits)continue;
   if(controller.moving())continue;
   if(controller.holding() && (owner!=cmd.client || !cmd.retainTorque ||
      (cmd.type!=WebCommandType::JogPlus && cmd.type!=WebCommandType::JogMinus && cmd.type!=WebCommandType::ManualJogPlus && cmd.type!=WebCommandType::ManualJogMinus)))continue;
   if(cmd.type==WebCommandType::CaptureOpen || cmd.type==WebCommandType::CaptureClosed ||
      cmd.type==WebCommandType::SetLimits || cmd.type==WebCommandType::BeginTeaching || cmd.type==WebCommandType::SaveCalibration ||
      cmd.type==WebCommandType::SetProfile || cmd.type==WebCommandType::DiscardCalibration || cmd.type==WebCommandType::SetDirection) {
    bool enabled=true;uint16_t a=0,b=0;
    if(!servo.readTorque(enabled) || enabled || !servo.readPosition(a) || !servo.readPosition(b) || abs(encoderDelta(a,b))>3) {
     snprintf(s.notice,sizeof(s.notice),"Calibration rejected: need stable position and torque OFF");continue;
    }
    if(cmd.type==WebCommandType::SetLimits || cmd.type==WebCommandType::BeginTeaching) {
     if(cmd.type==WebCommandType::BeginTeaching){
      if(cmd.resumeTeaching && (!s.calibrated || s.draft.referenceOffset!=kApplicationReferenceOffset || !validCalibration(s.draft))){
       snprintf(s.notice,sizeof(s.notice),"Fine tune rejected: save valid calibration first");continue;
      }
      if(cmd.retainClosed && (!s.calibrated || s.saved.referenceOffset!=kApplicationReferenceOffset ||
         !calibrationArc(s.saved).contains(b) || abs(calibrationArc(s.saved).coordinate(b))>kEndpointTolerance)){
       snprintf(s.notice,sizeof(s.notice),"Keep CLOSED rejected: need verified saved calibration and stable CLOSED feedback");continue;
      }
      cmd.minimum=0;cmd.maximum=4095;
     }
     if(cmd.maximum>kAllowedMaximum || cmd.minimum>=cmd.maximum || b<cmd.minimum || b>cmd.maximum) {
      snprintf(s.notice,sizeof(s.notice),"Limits rejected: current position must be inside limits (0-4095)");continue;
     }
     uint16_t id=0;MotionSettings candidate=config;candidate.minimum=cmd.minimum;candidate.maximum=cmd.maximum;candidate.hasTravelArc=false;
     if(!servo.readModel(id) || id!=777 || !controller.applyStationarySettings(candidate)){
      snprintf(s.notice,sizeof(s.notice),"Range rejected: verify ST3215 configuration, stable position and torque OFF");continue;
     }
     config=candidate;initialized=true;s.ready=controller.state()!=State::Fault;s.calibrationOnly=false;
     if(s.ready)s.fault[0]='\0';
     if(cmd.type==WebCommandType::BeginTeaching){
      s.teaching=true;
      if(!cmd.resumeTeaching){s.draft.referenceOffset=kApplicationReferenceOffset;s.draft.circular=true;s.draft.hasClosed=s.draft.hasOpen=false;
      s.draft.travelCounts=0;s.draft.openingDirection=kAssemblyOpeningDirection;
      if(cmd.retainClosed){s.draft.closed=s.saved.closed;s.draft.hasClosed=true;}
      }
     }
     s.draft.minimum=cmd.minimum;s.draft.maximum=cmd.maximum;s.dirty=true;
     if(s.draft.closed<cmd.minimum || s.draft.closed>cmd.maximum)s.draft.hasClosed=false;
     if(s.draft.open<cmd.minimum || s.draft.open>cmd.maximum)s.draft.hasOpen=false;
     s.commandOk=true;snprintf(s.notice,sizeof(s.notice),"Teaching ready; supervised steps only. Capture CLOSED and OPEN, then review and save.");
    } else if(cmd.type==WebCommandType::SetDirection) {
     if(cmd.openingDirection!=1 && cmd.openingDirection!=-1)continue;
     // Explicit observed direction; application calibration only. Recapture OPEN
     // after changing it, never reinterpret the old endpoint through rollover.
     MotionSettings candidate=config;candidate.hasTravelArc=false;
     if(!controller.applyStationarySettings(candidate))continue;
     config=candidate;s.draft.openingDirection=cmd.openingDirection;
     s.draft.hasOpen=false;s.draft.travelCounts=0;s.dirty=true;s.commandOk=true;
     snprintf(s.notice,sizeof(s.notice),"Opening direction recorded; teach CLOSED zero, then OPEN along the safe path");
    } else if(cmd.type==WebCommandType::SetProfile) {
     if(!validMotionProfile(cmd.profile)){snprintf(s.notice,sizeof(s.notice),"Invalid motion profile; settings unchanged");continue;}
     if(!controller.setMotionProfile(cmd.profile.jogSpeed,cmd.profile.acceleration,cmd.profile.timeoutMs))continue;
     s.draft.profile=cmd.profile;s.dirty=true;s.commandOk=true;
     config.speed=cmd.profile.jogSpeed;config.acceleration=cmd.profile.acceleration;config.timeoutMs=cmd.profile.timeoutMs;
     snprintf(s.notice,sizeof(s.notice),"Movement profile applied to draft; save to retain changes");
    } else if(cmd.type==WebCommandType::DiscardCalibration) {
     Calibration restored;
     if(loadCalibration(restored)!=SettingsLoad::Loaded || !calibrationMatchesAssembly(restored) || b<restored.minimum || b>restored.maximum){
      snprintf(s.notice,sizeof(s.notice),"Discard rejected: need verified saved calibration containing current position");continue;
     }
     MotionSettings candidate=config;candidate.minimum=restored.minimum;candidate.maximum=restored.maximum;
     candidate.hasTravelArc=true;candidate.arc=calibrationArc(restored);
     candidate.speed=restored.profile.jogSpeed;candidate.acceleration=restored.profile.acceleration;candidate.timeoutMs=restored.profile.timeoutMs;
     if(!controller.applyStationarySettings(candidate,restored.closed,restored.open))continue;
     config=candidate;s.teaching=false;s.saved=s.draft=restored;s.calibrated=true;s.dirty=false;s.calibrationReview=false;s.commandOk=true;
     snprintf(s.notice,sizeof(s.notice),"Saved calibration restored; no movement");
    } else if(cmd.type==WebCommandType::SaveCalibration) {
     if(!validCalibration(s.draft) || !calibrationMatchesAssembly(s.draft) || !calibrationArc(s.draft).contains(b)) {
      snprintf(s.notice,sizeof(s.notice),"Save rejected: teach direction and distinct endpoints on a supported safe arc");continue;
     }
     if(!saveCalibration(s.draft)) {snprintf(s.notice,sizeof(s.notice),"Save failed; endpoints disabled until verified save");s.calibrated=false;continue;}
     config.minimum=s.draft.minimum;config.maximum=s.draft.maximum;config.hasTravelArc=true;config.arc=calibrationArc(s.draft);
     config.speed=s.draft.profile.jogSpeed;config.acceleration=s.draft.profile.acceleration;config.timeoutMs=s.draft.profile.timeoutMs;
     if(!controller.applyStationarySettings(config,s.draft.closed,s.draft.open)) {s.calibrated=false;snprintf(s.notice,sizeof(s.notice),"Saved but not applied; reset and inspect");continue;}
     s.teaching=false;s.saved=s.draft;s.calibrated=true;s.dirty=false;s.calibrationReview=false;s.commandOk=true;
     snprintf(s.notice,sizeof(s.notice),"Calibration saved and read back from NVS");
    } else {
     if(b<s.draft.minimum || b>s.draft.maximum) {snprintf(s.notice,sizeof(s.notice),"Capture rejected: position outside draft limits");continue;}
     Calibration captured=s.draft;
     // Current mounting opens with decreasing encoder counts.
     if(s.teaching)captured.openingDirection=kAssemblyOpeningDirection;
     if(cmd.type==WebCommandType::CaptureOpen && !captured.openingDirection){snprintf(s.notice,sizeof(s.notice),"Observe a small supervised move and establish opening direction first");continue;}
     if(cmd.type==WebCommandType::CaptureOpen){
      const int signedTravel=captured.openingDirection*(int(b)-int(captured.closed));
      const int travel=captured.circular?wrapPosition(signedTravel):signedTravel;
      if(!captured.hasClosed || travel<=2*kEndpointTolerance || travel>=2048 || (!captured.circular && !supportedDirectPath(captured.closed,b))){
       snprintf(s.notice,sizeof(s.notice),"OPEN rejected: follow the opening direction; supported travel is 21-2047 counts");continue;
      }
      captured.open=b;captured.hasOpen=true;captured.travelCounts=travel;
     }else{
      captured.closed=b;captured.hasClosed=true;
      if(captured.hasOpen){
       const int signedTravel=captured.openingDirection*(int(captured.open)-int(b));
       const int travel=captured.circular?wrapPosition(signedTravel):signedTravel;
       if(travel<=2*kEndpointTolerance || travel>=2048 || (!captured.circular && !supportedDirectPath(b,captured.open))){
        snprintf(s.notice,sizeof(s.notice),"CLOSED rejected: retained OPEN must form a 21-2047 count arc in the opening direction");continue;
       }
       captured.travelCounts=travel;
      }else captured.travelCounts=0;
     }
     MotionSettings candidate=config;candidate.hasTravelArc=false;
     if(!controller.applyStationarySettings(candidate))continue;
     config=candidate;s.draft=captured;
     s.dirty=true;s.commandOk=true;snprintf(s.notice,sizeof(s.notice),captured.hasOpen?"Endpoint updated; other position retained. Review and save.":"CLOSED captured; teach OPEN, then review and save.");
    }
    continue;
   }
   diagnosticEvent("MOVE request=%d last_position=%u position_valid=%d",int(cmd.type),s.position,s.positionValid);
   const bool manualStow=cmd.type==WebCommandType::CloseManualStow;
   const bool closing=cmd.type==WebCommandType::Close || cmd.type==WebCommandType::CloseStowed || manualStow;
   const auto telescope=alpacaStatus();
   const bool checkStow=closing && !manualStow && (cmd.type==WebCommandType::CloseStowed || telescope.enabled);
   if(manualStow && manualStowContradicted(telescope,millis())){
    snprintf(s.notice,sizeof(s.notice),"Override rejected: telescope reports unsafe state");continue;
   }
   if(checkStow && !telescope.stowedCandidate(millis())){
    snprintf(s.notice,sizeof(s.notice),"Close rejected: need fresh confirmed telescope stow");continue;
   }
   const bool jogging=manual || cmd.type==WebCommandType::JogPlus || cmd.type==WebCommandType::JogMinus;
   const auto& profile=jogging?s.draft.profile:s.saved.profile;
   const uint16_t speed=jogging?profile.jogSpeed:closing?profile.closeSpeed:profile.openSpeed;
   if(!controller.holding() && !controller.setMotionProfile(speed,profile.acceleration,profile.timeoutMs))continue;
   s.timeoutMs=profile.timeoutMs;
   const uint32_t previousOwner=owner;owner=cmd.client;beat=cmd.received;motionStarted=millis();
   bool accepted=false;
   if(manual)debugLog(DebugLevel::Error,"MANUAL jog client=%lu step=%u; saved range and telescope stow bypassed",(unsigned long)cmd.client,cmd.step);
   if(manual)
    accepted=(cmd.step==10 || cmd.step==100 || cmd.step==500) && controller.manualJog(cmd.type==WebCommandType::ManualJogPlus?cmd.step:-int(cmd.step),true,cmd.retainTorque);
   else if(jogging)
    accepted=(cmd.step==10 || cmd.step==100 || cmd.step==500) && controller.jog((cmd.type==WebCommandType::JogPlus || cmd.type==WebCommandType::ManualJogPlus)?cmd.step:-int(cmd.step),true,cmd.retainTorque);
   else if(s.calibrated && !s.dirty && (cmd.type==WebCommandType::Open || closing))
    accepted=controller.moveEndpoint(cmd.type==WebCommandType::Open?s.saved.open:s.saved.closed,cmd.type==WebCommandType::Open,true);
   if(!accepted){diagnosticEvent("MOVE rejected reason=%s",controller.fault());owner=controller.holding()?previousOwner:0;snprintf(s.notice,sizeof(s.notice),"%s",controller.state()==State::Fault?controller.fault():manual?"Manual step rejected: check servo, encoder boundary and faults":controller.moveRejection());}
   else {s.heartbeatFaultAt=s.heartbeatFaultAge=0;s.heartbeatAtFault=HeartbeatEvidence{};s.commandOk=true;requireStowed=checkStow;manualStowClose=manualStow;if(manualStow)diagnosticEvent("CLOSE manual stow override client=%lu",(unsigned long)cmd.client);s.target=controller.target();s.motionMs=0;s.heartbeatAgeMs=0;s.maxHeartbeatGapMs=0;diagnosticEvent("MOVE raw=%u->%u travel=%d->%d dir=%d speed_counts_s=%u timeout_ms=%lu",controller.position(),s.target,calibrationArc(s.draft).coordinate(controller.position()),calibrationArc(s.draft).coordinate(s.target),s.draft.openingDirection,speed,(unsigned long)profile.timeoutMs);snprintf(s.notice,sizeof(s.notice),"Movement accepted");}
  }
  supervise();
  freezeFault();
  // Secondary telemetry is conservative; never delay normal motion polling.
  if(controller.moving() || controller.holding())unavailableSamples=0;
  if((controller.torqueTesting() && millis()-lastTelemetry>=150) ||
     (!controller.moving() && !controller.holding() && millis()-lastTelemetry>=5000)){
   lastTelemetry=millis();ServoTelemetry telemetry;const auto result=servo.readTelemetry(telemetry);
   // Read back control registers only while idle, never from an HTTP handler
   // or during motion/holding. This cannot stage a goal or enable torque.
   if(!controller.moving() && !controller.holding()){ServoGoalReadback goal;servo.readGoal(goal);}
   if(!noServoReply(result))unavailableSamples=0;
   if(result){s.telemetryValid=true;s.telemetryAt=millis();s.voltageDecivolts=telemetry.voltageDecivolts;s.temperatureC=telemetry.temperatureC;s.relativeLoad=telemetry.relativeLoad;s.currentRaw=telemetry.currentRaw;}
   if(result)diagnosticLog("SERVO TELEMETRY test=%d pos=%u voltage_dV=%u temp_C=%u load_relative=%d current_raw=%d",controller.torqueTesting(),telemetry.position,telemetry.voltageDecivolts,telemetry.temperatureC,telemetry.relativeLoad,telemetry.currentRaw);
   else diagnosticLog("SERVO TELEMETRY failed error=%u device_status=0x%02x",unsigned(result.error),result.deviceStatus);
  }
  if(!controller.moving() && !controller.holding()) owner=0;
  EndpointChange ignoredChange;endpointObserver.observe(controller.state(),false,0,ignoredChange);
  if(!controller.moving() && millis()-lastRead>=500) {
   lastRead=millis();const auto positionResult=servo.readPosition(p);s.positionValid=static_cast<bool>(positionResult);
   if(s.positionValid){s.position=p;s.positionAt=millis();}
   EndpointChange endpointChange;
   if(endpointObserver.observe(controller.state(),s.positionValid,p,endpointChange))
    debugLog(DebugLevel::Error,"SERVO %s encoder changed %u -> %u (delta=%d counts); possible external movement or encoder variation",
     stateName(endpointChange.state),endpointChange.previous,endpointChange.position,int(endpointChange.position)-int(endpointChange.previous));
   const auto torqueResult=servo.readTorque(torque);s.torqueValid=static_cast<bool>(torqueResult);if(s.torqueValid)s.torque=torque;
   if(!controller.holding() && noServoReply(positionResult) && noServoReply(torqueResult)){
    if(unavailableSamples<3)++unavailableSamples;
   }else unavailableSamples=0;
  } else if(controller.moving()) {
   // The existing secondary read runs five times less often than position
   // supervision. Read its full feedback block to retain target/load/current
   // evidence during motion, without adding another bus transaction.
   if(millis()-lastRead>=250) {
    lastRead=millis();ServoTelemetry telemetry;
    s.positionValid=static_cast<bool>(servo.readTelemetry(telemetry));
    if(s.positionValid){
     s.position=telemetry.position;s.positionAt=millis();
     s.telemetryValid=true;s.telemetryAt=millis();s.voltageDecivolts=telemetry.voltageDecivolts;
     s.temperatureC=telemetry.temperatureC;s.relativeLoad=telemetry.relativeLoad;s.currentRaw=telemetry.currentRaw;
    }
   }
   s.torqueValid=false;
  }
  controller.copyTrace(s.motionTrace);
  s.moving=controller.moving();s.holding=controller.holding();s.owner=owner;
  s.settingsOfflineAllowed=unavailableSamples>=3 && uint32_t(millis()-lastRead)<=1000 &&
   !s.moving && !s.holding && !s.positionValid && !s.torqueValid;
  snprintf(s.state,sizeof(s.state),"%s",stateName(controller.state()));
  s.manualReady=initialized && controller.state()!=State::Fault;
  if(s.manualReady && s.calibrated && !s.teaching){
   s.ready=controller.positionInRange() || calibrationArc(s.saved).endpointStartAllowed(controller.position());s.calibrationOnly=!s.ready;
   snprintf(s.fault,sizeof(s.fault),"%s",s.ready?"":"Outside saved travel; use supervised Manual Control to return");
  }
  if((initialized || torqueTestRequested) && controller.state()==State::Fault) {if(s.ready)diagnosticLog("MOTION FAULT: %s target=%u elapsed_ms=%lu heartbeat_age_ms=%lu",controller.fault(),s.target,(unsigned long)s.motionMs,(unsigned long)s.heartbeatAgeMs);s.ready=false;s.calibrationOnly=false;snprintf(s.fault,sizeof(s.fault),"%s",controller.fault());}
  if(controller.state()==State::Fault && previousState!=State::Fault) {
   noteRetainedFault(controller.fault(),s.positionValid?s.position:UINT32_MAX,s.target);
   debugLog(DebugLevel::Error,"SERVO fault: %s",controller.fault());
   const auto& t=s.motionTrace;
   diagnosticLog("MOTION EVIDENCE op=%lu target=%u last_valid=%u error=%d tolerance=%u last_valid_ms=%lu valid_reads=%lu failed_reads=%lu settled=%u",
    (unsigned long)t.operation,t.target,t.lastPosition,int(t.lastPosition)-int(t.target),t.tolerance,
    (unsigned long)t.lastValidMs,(unsigned long)t.validReads,(unsigned long)t.failedReads,t.settled);
  }
  if(controller.state()!=previousState) {
   const State state=controller.state();
   if(state==State::Opening || state==State::Closing){
    debugLog(DebugLevel::Info,"Cover %s requested: target %u%% travel, raw=%u",state==State::Opening?"open":"close",state==State::Opening?100:0,controller.target());
   }else if(state==State::Open || state==State::Closed){
    const unsigned delta=unsigned(abs(encoderDelta(controller.target(),controller.position())));
    int travel=0;const auto arc=calibrationArc(s.saved);
    if(arc.progress(controller.position(),travel))
     debugLog(DebugLevel::Info,"Cover %s encoder band: travel=%d%% raw=%u error=%u",state==State::Open?"open":"close",100*travel/arc.length,controller.position(),delta);
    else debugLog(DebugLevel::Info,"Cover %s encoder band: travel unavailable, raw=%u error=%u",state==State::Open?"open":"close",controller.position(),delta);
   }else{
    debugLog(state==State::Fault?DebugLevel::Error:DebugLevel::Info,"Cover state %s -> %s position=%u target=%u",stateName(previousState),s.state,s.position,s.target);
   }
   diagnosticLog("STATE %s -> %s position=%u target=%u elapsed_ms=%lu heartbeat_ms=%lu max_heartbeat_ms=%lu torque_off_confirmed=%d",
    stateName(previousState),s.state,controller.position(),s.target,(unsigned long)s.motionMs,(unsigned long)s.heartbeatAgeMs,(unsigned long)s.maxHeartbeatGapMs,controller.torqueOffConfirmed());
   previousState=controller.state();
  }
  auto lease=maintenanceStatus();
  if(lease.locked()){
   bool safe=!controller.moving() && !controller.holding() &&
    s.torqueValid && (reboot && retain?s.torque && controller.state()==State::Retained:!s.torque);
   safe=safe && (!reboot || rebootSucceeded);
   if(lease.lease.owner==MaintenanceOwner::Network){
    if(maintenanceObserved!=lease.lease.generation || uint32_t(millis()-maintenanceReadAt)>=500){
     const bool newLease=maintenanceObserved!=lease.lease.generation;
     maintenanceObserved=lease.lease.generation;maintenanceReadAt=millis();
     uint16_t position=0;
     settingsStationaryConfirmed=validateSettingsStationary(servo,controller.moving(),controller.holding(),&position);
     if(newLease)settingsStationaryPosition=position;
     else if(abs(encoderDelta(settingsStationaryPosition,position))>3)settingsStationaryConfirmed=false;
     settingsOfflineConfirmed=false;
     if(s.settingsOfflineAllowed){
      uint16_t observedModel=0;
      settingsOfflineConfirmed=noServoReply(servo.readModel(observedModel));
      if(!settingsOfflineConfirmed){unavailableSamples=0;s.settingsOfflineAllowed=false;}
     }
    }
    safe=!controller.moving() && !controller.holding() &&
     ((settingsOfflineConfirmed && s.settingsOfflineAllowed) || settingsStationaryConfirmed);
   }
   if(lease.lease.owner==MaintenanceOwner::Ota){
    if(lease.phase==MaintenancePhase::Ready && uint32_t(millis()-lease.validatedAt)>1500){
     portENTER_CRITICAL(&mux);if(maintenance.matches(lease.lease))maintenance.revoke(MaintenanceReason::Timeout);portEXIT_CRITICAL(&mux);
    }
    if(maintenanceObserved!=lease.lease.generation || uint32_t(millis()-maintenanceReadAt)>=500){
     maintenanceObserved=lease.lease.generation;maintenanceReadAt=millis();
     MaintenanceEvidence evidence;evidence.ready=s.ready;evidence.calibrated=s.calibrated;evidence.dirty=s.dirty;
     evidence.moving=controller.moving();evidence.holding=controller.holding();evidence.fault=controller.state()==State::Fault;
     evidence.closed=controller.state()==State::Closed;evidence.closedPosition=s.saved.closed;evidence.minimum=config.minimum;evidence.maximum=config.maximum;
     OtaMaintenanceRequirements requirements;bool sta;
     portENTER_CRITICAL(&mux);requirements=otaRequirements;sta=maintenanceStaOnly;portEXIT_CRITICAL(&mux);
     const bool physicallySafe=otaOperatorSecuredPolicy(requirements)?(!evidence.moving && !evidence.holding):
      (validateOtaStationary(servo,evidence,true,requirements.closedCover,requirements.recovery) ||
      (lease.releaseRequested && validateOtaStationary(servo,evidence,false,requirements.closedCover,requirements.recovery)));
     multi_heap_info_t heap{};heap_caps_get_info(&heap,MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT);
     safe=physicallySafe && sta && otaPositionPolicyAllowed(requirements) && requirements.startupAccepted && debugLogAvailable() &&
      requirements.minimumInternalHeap && requirements.minimumLargestBlock &&
      heap.total_free_bytes>=requirements.minimumInternalHeap && heap.largest_free_block>=requirements.minimumLargestBlock;
     if(!safe && lease.phase!=MaintenancePhase::Revoked && !lease.releaseRequested)
      diagnosticLog("OTA clearance revoked physical=%d sta=%d internal_heap=%u required_heap=%lu largest_block=%u required_block=%lu",
       physicallySafe,sta,unsigned(heap.total_free_bytes),(unsigned long)requirements.minimumInternalHeap,
       unsigned(heap.largest_free_block),(unsigned long)requirements.minimumLargestBlock);
     portENTER_CRITICAL(&mux);
     if(maintenance.matches(lease.lease)){
      if(lease.releaseRequested)maintenance.finish(lease.lease,physicallySafe);
      else if(!safe)maintenance.revoke(!physicallySafe?MaintenanceReason::Servo:!sta?MaintenanceReason::Network:MaintenanceReason::Preconditions);
      else if(!stopRequested){
       if(maintenance.acknowledge(lease.lease,millis()))xQueueReset(commands);
       else maintenance.validate(lease.lease,millis());
      }
     }
     portEXIT_CRITICAL(&mux);
    }
   }else{
    portENTER_CRITICAL(&mux);
    if(maintenance.matches(lease.lease)){
     if(lease.releaseRequested){maintenance.finish(lease.lease,true);rebootRequested=false;rebootRetain=false;}
     else if(!stopRequested && safe && maintenance.acknowledge(lease.lease,millis()))xQueueReset(commands);
     else if(lease.phase==MaintenancePhase::Ready && !safe)maintenance.revoke(MaintenanceReason::Servo);
    }
    portEXIT_CRITICAL(&mux);
   }
   const auto after=maintenanceStatus();
   if(after.phase==MaintenancePhase::Pending && uint32_t(millis()-after.requestedAt)>3000){
    portENTER_CRITICAL(&mux);if(maintenance.matches(after.lease))maintenance.revoke(MaintenanceReason::Timeout);portEXIT_CRITICAL(&mux);
   }
  }
  const auto currentMaintenance=maintenanceStatus();
  if(currentMaintenance.phase!=loggedMaintenance.phase || currentMaintenance.reason!=loggedMaintenance.reason ||
     (!sameLease(currentMaintenance.lease,loggedMaintenance.lease) && (currentMaintenance.locked() || loggedMaintenance.locked()))){
   const auto identity=currentMaintenance.locked()?currentMaintenance.lease:loggedMaintenance.lease;
   diagnosticEvent("MAINT owner=%s generation=%lu phase=%s reason=%s",maintenanceOwnerName(identity.owner),
    (unsigned long)identity.generation,maintenancePhaseName(currentMaintenance.phase),maintenanceReasonName(currentMaintenance.reason));
   loggedMaintenance=currentMaintenance;
  }
  s.rolloverSupported=servo.rolloverSupported();s.jogStepLimit=servo.maximumJogStep();s.activeMinimum=config.minimum;s.activeMaximum=config.maximum;
  portENTER_CRITICAL(&mux);
  servo.copyDiagnostics(supportShared.current);supportShared.sampledAt=millis();supportShared.available=true;
  portEXIT_CRITICAL(&mux);
  publish(s);vTaskDelay(pdMS_TO_TICKS(5));
 }
}
}
MaintenanceSnapshot maintenanceStatus(){portENTER_CRITICAL(&mux);const auto value=maintenance.snapshot();portEXIT_CRITICAL(&mux);return value;}
void beginStartupValidation(bool discardRetainedTorque,bool requireClosed,bool allowPowered,bool inspectServoOnly){closedOtaStartup=requireClosed;poweredOtaStartup=allowPowered;inspectOtaServoStartup=inspectServoOnly;portENTER_CRITICAL(&mux);startupAccepted=false;if(discardRetainedTorque)retainedRebootMarker=0;portEXIT_CRITICAL(&mux);}
void finishStartupValidation(bool accepted){portENTER_CRITICAL(&mux);startupAccepted=accepted;portEXIT_CRITICAL(&mux);}
bool controlRequestAllowed(uint32_t generation){portENTER_CRITICAL(&mux);const bool ok=startupAccepted && maintenance.commandsAllowed(generation);portEXIT_CRITICAL(&mux);return ok;}
bool heartbeatRequestAllowed(uint32_t generation){portENTER_CRITICAL(&mux);const bool ok=startupAccepted && !stopRequested && maintenance.heartbeatsAllowed(generation);portEXIT_CRITICAL(&mux);return ok;}
MaintenanceLease requestNetworkMaintenance(uint32_t generation){
 portENTER_CRITICAL(&mux);MaintenanceLease lease;
 if(startupAccepted && !emergencyReserved && !stopRequested && !shared.moving && !shared.holding){
  lease=maintenance.reserve(MaintenanceOwner::Network,millis(),generation);
 }
 portEXIT_CRITICAL(&mux);return lease;
}
void markRetainedReboot(bool retainTorque){retainedRebootMarker=retainTorque?0x48524f54:0;}
MaintenanceLease requestRebootMaintenance(bool retainTorque,uint32_t client,uint32_t generation){
 portENTER_CRITICAL(&mux);MaintenanceLease lease;
 if(startupAccepted && !emergencyReserved && !stopRequested && !shared.moving && shared.ready && (!shared.holding || shared.owner==client)){
  lease=maintenance.reserve(MaintenanceOwner::Reboot,millis(),generation);
  if(lease){rebootRequested=true;rebootRetain=retainTorque;}
 }
 portEXIT_CRITICAL(&mux);return lease;
}
bool maintenanceReady(MaintenanceLease lease){
 portENTER_CRITICAL(&mux);const auto status=maintenance.snapshot();
 const bool ready=maintenance.ready(lease) && !stopRequested && (lease.owner!=MaintenanceOwner::Ota ||
  (maintenanceStaOnly && uint32_t(millis()-status.validatedAt)<=1500));
 portEXIT_CRITICAL(&mux);return ready;
}
bool requestMaintenanceRelease(MaintenanceLease lease){
 portENTER_CRITICAL(&mux);const bool accepted=maintenance.requestRelease(lease);portEXIT_CRITICAL(&mux);return accepted;
}
bool networkMaintenanceReady(MaintenanceLease lease){return lease.owner!=MaintenanceOwner::Ota && maintenanceReady(lease);}
bool endNetworkMaintenance(MaintenanceLease lease){return lease.owner!=MaintenanceOwner::Ota && requestMaintenanceRelease(lease);}
MaintenanceLease requestOtaMaintenance(const OtaMaintenanceRequirements& requirements,uint32_t generation){
 const bool operationActive=telescopeArmStatus().locked || alpacaStowStatus().active();
 portENTER_CRITICAL(&mux);MaintenanceLease lease;
 if(startupAccepted && !operationActive && !stopRequested && !emergencyReserved && maintenanceStaOnly && otaPositionPolicyAllowed(requirements) && requirements.startupAccepted &&
    requirements.minimumInternalHeap && requirements.minimumLargestBlock &&
    (otaOperatorSecuredPolicy(requirements) ||
     ((requirements.recovery?!shared.torque:(shared.ready && shared.calibrated && !shared.dirty)) &&
      shared.torqueValid && (!requirements.closedCover || !strcmp(shared.state,"CLOSED")))) &&
    !shared.moving && !shared.holding){
  lease=maintenance.reserve(MaintenanceOwner::Ota,millis(),generation,maintenanceWorkers);
  if(lease)otaRequirements=requirements;
 }
 portEXIT_CRITICAL(&mux);return lease;
}
bool confirmMaintenanceCleanup(MaintenanceLease lease){portENTER_CRITICAL(&mux);const bool ok=lease.owner==MaintenanceOwner::Ota && maintenance.cleanup(lease);portEXIT_CRITICAL(&mux);return ok;}
bool beginOtaCommit(MaintenanceLease lease){
 portENTER_CRITICAL(&mux);const auto snapshot=maintenance.snapshot();
 const bool ok=!stopRequested && maintenanceStaOnly && uint32_t(millis()-snapshot.validatedAt)<=1500 && maintenance.beginCommit(lease);
 portEXIT_CRITICAL(&mux);return ok;
}
void noteMaintenanceNetwork(bool staOnly){
 portENTER_CRITICAL(&mux);maintenanceStaOnly=staOnly;
 if(!staOnly && maintenance.snapshot().lease.owner==MaintenanceOwner::Ota)maintenance.revoke(MaintenanceReason::Network);
 portEXIT_CRITICAL(&mux);
}
bool maintenanceMayExposeAp(){portENTER_CRITICAL(&mux);const bool ok=maintenance.mayExposeAp();portEXIT_CRITICAL(&mux);return ok;}
void registerMaintenanceWorker(uint8_t worker,bool running){
 portENTER_CRITICAL(&mux);
 if(running){maintenanceWorkers|=worker;if(maintenance.snapshot().lease.owner==MaintenanceOwner::Ota)maintenance.revoke(MaintenanceReason::Worker);}
 else{maintenanceWorkers&=~worker;maintenance.pause(maintenance.snapshot().lease,worker);}
 portEXIT_CRITICAL(&mux);
}
MaintenanceLease otaMaintenanceForWorker(){auto status=maintenanceStatus();return status.lease.owner==MaintenanceOwner::Ota?status.lease:MaintenanceLease{};}
void acknowledgeMaintenancePause(MaintenanceLease lease,uint8_t worker){portENTER_CRITICAL(&mux);maintenance.pause(lease,worker);portEXIT_CRITICAL(&mux);}
bool requestEmergencyShutdown(uint32_t expectedStopEpoch){
 portENTER_CRITICAL(&mux);
 const bool ok=startupAccepted&&expectedStopEpoch==stopEpoch&&!emergencyReserved&&!maintenance.snapshot().locked()&&!shared.moving&&!shared.holding&&shared.ready&&shared.calibrated&&!shared.dirty;
 if(ok){emergencyReserved=true;emergencyStart=true;emergencyCancelled=false;}
 portEXIT_CRITICAL(&mux);return ok;
}
uint32_t emergencyStopEpoch(){portENTER_CRITICAL(&mux);const uint32_t epoch=stopEpoch;portEXIT_CRITICAL(&mux);return epoch;}
bool requestEmergencyInspection(){
 portENTER_CRITICAL(&mux);const bool ok=emergencyReserved&&!emergencyStart&&!shared.shutdown.active();
 if(ok){emergencyFinish=true;}
 portEXIT_CRITICAL(&mux);return ok;
}
bool emergencyShutdownLocked(){portENTER_CRITICAL(&mux);const bool locked=emergencyReserved;portEXIT_CRITICAL(&mux);return locked;}
bool emergencyWorkPermitted(uint32_t operation,ShutdownAction action){
 portENTER_CRITICAL(&mux);
 const bool ok=emergencyReserved&&!emergencyCancelled&&shared.shutdown.active()&&shared.shutdown.operation==operation&&shared.shutdown.action()==action&&
  (action==ShutdownAction::StopCapture||!shared.shutdown.recovering);
 portEXIT_CRITICAL(&mux);return ok;
}
void beginWebControl() {
 supportShared=ServoSupportSnapshot{};
 commands=xQueueCreate(8,sizeof(WebCommand));
 if(!commands || xTaskCreatePinnedToCore(worker,"cover",6144,nullptr,2,nullptr,1)!=pdPASS) {
  noteRetainedFault("Cover task or queue allocation failed");
  diagnosticEvent(DebugLevel::Error,"ALLOC cover task/queue unavailable");
  WebStatus s;snprintf(s.fault,sizeof(s.fault),"Motion task unavailable");publish(s);
 }
}
bool requestStop(uint32_t client,bool automatic,uint32_t observedGeneration){
 portENTER_CRITICAL(&mux);
 const bool ok=commands && (!automatic || !shared.owner || shared.owner==client) && maintenance.stop(automatic,observedGeneration);
 if(ok){++stopEpoch;stopRequested=true;stopAutomatic=automatic;stopControlGeneration=observedGeneration;if(emergencyReserved)emergencyCancelled=true;}
 portEXIT_CRITICAL(&mux);return ok;
}
bool submitAutomaticStop(uint32_t client,uint32_t observedGeneration){return requestStop(client,true,observedGeneration);}
bool submitWebCommand(WebCommandType type,uint32_t client,uint16_t minimum,uint16_t maximum,uint32_t sequence,bool retainTorque,uint16_t step,const MotionProfile& profile,uint32_t generation,int8_t openingDirection,bool retainClosed,bool resumeTeaching){
 if(type==WebCommandType::Stop)return requestStop(client,false,0);
 WebCommand cmd;cmd.type=type;cmd.client=client;cmd.received=millis();cmd.sequence=sequence;cmd.controlGeneration=generation;
 cmd.retainTorque=retainTorque;cmd.minimum=minimum;cmd.maximum=maximum;cmd.step=step;cmd.profile=profile;cmd.openingDirection=openingDirection;cmd.retainClosed=retainClosed;cmd.resumeTeaching=resumeTeaching;
 portENTER_CRITICAL(&mux);
 const bool allowed=type==WebCommandType::Heartbeat?maintenance.heartbeatsAllowed(generation):maintenance.commandsAllowed(generation);
 const bool ok=commands && startupAccepted && !stopRequested && allowed && xQueueSend(commands,&cmd,0)==pdTRUE;
 portEXIT_CRITICAL(&mux);return ok;
}
WebStatus webStatus(){portENTER_CRITICAL(&mux);WebStatus s=shared;portEXIT_CRITICAL(&mux);return s;}
void copyServoSupport(ServoSupportSnapshot& output){portENTER_CRITICAL(&mux);output=supportShared;portEXIT_CRITICAL(&mux);}
}
#endif
