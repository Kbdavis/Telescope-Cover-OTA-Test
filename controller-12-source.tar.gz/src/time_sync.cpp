#ifdef COVER_WEB_CONTROL
#include "time_sync.h"
#include "settings.h"
#include <Arduino.h>
#include <esp_sntp.h>
#include <atomic>
namespace cover {
namespace {
std::atomic<uint32_t> syncedAt{0};
bool enabled=false,started=false;
// SNTP retains the server pointer. Keep this storage alive for the entire boot.
char server[64]={},zone[64]={};
void synchronized(struct timeval* value){
 if(value && value->tv_sec>=1704067200 && uint64_t(value->tv_sec)<=UINT32_MAX)
  syncedAt.store(uint32_t(value->tv_sec));
}
}
void beginTimeSync(const ApplicationSettings& settings){
 enabled=settings.ntpEnabled;
 memcpy(server,settings.ntpServer,sizeof(server));memcpy(zone,settings.timeZone,sizeof(zone));
 // Called once at startup. The timezone stays immutable until settings restart.
 setenv("TZ",zone,1);tzset();
}
void pollTimeSync(bool connected){
 if(!enabled || started || !connected)return;
 sntp_set_time_sync_notification_cb(synchronized);
 // The framework starts lwIP's asynchronous DNS/UDP SNTP client. No
 // getLocalTime(), delay(), DNS lookup, or wait-for-sync loop here.
 configTzTime(zone,server);
 started=true;
}
uint32_t lastTimeSync(){return syncedAt.load();}
uint32_t logEpochSeconds(){
 if(!lastTimeSync())return 0;
 const time_t now=time(nullptr);
 return now>=1704067200 && uint64_t(now)<=UINT32_MAX?uint32_t(now):0;
}
}
#endif
