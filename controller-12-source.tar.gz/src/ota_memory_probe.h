#pragma once
#include <stdint.h>
namespace cover {
enum class OtaMemoryStage : uint8_t {
 RequestArena, RequestReleased, StatusStart, StatusBuilt, StatusSent,
 TcpConnected, BeginBefore, BeginAfter, WriteBefore, WriteAfter, EndBefore, EndAfter, Count
};
constexpr unsigned kOtaMemoryStages=static_cast<unsigned>(OtaMemoryStage::Count);
struct OtaMemoryRow {
 uint32_t count=0,minimumFree=0,minimumBlock=0,at=0,maximumBytes=0;
};
// Caller serializes updates. Values are boundary observations, not allocator
// tracing or proof that a specific operation caused the lowest heap reading.
struct OtaMemoryEvidence {
 uint32_t epoch=0;
 OtaMemoryRow rows[2][kOtaMemoryStages]; // idle / active OTA ownership
 bool record(uint32_t observedEpoch,uint32_t currentEpoch,OtaMemoryStage stage,bool active,
             uint32_t free,uint32_t block,uint32_t at,uint32_t bytes){
  const unsigned index=static_cast<unsigned>(stage);
  if(!observedEpoch || observedEpoch!=currentEpoch || index>=kOtaMemoryStages)return false;
  if(epoch!=observedEpoch){*this=OtaMemoryEvidence{};epoch=observedEpoch;}
  auto& row=rows[active?1:0][index];
  if(!row.count || free<row.minimumFree){row.minimumFree=free;row.at=at;}
  if(!row.count || block<row.minimumBlock)row.minimumBlock=block;
  if(row.count<UINT32_MAX)++row.count;
  if(bytes>row.maximumBytes)row.maximumBytes=bytes;
  return true;
 }
};
static_assert(sizeof(OtaMemoryEvidence)==484,"Keep test recorder storage fixed");
#ifdef COVER_OTA_MEMORY_PROBE
#ifndef COVER_OTA_FLASH_PROBE
#error Memory experiment requires the nonactivating flash profile
#endif
void otaMemoryBoundary(OtaMemoryStage stage,uint32_t bytes=0);
void otaMemoryTransfer(bool active);
void otaMemoryFinish();
bool otaMemorySnapshot(OtaMemoryEvidence& out);
#else
inline void otaMemoryBoundary(OtaMemoryStage,uint32_t=0){}
inline void otaMemoryTransfer(bool){}
inline void otaMemoryFinish(){}
#endif
}
