#ifdef COVER_SERVO_DIAGNOSTIC
#ifndef COVER_SERVO_READ_ONLY
#error Diagnostic firmware requires the read-only driver guard
#endif
#include <Arduino.h>
#include <string.h>
#include "servo_controller.h"
#include "servo_diagnostic.h"

namespace cover {
namespace {
constexpr int kRx = 18, kTx = 19;
constexpr uint32_t kBusBaud = 1000000;
ServoController servo(Serial1);
uint32_t started = 0, lastPoll = 0;
unsigned samples = 0, failures = 0;
uint16_t minimum = 4095, maximum = 0;
bool initialized = false, finished = false;

bool report(const char* operation, ServoResult result) {
  if (!result) {
    ++failures;
    Serial.printf("FAIL %s error=%u status=0x%02x retries=%lu\n", operation,
                  static_cast<unsigned>(result.error), result.deviceStatus,
                  static_cast<unsigned long>(servo.retryCount()));
  }
  return static_cast<bool>(result);
}
bool inspect() {
  if (!report("ping", servo.ping())) return false;
  uint16_t model;
  if (!report("model", servo.readModel(model))) return false;
  Serial.printf("Servo ID=1 model=%u\n", model);
  if (model != 777) {
    ++failures;
    Serial.println("FAIL unexpected model; diagnostics halted");
    return false;
  }
  ServoConfiguration c;
  if (!report("configuration", servo.readConfiguration(c))) return false;
  Serial.printf("CONFIG id=%u mode=%u min=%u max=%u phase=%u resolution=%u offset=%u\n",
                c.id, c.mode, c.minimum, c.maximum, c.phase, c.resolution, c.offset);
  if (!report("validation", servo.validateConfiguration())) return false;
  bool torque;
  if (!report("torque", servo.readTorque(torque))) return false;
  Serial.printf("CONFIG PASS torque=%s (unchanged)\n", torque ? "ON" : "OFF");
  return true;
}
#ifdef COVER_SERVO_BACKUP
bool backup() {
  uint16_t model=0;bool torque=true;
  if(!report("backup model",servo.readModel(model)) || model!=777 ||
     !report("backup torque",servo.readTorque(torque)) || torque) {
    Serial.println("BACKUP FAIL expected model 777 and torque OFF");return false;
  }
  uint8_t baseline[40]={};
  for(unsigned pass=1;pass<=3;++pass){
    uint8_t bytes[40];
    if(!report("backup snapshot",servo.readConfigurationSnapshot(bytes)))return false;
    if(bytes[3]!=9 || bytes[4]!=3 || bytes[5]!=1){
      Serial.println("BACKUP FAIL snapshot identity mismatch");return false;
    }
    if(pass==1)memcpy(baseline,bytes,sizeof(bytes));
    else if(memcmp(baseline,bytes,sizeof(bytes))){
      Serial.println("BACKUP FAIL repeated snapshots differ");return false;
    }
    Serial.printf("BACKUP DATA pass=%u start=0 count=40 hex=",pass);
    for(uint8_t byte:bytes)Serial.printf("%02x",byte);
    Serial.println();
  }
  if(!report("backup final torque",servo.readTorque(torque)) || torque)return false;
  Serial.printf("BACKUP VERIFIED passes=3 model=777 id=1 torque=0 retries=%lu\n",
                static_cast<unsigned long>(servo.retryCount()));
  return true;
}
#endif
}

void beginServoDiagnostic() {
  Serial1.begin(kBusBaud, SERIAL_8N1, kRx, kTx);
  started = millis();
  Serial.println("Telescope Cover: READ-ONLY SERVO DIAGNOSTIC v1");
  Serial.println("UART1 RX=18 TX=19 baud=1000000; USB=115200; state=UNKNOWN");
  Serial.println("No motion, torque changes, EEPROM writes, web server, or USB forwarding.");
}

void pollServoDiagnostic() {
  if (finished) return;
  const uint32_t now = millis();
  if (!initialized) {
    if (now - started < 3000) return;
    initialized = true;
#ifdef COVER_SERVO_BACKUP
    if(!backup())Serial.println("BACKUP FAILED; no servo writes performed");
    finished=true;return;
#endif
    if (!inspect()) { finished = true; return; }
    lastPoll = millis();
    return;
  }
  if (now - lastPoll < 1000) return;
  lastPoll = now;
  ++samples;
  uint16_t position;
  if (report("position", servo.readPosition(position))) {
    if (position < minimum) minimum = position;
    if (position > maximum) maximum = position;
    Serial.printf("POSITION sample=%u counts=%u retries=%lu\n", samples, position,
                  static_cast<unsigned long>(servo.retryCount()));
  }
  if (samples % 5 == 0) {
    ServoTelemetry t;
    if (report("telemetry", servo.readTelemetry(t))) {
      Serial.printf("TELEMETRY pos=%u speed_raw=%d load_relative=%d current_raw=%d voltage=%.1fV temp=%uC moving=%u\n",
                    t.position, t.speedRaw, t.relativeLoad, t.currentRaw,
                    t.voltageDecivolts / 10.0, t.temperatureC, t.moving);
    }
  }
  if (samples == 60) {
    report("final configuration validation", servo.validateConfiguration());
    Serial.printf("DONE position_attempts=%u min=%u max=%u failed_operations=%u retries=%lu; polling stopped\n",
                  samples, minimum, maximum, failures,
                  static_cast<unsigned long>(servo.retryCount()));
    finished = true;
  }
}
}  // namespace cover
#endif
