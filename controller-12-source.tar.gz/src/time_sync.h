#pragma once
#include <stdint.h>
#include <stddef.h>
#include <time.h>
#include <string.h>
namespace cover {
struct ApplicationSettings;
// Web/network task only; never waits for DNS, a packet, or synchronization.
void beginTimeSync(const ApplicationSettings& settings);
void pollTimeSync(bool connected);
uint32_t lastTimeSync();
// Event publishers take a numeric snapshot; zero explicitly means unsynchronized.
uint32_t logEpochSeconds();
constexpr size_t kLocalTimestampSize=32;
inline void formatLocalTimestamp(uint32_t epoch,char* output,size_t size){
 if(!size)return;
 output[0]=0;if(!epoch)return;
 const time_t seconds=epoch;struct tm local{};
 if(!localtime_r(&seconds,&local) || !strftime(output,size,"%Y-%m-%dT%H:%M:%S%z",&local))output[0]=0;
}
}
