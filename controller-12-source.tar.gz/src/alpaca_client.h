#pragma once
#include <stdint.h>
namespace cover {
namespace alpaca {
enum class Property { Connected, CanFindHome, AtHome, Slewing, Tracking, Altitude, Azimuth };
enum class Metric { CameraConnected, CameraState, CameraTemperature, HeaterConnected, HeaterCount, HeaterIdentity, HeaterState };
enum class Auxiliary { Camera, Heater };
enum class Error { None, Offline, Timeout, Http, Oversized, Protocol, Unsupported, Driver };
struct Reply { Error error=Error::None; bool value=false; int32_t driverError=0; uint32_t elapsedMs=0; double number=0; };
struct Failure {
 Failure(const char* name="none",uint32_t tx=0,uint32_t elapsed=0,uint32_t when=0):request(name),transaction(tx),elapsedMs(elapsed),at(when){}
 const char* request="none";
 uint32_t transaction=0,elapsedMs=0,at=0;
};
class Transport {
 public:
 virtual ~Transport()=default;
 virtual Reply get(Property property,uint32_t transaction)=0;
 virtual Reply findHome(uint32_t){Reply r;r.error=Error::Unsupported;return r;}
 virtual Reply connectSession(uint32_t){Reply r;r.error=Error::Unsupported;return r;}
 virtual Reply getMetric(Metric,uint32_t){Reply r;r.error=Error::Unsupported;return r;}
 virtual Reply connectAuxiliary(Auxiliary,uint32_t){Reply r;r.error=Error::Unsupported;return r;}
};
struct Snapshot {
 bool enabled=false, valid=false, connected=false, canFindHome=false;
 bool readOnly=true;
 bool atHome=false, slewing=false, tracking=false;
 uint32_t sampledAt=0, completedAt=0, sequence=0;
 uint8_t consecutiveStowed=0;
 Error error=Error::None;
 int32_t driverError=0;
 Failure failure;
 bool fresh(uint32_t now) const {return enabled && valid && uint32_t(now-sampledAt)<=5000;}
 // Telescope telemetry only; NOT authorization to move the cover.
 bool stowedCandidate(uint32_t now) const {
  return fresh(now) && connected && canFindHome && atHome && !slewing && !tracking && consecutiveStowed>=2;
 }
};
// Each step issues at most one request. Optional session connection never moves hardware.
class Client {
 public:
 explicit Client(Transport& transport):transport_(transport){}
 void enable(bool enabled,bool autoConnect=false);
 void step(uint32_t now);
 Snapshot status(uint32_t now) const;
 bool optionalWindow(uint32_t now,uint32_t budgetMs) const {return !immediate_ && stage_==0 && !connectPending_ && published_.fresh(now) && int32_t(nextAt_-now)>=int32_t(budgetMs); }
 private:
 Transport& transport_;
 Snapshot published_, pending_;
 uint8_t stage_=0, failures_=0;
 uint32_t transaction_=0, nextAt_=0;
 bool connectPending_=false,connectAttempted_=false;
 uint32_t connectDue_=0;
 bool immediate_=true;
};
const char* propertyName(Property property);
const char* errorName(Error error);
enum class StowPhase { Idle, Checking, Waiting, Complete, Failed, Unknown };
struct StowStatus {
 StowPhase phase=StowPhase::Idle;
 Error error=Error::None;
 uint32_t startedAt=0, operation=0;
 bool active() const {return phase==StowPhase::Checking || phase==StowPhase::Waiting;}
};
// Supervised telescope-only test. Never issues a cover command or retries a PUT.
class StowTest {
 public:
 bool start(uint32_t now,uint32_t timeoutMs);
 void step(uint32_t now,const Snapshot& s,Transport& transport);
 StowStatus status() const {return state_;}
 private:
 StowStatus state_;
 uint32_t timeout_=60000,sentAt_=0,lastSequence_=0;
 uint8_t confirmations_=0;
};
const char* stowPhaseName(StowPhase phase);
}
// Monitoring worker with optional logical connection. Captured at boot; disabled by default.
void beginAlpaca();
alpaca::Snapshot alpacaStatus();
bool alpacaAltitude(double& degrees,uint32_t& ageMs);
bool requestAlpacaStow();
alpaca::StowStatus alpacaStowStatus();
}
