#pragma once
#include <stdint.h>
#include "travel_model.h"
#include "servo_reference.h"
namespace cover {
constexpr uint16_t kAllowedMinimum=0, kAllowedMaximum=4095;
constexpr uint16_t kDefaultMinimum=2015, kDefaultMaximum=2075;
// User-confirmed reversed mounting, 2026-10-29. Application mapping only.
constexpr int8_t kAssemblyOpeningDirection=-1;
struct MotionProfile {
 uint16_t openSpeed=100, closeSpeed=100, jogSpeed=100;
 uint8_t acceleration=10;
 uint16_t timeoutMs=5000;
};
bool validMotionProfile(const MotionProfile& profile);
struct Calibration {
 uint16_t minimum=kDefaultMinimum, maximum=kDefaultMaximum;
 uint16_t closed=0, open=0;
 bool hasClosed=false, hasOpen=false;
 int8_t openingDirection=0;
 uint16_t travelCounts=0;
 bool circular=false;
 uint16_t referenceOffset=kApplicationReferenceOffset;
 MotionProfile profile;
};
inline TravelArc calibrationArc(const Calibration& c) {
 TravelArc arc;arc.closedRaw=c.closed;arc.direction=c.openingDirection;arc.length=c.travelCounts;
 arc.circular=c.circular;arc.minimumRaw=c.minimum;arc.maximumRaw=c.maximum;return arc;
}
inline bool calibrationMatchesAssembly(const Calibration& c) {return c.openingDirection==kAssemblyOpeningDirection;}
bool validCalibration(const Calibration& value);
// Conversion is atomic and read-only. Unrepresentable linear bounds require
// explicit reteaching rather than widening the old mechanical interval.
inline bool convertCalibrationReference(Calibration& c,uint16_t target){
 if(c.referenceOffset==target)return true;
 if(c.referenceOffset!=kFactoryReferenceOffset || target!=kFixedReferenceOffset)return false;
 Calibration converted=c;
 converted.closed=wrapPosition(int(c.closed)-kFixedReferenceShift);
 converted.open=wrapPosition(int(c.open)-kFixedReferenceShift);
 if(!c.circular){
  converted.minimum=wrapPosition(int(c.minimum)-kFixedReferenceShift);
  converted.maximum=wrapPosition(int(c.maximum)-kFixedReferenceShift);
  if(converted.minimum>=converted.maximum)return false;
 }
 converted.referenceOffset=target;
 if(!validCalibration(converted))return false;
 c=converted;return true;
}
enum class SettingsLoad { Missing, Loaded, Invalid, Unavailable, ReviewRequired };
SettingsLoad loadCalibration(Calibration& output);
bool saveCalibration(const Calibration& value);
// Removes only saved calibration; does not touch application settings or servo EEPROM.
bool clearCalibration();
}

namespace cover {
// Application settings only; never contains or writes servo EEPROM registers.
// A saved record with wifiConfigured=false explicitly requests setup mode.
struct ApplicationSettings {
 bool disableTorqueAfterMove=false;
 bool enableDebugTab=false;
 bool ntpEnabled=false;
 char ntpServer[64]="pool.ntp.org";
 char timeZone[64]="MST7"; // Arizona: UTC-07:00, no daylight saving.
 bool wifiConfigured=false;
 char ssid[33]={};
 char password[65]={};
 char name[41]="Telescope Cover";
 char mdnsName[32]="cover";
 bool alpacaEnabled=false;
 bool alpacaReadOnly=true; // Legacy stored mode; production monitoring always recovers logical sessions.
 char alpacaHost[64]={};
 uint16_t alpacaPort=32323;
 uint16_t alpacaDevice=0;
 uint16_t stowTimeoutSeconds=60;
};
bool validMdnsName(const char* value);
bool validApplicationSettings(const ApplicationSettings& value);
SettingsLoad loadApplicationSettings(ApplicationSettings& output);
bool saveApplicationSettings(const ApplicationSettings& value);
bool betaNoticeAccepted();
bool acceptBetaNotice();
// Writes an explicit setup-mode record; leaves cover-cal untouched.
bool resetApplicationSettingsPreservingCalibration();
}
