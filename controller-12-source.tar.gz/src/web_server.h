#pragma once
class WebServer;
namespace cover {
void serveWebUi(WebServer& server); void beginWebServer(); void pollWebServer(); }
