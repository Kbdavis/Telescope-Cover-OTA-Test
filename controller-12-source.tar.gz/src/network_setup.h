#pragma once
#include <WebServer.h>
namespace cover {
void beginNetworkSetup(WebServer& server,const String& token);
void pollNetworkSetup();
bool networkSetupBusy();
bool alpacaMonitoringConfigured();
bool betaAcknowledged();
void addBetaNotice(String& page);
bool networkPortalRequest(WebServer& server);
}
