#pragma once
#include <stdint.h>
#include <stddef.h>
struct cJSON;
namespace cover {
// Display-only native telemetry. Never used to authorize cover movement.
struct SeestarPower {
 bool configured=false,valid=false;
 bool retrying=false,paused=false;
 uint32_t sampledAt=0;
 int batteryPercent=-1;
 bool externalPower=false,externalPowerValid=false;
 bool batteryOvertemp=false,batteryOvertempValid=false;
 double batteryTemperature=0;
 bool batteryTemperatureValid=false;
 char chargingState[24]={};
 bool fresh(uint32_t now) const {return valid && uint32_t(now-sampledAt)<=60000;}
};
// Read-only monitoring is paused only for active arm work, never an inspection
// lock. Each retry creates a fresh authenticated transport in the worker.
class PowerMonitor {
 public:
 PowerMonitor(){status_.configured=true;}
 bool due(uint32_t now,bool armActive);
 void record(uint32_t now,const SeestarPower& reading);
 SeestarPower status() const {return status_;}
 private:
 SeestarPower status_;
 bool attempted_=false,refresh_=false;
 uint32_t completedAt_=0;
};
// Bounded JSON parser shared by native transport and host tests. Caller owns result.
cJSON* parseSeestarFrame(const char* data,size_t length);
bool seestarReplyOk(const cJSON* root,uint32_t id);
bool parseSeestarPower(const cJSON* root,uint32_t id,uint32_t now,SeestarPower& out);
SeestarPower seestarPowerStatus();
void beginSeestarPower();
}
