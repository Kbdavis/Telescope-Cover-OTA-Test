#if defined(COVER_WEB_CONTROL) || defined(COVER_POWER_HOST_TEST)
#include "emergency_shutdown.h"
#include <cJSON.h>
#include <string.h>
namespace cover {
namespace {
const cJSON* item(const cJSON* node,const char* key){return cJSON_GetObjectItemCaseSensitive(node,key);}
bool equal(const cJSON* node,const char* value){return cJSON_IsString(node)&&strcmp(node->valuestring,value)==0;}
bool terminal(const cJSON* state){return equal(state,"idle")||equal(state,"complete")||equal(state,"cancel")||equal(state,"fail");}
bool functionIdle(const cJSON* function){
 if(!terminal(item(function,"state")))return false;
 for(auto child=function->child;child;child=child->next){
  // Saved plan/target metadata is not a running function. Nested live capture
  // states must agree with their parent before they can grant clearance.
  if(cJSON_IsObject(child)&&strcmp(child->string,"plan")&&item(child,"state")&&!functionIdle(child))return false;
 }
 return true;
}
}
bool parseShutdownNative(const cJSON* device,const cJSON* camera,const cJSON* app,const cJSON* plans,uint32_t now,ShutdownNative& out){
 out.valid=false;
 if(!cJSON_IsObject(device)||!cJSON_IsObject(camera)||!cJSON_IsObject(app)||!cJSON_IsArray(plans))return false;
 if(!equal(item(item(device,"device"),"product_model"),"Seestar S30 Pro"))return false;
 const auto mount=item(device,"mount"),closed=item(mount,"close"),tracking=item(mount,"tracking"),moving=item(mount,"move_type");
 if(!cJSON_IsBool(closed)||!cJSON_IsBool(tracking)||!cJSON_IsString(moving)||!cJSON_IsString(item(camera,"state")))return false;
 out.closed=cJSON_IsTrue(closed);out.tracking=cJSON_IsTrue(tracking);out.moving=!equal(moving,"none");
 out.cameraIdle=equal(item(camera,"state"),"idle")||equal(item(camera,"state"),"close");
 out.imagingIdle=true;out.planIdle=cJSON_GetArraySize(plans)==0;
 for(auto node=app->child;node;node=node->next){
  if(strcmp(node->string,"selected_cam")==0){if(!cJSON_IsString(node))return false;continue;}
  if(!cJSON_IsObject(node))return false;
  const auto state=item(node,"state");if(!cJSON_IsString(state))return false;
  // Unknown/paused/waiting functions cannot establish safe idle clearance.
  const bool idle=functionIdle(node);out.imagingIdle=out.imagingIdle&&idle;
  if(strcmp(node->string,"ViewPlan")==0)out.planIdle=out.planIdle&&idle;
 }
 out.valid=true;out.sampledAt=now;return true;
}
}
#endif
