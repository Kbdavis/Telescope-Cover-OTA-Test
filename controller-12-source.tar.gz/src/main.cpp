#include <Arduino.h>

#include "cover_controller.h"
#ifdef COVER_BENCH_OTA
namespace cover {void beginBenchOta();void pollBenchOta();}
#endif
#ifdef COVER_RELEASE_SIGNATURE_SELFTEST
namespace cover {void beginReleaseSignatureSelftest();}
#endif
#ifdef COVER_WEB_CONTROL
#include "web_server.h"
#include "alpaca_client.h"
#include "seestar_power.h"
#include "web_control.h"
#include "diagnostics.h"
#include "ota_service.h"
#endif
#ifdef COVER_SERVO_DIAGNOSTIC
#include "servo_diagnostic.h"
#endif
#ifdef COVER_MOTION_BENCH
#include "motion_bench.h"
#endif

void setup() {
  Serial.begin(115200);
#if defined(COVER_BENCH_OTA)
  cover::beginBenchOta();
#elif defined(COVER_RELEASE_SIGNATURE_SELFTEST)
  cover::beginReleaseSignatureSelftest();
#elif defined(COVER_SERVO_DIAGNOSTIC)
  cover::beginServoDiagnostic();
#elif defined(COVER_MOTION_BENCH)
  cover::beginMotionBench();
#elif defined(COVER_WEB_CONTROL)
  cover::beginOtaStartup();
  cover::beginDiagnostics();
  cover::beginWebControl();
  cover::beginWebServer();
  cover::beginAlpaca();
  // Telescope ownership stays with the Seestar app: no native authenticated worker.
#else
  Serial.println("Telescope Cover: scaffold firmware");
  Serial.printf("Cover state: %s; motion unavailable\n",
                cover::stateName(cover::State::Unknown));
#endif
}

void loop() {
#ifdef COVER_BENCH_OTA
  cover::pollBenchOta();
#endif
#ifdef COVER_SERVO_DIAGNOSTIC
  cover::pollServoDiagnostic();
#endif
#ifdef COVER_MOTION_BENCH
  cover::pollMotionBench();
#endif
#ifdef COVER_WEB_CONTROL
  cover::pollOtaStartup();
  cover::pollWebServer();
  cover::noteWebLoop();
#endif
  // Motion is always command-triggered.
  delay(1);  // Yield to the ESP32 scheduler between diagnostic polls.
}
