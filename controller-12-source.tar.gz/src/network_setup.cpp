#ifdef COVER_WEB_CONTROL
#include "network_setup.h"
#include "web_server.h"
#include "settings.h"
#include "time_sync.h"
#include "web_control.h"
#include "diagnostics.h"
#include "debug_response.h"
#include "sta_recovery.h"
#include <WiFi.h>
#include <DNSServer.h>
#include <ESPmDNS.h>
#include <esp_system.h>
#include <esp_wifi.h>
#if !defined(COVER_BROWSER_OTA) && !defined(COVER_MULTITURN_USB) && !defined(COVER_WEB_READ_ONLY) && __has_include("wifi_local.h")
#include "wifi_local.h"
#else
#define COVER_WIFI_SSID ""
#define COVER_WIFI_PASSWORD ""
#endif
namespace cover {
namespace {
DNSServer dns;
ApplicationSettings saved,candidate;
String authToken,apName,scanJson="[]",message="Ready";
bool ap=false,legacy=false,closeAP=false,recoveryAP=false;
StaRecovery staRecovery;
bool acknowledged=false;
extern const uint8_t betaNotice[] asm("_binary_data_beta_notice_html_start");
uint32_t apConnectedAt=0;
uint32_t disconnectedAt=0,started=0;
enum class Phase { Idle, WaitScan, Scanning, WaitConnect, Connecting, WaitReset, WaitClearCalibration, WaitAlpaca, WaitAdvanced, WaitReboot, WaitHostname, WaitTime, Restarting };
Phase phase=Phase::Idle;bool rebootKeepTorque=false,rebootOperation=false;
MaintenanceLease setupLease;
String quote(const String& s){
 String out="\"";
 for(size_t i=0;i<s.length();++i){unsigned char c=s[i];
  if(c=='"' || c=='\\'){out+='\\';out+=char(c);}
  else if(c<32){char b[7];snprintf(b,sizeof(b),"\\u%04x",c);out+=b;}
  else out+=char(c);
 }return out+'"';
}
void startAP(bool recovery=false){
 if(ap)return;
 noteMaintenanceNetwork(false);
 if(!maintenanceMayExposeAp())return;
 uint8_t mac[6];WiFi.macAddress(mac);
 char name[32];snprintf(name,sizeof(name),"TelescopeCover-%02X%02X%02X",mac[3],mac[4],mac[5]);apName=name;
 diagnosticWiFiAction("setup-AP-STA-start");
 WiFi.mode(WIFI_AP_STA);
 if(!WiFi.softAP(name)){message="Setup hotspot failed; inspect USB";return;}
 ap=true;recoveryAP=recovery;dns.start(53,"*",WiFi.softAPIP());
 Serial.printf("SETUP AP: %s open (no password) address=%s\n",name,WiFi.softAPIP().toString().c_str());
}
void finish(const String& result){rebootOperation=false;message=result;phase=Phase::Idle;candidate=ApplicationSettings{};endNetworkMaintenance(setupLease);setupLease=MaintenanceLease{};}
bool authorize(WebServer& s){
 if(s.header("X-Cover-Token")!=authToken){s.send(403,"text/plain","Reload configuration");return false;}
 if(!acknowledged){s.send(403,"text/plain","Accept the beta notice first");return false;}
 uint32_t generation=0;
 if(!debugCursor(s.arg("control_generation").c_str(),generation) || !controlRequestAllowed(generation)){
  s.send(409,"text/plain","Maintenance active or stale controls; refresh controller status");return false;
 }
 return true;
}
bool reserve(WebServer& s,Phase next){
 uint32_t generation=0;debugCursor(s.arg("control_generation").c_str(),generation);
 if(phase!=Phase::Idle || !(setupLease=requestNetworkMaintenance(generation))){s.send(409,"text/plain","Network setup busy or cover moving/holding");return false;}
 phase=next;started=millis();s.send(202,"text/plain","Waiting for motion-worker setup clearance");return true;
}
void reconnectSaved(){
 if(saved.wifiConfigured)WiFi.begin(saved.ssid,saved.password);
 else if(legacy)WiFi.begin(COVER_WIFI_SSID,COVER_WIFI_PASSWORD);
}
}
bool alpacaMonitoringConfigured(){return saved.alpacaEnabled;}
bool betaAcknowledged(){return acknowledged;}
void addBetaNotice(String& page){
 if(acknowledged)return;
 String notice(reinterpret_cast<const char*>(betaNotice));notice.replace("BOOT_TOKEN",authToken);
 page.replace("</body>",notice+"</body>");
}
bool networkSetupBusy(){return phase!=Phase::Idle || maintenanceStatus().locked();}
bool networkPortalRequest(WebServer& s){return ap && s.client().localIP()==WiFi.softAPIP();}
void beginNetworkSetup(WebServer& server,const String& token){
 authToken=token;
 WiFi.onEvent([](WiFiEvent_t event,WiFiEventInfo_t){
  if(event==ARDUINO_EVENT_WIFI_STA_DISCONNECTED || event==ARDUINO_EVENT_WIFI_STA_LOST_IP || event==ARDUINO_EVENT_WIFI_STA_GOT_IP)
   noteMaintenanceNetwork(false);
 });
 acknowledged=betaNoticeAccepted();
 server.on("/api/beta/accept",HTTP_POST,[&server]{
  if(server.header("X-Cover-Token")!=authToken){server.send(403,"text/plain","Reload this page");return;}
  if(server.arg("accepted")!="yes"){server.send(400,"text/plain","Explicit acceptance required");return;}
  auto status=webStatus();
  uint32_t generation=0;
  if(!debugCursor(server.arg("control_generation").c_str(),generation) || !controlRequestAllowed(generation) || networkSetupBusy() || status.moving || status.holding){server.send(409,"text/plain","Wait until the controller is idle, then retry");return;}
  if(acknowledged){server.send(200,"text/plain","Acceptance already saved");return;}
  const auto lease=requestNetworkMaintenance(generation);
  if(!lease){server.send(409,"text/plain","Maintenance active; retry acknowledgment");return;}
  // This short NVS write changes no network/servo state. The reservation still
  // excludes all other writers until the worker drains and releases it.
  const bool savedAcceptance=acceptBetaNotice();endNetworkMaintenance(lease);
  if(!savedAcceptance){server.send(503,"text/plain","Could not save acceptance. Please retry.");return;}
  acknowledged=true;server.sendHeader("Cache-Control","no-store");server.send(200,"text/plain","Acceptance saved");
 });
 diagnosticWiFiAction("boot-STA-disable-sleep");
 WiFi.persistent(false);WiFi.mode(WIFI_STA);WiFi.setSleep(false);
 const auto loaded=loadApplicationSettings(saved);
 beginTimeSync(saved);
 legacy=loaded==SettingsLoad::Missing && strlen(COVER_WIFI_SSID)>0;
 disconnectedAt=millis();
 staRecovery.reset(disconnectedAt);
 if(loaded==SettingsLoad::Loaded && saved.wifiConfigured)reconnectSaved();
 else if(legacy)reconnectSaved();
 else startAP();
 // ESPmDNS tracks Wi-Fi interface/address changes, including AP-to-STA setup.
 if(MDNS.begin(saved.mdnsName)){
  MDNS.addService("http","tcp",80);
  MDNS.addServiceTxt("http","tcp","path","/");
  diagnosticLog("MDNS started: http://%s.local/",saved.mdnsName);
 }else diagnosticEvent(DebugLevel::Warn,"MDNS start failed; use controller IP address");
 if(loaded==SettingsLoad::Invalid || loaded==SettingsLoad::Unavailable)message="Settings invalid or unavailable; configure Wi-Fi again";
 server.on("/configuration",HTTP_GET,[&server]{serveWebUi(server);});
 server.on("/api/network",HTTP_GET,[&server]{
  String body="{\"alpaca_enabled\":"+String(saved.alpacaEnabled?"true":"false")+",\"alpaca_read_only\":false,\"alpaca_host\":"+quote(saved.alpacaHost)+",\"alpaca_port\":"+String(saved.alpacaPort)+",\"alpaca_device\":"+String(saved.alpacaDevice)+",\"mdns_name\":"+quote(saved.mdnsName)+",\"busy\":"+String(networkSetupBusy()?"true":"false")+",\"connected\":"+String(WiFi.status()==WL_CONNECTED?"true":"false")+
   ",\"ssid\":"+quote(WiFi.SSID())+",\"ip\":"+quote(WiFi.localIP().toString())+",\"ap\":"+quote(ap?apName:"")+
   ",\"saved_ssid\":"+quote(saved.wifiConfigured?saved.ssid:legacy?COVER_WIFI_SSID:"")+",\"password_saved\":"+String((saved.wifiConfigured?saved.password[0]!=0:legacy&&strlen(COVER_WIFI_PASSWORD)>0)?"true":"false")+
   ",\"message\":"+quote(message)+",\"networks\":"+scanJson+"}";
  body.remove(body.length()-1);body+=",\"disable_torque_after_move\":"+String(saved.disableTorqueAfterMove?"true":"false")+",\"enable_debug_tab\":"+String(saved.enableDebugTab?"true":"false")+"}";
  char local[kLocalTimestampSize];formatLocalTimestamp(logEpochSeconds(),local,sizeof(local));
  body.remove(body.length()-1);
  body+=",\"ntp_enabled\":"+String(saved.ntpEnabled?"true":"false")+",\"ntp_server\":"+quote(saved.ntpServer)+
   ",\"time_zone\":"+quote(saved.timeZone)+",\"time_synchronized\":"+String(lastTimeSync()?"true":"false")+
   ",\"last_time_sync\":"+String(lastTimeSync())+",\"local_time\":"+(local[0]?quote(local):String("null"))+"}";
  server.sendHeader("Cache-Control","no-store");server.send(200,"application/json",body);
 });
 server.on("/api/settings/alpaca",HTTP_POST,[&server]{
  if(!authorize(server))return;
  ApplicationSettings next=saved;
  String enabled=server.arg("enabled"),host=server.arg("host"),port=server.arg("port"),device=server.arg("device");
  String readOnly=server.hasArg("read_only")?server.arg("read_only"):String(next.alpacaReadOnly?"true":"false");
  IPAddress ip;
  auto number=[](const String& s,unsigned max){if(!s.length() || s.length()>5)return false;for(unsigned i=0;i<s.length();++i)if(!isDigit(s[i]))return false;return s.toInt()<=long(max);};
  if((enabled!="true" && enabled!="false") || (readOnly!="true" && readOnly!="false") || (enabled=="true" && !ip.fromString(host)) || !number(port,65535) || !port.toInt() || !number(device,255)){
   server.send(400,"text/plain","Require enabled/read_only=true/false, numeric IPv4, port 1–65535, device 0–255");return;
  }
  next.alpacaEnabled=enabled=="true";
  // Session recovery is fixed firmware behavior. Keep the legacy mode field in
  // NVS for schema compatibility; neither it nor a stale form enables controls.
  // Disabling keeps the saved address even when no address has been configured.
  if(next.alpacaEnabled){
   memset(next.alpacaHost,0,sizeof(next.alpacaHost));
   String normalized=ip.toString();strcpy(next.alpacaHost,normalized.c_str());
   next.alpacaPort=port.toInt();next.alpacaDevice=device.toInt();
  }
  if(legacy){
   if(strlen(COVER_WIFI_SSID)>32 || strlen(COVER_WIFI_PASSWORD)>64){server.send(409,"text/plain","Configure Wi-Fi first");return;}
   next.wifiConfigured=true;strcpy(next.ssid,COVER_WIFI_SSID);strcpy(next.password,COVER_WIFI_PASSWORD);
  }
  if(!validApplicationSettings(next)){server.send(400,"text/plain","Invalid settings");return;}
  if(reserve(server,Phase::WaitAlpaca))candidate=next;
 });
 server.on("/api/controller/reboot",HTTP_POST,[&server]{
  if(!authorize(server))return;
  if(server.arg("confirm")!="reboot"){server.send(400,"text/plain","Confirm reboot");return;}
  const String disable=server.arg("disable_torque");
  const uint32_t client=strtoul(server.header("X-Cover-Client").c_str(),nullptr,10);
  if((disable!="true" && disable!="false") || !client){server.send(400,"text/plain","Require disable_torque=true/false and a client");return;}
  uint32_t generation=0;debugCursor(server.arg("control_generation").c_str(),generation);
  if(phase!=Phase::Idle || !(setupLease=requestRebootMaintenance(disable=="false",client,generation))){server.send(409,"text/plain","Finish movement or resolve servo fault before reboot");return;}
  rebootKeepTorque=disable=="false";rebootOperation=true;phase=Phase::WaitReboot;started=millis();
  server.send(202,"text/plain","Preparing servo torque for reboot");
 });
 server.on("/api/settings/advanced",HTTP_POST,[&server]{
  if(!authorize(server))return;
  const String value=server.arg("disable_torque_after_move");
  if(value!="true" && value!="false"){server.send(400,"text/plain","Require disable_torque_after_move=true/false");return;}
  const String debug=server.hasArg("enable_debug_tab")?server.arg("enable_debug_tab"):String(saved.enableDebugTab?"true":"false");
  if(debug!="true" && debug!="false"){server.send(400,"text/plain","Require enable_debug_tab=true/false");return;}
  ApplicationSettings next=saved;next.disableTorqueAfterMove=value=="true";next.enableDebugTab=debug=="true";
  if(legacy){
   if(strlen(COVER_WIFI_SSID)>32 || strlen(COVER_WIFI_PASSWORD)>64){server.send(409,"text/plain","Configure Wi-Fi first");return;}
   next.wifiConfigured=true;strcpy(next.ssid,COVER_WIFI_SSID);strcpy(next.password,COVER_WIFI_PASSWORD);
  }
  if(reserve(server,Phase::WaitAdvanced))candidate=next;
 });
 server.on("/api/settings/time",HTTP_POST,[&server]{
  if(!authorize(server))return;
  const String enabled=server.arg("enabled");
  String host=server.arg("server"),zone=server.arg("time_zone");host.trim();zone.trim();
  if((enabled!="true" && enabled!="false") || host.length()>=sizeof(saved.ntpServer) ||
     zone.length()>=sizeof(saved.timeZone) || strlen(host.c_str())!=host.length() || strlen(zone.c_str())!=zone.length()){
   server.send(400,"text/plain","Require enabled=true/false, server and POSIX time zone of 1–63 characters");return;
  }
  ApplicationSettings next=saved;next.ntpEnabled=enabled=="true";
  memset(next.ntpServer,0,sizeof(next.ntpServer));strcpy(next.ntpServer,host.c_str());
  memset(next.timeZone,0,sizeof(next.timeZone));strcpy(next.timeZone,zone.c_str());
  if(legacy){
   if(strlen(COVER_WIFI_SSID)>32 || strlen(COVER_WIFI_PASSWORD)>64){server.send(409,"text/plain","Configure Wi-Fi first");return;}
   next.wifiConfigured=true;strcpy(next.ssid,COVER_WIFI_SSID);strcpy(next.password,COVER_WIFI_PASSWORD);
  }
  if(!validApplicationSettings(next)){server.send(400,"text/plain","Use a hostname or IPv4 address and a POSIX time zone, e.g. MST7 or EST5EDT,M3.2.0/2,M11.1.0/2");return;}
  if(reserve(server,Phase::WaitTime))candidate=next;
 });
 server.on("/api/settings/hostname",HTTP_POST,[&server]{
  if(!authorize(server))return;
  String name=server.arg("hostname");name.trim();name.toLowerCase();
  if(name.length()>31 || strlen(name.c_str())!=name.length()){
   server.send(400,"text/plain","Use 1–31 letters, digits or hyphens; no leading/trailing hyphen or .local suffix");return;
  }
  ApplicationSettings next=saved;
  if(legacy){
   if(strlen(COVER_WIFI_SSID)>32 || strlen(COVER_WIFI_PASSWORD)>64){server.send(409,"text/plain","Configure Wi-Fi before saving hostname");return;}
   next.wifiConfigured=true;strcpy(next.ssid,COVER_WIFI_SSID);strcpy(next.password,COVER_WIFI_PASSWORD);
  }
  memset(next.mdnsName,0,sizeof(next.mdnsName));strcpy(next.mdnsName,name.c_str());
  if(!validApplicationSettings(next)){server.send(400,"text/plain","Invalid application settings");return;}
  if(reserve(server,Phase::WaitHostname))candidate=next;
 });
 server.on("/api/settings/clear-calibration",HTTP_POST,[&server]{
  if(!authorize(server))return;
  if(server.arg("confirm")!="clear-calibration"){
   server.send(400,"text/plain","Confirm clearing calibration");return;
  }
  if(reserve(server,Phase::WaitClearCalibration))message="Calibration clear requested; waiting for motion-worker clearance";
 });
 server.on("/api/settings/reset",HTTP_POST,[&server]{
  if(!authorize(server))return;
  if(server.arg("confirm")!="reset-preserve-calibration"){
   server.send(400,"text/plain","Confirm reset with calibration preserved");return;
  }
  if(reserve(server,Phase::WaitReset))message="Reset requested; waiting for motion-worker setup clearance";
 });
 server.on("/api/network/scan",HTTP_POST,[&server]{if(authorize(server))reserve(server,Phase::WaitScan);});
 server.on("/api/network/connect",HTTP_POST,[&server]{
  if(!authorize(server))return;
  const String ssid=server.arg("ssid");String password=server.arg("password");
  if(server.arg("keep_password")=="yes"){
   const char* existingSsid=saved.wifiConfigured?saved.ssid:legacy?COVER_WIFI_SSID:"";
   if(!existingSsid[0] || ssid!=existingSsid || password.length()){server.send(400,"text/plain","Saved password can only be kept for the same network");return;}
   password=saved.wifiConfigured?saved.password:COVER_WIFI_PASSWORD;
  }
  if(ssid.length()>32 || password.length()>64 || strlen(ssid.c_str())!=ssid.length() || strlen(password.c_str())!=password.length()){server.send(400,"text/plain","Invalid credentials");return;}
  ApplicationSettings next=saved;next.wifiConfigured=true;
  memset(next.ssid,0,sizeof(next.ssid));memset(next.password,0,sizeof(next.password));
  memcpy(next.ssid,ssid.c_str(),ssid.length());memcpy(next.password,password.c_str(),password.length());
  if(!validApplicationSettings(next)){server.send(400,"text/plain","Enter a valid SSID and password (blank for an open network)");return;}
  if(reserve(server,Phase::WaitConnect))candidate=next;
 });
}
void pollNetworkSetup(){
 pollTimeSync(WiFi.status()==WL_CONNECTED && uint32_t(WiFi.localIP())!=0);
 if(ap)dns.processNextRequest();
 noteMaintenanceNetwork(!ap && WiFi.getMode()==WIFI_STA && WiFi.status()==WL_CONNECTED && uint32_t(WiFi.localIP())!=0);
 if(setupLease && maintenanceStatus().phase==MaintenancePhase::Revoked){
  if(phase==Phase::Scanning){esp_wifi_scan_stop();WiFi.scanDelete();}
  if(phase==Phase::Connecting){WiFi.disconnect(false,false);reconnectSaved();}
  finish("Setup cancelled by Stop or lost clearance; already saved settings apply after restart");return;
 }
 if(phase==Phase::WaitTime || phase==Phase::WaitScan || phase==Phase::WaitConnect || phase==Phase::WaitReset || phase==Phase::WaitHostname || phase==Phase::WaitClearCalibration || phase==Phase::WaitAlpaca || phase==Phase::WaitAdvanced || phase==Phase::WaitReboot){
  if(networkMaintenanceReady(setupLease)){
   if(phase==Phase::WaitReboot){
    debugLog("Manual controller reboot prepared; retain_torque=%d",rebootKeepTorque);
    message="Restarting controller; saved settings preserved.";phase=Phase::Restarting;
   }else if(phase==Phase::WaitTime){
    if(!saveApplicationSettings(candidate)){finish("Time settings save failed; no restart");return;}
    saved=candidate;legacy=false;message="Time settings saved. Restarting.";phase=Phase::Restarting;
   }else if(phase==Phase::WaitAdvanced){
    if(!saveApplicationSettings(candidate)){finish("Advanced settings save failed; no restart");return;}
    saved=candidate;legacy=false;message="Advanced settings saved. Restarting.";phase=Phase::Restarting;
   }else if(phase==Phase::WaitAlpaca){
    if(!saveApplicationSettings(candidate)){finish("Alpaca settings save failed; no restart");return;}
    saved=candidate;legacy=false;
    message="Alpaca settings saved. Restarting with automatic session recovery; no telescope movement commands.";
    phase=Phase::Restarting;
   }else if(phase==Phase::WaitClearCalibration){
    if(!clearCalibration()){finish("Calibration clear failed; no restart. Retry before proceeding.");return;}
    message="Calibration cleared. Restarting; Open/Close requires newly saved endpoints. Wi-Fi and preferences preserved.";
    diagnosticLog("Calibration cleared; application settings preserved; restarting");
    // Keep worker maintenance active until reboot discards in-memory endpoints.
    phase=Phase::Restarting;
   }else if(phase==Phase::WaitHostname){
    if(!saveApplicationSettings(candidate)){finish("Hostname save could not be verified; retry");return;}
    saved=candidate;legacy=false;MDNS.end();
    if(MDNS.begin(saved.mdnsName)){
     MDNS.addService("http","tcp",80);MDNS.addServiceTxt("http","tcp","path","/");
     finish(String("Saved. Open http://")+saved.mdnsName+".local/ — old name may remain cached briefly.");
    }else finish("Hostname saved but mDNS start failed; use the IP address and restart later");
   }else if(phase==Phase::WaitReset){
    if(!resetApplicationSettingsPreservingCalibration()){
     acknowledged=betaNoticeAccepted();
     finish("Reset write could not be verified; no restart. Retry before reboot.");return;
    }
    saved=ApplicationSettings{};candidate=ApplicationSettings{};legacy=false;
    acknowledged=false;
    message="Settings reset; calibration preserved. Restarting into setup mode. Join the open setup hotspot; no password is needed.";
    diagnosticLog("Application settings reset; calibration preserved; restarting");
    phase=Phase::Restarting;
   }else if(phase==Phase::WaitScan){
    diagnosticWiFiAction("setup-scan");
    WiFi.scanDelete();const int result=WiFi.scanNetworks(true,false,false,600); // Arduino timeout = 20 × channel dwell (12 s).
    if(result==WIFI_SCAN_FAILED){finish("Scan could not start");return;}
    phase=Phase::Scanning;message="Scanning…";
   }else{
    closeAP=false;
    startAP(); // Retain a recovery path before changing credentials.
    if(!ap){finish("Cannot change Wi-Fi without a setup hotspot");return;}
    diagnosticWiFiAction("setup-connect-candidate");
    WiFi.disconnect(false,false);WiFi.begin(candidate.ssid,candidate.password);
    phase=Phase::Connecting;message="Connecting; setup hotspot remains available";
   }
   started=millis();
  }else if(millis()-started>3000)finish("Setup rejected: wait for stationary servo feedback or confirmed communication loss; Stop any movement first");
 }
 if(phase==Phase::Restarting && millis()-started>=2000){
  if(!networkMaintenanceReady(setupLease)){finish("Restart cancelled: maintenance clearance no longer confirmed");return;}
  // Stationary settings updates preserve the existing torque through restart.
  const auto cover=webStatus();
  markRetainedReboot(rebootOperation?rebootKeepTorque:cover.torqueValid && cover.torque);
  diagnosticWiFiAction("controller-reboot");ESP.restart();return;
 }
 if(phase==Phase::Scanning){
  int count=WiFi.scanComplete();
  if(count>=0){
   scanJson="[";
   for(int i=0;i<count && i<20;++i){if(i)scanJson+=',';scanJson+="{\"ssid\":"+quote(WiFi.SSID(i))+",\"rssi\":"+String(WiFi.RSSI(i))+",\"secure\":"+String(WiFi.encryptionType(i)!=WIFI_AUTH_OPEN?"true":"false")+"}";}
   scanJson+=']';WiFi.scanDelete();finish("Scan complete; choose a network or enter a hidden SSID");
  }else if(count==WIFI_SCAN_FAILED || millis()-started>15000){esp_wifi_scan_stop();WiFi.scanDelete();finish("Scan failed or timed out; try again");}
 }
 if(phase==Phase::Connecting){
  if(WiFi.status()==WL_CONNECTED && WiFi.SSID()==candidate.ssid && uint32_t(WiFi.localIP())!=0){
   if(saveApplicationSettings(candidate)){saved=candidate;legacy=false;closeAP=true;apConnectedAt=millis();finish("Connected and saved. Setup hotspot closes in 30 seconds. Join your home network and open the controller IP shown here.");}
   else{WiFi.disconnect(false,false);reconnectSaved();finish("Settings write could not be verified. Setup hotspot remains available; retry before reboot.");}
  }else if(millis()-started>20000){WiFi.disconnect(false,false);reconnectSaved();finish("Connection timed out. Check password and network; previous settings retained.");}
 }
 static bool connected=false;
 bool now=WiFi.status()==WL_CONNECTED && uint32_t(WiFi.localIP())!=0;
 if(now && !connected){
  Serial.printf("WEB READY http://%s/\n",WiFi.localIP().toString().c_str());
  if(ap && recoveryAP){closeAP=true;apConnectedAt=millis();}
 }
 if(!now && connected)disconnectedAt=millis();
 connected=now;
 if(closeAP && !now)apConnectedAt=millis();
 if(ap && closeAP && now && phase==Phase::Idle && !maintenanceStatus().locked() &&
    (!recoveryAP || WiFi.softAPgetStationNum()==0) && millis()-apConnectedAt>=30000){
  // In this pinned Arduino core softAPdisconnect(true) compares enableAP's
  // boolean result with ESP_OK, reporting false after a successful shutdown.
  // Use the boolean API directly so application state follows the radio.
  if(WiFi.enableAP(false)){
   dns.stop();ap=false;closeAP=false;recoveryAP=false;
   diagnosticWiFiAction("setup-AP-closed");
  }
 }
 if(!now && millis()-disconnectedAt>20000 && phase==Phase::Idle)startAP(true);
 StaRecoveryConditions recovery;
 recovery.connected=now;recovery.credentials=saved.wifiConfigured || legacy;
 recovery.setupBusy=phase!=Phase::Idle;recovery.maintenanceBusy=maintenanceStatus().locked();
 recovery.portalClient=ap && WiFi.softAPgetStationNum()!=0;
 if(staRecovery.poll(millis(),recovery)){
  // The saved/candidate setup paths already restore the intended RAM config.
  // Avoid WiFi.reconnect(): it forces a disconnect and may interrupt a connection
  // already being recovered by Arduino. This only submits an async STA request.
  diagnosticWiFiAction("saved-STA-retry");
  const esp_err_t result=esp_wifi_connect();
  noteFailureRetry(int(result),staRecovery.waitMs());
  debugLog("WIFI RETRY result=%d next_wait_ms=%lu",int(result),static_cast<unsigned long>(staRecovery.waitMs()));
 }
}
}
#endif
