#if defined(COVER_WEB_CONTROL) && defined(COVER_OTA_MEMORY_PROBE)
#include "ota_memory_probe.h"
#include "diagnostics.h"
#include <Arduino.h>
#include <esp_heap_caps.h>
namespace cover {
namespace {
portMUX_TYPE memoryMux=portMUX_INITIALIZER_UNLOCKED;
OtaMemoryEvidence evidence;
bool transfer=false;
uint32_t frozenEpoch=0;
}
void otaMemoryTransfer(bool active){
 portENTER_CRITICAL(&memoryMux);transfer=active;portEXIT_CRITICAL(&memoryMux);
}
void otaMemoryFinish(){
 // Preserve transfer minima before abort/release and host cancellation reads.
 portENTER_CRITICAL(&memoryMux);frozenEpoch=diagnosticsMetricsEpoch();portEXIT_CRITICAL(&memoryMux);
}
void otaMemoryBoundary(OtaMemoryStage stage,uint32_t bytes){
 const uint32_t epoch=diagnosticsMetricsEpoch();if(!epoch)return;
 portENTER_CRITICAL(&memoryMux);const bool frozen=frozenEpoch==epoch;portEXIT_CRITICAL(&memoryMux);
 if(frozen)return;
 DiagnosticsWork work(epoch);if(!work)return;
 multi_heap_info_t heap{};heap_caps_get_info(&heap,MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT);
 portENTER_CRITICAL(&memoryMux);
 // Finish may race an already acquired sample: do not publish it afterward.
 if(frozenEpoch!=epoch)
  evidence.record(epoch,diagnosticsMetricsEpoch(),stage,transfer,heap.total_free_bytes,heap.largest_free_block,millis(),bytes);
 portEXIT_CRITICAL(&memoryMux);
}
bool otaMemorySnapshot(OtaMemoryEvidence& out){
 // Never inspect while OTA is active; reporting must not alter that workload.
 portENTER_CRITICAL(&memoryMux);const bool idle=!transfer;if(idle)out=evidence;portEXIT_CRITICAL(&memoryMux);
 return idle;
}
}
#endif
