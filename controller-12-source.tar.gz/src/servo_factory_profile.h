#pragma once
#include "servo_build_config.h"
#include <stdint.h>
#include <string.h>

namespace cover {
// Exact documented identity/configuration snapshot of the commissioned ST3215.
// Phase 12 / offset 85 alone are insufficient to identify this profile.
inline bool matchesCommissionedFactoryProfile(const uint8_t (&bytes)[40]) {
  static const uint8_t expected[40] = {
    0x03,0x09,0x00,0x09,0x03,0x01,0x00,0x00,0x01,0x00,
    0x00,0xff,0x0f,0x46,0x8c,0x28,0xe8,0x03,0x0c,0x2c,
    0x2f,0x20,0x20,0x00,0x10,0x00,0x01,0x01,0x36,0x01,
    0x01,0x55,0x00,0x00,0x14,0xc8,0x50,0x0a,0xc8,0xc8
  };
  return memcmp(bytes, expected, sizeof(expected)) == 0;
}
#ifdef COVER_MULTITURN
inline bool matchesMultiTurnProbeProfile(const uint8_t (&bytes)[40]) {
 if(bytes[11]!=0 || bytes[12]!=0 || bytes[18]!=28)return false;
 uint8_t original[40];memcpy(original,bytes,sizeof(original));original[11]=255;original[12]=15;original[18]=12;
 return matchesCommissionedFactoryProfile(original);
}
#endif
#if defined(COVER_REFERENCE_PROBE) || defined(COVER_FIXED_REFERENCE)
// Proposed probe profile only: every factory byte except the fixed 1328 offset.
inline bool matchesReferenceProbeProfile(const uint8_t (&bytes)[40]) {
 if(bytes[31]!=0x30 || bytes[32]!=0x05)return false;
 uint8_t original[40];memcpy(original,bytes,sizeof(original));original[31]=85;original[32]=0;
 return matchesCommissionedFactoryProfile(original);
}
#endif

}
