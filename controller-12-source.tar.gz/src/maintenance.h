#pragma once
#include <stdint.h>
namespace cover {
enum class MaintenanceOwner : uint8_t { None, Network, Reboot, Ota, Telescope };
enum class MaintenancePhase : uint8_t { Idle, Pending, Ready, Revoked };
enum class MaintenanceReason : uint8_t { None, Stop, Network, Servo, Preconditions, Timeout, Worker };
struct MaintenanceLease {
 MaintenanceOwner owner=MaintenanceOwner::None;uint32_t generation=0;
 explicit operator bool() const{return owner!=MaintenanceOwner::None && generation!=0;}
};
inline bool sameLease(MaintenanceLease a,MaintenanceLease b){return a.owner==b.owner && a.generation==b.generation && bool(a);}
struct MaintenanceSnapshot {
 MaintenanceLease lease;
 MaintenancePhase phase=MaintenancePhase::Idle;
 MaintenanceReason reason=MaintenanceReason::None;
 uint32_t controlGeneration=1,requestedAt=0,acknowledgedAt=0,validatedAt=0;
 uint8_t requiredWorkers=0,pausedWorkers=0;
 bool releaseRequested=false,cleanupConfirmed=false,committing=false;
 bool locked() const{return bool(lease);}
};
inline const char* maintenanceOwnerName(MaintenanceOwner owner){
 switch(owner){case MaintenanceOwner::Network:return "network";case MaintenanceOwner::Reboot:return "reboot";
 case MaintenanceOwner::Ota:return "ota";case MaintenanceOwner::Telescope:return "telescope";default:return "none";}
}
inline const char* maintenancePhaseName(MaintenancePhase phase){
 switch(phase){case MaintenancePhase::Pending:return "pending";case MaintenancePhase::Ready:return "ready";
 case MaintenancePhase::Revoked:return "revoked";default:return "idle";}
}
inline const char* maintenanceReasonName(MaintenanceReason reason){
 switch(reason){case MaintenanceReason::Stop:return "stop";case MaintenanceReason::Network:return "network";
 case MaintenanceReason::Servo:return "servo";case MaintenanceReason::Preconditions:return "preconditions";
 case MaintenanceReason::Timeout:return "timeout";case MaintenanceReason::Worker:return "worker";default:return "none";}
}
// No I/O, allocation or implicit expiry/release. Caller serializes all accesses.
class MaintenanceArbiter {
 MaintenanceSnapshot state_;
 uint32_t nextLease_=0;
 void advance(){if(state_.controlGeneration<UINT32_MAX)++state_.controlGeneration;}
public:
 explicit MaintenanceArbiter(uint32_t generation=1){state_.controlGeneration=generation?generation:1;}
 MaintenanceSnapshot snapshot() const{return state_;}
 bool matches(MaintenanceLease lease) const{return sameLease(lease,state_.lease);}
 bool commandsAllowed(uint32_t generation) const{return generation && generation<UINT32_MAX && generation==state_.controlGeneration && !state_.locked();}
 bool heartbeatsAllowed(uint32_t generation) const{
  return generation && generation<UINT32_MAX && generation==state_.controlGeneration && (!state_.locked() || state_.phase==MaintenancePhase::Pending);
 }
 MaintenanceLease reserve(MaintenanceOwner owner,uint32_t now,uint32_t generation,uint8_t workers=0){
  if(owner==MaintenanceOwner::None || !commandsAllowed(generation) || nextLease_==UINT32_MAX)return {};
  state_.lease.owner=owner;state_.lease.generation=++nextLease_;state_.phase=MaintenancePhase::Pending;
  state_.reason=MaintenanceReason::None;state_.requestedAt=now;state_.acknowledgedAt=0;state_.validatedAt=0;
  state_.requiredWorkers=workers;state_.pausedWorkers=0;state_.cleanupConfirmed=false;state_.releaseRequested=false;
  return state_.lease;
 }
 bool acknowledge(MaintenanceLease lease,uint32_t now){
  if(!matches(lease) || state_.phase!=MaintenancePhase::Pending || state_.releaseRequested ||
     (state_.pausedWorkers&state_.requiredWorkers)!=state_.requiredWorkers)return false;
  state_.phase=MaintenancePhase::Ready;state_.acknowledgedAt=state_.validatedAt=now;advance();
  if(state_.controlGeneration==UINT32_MAX){state_.phase=MaintenancePhase::Revoked;state_.reason=MaintenanceReason::Preconditions;return false;}
  return true;
 }
 bool validate(MaintenanceLease lease,uint32_t now){if(!ready(lease))return false;state_.validatedAt=now;return true;}
 bool ready(MaintenanceLease lease) const{return matches(lease) && state_.phase==MaintenancePhase::Ready && !state_.releaseRequested;}
 bool beginCommit(MaintenanceLease lease){if(lease.owner!=MaintenanceOwner::Ota || !ready(lease) || state_.committing)return false;state_.committing=true;return true;}
 void revoke(MaintenanceReason reason){
  if(!state_.locked() || state_.phase==MaintenancePhase::Revoked)return;
  state_.phase=MaintenancePhase::Revoked;state_.reason=reason;advance();
 }
 bool stop(bool automatic,uint32_t observedGeneration){
  // Before clearance the old generation remains valid. After clearance only
  // stale automatic cleanup is ignored; explicit and legacy Stop always win.
  if(automatic && (!observedGeneration || observedGeneration!=state_.controlGeneration))return false;
  revoke(MaintenanceReason::Stop);advance();return true;
 }
 bool pause(MaintenanceLease lease,uint8_t worker){if(!matches(lease))return false;state_.pausedWorkers|=worker;return true;}
 bool cleanup(MaintenanceLease lease){if(!matches(lease))return false;state_.cleanupConfirmed=true;return true;}
 bool requestRelease(MaintenanceLease lease){if(!matches(lease))return false;state_.releaseRequested=true;return true;}
 bool finish(MaintenanceLease lease,bool workerSafe){
  if(!matches(lease) || !state_.releaseRequested)return false;
  if(lease.owner==MaintenanceOwner::Ota && (!state_.cleanupConfirmed || !workerSafe))return false;
  const uint32_t generation=state_.controlGeneration;state_=MaintenanceSnapshot{};state_.controlGeneration=generation;advance();return true;
 }
 bool mayExposeAp() const{return state_.lease.owner!=MaintenanceOwner::Ota || state_.cleanupConfirmed;}
};
struct OtaMaintenanceRequirements {
 bool closedCover=false,startupAccepted=false,recovery=false,operatorSecured=false;
 // Receiver-specific measured reserves must be supplied; zero disables admission.
 uint32_t minimumInternalHeap=0,minimumLargestBlock=0;
};
inline bool otaOperatorSecuredPolicy(const OtaMaintenanceRequirements& requirements){
#ifdef COVER_BROWSER_OTA
 return requirements.operatorSecured && !requirements.closedCover && !requirements.recovery;
#else
 (void)requirements;return false;
#endif
}
inline bool otaPositionPolicyAllowed(const OtaMaintenanceRequirements& requirements){
 if(requirements.operatorSecured)return otaOperatorSecuredPolicy(requirements);
#ifdef COVER_OTA_DEVELOPMENT
 (void)requirements;return true;
#else
 return requirements.closedCover && !requirements.recovery;
#endif
}
constexpr uint8_t kMaintenanceAlpacaWorker=1,kMaintenancePowerWorker=2;
}
