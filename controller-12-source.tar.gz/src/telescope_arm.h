#pragma once
#include "alpaca_client.h"
namespace cover {
enum class ArmPhase { Idle, Checking, Waiting, Complete, Unknown };
struct ArmStatus {
 bool supported=false,opening=false,locked=false;
 ArmPhase phase=ArmPhase::Idle;
 uint32_t operation=0;
 const char* reason="No arm operation requested";
 bool active() const{return phase==ArmPhase::Checking || phase==ArmPhase::Waiting;}
};
struct ArmEvidence {
// Both cover flags require fresh, clean, torque-off feedback at the open endpoint.
 // STOPPED is eligible only for explicit inspection and a separately confirmed stow.
 bool coverOpen=false,coverStoppedOpen=false,maintenance=false,cameraIdle=false;
 alpaca::Snapshot scope;
 bool altitudeValid=false;double altitude=0;uint32_t altitudeAt=0;
};
// Testable telescope-only operation. A command acknowledgment is never completion.
class ArmOperation {
 public:
 bool start(bool opening,uint32_t now,const ArmEvidence& e);
 void reject(bool opening){++status_.operation;status_.opening=opening;inspect("Arm preflight failed");}
 bool readyToSend(uint32_t now,const ArmEvidence& e) const;
 void sent(uint32_t now,bool acknowledged);
 void step(uint32_t now,const ArmEvidence& e);
 bool finish(uint32_t now,const ArmEvidence& e);
 ArmStatus status() const{return status_;}
 private:
 void inspect(const char* reason){status_.phase=ArmPhase::Unknown;status_.locked=true;status_.reason=reason;}
 ArmStatus status_;
 uint32_t started_=0,sentAt_=0,lastSequence_=0;
 uint8_t confirmations_=0;
};
bool armStationary(uint32_t now,const ArmEvidence& e,bool inspectedStopped=false);
const char* armPhaseName(ArmPhase phase);
ArmStatus telescopeArmStatus();
bool requestTelescopeArm(bool opening);
bool finishTelescopeArm();
ArmEvidence telescopeArmEvidence();
}
