#ifdef COVER_RELEASE_SIGNATURE_SELFTEST
#if defined(COVER_WEB_CONTROL) || defined(COVER_SERVO_DIAGNOSTIC) || defined(COVER_MOTION_BENCH)
#error Signature self-test must not include a controller/servo operating mode
#endif
#include <Arduino.h>
#include <esp_heap_caps.h>
#include "release_signature.h"
#include "generated_release_signature_vector.h"
namespace cover {
void beginReleaseSignatureSelftest(){
 // Dedicated spare-board test: no UART1, network, Preferences or servo calls.
 Serial.println("RELEASE_SIGNATURE_SELFTEST public-test-vector-only no-servo no-network");
 ReleasePublicKey key;key.id="test-only";memcpy(key.point,publicPoint,sizeof(publicPoint));
 const auto verify=[&](const uint8_t* sig){return verifyReleaseSignature(payload,sizeof(payload),sig,64,"test-only",9,&key,1);};
 const uint32_t started=millis();
 const uint32_t before=heap_caps_get_free_size(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT);
 bool passed=verify(signature)==ReleaseSignatureResult::Verified;
 uint8_t corrupt[64];memcpy(corrupt,signature,64);corrupt[0]^=1;
 passed=passed && verify(corrupt)==ReleaseSignatureResult::BadSignature;
 key.revoked=true;passed=passed && verify(signature)==ReleaseSignatureResult::RevokedKey;key.revoked=false;
 const uint32_t baseline=heap_caps_get_free_size(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT);
 for(unsigned i=0;i<8;++i)passed=verify(signature)==ReleaseSignatureResult::Verified && passed;
 const uint32_t after=heap_caps_get_free_size(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT);
 const uint32_t largest=heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT);
 Serial.printf("RELEASE_SIGNATURE_SELFTEST result=%s elapsed_ms=%lu before=%lu baseline=%lu after=%lu largest=%lu\n",
  passed?"PASS":"FAIL",(unsigned long)(millis()-started),(unsigned long)before,(unsigned long)baseline,(unsigned long)after,(unsigned long)largest);
 // Heap readings are observations; no guessed production reserve or leak verdict.
}
}
#endif
