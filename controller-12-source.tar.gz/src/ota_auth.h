#pragma once
#include "ota_protocol.h"
namespace cover {
// Crypto backends use platform libraries; no home-grown digest implementation.
bool otaSha256(const void* data,size_t n,uint8_t out[32]);
bool otaHmac(const uint8_t* key,size_t keySize,const void* data,size_t n,uint8_t out[32]);
bool otaMd5(const void* data,size_t n,uint8_t out[16]);
inline bool otaControlMac(const char* secret,const char* method,const char* route,const char* boot,const char* nonce,const char* transaction,
                          const char* body,size_t bodySize,uint8_t out[32]){
 if(strlen(secret)<32 || strlen(secret)>128 || bodySize>kOtaBodyBytes)return false;
 uint8_t key[32],digest[32];char digestHex[65],message[320];
 const char context[]="cover-ota-control-v1";
 if(!otaHmac(reinterpret_cast<const uint8_t*>(secret),strlen(secret),context,sizeof(context)-1,key) || !otaSha256(body,bodySize,digest))return false;
 otaHex(digest,32,digestHex);
 const int n=snprintf(message,sizeof(message),"COVER-OTA-CONTROL-1\n%s\n%s\n%s\n%s\n%s\n%s\n",method,route,boot,nonce,transaction,digestHex);
 if(n<=0 || n>=int(sizeof(message)))return false;
 const bool ok=otaHmac(key,sizeof(key),message,n,out);memset(key,0,sizeof(key));return ok;
}
class OtaChallenge {
 uint32_t peer_=0,issued_=0;bool live_=false;
 char nonce_[33]={};
public:
 bool issue(uint32_t peer,uint32_t now,const char* nonce){
  if(!peer || strlen(nonce)!=32 || (issued_ && uint32_t(now-issued_)<1000))return false;
  memcpy(nonce_,nonce,33);peer_=peer;issued_=now;live_=true;return true;
 }
 const char* nonce()const{return nonce_;}
 bool consume(uint32_t peer,uint32_t now,const char* nonce){
  if(!live_ || peer!=peer_ || strlen(nonce)!=32 || memcmp(nonce_,nonce,32))return false;
  live_=false;return uint32_t(now-issued_)<=10000;
 }
};
}
