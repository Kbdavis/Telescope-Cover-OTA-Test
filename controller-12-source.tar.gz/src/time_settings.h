#pragma once
#include <stddef.h>
#include <string.h>
namespace cover {
inline bool validTimeServer(const char* value,size_t capacity){
 const char* end=static_cast<const char*>(memchr(value,0,capacity));
 if(!end || end==value)return false;
 unsigned label=0;char previous=0;
 for(const char* p=value;p<end;++p){
  const char c=*p;
  if(c=='.'){if(!label || previous=='-')return false;label=0;}
  else {if(!((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='-') || (!label && c=='-') || ++label>63)return false;}
  previous=c;
 }
 return label && previous!='-';
}
namespace time_zone_detail {
inline bool number(const char*& p,unsigned min,unsigned max){
 if(*p<'0'||*p>'9')return false;
 unsigned n=0;do{n=n*10+unsigned(*p++-'0');if(n>max)return false;}while(*p>='0'&&*p<='9');
 return n>=min;
}
inline bool name(const char*& p){
 unsigned n=0;
 if(*p=='<'){
  ++p;while((*p>='A'&&*p<='Z')||(*p>='a'&&*p<='z')||(*p>='0'&&*p<='9')||*p=='+'||*p=='-'){++p;++n;}
  if(*p!='>')return false;
  ++p;
 }else while((*p>='A'&&*p<='Z')||(*p>='a'&&*p<='z')){++p;++n;}
 return n>=3;
}
inline bool offset(const char*& p,unsigned maxHour){
 if(*p=='+'||*p=='-')++p;
 if(!number(p,0,maxHour))return false;
 if(*p==':'){++p;if(!number(p,0,59))return false;if(*p==':'){++p;if(!number(p,0,59))return false;}}
 return true;
}
inline bool rule(const char*& p){
 if(*p=='M'){
  ++p;if(!number(p,1,12)||*p++!='.'||!number(p,1,5)||*p++!='.'||!number(p,0,6))return false;
 }else if(*p=='J'){++p;if(!number(p,1,365))return false;}
 else if(!number(p,0,365))return false;
 if(*p=='/'){++p;if(!offset(p,24))return false;}
 return true;
}
}
// POSIX TZ strings, with explicit rules when daylight saving is used. No
// filesystem zone database (e.g. America/Phoenix) is needed on the ESP32.
inline bool validTimeZone(const char* value,size_t capacity){
 if(!memchr(value,0,capacity))return false;
 using namespace time_zone_detail;
 const char* p=value;
 if(!name(p)||!offset(p,24))return false;
 if(!*p)return true;
 if(!name(p))return false;
 if(*p!=','&&!offset(p,24))return false;
 if(*p++!=','||!rule(p)||*p++!=','||!rule(p))return false;
 return !*p;
}
}
