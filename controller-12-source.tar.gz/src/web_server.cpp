#ifdef COVER_WEB_CONTROL
#include "web_server.h"
#include "firmware_version.h"
#include "web_control.h"
#include "diagnostics.h"
#include "debug_response.h"
#include "failure_response.h"
#include "servo_support_response.h"
#include "ota_service.h"
#include "browser_ota.h"
#include "update_capabilities.h"
#include <memory>
#include "network_setup.h"
#include "alpaca_client.h"
#include "manual_stow.h"
#include "alpaca_telemetry.h"
#include "seestar_power.h"
#include "telescope_arm.h"
#include "close_dry_run.h"
#include <WiFi.h>
#include <WebServer.h>
#include "bounded_web_server.h"
#include <esp_system.h>
#include "generated_ui.h"
namespace cover {
namespace {
BoundedWebServer server;
String token;
DebugReadBudget debugReadBudget;
String otaSnapshot(){
 return otaStatusJson();
}
struct HeartbeatHttp {
 uint32_t client=0,seq=0,rx=0,browser=0,generation=0,sendGap=0,timerGap=0,skipped=0,rtt=0,statusAge=0;
 bool queued=false;
};
HeartbeatHttp heartbeatHttp[64];unsigned heartbeatNext=0,heartbeatCount=0;

bool stowLocked=false,stowPending=false;
uint32_t stowRequestedAt=0;
String stowMessage="No stow test requested";
CloseDryRun dryRun;
bool dryRunRequested=false;
bool authorized(uint32_t& client) {
#ifdef COVER_WEB_READ_ONLY
 if(server.method()!=HTTP_GET){server.send(403,"text/plain","Read-only test firmware: controller and telescope commands disabled");return false;}
#endif
 if(server.header("X-Cover-Token")!=token){server.send(403,"text/plain","Reload the tool page");return false;}
 String id=server.header("X-Cover-Client");
 if(id.length()==0 || id.length()>9){server.send(400,"text/plain","Invalid client");return false;}
 for(unsigned i=0;i<id.length();++i)if(!isDigit(id[i])){server.send(400,"text/plain","Invalid client");return false;}
 client=strtoul(id.c_str(),nullptr,10);
 if(!client){server.send(400,"text/plain","Invalid client");return false;}return true;
}
uint32_t traceNumber(const char* name) {
 String value=server.arg(name);
 if(value.length()==0 || value.length()>9)return 0;
 for(unsigned i=0;i<value.length();++i)if(!isDigit(value[i]))return 0;
 return strtoul(value.c_str(),nullptr,10);
}
uint32_t metricsNumber(const char* key){
 const String value=server.arg(key);if(!value.length() || value.length()>10)return 0;
 uint64_t parsed=0;for(unsigned i=0;i<value.length();++i){if(!isDigit(value[i]))return 0;parsed=parsed*10+value[i]-'0';}
 return parsed<=UINT32_MAX?uint32_t(parsed):0;
}
void metricsRequest(MetricsRequest request){
 uint32_t client=0;if(!authorized(client))return;
 if(networkPortalRequest(server) || !betaAcknowledged()){
  server.send(403,"text/plain","Metrics require acknowledged home-network access");return;
 }
 const uint32_t generation=metricsNumber("generation");
 if(server.arg("boot_id")!=diagnosticsBootId() || !generation){server.send(409,"text/plain","Metrics session changed; reopen the panel");return;}
 if(!requestMetrics(request,client,generation,metricsNumber("observed_uptime_ms"))){
  server.send(409,"text/plain","Metrics subscription expired, stale or full; reopen the panel");return;
 }
 const auto status=runtimeDiagnostics();server.sendHeader("Cache-Control","no-store");
 server.send(200,"application/json",String("{\"accepted\":true,\"state\":\"")+metricsPhaseName(status.phase)+"\",\"viewers\":"+status.viewers+"}");
}
uint32_t manualClient=0,manualEnabledAt=0;
void command(WebCommandType type,bool /*dashboard*/=false) {
 // The open setup interface must not control the mechanism. Stop remains
 // available, but heartbeat cannot sustain motion from an AP client.
 if(networkPortalRequest(server) && type!=WebCommandType::Stop){
  server.send(403,"text/plain","Setup hotspot is configuration-only; use home Wi-Fi for cover controls");return;
 }
 uint32_t client=0;if(!authorized(client))return;
 if(!betaAcknowledged() && type!=WebCommandType::Stop){server.send(403,"text/plain","Accept the beta notice first");return;}
 if((stowLocked || telescopeArmStatus().locked || emergencyShutdownLocked()) && type!=WebCommandType::Stop){server.send(409,"text/plain","Telescope operation interlock active");return;}
 const uint32_t generation=metricsNumber("control_generation");
 const bool automatic=type==WebCommandType::Stop && server.arg("automatic")=="yes";
 if(type!=WebCommandType::Stop && !(type==WebCommandType::Heartbeat?heartbeatRequestAllowed(generation):controlRequestAllowed(generation))){
  server.send(409,"text/plain","Maintenance active or stale controls; refresh controller status");return;
 }
 if(automatic && (!generation || !submitAutomaticStop(client,generation))){server.send(409,"text/plain","Automatic Stop belongs to an old control generation");return;}
 if(automatic){server.send(202,"text/plain","Automatic Stop queued");return;}
 auto s=webStatus();
 const bool manual=type==WebCommandType::ManualJogPlus || type==WebCommandType::ManualJogMinus;
 if(manual && (manualClient!=client || millis()-manualEnabledAt>=900000)){
  server.send(403,"text/plain","Enable Manual Control and acknowledge the damage warning again");return;
 }
 if(manual && (!s.manualReady || s.moving || strcmp(s.state,"FAULT")==0)){server.send(409,"text/plain","Servo not ready or already moving; inspect and clear any fault first");return;}
 const bool manualClose=type==WebCommandType::Close && server.arg("override")=="yes";
 if(manualClose && (server.arg("stowed")!="yes" || manualStowContradicted(alpacaStatus(),millis()))){
  server.send(409,"text/plain","Manual override requires visual stow confirmation and no fresh unsafe telescope report");return;
 }
 const bool checkedClose=type==WebCommandType::Close && !manualClose && alpacaMonitoringConfigured();
 if(checkedClose && !alpacaStatus().stowedCandidate(millis())){
  server.send(409,"text/plain","Close requires fresh confirmed telescope stow");return;
 }
 if(type==WebCommandType::Close && !checkedClose && server.arg("stowed")!="yes"){
  server.send(409,"text/plain","Confirm the telescope is manually stowed before closing");return;
 }
 if(networkSetupBusy() && type!=WebCommandType::Stop && type!=WebCommandType::Heartbeat){server.send(409,"text/plain","Network setup in progress");return;}
 if(type==WebCommandType::JogPlus || type==WebCommandType::JogMinus || type==WebCommandType::Open || type==WebCommandType::Close) {
  if(server.arg("clear")!="yes" || !s.ready || s.moving){server.send(409,"text/plain","Not ready or path not confirmed clear");return;}
 }
 if((type==WebCommandType::Open || type==WebCommandType::Close) && (!s.calibrated || s.dirty)) {server.send(409,"text/plain","Save valid calibration first");return;}
 if(type==WebCommandType::Recover && (server.arg("inspect")!="yes" || s.moving || s.holding || (s.ready && strcmp(s.state,"FAULT")!=0))) {
  server.send(409,"text/plain","Inspect and support the mechanism; recovery requires idle startup failure or fault");return;
 }
 if(type==WebCommandType::TorqueTest && (server.arg("supported")!="yes" || s.moving || s.holding || !s.torqueValid || s.torque)){
  server.send(409,"text/plain","Torque test requires supported cover, idle controller and verified torque OFF");return;
 }
 const bool jog=manual || type==WebCommandType::JogPlus || type==WebCommandType::JogMinus;
 if(jog && !manual && alpacaMonitoringConfigured() && !alpacaStatus().stowedCandidate(millis())){
  server.send(409,"text/plain","Calibration movement requires fresh telescope stow");return;
 }
 uint16_t step=100;
 if(jog && server.hasArg("step")){
  const String value=server.arg("step");
  if(value!="10" && value!="100" && value!="500"){server.send(400,"text/plain","Choose 10, 100 or 500 counts");return;}
  step=value.toInt();
 }
 if(jog && step>s.jogStepLimit){server.send(409,"text/plain","This firmware limits jogs to 100 counts per step");return;}
 const bool retainTorque=jog && server.arg("hold")=="yes";
 if(s.holding && type!=WebCommandType::Stop && type!=WebCommandType::Heartbeat &&
    (!jog || !retainTorque || s.owner!=client)) {
  server.send(409,"text/plain","Holding: only owner may jog; support cover before Stop / release");return;
 }
#ifdef COVER_REFERENCE_PROBE
 if(type==WebCommandType::ProbeReference || type==WebCommandType::RestoreReference){
#ifdef COVER_MULTITURN_PROBE
  const char* confirmation=type==WebCommandType::ProbeReference?"locked-multiturn-0-28":"locked-factory-4095-12";
#else
  const char* confirmation=type==WebCommandType::ProbeReference?"locked-offset-1328":"locked-offset-85";
#endif
  if(server.arg("confirm")!=confirmation || server.arg("detached")!="yes" || server.arg("clear")!="yes" ||
     (type==WebCommandType::ProbeReference && (!s.ready || !s.teaching)) || s.moving || s.holding || !s.torqueValid || s.torque){
   server.send(409,"text/plain","Commissioning requires explicit approval, detached clear shaft and teaching with torque OFF");return;
  }
 }
#endif
 const bool calibration=type==WebCommandType::CaptureOpen || type==WebCommandType::CaptureClosed || type==WebCommandType::SetLimits || type==WebCommandType::BeginTeaching || type==WebCommandType::SaveCalibration || type==WebCommandType::SetProfile || type==WebCommandType::DiscardCalibration || type==WebCommandType::SetDirection;
 uint16_t minimum=0,maximum=0;MotionProfile profile;int8_t openingDirection=0;
 if(calibration) {
  const bool startupLimits=((type==WebCommandType::SetLimits || type==WebCommandType::BeginTeaching) && s.calibrationOnly) ||
   ((type==WebCommandType::SetLimits || type==WebCommandType::BeginTeaching || type==WebCommandType::SetProfile) && strcmp(s.state,"FAULT")==0 && server.arg("inspect")=="yes");
  if(server.arg("calibrate")!="yes" || (!s.ready && !startupLimits) || s.moving || !s.torqueValid || s.torque) {server.send(409,"text/plain","Unlock calibration; require ready, idle, torque OFF");return;}
  if(type==WebCommandType::SetLimits) {
   String lo=server.arg("minimum"),hi=server.arg("maximum");
   bool valid=lo.length()>0 && lo.length()<=4 && hi.length()>0 && hi.length()<=4;
   for(unsigned i=0;i<lo.length();++i)valid=valid && isDigit(lo[i]);
   for(unsigned i=0;i<hi.length();++i)valid=valid && isDigit(hi[i]);
   if(!valid || lo.toInt()<kAllowedMinimum || hi.toInt()>kAllowedMaximum || lo.toInt()>=hi.toInt()){server.send(400,"text/plain","Invalid mechanical limits (0-4095)");return;}
   minimum=lo.toInt();maximum=hi.toInt();
  }
 }
 if(type==WebCommandType::SetProfile){
  auto integer=[&](const char* key,uint32_t minimum,uint32_t maximum,uint32_t& result){
   const String value=server.arg(key);if(!value.length() || value.length()>5)return false;
   for(unsigned i=0;i<value.length();++i)if(!isDigit(value[i]))return false;
   result=strtoul(value.c_str(),nullptr,10);return result>=minimum && result<=maximum;
  };
  uint32_t opening,closing,jogSpeed,acceleration,timeout;
  if(!integer("open_speed",1,1600,opening) || !integer("close_speed",1,1600,closing) ||
     !integer("jog_speed",1,100,jogSpeed) || !integer("acceleration",1,100,acceleration) ||
     !integer("timeout_ms",500,30000,timeout)){
   server.send(400,"text/plain","Invalid motion profile; jog speed is limited to 100");return;
  }
  profile.openSpeed=opening;profile.closeSpeed=closing;profile.jogSpeed=jogSpeed;
  profile.acceleration=acceleration;profile.timeoutMs=timeout;
 }
 if(type==WebCommandType::BeginTeaching){
  if(server.arg("present")!="yes" || server.arg("supported")!="yes" || server.arg("stowed")!="yes" ||
     (alpacaMonitoringConfigured() && !alpacaStatus().stowedCandidate(millis()))){
   server.send(409,"text/plain","Confirm presence, supported mechanism and stowed telescope before teaching");return;
  }
 }
 if(type==WebCommandType::SetDirection){
  const String direction=server.arg("direction");
  if((direction!="1" && direction!="-1") || server.arg("observed")!="yes"){
   server.send(400,"text/plain","Observe small supervised movements and confirm the opening direction");return;
  }
  openingDirection=direction=="1"?1:-1;
 }
 const uint32_t seq=traceNumber(type==WebCommandType::Heartbeat?"seq":"request_id");
 const uint32_t received=millis();
 const bool queued=submitWebCommand(manualClose?WebCommandType::CloseManualStow:checkedClose?WebCommandType::CloseStowed:type,client,minimum,maximum,seq,retainTorque,step,profile,generation,openingDirection,type==WebCommandType::BeginTeaching && server.arg("retain_closed")=="yes",type==WebCommandType::BeginTeaching && server.arg("resume")=="yes");
 if(type==WebCommandType::Heartbeat) {
  auto& h=heartbeatHttp[heartbeatNext];h.client=client;h.seq=seq;h.rx=received;h.queued=queued;
  h.browser=traceNumber("b_ms");h.generation=traceNumber("gen");h.sendGap=traceNumber("send_gap");h.timerGap=traceNumber("timer_gap");
  h.skipped=traceNumber("skipped");h.rtt=traceNumber("prev_rtt");h.statusAge=traceNumber("status_age");
  heartbeatNext=(heartbeatNext+1)%64;if(heartbeatCount<64)++heartbeatCount;
  diagnosticLog("HB HTTP client=%lu seq=%lu rx_ms=%lu queued=%d b_ms=%lu gen=%lu send_gap=%lu timer_gap=%lu skipped=%lu prev_rtt=%lu status_age=%lu",
   (unsigned long)client,(unsigned long)seq,(unsigned long)received,queued,(unsigned long)traceNumber("b_ms"),(unsigned long)traceNumber("gen"),
   (unsigned long)traceNumber("send_gap"),(unsigned long)traceNumber("timer_gap"),(unsigned long)traceNumber("skipped"),
   (unsigned long)traceNumber("prev_rtt"),(unsigned long)traceNumber("status_age"));
  server.sendHeader("X-Heartbeat-Rx-Ms",String(received));
 }
 server.send(queued?202:503,"text/plain","Request queued; check status");
}
}
void serveWebUi(WebServer& web) {
 if(networkPortalRequest(web) && web.uri()!="/configuration"){
  web.sendHeader("Location","/configuration#configuration");web.send(302,"text/plain","");return;
 }
 web.sendHeader("Cache-Control","no-store");web.sendHeader("Content-Encoding","gzip");
 web.sendHeader("X-Frame-Options","DENY");web.sendHeader("X-Content-Type-Options","nosniff");
 web.send_P(200,"text/html",reinterpret_cast<const char*>(uiIndex),sizeof(uiIndex));
}
void beginWebServer() {
 char key[33];snprintf(key,sizeof(key),"%08lx%08lx%08lx%08lx",(unsigned long)esp_random(),(unsigned long)esp_random(),(unsigned long)esp_random(),(unsigned long)esp_random());token=key;
 beginNetworkSetup(server,token);
 const char* headers[]={"X-Cover-Token","X-Cover-Client","X-Ota-Nonce","X-Ota-Mac","Content-Type","Origin","X-Update-Session","X-Update-Key","X-Update-Boot"};server.collectHeaders(headers,9);
 registerOtaRoutes(server);
#ifdef COVER_BROWSER_OTA
 registerBrowserOtaRoutes(server);
#endif
 server.on("/api/session",HTTP_GET,[]{
  server.sendHeader("Cache-Control","no-store");
  server.send(200,"application/json","{\"token\":\""+token+"\",\"beta_accepted\":"+String(betaAcknowledged()?"true":"false")+
   ",\"setup_only\":"+String(networkPortalRequest(server)?"true":"false")+
#ifdef COVER_WEB_READ_ONLY
   ",\"read_only_test\":true"
#else
   ",\"read_only_test\":false"
#endif
   
#ifdef COVER_BROWSER_OTA
   +",\"browser_update\":"+browserOtaStatusJson()
#endif
   +",\"firmware_id\":\""+String(firmwareId())+"\",\"boot_id\":\""+String(diagnosticsBootId())+"\",\"firmware\":"+COVER_VERSION_JSON+",\"update_capabilities\":"+updateCapabilitiesJson()+"}");
 });
 server.on("/api/diagnostics/metrics/subscribe",HTTP_POST,[]{metricsRequest(MetricsRequest::Subscribe);});
 server.on("/api/diagnostics/metrics/renew",HTTP_POST,[]{metricsRequest(MetricsRequest::Renew);});
 server.on("/api/diagnostics/metrics/unsubscribe",HTTP_POST,[]{metricsRequest(MetricsRequest::Unsubscribe);});
 for(const char* path:{"/","/control","/calibration"})server.on(path,HTTP_GET,[]{serveWebUi(server);});
 server.on("/favicon.png",HTTP_GET,[]{server.sendHeader("Cache-Control","no-cache");server.send_P(200,"image/png",reinterpret_cast<const char*>(uiFavicon),sizeof(uiFavicon));});
 server.on("/favicon.ico",HTTP_GET,[]{server.sendHeader("Cache-Control","no-cache");server.send_P(200,"image/x-icon",reinterpret_cast<const char*>(uiFaviconIco),sizeof(uiFaviconIco));});
 server.on("/ui/styles.css",HTTP_GET,[]{server.sendHeader("Content-Encoding","gzip");server.sendHeader("Cache-Control","no-cache");server.send_P(200,"text/css",reinterpret_cast<const char*>(uiStyles),sizeof(uiStyles));});
 server.on("/ui/startup.js",HTTP_GET,[]{server.sendHeader("Content-Encoding","gzip");server.sendHeader("Cache-Control","no-store");server.send_P(200,"application/javascript",reinterpret_cast<const char*>(uiStartup),sizeof(uiStartup));});
 server.on("/ui/app.js",HTTP_GET,[]{server.sendHeader("Content-Encoding","gzip");server.sendHeader("Cache-Control","no-cache");server.send_P(200,"application/javascript",reinterpret_cast<const char*>(uiScript),sizeof(uiScript));});
 server.on("/ui/theme.js",HTTP_GET,[]{server.sendHeader("Content-Encoding","gzip");server.sendHeader("Cache-Control","no-cache");server.send_P(200,"application/javascript",reinterpret_cast<const char*>(uiTheme),sizeof(uiTheme));});
 server.on("/api/dashboard/open",HTTP_POST,[]{command(WebCommandType::Open,true);});
 server.on("/api/dashboard/close",HTTP_POST,[]{command(WebCommandType::Close,true);});
 // Retired telescope-control endpoints reject stale pages and direct API clients.
 for(const char* path:{"/api/emergency/start","/api/emergency/finish",
     "/api/telescope/arm/open","/api/telescope/arm/close","/api/telescope/arm/finish",
     "/api/alpaca/stow","/api/alpaca/close-dry-run","/api/alpaca/stow/finish"})
  server.on(path,HTTP_POST,[]{server.send(410,"text/plain","Telescope control removed. Use the Seestar app; this controller only monitors telescope status.");});
 server.on("/api/alpaca/status",HTTP_GET,[]{
  auto s=alpacaStatus();const auto test=alpacaStowStatus();const uint32_t now=millis();
  const auto cover=webStatus();
  const bool closeAuthorized=s.stowedCandidate(now) && !stowLocked && !telescopeArmStatus().locked && !emergencyShutdownLocked() && !networkSetupBusy() && betaAcknowledged() &&
   cover.ready && cover.calibrated && !cover.dirty && !cover.moving && !cover.holding &&
   cover.positionValid && now-cover.positionAt<1500;
  auto value=[&](bool v){return s.valid?String(v?"true":"false"):String("null");};
  String json="{\"enabled\":"+String(s.enabled?"true":"false")+",\"read_only\":"+String(s.readOnly?"true":"false")+",\"polling_read_only\":"+String(s.readOnly?"true":"false")+",\"valid\":"+String(s.valid?"true":"false")+
   ",\"connected\":"+value(s.connected)+",\"can_find_home\":"+value(s.canFindHome)+",\"at_home\":"+value(s.atHome)+
   ",\"slewing\":"+value(s.slewing)+",\"tracking\":"+value(s.tracking)+",\"sequence\":"+String(s.sequence)+
   ",\"age_ms\":"+(s.sequence?String(now-s.sampledAt):String("null"))+",\"stowed_observation\":"+String(s.stowedCandidate(now)?"true":"false")+
   ",\"close_authorized\":"+String(closeAuthorized?"true":"false")+",\"error\":\""+String(alpaca::errorName(s.error))+"\",\"driver_error\":"+String(s.driverError)+"}";
  json.remove(json.length()-1);
  json+=",\"failed_request\":\""+String(s.failure.request)+"\",\"request_ms\":"+String(s.failure.elapsedMs)+",\"failure_age_ms\":"+String(now-s.failure.at)+"}";
  json.remove(json.length()-1);
  json+=",\"stow_locked\":"+String(stowLocked?"true":"false")+",\"stow_pending\":"+String(stowPending?"true":"false")+
   ",\"stow_phase\":\""+String(alpaca::stowPhaseName(test.phase))+"\",\"stow_error\":\""+String(alpaca::errorName(test.error))+"\",\"stow_operation\":"+String(test.operation)+
   ",\"stow_message\":\""+stowMessage+"\"}";
  json.remove(json.length()-1);
  const auto telemetry=alpacaTelemetry();
  auto metric=[&](const char* key,const alpaca::TelemetrySample& sample,bool boolean=false){
   const bool valid=sample.fresh(now); // Display age is independent of motion clearance.
   json+=",\""+String(key)+"\":"+(valid?(boolean?String(sample.value!=0?"true":"false"):String(sample.value,2)):String("null"));
   json+=",\""+String(key)+"_age_ms\":"+(valid?String(now-sample.at):String("null"));
   json+=",\""+String(key)+"_last_value\":"+(sample.hasValue?(boolean?String(sample.value!=0?"true":"false"):String(sample.value,2)):String("null"));
   json+=",\""+String(key)+"_last_age_ms\":"+(sample.hasValue?String(now-sample.at):String("null"));
   json+=",\""+String(key)+"_error\":\""+String(alpaca::errorName(sample.error))+"\"";
  };
  metric("altitude",telemetry.altitude);metric("azimuth",telemetry.azimuth);metric("camera_state",telemetry.cameraState);
  metric("camera_temperature",telemetry.cameraTemperature);metric("heater_on",telemetry.heater,true);
  const auto power=seestarPowerStatus();const bool powerFresh=power.fresh(now);
  json+=",\"power_telemetry_supported\":"+String(power.configured?"true":"false")+",\"power_valid\":"+String(powerFresh?"true":"false");
  json+=",\"power_retrying\":"+String(power.retrying?"true":"false")+",\"power_paused\":"+String(power.paused?"true":"false");
  json+=",\"power_age_ms\":"+(power.valid?String(now-power.sampledAt):String("null"));
  json+=",\"battery_percent\":"+(powerFresh&&power.batteryPercent>=0?String(power.batteryPercent):String("null"));
  json+=",\"external_power\":"+(powerFresh&&power.externalPowerValid?String(power.externalPower?"true":"false"):String("null"));
  json+=",\"charging_state\":"+(powerFresh&&power.chargingState[0]?String("\"")+power.chargingState+"\"":String("null"));
  json+=",\"battery_temperature\":"+(powerFresh&&power.batteryTemperatureValid?String(power.batteryTemperature,1):String("null"));
  json+=",\"battery_overtemp\":"+(powerFresh&&power.batteryOvertempValid?String(power.batteryOvertemp?"true":"false"):String("null"))+"}";
  json.remove(json.length()-1);
  json+=",\"dry_run\":"+String(dryRunRequested?"true":"false")+",\"dry_run_phase\":\""+String(dryRun.name())+"\",\"dry_run_message\":\""+String(dryRun.reason())+"\",\"cover_checks_simulated\":"+String(dryRunRequested?"true":"false")+"}";
  const auto arm=telescopeArmStatus();json.remove(json.length()-1);
  json+=",\"arm_supported\":"+String(arm.supported?"true":"false")+",\"arm_locked\":"+String(arm.locked?"true":"false")+
   ",\"arm_phase\":\""+String(armPhaseName(arm.phase))+"\",\"arm_opening\":"+String(arm.opening?"true":"false")+
   ",\"arm_operation\":"+String(arm.operation)+",\"arm_reason\":\""+String(arm.reason)+"\"}";
  server.sendHeader("Cache-Control","no-store");server.send(200,"application/json",json);
 });
 // Read-only retained evidence; no additional servo reads or motion commands.
 server.on("/api/heartbeat/trace",HTTP_GET,[]{
  if(networkPortalRequest(server)){server.send(403,"text/plain","Detailed diagnostics require home Wi-Fi");return;}
  const auto s=webStatus();const auto& f=s.heartbeatAtFault;
  String json="{\"boot_id\":\""+String(diagnosticsBootId())+"\",\"firmware_id\":\""+String(firmwareId())+"\",\"fault_at_ms\":"+String(s.heartbeatFaultAt)+",\"fault_age_ms\":"+String(s.heartbeatFaultAge)+
   ",\"last_worker_before_fault\":{\"client\":"+String(f.client)+",\"seq\":"+String(f.sequence)+",\"rx_ms\":"+String(f.received)+",\"processed_ms\":"+String(f.processed)+",\"previous_age_ms\":"+String(f.previousAge)+",\"renewed\":"+String(f.renewed?"true":"false")+"},\"http\":[";
  for(unsigned i=0;i<heartbeatCount;++i){const auto& h=heartbeatHttp[(heartbeatNext+64-heartbeatCount+i)%64];if(i)json+=",";
   json+="{\"client\":"+String(h.client)+",\"seq\":"+String(h.seq)+",\"rx_ms\":"+String(h.rx)+",\"queued\":"+String(h.queued?"true":"false")+
    ",\"b_ms\":"+String(h.browser)+",\"gen\":"+String(h.generation)+",\"send_gap\":"+String(h.sendGap)+",\"timer_gap\":"+String(h.timerGap)+",\"skipped\":"+String(h.skipped)+",\"prev_rtt\":"+String(h.rtt)+",\"status_age\":"+String(h.statusAge)+"}";
  }
  json+="]}";server.sendHeader("Cache-Control","no-store");server.send(200,"application/json",json);
 });
 server.on("/api/motion/trace",HTTP_GET,[]{
  if(networkPortalRequest(server)){server.send(403,"text/plain","Detailed diagnostics require home Wi-Fi");return;}
  const auto s=webStatus();const auto& t=s.motionTrace;
  String json="{\"boot_id\":\""+String(diagnosticsBootId())+"\",\"firmware_id\":\""+String(firmwareId())+"\",\"operation\":"+String(t.operation)+",\"state\":\""+String(s.state)+"\",\"fault\":\""+String(s.fault)+"\",\"target\":"+String(t.target)+",\"tolerance\":"+String(t.tolerance)+
   ",\"valid_reads\":"+String(t.validReads)+",\"failed_reads\":"+String(t.failedReads)+",\"last_valid_ms\":"+String(t.lastValidMs)+",\"last_position\":"+String(t.lastPosition)+",\"settled_samples\":"+String(t.settled)+",\"samples\":[";
  for(unsigned i=0;i<t.count;++i){const auto& sample=t.samples[(t.next+MotionTrace::capacity-t.count+i)%MotionTrace::capacity];
   if(i)json+=",";
   json+="{\"ms\":"+String(sample.elapsedMs)+",\"position\":"+(sample.valid?String(sample.position):String("null"))+",\"disposition\":\""+String(dispositionName(sample.disposition))+"\"}";
  }
  json+="],\"started_at_ms\":"+String(t.startedAt)+",\"start_position\":"+String(t.startPosition)+",\"speed_counts_s\":"+String(t.speed)+
   ",\"acceleration\":"+String(t.acceleration)+",\"timeout_ms\":"+String(t.timeoutMs)+",\"rejected_reads\":"+String(t.rejectedReads)+"}";
  server.sendHeader("Cache-Control","no-store");server.send(200,"application/json",json);
 });
 server.on("/api/diagnostics/servo",HTTP_GET,[]{
  if(networkPortalRequest(server)){server.send(403,"text/plain","Detailed diagnostics require home Wi-Fi");return;}
  const auto status=webStatus();
  if(status.moving || status.holding || maintenanceStatus().lease.owner==MaintenanceOwner::Ota || !debugReadBudget.take(millis())){
   server.sendHeader("Retry-After","1");server.send(503,"text/plain","Diagnostics busy");return;
  }
  std::unique_ptr<ServoSupportSnapshot> snapshot(new(std::nothrow) ServoSupportSnapshot);
  std::unique_ptr<char[]> response(new(std::nothrow) char[kServoSupportResponseBytes+1]);
  if(!snapshot || !response){server.send(503,"text/plain","Diagnostics unavailable");return;}
  copyServoSupport(*snapshot);
  const size_t size=writeServoSupport(response.get(),*snapshot,diagnosticsBootId(),firmwareId());
  if(!size){server.send(503,"text/plain","Diagnostics unavailable");return;}
  server.sendHeader("Cache-Control","no-store");server.setContentLength(size);
  server.send(200,"application/json","");server.sendContent(response.get(),size);
 });
 server.on("/api/manual/enable",HTTP_POST,[]{
  uint32_t client=0;if(!authorized(client))return;
  if(!controlRequestAllowed(metricsNumber("control_generation"))){server.send(409,"text/plain","Maintenance active or stale controls");return;}
  if(networkPortalRequest(server) || !betaAcknowledged()){server.send(403,"text/plain","Use home Wi-Fi and accept beta notice");return;}
  if(server.arg("acknowledge")!="equipment-damage"){server.send(400,"text/plain","Acknowledge equipment damage warning");return;}
  const auto s=webStatus();
  if(s.moving || s.holding || networkSetupBusy()){server.send(409,"text/plain","Finish current operation first");return;}
  manualClient=client;manualEnabledAt=millis();debugLog("MANUAL enabled client=%lu; equipment damage acknowledged",(unsigned long)client);
  server.send(200,"text/plain","Manual control enabled for this browser for 15 minutes");
 });
 server.on("/api/manual/disable",HTTP_POST,[]{
  uint32_t client=0;if(!authorized(client))return;
  if(manualClient==client){manualClient=0;
   if(server.arg("automatic")=="yes")submitAutomaticStop(client,metricsNumber("control_generation"));
   else submitWebCommand(WebCommandType::Stop,client);
  }
  server.send(200,"text/plain","Manual control disabled");
 });
 server.on("/api/manual/jog-plus",HTTP_POST,[]{command(WebCommandType::ManualJogPlus);});
 server.on("/api/manual/jog-minus",HTTP_POST,[]{command(WebCommandType::ManualJogMinus);});
 server.on("/api/debug",HTTP_GET,[]{
  if(networkPortalRequest(server)){server.send(403,"text/plain","Detailed diagnostics require home Wi-Fi");return;}
  uint32_t after=0,epoch=0;
  if((server.hasArg("after") && !debugCursor(server.arg("after").c_str(),after)) ||
     (server.hasArg("sequence_epoch") && !debugCursor(server.arg("sequence_epoch").c_str(),epoch))){server.send(400,"text/plain","Invalid cursor");return;}
  const auto status=webStatus();
  if(status.moving || status.holding || maintenanceStatus().lease.owner==MaintenanceOwner::Ota || !debugReadBudget.take(millis())){
   server.sendHeader("Retry-After","1");server.send(503,"application/json","{\"busy\":true,\"retry_after_ms\":1000}");return;
  }
  DebugEnvelope envelope;envelope.window=debugLogWindow();envelope.after=after;
  envelope.bootId=diagnosticsBootId();envelope.firmware=firmwareId();
  envelope.reset=(server.hasArg("boot_id") && server.arg("boot_id")!=envelope.bootId) ||
   (server.hasArg("sequence_epoch") && epoch!=envelope.window.sequenceEpoch) || after>envelope.window.newest;
  envelope.metricsActive=runtimeDiagnostics().available;
  std::unique_ptr<char[]> response(new(std::nothrow) char[kDebugResponseBytes+1]);
  if(!response){server.send(503,"text/plain","Diagnostics response unavailable");return;}
  const size_t size=writeDebugResponse(response.get(),envelope,[&](uint32_t cursor,DebugEntry& entry){
   return nextDebugEntryInWindow(cursor,envelope.window.sequenceEpoch,entry);
  });
  if(!size){server.send(503,"text/plain","Diagnostics response unavailable");return;}
  server.sendHeader("Cache-Control","no-store");server.setContentLength(size);server.send(200,"application/json","");server.sendContent(response.get(),size);
 });
 server.on("/api/debug/retained",HTTP_GET,[]{
  if(networkPortalRequest(server)){server.send(403,"text/plain","Detailed diagnostics require home Wi-Fi");return;}
  const auto status=webStatus();
  if(status.moving || status.holding || maintenanceStatus().lease.owner==MaintenanceOwner::Ota || !debugReadBudget.take(millis())){
   server.sendHeader("Retry-After","1");server.send(503,"text/plain","Diagnostics busy");return;
  }
  std::unique_ptr<char[]> response(new(std::nothrow) char[kFailureResponseBytes+1]);
  if(!response){server.send(503,"text/plain","Diagnostics unavailable");return;}
  const auto record=retainedFailureSummary();
  const size_t size=writeFailureSummary(response.get(),record,diagnosticsBootId(),resetReasonName());
  if(!size){server.send(503,"text/plain","Diagnostics unavailable");return;}
  server.sendHeader("Cache-Control","no-store");server.setContentLength(size);
  server.send(200,"application/json","");server.sendContent(response.get(),size);
 });
 server.on("/api/ota/status",HTTP_GET,[]{
  if(networkPortalRequest(server)){server.send(403,"text/plain","Detailed diagnostics require home Wi-Fi");return;}
  server.sendHeader("Cache-Control","no-store");server.send(200,"application/json",otaSnapshot());
 });
 server.on("/api/status",HTTP_GET,[]{otaMemoryBoundary(OtaMemoryStage::StatusStart);auto s=webStatus();String json="{\"state\":\""+String(s.state)+"\",\"fault\":\""+String(s.fault)+"\",\"ready\":"+(s.ready?"true":"false")+",\"moving\":"+(s.moving?"true":"false")+",\"owner\":"+String(s.owner)+",\"position\":"+(s.positionValid?String(s.position):"null")+",\"age_ms\":"+String(millis()-s.positionAt)+",\"torque\":"+(s.torqueValid?(s.torque?"true":"false"):"null")+",\"wifi\":\""+(WiFi.status()==WL_CONNECTED?String("Home Wi-Fi"):String("Setup network"))+"\"}";json.remove(json.length()-1);
 json+=",\"manual_ready\":"+String(s.manualReady?"true":"false");
 json+=",\"assembly_opening_direction\":"+String(kAssemblyOpeningDirection);
 json+=",\"calibration_only\":"+String(s.calibrationOnly?"true":"false")+",\"calibrated\":"+String(s.calibrated?"true":"false")+",\"dirty\":"+String(s.dirty?"true":"false")+",\"notice\":\""+String(s.notice)+"\",\"minimum\":"+String(s.activeMinimum)+",\"maximum\":"+String(s.activeMaximum)+",\"draft_minimum\":"+String(s.draft.minimum)+",\"draft_maximum\":"+String(s.draft.maximum)+",\"draft_open\":"+(s.draft.hasOpen?String(s.draft.open):String("null"))+",\"draft_closed\":"+(s.draft.hasClosed?String(s.draft.closed):String("null"))+",\"open\":"+(s.calibrated?String(s.saved.open):String("null"))+",\"closed\":"+(s.calibrated?String(s.saved.closed):String("null"))+"}";
 json.remove(json.length()-1);json+=",\"wifi_power_save\":"+String(WiFi.getSleep()?"true":"false")+",\"wifi_rssi\":"+String(WiFi.RSSI())+",\"target\":"+String(s.target)+",\"motion_ms\":"+String(s.motionMs)+",\"heartbeat_age_ms\":"+String(s.heartbeatAgeMs)+",\"timeout_ms\":"+String(s.timeoutMs)+"}";
 json.remove(json.length()-1);json+=",\"holding\":"+String(s.holding?"true":"false")+",\"uptime_ms\":"+String(millis())+",\"free_heap\":"+String(ESP.getFreeHeap())+",\"min_free_heap\":"+String(ESP.getMinFreeHeap())+",\"reset_reason\":\""+String(resetReasonName())+"\",\"firmware_id\":\""+String(firmwareId())+"\",\"max_heartbeat_gap_ms\":"+String(s.maxHeartbeatGapMs)+"}";
 json.remove(json.length()-1);json+=",\"settings_offline_allowed\":"+String(s.settingsOfflineAllowed?"true":"false")+"}";
 json.remove(json.length()-1);
 const auto resources=networkPortalRequest(server)?RuntimeDiagnostics{}:runtimeDiagnostics();
 json+=",\"resources\":{\"state\":\""+String(metricsPhaseName(resources.phase))+"\",\"available\":"+String(resources.available?"true":"false")+
  ",\"viewers\":"+String(resources.viewers)+",\"epoch\":"+String(resources.epoch)+",\"boot_id\":\""+String(diagnosticsBootId())+"\"";
 if(resources.available){
 json+=",\"sampled_at_ms\":"+String(resources.sampledAt)+",\"age_ms\":"+String(millis()-resources.sampledAt)+
  ",\"internal_free_heap_bytes\":"+String(resources.internalFreeHeap)+
  ",\"internal_min_free_heap_bytes\":"+String(resources.internalMinimumFreeHeap)+
  ",\"internal_largest_free_block_bytes\":"+String(resources.internalLargestFreeBlock)+
  ",\"debug_log_available\":"+String(resources.debugLogAvailable?"true":"false")+
  ",\"log_dropped\":"+String(resources.logDropped)+",\"web_gap_ms\":"+String(resources.webGapMs)+",\"motion_gap_ms\":"+String(resources.motionGapMs)+
  ",\"ring_overwrites\":"+String(resources.ringOverwrites)+",\"log_truncated\":"+String(resources.logTruncated)+",\"suppressed_trace\":"+String(resources.suppressedTrace)+
  ",\"debug_log_capacity\":"+String(kDebugCapacity)+",\"task_stacks\":{";
 for(unsigned i=0;i<kDiagnosticTaskCount;++i){
  if(i)json+=',';
  json+='"';json+=diagnosticTaskName(static_cast<DiagnosticTask>(i));json+="\":";
  const auto& stack=resources.stacks[i];
  if(!stack.available){json+="null";continue;}
  json+="{\"min_free_bytes\":"+String(stack.minimumFreeBytes)+",\"sample_age_ms\":"+String(millis()-stack.sampledAt)+"}";
 }
 json+="},\"cpu_load\":{\"method\":\"timer_sampled\",\"available\":"+String(resources.cpu.available?"true":"false")+
  ",\"window_ms\":"+String(resources.cpu.windowMs)+",\"age_ms\":"+(resources.cpu.available?String(millis()-resources.cpu.sampledAt):String("null"));
 const auto& cpu=resources.cpu;
 json+=",\"core0_percent\":"+(cpu.available?String(cpu.busyPermille[0]/10.0f,1):String("null"))+
  ",\"core1_percent\":"+(cpu.available?String(cpu.busyPermille[1]/10.0f,1):String("null"))+
  ",\"average_percent\":"+(cpu.available?String((cpu.busyPermille[0]+cpu.busyPermille[1])/20.0f,1):String("null"))+"}";
 const auto& w=resources.wifi;
 json+=",\"wifi\":{\"connected\":"+String(w.connected?"true":"false")+
  ",\"disconnects\":"+String(w.disconnects)+",\"reconnects\":"+String(w.reconnects)+
  ",\"last_reason\":"+(w.hasDisconnect?String(w.reason):String("null"))+
  ",\"last_reason_name\":\""+String(w.hasDisconnect?WiFi.disconnectReasonName(static_cast<wifi_err_reason_t>(w.reason)):"None")+"\""+
  ",\"last_disconnect_uptime_ms\":"+(w.hasDisconnect?String(w.lastDisconnectAt):String("null"))+
  ",\"current_outage_ms\":"+String(resources.wifiOutageMs)+",\"last_outage_ms\":"+String(w.lastOutageMs)+
  ",\"rssi\":"+(w.rssiValid?String(w.rssi):String("null"))+
  ",\"minimum_rssi\":"+(w.hasRssi?String(w.minimumRssi):String("null"))+
  ",\"alpaca_requests\":"+String(w.requests)+",\"alpaca_failures\":"+String(w.failures)+
  ",\"alpaca_timeouts\":"+String(w.timeouts)+",\"last_request_ms\":"+String(w.lastRequestMs)+
  ",\"max_request_ms\":"+String(w.maxRequestMs)+",\"packet_loss\":null,\"radio_retries\":null";

 json+="}";
 }
 json+="}";
 const auto maintenance=maintenanceStatus();
 json+=",\"control_generation\":"+String(maintenance.controlGeneration)+",\"maintenance\":{\"owner\":\""+maintenanceOwnerName(maintenance.lease.owner)+
  "\",\"phase\":\""+maintenancePhaseName(maintenance.phase)+"\",\"generation\":"+String(maintenance.lease.generation)+
  ",\"reason\":\""+maintenanceReasonName(maintenance.reason)+"\",\"locked\":"+String(maintenance.locked()?"true":"false")+"}";
 json+=",\"ota\":"+otaSnapshot();
 json+=",\"command_id\":"+String(s.commandId)+",\"command_client\":"+String(s.commandClient)+",\"command_ok\":"+String(s.commandOk?"true":"false");
#if defined(COVER_REFERENCE_PROBE) || defined(COVER_MULTITURN_STARTUP)
#ifdef COVER_MULTITURN_USB
 json+=",\"multiturn_startup\":{\"attempted\":"+String(s.referenceProbe.writeAttempted?"true":"false")+
#elif defined(COVER_MULTITURN_PROBE)
 json+=",\"multiturn_probe\":{\"attempted\":"+String(s.referenceProbe.writeAttempted?"true":"false")+
#else
 json+=",\"reference_probe\":{\"attempted\":"+String(s.referenceProbe.writeAttempted?"true":"false")+
#endif
  ",\"locked\":"+String(s.referenceProbe.lockConfirmed?"true":"false")+
  ",\"position_before\":"+(s.referenceProbe.positionBeforeValid?String(s.referenceProbe.positionBefore):String("null"))+",\"position_after\":"+(s.referenceProbe.positionAfterValid?String(s.referenceProbe.positionAfter):String("null"))+
  ",\"before_valid\":"+String(s.referenceProbe.beforeValid?"true":"false")+",\"after_valid\":"+String(s.referenceProbe.afterValid?"true":"false");
 for(unsigned side=0;side<2;++side){json+=side?",\"after\":[":",\"before\":[";for(unsigned n=0;n<40;++n){if(n)json+=",";json+=String(side?s.referenceProbe.after[n]:s.referenceProbe.before[n]);}json+="]";}json+="}";
#endif
 auto profileJson=[](const MotionProfile& p){return String("{\"open_speed\":")+p.openSpeed+",\"close_speed\":"+p.closeSpeed+",\"jog_speed\":"+p.jogSpeed+",\"acceleration\":"+p.acceleration+",\"timeout_ms\":"+p.timeoutMs+"}";};
 json+=",\"saved_minimum\":"+String(s.saved.minimum)+",\"saved_maximum\":"+String(s.saved.maximum);
 json+=",\"draft_profile\":"+profileJson(s.draft.profile)+",\"saved_profile\":"+profileJson(s.saved.profile);
 json+=",\"travel_schema\":5,\"rollover_supported\":"+String(s.rolloverSupported?"true":"false")+",\"teaching\":"+String(s.teaching?"true":"false")+",\"calibration_review\":"+String(s.calibrationReview?"true":"false");
 json+=",\"jog_step_limit\":"+String(s.jogStepLimit);
 json+=",\"reference_offset\":"+String(kApplicationReferenceOffset)+",\"saved_reference_offset\":"+String(s.saved.referenceOffset)+",\"draft_reference_offset\":"+String(s.draft.referenceOffset);
 json+=",\"circular\":"+String(s.saved.circular?"true":"false")+",\"draft_circular\":"+String(s.draft.circular?"true":"false");
 json+=",\"opening_direction\":"+String(s.saved.openingDirection)+",\"travel_counts\":"+String(s.saved.travelCounts);
 json+=",\"draft_direction\":"+String(s.draft.openingDirection)+",\"draft_travel_counts\":"+String(s.draft.travelCounts);
 json+=",\"review_closed_raw\":"+(s.calibrationReview?String(s.saved.closed):String("null"));
 json+=",\"review_open_raw\":"+(s.calibrationReview?String(s.saved.open):String("null"));
 int travel=0;const auto arc=calibrationArc(s.saved);
 const bool progress=s.calibrated && s.positionValid && millis()-s.positionAt<1500 && arc.progress(s.position,travel);
 json+=",\"actuator_travel_counts\":"+(progress?String(travel):String("null"));
 json+=",\"travel_percent\":"+(progress?String(100.0*travel/arc.length,1):String("null"));
 const bool telemetryFresh=s.telemetryValid && millis()-s.telemetryAt<15000;
 json+=",\"servo_voltage\":"+(telemetryFresh?String(s.voltageDecivolts/10.0f,1):String("null"));
 json+=",\"servo_temperature\":"+(telemetryFresh?String(s.temperatureC):String("null"));
 json+=",\"servo_load\":"+(telemetryFresh?String(s.relativeLoad):String("null"));
 json+=",\"servo_current_raw\":"+(telemetryFresh?String(s.currentRaw):String("null"));
 json+=",\"emergency\":{\"supported\":"+String(telescopeArmStatus().supported&&alpacaMonitoringConfigured()?"true":"false")+
  ",\"locked\":"+String(emergencyShutdownLocked()?"true":"false")+",\"active\":"+String(s.shutdown.active()?"true":"false")+
  ",\"operation\":"+String(s.shutdown.operation)+",\"stop_epoch\":"+String(emergencyStopEpoch())+",\"phase\":\""+shutdownPhaseName(s.shutdown.phase)+"\",\"message\":\""+s.shutdown.message+"\"";
 json+=",\"recovering\":"+String(s.shutdown.recovering?"true":"false")+",\"recoveries\":"+String(s.shutdown.recoveries);
 const uint32_t recoveryElapsed=millis()-s.shutdown.recoveryAt;
 json+=",\"recovery_remaining_ms\":"+String(s.shutdown.recovering&&recoveryElapsed<15000?15000-recoveryElapsed:0);
 const auto& d=s.shutdown.diagnostic;
 json+=",\"diagnostic\":";
 if(!d.sequence)json+="null";
 else json+=String("{\"sequence\":")+d.sequence+",\"at_ms\":"+d.at+",\"phase\":\""+shutdownPhaseName(d.phase)+
  "\",\"source\":\""+d.source+"\",\"request\":\""+d.detail.request+"\",\"error\":\""+d.detail.error+
  "\",\"driver_code\":"+String(d.detail.code)+",\"transaction\":"+d.detail.transaction+",\"request_ms\":"+d.detail.elapsedMs+",\"sample_age_ms\":"+d.sampleAgeMs+"}";
 json+="}}";
 otaMemoryBoundary(OtaMemoryStage::StatusBuilt,json.length());
 server.sendHeader("Cache-Control","no-store");server.send(200,"application/json",json);
 otaMemoryBoundary(OtaMemoryStage::StatusSent,json.length());});
 server.on("/api/jog-plus",HTTP_POST,[]{command(WebCommandType::JogPlus);});
 server.on("/api/jog-minus",HTTP_POST,[]{command(WebCommandType::JogMinus);});
 server.on("/api/open",HTTP_POST,[]{command(WebCommandType::Open);});
 server.on("/api/close",HTTP_POST,[]{command(WebCommandType::Close);});
 server.on("/api/calibration/open",HTTP_POST,[]{command(WebCommandType::CaptureOpen);});
 server.on("/api/calibration/closed",HTTP_POST,[]{command(WebCommandType::CaptureClosed);});
#ifdef COVER_REFERENCE_PROBE
#ifdef COVER_MULTITURN_PROBE
 server.on("/api/commission/multiturn/apply",HTTP_POST,[]{command(WebCommandType::ProbeReference);});
 server.on("/api/commission/multiturn/restore",HTTP_POST,[]{command(WebCommandType::RestoreReference);});
#else
 server.on("/api/commission/reference/probe",HTTP_POST,[]{command(WebCommandType::ProbeReference);});
 server.on("/api/commission/reference/restore",HTTP_POST,[]{command(WebCommandType::RestoreReference);});
#endif
#endif
 server.on("/api/calibration/begin",HTTP_POST,[]{command(WebCommandType::BeginTeaching);});
 server.on("/api/calibration/limits",HTTP_POST,[]{command(WebCommandType::SetLimits);});
 server.on("/api/calibration/direction",HTTP_POST,[]{command(WebCommandType::SetDirection);});
 server.on("/api/calibration/profile",HTTP_POST,[]{command(WebCommandType::SetProfile);});
 server.on("/api/calibration/discard",HTTP_POST,[]{command(WebCommandType::DiscardCalibration);});
 server.on("/api/calibration/save",HTTP_POST,[]{command(WebCommandType::SaveCalibration);});
 server.on("/api/heartbeat",HTTP_POST,[]{command(WebCommandType::Heartbeat);});
 server.on("/api/diagnostics/torque-test",HTTP_POST,[]{command(WebCommandType::TorqueTest);});
 server.on("/api/recover",HTTP_POST,[]{command(WebCommandType::Recover);});
 server.on("/api/stop",HTTP_POST,[]{command(WebCommandType::Stop);});
 server.onNotFound([]{
  if(networkPortalRequest(server) && server.method()==HTTP_GET && !server.uri().startsWith("/api/")){
   server.sendHeader("Location","http://"+WiFi.softAPIP().toString()+"/configuration");server.sendHeader("Cache-Control","no-store");server.send(302,"text/plain","");
  }else server.send(404,"text/plain","Not found");
 });server.begin();otaWebServiceReady(server.listening());
}
void pollWebServer() {
 if(stowPending){
  if(networkMaintenanceReady()){
   stowPending=false;
   const bool queued=requestAlpacaStow();
   stowMessage=queued?"Stow request submitted; cover remains locked":"Telescope test could not start; inspect then finish test";
   if(!queued && dryRunRequested)dryRun.cancel("Stow could not start");
  }else if(millis()-stowRequestedAt>3000){stowPending=false;stowMessage="Cover interlock failed: require torque OFF or confirmed disconnected servo";if(dryRunRequested)dryRun.cancel("Cover interlock timeout");}
 }
 if(dryRunRequested && !stowPending){
  const auto s=webStatus();
  const bool checks=stowLocked && networkMaintenanceReady() && s.calibrated && !s.dirty &&
   !s.ready && !s.positionValid && !s.torqueValid && !s.moving && !s.holding;
  const auto previous=dryRun.phase();
  dryRun.step(millis(),alpacaStowStatus(),alpacaStatus(),checks);
  if(previous!=dryRun.phase())diagnosticLog("CLOSE DRY RUN phase=%s reason=%s no_cover_command=true",dryRun.name(),dryRun.reason());
 }
 pollNetworkSetup();
 server.handleClient();
}
}
#endif
