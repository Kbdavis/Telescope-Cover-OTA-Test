#pragma once

// Deliberately unavailable to web/normal firmware. This commissioning profile
// is for the detached, supervised new servo captured on 2026-10-27 only.
#if !defined(COVER_FACTORY_MOTION_BENCH) || !defined(COVER_MOTION_BENCH) || defined(COVER_WEB_CONTROL)
#error "Factory profile is restricted to the isolated motion bench"
#endif

#include "servo_controller.h"
#include "servo_factory_profile.h"

namespace cover {
class FactoryBenchServo final : public ServoController {
 public:
  explicit FactoryBenchServo(Stream& bus) : ServoController(bus) {}
  ServoResult validateConfiguration() override {
    // All documented identity/configuration bytes must match the verified
    // backup, including firmware, mode, limits, phase and position offset.
    uint8_t observed[40];
    auto result = readConfigurationSnapshot(observed);
    if (!result) return result;
    return matchesCommissionedFactoryProfile(observed)
      ? ServoResult{} : ServoResult{ServoError::InvalidConfiguration};
  }
};
}
