#pragma once
#include <stdint.h>
#include <stdlib.h>

namespace cover {
constexpr int kEncoderPeriod = 4096;
// Legacy direct goals stay inside the linear half-turn gate. Circular
// commands require a separate hardware capability and an explicit bounded arc.
inline bool supportedDirectPath(int from, int to) {
 return from>=0 && from<kEncoderPeriod && to>=0 && to<kEncoderPeriod && abs(to-from)<kEncoderPeriod/2;
}

inline int wrapPosition(int value) {return (value%kEncoderPeriod+kEncoderPeriod)%kEncoderPeriod;}
// Only for consecutive stable feedback, never for choosing an endpoint path.
inline int encoderDelta(int from,int to) {
 int delta=to-from;
 if(delta>kEncoderPeriod/2)delta-=kEncoderPeriod;
 if(delta<-kEncoderPeriod/2)delta+=kEncoderPeriod;
 return delta;
}
// An explicit opening direction and taught length define the application arc.
// Circular arcs have a ten-count settling margin, not a full-turn safety range.
struct TravelArc {
 uint16_t closedRaw=0, length=0, minimumRaw=0, maximumRaw=0;
 bool circular=false;
 int8_t direction=0; // +1 increasing raw counts toward OPEN; -1 decreasing.
 int coordinate(int raw,int margin=10) const {
  const int value=direction*(raw-int(closedRaw));
  if(!circular)return value;
  const int positive=wrapPosition(value);
  return positive<=int(length)+margin?positive:positive-kEncoderPeriod;
 }
 int rawTarget(int travel) const {return circular?wrapPosition(int(closedRaw)+direction*travel):int(closedRaw)+direction*travel;}
 int minimum() const {return circular?-10:coordinate(direction>0?minimumRaw:maximumRaw);}
 int maximum() const {return circular?int(length)+10:coordinate(direction>0?maximumRaw:minimumRaw);}
 bool valid() const {
  return (direction==1 || direction==-1) && minimumRaw<maximumRaw && maximumRaw<kEncoderPeriod &&
   closedRaw>=minimumRaw && closedRaw<=maximumRaw && length>0 && length<kEncoderPeriod/2 &&
   (!circular || (minimumRaw==0 && maximumRaw==4095)) &&
   rawTarget(length)>=minimumRaw && rawTarget(length)<=maximumRaw;
 }
 bool contains(int raw) const {return valid() && raw>=minimumRaw && raw<=maximumRaw && (!circular || (coordinate(raw)>=minimum() && coordinate(raw)<=maximum()));}
 // Endpoint commands may recover inward from small post-release drift. This
 // does not widen ordinary jogging, mechanical bounds or target settling.
 bool endpointStartAllowed(int raw) const {
  return contains(raw) || (valid() && circular && raw>=minimumRaw && raw<=maximumRaw &&
   coordinate(raw,25)>=-25 && coordinate(raw,25)<=int(length)+25);
 }
 bool progress(int raw, int& travel) const {
  if(!contains(raw))return false;
  const int value=coordinate(raw);
  if(value<0 || value>length)return false; // Never clamp into an endpoint.
  travel=value;return true;
 }
};

struct TravelTiming {uint32_t nominalMs=0, expectedMs=0, recommendedMs=0;};
// Planning estimate only. Acceleration allowance is deliberately heuristic,
// pending loaded bench measurements; it is not a calibrated ST3215 unit map.
inline TravelTiming travelTiming(uint16_t counts,uint16_t speed,uint8_t acceleration) {
 TravelTiming t;
 if(!speed || !acceleration)return t;
 t.nominalMs=(uint32_t(counts)*1000+speed-1)/speed;
 t.expectedMs=t.nominalMs+(20000U+acceleration-1)/acceleration+500; // ramp + stable settling
 const uint32_t margin=t.nominalMs/4>1500?t.nominalMs/4:1500;
 t.recommendedMs=((t.expectedMs+margin+1000+999)/1000)*1000; // preflight + margin, round up
 return t;
}
}
