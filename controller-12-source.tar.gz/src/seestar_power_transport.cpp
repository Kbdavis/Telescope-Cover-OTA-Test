#ifdef COVER_WEB_CONTROL
#include "seestar_power.h"
#include "telescope_arm.h"
#include "web_control.h"
#include "alpaca_telemetry.h"
#include "settings.h"
#include "diagnostics.h"
#include <WiFi.h>
#include <cJSON.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <sys/socket.h>
#include <errno.h>
#include <memory>
#if !defined(COVER_BROWSER_OTA) && !defined(COVER_MULTITURN_USB) && !defined(COVER_WEB_READ_ONLY) && __has_include("seestar_local.h")
#include "seestar_local.h"
#include <mbedtls/pk.h>
#include <mbedtls/sha1.h>
#include <mbedtls/base64.h>
#include <esp_system.h>
#define COVER_NATIVE_POWER_KEY 1
#endif
namespace cover {
namespace {
portMUX_TYPE powerMux=portMUX_INITIALIZER_UNLOCKED;
SeestarPower sharedPower;
ArmStatus sharedArm;
ShutdownNative sharedShutdownNative;
ShutdownReply sharedShutdownReply;
bool armQueued=false,armOpening=false,armFinish=false;
#ifdef COVER_NATIVE_POWER_KEY
using Json=std::unique_ptr<cJSON,decltype(&cJSON_Delete)>;
int randomBytes(void*,unsigned char* data,size_t length){esp_fill_random(data,length);return 0;}
class NativeSeestarClient {
 WiFiClient socket_;
 std::unique_ptr<char[]> frame_{new(std::nothrow) char[8193]};
 uint32_t started_=0;
 ShutdownRequest lastRequest_;
 bool problem(const char* request,const char* error){lastRequest_={request,error};return false;}
 bool withinDeadline(){return uint32_t(millis()-started_)<6000;}
 // Bounded native requests. Motion is only issued by the guarded arm operation.
 Json request(const char* payload,uint32_t id,const char* method="native_request"){
  const uint32_t began=millis();lastRequest_={method,"timeout",0,id,0};
  auto failed=[&](const char* error){lastRequest_.error=error;lastRequest_.elapsedMs=millis()-began;return Json(nullptr,cJSON_Delete);};
  size_t length=strlen(payload),sent=0;
  while(sent<length && withinDeadline()){
   int n=::send(socket_.fd(),payload+sent,length-sent,MSG_DONTWAIT);
   if(n>0)sent+=n;
   else if(n<0 && errno!=EAGAIN && errno!=EWOULDBLOCK && errno!=EINTR)return failed("socket");
   else vTaskDelay(pdMS_TO_TICKS(2));
  }
  if(sent!=length)return failed("timeout");
  size_t used=0,total=0;
  while(withinDeadline() && total<32768){
   if(socket_.available()){
    int byte=socket_.read();if(byte<0)continue;++total;
    if(byte=='\n'){
     Json root(parseSeestarFrame(frame_.get(),used),cJSON_Delete);used=0;
     if(!root)return failed("protocol");
     const auto tx=cJSON_GetObjectItemCaseSensitive(root.get(),"id");
     if(cJSON_IsNumber(tx)&&tx->valuedouble==id){
      lastRequest_.elapsedMs=millis()-began;lastRequest_.error=seestarReplyOk(root.get(),id)?"none":"reply";
      const auto code=cJSON_GetObjectItemCaseSensitive(root.get(),"code");
      if(cJSON_IsNumber(code))lastRequest_.code=code->valueint;
      return root;
     }
     // Ignore bounded unsolicited events and replies for other IDs.
    }else{if(used>=8192)return failed("oversized");frame_[used++]=char(byte);}
   }else if(!socket_.connected())return failed("disconnected");
   else vTaskDelay(pdMS_TO_TICKS(2));
  }
  return failed(total>=32768?"oversized":"timeout");
 }
 public:
 ShutdownRequest detail() const {return lastRequest_;}
 bool authenticate(const char* host){
  started_=millis();
  IPAddress ip;
  if(!frame_ || WiFi.status()!=WL_CONNECTED || !ip.fromString(host))return problem("tcp_connect","unavailable");
  socket_.setTimeout(1);
  if(!socket_.connect(ip,4700,300)){problem("tcp_connect","connect_failed");lastRequest_.elapsedMs=millis()-started_;return false;}
  auto challenge=request("{\"id\":1,\"method\":\"get_verify_str\"}\r\n",1,"get_verify_str");
  if(!seestarReplyOk(challenge.get(),1))return false;
  const auto result=cJSON_GetObjectItemCaseSensitive(challenge.get(),"result");
  const auto str=cJSON_GetObjectItemCaseSensitive(result,"str");
  if(!cJSON_IsString(str) || strlen(str->valuestring)>256)return problem("get_verify_str","protocol");
  mbedtls_pk_context key;mbedtls_pk_init(&key);
  unsigned char digest[20],signature[512];size_t signatureLength=0;
  int error=mbedtls_pk_parse_key(&key,reinterpret_cast<const unsigned char*>(seestarPrivateKey),sizeof(seestarPrivateKey),nullptr,0);
  if(!error)error=mbedtls_sha1_ret(reinterpret_cast<const unsigned char*>(str->valuestring),strlen(str->valuestring),digest);
  if(!error && mbedtls_pk_get_len(&key)>sizeof(signature))error=-1;
  if(!error)error=mbedtls_pk_sign(&key,MBEDTLS_MD_SHA1,digest,sizeof(digest),signature,&signatureLength,randomBytes,nullptr);
  mbedtls_pk_free(&key);
  if(error)return problem("authentication","sign_failed");
  unsigned char encoded[700];size_t encodedLength=0;
  if(mbedtls_base64_encode(encoded,sizeof(encoded)-1,&encodedLength,signature,signatureLength))return problem("authentication","encode_failed");
  encoded[encodedLength]=0;
  // cJSON escapes the challenge. Neither credentials nor auth replies are logged.
  Json auth(cJSON_CreateObject(),cJSON_Delete);
  if(!auth)return problem("authentication","allocation");
  cJSON_AddNumberToObject(auth.get(),"id",2);cJSON_AddStringToObject(auth.get(),"method","verify_client");
  auto params=cJSON_AddObjectToObject(auth.get(),"params");if(!params)return problem("authentication","allocation");
  if(!cJSON_AddStringToObject(params,"sign",reinterpret_cast<char*>(encoded)) || !cJSON_AddStringToObject(params,"data",str->valuestring))return problem("authentication","allocation");
  char payload[1400];
  if(!cJSON_PrintPreallocated(auth.get(),payload,sizeof(payload)-3,false))return problem("authentication","encode_failed");
  strcat(payload,"\r\n");
  auto verified=request(payload,2,"verify_client");
  // Current firmware returns code=0 with a result object, not result=0.
  return seestarReplyOk(verified.get(),2);
 }
 bool read(const char* host,SeestarPower& out){
  out=SeestarPower{};out.configured=true;
  if(!authenticate(host))return false;
  auto state=request("{\"id\":3,\"method\":\"get_device_state\",\"params\":{\"keys\":[\"device\",\"pi_status\"]}}\r\n",3);
  return parseSeestarPower(state.get(),3,millis(),out);
 }
 bool moveArm(const char* host,bool opening){
  if(!authenticate(host))return false;
  auto state=request("{\"id\":3,\"method\":\"get_device_state\",\"params\":{\"keys\":[\"device\",\"mount\"]}}\r\n",3);
  if(!seestarReplyOk(state.get(),3))return false;
  auto result=cJSON_GetObjectItemCaseSensitive(state.get(),"result");
  auto device=cJSON_GetObjectItemCaseSensitive(result,"device");
  auto model=cJSON_GetObjectItemCaseSensitive(device,"product_model");
  auto mount=cJSON_GetObjectItemCaseSensitive(result,"mount");
  auto closed=cJSON_GetObjectItemCaseSensitive(mount,"close");
  auto tracking=cJSON_GetObjectItemCaseSensitive(mount,"tracking");
  auto motion=cJSON_GetObjectItemCaseSensitive(mount,"move_type");
  if(!cJSON_IsString(model)||strcmp(model->valuestring,"Seestar S30 Pro") ||
     !cJSON_IsBool(closed)||bool(cJSON_IsTrue(closed))!=opening || !cJSON_IsFalse(tracking) ||
     !cJSON_IsString(motion)||strcmp(motion->valuestring,"none"))return false;
  // Recheck worker-owned cover lock and live evidence immediately before sending.
  const auto evidence=telescopeArmEvidence();
  if(!evidence.maintenance || !armStationary(millis(),evidence,!opening) || evidence.scope.atHome!=opening || !withinDeadline())return false;
  auto reply=request(opening?"{\"id\":4,\"method\":\"scope_move_to_horizon\"}\r\n":
                             "{\"id\":4,\"method\":\"scope_park\"}\r\n",4);
  // Never retry a motion request, including a lost acknowledgment.
  return seestarReplyOk(reply.get(),4);
 }
 bool shutdownRead(const char* host,ShutdownNative& out,SeestarPower* power=nullptr){
  if(!authenticate(host))return false;
  const uint32_t sampled=millis();
  auto device=request("{\"id\":10,\"method\":\"get_device_state\",\"params\":{\"keys\":[\"device\",\"mount\",\"pi_status\"]}}\r\n",10,"get_device_state");
  if(power)parseSeestarPower(device.get(),10,sampled,*power);
  if(!seestarReplyOk(device.get(),10))return false;
  auto camera=request("{\"id\":11,\"method\":\"get_camera_state\"}\r\n",11,"get_camera_state");
  if(!seestarReplyOk(camera.get(),11))return false;
  auto app=request("{\"id\":12,\"method\":\"iscope_get_app_state\"}\r\n",12,"iscope_get_app_state");
  if(!seestarReplyOk(app.get(),12))return false;
  auto plans=request("{\"id\":13,\"method\":\"get_enabled_plan\"}\r\n",13,"get_enabled_plan");
  if(!seestarReplyOk(plans.get(),13))return false;
  if(!parseShutdownNative(cJSON_GetObjectItemCaseSensitive(device.get(),"result"),cJSON_GetObjectItemCaseSensitive(camera.get(),"result"),
   cJSON_GetObjectItemCaseSensitive(app.get(),"result"),cJSON_GetObjectItemCaseSensitive(plans.get(),"result"),sampled,out))return problem("native_state","invalid_state");
  if(!out.fresh(millis())){out.valid=false;return problem("native_state","stale");}
  return true;
 }
 ShutdownResult shutdownCommand(const char* host,uint32_t operation,ShutdownAction action){
  ShutdownNative evidence;if(!shutdownRead(host,evidence))return ShutdownResult::Deferred;
  bool attempted=false;
  auto outcome=[&](){return attempted?ShutdownResult::Failed:ShutdownResult::Deferred;};
  auto send=[&](const char* payload,uint32_t id,const char* method){
   // Stop/cancel invalidates a request even if authentication or reads were delayed.
   if(!emergencyWorkPermitted(operation,action))return problem(method,"interlock");
   if(!withinDeadline())return problem(method,"deadline");
   attempted=true; // From this point, any failure is an uncertain write: never retry.
   auto response=request(payload,id,method);return seestarReplyOk(response.get(),id);
  };
  if(action==ShutdownAction::StopCapture){
   if(!evidence.planIdle&&!send("{\"id\":20,\"method\":\"stop_func\",\"params\":{\"name\":\"ViewPlan\"}}\r\n",20,"stop_func"))return outcome();
   // Full view stop terminates stacking/continuous capture rather than just one frame.
   if((!evidence.imagingIdle||!evidence.cameraIdle)&&!send("{\"id\":21,\"method\":\"iscope_stop_view\"}\r\n",21,"iscope_stop_view"))return outcome();
   if(!evidence.cameraIdle){
    auto camera=request("{\"id\":26,\"method\":\"get_camera_state\"}\r\n",26,"get_camera_state");
    if(!seestarReplyOk(camera.get(),26))return outcome();
    const auto state=cJSON_GetObjectItemCaseSensitive(cJSON_GetObjectItemCaseSensitive(camera.get(),"result"),"state");
    if(!cJSON_IsString(state)){problem("get_camera_state","protocol");return outcome();}
    if(strcmp(state->valuestring,"idle")&&strcmp(state->valuestring,"close")&&!send("{\"id\":22,\"method\":\"stop_exposure\"}\r\n",22,"stop_exposure"))return outcome();
   }
   if(evidence.tracking&&!send("{\"id\":23,\"method\":\"scope_set_track_state\",\"params\":false}\r\n",23,"scope_set_track_state"))return outcome();
   if(evidence.moving&&!send("{\"id\":24,\"method\":\"scope_move\",\"params\":[\"none\"]}\r\n",24,"scope_move"))return outcome();
   if(!emergencyWorkPermitted(operation,action)){problem("capture_stop","cancelled");return outcome();}
   return ShutdownResult::Acknowledged;
  }
  if(action==ShutdownAction::Park){
   const auto cover=webStatus();const auto scope=alpacaStatus();const uint32_t now=millis();
   if(!cover.ready||!cover.calibrated||cover.dirty||cover.moving||cover.holding||!cover.positionValid||now-cover.positionAt>=1500||
      !cover.torqueValid||cover.torque||strcmp(cover.state,"OPEN")||abs(int(cover.position)-int(cover.saved.open))>kEndpointTolerance||
      !scope.fresh(now)||!scope.connected||scope.slewing||scope.tracking||scope.atHome||!evidence.quiet(now)||evidence.closed){problem("scope_park_preflight","interlock");return ShutdownResult::Deferred;}
   return send("{\"id\":25,\"method\":\"scope_park\"}\r\n",25,"scope_park")?ShutdownResult::Acknowledged:outcome();
  }
  problem("shutdown_command","unsupported");return ShutdownResult::Failed;
 }

};
void powerWorker(void*){
 ApplicationSettings settings;
 if(loadApplicationSettings(settings)!=SettingsLoad::Loaded || !settings.alpacaEnabled){registerMaintenanceWorker(kMaintenancePowerWorker,false);vTaskDelete(nullptr);return;}
 ArmOperation arm;ArmStatus loggedArm;PowerMonitor powerMonitor;
 auto publishPower=[&]{portENTER_CRITICAL(&powerMux);sharedPower=powerMonitor.status();portEXIT_CRITICAL(&powerMux);};
 auto recordPower=[&](const SeestarPower& reading){
  const auto before=powerMonitor.status();powerMonitor.record(millis(),reading);
  if(before.retrying!=!reading.valid || (!before.valid&&reading.valid))
   diagnosticLog("SEESTAR power telemetry=%s",reading.valid?"available":"retrying");
  publishPower();
 };
 publishPower();
 uint32_t shutdownOperation=0,shutdownReadAt=0,shutdownSequence=0;
 ShutdownDispatch shutdownDispatch;
 portENTER_CRITICAL(&powerMux);sharedArm.supported=true;portEXIT_CRITICAL(&powerMux);
 MaintenanceLease pausedLease;
 for(;;){
  const auto pause=otaMaintenanceForWorker();
  if(pause){
   if(!sameLease(pausedLease,pause)){
    pausedLease=pause;powerMonitor=PowerMonitor{};
    portENTER_CRITICAL(&powerMux);sharedPower=SeestarPower{};sharedShutdownNative=ShutdownNative{};portEXIT_CRITICAL(&powerMux);
    acknowledgeMaintenancePause(pause,kMaintenancePowerWorker);
   }
   vTaskDelay(pdMS_TO_TICKS(50));continue;
  }
  if(pausedLease){pausedLease=MaintenanceLease{};powerMonitor=PowerMonitor{};}
  const auto shutdown=webStatus().shutdown;
  if(emergencyShutdownLocked()){
   if(shutdown.operation!=shutdownOperation){shutdownOperation=shutdown.operation;shutdownReadAt=0;}
   if(shutdownDispatch.ready(millis(),shutdown)){
    ShutdownReply reply;reply.operation=shutdown.operation;reply.action=shutdown.action();
    ShutdownResult result;
    {NativeSeestarClient reader;result=reader.shutdownCommand(settings.alpacaHost,shutdown.operation,shutdown.action());reply.detail=reader.detail();}
    reply.at=millis();reply.done=result!=ShutdownResult::Deferred;reply.ok=result==ShutdownResult::Acknowledged;
    shutdownDispatch.complete(reply.at,reply.action,result);
    portENTER_CRITICAL(&powerMux);sharedShutdownReply=reply;portEXIT_CRITICAL(&powerMux);
    shutdownReadAt=0;
   }
   if(shutdown.operation&&(!shutdownReadAt||uint32_t(millis()-shutdownReadAt)>=500)){
    ShutdownNative next;next.operation=shutdown.operation;next.sequence=++shutdownSequence;
    // Reuse the existing native read during shutdown/recovery; no extra socket
    // or request can delay the safety sequence for display-only power data.
    SeestarPower power;
    {NativeSeestarClient reader;reader.shutdownRead(settings.alpacaHost,next,&power);next.detail=reader.detail();}
    recordPower(power);
    portENTER_CRITICAL(&powerMux);sharedShutdownNative=next;portEXIT_CRITICAL(&powerMux);
    shutdownReadAt=millis();
   }
   vTaskDelay(pdMS_TO_TICKS(50));continue;
  }
  bool queued,opening,finish;
  portENTER_CRITICAL(&powerMux);queued=armQueued;opening=armOpening;armQueued=false;finish=armFinish;armFinish=false;portEXIT_CRITICAL(&powerMux);
  auto evidence=telescopeArmEvidence();
  if(queued && !arm.start(opening,millis(),evidence)){
   // Preserve the lock and expose failed preflight for explicit inspection.
   arm.reject(opening);
  }
  if(finish && arm.finish(millis(),evidence))endNetworkMaintenance();
  const auto prior=arm.status().phase;
  arm.step(millis(),evidence);
  if(arm.readyToSend(millis(),evidence)){
   NativeSeestarClient reader;const bool acknowledged=reader.moveArm(settings.alpacaHost,arm.status().opening);
   arm.sent(millis(),acknowledged);
  }
  auto status=arm.status();status.supported=true;
  if(status.phase!=loggedArm.phase || status.operation!=loggedArm.operation){
   diagnosticLog("TELESCOPE ARM op=%lu direction=%s phase=%s cover_locked=%d reason=%s",(unsigned long)status.operation,
    status.opening?"open":"close",armPhaseName(status.phase),status.locked,status.reason);loggedArm=status;
  }
  if(status.phase==ArmPhase::Complete && prior!=ArmPhase::Complete)endNetworkMaintenance();
  portENTER_CRITICAL(&powerMux);if(!armQueued)sharedArm=status;portEXIT_CRITICAL(&powerMux);
  if(powerMonitor.due(millis(),status.active())){
   SeestarPower next;
   {NativeSeestarClient reader;reader.read(settings.alpacaHost,next);}
   recordPower(next);
  }else publishPower();
  vTaskDelay(pdMS_TO_TICKS(50));
 }
}
#endif
}
ArmEvidence telescopeArmEvidence(){
 const auto cover=webStatus();const auto camera=alpacaTelemetry().cameraState;const auto altitude=alpacaTelemetry().altitude;
 const uint32_t now=millis();ArmEvidence e;
 const bool openFeedback=cover.ready && cover.calibrated && !cover.dirty && !cover.moving && !cover.holding &&
  cover.positionValid && now-cover.positionAt<1500 && cover.torqueValid && !cover.torque &&
  abs(int(cover.position)-int(cover.saved.open))<=kEndpointTolerance;
 e.coverOpen=openFeedback && strcmp(cover.state,"OPEN")==0;
 e.coverStoppedOpen=openFeedback && strcmp(cover.state,"STOPPED")==0;
 e.maintenance=networkMaintenanceReady();e.cameraIdle=camera.fresh(now)&&camera.value==0;
 e.scope=alpacaStatus();e.altitudeValid=altitude.valid;e.altitude=altitude.value;e.altitudeAt=altitude.at;return e;
}
ArmStatus telescopeArmStatus(){portENTER_CRITICAL(&powerMux);auto result=sharedArm;portEXIT_CRITICAL(&powerMux);return result;}
bool requestTelescopeArm(bool opening){
 if(maintenanceStatus().locked())return false;
 portENTER_CRITICAL(&powerMux);
 bool ok=sharedArm.supported&&!sharedArm.locked&&!armQueued;
 if(ok){armQueued=true;armOpening=opening;sharedArm.locked=true;sharedArm.opening=opening;sharedArm.phase=ArmPhase::Checking;}
 portEXIT_CRITICAL(&powerMux);return ok;
}
bool finishTelescopeArm(){
 portENTER_CRITICAL(&powerMux);bool ok=sharedArm.phase==ArmPhase::Unknown&&!armFinish;
 if(ok)armFinish=true;portEXIT_CRITICAL(&powerMux);return ok;
}
SeestarPower seestarPowerStatus(){portENTER_CRITICAL(&powerMux);auto result=sharedPower;portEXIT_CRITICAL(&powerMux);return result;}
ShutdownNative shutdownNativeStatus(){portENTER_CRITICAL(&powerMux);auto result=sharedShutdownNative;portEXIT_CRITICAL(&powerMux);return result;}
ShutdownReply shutdownNativeReply(){portENTER_CRITICAL(&powerMux);auto result=sharedShutdownReply;portEXIT_CRITICAL(&powerMux);return result;}
void beginSeestarPower(){
#ifdef COVER_NATIVE_POWER_KEY
 registerMaintenanceWorker(kMaintenancePowerWorker,true);
 if(xTaskCreatePinnedToCore(powerWorker,"seestar-power",12288,nullptr,1,nullptr,0)!=pdPASS){
  registerMaintenanceWorker(kMaintenancePowerWorker,false);
  diagnosticEvent(DebugLevel::Error,"ALLOC Seestar power worker failed");
 }
#endif
}
}
#endif
