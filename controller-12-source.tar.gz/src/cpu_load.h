#pragma once
#include <stdint.h>
namespace cover {
struct CpuLoadSample {
 bool available=false;
 uint16_t busyPermille[2]={0,0};
 uint32_t sampledAt=0,windowMs=0;
};
// Counter arithmetic only. Hardware sampling and publication belong to diagnostics.
class CpuLoadTracker {
 public:
  bool update(uint32_t now,uint32_t samples,const uint32_t idle[2],CpuLoadSample& out){
   if(!started_){baseline(now,samples,idle);started_=true;return false;}
   const uint32_t elapsed=now-at_;
   if(elapsed<1000)return false;
   const uint32_t count=samples-samples_;
   CpuLoadSample next;next.sampledAt=now;next.windowMs=elapsed;
   next.available=elapsed<=5000 && count>=100;
   for(unsigned i=0;i<2;++i){
    uint32_t free=idle[i]-idle_[i];
    // A snapshot may straddle the ISR's idle/total stores by one observation.
    if(free>count){if(free-count>1)next.available=false;free=count;}
    if(count)next.busyPermille[i]=1000-uint16_t((uint64_t(free)*1000+count/2)/count);
   }
   baseline(now,samples,idle);out=next;return true;
  }
 private:
  bool started_=false;
  uint32_t at_=0,samples_=0,idle_[2]={0,0};
  void baseline(uint32_t now,uint32_t samples,const uint32_t idle[2]){
   at_=now;samples_=samples;idle_[0]=idle[0];idle_[1]=idle[1];
  }
};
}
