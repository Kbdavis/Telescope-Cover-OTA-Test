#pragma once
#include "servo_support.h"
#include "debug_response.h"
#include "servo_factory_profile.h"
namespace cover {
constexpr size_t kServoSupportResponseBytes=12288;
inline void supportNumber(DebugJson& j,const char* key,uint32_t value){j.raw(",\"");j.raw(key);j.raw("\":");j.number(value);}
inline void supportBool(DebugJson& j,const char* key,bool value){j.raw(",\"");j.raw(key);j.raw("\":");j.raw(value?"true":"false");}
inline void supportOptional(DebugJson& j,const char* key,bool valid,uint32_t value){j.raw(",\"");j.raw(key);j.raw("\":");if(valid)j.number(value);else j.raw("null");}
inline void supportSigned(DebugJson& j,const char* key,int value){char text[16];snprintf(text,sizeof(text),"%d",value);j.raw(",\"");j.raw(key);j.raw("\":");j.raw(text);}
inline void writeServoCache(DebugJson& j,const ServoDiagnostics& d,uint32_t at){
 j.raw("{\"exchanges\":");j.number(d.exchanges);
#ifdef COVER_MULTITURN
 j.raw(",\"native_position\":");if(d.nativePositionValid){char value[16];snprintf(value,sizeof(value),"%d",d.nativePosition);j.raw(value);}else j.raw("null");
 supportOptional(j,"native_position_age_ms",d.nativePositionValid,at-d.nativePositionAt);
#endif
 supportNumber(j,"failed_exchanges",d.failedExchanges);supportNumber(j,"failed_reads",d.failedReads);
 supportNumber(j,"retries",d.retries);supportNumber(j,"driver_rejected_positions",d.rejectedPositions);
 supportOptional(j,"last_success_at_ms",d.hasSuccess,d.lastSuccessAt);
 supportOptional(j,"last_success_age_ms",d.hasSuccess,at-d.lastSuccessAt);
 j.raw(",\"last_transport_failure\":");
 if(!d.hasFailure)j.raw("null");else{
  j.raw("{\"error\":");j.string(servoErrorName(d.lastFailure.error));
  supportNumber(j,"device_status",d.lastFailure.deviceStatus);supportNumber(j,"instruction",d.failureInstruction);
  supportNumber(j,"address",d.failureAddress);supportNumber(j,"at_ms",d.lastFailureAt);supportNumber(j,"age_ms",at-d.lastFailureAt);j.raw("}");
 }
 supportOptional(j,"position",d.positionValid,d.position);supportOptional(j,"position_age_ms",d.positionValid,at-d.positionAt);
 j.raw(",\"torque\":");j.raw(!d.torqueValid?"null":d.torque?"true":"false");
 supportOptional(j,"torque_age_ms",d.torqueValid,at-d.torqueAt);
 supportOptional(j,"model",d.modelValid,d.model);
 supportOptional(j,"model_age_ms",d.modelValid,at-d.modelAt);
 j.raw(",\"goal_readback\":");
 if(!d.goalValid)j.raw("null");else{
  j.raw("{\"sampled_at_ms\":");j.number(d.goalAt);supportNumber(j,"age_ms",at-d.goalAt);
  supportNumber(j,"register_42_position_raw",d.goal.positionRaw);supportNumber(j,"register_44_raw",d.goal.register44Raw);
  supportNumber(j,"register_46_speed_raw",d.goal.speedRaw);supportNumber(j,"register_41_acceleration",d.goal.acceleration);
  supportNumber(j,"register_48_torque_limit_raw",d.goal.torqueLimitRaw);j.raw("}");
 }
 j.raw(",\"model_777\":");if(d.modelValid)j.raw(d.model==777?"true":"false");else j.raw("null");
 j.raw(",\"telemetry\":");
 if(!d.telemetryValid)j.raw("null");else{
  j.raw("{\"sampled_at_ms\":");j.number(d.telemetryAt);supportNumber(j,"age_ms",at-d.telemetryAt);
  supportNumber(j,"position",d.telemetry.position);supportNumber(j,"voltage_decivolts",d.telemetry.voltageDecivolts);
  supportNumber(j,"temperature_c",d.telemetry.temperatureC);supportSigned(j,"relative_load",d.telemetry.relativeLoad);
  supportSigned(j,"current_raw",d.telemetry.currentRaw);supportSigned(j,"speed_raw",d.telemetry.speedRaw);
  supportNumber(j,"register_67_target_raw",d.telemetry.targetPositionRaw);
  supportBool(j,"moving",d.telemetry.moving);j.raw("}");
 }
 j.raw(",\"configuration\":{\"validation_attempted\":");j.raw(d.validationAttempted?"true":"false");
#ifdef COVER_MULTITURN_USB
 j.raw(",\"compiled_policy\":\"exact_multiturn_ram_startup_usb\"");
#elif defined(COVER_MULTITURN_STARTUP)
 j.raw(",\"compiled_policy\":\"exact_multiturn_ram_startup_qualification\"");
#elif defined(COVER_MULTITURN)
 j.raw(",\"compiled_policy\":\"exact_multiturn_probe_or_factory\"");
#elif defined(COVER_FIXED_REFERENCE)
 j.raw(",\"compiled_policy\":\"exact_fixed_reference_1328\"");
#elif defined(COVER_REFERENCE_PROBE)
 j.raw(",\"compiled_policy\":\"legacy_or_exact_factory_or_reference_probe\"");
#else
 j.raw(",\"compiled_policy\":\"legacy_or_exact_factory\"");
#endif
 supportBool(j,"validation_passed",d.validationPassed);j.raw(",\"validation_error\":");
 if(d.validationAttempted)j.string(servoErrorName(d.validationResult.error));else j.raw("null");
 supportOptional(j,"validated_at_ms",d.validationAttempted,d.validationAt);
 supportOptional(j,"validation_age_ms",d.validationAttempted,at-d.validationAt);
 supportOptional(j,"observed_at_ms",d.configurationRead,d.configurationAt);
 j.raw(",\"observed\":");
 if(!d.configurationRead)j.raw("null");else{
  const auto& c=d.configuration;j.raw("{\"id\":");j.number(c.id);
  supportNumber(j,"mode",c.mode);supportNumber(j,"minimum",c.minimum);supportNumber(j,"maximum",c.maximum);
  supportNumber(j,"phase",c.phase);supportNumber(j,"resolution",c.resolution);supportNumber(j,"offset",c.offset);j.raw("}");
 }
 j.raw(",\"critical_checks\":");
 if(!d.configurationRead)j.raw("null");else{
  const auto& c=d.configuration;j.raw("{\"id_1\":");j.raw(c.id==1?"true":"false");
  supportBool(j,"mode_0",c.mode==0);supportBool(j,"minimum_0",c.minimum==0);supportBool(j,"maximum_4095",c.maximum==4095);
  supportBool(j,"maximum_0",c.maximum==0);supportBool(j,"phase_28_offset_85",c.phase==28 && c.offset==85);
  supportBool(j,"resolution_1",c.resolution==1);supportBool(j,"legacy_phase_offset",c.phase==0 && c.offset==0);j.raw("}");
 }
 supportOptional(j,"lock",d.lockValid,d.lock);supportOptional(j,"snapshot_at_ms",d.snapshotValid,d.snapshotAt);
 j.raw(",\"identity_configuration_bytes_0_39\":");
 if(!d.snapshotValid)j.raw("null");else{
  j.raw("[");for(unsigned i=0;i<40;++i){if(i)j.raw(",");j.number(d.snapshot[i]);}j.raw("]");
 }
 j.raw(",\"factory_snapshot_matches\":");if(d.snapshotValid)j.raw(matchesCommissionedFactoryProfile(d.snapshot)?"true":"false");else j.raw("null");
#if defined(COVER_REFERENCE_PROBE) || defined(COVER_FIXED_REFERENCE)
 j.raw(",\"fixed_reference_snapshot_matches\":");if(d.snapshotValid)j.raw(matchesReferenceProbeProfile(d.snapshot)?"true":"false");else j.raw("null");
#endif
#ifdef COVER_MULTITURN
 j.raw(",\"multiturn_snapshot_matches\":");if(d.snapshotValid)j.raw(matchesMultiTurnProbeProfile(d.snapshot)?"true":"false");else j.raw("null");
#endif
 j.raw("}}");
}
inline const char* dispositionName(PositionDisposition d){
 switch(d){case PositionDisposition::Accepted:return "accepted";case PositionDisposition::ReadFailed:return "read_failed";
 case PositionDisposition::OutsideLimits:return "outside_limits";case PositionDisposition::Discontinuity:return "discontinuity";
 case PositionDisposition::AwayFromTarget:return "away_from_target";case PositionDisposition::HoldingDrift:return "holding_drift";
 case PositionDisposition::TargetOvershoot:return "target_overshoot";}
 return "unknown";
}
inline void writeSupportTrace(DebugJson& j,const MotionTrace& t){
 j.raw("{\"operation\":");j.number(t.operation);supportNumber(j,"started_at_ms",t.startedAt);
 supportNumber(j,"start_position",t.startPosition);supportNumber(j,"target",t.target);supportNumber(j,"speed_counts_s",t.speed);
 supportNumber(j,"acceleration",t.acceleration);supportNumber(j,"timeout_ms",t.timeoutMs);supportNumber(j,"tolerance",t.tolerance);
 supportNumber(j,"valid_reads",t.validReads);supportNumber(j,"failed_reads",t.failedReads);supportNumber(j,"rejected_reads",t.rejectedReads);
 supportOptional(j,"last_position",t.validReads!=0,t.lastPosition);supportOptional(j,"last_valid_ms",t.validReads!=0,t.lastValidMs);
 supportNumber(j,"settled_samples",t.settled);supportNumber(j,"capacity",MotionTrace::capacity);supportNumber(j,"sample_interval_ms",100);
 j.raw(",\"samples\":[");
 for(unsigned i=0;i<t.count;++i){const auto& s=t.samples[(t.next+MotionTrace::capacity-t.count+i)%MotionTrace::capacity];
  if(i)j.raw(",");
  j.raw("{\"ms\":");j.number(s.elapsedMs);supportOptional(j,"position",s.valid,s.position);
  j.raw(",\"disposition\":");j.string(dispositionName(s.disposition));j.raw("}");
 }j.raw("]}");
}
inline size_t writeServoSupport(char* buffer,const ServoSupportSnapshot& s,const char* boot,const char* firmware){
 DebugJson j(buffer,kServoSupportResponseBytes);j.raw("{\"schema_version\":1,\"boot_id\":");j.string(boot);
 j.raw(",\"firmware_id\":");j.string(firmware);supportBool(j,"available",s.available);supportNumber(j,"sampled_at_ms",s.sampledAt);
 j.raw(",\"retention\":\"ram_until_reboot\",\"current\":");writeServoCache(j,s.current,s.sampledAt);
 j.raw(",\"fault\":");
 if(!s.faultRevision)j.raw("null");else{
  const auto& f=s.fault;j.raw("{\"revision\":");j.number(s.faultRevision);supportNumber(j,"at_ms",f.at);
  j.raw(",\"origin\":");j.string(s.startupFault?"startup":"controller");j.raw(",\"reason\":");j.string(f.reason);
  j.raw(",\"state_before\":");j.string(stateName(f.stateBefore));supportNumber(j,"elapsed_ms",f.elapsedMs);
  supportOptional(j,"last_accepted_position",f.positionKnown,f.acceptedPosition);supportBool(j,"torque_off_confirmed_after_release",f.releaseConfirmed);
  supportNumber(j,"consecutive_read_failures",f.consecutiveReadFailures);supportNumber(j,"wrong_samples",f.wrongSamples);supportNumber(j,"limit_samples",f.limitSamples);
  supportNumber(j,"heartbeat_age_ms",s.heartbeatAgeMs);supportNumber(j,"heartbeat_received_at_ms",s.heartbeatReceivedAt);
  supportNumber(j,"heartbeat_processed_at_ms",s.heartbeatProcessedAt);supportNumber(j,"heartbeat_sequence",s.heartbeatSequence);
  j.raw(",\"servo_before_release\":");writeServoCache(j,f.servo,f.at);j.raw(",\"motion\":");
  if(f.traceAvailable)writeSupportTrace(j,s.frozenTrace);else j.raw("null");j.raw("}");
 }j.raw("}");return j.ok()?j.size():0;
}
}
