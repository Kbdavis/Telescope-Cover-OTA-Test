#pragma once
#include <stdint.h>
namespace cover {
// Fixed storage, no allocations or I/O. The owner supplies external locking.
class MetricsLeases {
 struct Lease { uint32_t client=0,generation=0,at=0; bool active=false; } leases_[4];
 Lease* find(uint32_t client){for(auto& l:leases_)if(l.client==client)return &l;return nullptr;}
 Lease* slot(uint32_t now,uint32_t client){
  if(auto* l=find(client))return l;
  for(auto& l:leases_)if(!l.client || (!l.active && uint32_t(now-l.at)>=10000)){l=Lease{};l.client=client;return &l;}
  return nullptr;
 }
public:
 static constexpr uint32_t durationMs=5000;
 void expire(uint32_t now){for(auto& l:leases_)if(l.active && uint32_t(now-l.at)>=durationMs){l.active=false;l.at=now;}}
 unsigned viewers() const {unsigned n=0;for(const auto& l:leases_)if(l.active)++n;return n;}
 bool subscribe(uint32_t now,uint32_t client,uint32_t generation,uint32_t observedUptime){
  expire(now);
  // Fresh controller time bounds delayed requests, including after tombstone reuse.
  if(!client || !generation || uint32_t(now-observedUptime)>3000)return false;
  auto* l=slot(now,client);if(!l)return false;
  if(generation<l->generation || (generation==l->generation && !l->active))return false;
  l->generation=generation;l->at=now;l->active=true;return true;
 }
 bool renew(uint32_t now,uint32_t client,uint32_t generation){
  expire(now);auto* l=find(client);
  if(!l || !l->active || l->generation!=generation)return false;
  l->at=now;return true;
 }
 bool unsubscribe(uint32_t now,uint32_t client,uint32_t generation){
  expire(now);if(!client || !generation)return false;
  auto* l=slot(now,client);if(!l)return false;
  if(generation<l->generation)return true; // Delayed close cannot cancel a newer open.
  l->generation=generation;l->at=now;l->active=false;return true;
 }
};
enum class MetricsPhase : uint8_t { Off, Starting, Active, Stopping, Unavailable };
inline const char* metricsPhaseName(MetricsPhase phase){
 switch(phase){case MetricsPhase::Off:return "off";case MetricsPhase::Starting:return "starting";
 case MetricsPhase::Active:return "active";case MetricsPhase::Stopping:return "stopping";default:return "unavailable";}
}
// Called only by the diagnostics task. Cleanup is acknowledged before OFF.
class MetricsCollector {
 MetricsPhase phase_=MetricsPhase::Off;
 bool failed_=false;
public:
 MetricsPhase phase() const{return phase_;}
 template<class Backend> void poll(bool wanted,uint32_t now,Backend& backend){
  if(phase_==MetricsPhase::Off){
   if(!wanted)return; // No hardware, scans, formatting or cache work in OFF.
   phase_=MetricsPhase::Starting;failed_=!backend.start();
   phase_=failed_?MetricsPhase::Stopping:MetricsPhase::Active;
  }
  if(phase_==MetricsPhase::Unavailable){if(wanted)return;phase_=MetricsPhase::Off;return;}
  if(!wanted)phase_=MetricsPhase::Stopping;
  if(phase_==MetricsPhase::Stopping){
   if(!backend.stop() || !backend.quiescent())return;
   backend.clear();phase_=failed_&&wanted?MetricsPhase::Unavailable:MetricsPhase::Off;return;
  }
  backend.sample(now);
 }
};
}
