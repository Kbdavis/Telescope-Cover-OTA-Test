#include "emergency_shutdown.h"
#include <string.h>
namespace cover {
namespace {
bool scopeUsable(uint32_t now,const alpaca::Snapshot& s){return s.enabled&&s.connected&&s.error==alpaca::Error::None&&uint32_t(now-s.sampledAt)<=5000;}
bool coverUsable(const ShutdownEvidence& e){return e.coverReady&&e.positionFresh&&e.calibrationClean;}
}
void EmergencyShutdown::enter(ShutdownPhase p,uint32_t now,const char* message){
 status_.phase=p;status_.phaseAt=now;status_.message=message;status_.recovering=false;confirmations_=0;nativeSequence_=scopeSequence_=0;
}
void EmergencyShutdown::record(uint32_t now,const ShutdownEvidence& e,const char* source,const ShutdownRequest& detail){
 auto& d=status_.diagnostic;++d.sequence;d.at=now;d.phase=status_.phase;d.source=source;d.detail=detail;
 d.sampleAgeMs=uint32_t(now-e.scope.sampledAt);
}
void EmergencyShutdown::recordAlpaca(uint32_t now,const ShutdownEvidence& e){
 const auto& s=e.scope;ShutdownRequest d;
 d.request=s.failure.request;d.transaction=s.failure.transaction;d.elapsedMs=s.failure.elapsedMs;d.code=s.driverError;
 d.error=alpaca::errorName(s.error);
 if(s.error==alpaca::Error::None){d.request=s.connected?"status_age":"connected";d.error=s.connected?"stale":"disconnected";}
 record(now,e,"alpaca",d);
}
bool EmergencyShutdown::recover(uint32_t now,const ShutdownEvidence& e){
 if(!status_.recovering){
  recordAlpaca(now,e);status_.recovering=true;status_.recoveryAt=now;++status_.recoveries;
  resumeMessage_=status_.message;status_.message="Reconnecting telescope status; cover stays open";
  recoveryConfirmations_=0;recoveryScope_=recoveryNative_=0;confirmations_=0;
 }
 if(uint32_t(now-status_.recoveryAt)>=15000){fail(now,"Telescope status did not recover within 15 seconds; inspect before retrying");return false;}
 const auto& s=e.scope;const auto& n=e.native;
 if(!s.fresh(now)||!s.connected||!s.canFindHome||s.error!=alpaca::Error::None||
    n.operation!=status_.operation||!n.fresh(now)||s.atHome!=n.closed||s.slewing!=n.moving||s.tracking!=n.tracking){
  recoveryConfirmations_=0;return false;
 }
 if(int32_t(s.sampledAt-status_.recoveryAt)<=0||int32_t(n.sampledAt-status_.recoveryAt)<=0){recoveryConfirmations_=0;return false;}
 if(s.sequence==recoveryScope_||n.sequence==recoveryNative_)return false;
 recoveryScope_=s.sequence;recoveryNative_=n.sequence;
 const unsigned signature=unsigned(s.atHome)|(unsigned(s.slewing)<<1)|(unsigned(s.tracking)<<2)|
  (unsigned(n.imagingIdle)<<3)|(unsigned(n.cameraIdle)<<4)|(unsigned(n.planIdle)<<5);
 recoveryConfirmations_=recoveryConfirmations_&&signature==recoverySignature_?recoveryConfirmations_+1:1;
 recoverySignature_=signature;if(recoveryConfirmations_<2)return false;
 status_.recovering=false;status_.message=resumeMessage_;
 // Recovery is only connectivity evidence. Phase-specific idle/stow clearance
 // starts again, and neither command nor phase deadlines are extended.
 confirmations_=0;nativeSequence_=n.sequence;scopeSequence_=s.sequence;return true;
}
bool EmergencyShutdown::start(uint32_t now,const ShutdownEvidence& e){
 if(status_.locked()||!coverUsable(e)||!e.coverStationary||!e.torqueOff||!e.scope.fresh(now)||!e.scope.connected||
    (!e.coverOpen&&!e.scope.stowedCandidate(now)))return false;
 ++status_.operation;if(!status_.operation)++status_.operation;
 status_.recoveries=0;status_.diagnostic=ShutdownDiagnostic{};
 status_.startedAt=now;enter(ShutdownPhase::StoppingCapture,now,"Stopping capture and observing plans");return true;
}
void EmergencyShutdown::fail(uint32_t now,const char* reason){
 if(status_.phase==ShutdownPhase::Idle||status_.phase==ShutdownPhase::Complete){++status_.operation;if(!status_.operation)++status_.operation;}
 enter(ShutdownPhase::Fault,now,reason);
}
void EmergencyShutdown::cancel(uint32_t now){if(status_.active())enter(ShutdownPhase::Cancelled,now,"Shutdown cancelled; inspect telescope and cover before recovery");}
bool EmergencyShutdown::closePermitted(uint32_t now,const ShutdownEvidence& e) const {
 return status_.phase==ShutdownPhase::Closing&&coverUsable(e)&&e.scope.stowedCandidate(now)&&
  e.native.operation==status_.operation&&e.native.quiet(now)&&e.native.closed;
}
void EmergencyShutdown::tick(uint32_t now,const ShutdownEvidence& e){
 if(!status_.active())return;
 auto issue=[&](const char* request,const char* error){ShutdownRequest d;d.request=request;d.error=error;record(now,e,"controller",d);};
 if(uint32_t(now-status_.startedAt)>150000){issue("shutdown","timeout");fail(now,"Shutdown timed out; inspect telescope and cover");return;}
 if(!coverUsable(e)){issue("cover_feedback","unavailable");fail(now,"Cover feedback or calibration lost; closure inhibited");return;}
 if(status_.phase!=ShutdownPhase::Closing&&(!e.coverStationary||!e.torqueOff)){
  issue("cover_stationary","contradiction");
  fail(now,"Cover moved during telescope shutdown; inspect clearance");return;
 }
 const auto p=status_.phase;
 const bool command=p==ShutdownPhase::StoppingCapture||p==ShutdownPhase::Stowing;
 const bool acknowledged=command&&e.reply.done&&e.reply.operation==status_.operation&&e.reply.action==status_.action();
 if(acknowledged&&(!e.reply.ok||uint32_t(e.reply.at-status_.phaseAt)>15000)){
  auto d=e.reply.detail;
  if(e.reply.ok){d.request="command_ack";d.error="late";}
  else if(strcmp(d.error,"none")==0){d.request="command_ack";d.error="unconfirmed";}
  record(now,e,"native",d);
  fail(now,p==ShutdownPhase::StoppingCapture?"Capture stop unconfirmed; closure inhibited":"Arm command unconfirmed; closure inhibited");return;
 }
 if(command&&!acknowledged&&uint32_t(now-status_.phaseAt)>15000){
  auto d=e.reply.operation==status_.operation?e.reply.detail:ShutdownRequest{};
  if(strcmp(d.error,"none")==0){d.request="command_ack";d.error="timeout";}
  record(now,e,"native",d);fail(now,"Telescope command timed out; closure inhibited");return;
 }
 if((p==ShutdownPhase::VerifyingIdle||p==ShutdownPhase::VerifyingStow)&&uint32_t(now-status_.phaseAt)>(p==ShutdownPhase::VerifyingIdle?30000U:60000U)){
  if(!status_.recovering){
   if(!e.native.fresh(now)&&strcmp(e.native.detail.error,"none"))record(now,e,"native",e.native.detail);
   else issue("status_verification","timeout");
  }
  fail(now,p==ShutdownPhase::VerifyingIdle?"Imaging or telescope motion did not stop; closure inhibited":"Telescope stow not confirmed; closure inhibited");return;
 }
 if(!scopeUsable(now,e.scope)||status_.recovering){
  if(p==ShutdownPhase::Closing||!e.coverOpen||!e.scope.enabled){
   recordAlpaca(now,e);fail(now,"Alpaca status lost; closure inhibited");return;
  }
  if(!recover(now,e))return;
 }
 if(p==ShutdownPhase::StoppingCapture||p==ShutdownPhase::Stowing){
  if(acknowledged){
   enter(p==ShutdownPhase::StoppingCapture?ShutdownPhase::VerifyingIdle:ShutdownPhase::VerifyingStow,now,
         p==ShutdownPhase::StoppingCapture?"Verifying imaging stopped and telescope stationary":"Verifying telescope securely stowed");
  }
  return;
 }
 if(p==ShutdownPhase::Closing){
  if(!closePermitted(now,e)){issue("close_clearance","lost");fail(now,"Telescope clearance lost; stopping cover");return;}
  if(e.coverClosed&&e.coverStationary&&e.torqueOff)enter(ShutdownPhase::Complete,now,"Shutdown complete: telescope stowed, cover at saved closed position");
  else if(uint32_t(now-status_.phaseAt)>35000){issue("cover_close","timeout");fail(now,"Cover closure timed out; inspect mechanism");}
  return;
 }
 if(e.native.operation!=status_.operation||!e.native.fresh(now)||!e.scope.fresh(now))return;
 if(int32_t(e.native.sampledAt-status_.phaseAt)<=0||int32_t(e.scope.sampledAt-status_.phaseAt)<=0)return;
 if(e.native.sequence==nativeSequence_||e.scope.sequence==scopeSequence_)return;
 nativeSequence_=e.native.sequence;scopeSequence_=e.scope.sequence;
 const bool stationary=e.native.quiet(now)&&!e.scope.slewing&&!e.scope.tracking;
 const bool stowed=stationary&&e.native.closed&&e.scope.stowedCandidate(now);
 if(!(p==ShutdownPhase::VerifyingIdle?stationary:stowed)){confirmations_=0;return;}
 if(++confirmations_<2)return;
 if(p==ShutdownPhase::VerifyingStow||stowed)enter(ShutdownPhase::Closing,now,"Telescope stow verified; closing cover");
 else if(e.coverOpen&&!e.native.closed&&!e.scope.atHome)enter(ShutdownPhase::Stowing,now,"Lowering telescope arm; cover locked open");
 else fail(now,"Telescope and cover positions disagree; closure inhibited");
}
bool EmergencyShutdown::finish(uint32_t now,const ShutdownEvidence& e){
 if(status_.active()||!status_.locked()||!e.positionFresh||!e.calibrationClean||!e.coverStationary||!e.torqueOff||
    !e.scope.fresh(now)||!e.scope.connected||e.scope.slewing||e.scope.tracking||
    e.native.operation!=status_.operation||!e.native.quiet(now))return false;
 enter(ShutdownPhase::Idle,now,"Shutdown lock cleared after inspection; no movement requested");return true;
}
const char* shutdownPhaseName(ShutdownPhase p){switch(p){
 case ShutdownPhase::Idle:return "idle";case ShutdownPhase::StoppingCapture:return "stopping_capture";
 case ShutdownPhase::VerifyingIdle:return "verifying_idle";case ShutdownPhase::Stowing:return "stowing";
 case ShutdownPhase::VerifyingStow:return "verifying_stow";case ShutdownPhase::Closing:return "closing";
 case ShutdownPhase::Complete:return "complete";case ShutdownPhase::Fault:return "fault";case ShutdownPhase::Cancelled:return "cancelled";
 }return "fault";}
}
