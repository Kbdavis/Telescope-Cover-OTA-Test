#pragma once

// Future physical limit, rain, and environmental sensor interface.
// Unavailable sensors must never be reported as confirmed safe.
