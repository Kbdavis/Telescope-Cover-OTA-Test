#pragma once
namespace cover { void beginMotionBench(); void pollMotionBench(); }
