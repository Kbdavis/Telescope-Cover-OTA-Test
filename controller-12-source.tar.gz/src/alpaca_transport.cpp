#ifdef COVER_WEB_CONTROL
#include "alpaca_client.h"
#include "alpaca_telemetry.h"
#include "settings.h"
#include "diagnostics.h"
#include "web_control.h"
#include <WiFi.h>
#include <cJSON.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <math.h>
#include <sys/socket.h>
#include <errno.h>
namespace cover {
namespace {
portMUX_TYPE alpacaMux=portMUX_INITIALIZER_UNLOCKED;
alpaca::Snapshot sharedAlpaca;
alpaca::StowStatus sharedStow;
alpaca::Telemetry sharedTelemetry;
void publish(const alpaca::Snapshot& s){portENTER_CRITICAL(&alpacaMux);sharedAlpaca=s;portEXIT_CRITICAL(&alpacaMux);}
class HttpTransport:public alpaca::Transport {
 ApplicationSettings settings_;
 uint32_t deadlineMs_;
 public:
 explicit HttpTransport(const ApplicationSettings& s,uint32_t deadlineMs=1200):settings_(s),deadlineMs_(deadlineMs){}
 alpaca::Reply get(alpaca::Property property,uint32_t transaction) override {
  return request(alpaca::propertyName(property),transaction,false);
 }
 alpaca::Reply findHome(uint32_t transaction) override {return request("findhome",transaction,true);}
 alpaca::Reply connectSession(uint32_t transaction) override {
  const auto result=request("connected",transaction,true);
  diagnosticLog("ALPACA connect error=%s driver=%ld elapsed_ms=%lu",alpaca::errorName(result.error),
   (long)result.driverError,(unsigned long)result.elapsedMs);
  return result;
 }
 alpaca::Reply getMetric(alpaca::Metric metric,uint32_t transaction) override {
  using alpaca::Metric;
  switch(metric){
   case Metric::CameraConnected:return request("connected",transaction,false,"camera");
   case Metric::CameraState:return request("camerastate",transaction,false,"camera");
   case Metric::CameraTemperature:return request("ccdtemperature",transaction,false,"camera");
   case Metric::HeaterConnected:return request("connected",transaction,false,"switch");
   case Metric::HeaterCount:return request("maxswitch",transaction,false,"switch");
   case Metric::HeaterIdentity:return request("getswitchname",transaction,false,"switch","&Id=0");
   case Metric::HeaterState:return request("getswitch",transaction,false,"switch","&Id=0");
  }
  alpaca::Reply r;r.error=alpaca::Error::Unsupported;return r;
 }
 alpaca::Reply connectAuxiliary(alpaca::Auxiliary device,uint32_t transaction) override {
  return request("connected",transaction,true,device==alpaca::Auxiliary::Camera?"camera":"switch");
 }
 private:
 alpaca::Reply request(const char* property,uint32_t transaction,bool put,const char* family="telescope",const char* query=""){
  const uint32_t start=millis();bool attempted=false;
  auto result=[&](alpaca::Error e,bool value=false,int32_t driver=0){alpaca::Reply r;r.error=e;r.value=value;r.driverError=driver;r.elapsedMs=millis()-start;if(attempted)noteAlpacaRequest(e!=alpaca::Error::None,e==alpaca::Error::Timeout,r.elapsedMs);return r;};
  // Monitoring may establish logical sessions, but never operate the telescope,
  // camera or heater. Keep the write allowlist here, below all public callers.
  const bool session=strcmp(property,"connected")==0 &&
   (strcmp(family,"telescope")==0 || strcmp(family,"camera")==0 || strcmp(family,"switch")==0);
  if(put && !session)return result(alpaca::Error::Unsupported);
  if(WiFi.status()!=WL_CONNECTED)return result(alpaca::Error::Offline);
  // Numeric IPv4 keeps DNS resolution outside this bounded first transport.
  IPAddress ip;if(!ip.fromString(settings_.alpacaHost))return result(alpaca::Error::Protocol);
  WiFiClient socket;socket.setTimeout(1);
  attempted=true;
  if(!socket.connect(ip,settings_.alpacaPort,300))return result(alpaca::Error::Timeout);
  char request[480],form[80];
  snprintf(form,sizeof(form),"ClientID=731&ClientTransactionID=%lu%s",(unsigned long)transaction,
   put && strcmp(property,"connected")==0?"&Connected=true":query);
  const unsigned device=strcmp(family,"telescope")==0?settings_.alpacaDevice:0;
  int size=put?snprintf(request,sizeof(request),"PUT /api/v1/%s/%u/%s HTTP/1.0\r\nHost: %s:%u\r\nConnection: close\r\nContent-Type: application/x-www-form-urlencoded\r\nContent-Length: %u\r\n\r\n%s",family,device,property,settings_.alpacaHost,settings_.alpacaPort,unsigned(strlen(form)),form):
   snprintf(request,sizeof(request),"GET /api/v1/%s/%u/%s?%s HTTP/1.0\r\nHost: %s:%u\r\nConnection: close\r\nAccept: application/json\r\n\r\n",family,device,property,form,settings_.alpacaHost,settings_.alpacaPort);
  if(size<=0 || size>=int(sizeof(request))){socket.stop();return result(alpaca::Error::Protocol);}
  // WiFiClient::write can retry for many seconds; use deadline-limited sends.
  int sent=0;
  while(sent<size && millis()-start<deadlineMs_){
   int n=::send(socket.fd(),request+sent,size-sent,MSG_DONTWAIT);
   if(n>0)sent+=n;
   else if(n<0 && errno!=EAGAIN && errno!=EWOULDBLOCK && errno!=EINTR)break;
   else vTaskDelay(pdMS_TO_TICKS(1));
  }
  if(sent!=size){socket.stop();return result(alpaca::Error::Timeout);}
  char header[1025]={},body[2049]={};size_t used=0;bool done=false;
  while(millis()-start<deadlineMs_ && used<1024){
   if(socket.available()){header[used++]=char(socket.read());if(used>=4 && memcmp(header+used-4,"\r\n\r\n",4)==0){done=true;break;}}
   else if(!socket.connected())break;else vTaskDelay(pdMS_TO_TICKS(1));
  }
  if(!done){socket.stop();return result(used==1024?alpaca::Error::Oversized:alpaca::Error::Timeout);}
  int code=0;if(sscanf(header,"HTTP/%*u.%*u %d",&code)!=1 || code!=200){socket.stop();return result(alpaca::Error::Http);}
  long length=-1;bool bad=false;
  bool closeDelimited=strncmp(header,"HTTP/1.0 ",9)==0;
  for(char* line=strstr(header,"\r\n")+2;*line && strncmp(line,"\r\n",2)!=0;){
   char* end=strstr(line,"\r\n");if(!end){bad=true;break;}*end=0;
   if(strncasecmp(line,"Content-Length:",15)==0){
    char* tail=nullptr;const char* value=line+15;while(*value==' ')++value;
    long n=strtol(value,&tail,10);if(length!=-1 || tail==value || *tail!=0 || n<1)bad=true;length=n;
   }
   if(strncasecmp(line,"Connection:",11)==0){const char* value=line+11;while(*value==' ')++value;if(strcasecmp(value,"close")==0)closeDelimited=true;}
   if(strncasecmp(line,"Transfer-Encoding:",18)==0)bad=true;
   line=end+2;
  }
  if(bad || (length<0 && !closeDelimited) || length>2048){socket.stop();return result(length>2048?alpaca::Error::Oversized:alpaca::Error::Protocol);}
  used=0;bool complete=false;
  while(millis()-start<deadlineMs_){
   if(length>=0 && used==size_t(length)){complete=true;break;}
   if(socket.available()){
    if(used>=2048){socket.stop();return result(alpaca::Error::Oversized);}
    body[used++]=char(socket.read());
   }else if(!socket.connected()){complete=length<0 && used>0;break;}
   else vTaskDelay(pdMS_TO_TICKS(1));
  }
  socket.stop();if(!complete)return result(alpaca::Error::Timeout);
  if(memchr(body,0,used))return result(alpaca::Error::Protocol);
  // Cap JSON nesting before the recursive parser touches its task stack.
  int depth=0;bool quoted=false,escaped=false;
  for(size_t i=0;i<used;++i){char c=body[i];
   if(quoted){if(escaped)escaped=false;else if(c=='\\')escaped=true;else if(c=='"')quoted=false;}
   else if(c=='"')quoted=true;
   else if(c=='{' || c=='['){if(++depth>16)return result(alpaca::Error::Protocol);}
   else if(c=='}' || c==']'){if(--depth<0)return result(alpaca::Error::Protocol);}
  }
  const char* end=nullptr;cJSON* root=cJSON_ParseWithLengthOpts(body,used+1,&end,true);
  if(!root || !cJSON_IsObject(root)){cJSON_Delete(root);return result(alpaca::Error::Protocol);}
  // Reject duplicate members instead of accepting the first ambiguous value.
  for(cJSON* a=root->child;a;a=a->next)for(cJSON* b=a->next;b;b=b->next)if(strcmp(a->string,b->string)==0)bad=true;
  cJSON* error=cJSON_GetObjectItemCaseSensitive(root,"ErrorNumber");
  cJSON* tx=cJSON_GetObjectItemCaseSensitive(root,"ClientTransactionID");
  cJSON* serverTx=cJSON_GetObjectItemCaseSensitive(root,"ServerTransactionID");
  cJSON* msg=cJSON_GetObjectItemCaseSensitive(root,"ErrorMessage");
  cJSON* value=cJSON_GetObjectItemCaseSensitive(root,"Value");
  auto integer=[](cJSON* v,double max){return cJSON_IsNumber(v) && isfinite(v->valuedouble) && v->valuedouble>=0 && v->valuedouble<=max && floor(v->valuedouble)==v->valuedouble;};
  alpaca::Reply reply;
  if(bad || !integer(error,2147483647) || !integer(tx,4294967295.0) || tx->valuedouble!=transaction || !integer(serverTx,4294967295.0) || !cJSON_IsString(msg))reply=result(alpaca::Error::Protocol);
  else if(error->valueint!=0)reply=result(error->valueint==1024?alpaca::Error::Unsupported:alpaca::Error::Driver,false,error->valueint);
  else if(put)reply=result(alpaca::Error::None);
  else if(strcmp(property,"getswitchname")==0){
   if(!cJSON_IsString(value))reply=result(alpaca::Error::Protocol);
   else reply=result(strcasecmp(value->valuestring,"Dew heater")==0?alpaca::Error::None:alpaca::Error::Unsupported,true);
  }
  else if(strcmp(property,"altitude")==0 || strcmp(property,"azimuth")==0 || strcmp(property,"ccdtemperature")==0 || strcmp(property,"camerastate")==0 || strcmp(property,"maxswitch")==0){
   double low=0,high=0;bool whole=false;
   if(strcmp(property,"altitude")==0){low=-90;high=90;}
   else if(strcmp(property,"azimuth")==0){high=360;}
   else if(strcmp(property,"ccdtemperature")==0){low=-273.15;high=150;}
   else if(strcmp(property,"camerastate")==0){high=5;whole=true;}
   else {high=16;whole=true;}
   if(!cJSON_IsNumber(value) || !isfinite(value->valuedouble) || value->valuedouble<low || value->valuedouble>high || (whole && floor(value->valuedouble)!=value->valuedouble))reply=result(alpaca::Error::Protocol);
   else{reply=result(alpaca::Error::None);reply.number=value->valuedouble;}
  }
  else if(!cJSON_IsBool(value))reply=result(alpaca::Error::Protocol);
  else reply=result(alpaca::Error::None,cJSON_IsTrue(value));
  cJSON_Delete(root);return reply;
 }
};
void alpacaWorker(void*) {
 ApplicationSettings config;
 if(loadApplicationSettings(config)!=SettingsLoad::Loaded || !config.alpacaEnabled){publish(alpaca::Snapshot{});registerMaintenanceWorker(kMaintenanceAlpacaWorker,false);vTaskDelete(nullptr);return;}
 HttpTransport transport(config);alpaca::Client client(transport);client.enable(true,true);
 HttpTransport optionalTransport(config,700);
 alpaca::TelemetryClient telemetry(optionalTransport);uint32_t telemetrySequence=0,optionalAt=0;
 constexpr uint32_t statusLogIntervalMs=60000;
 uint32_t statusLogAt=0;bool statusLogged=false;
 MaintenanceLease pausedLease;
 for(;;){
  noteTaskStack(DiagnosticTask::Alpaca);
  const auto pause=otaMaintenanceForWorker();
  if(pause){
   if(!sameLease(pausedLease,pause)){
    pausedLease=pause;client.enable(false);telemetry.reset();
    auto unavailable=alpaca::Snapshot{};unavailable.enabled=true;unavailable.error=alpaca::Error::Offline;publish(unavailable);
    portENTER_CRITICAL(&alpacaMux);sharedTelemetry=alpaca::Telemetry{};portEXIT_CRITICAL(&alpacaMux);
    acknowledgeMaintenancePause(pause,kMaintenanceAlpacaWorker);
   }
   vTaskDelay(pdMS_TO_TICKS(25));continue;
  }
  if(pausedLease){pausedLease=MaintenanceLease{};client.enable(true,true);telemetry.reset();telemetrySequence=0;optionalAt=0;}
  client.step(millis());auto snapshot=client.status(millis());
  publish(snapshot);
  const bool connected=snapshot.valid && snapshot.connected;
  const uint32_t statusLogNow=millis();
  // Polling can alternate between transient failures and recovery. Bound routine
  // status output independently of transitions so it cannot flood the log ring.
  if(!statusLogged || uint32_t(statusLogNow-statusLogAt)>=statusLogIntervalMs){
   diagnosticEvent(DebugLevel::Info,"ALPACA %s error=%s request=%s driver=%ld",
    connected?"connection available":!snapshot.sequence && (snapshot.error==alpaca::Error::None || WiFi.status()!=WL_CONNECTED)?"Waiting for status":"connection unavailable",
    alpaca::errorName(snapshot.error),snapshot.failure.request,(long)snapshot.driverError);
   statusLogAt=statusLogNow;statusLogged=true;
  }
  // Optional display telemetry: outside the safety sweep and never grants clearance.
  if(snapshot.valid && snapshot.sequence!=telemetrySequence && client.optionalWindow(millis(),750) && (!optionalAt || uint32_t(millis()-optionalAt)>=2000)){
   telemetrySequence=snapshot.sequence;optionalAt=millis();
   telemetry.step(millis(),true);
   portENTER_CRITICAL(&alpacaMux);sharedTelemetry=telemetry.status();portEXIT_CRITICAL(&alpacaMux);
  }
  vTaskDelay(pdMS_TO_TICKS(25));
 }
}
}
bool requestAlpacaStow(){return false;} // Monitoring only; telescope movement belongs to the app.
alpaca::StowStatus alpacaStowStatus(){portENTER_CRITICAL(&alpacaMux);auto s=sharedStow;portEXIT_CRITICAL(&alpacaMux);return s;}
bool alpacaAltitude(double& degrees,uint32_t& ageMs){
 const auto value=alpacaTelemetry().altitude;degrees=value.value;ageMs=millis()-value.at;
 return value.valid && ageMs<=5000 && alpacaStatus().fresh(millis());
}
alpaca::Telemetry alpacaTelemetry(){portENTER_CRITICAL(&alpacaMux);auto s=sharedTelemetry;portEXIT_CRITICAL(&alpacaMux);return s;}
void beginAlpaca(){
 registerMaintenanceWorker(kMaintenanceAlpacaWorker,true);
 if(xTaskCreatePinnedToCore(alpacaWorker,"alpaca",12288,nullptr,1,nullptr,0)!=pdPASS){
  registerMaintenanceWorker(kMaintenanceAlpacaWorker,false);
  alpaca::Snapshot s;s.enabled=true;s.error=alpaca::Error::Offline;publish(s);diagnosticEvent(DebugLevel::Error,"ALLOC Alpaca worker failed");
 }
}
alpaca::Snapshot alpacaStatus(){portENTER_CRITICAL(&alpacaMux);auto s=sharedAlpaca;portEXIT_CRITICAL(&alpacaMux);const uint32_t now=millis();if(s.valid && !s.fresh(now)){s.valid=false;s.error=alpaca::Error::Timeout;s.consecutiveStowed=0;s.failure={"status_age",0,0,now};}return s;}
}
#endif
