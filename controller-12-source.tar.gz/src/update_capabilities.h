#pragma once
#ifdef COVER_WEB_CONTROL
#include <Arduino.h>
namespace cover {
// Passive report only: no servo I/O, settings writes or maintenance reservation.
String updateCapabilitiesJson();
}
#endif
