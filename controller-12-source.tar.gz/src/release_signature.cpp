#if defined(COVER_WEB_CONTROL) || defined(COVER_RELEASE_SIGNATURE_SELFTEST) || defined(COVER_BENCH_OTA)
#include "release_signature.h"
#include <mbedtls/ecdsa.h>
#include <mbedtls/sha256.h>
namespace cover {
bool verifyReleaseP256(const uint8_t* payload,size_t size,const uint8_t* signature,const uint8_t* publicPoint){
 if(!payload || !size || size>kReleasePayloadLimit || !signature || !publicPoint || publicPoint[0]!=4)return false;
 uint8_t digest[32]={};
 if(mbedtls_sha256_ret(payload,size,digest,0)!=0)return false;
 mbedtls_ecp_group group;mbedtls_ecp_point point;mbedtls_mpi r,s;
 mbedtls_ecp_group_init(&group);mbedtls_ecp_point_init(&point);mbedtls_mpi_init(&r);mbedtls_mpi_init(&s);
 const bool valid=mbedtls_ecp_group_load(&group,MBEDTLS_ECP_DP_SECP256R1)==0 &&
  mbedtls_ecp_point_read_binary(&group,&point,publicPoint,kReleasePublicKeyBytes)==0 &&
  mbedtls_ecp_check_pubkey(&group,&point)==0 &&
  mbedtls_mpi_read_binary(&r,signature,32)==0 && mbedtls_mpi_read_binary(&s,signature+32,32)==0 &&
  mbedtls_ecdsa_verify(&group,digest,sizeof(digest),&point,&r,&s)==0;
 mbedtls_mpi_free(&s);mbedtls_mpi_free(&r);mbedtls_ecp_point_free(&point);mbedtls_ecp_group_free(&group);
 return valid;
}
}
#endif
