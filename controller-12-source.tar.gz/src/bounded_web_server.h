#pragma once
#include <WebServer.h>
#include <memory>
#include <new>
#include <lwip/sockets.h>
#include "http_request.h"
#include "ota_memory_probe.h"
#include "usb_memory_probe.h"
namespace cover {
// Adapter for the pinned Arduino WebServer routing/response API. Never calls
// its unbounded _parseRequest/_parseForm or its blocking input helpers.
class BoundedWebServer:public WebServer {
 public:
  explicit BoundedWebServer(int port=80):WebServer(port){}
  bool listening(){return bool(_server);}
  // A handler may retain this one connection while another task finishes work.
  // The callback must be nonblocking and return true only after sending a response.
  void deferResponse(bool (*ready)()){deferred_=ready;deferredAt_=millis();}
  void close()override{deferred_=nullptr;request_.reset();WebServer::close();}
  void handleClient()override{
   if(deferred_){
    if(!_currentClient.connected()){release();return;}
    if(uint32_t(millis()-deferredAt_)>=5000){send(503,"text/plain","Worker acknowledgement timed out; inspect transaction");release();return;}
    if(deferred_())release();
    return;
   }
   if(!request_){
    _currentClient=_server.available();
    if(!_currentClient)return;
    request_.reset(new(std::nothrow) HttpRequest(millis()));
    if(!request_){_currentClient.stop();_currentClient=WiFiClient();return;}
   }
   auto& request=*request_;
   request.expired(millis());
   // A short byte budget per loop; slow clients never monopolize input parsing.
   for(unsigned n=0;n<256 && !request.error && !request.ready && _currentClient.available();++n){
    const int c=_currentClient.read();if(c<0)break;request.feed(char(c),millis());
   }
   if(request.ready && _currentClient.available())request.error=400; // no pipelining/trailers
   if(request.error){
    // Fixed response, no reflected request values and no event/serial logging.
    // A single nonblocking best-effort write; never enter WiFiClient's retry loop.
    char response[128];int size=snprintf(response,sizeof(response),
     "HTTP/1.1 %u Rejected\r\nConnection: close\r\nContent-Length: 0\r\n\r\n",request.error);
    ::send(_currentClient.fd(),response,size,MSG_DONTWAIT);
    release();return;
   }
   if(request.ready){
    noteUsbMemoryHttp(request.bytes+request.target);
    otaMemoryBoundary(OtaMemoryStage::RequestArena);
    const bool routed=prepareDispatch(request);
    request_.reset(); // No input arena retained while a handler builds its response.
    otaMemoryBoundary(OtaMemoryStage::RequestReleased);
    if(routed)_handleRequest();
    if(!deferred_)release();
    return;
   }
   if(!_currentClient.connected())release();
  }
 private:
  std::unique_ptr<HttpRequest> request_;
  bool (*deferred_)()=nullptr;
  uint32_t deferredAt_=0;
  void release(){
   deferred_=nullptr;
   _currentClient.stop();_currentClient=WiFiClient();request_.reset();
   _currentStatus=HC_NONE;_currentHandler=nullptr;_currentUri=String();_hostHeader=String();
   if(_currentArgs){delete[] _currentArgs;_currentArgs=nullptr;}_currentArgCount=0;
   for(int i=0;i<_headerKeysCount;++i)_currentHeaders[i].value=String();
   _responseHeaders=String();_currentUpload.reset();_currentRaw.reset();
  }
  bool prepareDispatch(const HttpRequest& request){
   _currentMethod=request.method==HttpRequest::Method::Get?HTTP_GET:HTTP_POST;
   _currentVersion=request.version;_currentUri=request.bytes+request.target;
   _hostHeader=request.header("Host");_clientContentLength=request.length;
   _chunked=false;_contentLength=CONTENT_LENGTH_NOT_SET;_responseHeaders=String();
   for(int i=0;i<_headerKeysCount;++i)_currentHeaders[i].value=String();
   for(size_t i=0;i<request.fieldCount;++i)_collectHeader(request.bytes+request.fields[i].name,request.bytes+request.fields[i].value);
   String args=request.query?request.bytes+request.query:"";
   if(request.encoded() && request.length){if(args.length())args+='&';args+=request.bytes+request.body;}
   // Input sizes and argument count are already bounded. Parse without the
   // framework's verbose argument logging (forms can contain WiFi credentials).
   size_t slots=1;
   if(args.length()){++slots;for(size_t i=0;i<args.length();++i)if(args[i]=='&')++slots;}
   _currentArgCount=0;_currentArgs=new(std::nothrow) RequestArgument[slots];
   if(!_currentArgs)return false;
   int start=0;
   while(start<int(args.length())){
    int end=args.indexOf('&',start);if(end<0)end=args.length();
    int equal=args.indexOf('=',start);
    if(equal>=start && equal<end){auto& arg=_currentArgs[_currentArgCount++];arg.key=urlDecode(args.substring(start,equal));arg.value=urlDecode(args.substring(equal+1,end));}
    start=end+1;
   }
   if(!request.encoded() && request.length){auto& arg=_currentArgs[_currentArgCount++];arg.key="plain";arg.value=request.bytes+request.body;}
   _currentHandler=nullptr;
   for(auto* handler=_firstHandler;handler;handler=handler->next())if(handler->canHandle(_currentMethod,_currentUri)){_currentHandler=handler;break;}
   _currentClient.setTimeout(1); // Existing response path; not an input deadline.
   return true;
  }
};
}
