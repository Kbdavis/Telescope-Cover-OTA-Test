#pragma once
#include <Arduino.h>
#include "settings.h"
#include "cover_controller.h"
#include "emergency_shutdown.h"
#include "maintenance.h"
#ifndef COVER_WEB_JOG_SPEED
#define COVER_WEB_JOG_SPEED 100
#endif
namespace cover {
constexpr uint16_t kWebJogSpeed = COVER_WEB_JOG_SPEED;
static_assert(kWebJogSpeed >= 1 && kWebJogSpeed <= 100, "Web bench speed must be 1..100");
struct HeartbeatEvidence {
 uint32_t client=0,sequence=0,received=0,processed=0,previousAge=0;
 bool renewed=false;
};
struct WebStatus {
 HeartbeatEvidence heartbeatLast,heartbeatAtFault;
 uint32_t heartbeatFaultAt=0,heartbeatFaultAge=0;

 MotionTrace motionTrace;
 bool calibrationOnly=false;
 bool settingsOfflineAllowed=false; // Worker-confirmed communication loss; never motion clearance.
 bool ready=false, manualReady=false, moving=false, holding=false, positionValid=false, torqueValid=false, torque=false;
 uint16_t position=0;
 uint16_t activeMinimum=kDefaultMinimum,activeMaximum=kDefaultMaximum;
 uint32_t positionAt=0, owner=0;
 uint32_t motionMs=0, heartbeatAgeMs=0, maxHeartbeatGapMs=0, timeoutMs=5000;
 uint16_t target=0;
 Calibration draft, saved;
 ShutdownStatus shutdown;
 uint32_t commandId=0,commandClient=0;bool commandOk=false;
 bool telemetryValid=false;uint32_t telemetryAt=0;
 uint8_t voltageDecivolts=0,temperatureC=0;int16_t relativeLoad=0,currentRaw=0;
 bool calibrated=false, dirty=false, calibrationReview=false, teaching=false, rolloverSupported=false;
 uint16_t jogStepLimit=500;
#if defined(COVER_REFERENCE_PROBE) || defined(COVER_MULTITURN_STARTUP)
 ReferenceProbeEvidence referenceProbe;
#endif
 char notice[100]="";
 char state[16]="UNKNOWN", fault[80]="Starting";
};
enum class WebCommandType { JogPlus, JogMinus, ManualJogPlus, ManualJogMinus, Heartbeat, Stop, Recover, CaptureOpen, CaptureClosed, SetLimits, SaveCalibration, Open, Close, TorqueTest, CloseStowed, SetProfile, DiscardCalibration, SetDirection, BeginTeaching
#ifdef COVER_REFERENCE_PROBE
 ,ProbeReference,RestoreReference
#endif
 ,CloseManualStow
 };
struct WebCommand { WebCommandType type; uint32_t client; uint32_t received; uint32_t sequence=0,controlGeneration=0; bool retainTorque=false,retainClosed=false,resumeTeaching=false; uint16_t minimum=0, maximum=0, step=100; MotionProfile profile; int8_t openingDirection=0; };
// Network setup requests a worker-acknowledged pause before touching Wi-Fi.
MaintenanceLease requestNetworkMaintenance(uint32_t controlGeneration);
MaintenanceLease requestRebootMaintenance(bool retainTorque,uint32_t client,uint32_t controlGeneration);
void markRetainedReboot(bool retainTorque);
bool networkMaintenanceReady(MaintenanceLease lease={});
bool endNetworkMaintenance(MaintenanceLease lease={});
MaintenanceSnapshot maintenanceStatus();
bool maintenanceReady(MaintenanceLease lease);
bool requestMaintenanceRelease(MaintenanceLease lease);
bool controlRequestAllowed(uint32_t generation);
bool heartbeatRequestAllowed(uint32_t generation);
MaintenanceLease requestOtaMaintenance(const OtaMaintenanceRequirements& requirements,uint32_t generation);
bool beginOtaCommit(MaintenanceLease lease);
void beginStartupValidation(bool discardRetainedTorque,bool requireClosed=false,bool allowPowered=false,bool inspectServoOnly=false);
void finishStartupValidation(bool accepted);
bool confirmMaintenanceCleanup(MaintenanceLease lease);
void noteMaintenanceNetwork(bool staOnly);
bool maintenanceMayExposeAp();
void registerMaintenanceWorker(uint8_t worker,bool running);
MaintenanceLease otaMaintenanceForWorker();
void acknowledgeMaintenancePause(MaintenanceLease lease,uint8_t worker);
bool submitAutomaticStop(uint32_t client,uint32_t observedGeneration);
bool requestEmergencyShutdown(uint32_t stopEpoch);
uint32_t emergencyStopEpoch();
bool requestEmergencyInspection();
bool emergencyShutdownLocked();
bool emergencyWorkPermitted(uint32_t operation,ShutdownAction action);
void beginWebControl();
bool submitWebCommand(WebCommandType type,uint32_t client,uint16_t minimum=0,uint16_t maximum=0,uint32_t sequence=0,bool retainTorque=false,uint16_t step=100,const MotionProfile& profile=MotionProfile{},uint32_t controlGeneration=0,int8_t openingDirection=0,bool retainClosed=false,bool resumeTeaching=false);
WebStatus webStatus();
}
