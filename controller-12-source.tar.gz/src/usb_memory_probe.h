#pragma once
#include <stdint.h>
namespace cover {
enum class DiagnosticTask:uint8_t;
#if defined(COVER_OTA_USB_MEMORY_PROBE) && (!defined(COVER_USB_MEMORY_PROBE) || !defined(COVER_OTA_FLASH_PROBE) || defined(COVER_OTA_MEMORY_PROBE))
#error Passive OTA USB measurement requires only the nonactivating flash experiment and USB collector
#endif
#ifdef COVER_USB_MEMORY_PROBE
#if defined(COVER_OTA_RESOURCE_PROBE) || (defined(COVER_OTA_FLASH_PROBE) && !defined(COVER_OTA_USB_MEMORY_PROBE))
#error USB baseline must not include an OTA experiment
#endif
void beginUsbMemoryProbe();
void pollUsbMemoryProbe(unsigned queued,uint32_t dropped,uint32_t truncated);
void noteUsbMemoryStack(DiagnosticTask task);
void noteUsbMemoryHttp(const char* path);
#else
inline void beginUsbMemoryProbe(){}
inline void pollUsbMemoryProbe(unsigned,uint32_t,uint32_t){}
inline void noteUsbMemoryStack(DiagnosticTask){}
inline void noteUsbMemoryHttp(const char*){}
#endif
}
