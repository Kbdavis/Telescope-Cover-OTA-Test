#include "close_dry_run.h"
namespace cover {
const char* CloseDryRun::name() const {
 switch(phase_){case Phase::Idle:return "idle";case Phase::Stowing:return "stowing";
 case Phase::Rechecking:return "rechecking";case Phase::Ready:return "ready_to_close";
 case Phase::Cancelled:return "cancelled";}return "unknown";
}
void CloseDryRun::step(uint32_t now,const alpaca::StowStatus& test,const alpaca::Snapshot& scope,bool coverChecks){
 if(!active())return;
 if(!coverChecks){cancel("Cover interlock or calibration check failed");return;}
 if(uint32_t(now-started_)>195000){cancel("Dry-run deadline expired; inspect telescope");return;}
 if(scope.error!=alpaca::Error::None){cancel("Telescope communication failed; no automatic retry");return;}
 if(phase_==Phase::Stowing){
  if(test.operation!=operation_)return; // Never reuse a previous operation's success.
  if(test.phase==alpaca::StowPhase::Failed || test.phase==alpaca::StowPhase::Unknown){cancel("Stow failed or outcome unknown");return;}
  if(test.phase==alpaca::StowPhase::Complete){phase_=Phase::Rechecking;recheckAt_=now;reason_="Stowed; obtaining a new final telescope observation";}
  return;
 }
 if(!scope.stowedCandidate(now)){cancel("Telescope clearance lost; inspect before a new test");return;}
 if(phase_==Phase::Rechecking && int32_t(scope.sampledAt-recheckAt_)>=0){
  phase_=Phase::Ready;reason_="Ready to close - dry run only; cover feedback simulated, no movement authorized";
 }
 // Continue observing in Ready. Lost clearance permanently cancels this run.
}
}
