#pragma once
#include "cover_controller.h"
namespace cover {
struct EndpointChange { State state; uint16_t previous, position; };
class EndpointObserver {
 public:
  bool observe(State state,bool valid,uint16_t position,EndpointChange& change) {
   if(state!=State::Open && state!=State::Closed){known_=false;return false;}
   if(!valid || position>4095)return false;
   if(!known_ || state!=state_){known_=true;state_=state;last_=position;return false;}
   if(position==last_)return false;
   change={state,last_,position};last_=position;return true;
  }
 private:
  bool known_=false;State state_=State::Unknown;uint16_t last_=0;
};
}
