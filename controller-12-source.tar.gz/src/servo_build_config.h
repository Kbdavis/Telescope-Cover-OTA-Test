#pragma once

#if defined(COVER_BENCH_OTA) && (defined(COVER_WEB_CONTROL) || !defined(COVER_SERVO_READ_ONLY) || defined(COVER_MULTITURN_STARTUP) || defined(COVER_REFERENCE_PROBE) || defined(COVER_OTA_DEVELOPMENT))
#error "Bench OTA must exclude controller, motion preparation and development credentials"
#endif

#ifdef COVER_WEB_READ_ONLY
#if !defined(COVER_SERVO_READ_ONLY) || defined(COVER_MULTITURN_USB) || defined(COVER_MULTITURN_STARTUP) || defined(COVER_MULTITURN_PROBE) || defined(COVER_REFERENCE_PROBE) || defined(COVER_FIXED_REFERENCE) || defined(COVER_OTA_DEVELOPMENT) || defined(COVER_OTA_FLASH_PROBE) || defined(COVER_OTA_RESOURCE_PROBE) || defined(COVER_OTA_COMPILE_TEST) || defined(COVER_USB_MEMORY_PROBE)
#error "Read-only web preview must exclude write/commissioning/development modes"
#endif
#endif

// Native motion capability is separate from operator-only commissioning routes.
#ifdef COVER_MULTITURN_USB
#if defined(COVER_OTA_DEVELOPMENT) || defined(COVER_REFERENCE_PROBE) || defined(COVER_MULTITURN_PROBE) || defined(COVER_FIXED_REFERENCE) || defined(COVER_ROLLOVER_BENCH) || defined(COVER_SETTLE_SAMPLES) || defined(COVER_OTA_COMPILE_TEST) || defined(COVER_OTA_RESOURCE_PROBE) || defined(COVER_OTA_FLASH_PROBE) || defined(COVER_USB_MEMORY_PROBE)
#error "Production multi-turn USB cannot include development or probe features"
#endif
#define COVER_MULTITURN
#define COVER_MULTITURN_STARTUP
#endif
#ifdef COVER_MULTITURN_PROBE
#define COVER_MULTITURN
#endif
#if defined(COVER_MULTITURN_STARTUP) && !defined(COVER_MULTITURN)
#error "RAM startup requires the native multi-turn driver"
#endif

#ifdef COVER_BROWSER_OTA
#if !defined(COVER_MULTITURN) || defined(COVER_MULTITURN_STARTUP) || defined(COVER_MULTITURN_USB) || defined(COVER_REFERENCE_PROBE) || defined(COVER_OTA_DEVELOPMENT) || defined(COVER_WEB_READ_ONLY) || defined(COVER_SERVO_READ_ONLY)
#error "Signed browser controller requires native motion and inspect-only startup, without probes or local credentials"
#endif
#endif
