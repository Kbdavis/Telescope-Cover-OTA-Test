#if defined(COVER_WEB_CONTROL) || defined(COVER_POWER_HOST_TEST)
#include "seestar_power.h"
#include <cJSON.h>
#include <math.h>
#include <string.h>
#include <initializer_list>
namespace cover {
bool PowerMonitor::due(uint32_t now,bool armActive){
 if(status_.paused&&!armActive)refresh_=true;
 status_.paused=armActive;
 return !armActive && (refresh_||!attempted_||uint32_t(now-completedAt_)>=(status_.retrying?5000U:30000U));
}
void PowerMonitor::record(uint32_t now,const SeestarPower& reading){
 // A failed refresh must not extend the age of the last valid reading.
 if(reading.valid)status_=reading;
 status_.configured=true;status_.retrying=!reading.valid;status_.paused=false;
 attempted_=true;refresh_=false;completedAt_=now;
}
namespace {
bool unique(const cJSON* node){
 if(cJSON_IsObject(node))for(auto a=node->child;a;a=a->next)
  for(auto b=a->next;b;b=b->next)if(strcmp(a->string,b->string)==0)return false;
 for(auto c=node->child;c;c=c->next)if(!unique(c))return false;
 return true;
}
bool number(const cJSON* v,double low,double high){return cJSON_IsNumber(v)&&isfinite(v->valuedouble)&&v->valuedouble>=low&&v->valuedouble<=high;}
}
cJSON* parseSeestarFrame(const char* data,size_t length){
 if(!length || length>8192 || memchr(data,0,length))return nullptr;
 int depth=0;bool quoted=false,escaped=false;
 for(size_t i=0;i<length;i++){
  char c=data[i];
  if(quoted){if(escaped)escaped=false;else if(c=='\\')escaped=true;else if(c=='"')quoted=false;}
  else if(c=='"')quoted=true;
  else if(c=='{'||c=='['){if(++depth>12)return nullptr;}
  else if(c=='}'||c==']'){if(--depth<0)return nullptr;}
 }
 if(depth || quoted)return nullptr;
 const char* end=nullptr;
 cJSON* root=cJSON_ParseWithLengthOpts(data,length,&end,false);
 while(end && end<data+length && (*end==' '||*end=='\r'||*end=='\n'||*end=='\t'))++end;
 if(!root || !cJSON_IsObject(root) || end!=data+length || !unique(root)){cJSON_Delete(root);return nullptr;}
 return root;
}
bool seestarReplyOk(const cJSON* root,uint32_t id){
 const auto tx=cJSON_GetObjectItemCaseSensitive(root,"id");
 const auto code=cJSON_GetObjectItemCaseSensitive(root,"code");
 return number(tx,1,4294967295.0)&&tx->valuedouble==id && number(code,0,0);
}
bool parseSeestarPower(const cJSON* root,uint32_t id,uint32_t now,SeestarPower& out){
 out=SeestarPower{};out.configured=true;
 if(!seestarReplyOk(root,id))return false;
 const auto result=cJSON_GetObjectItemCaseSensitive(root,"result");
 const auto device=cJSON_GetObjectItemCaseSensitive(result,"device");
 const auto model=cJSON_GetObjectItemCaseSensitive(device,"product_model");
 if(!cJSON_IsString(model)||strcmp(model->valuestring,"Seestar S30 Pro")!=0)return false;
 const auto power=cJSON_GetObjectItemCaseSensitive(result,"pi_status");
 if(!cJSON_IsObject(power))return false;
 const auto battery=cJSON_GetObjectItemCaseSensitive(power,"battery_capacity");
 if(number(battery,0,100)&&floor(battery->valuedouble)==battery->valuedouble)out.batteryPercent=battery->valueint;
 const auto online=cJSON_GetObjectItemCaseSensitive(power,"charge_online");
 out.externalPowerValid=cJSON_IsBool(online);out.externalPower=cJSON_IsTrue(online);
 const auto temp=cJSON_GetObjectItemCaseSensitive(power,"battery_temp");
 out.batteryTemperatureValid=number(temp,-50,100);
 if(out.batteryTemperatureValid)out.batteryTemperature=temp->valuedouble;
 const auto hot=cJSON_GetObjectItemCaseSensitive(power,"battery_overtemp");
 out.batteryOvertempValid=cJSON_IsBool(hot);out.batteryOvertemp=cJSON_IsTrue(hot);
 const auto state=cJSON_GetObjectItemCaseSensitive(power,"charger_status");
 // Only known descriptive states are exported into JSON/HTML.
 if(cJSON_IsString(state))for(const char* name:{"Charging","Discharging","Full","Not charging","Unknown"})
  if(strcmp(state->valuestring,name)==0)strcpy(out.chargingState,name);
 out.valid=out.batteryPercent>=0||out.externalPowerValid||out.chargingState[0]||out.batteryTemperatureValid||out.batteryOvertempValid;
 if(out.valid)out.sampledAt=now;
 return out.valid;
}
}
#endif
