#include "telescope_arm.h"
#include <math.h>
namespace cover {
bool armStationary(uint32_t now,const ArmEvidence& e,bool inspectedStopped){return (e.coverOpen || (inspectedStopped && e.coverStoppedOpen)) && e.cameraIdle && e.scope.fresh(now) && e.scope.connected && !e.scope.slewing && !e.scope.tracking;}
bool ArmOperation::start(bool opening,uint32_t now,const ArmEvidence& e){
 if(status_.locked || !armStationary(now,e,!opening) || e.scope.atHome!=opening)return false;
 ++status_.operation;status_.opening=opening;status_.phase=ArmPhase::Checking;status_.locked=true;status_.reason="Checking telescope and cover";
 started_=now;confirmations_=0;lastSequence_=0;return true;
}
bool ArmOperation::readyToSend(uint32_t now,const ArmEvidence& e) const{
 return status_.phase==ArmPhase::Checking && uint32_t(now-started_)<3000 && e.maintenance && armStationary(now,e,!status_.opening) && e.scope.atHome==status_.opening;
}
void ArmOperation::sent(uint32_t now,bool acknowledged){
 if(status_.phase!=ArmPhase::Checking)return;
 sentAt_=now;
 if(!acknowledged){inspect("Arm command acknowledgment uncertain");return;}
 status_.phase=ArmPhase::Waiting;status_.reason="Waiting for verified arm completion";
}
void ArmOperation::step(uint32_t now,const ArmEvidence& e){
 if(!status_.active())return;
 if(!e.coverOpen && !(!status_.opening && e.coverStoppedOpen)){inspect("Open cover evidence lost");return;}
 if(!e.cameraIdle){inspect("Idle camera evidence lost");return;}
 if(e.scope.tracking){inspect("Telescope tracking became active");return;}
 if(e.scope.error!=alpaca::Error::None || uint32_t(now-e.scope.sampledAt)>5000){inspect("Telescope status lost or stale");return;}
 if(status_.phase==ArmPhase::Checking){if(uint32_t(now-started_)>=3000 || e.scope.slewing)inspect("Arm preflight expired or telescope moving");return;}
 if(!e.maintenance){inspect("Cover interlock lost");return;}
 if(uint32_t(now-sentAt_)>=60000){inspect(status_.opening?"Lift verification timed out; requires stationary telescope and altitude within 3 degrees of horizon":"Stow verification timed out");return;}
 if(!e.scope.fresh(now) || !e.scope.connected)return; // In-progress sweep is not a contradictory completed sample.
 if(e.scope.sequence==lastSequence_ || int32_t(e.scope.sampledAt-sentAt_)<=0)return;
 lastSequence_=e.scope.sequence;
 bool done=!e.scope.slewing && e.scope.atHome!=status_.opening;
 // Opening must reach reported horizon, not merely leave the home switch.
 if(status_.opening)done=done && e.altitudeValid && isfinite(e.altitude) && fabs(e.altitude)<=3 && uint32_t(now-e.altitudeAt)<=5000 && int32_t(e.altitudeAt-sentAt_)>0;
 if(done){if(++confirmations_>=2){status_.phase=ArmPhase::Complete;status_.locked=false;status_.reason="Arm completion verified";}}
 else confirmations_=0;
}
bool ArmOperation::finish(uint32_t now,const ArmEvidence& e){
 if(status_.phase!=ArmPhase::Unknown || !e.maintenance || !armStationary(now,e,true))return false;
 status_.phase=ArmPhase::Idle;status_.locked=false;status_.reason="Inspection accepted; no movement requested";return true;
}
const char* armPhaseName(ArmPhase p){switch(p){case ArmPhase::Idle:return "idle";case ArmPhase::Checking:return "checking";case ArmPhase::Waiting:return "moving";case ArmPhase::Complete:return "complete";case ArmPhase::Unknown:return "inspect";}return "inspect";}
}
