#pragma once
#include <stddef.h>
#include <stdint.h>
#include <string.h>
namespace cover {
constexpr size_t kReleasePayloadLimit=4096,kReleaseSignatureBytes=64,kReleasePublicKeyBytes=65;
struct ReleasePublicKey {
 const char* id=nullptr;
 uint8_t point[kReleasePublicKeyBytes]={}; // SEC1 uncompressed P-256 point.
 bool revoked=false;
};
enum class ReleaseSignatureResult { Verified,InvalidInput,InvalidTrust,UnknownKey,RevokedKey,BadSignature };
// Platform crypto boundary: SHA-256 + P-256, fixed-width P1363 r||s. No flash,
// persistence, servo access or trust-key provisioning belongs in this function.
bool verifyReleaseP256(const uint8_t* payload,size_t size,const uint8_t* signature,const uint8_t* publicPoint);
inline bool validReleaseKeyId(const char* id,size_t size){
 if(!id || !size || size>48 || id[0]<'a' || id[0]>'z')return false;
 for(size_t i=1;i<size;++i)if(!((id[i]>='a'&&id[i]<='z')||(id[i]>='0'&&id[i]<='9')||id[i]=='-'))return false;
 return true;
}
inline ReleaseSignatureResult verifyReleaseSignature(const uint8_t* payload,size_t size,
 const uint8_t* signature,size_t signatureSize,const char* keyId,size_t keyIdSize,
 const ReleasePublicKey* keys,size_t keyCount){
 if(!payload || !size || size>kReleasePayloadLimit || !signature || signatureSize!=kReleaseSignatureBytes ||
    !validReleaseKeyId(keyId,keyIdSize))return ReleaseSignatureResult::InvalidInput;
 if(keyCount>4 || (keyCount && !keys))return ReleaseSignatureResult::InvalidTrust;
 const ReleasePublicKey* selected=nullptr;
 for(size_t i=0;i<keyCount;++i){
  const size_t n=keys[i].id?strnlen(keys[i].id,49):0;
  if(!validReleaseKeyId(keys[i].id,n))return ReleaseSignatureResult::InvalidTrust;
  for(size_t j=0;j<i;++j)if(!strcmp(keys[i].id,keys[j].id) || !memcmp(keys[i].point,keys[j].point,kReleasePublicKeyBytes))
   return ReleaseSignatureResult::InvalidTrust; // No aliases around key revocation.
  if(n==keyIdSize && !memcmp(keys[i].id,keyId,n))selected=&keys[i];
 }
 if(!selected)return ReleaseSignatureResult::UnknownKey;
 if(selected->revoked)return ReleaseSignatureResult::RevokedKey;
 if(selected->point[0]!=4)return ReleaseSignatureResult::InvalidTrust;
 return verifyReleaseP256(payload,size,signature,selected->point)?ReleaseSignatureResult::Verified:ReleaseSignatureResult::BadSignature;
}
// Signature validity alone never means that a release/profile/settings pair
// is compatible, a maintenance lease is granted, or installation is authorized.
}
