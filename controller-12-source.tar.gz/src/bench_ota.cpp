#ifdef COVER_BENCH_OTA
#include <Arduino.h>
#include <WiFi.h>
#include <Preferences.h>
#include <ESPmDNS.h>
#include <esp_ota_ops.h>
#include <soc/rtc_wdt.h>
#include <mbedtls/sha256.h>
#include <atomic>
#include "bounded_web_server.h"
#include "settings.h"
#include "release_signature.h"
#include "bench_ota_protocol.h"
#include "bench_generated.h"

extern "C" bool verifyRollbackLater(){
 rtc_wdt_protect_off();rtc_wdt_set_stage(RTC_WDT_STAGE0,RTC_WDT_STAGE_ACTION_RESET_RTC);
 rtc_wdt_set_time(RTC_WDT_STAGE0,45000);rtc_wdt_enable();rtc_wdt_protect_on();return true;
}
namespace cover {
extern const uint8_t benchOtaDescriptor[64] __attribute__((section(".rodata_custom_desc"),used,aligned(4)))={
 'T','C','B','E','N','C','H','O','T','A','0','1',0,0,0,0,
 COVER_BENCH_BUILD&255,(COVER_BENCH_BUILD>>8)&255,0,0};
namespace {
BoundedWebServer web;
portMUX_TYPE mux=portMUX_INITIALIZER_UNLOCKED;
QueueHandle_t queue=nullptr;TaskHandle_t workerHandle=nullptr;
enum class Op:uint8_t {Start,Chunk,Finish};
struct Command {Op op=Op::Start;BenchManifest manifest;uint32_t offset=0;uint16_t size=0;uint8_t data[kBenchChunk]={};};
enum class Phase:uint8_t {Idle,Preparing,Receiving,Verified,Committing,Rebooting,Failed,Cancelled};
Phase phase=Phase::Idle;char reason[80]="none";uint32_t consumed=0,total=0;
char bootId[33]={},nonce[33]={},transaction[33]={},updateToken[65]={};
char ackTransaction[33]={};uint32_t ackEnd=0;
bool accepted=false,settingsPreserved=false;
std::atomic<bool> cancelled{false};
OtaRecord journal;bool journalPresent=false;const char* outcome="none";
void randomHex(char* out,size_t bytes){uint8_t data[32];esp_fill_random(data,bytes);otaHex(data,bytes,out);}
const char* phaseName(Phase p){switch(p){case Phase::Idle:return "idle";case Phase::Preparing:return "preparing";case Phase::Receiving:return "receiving";
 case Phase::Verified:return "verified";case Phase::Committing:return "committing";case Phase::Rebooting:return "rebooting";case Phase::Failed:return "failed";default:return "cancelled";}}
void setPhase(Phase p,const char* why="none"){portENTER_CRITICAL(&mux);phase=p;snprintf(reason,sizeof(reason),"%s",why);portEXIT_CRITICAL(&mux);Serial.printf("BENCH phase=%s reason=%s\n",phaseName(p),why);}
bool busy(Phase p){return p==Phase::Preparing || p==Phase::Receiving || p==Phase::Verified || p==Phase::Committing || p==Phase::Rebooting;}
bool chunkResponseReady(){
 Phase p;uint32_t bytes;portENTER_CRITICAL(&mux);p=phase;bytes=consumed;portEXIT_CRITICAL(&mux);
 if(p!=Phase::Receiving || cancelled || strcmp(ackTransaction,transaction) || bytes>ackEnd){
  web.send(409,"text/plain","Chunk was not confirmed; inspect transaction");return true;
 }
 if(bytes!=ackEnd)return false;
 // consumed is published only after the worker's flash write and SHA update.
 web.sendHeader("Cache-Control","no-store");
 web.send(200,"application/json",String("{\"transaction\":\"")+ackTransaction+"\",\"received\":"+String(bytes)+"}");return true;
}
bool settingsDigest(uint8_t hash[32]){
 Preferences p;if(!p.begin("cover-app",true))return false;
 uint8_t bytes[382];size_t size=p.getBytesLength("v1");bool ok=size>0 && size<=sizeof(bytes) && p.getBytes("v1",bytes,size)==size;p.end();
 return ok && mbedtls_sha256_ret(bytes,size,hash,0)==0;
}
bool saveJournal(OtaRecord& value){uint8_t bytes[kOtaRecordBytes],check[kOtaRecordBytes];encodeOtaRecord(value,bytes);Preferences p;
 if(!p.begin("bench-ota",false))return false;
 bool ok=p.putBytes("handoff",bytes,sizeof(bytes))==sizeof(bytes) && p.getBytesLength("handoff")==sizeof(bytes) && p.getBytes("handoff",check,sizeof(check))==sizeof(check) && !memcmp(bytes,check,sizeof(bytes));p.end();
 if(ok){portENTER_CRITICAL(&mux);journal=value;journalPresent=true;portEXIT_CRITICAL(&mux);}return ok;
}
bool layoutValid(){
 struct Part {uint8_t type,subtype;uint32_t address,size;const char* label;};
 const Part expected[]={{1,2,0x9000,0x5000,"nvs"},{1,0,0xe000,0x2000,"otadata"},{0,0x10,0x10000,0x140000,"app0"},{0,0x11,0x150000,0x140000,"app1"},{1,0x82,0x290000,0x160000,"spiffs"},{1,3,0x3f0000,0x10000,"coredump"}};
 for(const auto& e:expected){const auto* p=esp_partition_find_first(esp_partition_type_t(e.type),esp_partition_subtype_t(e.subtype),e.label);if(!p || p->address!=e.address || p->size!=e.size || p->encrypted)return false;}
 unsigned count=0;auto it=esp_partition_find(ESP_PARTITION_TYPE_ANY,ESP_PARTITION_SUBTYPE_ANY,nullptr);while(it){++count;it=esp_partition_next(it);}return count==6 && ESP.getFlashChipSize()==4194304;
}
bool authorized(){
 const String host=WiFi.localIP().toString();
 if(!accepted || WiFi.getMode()!=WIFI_STA || WiFi.status()!=WL_CONNECTED || web.hostHeader()!=host ||
   web.header("Origin")!="http://"+host || web.header("X-Bench-Nonce")!=nonce){web.send(403,"text/plain","Use this controller's home-LAN page and refresh");return false;}
 const String key=web.header("X-Bench-Key");
 if(key.length()!=64 || !otaEqual(reinterpret_cast<const uint8_t*>(key.c_str()),reinterpret_cast<const uint8_t*>(updateToken),64)){web.send(403,"text/plain","Refresh this controller page to renew update authorization");return false;}
 return true;
}
void worker(void*){
 esp_ota_handle_t handle=0;bool live=false;BenchManifest manifest;
 const esp_partition_t* target=nullptr;
 uint32_t received=0,lastData=0,started=0;uint8_t prefix[kOtaPrefixBytes];size_t prefixUsed=0;
 mbedtls_sha256_context sha;mbedtls_sha256_init(&sha);
 auto fail=[&](const char* why){if(live)esp_ota_abort(handle);live=false;setPhase(cancelled?Phase::Cancelled:Phase::Failed,why);};
 for(;;){
  Command c;
  if(xQueueReceive(queue,&c,pdMS_TO_TICKS(20))!=pdTRUE){
   Phase p;portENTER_CRITICAL(&mux);p=phase;portEXIT_CRITICAL(&mux);
   if(p==Phase::Receiving && (cancelled || WiFi.status()!=WL_CONNECTED || uint32_t(millis()-lastData)>10000 || uint32_t(millis()-started)>600000))fail("cancelled_network_or_timeout");
   continue;
  }
  if(c.op==Op::Start){
   manifest=c.manifest;received=0;prefixUsed=0;started=lastData=millis();target=esp_ota_get_next_update_partition(nullptr);
   const auto* running=esp_ota_get_running_partition();
   if(cancelled || !target || !running || target==running || target->size!=kOtaSlotBytes || !layoutValid() || !benchSourceAllowed(manifest,COVER_BENCH_BUILD,esp_ota_get_app_description()->app_elf_sha256)){fail("source_or_partition");continue;}
   if(mbedtls_sha256_starts_ret(&sha,0)){fail("digest_init");continue;}
   setPhase(Phase::Receiving);continue;
  }
  Phase p;portENTER_CRITICAL(&mux);p=phase;portEXIT_CRITICAL(&mux);
  if(p!=Phase::Receiving || cancelled || WiFi.status()!=WL_CONNECTED || uint32_t(millis()-lastData)>10000 || uint32_t(millis()-started)>600000){fail("transaction_no_longer_receiving");continue;}
  if(c.op==Op::Chunk){
   if(c.offset!=received || !c.size || c.size>manifest.size-received){fail("chunk_offset_or_length");continue;}
   size_t offset=0;
   if(!live){const size_t take=min(size_t(c.size),sizeof(prefix)-prefixUsed);memcpy(prefix+prefixUsed,c.data,take);prefixUsed+=take;offset=take;
    if(prefixUsed==sizeof(prefix)){
     if(!benchPrefixValid(prefix,sizeof(prefix),manifest) || cancelled){fail("wrong_bench_image_prefix");continue;}
     if(esp_ota_begin(target,OTA_WITH_SEQUENTIAL_WRITES,&handle)!=ESP_OK){fail("flash_begin");continue;}live=true;
     if(esp_ota_write(handle,prefix,sizeof(prefix))!=ESP_OK || mbedtls_sha256_update_ret(&sha,prefix,sizeof(prefix))){fail("prefix_write");continue;}
    }
   }
   if(offset<c.size && (!live || esp_ota_write(handle,c.data+offset,c.size-offset)!=ESP_OK || mbedtls_sha256_update_ret(&sha,c.data+offset,c.size-offset))){fail("flash_write");continue;}
   received+=c.size;lastData=millis();portENTER_CRITICAL(&mux);consumed=received;portEXIT_CRITICAL(&mux);continue;
  }
  if(c.op==Op::Finish){
   uint8_t hash[32];
   if(!live || received!=manifest.size || mbedtls_sha256_finish_ret(&sha,hash) || !otaEqual(hash,manifest.sha,32)){fail("incomplete_or_hash_mismatch");continue;}
   const esp_err_t ended=esp_ota_end(handle);live=false;if(ended!=ESP_OK){fail("image_validation");continue;}
   setPhase(Phase::Verified);
   uint8_t settings[32];Preferences prefs;
   if(cancelled || !settingsDigest(settings) || !prefs.begin("bench-ota",false)){fail("settings_checkpoint");continue;}
   const bool stored=prefs.putBytes("settings",settings,32)==32;prefs.end();if(!stored){fail("settings_checkpoint");continue;}
   OtaRecord record;record.size=manifest.size;record.sourceSlot=esp_ota_get_running_partition()->address;record.targetSlot=target->address;
   otaUnhex(transaction,32,record.transaction);memcpy(record.source,manifest.source,32);memcpy(record.target,manifest.target,32);memcpy(record.sha256,manifest.sha,32);
   if(!saveJournal(record) || cancelled){fail("intent_checkpoint_or_cancelled");continue;}
   portENTER_CRITICAL(&mux);const bool stop=cancelled.load();if(!stop)phase=Phase::Committing;portEXIT_CRITICAL(&mux);
   if(stop){fail("cancelled_before_selection");continue;}
   if(esp_ota_set_boot_partition(target)!=ESP_OK){fail("boot_selection");continue;}
   record.activationConfirmed=true;
   if(!saveJournal(record)){setPhase(Phase::Rebooting,"activation_checkpoint_unconfirmed");}
   else setPhase(Phase::Rebooting);
   Serial.printf("BENCH activated target_slot=0x%lx bytes=%lu\n",(unsigned long)target->address,(unsigned long)received);
   vTaskDelay(pdMS_TO_TICKS(1000));ESP.restart();
  }
 }
}
String statusJson(){
 Phase p;uint32_t bytes,size;char why[80],tx[33];OtaRecord record;bool present;
 portENTER_CRITICAL(&mux);p=phase;bytes=consumed;size=total;memcpy(why,reason,sizeof(why));memcpy(tx,transaction,sizeof(tx));record=journal;present=journalPresent;portEXIT_CRITICAL(&mux);
 char elf[65],target[65],journalTx[33];otaHex(esp_ota_get_app_description()->app_elf_sha256,32,elf);otaHex(record.target,32,target);otaHex(record.transaction,16,journalTx);
 const auto* running=esp_ota_get_running_partition();
 String s="{\"profile\":\"bench-ota-v1\",\"version\":\"" COVER_BENCH_VERSION "\",\"build\":"+String(COVER_BENCH_BUILD)+",\"elf\":\""+elf+"\",\"boot\":\""+bootId+"\",\"nonce\":\""+nonce+"\",\"accepted\":"+(accepted?"true":"false");
 s+=",\"chunk_bytes\":"+String(kBenchChunk)+",\"chunk_ack\":\"consumed-offset-v1\",\"servo_operations\":false,\"phase\":\""+String(phaseName(p))+"\",\"reason\":\""+why+"\",\"received\":"+String(bytes)+",\"total\":"+String(size)+",\"transaction\":\""+tx+"\",\"outcome\":\""+outcome+"\",\"journal_transaction\":\""+journalTx+"\",\"journal_target\":\""+target+"\",\"journal_present\":"+(present?"true":"false");
 s+=",\"settings_preserved\":"+String(settingsPreserved?"true":"false")+",\"slot\":"+String(running?running->address:0)+",\"heap\":"+String(ESP.getFreeHeap())+",\"min_heap\":"+String(ESP.getMinFreeHeap())+",\"worker_stack_high_water_raw\":"+String(workerHandle?uxTaskGetStackHighWaterMark(workerHandle):0)+"}";return s;
}
}
void beginBenchOta(){
 // This environment links no ServoController, UART1 initialization or telescope worker.
 Serial.println("TELESCOPE COVER OTA BENCH — NO SERVO OPERATIONS");
 const volatile uint8_t* marker=benchOtaDescriptor;if(marker[0]!='T' || !layoutValid()){Serial.println("BENCH startup failed: descriptor/layout");return;}
 randomHex(bootId,16);randomHex(nonce,16);
 Preferences p;if(!p.begin("bench-ota",false)){Serial.println("BENCH startup failed: NVS");return;}
 // The owner selected automatic trusted-LAN authorization. Issue a fresh
 // boot-scoped token; keep any legacy NVS key untouched for old-image rollback.
 randomHex(updateToken,32);
 if(p.isKey("handoff")){uint8_t bytes[kOtaRecordBytes];if(p.getBytesLength("handoff")!=sizeof(bytes) || p.getBytes("handoff",bytes,sizeof(bytes))!=sizeof(bytes) || !decodeOtaRecord(bytes,sizeof(bytes),journal)){p.end();Serial.println("BENCH invalid journal");return;}journalPresent=true;}
 uint8_t expectedSettings[32],actualSettings[32];bool hasSettings=p.getBytesLength("settings")==32 && p.getBytes("settings",expectedSettings,32)==32;p.end();
 ApplicationSettings settings;if(loadApplicationSettings(settings)!=SettingsLoad::Loaded || !settings.wifiConfigured){Serial.println("BENCH needs existing configured Wi-Fi; USB recovery available");return;}
 WiFi.mode(WIFI_STA);WiFi.setSleep(false);WiFi.begin(settings.ssid,settings.password);
 const uint32_t at=millis();while(WiFi.status()!=WL_CONNECTED && uint32_t(millis()-at)<20000)delay(50);
 if(WiFi.status()!=WL_CONNECTED){Serial.println("BENCH startup failed: home Wi-Fi unavailable");return;}
 settingsPreserved=hasSettings && settingsDigest(actualSettings) && otaEqual(expectedSettings,actualSettings,32);
 queue=xQueueCreate(1,sizeof(Command));if(!queue || xTaskCreatePinnedToCore(worker,"bench-ota",8192,nullptr,1,&workerHandle,0)!=pdPASS){Serial.println("BENCH worker allocation failed");return;}
 const char* headers[]={"Origin","X-Bench-Key","X-Bench-Nonce","X-Bench-Session"};web.collectHeaders(headers,4);
 web.on("/",HTTP_GET,[]{web.sendHeader("Cache-Control","no-store");web.sendHeader("Content-Encoding","gzip");web.sendHeader("X-Content-Type-Options","nosniff");web.sendHeader("X-Frame-Options","DENY");web.send_P(200,"text/html",reinterpret_cast<const char*>(benchHtml),sizeof(benchHtml));});
 web.on("/app.js",HTTP_GET,[]{web.sendHeader("Cache-Control","no-store");web.sendHeader("Content-Encoding","gzip");web.send_P(200,"application/javascript",reinterpret_cast<const char*>(benchJs),sizeof(benchJs));});
 web.on("/api/bench/status",HTTP_GET,[]{web.sendHeader("Cache-Control","no-store");web.send(200,"application/json",statusJson());});
 // Custom same-origin request header prevents a cross-site simple GET from
 // collecting authorization; no CORS/OPTIONS permission is granted. This is
 // intentionally automatic LAN access, not independent user authentication.
 web.on("/api/bench/session",HTTP_GET,[]{
  web.sendHeader("Cache-Control","no-store");web.sendHeader("X-Content-Type-Options","nosniff");
  const String host=WiFi.localIP().toString(),origin=web.header("Origin");
  if(!accepted || WiFi.getMode()!=WIFI_STA || WiFi.status()!=WL_CONNECTED || web.hostHeader()!=host ||
    (origin.length() && origin!="http://"+host) || web.header("X-Bench-Session")!="1"){
   web.send(403,"text/plain","Use the controller's own home-LAN page");return;
  }
  web.send(200,"application/json",String("{\"boot\":\"")+bootId+"\",\"nonce\":\""+nonce+"\",\"update_token\":\""+updateToken+"\"}");
 });
 web.on("/api/bench/start",HTTP_POST,[]{
  if(!authorized())return;
  if(web.arg("confirm")!="install"){web.send(400,"text/plain","Explicit install confirmation required");return;}
  Phase state;portENTER_CRITICAL(&mux);state=phase;portEXIT_CRITICAL(&mux);if(busy(state)){web.send(409,"text/plain","Update already active");return;}
  if(ESP.getFreeHeap()<64000 || ESP.getMaxAllocHeap()<32000){web.send(409,"text/plain","Insufficient bench memory");return;}
  const String text=web.arg("manifest"),signature=web.arg("signature");uint8_t sig[64];Command c;c.op=Op::Start;
  if(!parseBenchManifest(text.c_str(),text.length(),c.manifest) || !benchSourceAllowed(c.manifest,COVER_BENCH_BUILD,esp_ota_get_app_description()->app_elf_sha256) || signature.length()!=128 || !otaUnhex(signature.c_str(),128,sig) ||
   !verifyReleaseP256(reinterpret_cast<const uint8_t*>(text.c_str()),text.length(),sig,benchPublicPoint)){web.send(400,"text/plain","Signed bench manifest invalid or source mismatch");return;}
  randomHex(transaction,16);cancelled=false;portENTER_CRITICAL(&mux);consumed=0;total=c.manifest.size;portEXIT_CRITICAL(&mux);setPhase(Phase::Preparing);
  if(xQueueSend(queue,&c,0)!=pdTRUE){setPhase(Phase::Failed,"queue_busy");web.send(409,"text/plain","Worker busy");return;}
  web.send(202,"text/plain",transaction);
 });
 web.on("/api/bench/chunk",HTTP_POST,[]{
  if(!authorized())return;
  Phase state;uint32_t offset;portENTER_CRITICAL(&mux);state=phase;offset=consumed;portEXIT_CRITICAL(&mux);
  const String tx=web.arg("transaction"),number=web.arg("offset"),data=web.arg("data");char canonical[16];snprintf(canonical,sizeof(canonical),"%lu",(unsigned long)offset);
  Command c;c.op=Op::Chunk;c.offset=offset;
  if(state!=Phase::Receiving || tx!=transaction || number!=canonical || !data.length() || data.length()>2*kBenchChunk || data.length()%2 || !otaUnhex(data.c_str(),data.length(),c.data)){web.send(409,"text/plain","Wrong transaction, offset or chunk");return;}
  c.size=data.length()/2;if(xQueueSend(queue,&c,0)!=pdTRUE){web.send(409,"text/plain","Worker backpressure");return;}
  memcpy(ackTransaction,transaction,sizeof(ackTransaction));ackEnd=offset+c.size;
  web.deferResponse(chunkResponseReady);
 });
 web.on("/api/bench/finish",HTTP_POST,[]{if(!authorized())return;
  Phase state;uint32_t bytes,size;portENTER_CRITICAL(&mux);state=phase;bytes=consumed;size=total;portEXIT_CRITICAL(&mux);
  if(state!=Phase::Receiving || web.arg("transaction")!=transaction || bytes!=size){web.send(409,"text/plain","Incomplete transaction");return;}
  Command c;c.op=Op::Finish;if(xQueueSend(queue,&c,0)!=pdTRUE){web.send(409,"text/plain","Worker busy");return;}web.send(202,"text/plain","verifying");
 });
 web.on("/api/bench/cancel",HTTP_POST,[]{if(!authorized())return;
  const String requested=web.arg("transaction");
  portENTER_CRITICAL(&mux);const bool allowed=phase!=Phase::Committing && phase!=Phase::Rebooting && requested==transaction;if(allowed)cancelled=true;portEXIT_CRITICAL(&mux);
  web.send(allowed?202:409,"text/plain",allowed?"cancelling":"Commit already started or wrong transaction");
 });
 web.begin();if(!web.listening()){Serial.println("BENCH startup failed: web listener");return;}
 esp_ota_img_states_t imageState=ESP_OTA_IMG_UNDEFINED;const auto* running=esp_ota_get_running_partition();esp_ota_get_state_partition(running,&imageState);
 if(imageState==ESP_OTA_IMG_PENDING_VERIFY && (!journalPresent || !settingsPreserved || !otaEqual(journal.target,esp_ota_get_app_description()->app_elf_sha256,32) || running->address!=journal.targetSlot)){Serial.println("BENCH pending startup rejected");esp_ota_mark_app_invalid_rollback_and_reboot();return;}
 if(imageState==ESP_OTA_IMG_PENDING_VERIFY && esp_ota_mark_app_valid_cancel_rollback()!=ESP_OK){Serial.println("BENCH accept failed");return;}
 if(journalPresent){
  esp_ota_img_states_t targetState=ESP_OTA_IMG_UNDEFINED;const auto* target=esp_partition_find_first(ESP_PARTITION_TYPE_APP,running->address==journal.targetSlot?running->subtype:esp_partition_subtype_t(journal.targetSlot==0x10000?0x10:0x11),nullptr);
  if(target)esp_ota_get_state_partition(target,&targetState);
  const auto result=reconcileOtaRecord(journal,running->address,esp_ota_get_app_description()->app_elf_sha256,targetState==ESP_OTA_IMG_INVALID,true);
  journal.outcome=result;if(result==OtaOutcome::Complete){outcome="complete";if(!saveJournal(journal)){Serial.println("BENCH completion persistence failed");return;}}
  else if(result==OtaOutcome::RolledBack)outcome="rolled_back";else outcome="unconfirmed";
 }
 accepted=true;rtc_wdt_protect_off();rtc_wdt_disable();rtc_wdt_protect_on();MDNS.begin("cover-bench");
 Serial.printf("BENCH accepted version=%s build=%u ip=%s slot=0x%lx outcome=%s settings_preserved=%d\n",COVER_BENCH_VERSION,unsigned(COVER_BENCH_BUILD),WiFi.localIP().toString().c_str(),(unsigned long)running->address,outcome,settingsPreserved);
}
void pollBenchOta(){web.handleClient();}
}
#endif
