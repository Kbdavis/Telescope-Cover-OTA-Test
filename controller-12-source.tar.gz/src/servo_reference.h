#pragma once
#include <stdint.h>
namespace cover {
constexpr uint16_t kFactoryReferenceOffset=85;
constexpr uint16_t kFixedReferenceOffset=1328;
constexpr int kFixedReferenceShift=1243;
#ifdef COVER_FIXED_REFERENCE
constexpr uint16_t kApplicationReferenceOffset=kFixedReferenceOffset;
#else
constexpr uint16_t kApplicationReferenceOffset=kFactoryReferenceOffset;
#endif
}
