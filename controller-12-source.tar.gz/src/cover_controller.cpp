#include "cover_controller.h"
#include <stdlib.h>
#include <stdio.h>
#ifndef COVER_SETTLE_SAMPLES
#define COVER_SETTLE_SAMPLES 5
#endif
static_assert(COVER_SETTLE_SAMPLES >= 5 && COVER_SETTLE_SAMPLES <= 100, "Invalid settling sample count");
namespace cover {
const char* stateName(State state) {
  switch (state) {
    case State::Unknown: return "UNKNOWN";
    case State::Closed: return "CLOSED";
    case State::Opening: return "OPENING";
    case State::Open: return "OPEN";
    case State::Closing: return "CLOSING";
    case State::Stopped: return "STOPPED";
    case State::Fault: return "FAULT";
    case State::Manual: return "MANUAL";
    case State::Holding: return "HOLDING";
    case State::Retained: return "RETAINED";
    case State::TorqueTest: return "TORQUE_TEST";
  }
  return "UNKNOWN";
}
bool CoverController::configure(const MotionSettings& s) {
  if (moving() || holding() || state_ == State::Fault || (s.hasTravelArc && (!s.arc.valid() || s.arc.minimumRaw!=s.minimum || s.arc.maximumRaw!=s.maximum)) || s.minimum >= s.maximum || s.maximum > 4095 ||
      s.speed == 0 || s.speed > 1600 || s.acceleration == 0 || s.acceleration > 100 ||
      s.timeoutMs < 500 || s.timeoutMs > 30000) return false;
  motionArcActive_=false;settings_ = s; configured_ = true; state_ = State::Unknown; return true;
}
bool CoverController::initializeStationary(const MotionSettings& s,int closed,int open,bool allowPowered,bool allowOutsideRange) {
  if(moving() || holding() || (s.hasTravelArc && (!s.arc.valid() || s.arc.minimumRaw!=s.minimum || s.arc.maximumRaw!=s.maximum)) || s.minimum>=s.maximum || s.maximum>4095 ||
     s.speed<1 || s.speed>1600 || s.acceleration<1 || s.acceleration>100 ||
     s.timeoutMs<500 || s.timeoutMs>30000)return false;
  const bool endpoints=closed!=-1 || open!=-1;
  if(s.hasTravelArc && (!endpoints || closed!=s.arc.closedRaw || open!=s.arc.rawTarget(s.arc.length)))return false;
  if(endpoints && (!(s.hasTravelArc?s.arc.valid():supportedDirectPath(closed,open)) || closed<s.minimum || closed>s.maximum || open<s.minimum || open>s.maximum || abs(open-closed)<=2*kEndpointTolerance))return false;
  bool torque=true;uint16_t a=0,b=0;
  if(!servo_.validateConfiguration() || !servo_.readTorque(torque) || (torque && !allowPowered) ||
     !servo_.readPosition(a) || !servo_.readPosition(b) || abs(encoderDelta(a,b))>3 ||
     a>4095 || b>4095)return false;
  const bool inside=a>=s.minimum && a<=s.maximum && b>=s.minimum && b<=s.maximum &&
    (!s.hasTravelArc || (s.arc.contains(a) && s.arc.contains(b)));
  if(!inside && !allowOutsideRange)return false;
  manualOverride_=false;motionArcActive_=false;settings_=s;configured_=true;state_=torque?State::Retained:State::Unknown;fault_="";
  if(endpoints && inside){
    const auto difference=[&](int raw,int endpoint){return s.hasTravelArc?
      abs(s.arc.coordinate(raw)-s.arc.coordinate(endpoint)):abs(raw-endpoint);};
    if(difference(a,closed)<=kEndpointTolerance && difference(b,closed)<=kEndpointTolerance)state_=State::Closed;
    else if(difference(a,open)<=kEndpointTolerance && difference(b,open)<=kEndpointTolerance)state_=State::Open;
  }
  position_=b;positionKnown_=true;torqueOffConfirmed_=!torque;return true;
}
bool CoverController::prepareReboot(bool retainTorque) {
 if(moving() || torqueTesting() || state_==State::Fault || !configured_)return false;
 if(!retainTorque){stop();return torqueOffConfirmed_ && state_!=State::Fault;}
 uint16_t a=0,b=0;
 if(!servo_.validateConfiguration() || !servo_.readPosition(a) || !servo_.readPosition(b) ||
    abs(encoderDelta(a,b))>3 || !inRange(a) || !inRange(b)){fail("Reboot hold validation failed");return false;}
 bool enabled=false;
 if(!servo_.readTorque(enabled) || (!enabled && !servo_.enableTorque()) || !servo_.readTorque(enabled) || !enabled){fail("Reboot holding torque unconfirmed");return false;}
 position_=b;torqueOffConfirmed_=false;state_=State::Retained;return true;
}
bool CoverController::applyStationarySettings(const MotionSettings& settings,int closed,int open) {
 const bool faulted=state_==State::Fault;const char* reason=fault_;
 if(!initializeStationary(settings,closed,open))return false;
 // An inspected range correction does not clear an unexplained motion fault.
 if(faulted){state_=State::Fault;fault_=reason;}
 return true;
}
bool CoverController::setMotionProfile(uint16_t speed,uint8_t acceleration,uint32_t timeoutMs) {
 if(!configured_ || moving() || holding() || speed<1 || speed>1600 ||
    acceleration<1 || acceleration>100 || timeoutMs<500 || timeoutMs>30000)return false;
 settings_.speed=speed;settings_.acceleration=acceleration;settings_.timeoutMs=timeoutMs;return true;
}
bool CoverController::startTorqueTest() {
  if(moving() || holding())return false;
  bool torque=true;uint16_t a=0,b=0;
  if(!servo_.validateConfiguration() || !servo_.readTorque(torque) || torque ||
     !servo_.readPosition(a) || !servo_.readPosition(b) || a>4095 || b>4095 || abs(encoderDelta(a,b))>3)return false;
  traceForAttempt_=false;position_=b;positionKnown_=true;target_=b;started_=millis();lastPoll_=0;
  readFailures_=wrongSamples_=limitSamples_=settled_=0;
  // Driver stages the current position, not the previous movement target.
  if(!servo_.enableTorque()){fail("Torque test enable failed");return false;}
  state_=State::TorqueTest;torqueOffConfirmed_=false;return true;
}
bool CoverController::release() {
  auto result = servo_.releaseTorque();
  bool enabled = true;
  auto read = servo_.readTorque(enabled);
  torqueOffConfirmed_ = static_cast<bool>(read) && !enabled;
  // Keep uncertain write acknowledgements visible even if readback says OFF.
  return static_cast<bool>(result) && torqueOffConfirmed_;
}
void CoverController::captureFault(const char* reason) {
  // Preserve the initiating evidence BEFORE best-effort release can replace
  // the last transport failure, torque observation or position read.
  if(state_!=State::Fault){
   ++faultEvidence_.sequence;faultEvidence_.at=millis();faultEvidence_.stateBefore=state_;
   faultEvidence_.traceAvailable=traceForAttempt_;
   faultEvidence_.elapsedMs=traceForAttempt_?uint32_t(millis()-trace_.startedAt):0;
   faultEvidence_.acceptedPosition=position_;faultEvidence_.positionKnown=positionKnown_;
   faultEvidence_.consecutiveReadFailures=readFailures_;faultEvidence_.wrongSamples=wrongSamples_;faultEvidence_.limitSamples=limitSamples_;
   snprintf(faultEvidence_.reason,sizeof(faultEvidence_.reason),"%s",reason);
   servo_.copyDiagnostics(faultEvidence_.servo);
  }
}
void CoverController::fail(const char* reason) {
  reason=servoFaultReason(servo_.lastResult(),reason);
  captureFault(reason);
  state_ = State::Fault; fault_ = reason;
  release(); // Best effort; never claim torque is off without valid readback.
  faultEvidence_.releaseConfirmed=torqueOffConfirmed_;
}
void CoverController::stop() {
  const bool wasFault = state_ == State::Fault;
  if (!release()) {
   captureFault("Torque release unconfirmed");faultEvidence_.releaseConfirmed=torqueOffConfirmed_;
   state_=State::Fault;fault_="Torque release unconfirmed";return;
  }
  if (!wasFault) state_ = State::Stopped;
}
bool CoverController::recover(bool allowOutsideRange) {
  if (state_ != State::Fault) return false;
  if (!release() || !servo_.validateConfiguration()) return false;
  uint16_t p, confirm;
  if (!configured_ || !servo_.readPosition(p) || !servo_.readPosition(confirm) ||
      p>4095 || confirm>4095 || abs(encoderDelta(p,confirm)) > 3 ||
      (!allowOutsideRange && (!inRange(p) || !inRange(confirm)))) return false;
  manualOverride_=false;motionArcActive_=false;position_ = confirm;positionKnown_=true; state_ = State::Unknown; fault_ = ""; return true;
}
bool CoverController::jog(int16_t counts, bool pathClear, bool retainTorque) {
  if(counts == 0 || abs(int(counts))>servo_.maximumJogStep()) return false;
  return beginMove(counts, false, State::Manual, pathClear, retainTorque);
}
bool CoverController::manualJog(int16_t counts,bool pathClear,bool retainTorque) {
  if(counts==0 || abs(int(counts))>servo_.maximumJogStep())return false;
  return beginMove(counts,false,State::Manual,pathClear,retainTorque,true);
}
bool CoverController::moveEndpoint(uint16_t target, bool opening, bool pathClear) {
  if(target > 4095 || (settings_.hasTravelArc && target!=(opening?settings_.arc.rawTarget(settings_.arc.length):settings_.arc.closedRaw))){moveRejection_="Move rejected: target is not the requested saved endpoint";return false;}
  return beginMove(target, true, opening?State::Opening:State::Closing, pathClear);
}
bool CoverController::beginMove(int value, bool absolute, State motion, bool pathClear, bool retainTorque,bool manualOverride) {
  moveRejection_="Move rejected: controller is busy or movement is not permitted";
  if (!configured_ || moving() || state_ == State::Fault || !pathClear) return false;
  if(holding() && (motion!=State::Manual || !retainTorque)) return false;
  traceForAttempt_=false;
  manualOverride_=manualOverride;
  if (!servo_.validateConfiguration()) { fail("Invalid configuration or communication"); return false; }
  uint16_t p, confirm;
  if (!servo_.readPosition(p) || !servo_.readPosition(confirm) || abs(encoderDelta(p,confirm)) > 3) {
    fail("Unstable starting position"); return false;
  }
  motionArcActive_=false;
  endpointRecovery_=false;recoveryEntered_=false;
  const int goal = absolute ? value : manualOverride_ && !servo_.rolloverSupported() ? int(confirm)+value : wrapPosition(int(confirm) + value);
  if(absolute && settings_.hasTravelArc && (!inRange(p) || !inRange(confirm))){
   if(!settings_.arc.endpointStartAllowed(p) || !settings_.arc.endpointStartAllowed(confirm)){moveRejection_="Move rejected: position exceeds the 25-count endpoint recovery allowance";return false;}
   endpointRecovery_=true;
   const int a=coordinate(p),b=coordinate(confirm);
   recoveryStart_=a<0 || b<0?(a<b?a:b):(a>b?a:b);
  }
  if (!motionInRange(p) || !motionInRange(confirm) || !motionInRange(goal)){moveRejection_="Move rejected: requested path is outside allowed travel";return false;}
  const bool crossing=!supportedDirectPath(confirm,goal);
  if(crossing && !servo_.rolloverSupported()){moveRejection_="Move rejected: encoder crossing is not configured";return false;}
  if(!absolute && (manualOverride_ || !settings_.hasTravelArc) && crossing){
    motionArc_=TravelArc{};motionArc_.closedRaw=confirm;motionArc_.direction=value>0?1:-1;
    motionArc_.length=abs(value);motionArc_.minimumRaw=0;motionArc_.maximumRaw=4095;motionArc_.circular=true;
    motionArcActive_=true;
  }
  if(abs(coordinate(goal)-coordinate(confirm))>=2048 ||
     (!manualOverride_ && !absolute && settings_.hasTravelArc && coordinate(goal)-coordinate(confirm)!=settings_.arc.direction*value))return false;
  const TravelArc& commandArc=motionArcActive_?motionArc_:settings_.arc;
  // Reject incompatible timing before any torque write. Saving a profile or
  // correcting it while faulted never clears a fault or starts movement.
  if(absolute && settings_.hasTravelArc && settings_.timeoutMs<travelTiming(settings_.arc.length,settings_.speed,settings_.acceleration).recommendedMs){moveRejection_="Move rejected: timeout is too short for the saved travel and speed";return false;}
  started_ = millis();
  // Reset in place: constructing a whole MotionTrace temporary here reserves
  // another history buffer while the worker's own history/status are live.
  ++trace_.operation;
  for(auto& sample:trace_.samples)sample=MotionSample{};
  trace_.validReads=trace_.failedReads=trace_.lastValidMs=trace_.rejectedReads=0;
  trace_.lastPosition=0;trace_.count=trace_.next=trace_.settled=0;
  trace_.target=goal;trace_.startPosition=confirm;trace_.startedAt=started_;
  readFailures_=wrongSamples_=limitSamples_=settled_=0;
  trace_.speed=settings_.speed;trace_.acceleration=settings_.acceleration;trace_.timeoutMs=settings_.timeoutMs;
  // Allow normal encoder settling on fine steps without accepting the start
  // position as completion. Larger jogs retain the commissioned 20-count cap.
  const int scaledJogTolerance=abs(value)/5;
  jogTolerance_ = absolute ? kEndpointTolerance :
    (scaledJogTolerance<kManualJogTolerance ? scaledJogTolerance : kManualJogTolerance);
  trace_.tolerance=jogTolerance_;traceForAttempt_=true;
  if(holding() || state_==State::Retained || ((state_==State::Open || state_==State::Closed) && !torqueOffConfirmed_)) {
    // Preserve support between supervised jogs and completed endpoint moves.
    bool enabled=false;
    if(!servo_.readTorque(enabled) || !enabled){fail("Holding torque unconfirmed");return false;}
  } else {
    if (!release()) { fail("Preflight torque release failed"); return false; }
    if (!servo_.enableTorque()) { fail("Torque enable failed"); return false; }
  }
  torqueOffConfirmed_ = false;
  if (millis() - started_ >= settings_.timeoutMs) { fail("Preflight timeout"); return false; }
  if (!(absolute && settings_.hasTravelArc?servo_.moveCalibratedEndpoint(goal,settings_.speed,settings_.acceleration,settings_.arc):
      crossing?servo_.moveAcrossBoundary(goal,settings_.speed,settings_.acceleration,commandArc):
      servo_.moveTo(goal, settings_.speed, settings_.acceleration, manualOverride_?0:settings_.minimum, manualOverride_?4095:settings_.maximum))) {
    fail("Move command failed"); return false;
  }
  position_ = confirm;positionKnown_=true; target_ = goal; bestDistance_ = distance(target_,position_);
  previousDistance_=bestDistance_;previousDistanceValid_=true;
  lastPoll_ = millis(); readFailures_ = wrongSamples_ = limitSamples_ = settled_ = 0;
  recordPosition(true,confirm);
  holdAfterMove_=retainTorque;state_ = motion; return true;
}
void CoverController::recordPosition(bool valid,uint16_t p,PositionDisposition disposition) {
 const uint32_t elapsed=millis()-started_;
 if(valid){++trace_.validReads;trace_.lastPosition=p;trace_.lastValidMs=elapsed;}
 else ++trace_.failedReads;
 if(!valid)disposition=PositionDisposition::ReadFailed;
 if(valid && disposition!=PositionDisposition::Accepted)++trace_.rejectedReads;
 // Retain at most ten samples per second; counters include every control read.
 if(trace_.count && elapsed-trace_.samples[(trace_.next+MotionTrace::capacity-1)%MotionTrace::capacity].elapsedMs<100)return;
 auto& sample=trace_.samples[trace_.next];sample.elapsedMs=elapsed;sample.position=p;sample.valid=valid;sample.disposition=disposition;
 trace_.next=(trace_.next+1)%MotionTrace::capacity;
 if(trace_.count<MotionTrace::capacity)++trace_.count;
}
void CoverController::tick(bool pathClear, bool telescopeClear) {
  if(torqueTesting()){
    if(millis()-started_>=750){fail("Torque test finished; inspect before recovery");return;}
    if(millis()-lastPoll_<100)return;
    lastPoll_=millis();uint16_t p;
    if(!servo_.readPosition(p)){fail("Torque test position read failed");return;}
    if(abs(encoderDelta(target_,p))>20){fail("Torque test position changed");return;}
    position_=p;return;
  }

  if (!moving() && !holding()) return;
  if (!telescopeClear) { fail("Telescope stow confirmation lost"); return; }
  if (!pathClear) { fail("Safety interlock"); return; }
  const uint32_t now = millis();
  if (!holding() && now - started_ >= settings_.timeoutMs) { fail("Movement timeout"); return; }
  if (now - lastPoll_ < 50) return;
  lastPoll_ = now;
  uint16_t p;
  const auto positionResult=servo_.readPosition(p);
  if (!positionResult) {
    previousDistanceValid_=false;
    recordPosition(false,0);trace_.settled=0;
    settled_ = wrongSamples_ = limitSamples_ = 0;
    if (++readFailures_ >= 3 || (positionResult.error==ServoError::DeviceError && (positionResult.deviceStatus & 0x08)))
      fail(servoFaultReason(positionResult,"Repeated position read failure"));
    return;
  }
  if(holding()) {
    bool enabled=false;
    if(!servo_.readTorque(enabled)) {
      recordPosition(true,p);
      if(++readFailures_>=3)fail("Holding torque read failure");
      return;
    }
    if(!enabled){recordPosition(true,p);fail("Holding torque lost");return;}
  }
  readFailures_ = 0;
  if (!holding() && millis() - started_ >= settings_.timeoutMs) {recordPosition(true,p); fail("Movement timeout"); return; }
  if (!motionInRange(p)) {
    previousDistanceValid_=false;
    recordPosition(true,p,PositionDisposition::OutsideLimits);
    settled_ = wrongSamples_ = 0;
    if (++limitSamples_ >= 3) fail("Repeated position outside travel limits");
    return;
  }
  limitSamples_ = 0;
  if(endpointRecovery_ && coordinate(p)>=0 && coordinate(p)<=int(settings_.arc.length))recoveryEntered_=true;
  if(abs(coordinate(position_)-coordinate(p))>=2048 || (motionArcActive_ && !motionArc_.contains(p))) {
    previousDistanceValid_=false;
    recordPosition(true,p,PositionDisposition::Discontinuity);
    settled_=0;
    if(repeatedWrongSample(PositionDisposition::Discontinuity))fail("Unvalidated encoder boundary or position jump");
    return;
  }
  const int remaining = distance(target_,p);
  if(holding()) {
    recordPosition(true,p,remaining>kManualJogTolerance?PositionDisposition::HoldingDrift:PositionDisposition::Accepted);
    if(remaining>kManualJogTolerance){if(repeatedWrongSample(PositionDisposition::HoldingDrift))fail("Holding position drift");}
    else {wrongSamples_=0;position_=p;}
    return;
  }
  const uint16_t tolerance = state_ == State::Manual ? jogTolerance_ : kEndpointTolerance;
  // Accept normal settling inside the target band even after a closer sample.
  // A single outlier outside that band never becomes the fault baseline.
  if (remaining > tolerance && remaining > bestDistance_ + 6) {
    // Passing the goal in the requested direction is overshoot, not reversed
    // motion. Both remain guarded; in-band settling is allowed for every move.
    const int command=coordinate(target_)-coordinate(trace_.startPosition);
    const bool overshoot=command>0?coordinate(p)>coordinate(target_):coordinate(p)<coordinate(target_);
    const auto kind=overshoot?PositionDisposition::TargetOvershoot:PositionDisposition::AwayFromTarget;
    recordPosition(true,p,kind);
    previousDistanceValid_=false;
    settled_ = 0;
    if (repeatedWrongSample(kind)) fail(overshoot?"Repeated target overshoot":"Repeated movement away from target");
    return;
  }
  recordPosition(true,p);
  wrongSamples_ = 0;
  // Confirm progress with two consecutive accepted reads. A single closer
  // outlier cannot establish the baseline. Unlike a fixed counts/poll cap,
  // this follows validated motion at the configured speed.
  if(previousDistanceValid_){
    const int confirmed=remaining>previousDistance_?remaining:previousDistance_;
    if(confirmed<bestDistance_)bestDistance_=confirmed;
  }
  previousDistance_=remaining;previousDistanceValid_=true;
  position_ = p;
  if (remaining <= tolerance) {
    {
      // A wider target band is not proof of settling: require a stable window,
      // not five samples that are still travelling through the band.
      if(!settled_) settleMinimum_ = settleMaximum_ = coordinate(p);
      const int low = coordinate(p) < settleMinimum_ ? coordinate(p) : settleMinimum_;
      const int high = coordinate(p) > settleMaximum_ ? coordinate(p) : settleMaximum_;
      if(high-low > kSettlingSpread) {settled_=0;settleMinimum_=settleMaximum_=coordinate(p);}
      else {settleMinimum_=low;settleMaximum_=high;}
    }
    trace_.settled=settled_+1;
    if (++settled_ >= COVER_SETTLE_SAMPLES) {
      if(state_==State::Manual && holdAfterMove_) {
        bool enabled=false;
        if(!servo_.readTorque(enabled)||!enabled){fail("Holding torque unconfirmed");return;}
        state_=State::Holding;wrongSamples_=readFailures_=limitSamples_=0;return;
      }
      const State finished = state_ == State::Opening ? State::Open : state_ == State::Closing ? State::Closed : State::Stopped;
      if(finished==State::Stopped || settings_.disableTorqueAfterMove) stop();
      else {
        bool enabled=false;
        if(!servo_.readTorque(enabled) || !enabled){fail("Endpoint torque unconfirmed");return;}
      }
      if(state_ != State::Fault) state_ = finished;
    }
  } else {settled_ = 0;trace_.settled=0;}
}
}
