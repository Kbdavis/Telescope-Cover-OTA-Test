#pragma once
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <atomic>

namespace cover {
// POD layout is intentional: RTC_NOINIT storage must have no startup constructor.
struct FailureContext {
 char firmware[65],boot[33];
 uint32_t at,freeHeap,minimumHeap,largestBlock,largestAvailable;
};
struct RetainedWiFiFailure {
 uint32_t present,active,firstReason,lastReason,disconnects,retries,lastRetryAt,nextWait,recoveredAt,outageMs;
 int32_t retryResult,rssi;
 uint8_t bssid[6];
 char localAction[32];uint32_t actionAge;
 FailureContext context;
};
struct RetainedCoverFault {
 uint32_t present,position,target;
 char message[80];
 FailureContext context;
};
struct FailureSummaryRecord {
 uint32_t version,sequence,boots,reset;
 RetainedWiFiFailure wifi;
 RetainedCoverFault fault;
};
struct FailureSummarySlot {uint32_t committed;FailureSummaryRecord record;uint32_t checksum;};
static_assert(sizeof(FailureSummarySlot)*2<=1024,"Keep retained evidence below 1 KiB");

// Caller serializes access. Two checksummed slots preserve the preceding commit
// if reset interrupts a write. This is reset-retained RAM, never flash storage.
class FailureSummaryStore {
 FailureSummarySlot* slots_;int active_=-1;
 static constexpr uint32_t kMagic=0x46414931;
 static void increment(uint32_t& v){if(v!=UINT32_MAX)++v;}
 int readable()const{
  if(active_>=0 && valid(slots_[active_]))return active_;
  if(active_>=0 && valid(slots_[1-active_]))return 1-active_;
  return -1;
 }
public:
 explicit FailureSummaryStore(FailureSummarySlot* slots):slots_(slots){}
 static uint32_t checksum(const FailureSummaryRecord& record){
  const auto* bytes=reinterpret_cast<const uint8_t*>(&record);uint32_t hash=2166136261u;
  for(size_t i=0;i<sizeof(record);++i)hash=(hash^bytes[i])*16777619u;
  return hash;
 }
 static bool valid(const FailureSummarySlot& slot){
  return slot.committed==kMagic && slot.record.version==1 && slot.record.sequence &&
   slot.record.wifi.context.firmware[64]==0 && slot.record.wifi.context.boot[32]==0 && slot.record.wifi.localAction[31]==0 &&
   slot.record.fault.context.firmware[64]==0 && slot.record.fault.context.boot[32]==0 &&
   slot.record.fault.message[79]==0 && checksum(slot.record)==slot.checksum;
 }
 FailureSummaryRecord snapshot()const{
  FailureSummaryRecord record{};const int index=readable();
  if(index>=0)memcpy(&record,&slots_[index].record,sizeof(record));
  return record;
 }
 void commit(FailureSummaryRecord record){
  const int previous=readable();
  record.version=1;record.sequence=previous<0?1:slots_[previous].record.sequence+1;
  if(!record.sequence)record.sequence=1;
  const int next=previous==0?1:0;
  slots_[next].committed=0;std::atomic_thread_fence(std::memory_order_seq_cst);
  memcpy(&slots_[next].record,&record,sizeof(record));slots_[next].checksum=checksum(record);
  std::atomic_thread_fence(std::memory_order_seq_cst);slots_[next].committed=kMagic;
  active_=next;
 }
 void begin(bool preserve,uint32_t reset){
  active_=-1;
  if(preserve){
   if(valid(slots_[0]))active_=0;
   if(valid(slots_[1]) && (active_<0 || int32_t(slots_[1].record.sequence-slots_[0].record.sequence)>0))active_=1;
  }else{slots_[0].committed=0;slots_[1].committed=0;}
  auto record=snapshot();increment(record.boots);record.reset=reset;commit(record);
 }
 void disconnect(const FailureContext& context,uint32_t reason,int rssi,const uint8_t* bssid,const char* action="none",uint32_t actionAge=0){
  auto record=snapshot();auto& wifi=record.wifi;
  if(!wifi.present || !wifi.active || strcmp(wifi.context.boot,context.boot)){
   memset(&wifi,0,sizeof(wifi));wifi.present=wifi.active=1;wifi.context=context;
   wifi.firstReason=reason;wifi.rssi=rssi;if(bssid)memcpy(wifi.bssid,bssid,6);
   strncpy(wifi.localAction,action,sizeof(wifi.localAction)-1);wifi.actionAge=actionAge;
  }
  wifi.lastReason=reason;increment(wifi.disconnects);commit(record);
 }
 void retry(const char* boot,uint32_t now,int result,uint32_t wait){
  auto record=snapshot();auto& wifi=record.wifi;
  if(!wifi.present || !wifi.active || strcmp(wifi.context.boot,boot))return;
  increment(wifi.retries);wifi.lastRetryAt=now;wifi.retryResult=result;wifi.nextWait=wait;commit(record);
 }
 void recovered(const char* boot,uint32_t now){
  auto record=snapshot();auto& wifi=record.wifi;
  if(!wifi.present || !wifi.active || strcmp(wifi.context.boot,boot))return;
  wifi.active=0;wifi.recoveredAt=now;wifi.outageMs=now-wifi.context.at;commit(record);
 }
 void fault(const FailureContext& context,const char* message,uint32_t position,uint32_t target){
  auto record=snapshot();auto& fault=record.fault;
  fault.present=1;fault.context=context;fault.position=position;fault.target=target;
  memset(fault.message,0,sizeof(fault.message));strncpy(fault.message,message,sizeof(fault.message)-1);commit(record);
 }
};
}
