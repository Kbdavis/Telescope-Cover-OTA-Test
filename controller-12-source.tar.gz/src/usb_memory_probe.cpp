#if defined(COVER_WEB_CONTROL) && defined(COVER_USB_MEMORY_PROBE)
#include "usb_memory_probe.h"
#include "memory_failures.h"
#include "diagnostics.h"
#include <Arduino.h>
#include <esp_heap_caps.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <stdio.h>
#include <string.h>
namespace cover {
namespace {
#ifndef COVER_USB_MEMORY_DURATION_MS
#define COVER_USB_MEMORY_DURATION_MS 180000
#endif
constexpr uint32_t kUsbWindowMs=COVER_USB_MEMORY_DURATION_MS;
static_assert(kUsbWindowMs>=180000 && kUsbWindowMs<=600000,"Bound the explicit USB experiment");
AllocationFailures failures;
uint32_t started=0,lastSample=0,lastStackReport=0,queuePeak=0;
bool hook=false,finished=false;
std::atomic<uint32_t> requests{0},statusRequests{0};
struct Stack {std::atomic<uint32_t> free{UINT32_MAX},at{0};};
Stack stacks[kDiagnosticTaskCount];
// Only the diagnostics owner formats output; fixed storage avoids printf's
// long-line allocation and bypasses the diagnostics queue being measured.
char line[352];
void writeLine(int size){if(size>0 && size<int(sizeof(line)))Serial.write(reinterpret_cast<const uint8_t*>(line),size);}
void failed(size_t size,uint32_t caps,const char*){failures.failure(uint32_t(size),caps);}
bool collecting(){return failures.enabled.load() && usbMemoryWindow(millis(),started,kUsbWindowMs);}
}
void beginUsbMemoryProbe(){
 started=millis();hook=heap_caps_register_failed_alloc_callback(failed)==ESP_OK;
 failures.enabled.store(true);
}
void noteUsbMemoryHttp(const char* path){
 if(!collecting())return;
 requests.fetch_add(1);if(path && !strcmp(path,"/api/status"))statusRequests.fetch_add(1);
}
void noteUsbMemoryStack(DiagnosticTask task){
 if(!collecting())return;
 const unsigned index=static_cast<unsigned>(task);if(index>=kDiagnosticTaskCount)return;
 auto& row=stacks[index];const uint32_t now=millis(),at=row.at.load();
 if(at && uint32_t(now-at)<5000)return;
 row.free.store(uxTaskGetStackHighWaterMark(nullptr));row.at.store(now);
}
void pollUsbMemoryProbe(unsigned queued,uint32_t dropped,uint32_t truncated){
 if(finished)return;
 const uint32_t now=millis();
 if(!usbMemoryWindow(now,started,kUsbWindowMs)){
  failures.enabled.store(false);finished=true;
  writeLine(snprintf(line,sizeof(line),"[%lu] USBMEM end duration_ms=%lu failures=%lu hook=%d http=%lu status_http=%lu\n",
   (unsigned long)now,(unsigned long)(now-started),(unsigned long)failures.count.load(),hook,
   (unsigned long)requests.load(),(unsigned long)statusRequests.load()));return;
 }
 if(queued>queuePeak)queuePeak=queued;
 if(lastSample && uint32_t(now-lastSample)<1000)return;
 lastSample=now;
 multi_heap_info_t internal{},dma{};
 heap_caps_get_info(&internal,MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT);
 heap_caps_get_info(&dma,MALLOC_CAP_INTERNAL|MALLOC_CAP_DMA);
 writeLine(snprintf(line,sizeof(line),"[%lu] USBMEM heap internal_free=%u internal_min=%u internal_block=%u dma_free=%u dma_block=%u queue=%u queue_peak_sampled=%lu dropped=%lu truncated=%lu http=%lu status_http=%lu\n",
  (unsigned long)now,unsigned(internal.total_free_bytes),unsigned(internal.minimum_free_bytes),unsigned(internal.largest_free_block),
  unsigned(dma.total_free_bytes),unsigned(dma.largest_free_block),queued,(unsigned long)queuePeak,
  (unsigned long)dropped,(unsigned long)truncated,(unsigned long)requests.load(),(unsigned long)statusRequests.load()));
 AllocationFailureSample sample;
 if(failures.snapshot(sample))
  writeLine(snprintf(line,sizeof(line),"[%lu] USBMEM allocation hook=%d failures=%lu metadata_lost=%lu sequence=%lu requested=%lu caps=0x%lx\n",
   (unsigned long)now,hook,(unsigned long)failures.count.load(),(unsigned long)failures.metadataLost.load(),
   (unsigned long)sample.sequence,(unsigned long)sample.size,(unsigned long)sample.caps));
 if(!lastStackReport || uint32_t(now-lastStackReport)>=5000){
  lastStackReport=now;
  for(unsigned i=0;i<kDiagnosticTaskCount;++i){
   const auto free=stacks[i].free.load(),at=stacks[i].at.load();
   writeLine(snprintf(line,sizeof(line),"[%lu] USBMEM stack task=%s min_free=%ld age_ms=%lu\n",(unsigned long)now,
    diagnosticTaskName(static_cast<DiagnosticTask>(i)),free==UINT32_MAX?-1L:long(free),(unsigned long)(at?now-at:0)));
  }
 }
}
}
#endif
