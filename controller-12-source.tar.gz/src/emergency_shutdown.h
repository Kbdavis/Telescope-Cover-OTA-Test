#pragma once
#include "alpaca_client.h"
#include <stdint.h>
struct cJSON;
namespace cover {
enum class ShutdownPhase { Idle, StoppingCapture, VerifyingIdle, Stowing, VerifyingStow, Closing, Complete, Fault, Cancelled };
enum class ShutdownAction { None, StopCapture, Park };
enum class ShutdownResult { Deferred, Acknowledged, Failed };
struct ShutdownRequest {
 ShutdownRequest(const char* name="none",const char* failure="none",int32_t result=0,uint32_t tx=0,uint32_t elapsed=0):request(name),error(failure),code(result),transaction(tx),elapsedMs(elapsed){}
 const char* request="none";
 const char* error="none";
 int32_t code=0;
 uint32_t transaction=0,elapsedMs=0;
};
struct ShutdownNative {
 uint32_t operation=0,sequence=0,sampledAt=0;
 bool valid=false,imagingIdle=false,cameraIdle=false,planIdle=false,closed=false,moving=false,tracking=false;
 ShutdownRequest detail;
 bool fresh(uint32_t now) const {return valid && uint32_t(now-sampledAt)<3000;}
 bool quiet(uint32_t now) const {return fresh(now)&&imagingIdle&&cameraIdle&&planIdle&&!moving&&!tracking;}
};
struct ShutdownReply {uint32_t operation=0,at=0;ShutdownAction action=ShutdownAction::None;bool done=false,ok=false;ShutdownRequest detail;};
struct ShutdownDiagnostic {
 uint32_t sequence=0,at=0,sampleAgeMs=0;
 ShutdownPhase phase=ShutdownPhase::Idle;
 const char* source="none";
 ShutdownRequest detail;
};
struct ShutdownStatus {
 ShutdownPhase phase=ShutdownPhase::Idle;
 uint32_t operation=0,startedAt=0,phaseAt=0;
 bool recovering=false;
 uint32_t recoveryAt=0,recoveries=0;
 ShutdownDiagnostic diagnostic;
 bool active() const {return phase>=ShutdownPhase::StoppingCapture&&phase<=ShutdownPhase::Closing;}
 bool locked() const {return active()||phase==ShutdownPhase::Fault||phase==ShutdownPhase::Cancelled;}
 ShutdownAction action() const {return phase==ShutdownPhase::StoppingCapture?ShutdownAction::StopCapture:phase==ShutdownPhase::Stowing?ShutdownAction::Park:ShutdownAction::None;}
 bool commandReady() const {return active()&&!recovering&&action()!=ShutdownAction::None;}
 const char* message="Emergency shutdown ready";
};
// Only unsent commands may be deferred. A success or uncertain write outcome
// consumes that action for the operation, including across telemetry recovery.
class ShutdownDispatch {
 public:
 bool ready(uint32_t now,const ShutdownStatus& s){
  if(operation_!=s.operation){operation_=s.operation;consumed_=0;waiting_=false;}
  return s.operation&&s.commandReady()&&!(consumed_&(1U<<unsigned(s.action())))&&(!waiting_||int32_t(now-retryAt_)>=0);
 }
 void complete(uint32_t now,ShutdownAction action,ShutdownResult result){
  waiting_=result==ShutdownResult::Deferred;
  if(waiting_)retryAt_=now+1000;
  else consumed_|=1U<<unsigned(action);
 }
 private:
 uint32_t operation_=0,retryAt_=0;
 unsigned consumed_=0;bool waiting_=false;
};
struct ShutdownEvidence {
 bool coverReady=false,coverStationary=false,coverOpen=false,coverClosed=false,coverMoving=false,torqueOff=false;
 bool positionFresh=false,calibrationClean=false;
 alpaca::Snapshot scope;
 ShutdownNative native;
 ShutdownReply reply;
};
// No I/O: the motion worker owns this sequence and executes its closing request.
class EmergencyShutdown {
 public:
 bool start(uint32_t now,const ShutdownEvidence& e);
 void tick(uint32_t now,const ShutdownEvidence& e);
 void cancel(uint32_t now);
 void fail(uint32_t now,const char* reason);
 bool finish(uint32_t now,const ShutdownEvidence& e);
 bool closePermitted(uint32_t now,const ShutdownEvidence& e) const;
 ShutdownStatus status() const {return status_;}
 private:
 void enter(ShutdownPhase phase,uint32_t now,const char* message);
 void record(uint32_t now,const ShutdownEvidence& e,const char* source,const ShutdownRequest& detail);
 void recordAlpaca(uint32_t now,const ShutdownEvidence& e);
 bool recover(uint32_t now,const ShutdownEvidence& e);
 ShutdownStatus status_;
 uint32_t nativeSequence_=0,scopeSequence_=0;
 unsigned confirmations_=0;
 uint32_t recoveryScope_=0,recoveryNative_=0;
 unsigned recoveryConfirmations_=0,recoverySignature_=0;
 const char* resumeMessage_="";
};
const char* shutdownPhaseName(ShutdownPhase phase);
// Strict native parser; missing/unknown activity never counts as stopped.
bool parseShutdownNative(const cJSON* device,const cJSON* camera,const cJSON* app,const cJSON* plans,
                         uint32_t now,ShutdownNative& out);
// Native-worker bridge. Returned observations are tied to one operation.
ShutdownNative shutdownNativeStatus();
ShutdownReply shutdownNativeReply();
}
