#pragma once
#include "cover_controller.h"
namespace cover {
// Separate from WebStatus: do not inflate the ordinary status/motion task's
// copied stack frame with an extra history buffer. Published under its lock.
struct ServoSupportSnapshot {
 bool available=false,startupFault=false;
 uint32_t sampledAt=0,faultRevision=0;
 uint32_t heartbeatAgeMs=0,heartbeatReceivedAt=0,heartbeatProcessedAt=0,heartbeatSequence=0;
 ServoDiagnostics current;
 MotionFaultEvidence fault;
 MotionTrace frozenTrace;
};
static_assert(sizeof(ServoSupportSnapshot)<=1280,"Bound passive servo support storage");
void copyServoSupport(ServoSupportSnapshot& output);
}
