#pragma once
#include "alpaca_client.h"
namespace cover {
// Missing telemetry may be replaced by one explicit visual confirmation.
// Positive, fresh evidence of an unsafe telescope still blocks closure.
inline bool manualStowContradicted(const alpaca::Snapshot& scope,uint32_t now){
 return scope.fresh(now) && scope.connected && (!scope.atHome || scope.slewing || scope.tracking);
}
}
