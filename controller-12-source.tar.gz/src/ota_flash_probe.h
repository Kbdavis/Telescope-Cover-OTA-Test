#pragma once
#include "ota_protocol.h"
namespace cover {
// Fixed-slot experimental policy. Never silently erase a candidate/fallback.
inline bool otaProbeTargetAllowed(uint32_t running,uint32_t selected,uint32_t target,uint32_t sourceBytes,uint32_t targetBytes,const uint8_t* header,size_t n){
 if(running!=0x10000 || selected!=running || target!=0x150000 || sourceBytes!=kOtaSlotBytes || targetBytes!=kOtaSlotBytes || !header || n!=kOtaPrefixBytes)return false;
 for(size_t i=0;i<n;++i)if(header[i]!=0xff)return false;
 return true;
}
// Caller serializes this with queue reservation. Failed authentication/manifest
// validation never reaches this function. No second accepted attempt per boot.
inline bool reserveOtaProbe(bool active,bool locked,bool& attempted){
 if(active || locked || attempted)return false;
 attempted=true;return true;
}
inline bool otaProbeSelectionUnchanged(uint32_t running,uint32_t selected){return running==0x10000 && selected==running;}
}
