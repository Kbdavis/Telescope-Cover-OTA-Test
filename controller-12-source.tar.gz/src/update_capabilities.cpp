#ifdef COVER_WEB_CONTROL
#include "update_capabilities.h"
#include "firmware_version.h"
#include "diagnostics.h"
#include "web_control.h"
#include "ota_service.h"
#include "servo_support.h"
#include "update_profile_evidence.h"
#include <esp_ota_ops.h>
#include <string.h>
namespace cover {
String updateCapabilitiesJson(){
 const auto status=webStatus();
 ServoSupportSnapshot support;copyServoSupport(support);
 const bool profileVerified=support.available && updateNativeProfileVerified(support.current,millis());
 const auto* running=esp_ota_get_running_partition();
 const auto* target=esp_ota_get_next_update_partition(nullptr);
 // Layout verification is shared with startup, rather than inferred from two slots.
 const bool layout=otaPinnedLayout();
 String out;out.reserve(1536);
 out="{\"schema\":\"telescope-cover-device/1\",\"firmware\":{\"version\":\"";
 out+=COVER_VERSION;out+="\",\"commit\":\"";out+=COVER_SOURCE_COMMIT;
 out+="\",\"elf\":\"";out+=firmwareId();out+="\",\"build_profile\":\"";out+=COVER_BUILD_PROFILE;
 out+="\",\"release\":";out+=strstr(COVER_VERSION_JSON,"\"release\":true")?"true":"false";
 out+=",\"dirty\":";out+=strstr(COVER_VERSION_JSON,"\"dirty\":false")?"false":"true";
 out+="},\"hardware\":{\"board\":\"waveshare-21593\",\"chip\":\"esp32\",\"flash_bytes\":";
 out+=String(ESP.getFlashChipSize());out+=",\"layout\":\"";out+=layout?"cover-4mb-v1":"unknown";
 out+="\",\"slot_bytes\":";out+=String(layout && running && target?min(running->size,target->size):0);
 out+="},\"motion\":";
#ifdef COVER_MULTITURN
 out+="{\"capability\":\"native-multiturn-v1\",\"profile_sha256\":\"11ec86b5a32010e63a62d009d190685f05bafdf5118df74612991a7e20971470\",\"reference_offset\":85,\"opening_direction\":-1,\"startup_policy\":\"inspect-only-v1\"}";
#else
 // Absolute legacy profiles are not a qualified native update source.
 out+="null";
#endif
 out+=",\"settings\":{\"calibration\":5,\"application\":\"cover-app-382-v1\",\"network\":\"cover-app-network-v1\",\"auth\":\"legacy-session-token-v1\",\"handoff\":1}";
 // The existing private desktop uploader is not the signed browser receiver.
 // Neither historical rollback tests nor the SDK flag establish this device's
 // exact source/fallback qualification. Keep the production report fail-closed.
#ifdef COVER_BROWSER_OTA
 out+=",\"receiver\":{\"enabled\":true,\"protocol\":1,\"rollback\":\"unknown\"}";
#else
 out+=",\"receiver\":{\"enabled\":false,\"protocol\":1,\"rollback\":\"unknown\"}";
#endif
 out+=",\"calibration_review_required\":";out+=status.calibrationReview?"true":"false";
 out+=",\"read_only_test\":";
#ifdef COVER_WEB_READ_ONLY
 out+="true";
#else
 out+="false";
#endif
 out+=",\"servo_profile_verified\":";out+=profileVerified?"true":"false";out+="}";
 return out;
}
}
#endif
