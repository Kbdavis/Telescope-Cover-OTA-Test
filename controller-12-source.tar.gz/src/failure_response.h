#pragma once
#include "debug_response.h"
namespace cover {
constexpr size_t kFailureResponseBytes=2048;
inline void failureContextJson(DebugJson& json,const FailureContext& c){
 json.raw("{\"firmware\":");json.string(c.firmware);json.raw(",\"boot_id\":");json.string(c.boot);
 json.raw(",\"uptime_ms\":");json.number(c.at);json.raw(",\"free_heap\":");json.number(c.freeHeap);
 json.raw(",\"minimum_heap\":");json.number(c.minimumHeap);
 json.raw(",\"largest_internal_block\":");if(c.largestAvailable)json.number(c.largestBlock);else json.raw("null");json.raw("}");
}
inline void failureSigned(DebugJson& json,int32_t n){char buffer[16];snprintf(buffer,sizeof(buffer),"%ld",long(n));json.raw(buffer);}
inline size_t writeFailureSummary(char* data,const FailureSummaryRecord& record,const char* boot,const char* reset){
 DebugJson json(data,kFailureResponseBytes);
 json.raw("{\"schema_version\":1,\"retention\":\"rtc\",\"power_loss_persistent\":false,\"available\":");
 json.raw(record.version==1?"true":"false");json.raw(",\"current_boot\":");json.string(boot);
 json.raw(",\"reset_reason\":");json.string(reset);json.raw(",\"retained_boots\":");json.number(record.boots);
 json.raw(",\"wifi\":");
 const auto& w=record.wifi;
 if(!w.present)json.raw("null");else{
  json.raw("{\"context\":");failureContextJson(json,w.context);
  json.raw(",\"same_boot\":");json.raw(strcmp(w.context.boot,boot)?"false":"true");
  json.raw(",\"active_in_recorded_boot\":");json.raw(w.active?"true":"false");
  json.raw(",\"first_reason\":");json.number(w.firstReason);json.raw(",\"last_reason\":");json.number(w.lastReason);
  json.raw(",\"disconnect_events\":");json.number(w.disconnects);json.raw(",\"rssi\":");failureSigned(json,w.rssi);
  char bssid[18];snprintf(bssid,sizeof(bssid),"%02x:%02x:%02x:%02x:%02x:%02x",w.bssid[0],w.bssid[1],w.bssid[2],w.bssid[3],w.bssid[4],w.bssid[5]);
  json.raw(",\"bssid\":");json.string(bssid);json.raw(",\"retries\":");json.number(w.retries);
  json.raw(",\"local_action\":");json.string(w.localAction);json.raw(",\"action_age_ms\":");json.number(w.actionAge);
  json.raw(",\"retry_result\":");if(w.retries)failureSigned(json,w.retryResult);else json.raw("null");
  json.raw(",\"last_retry_uptime_ms\":");if(w.retries)json.number(w.lastRetryAt);else json.raw("null");
  json.raw(",\"next_wait_ms\":");if(w.retries)json.number(w.nextWait);else json.raw("null");
  json.raw(",\"outage_ms\":");if(!w.active)json.number(w.outageMs);else json.raw("null");json.raw("}");
 }
 json.raw(",\"fault\":");const auto& f=record.fault;
 if(!f.present)json.raw("null");else{
  json.raw("{\"context\":");failureContextJson(json,f.context);json.raw(",\"message\":");json.string(f.message);
  json.raw(",\"position\":");if(f.position==UINT32_MAX)json.raw("null");else json.number(f.position);
  json.raw(",\"target\":");if(f.target==UINT32_MAX)json.raw("null");else json.number(f.target);json.raw("}");
 }
 json.raw("}");return json.ok()?json.size():0;
}
}
