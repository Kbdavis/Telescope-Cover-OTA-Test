#pragma once
#if __has_include("generated_version.h")
#include "generated_version.h"
#else
// Offline host tests do not run PlatformIO's metadata generator.
#define COVER_VERSION "unversioned-dev"
#define COVER_SOURCE_COMMIT "unknown"
#define COVER_BUILD_PROFILE "host"
#define COVER_VERSION_JSON "{\"version\":\"unversioned-dev\",\"commit\":\"unknown\",\"profile\":\"host\",\"built_at\":\"unknown\",\"release\":false,\"dirty\":true}"
#endif
