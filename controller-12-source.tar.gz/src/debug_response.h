#pragma once
#include "diagnostics.h"
#include "time_sync.h"
#include <stddef.h>
#include <stdio.h>
#include <string.h>
namespace cover {
constexpr size_t kDebugResponseBytes=4096;
inline bool debugCursor(const char* text,uint32_t& value){
 if(!*text || strlen(text)>10)return false;
 uint64_t parsed=0;for(const char* p=text;*p;++p){if(*p<'0' || *p>'9')return false;parsed=parsed*10+(*p-'0');}
 if(parsed>UINT32_MAX)return false;
 value=uint32_t(parsed);return true;
}
// One budget for all readers, charged at maximum response size before formatting.
class DebugReadBudget {
 uint32_t at_=0;unsigned used_=0;
public:
 bool take(uint32_t now){if(uint32_t(now-at_)>=1000){at_=now;used_=0;}if(used_>=2)return false;++used_;return true;}
};
class DebugJson {
 char* data_;size_t at_=0,limit_;bool ok_=true;
public:
 DebugJson(char* data,size_t limit):data_(data),limit_(limit){data_[0]=0;}
 size_t size() const{return at_;}bool ok() const{return ok_;}
 void rewind(size_t at){at_=at;ok_=true;data_[at_]=0;}
 void limit(size_t value){limit_=value;}
 void raw(const char* text){const size_t n=strlen(text);if(at_+n>limit_){ok_=false;return;}memcpy(data_+at_,text,n+1);at_+=n;}
 void number(uint32_t value){char buffer[16];snprintf(buffer,sizeof(buffer),"%lu",(unsigned long)value);raw(buffer);}
 void string(const char* text){
  raw("\"");for(const unsigned char* p=reinterpret_cast<const unsigned char*>(text);*p && ok_;++p){
   char escaped[7]={0};
   if(*p=='"' || *p=='\\'){escaped[0]='\\';escaped[1]=char(*p);}
   else if(*p<32 || *p>=127)snprintf(escaped,sizeof(escaped),"\\u%04x",unsigned(*p));
   else escaped[0]=char(*p);
   raw(escaped);
  }raw("\"");
 }
};
struct DebugEnvelope {
 DebugWindow window;
 const char* bootId="";const char* firmware="";
 uint32_t after=0;
 bool reset=false,metricsActive=false;
};
// Reader copies one ring entry under its lock; all JSON work happens outside it.
template<class Reader> size_t writeDebugResponse(char* data,const DebugEnvelope& env,Reader reader){
 DebugJson json(data,kDebugResponseBytes);const auto& w=env.window;
 json.raw("{\"schema_version\":1,\"boot_id\":");json.string(env.bootId);
 json.raw(",\"firmware\":");json.string(env.firmware);
 json.raw(",\"available\":");json.raw(w.available?"true":"false");
 json.raw(",\"capacity\":");json.number(kDebugCapacity);
 json.raw(",\"sequence_epoch\":");json.number(w.sequenceEpoch);
 json.raw(",\"oldest_sequence\":");json.number(w.oldest);json.raw(",\"newest_sequence\":");json.number(w.newest);
 json.raw(",\"loss\":{\"ring_overwrites\":");json.number(w.overwrites);
 json.raw(",\"serial_dropped\":");json.number(w.serialDropped);
 json.raw(",\"truncated\":");json.number(w.truncated);
 json.raw(",\"suppressed_trace\":");json.number(w.suppressedTrace);
 json.raw("},\"metrics_active\":");json.raw(env.metricsActive?"true":"false");
 json.raw(",\"cursor_reset\":");json.raw(env.reset?"true":"false");
 uint32_t cursor=env.reset?0:env.after;
 json.raw(",\"gap\":");json.raw(w.oldest && cursor<w.oldest-1?"true":"false");json.raw(",\"entries\":[");
 json.limit(kDebugResponseBytes-100);DebugEntry entry;
 for(unsigned n=0;n<16 && reader(cursor,entry) && entry.sequence<=w.newest;++n){
  const size_t mark=json.size();if(n)json.raw(",");
  json.raw("{\"sequence\":");json.number(entry.sequence);json.raw(",\"ms\":");json.number(entry.at);
  char local[kLocalTimestampSize];formatLocalTimestamp(entry.epoch,local,sizeof(local));
  json.raw(",\"local_time\":");if(local[0])json.string(local);else json.raw("null");
  json.raw(",\"level\":");json.string(entry.level==DebugLevel::Error?"error":entry.level==DebugLevel::Warn?"warn":"info");
  json.raw(",\"truncated\":");json.raw(entry.truncated?"true":"false");json.raw(",\"message\":");json.string(entry.message);json.raw("}");
  if(!json.ok()){json.rewind(mark);break;}cursor=entry.sequence;
 }
 json.limit(kDebugResponseBytes);json.raw("],\"next_after\":");json.number(cursor);
 json.raw(",\"more\":");json.raw(cursor<w.newest?"true":"false");json.raw("}");
 return json.ok()?json.size():0;
}
}
