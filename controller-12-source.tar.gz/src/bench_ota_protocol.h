#pragma once
#include "ota_protocol.h"
namespace cover {
constexpr size_t kBenchChunk=768;
struct BenchManifest {uint32_t sourceBuild=0,targetBuild=0,size=0;uint8_t source[32]={},target[32]={},sha[32]={};};
inline bool parseBenchManifest(const char* text,size_t size,BenchManifest& result){
 if(!text || size>768 || !size || memchr(text,0,size))return false;
 const char* p=text;const char* end=p+size;
 auto literal=[&](const char* value){const size_t n=strlen(value);if(size_t(end-p)<n || memcmp(p,value,n))return false;p+=n;return true;};
 auto number=[&](uint32_t& v){if(p==end || *p<'1' || *p>'9')return false;uint64_t n=0;
  while(p<end && *p>='0' && *p<='9'){n=n*10+*p++-'0';if(n>UINT32_MAX)return false;}
  if(p==end || *p++!='\n')return false;
  v=uint32_t(n);return true;};
 auto hex=[&](uint8_t* v){if(end-p<65 || !otaUnhex(p,64,v))return false;p+=64;return *p++=='\n';};
 BenchManifest m;
 if(!literal("product=telescope-cover-ota-bench\nprotocol=1\nlayout=cover-4mb-v1\nsettings=preserve-cover-app-v1\nsource_build=") ||
  !number(m.sourceBuild) || !literal("source_elf=") || !hex(m.source) || !literal("target_build=") || !number(m.targetBuild) ||
  !literal("target_elf=") || !hex(m.target) || !literal("size=") || !number(m.size) || !literal("sha256=") || !hex(m.sha) || p!=end ||
  m.sourceBuild>=m.targetBuild || m.targetBuild>9999 || m.size<kOtaPrefixBytes || m.size>kOtaSlotBytes)return false;
 result=m;return true;
}
inline bool benchSourceAllowed(const BenchManifest& m,uint32_t build,const uint8_t* elf){return m.sourceBuild==build && otaEqual(m.source,elf,32);}
inline bool benchPrefixValid(const uint8_t* p,size_t n,const BenchManifest& m){
 static const uint8_t marker[16]={'T','C','B','E','N','C','H','O','T','A','0','1',0,0,0,0};
 return n>=kOtaPrefixBytes && p[0]==0xe9 && p[1]>0 && p[1]<=16 && p[2]==2 && p[3]==0x20 && p[12]==0 && p[13]==0 && p[23]==1 &&
  otaU32(p+28)>=320 && otaU32(p+28)<=m.size-32 && otaU32(p+32)==0xabcd5432 &&
  otaEqual(p+176,m.target,32) && !memcmp(p+288,marker,sizeof(marker)) && otaU32(p+304)==m.targetBuild;
}
}
