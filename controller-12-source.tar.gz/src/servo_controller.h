#pragma once
#include "servo_build_config.h"

#include <Arduino.h>
#include "travel_model.h"

namespace cover {
namespace st3215 {
constexpr uint8_t kServoId = 1;
constexpr uint16_t kMinPosition = 0;
constexpr uint16_t kMaxPosition = 4095;
}

enum class ServoError {
  None, InvalidArgument, Timeout, WriteFailed, InvalidPacket,
  DeviceError, InvalidConfiguration, InvalidPosition, TorqueDisabled
};
struct ServoResult {
  ServoResult(ServoError value = ServoError::None, uint8_t status = 0)
      : error(value), deviceStatus(status) {}
  ServoError error = ServoError::None;
  uint8_t deviceStatus = 0;
  explicit operator bool() const { return error == ServoError::None; }
};
inline const char* servoFaultReason(ServoResult result,const char* fallback) {
  return result.error==ServoError::DeviceError && (result.deviceStatus & 0x08)
    ? "Servo overcurrent; cycle servo power before clearing fault" : fallback;
}
struct ServoConfiguration {
  uint8_t id = 0;
  uint8_t mode = 0;
  uint8_t phase = 0;
  uint8_t resolution = 0;
  uint16_t offset = 0;
  uint16_t minimum = 0;
  uint16_t maximum = 0;
};
struct ServoTelemetry {
  uint16_t position = 0;
  uint16_t targetPositionRaw = 0; // Raw read-only registers 67..68; diagnostic only.
  int16_t speedRaw = 0;
  int16_t relativeLoad = 0;  // Not calibrated torque.
  int16_t currentRaw = 0;  // No physical-unit conversion until bench verified.
  uint8_t voltageDecivolts = 0;
  uint8_t temperatureC = 0;
  bool moving = false;
};
struct ServoGoalReadback {
 uint16_t positionRaw=0,register44Raw=0,speedRaw=0,torqueLimitRaw=0;
 uint8_t acceleration=0;
};

// Passive cache only. Timestamps are controller uptime; valid flags distinguish
// never observed data from a genuine zero. No diagnostic accessor performs I/O.
struct ServoDiagnostics {
#ifdef COVER_MULTITURN
 int16_t nativePosition=0;bool nativePositionValid=false;uint32_t nativePositionAt=0;
#endif
 uint32_t exchanges=0,failedExchanges=0,failedReads=0,retries=0,rejectedPositions=0;
 uint32_t lastSuccessAt=0,lastFailureAt=0,positionAt=0,torqueAt=0,telemetryAt=0;
 bool hasSuccess=false,hasFailure=false,positionValid=false,torqueValid=false,torque=false,telemetryValid=false;
 uint16_t position=0,model=0;bool modelValid=false;uint32_t modelAt=0;
 ServoResult lastFailure;
 uint8_t failureInstruction=0,failureAddress=0;
 ServoTelemetry telemetry;
 ServoGoalReadback goal;
 uint32_t goalAt=0;bool goalValid=false;
 bool configurationRead=false,validationAttempted=false,validationPassed=false;
 bool snapshotValid=false,lockValid=false;uint8_t lock=0;
 uint32_t configurationAt=0,validationAt=0,snapshotAt=0;
 ServoResult validationResult;
 ServoConfiguration configuration;
 uint8_t snapshot[40]={};
};
const char* servoErrorName(ServoError error);

#if defined(COVER_REFERENCE_PROBE) || defined(COVER_FIXED_REFERENCE) || defined(COVER_MULTITURN)
// Evidence for fixed configuration preparation. No arbitrary register-write API.
struct ReferenceProbeEvidence {
 uint8_t before[40]={},after[40]={};
 uint16_t positionBefore=0,positionAfter=0;
 bool beforeValid=false,afterValid=false,writeAttempted=false,lockConfirmed=false;
 bool positionBeforeValid=false,positionAfterValid=false;
};
#endif

// Minimal hardware boundary for the cover safety controller and offline fakes.
class ServoMotion {
 public:
  virtual ~ServoMotion() = default;
  virtual ServoResult lastResult() const {return {};}
  virtual ServoResult validateConfiguration() = 0;
  virtual ServoResult readPosition(uint16_t&) = 0;
  virtual ServoResult readTorque(bool&) = 0;
  virtual ServoResult releaseTorque() = 0;
  virtual ServoResult enableTorque() = 0;
  virtual ServoResult moveTo(uint16_t, uint16_t, uint8_t, uint16_t, uint16_t) = 0;
  virtual bool rolloverSupported() const {return false;}
  virtual uint16_t maximumJogStep() const {return 500;}
  virtual void copyDiagnostics(ServoDiagnostics& output) const {output=ServoDiagnostics{};}
  virtual ServoResult moveAcrossBoundary(uint16_t,uint16_t,uint8_t,const TravelArc&) {return {ServoError::InvalidConfiguration};}
  // Only the cover controller's saved endpoint path uses this entry point.
  virtual ServoResult moveCalibratedEndpoint(uint16_t target,uint16_t speed,uint8_t acceleration,const TravelArc& arc) {
    if(!arc.valid() || (target!=arc.closedRaw && target!=arc.rawTarget(arc.length)))return {ServoError::InvalidArgument};
    uint16_t position=0;auto result=readPosition(position);if(!result)return result;
    if(!arc.endpointStartAllowed(position) || abs(arc.coordinate(position,25)-arc.coordinate(target,25))>=2048)
      return {ServoError::InvalidPosition};
    return supportedDirectPath(position,target)
      ? moveTo(target,speed,acceleration,arc.minimumRaw,arc.maximumRaw)
      : moveAcrossBoundary(target,speed,acceleration,arc);
  }
};

// Single caller only. Caller initializes the board's UART and bus circuitry.
// No constructor I/O. Output arguments change only after successful validation.
class ServoController : public ServoMotion {
 public:
  explicit ServoController(Stream& bus, uint8_t id = st3215::kServoId)
      : bus_(bus), id_(id) {}
  ServoResult lastResult() const override {return lastResult_;}
  bool rolloverSupported() const override {return rolloverSupported_;}
  ServoResult moveAcrossBoundary(uint16_t target,uint16_t speed,uint8_t acceleration,const TravelArc& arc) override;
#if defined(COVER_REFERENCE_PROBE) || defined(COVER_FIXED_REFERENCE)
  ServoResult probeLockedReference(bool restoreFactory,ReferenceProbeEvidence& evidence);
#endif
#ifdef COVER_MULTITURN
  // Update/rollback startup: exact native profile, stationary torque OFF,
  // reads only. The native-only restriction lasts for this driver lifetime.
  ServoResult inspectMultiTurnStartup();
#ifdef COVER_MULTITURN_PROBE
  ServoResult probeLockedMultiTurn(bool restoreFactory,ReferenceProbeEvidence& evidence) {
    return configureLockedMultiTurn(restoreFactory,evidence);
  }
#endif
#ifdef COVER_MULTITURN_STARTUP
  // Stationary exact-profile RAM setup; never enables torque or moves.
  ServoResult prepareMultiTurnStartup(ReferenceProbeEvidence& evidence);
#endif
  ServoResult moveCalibratedEndpoint(uint16_t target,uint16_t speed,uint8_t acceleration,const TravelArc& arc) override;
  uint16_t maximumJogStep() const override {return 500;}
#endif
#ifdef COVER_FIXED_REFERENCE
  // Exact approved RAM reference only; no movement or EEPROM unlock.
  ServoResult prepareFixedReference();
#endif
  ServoResult ping();
  ServoResult readModel(uint16_t& output);
  uint32_t retryCount() const { return retries_; }
  void copyDiagnostics(ServoDiagnostics& output) const override {output=diagnostics_;output.retries=retries_;}
  ServoResult readConfiguration(ServoConfiguration& output);
  // Documented identity (0..4) and persistent configuration (5..39).
  // Raw snapshot only, not a restore image; never includes live control registers.
  ServoResult readConfigurationSnapshot(uint8_t (&output)[40]);
  ServoResult validateConfiguration() override;
  // Return the same checked sample for diagnostics, including on mismatch.
  // Transport/device failures leave output unchanged.
  ServoResult validateConfiguration(ServoConfiguration& output);
  ServoResult readPosition(uint16_t& output) override;
  ServoResult readTelemetry(ServoTelemetry& output);
  ServoResult readGoal(ServoGoalReadback& output); // Read-only, no staging or torque changes.
  ServoResult readTorque(bool& enabled) override;
  ServoResult releaseTorque() override;
  // Stages the present position before enabling to avoid a stale goal.
  ServoResult enableTorque() override;
  // Requires torque already enabled; limits supplied by the cover controller.
  ServoResult moveTo(uint16_t target, uint16_t speed, uint8_t acceleration,
                     uint16_t mechanicalMinimum, uint16_t mechanicalMaximum) override;

 private:
  ServoResult lastResult_;
  static constexpr uint32_t kTimeoutMs = 20;
  static constexpr uint8_t kReadAttempts = 3;
  ServoResult exchange(uint8_t instruction, const uint8_t* parameters,
                       uint8_t count, uint8_t* output, uint8_t outputCount);
  ServoResult exchangePacket(uint8_t instruction,const uint8_t* parameters,uint8_t count,uint8_t* output,uint8_t outputCount);
  ServoResult checkConfiguration(ServoConfiguration& output);
  ServoDiagnostics diagnostics_;
  ServoResult read(uint8_t address, uint8_t count, uint8_t* output);
  ServoResult writeGoal(uint16_t target, uint16_t speed, uint8_t acceleration);
  bool rolloverSupported_=false;
#ifdef COVER_MULTITURN
  bool multiTurnActive_=false,nativePositionValid_=false,updateInspectionOnly_=false;
  int nativePosition_=0;
#ifdef COVER_MULTITURN_STARTUP
  bool startupWriteAttempted_=false;
  bool startupProfileRequired_=false;
  bool startupInspection_=false;
  ServoResult startupPreparationResult_{ServoError::InvalidConfiguration};
#endif
  ServoResult configureLockedMultiTurn(bool restoreFactory,ReferenceProbeEvidence& evidence);
  ServoResult decodeNativePosition(uint16_t encoded,uint16_t& wrapped);
  ServoResult writeNativeGoal(int target,uint16_t speed,uint8_t acceleration,uint16_t maximumDistance=500);
#endif
  Stream& bus_;
  uint8_t id_;
  uint32_t retries_ = 0;
};
}  // namespace cover
