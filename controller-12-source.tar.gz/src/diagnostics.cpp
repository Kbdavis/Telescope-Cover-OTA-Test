#ifdef COVER_WEB_CONTROL
#include "diagnostics.h"
#include "firmware_version.h"
#include "time_sync.h"
#include "debug_buffer.h"
#include "usb_memory_probe.h"
#include <Arduino.h>
#include <WiFi.h>
#include <esp_system.h>
#include <esp_wifi.h>
#include <esp_ota_ops.h>
#include <esp_heap_caps.h>
#include <driver/timer.h>
#include <freertos/FreeRTOS.h>
#include <freertos/queue.h>
#include <freertos/task.h>
#include <atomic>
#include <stdarg.h>
#include <new>
namespace cover {
namespace {
struct Entry { uint32_t at,epoch; char message[320]; };
QueueHandle_t logs=nullptr;
DebugBuffer* debugEntries=nullptr;
portMUX_TYPE debugMux=portMUX_INITIALIZER_UNLOCKED;
std::atomic<uint32_t> webAt{0}, motionAt{0}, dropped{0}, truncatedRecords{0}, suppressedTrace{0};
constexpr uint32_t kStackSampleIntervalMs=5000;
struct StackEvidence {
 std::atomic<uint32_t> minimumFreeBytes{UINT32_MAX},sampledAt{0},epoch{0};
};
StackEvidence taskStacks[kDiagnosticTaskCount];
// Reserve general-purpose timer group 1 / timer 1; no other project module uses it.
constexpr uint32_t kCpuSamplePeriodUs=4093;
static_assert(ATOMIC_INT_LOCK_FREE==2,"CPU ISR counters must be lock free");
std::atomic<uint32_t> cpuSamples{0};
std::atomic<uint32_t> cpuIdle[2]{{0},{0}};
TaskHandle_t cpuIdleTasks[2]={nullptr,nullptr};
portMUX_TYPE metricsMux=portMUX_INITIALIZER_UNLOCKED;
MetricsLeases metricsLeases;
MetricsCollector metricsCollector;
RuntimeDiagnostics metricsCache;
MetricsPhase metricsPhase=MetricsPhase::Off;
std::atomic<uint32_t> metricsEpoch{0},optionalReaders{0};
uint32_t nextMetricsEpoch=0;
bool metricsOwnerReady=false,timerInitialized=false,timerCallback=false;
char metricsBoot[33]="unavailable";
CpuLoadSample cpuStatus;
CpuLoadTracker cpuTracker;
bool IRAM_ATTR sampleCpu(void*){
 // Independent timer avoids sampling at the same phase as periodic RTOS work.
 // This ISR is the only counter writer. Relaxed load/store requires no CAS loop.
 for(unsigned i=0;i<2;++i){
  if(xTaskGetCurrentTaskHandleForCPU(i)==cpuIdleTasks[i])
   cpuIdle[i].store(cpuIdle[i].load(std::memory_order_relaxed)+1,std::memory_order_relaxed);
 }
 cpuSamples.store(cpuSamples.load(std::memory_order_relaxed)+1,std::memory_order_relaxed);
 return false;
}
bool beginCpuSampling(){
 cpuSamples.store(0);cpuTracker=CpuLoadTracker{};cpuStatus=CpuLoadSample{};
 for(unsigned i=0;i<2;++i){cpuIdle[i].store(0);cpuIdleTasks[i]=xTaskGetIdleTaskHandleForCPU(i);if(!cpuIdleTasks[i])return false;}
 timer_config_t config{};
 config.divider=80;config.counter_dir=TIMER_COUNT_UP;config.counter_en=TIMER_PAUSE;
 config.alarm_en=TIMER_ALARM_EN;config.auto_reload=TIMER_AUTORELOAD_EN;config.intr_type=TIMER_INTR_LEVEL;
 if(timer_init(TIMER_GROUP_1,TIMER_1,&config)!=ESP_OK)return false;
 timerInitialized=true;
 if(timer_set_counter_value(TIMER_GROUP_1,TIMER_1,0)!=ESP_OK ||
    timer_set_alarm_value(TIMER_GROUP_1,TIMER_1,kCpuSamplePeriodUs)!=ESP_OK)return false;
 if(timer_isr_callback_add(TIMER_GROUP_1,TIMER_1,sampleCpu,nullptr,ESP_INTR_FLAG_IRAM)!=ESP_OK)return false;
 timerCallback=true;
 return timer_start(TIMER_GROUP_1,TIMER_1)==ESP_OK;
}
bool stopCpuSampling(){
 if(!timerInitialized)return true;
 if(timer_pause(TIMER_GROUP_1,TIMER_1)!=ESP_OK || timer_disable_intr(TIMER_GROUP_1,TIMER_1)!=ESP_OK)return false;
 if(timerCallback){if(timer_isr_callback_remove(TIMER_GROUP_1,TIMER_1)!=ESP_OK)return false;timerCallback=false;}
 if(timer_deinit(TIMER_GROUP_1,TIMER_1)!=ESP_OK)return false;
 timerInitialized=false;return true;
}
portMUX_TYPE wifiMetricsMux=portMUX_INITIALIZER_UNLOCKED;
WiFiDiagnosticTracker wifiMetrics;
struct MetricsBackend {
 uint32_t lastSnapshot=0;
 bool start(){
  if(!beginCpuSampling())return false;
  portENTER_CRITICAL(&metricsMux);
  metricsLeases.expire(millis());
  const bool wanted=metricsLeases.viewers()!=0;
  if(wanted){if(!++nextMetricsEpoch)++nextMetricsEpoch;metricsEpoch.store(nextMetricsEpoch);}
  portEXIT_CRITICAL(&metricsMux);
  lastSnapshot=0;return wanted;
 }
 bool stop(){metricsEpoch.store(0);return stopCpuSampling();}
 bool quiescent(){return optionalReaders.load()==0;}
 void clear(){
  cpuStatus=CpuLoadSample{};cpuTracker=CpuLoadTracker{};
  portENTER_CRITICAL(&metricsMux);metricsCache=RuntimeDiagnostics{};portEXIT_CRITICAL(&metricsMux);
 }
 void sample(uint32_t now){
  const uint32_t epoch=metricsEpoch.load();if(!epoch)return;
  const uint32_t samples=cpuSamples.load(std::memory_order_relaxed);
  const uint32_t idle[]={cpuIdle[0].load(std::memory_order_relaxed),cpuIdle[1].load(std::memory_order_relaxed)};
  CpuLoadSample next;if(cpuTracker.update(now,samples,idle,next))cpuStatus=next;
  if(lastSnapshot && uint32_t(now-lastSnapshot)<1000)return;
  lastSnapshot=now;
  RuntimeDiagnostics result;result.available=true;result.sampledAt=now;result.epoch=epoch;
  multi_heap_info_t heap{};heap_caps_get_info(&heap,MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT);
  result.internalFreeHeap=heap.total_free_bytes;result.internalMinimumFreeHeap=heap.minimum_free_bytes;
  result.internalLargestFreeBlock=heap.largest_free_block;result.debugLogAvailable=debugLogAvailable();result.cpu=cpuStatus;
  result.logDropped=dropped.load();result.webGapMs=now-webAt.load();result.motionGapMs=now-motionAt.load();
  const auto loss=debugLogWindow();result.ringOverwrites=loss.overwrites;
  result.logTruncated=loss.truncated;result.suppressedTrace=loss.suppressedTrace;
  portENTER_CRITICAL(&wifiMetricsMux);result.wifi=wifiMetrics.data;result.wifiOutageMs=wifiMetrics.outageMs(now);portEXIT_CRITICAL(&wifiMetricsMux);
  for(unsigned i=0;i<kDiagnosticTaskCount;++i){
   auto& stack=result.stacks[i];auto& evidence=taskStacks[i];
   stack.available=evidence.epoch.load()==epoch;
   if(stack.available){stack.minimumFreeBytes=evidence.minimumFreeBytes.load();stack.sampledAt=evidence.sampledAt.load();}
  }
  portENTER_CRITICAL(&metricsMux);
  if(metricsEpoch.load()==epoch)metricsCache=result;
  portEXIT_CRITICAL(&metricsMux);
 }
} metricsBackend;
void pollMetrics(){
 const uint32_t now=millis();
 portENTER_CRITICAL(&metricsMux);metricsLeases.expire(now);const bool wanted=metricsLeases.viewers()!=0;
 if(!wanted)metricsEpoch.store(0);
 portEXIT_CRITICAL(&metricsMux);
 // A last-close followed immediately by another open still needs a fresh baseline.
 metricsCollector.poll(wanted && !(metricsCollector.phase()==MetricsPhase::Active && !metricsEpoch.load()),now,metricsBackend);
 portENTER_CRITICAL(&metricsMux);metricsPhase=metricsCollector.phase();portEXIT_CRITICAL(&metricsMux);
}
char identity[65]="unavailable";
RTC_NOINIT_ATTR FailureSummarySlot retainedFailures[2];
FailureSummaryStore failureStore(retainedFailures);
portMUX_TYPE failureMux=portMUX_INITIALIZER_UNLOCKED;
FailureContext failureContext(bool largest=true){
 FailureContext context{};
 memcpy(context.firmware,identity,sizeof(context.firmware));memcpy(context.boot,metricsBoot,sizeof(context.boot));
 context.at=millis();context.freeHeap=ESP.getFreeHeap();context.minimumHeap=ESP.getMinFreeHeap();
 if(largest){context.largestBlock=heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT);context.largestAvailable=1;}
 return context;
}
std::atomic<uint32_t> loggerAt{0};
portMUX_TYPE wifiTraceMux=portMUX_INITIALIZER_UNLOCKED;
const char* lastWiFiAction="none";uint32_t lastWiFiActionAt=0;
std::atomic<uint32_t> associatedAt{0},lastLinkAt{0};
std::atomic<int> lastLinkRssi{0};
void logLink(){
 wifi_ap_record_t ap{};const esp_err_t result=esp_wifi_sta_get_ap_info(&ap);
 if(result!=ESP_OK)return; // Disconnected RSSI=0 is not a signal sample.
 lastLinkRssi.store(ap.rssi);lastLinkAt.store(millis());
 portENTER_CRITICAL(&wifiMetricsMux);wifiMetrics.signal(ap.rssi);portEXIT_CRITICAL(&wifiMetricsMux);
 diagnosticLog("WIFI LINK bssid=%02x:%02x:%02x:%02x:%02x:%02x channel=%u rssi=%d mode=%d sleep=%d auto_reconnect=%d",
  ap.bssid[0],ap.bssid[1],ap.bssid[2],ap.bssid[3],ap.bssid[4],ap.bssid[5],ap.primary,int(ap.rssi),int(WiFi.getMode()),int(WiFi.getSleep()),WiFi.getAutoReconnect());
}
void logger(void*) {
 uint32_t lastHealth=millis(),lastLink=millis();Entry entry;
 noteTaskStack(DiagnosticTask::Diagnostics);
 for(;;) {
  loggerAt.store(millis());
  pollMetrics();
#ifdef COVER_USB_MEMORY_PROBE
  pollUsbMemoryProbe(uxQueueMessagesWaiting(logs),dropped.load(),truncatedRecords.load());
#endif
  if(xQueueReceive(logs,&entry,pdMS_TO_TICKS(100))==pdTRUE){
   char local[kLocalTimestampSize];formatLocalTimestamp(entry.epoch,local,sizeof(local));
   Serial.printf("[%lu] %s local_time=%s\n",(unsigned long)entry.at,entry.message,local[0]?local:"unsynchronized");
  }
  if(millis()-lastLink>=1000){lastLink=millis();logLink();}
  if(millis()-lastHealth>=5000) {
   const uint32_t web=webAt.load(),motion=motionAt.load();
   lastHealth=millis();
   noteTaskStack(DiagnosticTask::Diagnostics);
   const auto resources=runtimeDiagnostics();
   char local[kLocalTimestampSize];formatLocalTimestamp(logEpochSeconds(),local,sizeof(local));
   const char* stamp=local[0]?local:"unsynchronized";
   Serial.printf("[%lu] HEALTH heap=%u min_heap=%u wifi=%d rssi=%d web_gap_ms=%lu motion_gap_ms=%lu log_dropped=%lu local_time=%s\n",
    (unsigned long)lastHealth,ESP.getFreeHeap(),ESP.getMinFreeHeap(),int(WiFi.status()),int(WiFi.RSSI()),
    (unsigned long)(lastHealth-web),(unsigned long)(lastHealth-motion),(unsigned long)dropped.load(),stamp);
   if(resources.available){
    Serial.printf("[%lu] METRICS internal_heap=%lu internal_min_heap=%lu internal_largest_block=%lu debug_log_available=%d debug_log_capacity=%u local_time=%s\n",
     (unsigned long)lastHealth,(unsigned long)resources.internalFreeHeap,(unsigned long)resources.internalMinimumFreeHeap,
     (unsigned long)resources.internalLargestFreeBlock,resources.debugLogAvailable,kDebugCapacity,stamp);
    for(unsigned i=0;i<kDiagnosticTaskCount;++i){
     const auto& stack=resources.stacks[i];
     Serial.printf("[%lu] STACK task=%s min_free_bytes=%ld sample_age_ms=%lu local_time=%s\n",
      (unsigned long)lastHealth,diagnosticTaskName(static_cast<DiagnosticTask>(i)),stack.available?long(stack.minimumFreeBytes):-1L,
      (unsigned long)(stack.available?resources.sampledAt-stack.sampledAt:0),stamp);
    }
   }
  }
 }
}
}
FailureSummaryRecord retainedFailureSummary(){
 portENTER_CRITICAL(&failureMux);auto result=failureStore.snapshot();portEXIT_CRITICAL(&failureMux);return result;
}
void noteRetainedFault(const char* message,uint32_t position,uint32_t target){
 const auto context=failureContext();
 portENTER_CRITICAL(&failureMux);failureStore.fault(context,message,position,target);portEXIT_CRITICAL(&failureMux);
}
void noteFailureRetry(int result,uint32_t nextWaitMs){
 // Keep a prior boot's evidence through brief startup association failures.
 // A startup outage becomes retained evidence once an application retry is due.
 const auto previous=retainedFailureSummary();
 const auto context=failureContext(!previous.wifi.present || !previous.wifi.active || strcmp(previous.wifi.context.boot,metricsBoot));
 portENTER_CRITICAL(&wifiMetricsMux);
 if(!wifiMetrics.data.connected){
  portENTER_CRITICAL(&failureMux);
  const auto record=failureStore.snapshot();
  if(!record.wifi.present || !record.wifi.active || strcmp(record.wifi.context.boot,metricsBoot))
   failureStore.disconnect(context,wifiMetrics.data.reason,lastLinkRssi.load(),nullptr);
  failureStore.retry(metricsBoot,millis(),result,nextWaitMs);
  portEXIT_CRITICAL(&failureMux);
 }
 portEXIT_CRITICAL(&wifiMetricsMux);
}
void noteAlpacaRequest(bool failed,bool timeout,uint32_t elapsedMs){
 portENTER_CRITICAL(&wifiMetricsMux);wifiMetrics.request(failed,timeout,elapsedMs);portEXIT_CRITICAL(&wifiMetricsMux);
}
void diagnosticWiFiAction(const char* action){
 const uint32_t at=millis();
 portENTER_CRITICAL(&wifiTraceMux);lastWiFiAction=action;lastWiFiActionAt=at;portEXIT_CRITICAL(&wifiTraceMux);
 diagnosticEvent("WIFI LOCAL action=%s status=%d mode=%d",action,int(WiFi.status()),int(WiFi.getMode()));
}
void noteWebLoop(){
 noteTaskStack(DiagnosticTask::Web);
 const uint32_t now=millis(),previous=webAt.exchange(now);
 if(previous && now-previous>=100)diagnosticLog("WEB LOOP gap_ms=%lu",(unsigned long)(now-previous));
}
void noteMotionLoop(){
 noteTaskStack(DiagnosticTask::Cover);
 const uint32_t now=millis(),previous=motionAt.exchange(now);
 if(previous && now-previous>=100)diagnosticLog("MOTION LOOP gap_ms=%lu",(unsigned long)(now-previous));
}
const char* firmwareId(){return identity;}
const char* resetReasonName(){
 switch(esp_reset_reason()) {
 case ESP_RST_POWERON:return "POWERON";case ESP_RST_EXT:return "EXTERNAL";
 case ESP_RST_SW:return "SOFTWARE";case ESP_RST_PANIC:return "PANIC";
 case ESP_RST_INT_WDT:return "INTERRUPT_WATCHDOG";case ESP_RST_TASK_WDT:return "TASK_WATCHDOG";
 case ESP_RST_WDT:return "WATCHDOG";case ESP_RST_DEEPSLEEP:return "DEEPSLEEP";
 case ESP_RST_BROWNOUT:return "BROWNOUT";case ESP_RST_SDIO:return "SDIO";
 default:return "UNKNOWN";
 }
}
void publishDiagnostic(bool shared,DebugLevel level,const char* format,va_list args){
 Entry serial;serial.at=millis();serial.epoch=logEpochSeconds();
 const int prefix=shared?snprintf(serial.message,sizeof(serial.message),"DEBUG [%s] ",debugLevelName(level)):0;
 const int size=vsnprintf(serial.message+prefix,sizeof(serial.message)-prefix,format,args);
 if(size>=int(sizeof(serial.message)-prefix))memcpy(serial.message+sizeof(serial.message)-4,"...",4);
 const bool shortened=size<0 || size>=int(shared?sizeof(DebugEntry::message):sizeof(serial.message));
 if(shortened)truncatedRecords.fetch_add(1);
 if(shared){
  DebugEntry entry;entry.at=serial.at;entry.epoch=serial.epoch;entry.level=level;entry.truncated=shortened;
  snprintf(entry.message,sizeof(entry.message),"%s",serial.message+prefix);
  if(shortened)memcpy(entry.message+sizeof(entry.message)-4,"...",4);
  if(debugEntries){portENTER_CRITICAL(&debugMux);debugEntries->append(entry);portEXIT_CRITICAL(&debugMux);}
 }else suppressedTrace.fetch_add(1);
 // Publishing never recurses and never waits for the UART or queue space.
 if(!logs || xQueueSend(logs,&serial,0)!=pdTRUE)dropped.fetch_add(1);
}
void diagnosticLog(const char* format,...) {
 va_list args;va_start(args,format);publishDiagnostic(false,DebugLevel::Info,format,args);va_end(args);
}
void diagnosticEvent(const char* format,...) {
 va_list args;va_start(args,format);publishDiagnostic(true,DebugLevel::Info,format,args);va_end(args);
}
void diagnosticEvent(DebugLevel level,const char* format,...) {
 va_list args;va_start(args,format);publishDiagnostic(true,level,format,args);va_end(args);
}
const char* debugLevelName(DebugLevel level){
 switch(level){case DebugLevel::Error:return "error";case DebugLevel::Warn:return "warn";default:return "info";}
}
bool debugLogAvailable(){return debugEntries && debugEntries->available();}
bool diagnosticsStartupHealthy(uint32_t now){return logs && debugLogAvailable() && loggerAt.load() && motionAt.load() && uint32_t(now-loggerAt.load())<1500 && uint32_t(now-motionAt.load())<1000;}
uint32_t diagnosticsMetricsEpoch(){return metricsEpoch.load();}
bool beginDiagnosticsWork(uint32_t epoch){
 if(!epoch || metricsEpoch.load()!=epoch)return false;
 optionalReaders.fetch_add(1);
 if(metricsEpoch.load()==epoch)return true;
 optionalReaders.fetch_sub(1);return false;
}
void endDiagnosticsWork(){optionalReaders.fetch_sub(1);}
void noteTaskStack(DiagnosticTask task){
 noteUsbMemoryStack(task);
 const uint32_t epoch=metricsEpoch.load();if(!epoch)return;
 const unsigned index=static_cast<unsigned>(task);if(index>=kDiagnosticTaskCount)return;
 auto& sample=taskStacks[index];const uint32_t now=millis();
 if(sample.epoch.load()==epoch && uint32_t(now-sample.sampledAt.load())<kStackSampleIntervalMs)return;
 optionalReaders.fetch_add(1);
 if(metricsEpoch.load()==epoch){
  // ESP-IDF 4.4 reports bytes. Never scale by word size.
  const uint32_t bytes=uxTaskGetStackHighWaterMark(nullptr);
  if(metricsEpoch.load()==epoch){sample.minimumFreeBytes.store(bytes);sample.sampledAt.store(now);sample.epoch.store(epoch);}
 }
 optionalReaders.fetch_sub(1);
}
RuntimeDiagnostics runtimeDiagnostics(){
 // Read cached values only. A normal status request never acquires metrics.
 portENTER_CRITICAL(&metricsMux);
 RuntimeDiagnostics result=metricsCache;result.viewers=metricsLeases.viewers();result.phase=metricsPhase;
 if(!result.viewers && result.phase==MetricsPhase::Active)result.phase=MetricsPhase::Stopping;
 if(result.viewers && result.phase==MetricsPhase::Off)result.phase=MetricsPhase::Starting;
 result.available=result.available && metricsEpoch.load()!=0 && result.phase==MetricsPhase::Active;
 portEXIT_CRITICAL(&metricsMux);return result;
}
const char* diagnosticsBootId(){return metricsBoot;}
bool requestMetrics(MetricsRequest request,uint32_t client,uint32_t generation,uint32_t observedUptime){
 const uint32_t now=millis();bool accepted=false;
 portENTER_CRITICAL(&metricsMux);
 if(metricsOwnerReady){
  // Preserve the zero-viewer transition even if a new subscribe arrives before
  // the owner services an expired final lease.
  metricsLeases.expire(now);
  if(!metricsLeases.viewers())metricsEpoch.store(0);
  switch(request){
  case MetricsRequest::Subscribe:accepted=metricsLeases.subscribe(now,client,generation,observedUptime);break;
  case MetricsRequest::Renew:accepted=metricsLeases.renew(now,client,generation);break;
  case MetricsRequest::Unsubscribe:accepted=metricsLeases.unsubscribe(now,client,generation);break;
  }
  if(!metricsLeases.viewers())metricsEpoch.store(0);
 }
 portEXIT_CRITICAL(&metricsMux);return accepted;
}
const char* diagnosticTaskName(DiagnosticTask task){
 switch(task){
 case DiagnosticTask::Web:return "web";
 case DiagnosticTask::Cover:return "cover";
 case DiagnosticTask::Alpaca:return "alpaca";
 case DiagnosticTask::Diagnostics:return "diagnostics";
 case DiagnosticTask::Ota:return "ota";
 default:return "unknown";
 }
}
void debugLog(const char* format,...) {
 va_list args;va_start(args,format);publishDiagnostic(true,DebugLevel::Info,format,args);va_end(args);
}
void debugLog(DebugLevel level,const char* format,...) {
 va_list args;va_start(args,format);publishDiagnostic(true,level,format,args);va_end(args);
}
DebugWindow debugLogWindow(){
 DebugWindow window;
 if(debugEntries){portENTER_CRITICAL(&debugMux);window=debugEntries->window();portEXIT_CRITICAL(&debugMux);}
 window.serialDropped=dropped.load();window.truncated=truncatedRecords.load();window.suppressedTrace=suppressedTrace.load();return window;
}
bool nextDebugEntry(uint32_t after,DebugEntry& output) {
 if(!debugEntries)return false;
 bool found=false;portENTER_CRITICAL(&debugMux);
 found=debugEntries->next(after,output);
 portEXIT_CRITICAL(&debugMux);return found;
}
bool nextDebugEntryInWindow(uint32_t after,uint32_t sequenceEpoch,DebugEntry& output){
 if(!debugEntries)return false;
 portENTER_CRITICAL(&debugMux);
 const bool found=debugEntries->window().sequenceEpoch==sequenceEpoch && debugEntries->next(after,output);
 portEXIT_CRITICAL(&debugMux);return found;
}
void beginDiagnostics(){
 beginUsbMemoryProbe();
 // Allocate once from heap: a large static array would exhaust ESP32 DRAM data space.
 debugEntries=new(std::nothrow) DebugBuffer;
 if(!debugLogAvailable())Serial.println("DEBUG log allocation failed; serial logging remains available");
 const auto* app=esp_ota_get_app_description();
 for(unsigned i=0;i<32;++i)snprintf(identity+2*i,3,"%02x",app->app_elf_sha256[i]);
 snprintf(metricsBoot,sizeof(metricsBoot),"%08lx%08lx%08lx%08lx",(unsigned long)esp_random(),(unsigned long)esp_random(),(unsigned long)esp_random(),(unsigned long)esp_random());
 const auto reset=esp_reset_reason();
 failureStore.begin(reset!=ESP_RST_POWERON && reset!=ESP_RST_BROWNOUT && reset!=ESP_RST_UNKNOWN,uint32_t(reset));
 logs=xQueueCreate(24,sizeof(Entry));
 diagnosticEvent("BOOT reset=%s elf_sha256=%s",resetReasonName(),identity);
 if(!debugLogAvailable()){
  noteRetainedFault("Event log allocation failed");
  diagnosticEvent(DebugLevel::Error,"ALLOC event ring unavailable; serial fallback only");
 }
 if(!logs || xTaskCreatePinnedToCore(logger,"diagnostics",4096,nullptr,1,nullptr,0)!=pdPASS) {
  noteRetainedFault("Diagnostics task or queue allocation failed");
  Serial.println("DIAGNOSTICS unavailable");diagnosticEvent(DebugLevel::Error,"ALLOC diagnostics task/queue unavailable");return;
 }
 portENTER_CRITICAL(&metricsMux);metricsOwnerReady=true;portEXIT_CRITICAL(&metricsMux);
 diagnosticLog("BUILD timestamp=%s %s reset_code=%d",__DATE__,__TIME__,int(esp_reset_reason()));
 diagnosticLog("FIRMWARE version=%s profile=%s",COVER_VERSION,COVER_BUILD_PROFILE);
 diagnosticLog("SOURCE commit=%s",COVER_SOURCE_COMMIT);
 WiFi.onEvent([](WiFiEvent_t event,WiFiEventInfo_t info){
  const char* action;uint32_t actionAt;
  portENTER_CRITICAL(&wifiTraceMux);action=lastWiFiAction;actionAt=lastWiFiActionAt;portEXIT_CRITICAL(&wifiTraceMux);
  const uint32_t now=millis();
  diagnosticEvent("WIFI EVENT name=%s id=%d status=%d local_action=%s action_age_ms=%lu",
   WiFi.eventName(event),int(event),int(WiFi.status()),action,(unsigned long)(now-actionAt));
  if(event==ARDUINO_EVENT_WIFI_STA_DISCONNECTED){
   const auto& d=info.wifi_sta_disconnected;
   portENTER_CRITICAL(&wifiMetricsMux);wifiMetrics.disconnected(now,d.reason);const bool wasOnline=wifiMetrics.data.everConnected;portEXIT_CRITICAL(&wifiMetricsMux);
   const bool plannedReboot=now-actionAt<5000 && (!strcmp(action,"ota-reboot") || !strcmp(action,"controller-reboot"));
   if(wasOnline && !plannedReboot){
    const auto previous=retainedFailureSummary();
    const auto context=failureContext(!previous.wifi.present || !previous.wifi.active || strcmp(previous.wifi.context.boot,metricsBoot));
    portENTER_CRITICAL(&failureMux);failureStore.disconnect(context,d.reason,d.rssi,d.bssid,action,now-actionAt);portEXIT_CRITICAL(&failureMux);
   }
   const uint32_t sampled=lastLinkAt.load(),associated=associatedAt.load(),eventAt=millis();
   diagnosticEvent(DebugLevel::Warn,"WIFI DISCONNECT reason=%u name=%s bssid=%02x:%02x:%02x:%02x:%02x:%02x event_rssi=%d last_rssi=%d sample_valid=%d sample_age_ms=%lu association_age_ms=%lu",
    unsigned(d.reason),WiFi.disconnectReasonName(static_cast<wifi_err_reason_t>(d.reason)),
    d.bssid[0],d.bssid[1],d.bssid[2],d.bssid[3],d.bssid[4],d.bssid[5],int(d.rssi),lastLinkRssi.load(),sampled!=0,
    (unsigned long)(sampled?eventAt-sampled:0),(unsigned long)(associated?eventAt-associated:0));
  }else if(event==ARDUINO_EVENT_WIFI_STA_CONNECTED){
   associatedAt.store(now);lastLinkAt.store(0);lastLinkRssi.store(0);
   const auto& c=info.wifi_sta_connected;
   diagnosticEvent("WIFI ASSOCIATED bssid=%02x:%02x:%02x:%02x:%02x:%02x channel=%u auth=%d",
    c.bssid[0],c.bssid[1],c.bssid[2],c.bssid[3],c.bssid[4],c.bssid[5],c.channel,int(c.authmode));
  }else if(event==ARDUINO_EVENT_WIFI_STA_AUTHMODE_CHANGE){
   diagnosticEvent("WIFI AUTH changed old=%d new=%d",int(info.wifi_sta_authmode_change.old_mode),int(info.wifi_sta_authmode_change.new_mode));
  }else if(event==ARDUINO_EVENT_WIFI_STA_GOT_IP){
   portENTER_CRITICAL(&wifiMetricsMux);wifiMetrics.gotIP(now);portEXIT_CRITICAL(&wifiMetricsMux);
   portENTER_CRITICAL(&failureMux);failureStore.recovered(metricsBoot,now);portEXIT_CRITICAL(&failureMux);
   diagnosticEvent("WIFI IP address=%s gateway=%s mask=%s changed=%d",IPAddress(info.got_ip.ip_info.ip.addr).toString().c_str(),
    IPAddress(info.got_ip.ip_info.gw.addr).toString().c_str(),IPAddress(info.got_ip.ip_info.netmask.addr).toString().c_str(),info.got_ip.ip_changed);
  }
 });
}
}
#endif
