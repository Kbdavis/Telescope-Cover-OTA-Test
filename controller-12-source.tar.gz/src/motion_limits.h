#pragma once
#include <stdint.h>
namespace cover {
// Encoder tolerance only; physical cover seating still requires validation.
constexpr uint16_t kEndpointTolerance = 10;
}
