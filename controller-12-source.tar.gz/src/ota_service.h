#pragma once
#ifdef COVER_WEB_CONTROL
#include <Arduino.h>
class WebServer;
namespace cover {
void beginOtaStartup();
void pollOtaStartup();
void registerOtaRoutes(WebServer& server);
void otaWebServiceReady(bool listening);
String otaStatusJson();
bool otaPinnedLayout();
}
#endif
