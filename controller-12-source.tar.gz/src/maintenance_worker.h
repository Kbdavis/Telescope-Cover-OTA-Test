#pragma once
#include <stdint.h>
#include "motion_limits.h"
namespace cover {
// Settings change application preferences, not servo calibration/configuration.
// Admission depends on actual stationary feedback, never a CLOSED state label.
template<class Servo> bool validateSettingsStationary(Servo& servo,bool moving,bool holding,uint16_t* stablePosition=nullptr){
 if(moving || holding)return false;
 bool torque=false;uint16_t a=0,b=0;
 if(!servo.readTorque(torque) || !servo.readPosition(a) || !servo.readPosition(b))return false;
 if(a>4095 || b>4095 || int(a)-int(b)<-3 || int(a)-int(b)>3)return false;
 if(stablePosition)*stablePosition=b;
 return true;
}
struct MaintenanceEvidence {
 bool ready=false,calibrated=false,dirty=true,moving=true,holding=true,fault=true,closed=false;
 uint16_t minimum=0,maximum=0,closedPosition=0;
};
// Called only by the servo worker. Failed reads never supply usable evidence;
// no register/torque write is performed by stationary OTA admission.
template<class Servo> bool validateOtaStationary(Servo& servo,const MaintenanceEvidence& evidence,bool admission=true,bool requireClosed=true,bool recovery=false){
 if(recovery){
#ifdef COVER_OTA_DEVELOPMENT
  // Recovery updates repair application/configuration faults. Do not require
  // a usable calibration or servo configuration merely to replace firmware.
  // Never release torque implicitly: demand fresh OFF and stationary raw reads.
  if(requireClosed || evidence.moving || evidence.holding)return false;
  uint16_t model=0,a=0,b=0;bool torque=true;
  if(!servo.readModel(model) || model!=777 || !servo.readTorque(torque) || torque ||
     !servo.readPosition(a) || !servo.readPosition(b) || a>4095 || b>4095)return false;
  return int(a)-int(b)>=-3 && int(a)-int(b)<=3;
#else
  return false;
#endif
 }
 if(!evidence.ready || !evidence.calibrated || evidence.dirty || evidence.moving || evidence.holding ||
    evidence.fault || (admission && requireClosed && (!evidence.closed || evidence.closedPosition<evidence.minimum || evidence.closedPosition>evidence.maximum)) || evidence.minimum>=evidence.maximum || evidence.maximum>4095)return false;
 uint16_t model=0,a=0,b=0;bool torque=true;
 if(!servo.readModel(model) || model!=777 || !servo.validateConfiguration() || !servo.readTorque(torque) || (!admission && torque) ||
    !servo.readPosition(a) || !servo.readPosition(b))return false;
 const int delta=int(a)-int(b);
 const int ca=int(a)-int(evidence.closedPosition),cb=int(b)-int(evidence.closedPosition);
 if(admission && requireClosed && (ca < -int(kEndpointTolerance) || ca > int(kEndpointTolerance) || cb < -int(kEndpointTolerance) || cb > int(kEndpointTolerance)))return false;
 return delta>=-3 && delta<=3 && a>=evidence.minimum && a<=evidence.maximum && b>=evidence.minimum && b<=evidence.maximum;
}
}
