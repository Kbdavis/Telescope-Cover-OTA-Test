#include "servo_controller.h"
#include "travel_model.h"
#include "servo_factory_profile.h"
#include <string.h>
#ifdef COVER_WEB_CONTROL
#include "diagnostics.h"
#endif

namespace cover {
const char* servoErrorName(ServoError error){
 switch(error){
  case ServoError::None:return "none";case ServoError::InvalidArgument:return "invalid_argument";
  case ServoError::Timeout:return "timeout";case ServoError::WriteFailed:return "write_failed";
  case ServoError::InvalidPacket:return "invalid_packet";case ServoError::DeviceError:return "device_error";
  case ServoError::InvalidConfiguration:return "invalid_configuration";case ServoError::InvalidPosition:return "invalid_position";
  case ServoError::TorqueDisabled:return "torque_disabled";
 }return "unknown";
}
namespace {
constexpr uint8_t kPing = 1, kRead = 2, kWrite = 3;
constexpr uint8_t kId = 5, kTorque = 40, kAcceleration = 41, kPosition = 56;
uint16_t word(const uint8_t* p) {
  return static_cast<uint16_t>(p[0]) | (static_cast<uint16_t>(p[1]) << 8);
}
int16_t signedMagnitude(uint16_t raw, uint8_t signBit) {
  const uint16_t mask = static_cast<uint16_t>(1U << signBit);
  const int16_t magnitude = raw & (mask - 1);
  return (raw & mask) ? -magnitude : magnitude;
}
}

ServoResult ServoController::exchange(uint8_t instruction, const uint8_t* parameters,
                                     uint8_t count, uint8_t* output, uint8_t outputCount) {
 ++diagnostics_.exchanges;
 const auto result=exchangePacket(instruction,parameters,count,output,outputCount);
 lastResult_=result;
 if(result){diagnostics_.hasSuccess=true;diagnostics_.lastSuccessAt=millis();}
 else {
  ++diagnostics_.failedExchanges;diagnostics_.hasFailure=true;diagnostics_.lastFailureAt=millis();
  diagnostics_.lastFailure=result;diagnostics_.failureInstruction=instruction;
  diagnostics_.failureAddress=count?parameters[0]:0;
 }
 return result;
}
ServoResult ServoController::exchangePacket(uint8_t instruction,const uint8_t* parameters,
                                          uint8_t count,uint8_t* output,uint8_t outputCount){
#ifdef COVER_SERVO_READ_ONLY
  if (instruction != kPing && instruction != kRead)
    return {ServoError::InvalidArgument};
#endif
  if (id_ == 0 || id_ >= 254 || count > 8 || outputCount > 29)
    return {ServoError::InvalidArgument};
  // Bounded stale-input drain; continuous noise cannot trap the controller.
  for (unsigned i = 0; i < 128 && bus_.available(); ++i) bus_.read();
  if (bus_.available()) return {ServoError::InvalidPacket};
  uint8_t request[14] = {255, 255, id_, static_cast<uint8_t>(count + 2), instruction};
  uint8_t sum = id_ + count + 2 + instruction;
  for (uint8_t i = 0; i < count; ++i) {
    request[5 + i] = parameters[i];
    sum += parameters[i];
  }
  request[5 + count] = static_cast<uint8_t>(~sum);
  if (bus_.write(request, count + 6) != static_cast<size_t>(count + 6))
    return {ServoError::WriteFailed};
  // No flush(): some Stream implementations can block without a deadline.
  const uint32_t start = millis();
  uint8_t response[35] = {};
  uint8_t used = 0;
  const uint8_t expected = outputCount + 6;
  while (static_cast<uint32_t>(millis() - start) < kTimeoutMs) {
    if (!bus_.available()) { yield(); continue; }
    const int value = bus_.read();
    if (value < 0) continue;
    const uint8_t byte = static_cast<uint8_t>(value);
    if (used < 2) {
      if (byte == 255) response[used++] = byte;
      else used = 0;
      continue;
    }
    response[used++] = byte;
    if (used == 3 && byte != id_) return {ServoError::InvalidPacket};
    if (used == 4 && byte != outputCount + 2) return {ServoError::InvalidPacket};
    if (used != expected) continue;
    uint8_t checksum = 0;
    for (uint8_t i = 2; i < expected; ++i) checksum += response[i];
    if (checksum != 255) return {ServoError::InvalidPacket};
    if (response[4]) return {ServoError::DeviceError, response[4]};
    if (outputCount) memcpy(output, response + 5, outputCount);
    return {};
  }
  return {ServoError::Timeout};
}

ServoResult ServoController::read(uint8_t address, uint8_t count, uint8_t* output) {
  const uint8_t parameters[] = {address, count};
  ServoResult result;
  for (uint8_t attempt = 0; attempt < kReadAttempts; ++attempt) {
    if (attempt) ++retries_;
    result = exchange(kRead, parameters, 2, output, count);
    if (result || result.error == ServoError::DeviceError ||
        result.error == ServoError::InvalidArgument) break;
  }
  if(!result)++diagnostics_.failedReads;
#ifdef COVER_WEB_CONTROL
  if(!result)diagnosticLog("SERVO READ failed reg=%u bytes=%u error=%u device_status=0x%02x retries=%lu",address,count,unsigned(result.error),result.deviceStatus,(unsigned long)retries_);
#endif
  return result;
}

ServoResult ServoController::ping() {
  ServoResult result;
  for (uint8_t attempt = 0; attempt < kReadAttempts; ++attempt) {
    if (attempt) ++retries_;
    result = exchange(kPing, nullptr, 0, nullptr, 0);
    if (result || result.error == ServoError::DeviceError ||
        result.error == ServoError::InvalidArgument) break;
  }
  return result;
}

ServoResult ServoController::readModel(uint16_t& output) {
  uint8_t bytes[2];
  auto result = read(3, 2, bytes);
  if (result) {output = word(bytes);diagnostics_.model=output;diagnostics_.modelValid=true;diagnostics_.modelAt=millis();}
  return result;
}

ServoResult ServoController::readConfiguration(ServoConfiguration& output) {
  uint8_t bytes[29];  // ID through operating mode, registers 5..33.
  auto result = read(kId, sizeof(bytes), bytes);
  if (!result) return result;
  ServoConfiguration value;
  value.id = bytes[0]; value.minimum = word(bytes + 4);
  value.maximum = word(bytes + 6); value.phase = bytes[13];
  value.resolution = bytes[25]; value.offset = word(bytes + 26);
  value.mode = bytes[28];
  output = value;
  diagnostics_.configuration=value;diagnostics_.configurationRead=true;diagnostics_.configurationAt=millis();
  return {};
}

ServoResult ServoController::readConfigurationSnapshot(uint8_t (&output)[40]) {
  uint8_t bytes[40];
  auto result=read(0,29,bytes);
  if(!result)return result;
  result=read(29,11,bytes+29);
  if(result){memcpy(output,bytes,sizeof(bytes));memcpy(diagnostics_.snapshot,bytes,sizeof(bytes));diagnostics_.snapshotValid=true;diagnostics_.snapshotAt=millis();}
  return result;
}

ServoResult ServoController::validateConfiguration() {
  ServoConfiguration config;
  return validateConfiguration(config);
}

ServoResult ServoController::validateConfiguration(ServoConfiguration& config) {
 diagnostics_.validationAttempted=true;diagnostics_.validationPassed=false;
 diagnostics_.lockValid=false;
 const auto result=checkConfiguration(config);
 diagnostics_.validationAt=millis();diagnostics_.validationResult=result;diagnostics_.validationPassed=static_cast<bool>(result);
 return result;
}
ServoResult ServoController::checkConfiguration(ServoConfiguration& config){
  rolloverSupported_=false;
#ifdef COVER_MULTITURN
  multiTurnActive_=false;
#endif
#ifdef COVER_MULTITURN_STARTUP
  if(startupWriteAttempted_ && !startupPreparationResult_)return {ServoError::InvalidConfiguration};
#endif
  auto result = readConfiguration(config);
  if (!result) return result;
#ifdef COVER_MULTITURN
  if(config.mode==0 && config.minimum==0 && config.maximum==0 && config.phase==28 && config.offset==85){
    uint8_t snapshot[40],locked=0;
    result=readConfigurationSnapshot(snapshot);if(!result)return result;
    result=read(55,1,&locked);if(!result)return result;
    diagnostics_.lockValid=true;diagnostics_.lock=locked;
    if(locked==1 && matchesMultiTurnProbeProfile(snapshot)){
      multiTurnActive_=rolloverSupported_=true;return {};
    }
    return {ServoError::InvalidConfiguration};
  }
#endif
#ifdef COVER_MULTITURN
  if(updateInspectionOnly_)return {ServoError::InvalidConfiguration};
#endif
#ifdef COVER_BROWSER_OTA
  // This release's saved travel and signed update policy require native goals.
  // A factory profile must not silently fall back to single-turn control.
  return {ServoError::InvalidConfiguration};
#endif
#ifdef COVER_MULTITURN_STARTUP
  // Once accepted, losing the RAM profile is a fault, not a silent fallback to
  // factory single-turn control with an existing circular calibration.
  if(startupProfileRequired_ || !startupInspection_)return {ServoError::InvalidConfiguration};
#endif
#ifndef COVER_FIXED_REFERENCE
  if (config.id == id_ && config.mode == 0 && config.minimum == 0 &&
      config.maximum == 4095 && config.resolution == 1 &&
      config.phase == 12 && config.offset == 85) {
    uint8_t snapshot[40];
    result = readConfigurationSnapshot(snapshot);
    if (!result) return result;
    if (matchesCommissionedFactoryProfile(snapshot)) {
#ifdef COVER_ROLLOVER_BENCH
      // Supervised detached-shaft commissioning build only. No EEPROM writes.
      rolloverSupported_=true;
#endif
      return {};
    }
  }
#endif
#if defined(COVER_REFERENCE_PROBE) || defined(COVER_FIXED_REFERENCE)
  if(config.phase==12 && config.offset==1328){
    uint8_t snapshot[40],locked=0;
    result=readConfigurationSnapshot(snapshot);if(!result)return result;
    result=read(55,1,&locked);if(!result)return result;
    diagnostics_.lockValid=true;diagnostics_.lock=locked;
    if(locked==1 && matchesReferenceProbeProfile(snapshot))return {};
  }
#endif
#ifdef COVER_FIXED_REFERENCE
  // A servo power cycle restores offset 85. Never use reference-1328 endpoints
  // under that baseline; explicit recovery must reapply the approved RAM shift.
  return {ServoError::InvalidConfiguration};
#endif
  if (config.id != id_ || config.mode != 0 || config.minimum != 0 ||
      config.maximum != 4095 || config.phase != 0 || config.resolution != 1 ||
      config.offset != 0) {
#ifdef COVER_WEB_CONTROL
    diagnosticEvent(DebugLevel::Error,
      "SERVO CONFIG invalid id=%u mode=%u min=%u max=%u phase=%u resolution=%u offset=%u",
      config.id,config.mode,config.minimum,config.maximum,config.phase,
      config.resolution,config.offset);
    diagnosticLog("SERVO CONFIG requires legacy phase=0 offset=0 or exact commissioned factory profile; id=%u mode=0 min=0 max=4095 resolution=1",id_);
#endif
    return {ServoError::InvalidConfiguration};
  }
  return {};
}

ServoResult ServoController::readPosition(uint16_t& output) {
  uint8_t bytes[2];
  auto result = read(kPosition, 2, bytes);
  if (!result) return result;
  uint16_t value = word(bytes);
#ifdef COVER_MULTITURN
  result=decodeNativePosition(value,value);if(!result)return result;
#endif
  if (value > st3215::kMaxPosition) {++diagnostics_.rejectedPositions;return {ServoError::InvalidPosition};}
  output = value;
  diagnostics_.position=value;diagnostics_.positionValid=true;diagnostics_.positionAt=millis();
  return {};
}

ServoResult ServoController::readTelemetry(ServoTelemetry& output) {
  uint8_t bytes[15];  // Position through current, registers 56..70.
  auto result = read(kPosition, sizeof(bytes), bytes);
  if (!result) return result;
  ServoTelemetry value;
  value.position = word(bytes);
#ifdef COVER_MULTITURN
  if(bytes[10]>1 || word(bytes+4)>2047)return {ServoError::InvalidPacket};
  result=decodeNativePosition(value.position,value.position);if(!result)return result;
#endif
  if (value.position > st3215::kMaxPosition) {++diagnostics_.rejectedPositions;return {ServoError::InvalidPosition};}
  if (bytes[10] > 1 || word(bytes + 4) > 2047) return {ServoError::InvalidPacket};
  value.speedRaw = signedMagnitude(word(bytes + 2), 15);
  value.relativeLoad = signedMagnitude(word(bytes + 4), 10);
  value.voltageDecivolts = bytes[6]; value.temperatureC = bytes[7];
  value.moving = bytes[10] != 0;
  value.targetPositionRaw = word(bytes + 11);
  value.currentRaw = signedMagnitude(word(bytes + 13), 15);
  output = value;
  diagnostics_.telemetry=value;diagnostics_.telemetryValid=true;diagnostics_.telemetryAt=millis();
  return {};
}

ServoResult ServoController::readGoal(ServoGoalReadback& output) {
 uint8_t bytes[9]; // Raw control registers 41..49; no writes or position staging.
 auto result=read(kAcceleration,sizeof(bytes),bytes);
 if(!result)return result;
 ServoGoalReadback value;value.acceleration=bytes[0];value.positionRaw=word(bytes+1);
 value.register44Raw=word(bytes+3);value.speedRaw=word(bytes+5);
 value.torqueLimitRaw=word(bytes+7);
 output=value;diagnostics_.goal=value;diagnostics_.goalAt=millis();diagnostics_.goalValid=true;
 return {};
}

ServoResult ServoController::readTorque(bool& enabled) {
  uint8_t value;
  auto result = read(kTorque, 1, &value);
  if (!result) return result;
  if (value > 1) return {ServoError::InvalidPacket};
  enabled = value == 1;
  diagnostics_.torque=enabled;diagnostics_.torqueValid=true;diagnostics_.torqueAt=millis();
  return {};
}

ServoResult ServoController::releaseTorque() {
  const uint8_t parameters[] = {kTorque, 0};
  auto result=exchange(kWrite, parameters, sizeof(parameters), nullptr, 0);
#ifdef COVER_WEB_CONTROL
  diagnosticLog("SERVO TORQUE OFF result=%u device_status=0x%02x",unsigned(result.error),result.deviceStatus);
#endif
  return result;
}

ServoResult ServoController::writeGoal(uint16_t target, uint16_t speed, uint8_t acceleration) {
#ifdef COVER_MULTITURN
  if(multiTurnActive_){
    if(!nativePositionValid_ || target>4095)return {ServoError::InvalidPosition};
    return writeNativeGoal(nativePosition_+encoderDelta(wrapPosition(nativePosition_),target),speed,acceleration);
  }
#endif
  const uint8_t parameters[] = {kAcceleration, acceleration,
    static_cast<uint8_t>(target), static_cast<uint8_t>(target >> 8), 0, 0,
    static_cast<uint8_t>(speed), static_cast<uint8_t>(speed >> 8)};
  return exchange(kWrite, parameters, sizeof(parameters), nullptr, 0);
}

ServoResult ServoController::enableTorque() {
#ifdef COVER_WEB_CONTROL
  ServoTelemetry before;auto telemetry=readTelemetry(before);
  if(telemetry)diagnosticLog("SERVO PRE TORQUE pos=%u voltage_dV=%u temp_C=%u load_relative=%d current_raw=%d",before.position,before.voltageDecivolts,before.temperatureC,before.relativeLoad,before.currentRaw);
  else diagnosticLog("SERVO PRE TORQUE telemetry error=%u device_status=0x%02x",unsigned(telemetry.error),telemetry.deviceStatus);
#endif
  auto result = validateConfiguration();
  if (!result) return result;
  bool enabled;
  result = readTorque(enabled);
  if (!result || enabled) return result;
  uint16_t position;
  result = readPosition(position);
  if (!result) return result;
  uint16_t confirm;
  result = readPosition(confirm);
  if (!result) return result;
  // A single valid-looking zero must not become a staged goal across rollover.
  if (abs(encoderDelta(position,confirm))>3) return {ServoError::InvalidPosition};
  result = writeGoal(confirm, 100, 10);
  if (!result) return result;
  const uint8_t parameters[] = {kTorque, 1};
  auto enabledResult=exchange(kWrite, parameters, sizeof(parameters), nullptr, 0);
#ifdef COVER_WEB_CONTROL
  diagnosticLog("SERVO TORQUE ON hold_position=%u result=%u device_status=0x%02x",position,unsigned(enabledResult.error),enabledResult.deviceStatus);
#endif
  return enabledResult;
}

ServoResult ServoController::moveTo(uint16_t target, uint16_t speed, uint8_t acceleration,
                                   uint16_t mechanicalMinimum, uint16_t mechanicalMaximum) {
  // Reject zero/unlimited speed and unbounded acceleration in this first version.
  if (mechanicalMinimum >= mechanicalMaximum || mechanicalMaximum > 4095 ||
      target < mechanicalMinimum || target > mechanicalMaximum ||
      speed == 0 || speed > 4095 || acceleration == 0 || acceleration > 254)
    return {ServoError::InvalidArgument};
  auto result = validateConfiguration();
  if (!result) return result;
  uint16_t position;
  result = readPosition(position);
  if (!result) return result;
  if (position < mechanicalMinimum || position > mechanicalMaximum || !supportedDirectPath(position,target))
    return {ServoError::InvalidPosition};
  bool enabled;
  result = readTorque(enabled);
  if (!result) return result;
  if (!enabled) return {ServoError::TorqueDisabled};
  return writeGoal(target, speed, acceleration);
}
}  // namespace cover

namespace cover {
ServoResult ServoController::moveAcrossBoundary(uint16_t target,uint16_t speed,uint8_t acceleration,const TravelArc& arc) {
 if(!arc.circular || !arc.valid() || !arc.contains(target) || !speed || speed>1600 || !acceleration || acceleration>100)return {ServoError::InvalidArgument};
 auto result=validateConfiguration();if(!result)return result;
 if(!rolloverSupported())return {ServoError::InvalidConfiguration};
 uint16_t position=0;result=readPosition(position);if(!result)return result;
 #ifdef COVER_ROLLOVER_BENCH
 if(abs(arc.coordinate(position)-arc.coordinate(target))>100)return {ServoError::InvalidArgument};
 #endif
 #if defined(COVER_ROLLOVER_BENCH) || defined(COVER_MULTITURN)
 if(speed>100 || acceleration>10 || abs(arc.coordinate(position)-arc.coordinate(target))>maximumJogStep())return {ServoError::InvalidArgument};
#endif
 if(!arc.contains(position) || abs(arc.coordinate(position)-arc.coordinate(target))>=2048)return {ServoError::InvalidPosition};
 bool enabled=false;result=readTorque(enabled);if(!result)return result;
 if(!enabled)return {ServoError::TorqueDisabled};
#ifdef COVER_MULTITURN
 if(multiTurnActive_)return writeNativeGoal(nativePosition_+arc.direction*(arc.coordinate(target)-arc.coordinate(position)),speed,acceleration);
#endif
 return writeGoal(target,speed,acceleration);
}
}

#ifdef COVER_MULTITURN
namespace cover {
ServoResult ServoController::inspectMultiTurnStartup(){
 // Set before the first read, so an unsuccessful inspection cannot fall back
 // to factory coordinates through a subsequent Recheck or torque command.
 updateInspectionOnly_=true;
 uint16_t model=0;auto result=readModel(model);if(!result)return result;
 if(model!=777)return {ServoError::InvalidConfiguration};
 result=validateConfiguration();if(!result)return result;
 if(!rolloverSupported_)return {ServoError::InvalidConfiguration};
 bool torque=true;result=readTorque(torque);if(!result)return result;
 if(torque)return {ServoError::TorqueDisabled};
 ServoTelemetry before,after;
 result=readTelemetry(before);if(!result)return result;
 if(before.moving || before.speedRaw!=0 || !nativePositionValid_)return {ServoError::InvalidPosition};
 const int firstNative=nativePosition_;
 const uint32_t started=millis();
 while(uint32_t(millis()-started)<100)yield();
 result=readTelemetry(after);if(!result)return result;
 if(after.moving || after.speedRaw!=0 || !nativePositionValid_ || abs(nativePosition_-firstNative)>3)
  return {ServoError::InvalidPosition};
 result=readTorque(torque);if(!result)return result;
 return torque?ServoResult{ServoError::TorqueDisabled}:ServoResult{};
}
#ifdef COVER_MULTITURN_STARTUP
ServoResult ServoController::prepareMultiTurnStartup(ReferenceProbeEvidence& evidence){
 // An update startup can never authorize RAM setup later in the same boot.
 if(updateInspectionOnly_)return {ServoError::InvalidConfiguration};
 // Never repeat a configuration write in this driver lifetime, including after
 // an uncertain acknowledgement, ignored write or a subsequent servo reset.
 if(startupWriteAttempted_){
  if(!startupPreparationResult_)return startupPreparationResult_;
  auto result=validateConfiguration();if(!result)return result;
  return rolloverSupported_?ServoResult{}:ServoResult{ServoError::InvalidConfiguration};
 }
 evidence=ReferenceProbeEvidence{};
 uint16_t model=0;auto result=readModel(model);if(!result)return result;
 if(model!=777)return {ServoError::InvalidConfiguration};
 startupInspection_=true;
 result=validateConfiguration();
 startupInspection_=false;
 if(!result)return result;
 const bool alreadyActive=rolloverSupported_;
 // All setup is torque-OFF. A retained, already configured servo may stay
 // energized across an explicitly permitted OTA; this branch performs reads only.
 bool torque=true;result=readTorque(torque);if(!result)return result;
 if(torque && !alreadyActive)return {ServoError::TorqueDisabled};
 ServoTelemetry before,after;
 result=readTelemetry(before);if(!result)return result;
 if(before.moving || before.speedRaw!=0)return {ServoError::InvalidPosition};
 const uint32_t started=millis();
 while(uint32_t(millis()-started)<100)yield();
 result=readTelemetry(after);if(!result)return result;
 if(after.moving || after.speedRaw!=0 || abs(encoderDelta(before.position,after.position))>3)
  return {ServoError::InvalidPosition};
 // On a warm boot preserve native turns and perform no configuration writes.
 if(alreadyActive){startupProfileRequired_=true;return {};}
 // configureLockedMultiTurn rechecks the exact factory snapshot, lock, torque and
 // feedback immediately before its two fixed writes, and verifies readback.
 result=configureLockedMultiTurn(false,evidence);
 if(evidence.writeAttempted){
  startupWriteAttempted_=true;
  startupPreparationResult_=result;
 }
 if(!result)return result;
 startupProfileRequired_=true;
 result=validateConfiguration();
 if(result && !rolloverSupported_)result={ServoError::InvalidConfiguration};
 bool enabled=true;
 if(result)result=readTorque(enabled);
 if(result && enabled)result={ServoError::TorqueDisabled};
 // Compare native feedback as well as wrapped feedback: an unexpected complete
 // turn must not be accepted merely because it has the same display angle.
 if(result)result=readTelemetry(after);
 if(result && (after.moving || after.speedRaw!=0 ||
    abs(nativePosition_-int(evidence.positionBefore))>3))result={ServoError::InvalidPosition};
 startupPreparationResult_=result;
 return result;
}
#endif
ServoResult ServoController::decodeNativePosition(uint16_t encoded,uint16_t& wrapped){
 if(!multiTurnActive_)return encoded<=4095?ServoResult{}:ServoResult{ServoError::InvalidPosition};
 const int native=signedMagnitude(encoded,15);
 // Commissioning only: never admit arbitrary multi-revolution motion.
 if(abs(native)>8191)return {ServoError::InvalidPosition};
 // Equal wrapped readings can still differ by a complete revolution. Never
 // let a bogus native zero become a staged hold goal one turn away.
 if(nativePositionValid_ && abs(native-nativePosition_)>=2048)return {ServoError::InvalidPosition};
 nativePosition_=native;nativePositionValid_=true;wrapped=wrapPosition(native);
 diagnostics_.nativePosition=native;diagnostics_.nativePositionValid=true;diagnostics_.nativePositionAt=millis();return {};
}
ServoResult ServoController::moveCalibratedEndpoint(uint16_t target,uint16_t speed,uint8_t acceleration,const TravelArc& arc){
 if(!arc.valid() || (target!=arc.closedRaw && target!=arc.rawTarget(arc.length)))return {ServoError::InvalidArgument};
 auto result=validateConfiguration();if(!result)return result;
 if(!multiTurnActive_)return ServoMotion::moveCalibratedEndpoint(target,speed,acceleration,arc);
 uint16_t position=0;result=readPosition(position);if(!result)return result;
 if(!arc.endpointStartAllowed(position))return {ServoError::InvalidPosition};
 const int delta=arc.direction*(arc.coordinate(target,25)-arc.coordinate(position,25));
 if(abs(delta)>=2048)return {ServoError::InvalidPosition};
 bool enabled=false;result=readTorque(enabled);if(!result)return result;
 if(!enabled)return {ServoError::TorqueDisabled};
 // Explicit taught endpoints may span the arc; jogs retain the 500-count cap.
 // Allow bounded inward recovery from up to 25 counts beyond an endpoint.
 return writeNativeGoal(nativePosition_+delta,speed,acceleration,arc.length<2023?arc.length+25:2047);
}
ServoResult ServoController::writeNativeGoal(int target,uint16_t speed,uint8_t acceleration,uint16_t maximumDistance){
 if(!multiTurnActive_ || !nativePositionValid_ || abs(target)>8191 ||
    maximumDistance>=2048 || abs(target-nativePosition_)>maximumDistance || !speed || speed>100 || !acceleration || acceleration>10)
  return {ServoError::InvalidArgument};
 const uint16_t encoded=target<0?uint16_t(-target)|0x8000:uint16_t(target);
 const uint8_t parameters[]={41,acceleration,uint8_t(encoded),uint8_t(encoded>>8),0,0,uint8_t(speed),uint8_t(speed>>8)};
 return exchange(kWrite,parameters,sizeof(parameters),nullptr,0);
}
ServoResult ServoController::configureLockedMultiTurn(bool restore,ReferenceProbeEvidence& e){
#ifdef COVER_MULTITURN_USB
 if(restore)return {ServoError::InvalidArgument};
#endif
 e=ReferenceProbeEvidence{};nativePositionValid_=false;
 uint8_t snapshot[40],lock=0;auto result=readConfigurationSnapshot(snapshot);if(!result)return result;
 memcpy(e.before,snapshot,40);e.beforeValid=true;
 uint8_t original[40];memcpy(original,snapshot,40);original[11]=255;original[12]=15;original[18]=12;
 const bool knownLimits=(snapshot[11]==0 && snapshot[12]==0)||(snapshot[11]==255 && snapshot[12]==15);
 const bool knownPhase=snapshot[18]==12 || snapshot[18]==28;
 // Permit exact rollback from either known intermediate state after a lost
 // acknowledgement, but never repair unrelated configuration corruption.
 if(restore?(!knownLimits || !knownPhase || !matchesCommissionedFactoryProfile(original)):
            !matchesCommissionedFactoryProfile(snapshot))return {ServoError::InvalidConfiguration};
 result=read(55,1,&lock);if(!result)return result;
 if(lock!=1)return {ServoError::InvalidConfiguration};
 e.lockConfirmed=true;
 bool torque=true;result=readTorque(torque);if(!result)return result;
 if(torque)return {ServoError::InvalidConfiguration};
 const bool fullFeedback=snapshot[18]==28;
 auto readBefore=[&](uint16_t& out){
  uint8_t bytes[2];auto r=read(56,2,bytes);if(!r)return r;
  const int native=fullFeedback?signedMagnitude(word(bytes),15):word(bytes);
  if(abs(native)>(fullFeedback?8191:4095))return ServoResult{ServoError::InvalidPosition};
  out=wrapPosition(native);return ServoResult{};
 };
 uint16_t a=0,b=0;result=readBefore(a);if(!result)return result;
 result=readBefore(b);if(!result)return result;
 if(abs(encoderDelta(a,b))>3)return {ServoError::InvalidPosition};
 e.positionBefore=b;e.positionBeforeValid=true;
 // Fixed approved values only. No unlock and no retry of either write.
 const uint8_t limit[]={11,uint8_t(restore?255:0),uint8_t(restore?15:0)};
 e.writeAttempted=true;result=exchange(kWrite,limit,sizeof(limit),nullptr,0);
 if(!result)return result; // A partial/uncertain application remains faulted.
 const uint8_t phase[]={18,uint8_t(restore?12:28)};
 result=exchange(kWrite,phase,sizeof(phase),nullptr,0);if(!result)return result;
 result=readConfigurationSnapshot(snapshot);if(!result)return result;
 memcpy(e.after,snapshot,40);e.afterValid=true;
 result=read(55,1,&lock);if(!result)return result;e.lockConfirmed=lock==1;
 if(!e.lockConfirmed || !(restore?matchesCommissionedFactoryProfile(snapshot):matchesMultiTurnProbeProfile(snapshot)))return {ServoError::InvalidConfiguration};
 multiTurnActive_=!restore;rolloverSupported_=!restore;
 result=readPosition(e.positionAfter);e.positionAfterValid=bool(result);
 if(!result)return result;
 if(abs(encoderDelta(e.positionBefore,e.positionAfter))>3)return {ServoError::InvalidPosition};
 return {};
}
}
#endif

#if defined(COVER_REFERENCE_PROBE) || defined(COVER_FIXED_REFERENCE)
namespace cover {
ServoResult ServoController::probeLockedReference(bool restoreFactory,ReferenceProbeEvidence& evidence) {
 evidence=ReferenceProbeEvidence{};
 uint8_t snapshot[40];auto result=readConfigurationSnapshot(snapshot);if(!result)return result;
 memcpy(evidence.before,snapshot,40);evidence.beforeValid=true;
 if(!(restoreFactory?matchesReferenceProbeProfile(snapshot):matchesCommissionedFactoryProfile(snapshot)))return {ServoError::InvalidConfiguration};
 uint8_t locked=0;result=read(55,1,&locked);if(!result)return result;
 if(locked!=1)return {ServoError::InvalidConfiguration};
 evidence.lockConfirmed=true;
 bool torque=true;result=readTorque(torque);if(!result)return result;
 if(torque)return {ServoError::InvalidConfiguration};
 uint16_t a=0,b=0;result=readPosition(a);if(!result)return result;
 result=readPosition(b);if(!result)return result;
 if(abs(encoderDelta(a,b))>3)return {ServoError::InvalidPosition};
 evidence.positionBefore=b;evidence.positionBeforeValid=true;
 // EEPROM lock remains 1. Never unlock, retry an uncertain write, enable torque,
 // or send a goal. The experiment fails if firmware ignores locked RAM writes.
 const uint16_t offset=restoreFactory?85:1328;
 const uint8_t parameters[]={31,uint8_t(offset),uint8_t(offset>>8)};
 evidence.writeAttempted=true;
 const auto writeResult=exchange(kWrite,parameters,sizeof(parameters),nullptr,0);
 result=readConfigurationSnapshot(snapshot);
 if(result){memcpy(evidence.after,snapshot,40);evidence.afterValid=true;}
 uint8_t afterLock=0;const auto lockResult=read(55,1,&afterLock);
 evidence.lockConfirmed=lockResult && afterLock==1;
 const auto positionResult=readPosition(evidence.positionAfter);evidence.positionAfterValid=bool(positionResult);
 if(!writeResult)return writeResult;
 if(!result)return result;
 if(!lockResult)return lockResult;
 if(!positionResult)return positionResult;
 if(!evidence.lockConfirmed || !(restoreFactory?matchesCommissionedFactoryProfile(snapshot):matchesReferenceProbeProfile(snapshot)))return {ServoError::InvalidConfiguration};
 // Predicted mapping is a hypothesis checked with torque OFF, before any motion.
 const int expected=wrapPosition(int(b)+(restoreFactory?1243:-1243));
 if(abs(encoderDelta(expected,evidence.positionAfter))>3)return {ServoError::InvalidPosition};
 return {};
}
}
#endif

#ifdef COVER_FIXED_REFERENCE
namespace cover {
ServoResult ServoController::prepareFixedReference(){
 uint8_t snapshot[40],locked=0;auto result=readConfigurationSnapshot(snapshot);if(!result)return result;
 result=read(55,1,&locked);if(!result)return result;
 if(locked!=1)return {ServoError::InvalidConfiguration};
 if(matchesReferenceProbeProfile(snapshot))return {}; // Already applied; never restage a goal.
 if(!matchesCommissionedFactoryProfile(snapshot))return {ServoError::InvalidConfiguration};
 ReferenceProbeEvidence evidence;return probeLockedReference(false,evidence);
}
}
#endif
