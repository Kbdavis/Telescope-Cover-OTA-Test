#pragma once
#ifdef COVER_BROWSER_OTA
#include <Arduino.h>
#include "ota_protocol.h"
namespace cover {
class BoundedWebServer;
void beginBrowserOta();
bool browserOtaReady();
void registerBrowserOtaRoutes(BoundedWebServer& web);
String browserOtaStatusJson();
bool browserOtaSettingsMatch();
bool browserOtaOperatorSecuredStartup(const OtaRecord& record);
// Owned by the established startup/journal service.
bool otaBrowserAccepted();
bool otaBrowserSaveRecord(const OtaRecord& record);
}
#endif
