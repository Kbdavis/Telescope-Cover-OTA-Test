#pragma once
#include "servo_controller.h"
#include "servo_factory_profile.h"
namespace cover {
// A passive freshness check, never update admission or permission to write.
inline bool updateNativeProfileVerified(const ServoDiagnostics& d,uint32_t now){
#ifdef COVER_MULTITURN
 constexpr uint32_t freshnessMs=1500;
 return d.modelValid && d.model==777 && d.validationAttempted && d.validationPassed &&
  d.snapshotValid && d.lockValid && d.lock==1 && d.nativePositionValid &&
  uint32_t(now-d.modelAt)<=freshnessMs && uint32_t(now-d.validationAt)<=freshnessMs &&
  uint32_t(now-d.snapshotAt)<=freshnessMs && uint32_t(now-d.nativePositionAt)<=freshnessMs &&
  matchesMultiTurnProbeProfile(d.snapshot);
#else
 (void)d;(void)now;return false;
#endif
}
}
