#pragma once
#include <stdint.h>

namespace cover {
struct StaRecoveryConditions {
 bool connected=false,credentials=false,setupBusy=false,maintenanceBusy=false,portalClient=false;
};

// Bounds application-issued retries; Arduino may also reconnect independently.
// No I/O, allocation, event-thread state or credential storage.
class StaRecovery {
 uint32_t since_=0,wait_=kInitialWaitMs;
public:
 static constexpr uint32_t kInitialWaitMs=20000,kMaximumWaitMs=120000;
 void reset(uint32_t now){since_=now;wait_=kInitialWaitMs;}
 bool poll(uint32_t now,const StaRecoveryConditions& state){
  if(state.connected || !state.credentials || state.setupBusy || state.maintenanceBusy || state.portalClient){
   reset(now);return false;
  }
  if(uint32_t(now-since_)<wait_)return false;
  since_=now;
  wait_=wait_<kMaximumWaitMs/2?wait_*2:kMaximumWaitMs;
  return true;
 }
 uint32_t waitMs() const{return wait_;}
};
}
