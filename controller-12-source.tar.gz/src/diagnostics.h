#pragma once
#include <stdint.h>
#include "cpu_load.h"
#include "wifi_diagnostics.h"
#include "metrics_session.h"
#include "failure_summary.h"
namespace cover {
void beginDiagnostics();
enum class DebugLevel : uint8_t { Info, Warn, Error };
#ifndef COVER_DEBUG_LOG_CAPACITY
#define COVER_DEBUG_LOG_CAPACITY 20
#endif
constexpr unsigned kDebugCapacity=COVER_DEBUG_LOG_CAPACITY;
static_assert(kDebugCapacity>=10 && kDebugCapacity%10==0,"Debug capacity must use whole 10-entry blocks");
struct DebugEntry { uint32_t sequence=0, at=0, epoch=0; DebugLevel level=DebugLevel::Info; bool truncated=false; char message[112]={}; };
static_assert(sizeof(DebugEntry)==128,"Keep event timestamps compact");
struct DebugWindow {
 uint32_t oldest=0,newest=0,sequenceEpoch=0,overwrites=0;
 uint32_t serialDropped=0,truncated=0,suppressedTrace=0;
 bool available=false;
};
DebugWindow debugLogWindow();
const char* debugLevelName(DebugLevel level);
bool debugLogAvailable();
bool diagnosticsStartupHealthy(uint32_t now);
enum class DiagnosticTask : uint8_t { Web, Cover, Alpaca, Diagnostics, Ota, Count };
// Lifecycle gate only; reading it performs no sampling or acquisition.
uint32_t diagnosticsMetricsEpoch();
bool beginDiagnosticsWork(uint32_t epoch);
void endDiagnosticsWork();
// OFF acknowledgment waits for in-flight optional work to release its resources.
class DiagnosticsWork {
 bool active_;
 public:
 explicit DiagnosticsWork(uint32_t epoch):active_(beginDiagnosticsWork(epoch)){}
 ~DiagnosticsWork(){if(active_)endDiagnosticsWork();}
 DiagnosticsWork(const DiagnosticsWork&)=delete;
 DiagnosticsWork& operator=(const DiagnosticsWork&)=delete;
 explicit operator bool()const{return active_;}
};
constexpr unsigned kDiagnosticTaskCount=static_cast<unsigned>(DiagnosticTask::Count);
struct TaskStackSample {
 bool available=false;
 uint32_t minimumFreeBytes=0,sampledAt=0;
};
struct RuntimeDiagnostics {
 MetricsPhase phase=MetricsPhase::Off;
 bool available=false;
 unsigned viewers=0;
 uint32_t epoch=0;
 uint32_t sampledAt=0,internalFreeHeap=0,internalMinimumFreeHeap=0,internalLargestFreeBlock=0;
 uint32_t logDropped=0,webGapMs=0,motionGapMs=0;
 uint32_t ringOverwrites=0,logTruncated=0,suppressedTrace=0;
 bool debugLogAvailable=false;
 WiFiDiagnostics wifi;
 uint32_t wifiOutageMs=0;
 CpuLoadSample cpu;
 TaskStackSample stacks[kDiagnosticTaskCount];
};
// No stack scan unless a metrics session is active. Sample only the calling task.
void noteTaskStack(DiagnosticTask task);
const char* diagnosticTaskName(DiagnosticTask task);
RuntimeDiagnostics runtimeDiagnostics();
const char* diagnosticsBootId();
enum class MetricsRequest : uint8_t { Subscribe, Renew, Unsubscribe };
bool requestMetrics(MetricsRequest request,uint32_t client,uint32_t generation,uint32_t observedUptime=0);
// Bounded RAM log; producers never wait for serial or network I/O.
void debugLog(const char* format, ...) __attribute__((format(printf, 1, 2)));
void debugLog(DebugLevel level,const char* format, ...) __attribute__((format(printf, 2, 3)));
bool nextDebugEntry(uint32_t after, DebugEntry& output);
bool nextDebugEntryInWindow(uint32_t after,uint32_t sequenceEpoch,DebugEntry& output);
void diagnosticLog(const char* format, ...) __attribute__((format(printf, 1, 2)));
// Selected events go to both sinks once; diagnosticLog remains serial-only detail.
void diagnosticEvent(const char* format, ...) __attribute__((format(printf, 1, 2)));
void diagnosticEvent(DebugLevel level,const char* format, ...) __attribute__((format(printf, 2, 3)));
// Call with a static string immediately before an application Wi-Fi change.
void diagnosticWiFiAction(const char* action);
void noteAlpacaRequest(bool failed,bool timeout,uint32_t elapsedMs);
void noteWebLoop();
void noteMotionLoop();
const char* resetReasonName();
const char* firmwareId();
FailureSummaryRecord retainedFailureSummary();
void noteFailureRetry(int result,uint32_t nextWaitMs);
void noteRetainedFault(const char* message,uint32_t position=UINT32_MAX,uint32_t target=UINT32_MAX);
}
