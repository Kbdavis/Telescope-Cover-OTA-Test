#pragma once
#include "alpaca_client.h"
namespace cover { namespace alpaca {
// Optional display samples never grant motion permission. No camera/heater controls.
struct TelemetrySample {
 bool valid=false,hasValue=false;
 double value=0;
 uint32_t at=0;
 Error error=Error::Offline;
 bool fresh(uint32_t now) const {return valid && uint32_t(now-at)<=60000;}
};
struct Telemetry {
 TelemetrySample altitude,azimuth,cameraState,cameraTemperature,heater;
};
class TelemetryClient {
 public:
 explicit TelemetryClient(Transport& transport):transport_(transport){}
 // One optional request per completed safety sweep, never during a safety sweep.
 void step(uint32_t now,bool autoConnect);
 Telemetry status() const {return samples_;}
 void reset(){samples_=Telemetry{};stage_=0;altitudeTurn_=true;attempted_[0]=attempted_[1]=false;connectAt_[0]=connectAt_[1]=0;}
 private:
 void sample(TelemetrySample& out,const Reply& reply,uint32_t now);
 Transport& transport_;
 Telemetry samples_;
 uint8_t stage_=0;
 uint32_t transaction_=0,connectAt_[2]={0,0};
 bool attempted_[2]={false,false};
 bool altitudeTurn_=true;
};
}
alpaca::Telemetry alpacaTelemetry();
}
