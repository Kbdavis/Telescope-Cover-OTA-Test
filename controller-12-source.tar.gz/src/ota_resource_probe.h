#pragma once
#include "ota_protocol.h"
namespace cover {
// Pure scheduling and deterministic bytes for the USB-only synthetic experiment.
// This is not a native ESP image and must never be passed to an SDK OTA writer.
constexpr uint32_t kOtaProbeBytes=65536;
class OtaProbeSchedule {
 uint32_t epoch_=0,at_=0;
 public:
 bool due(uint32_t now,uint32_t epoch,bool safe){
  if(!epoch || !safe)return false;
  if(epoch_==epoch && uint32_t(now-at_)<5000)return false;
  epoch_=epoch;at_=now;return true;
 }
};
inline OtaManifest otaProbeManifest(){
 OtaManifest m;m.size=kOtaProbeBytes;memset(m.elf,0x55,sizeof(m.elf));
 otaUnhex("93294915232fbf17bf92cc451043298a052615b37a33a9d4070e4e717e568c56",64,m.sha256);
 otaUnhex("313549fb5b78f30ff364cfd0c4768b5b",32,m.md5);return m;
}
inline bool otaProbeBlock(uint32_t offset,uint8_t* buffer,size_t n){
 if(!buffer || !n || offset>kOtaProbeBytes || n>kOtaProbeBytes-offset || (!offset && n<kOtaPrefixBytes))return false;
 for(size_t i=0;i<n;++i)buffer[i]=uint8_t(offset+i);
 if(offset)return true;
 // The first block is always at least the full 352-byte prefix.
 memset(buffer,0,kOtaPrefixBytes);buffer[0]=0xe9;buffer[1]=1;buffer[2]=2;buffer[3]=0x20;buffer[23]=1;
 otaPut32(buffer+28,kOtaProbeBytes-32);otaPut32(buffer+32,0xabcd5432);memset(buffer+176,0x55,32);
 static const uint8_t descriptor[64]={
  'T','C','O','T','A','0','0','1',
  't','e','l','e','s','c','o','p','e','-','c','o','v','e','r',0,
  'w','e','b','_','c','o','n','t','r','o','l',0,0,0,0,0,
  1,0,5,0,1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
 memcpy(buffer+288,descriptor,sizeof(descriptor));
 return true;
}
}
