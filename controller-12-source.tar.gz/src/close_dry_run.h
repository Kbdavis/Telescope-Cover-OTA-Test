#pragma once
#include "alpaca_client.h"
namespace cover {
// Deliberately has no actuator/command dependency. This result cannot authorize motion.
class CloseDryRun {
 public:
 enum class Phase { Idle, Stowing, Rechecking, Ready, Cancelled };
 void start(uint32_t now,uint32_t operation){phase_=Phase::Stowing;started_=now;operation_=operation;reason_="Waiting for telescope stow";}
 void reset(){phase_=Phase::Idle;reason_="No dry run requested";}
 void cancel(const char* reason){phase_=Phase::Cancelled;reason_=reason;}
 void step(uint32_t now,const alpaca::StowStatus& test,const alpaca::Snapshot& scope,bool coverChecks);
 Phase phase() const{return phase_;}
 const char* name() const;
 const char* reason() const{return reason_;}
 bool active() const{return phase_==Phase::Stowing || phase_==Phase::Rechecking || phase_==Phase::Ready;}
 private:
 Phase phase_=Phase::Idle;
 uint32_t started_=0,operation_=0,recheckAt_=0;
 const char* reason_="No dry run requested";
};
}
