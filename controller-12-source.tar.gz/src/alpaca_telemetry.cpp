#include "alpaca_telemetry.h"
namespace cover { namespace alpaca {
void TelemetryClient::sample(TelemetrySample& out,const Reply& r,uint32_t now){
 out.valid=r.error==Error::None;out.error=r.error;
 if(out.valid){out.hasValue=true;out.value=r.number;out.at=now+r.elapsedMs;}
}
void TelemetryClient::step(uint32_t now,bool autoConnect){
 if(++transaction_>=0x3fffffffU)transaction_=1;
 const uint32_t tx=0x40000000U|transaction_;
 if(altitudeTurn_){sample(samples_.altitude,transport_.get(Property::Altitude,tx),now);altitudeTurn_=false;return;}
 altitudeTurn_=true;
 Reply r;
 switch(stage_){
 case 0: // Altitude is interleaved; the secondary rotation starts with azimuth.
 case 1:sample(samples_.azimuth,transport_.get(Property::Azimuth,tx),now);stage_=2;break;
 case 2:case 6:{
  const bool camera=stage_==2;const unsigned index=camera?0:1;
  r=transport_.getMetric(camera?Metric::CameraConnected:Metric::HeaterConnected,tx);
  if(r.error==Error::None && r.value){stage_=camera?4:8;break;}
  if(camera){samples_.cameraState.valid=samples_.cameraTemperature.valid=false;samples_.cameraState.error=samples_.cameraTemperature.error=r.error==Error::None?Error::Offline:r.error;}
  else {samples_.heater.valid=false;samples_.heater.error=r.error==Error::None?Error::Offline:r.error;}
  if(autoConnect && r.error==Error::None && !r.value && (!attempted_[index] || uint32_t(now-connectAt_[index])>=10000))stage_=camera?3:7;
  else stage_=camera?6:0;
  break;
 }
 case 3:case 7:{
  const bool camera=stage_==3;const unsigned index=camera?0:1;
  if(autoConnect){transport_.connectAuxiliary(camera?Auxiliary::Camera:Auxiliary::Heater,tx);attempted_[index]=true;connectAt_[index]=now;}
  // A PUT acknowledgment never substitutes for Connected GET verification.
  stage_=camera?2:6;break;
 }
 case 4:sample(samples_.cameraState,transport_.getMetric(Metric::CameraState,tx),now);stage_=5;break;
 case 5:sample(samples_.cameraTemperature,transport_.getMetric(Metric::CameraTemperature,tx),now);stage_=6;break;
 case 8:
  r=transport_.getMetric(Metric::HeaterCount,tx);
  if(r.error==Error::None && r.number>=1){stage_=9;break;}
  samples_.heater.valid=false;samples_.heater.error=r.error==Error::None?Error::Unsupported:r.error;stage_=0;break;
 case 9:
  r=transport_.getMetric(Metric::HeaterIdentity,tx);
  if(r.error==Error::None && r.value){stage_=10;break;}
  samples_.heater.valid=false;samples_.heater.error=r.error==Error::None?Error::Unsupported:r.error;stage_=0;break;
 case 10:
  r=transport_.getMetric(Metric::HeaterState,tx);r.number=r.value?1:0;
  sample(samples_.heater,r,now);stage_=0;break;
 default:stage_=0;break;
 }
}
}}
