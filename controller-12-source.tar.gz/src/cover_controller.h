#pragma once
#include "servo_controller.h"
#include <stdlib.h>
#include "motion_limits.h"
#include "travel_model.h"

namespace cover {
constexpr uint16_t kManualJogTolerance = 20;
constexpr uint16_t kSettlingSpread = 3;
enum class State { Unknown, Closed, Opening, Open, Closing, Stopped, Fault, Manual, Holding, Retained, TorqueTest };
enum class Command { Open, Close, Stop };
const char* stateName(State state);

enum class PositionDisposition : uint8_t { Accepted, ReadFailed, OutsideLimits, Discontinuity, AwayFromTarget, HoldingDrift, TargetOvershoot };
struct MotionSample {uint32_t elapsedMs=0;uint16_t position=0;bool valid=false;PositionDisposition disposition=PositionDisposition::Accepted;};
struct MotionTrace {
 static constexpr unsigned capacity=64;
 MotionSample samples[capacity];
 uint32_t operation=0,validReads=0,failedReads=0,lastValidMs=0;
 uint16_t target=0,lastPosition=0;
 uint8_t count=0,next=0,tolerance=0,settled=0;
 uint32_t startedAt=0,timeoutMs=0,rejectedReads=0;
 uint16_t startPosition=0,speed=0;uint8_t acceleration=0;
};
struct MotionFaultEvidence {
 uint32_t sequence=0,at=0,elapsedMs=0;
 State stateBefore=State::Unknown;
 bool traceAvailable=false,positionKnown=false,releaseConfirmed=false;
 uint16_t acceptedPosition=0;
 uint8_t consecutiveReadFailures=0,wrongSamples=0,limitSamples=0;
 char reason[80]={};
 ServoDiagnostics servo;
};
static_assert(sizeof(MotionFaultEvidence)<=384,"Keep fault evidence bounded on the motion stack");
struct MotionSettings {
  uint16_t minimum = 0, maximum = 0; // Equal defaults prohibit motion.
  uint16_t speed = 100;
  uint8_t acceleration = 10;
  uint32_t timeoutMs = 5000;
  bool disableTorqueAfterMove = false;
  bool hasTravelArc = false;
  TravelArc arc;
};

// Supervised actuator motion. OPEN/CLOSED are encoder bands; physical sensors remain pending.
// Caller must supply a current safety decision on every command and tick.
class CoverController {
 public:
  explicit CoverController(ServoMotion& servo) : servo_(servo) {}
  bool configure(const MotionSettings& settings);
  // Optional saved endpoints classify stable encoder feedback, not physical sensors.
  bool initializeStationary(const MotionSettings& settings, int closed=-1, int open=-1, bool allowPowered=false, bool allowOutsideRange=false);
  bool prepareReboot(bool retainTorque);
  bool applyStationarySettings(const MotionSettings& settings, int closed=-1, int open=-1);
  bool setMotionProfile(uint16_t speed, uint8_t acceleration, uint32_t timeoutMs);
  bool jog(int16_t counts, bool pathClear, bool retainTorque = false);
  // Explicit manual authorization only. Saved cover limits remain unchanged.
  bool manualJog(int16_t counts, bool pathClear, bool retainTorque=false);
  bool moveEndpoint(uint16_t target, bool opening, bool pathClear);
  const char* moveRejection() const {return moveRejection_;}
  void tick(bool pathClear, bool telescopeClear = true);
  void stop();
#ifdef COVER_REFERENCE_PROBE
  void invalidateReference() {fail("Servo reference probe; inspect and recalibrate before motion");}
#endif
  bool recover(bool allowOutsideRange=false); // Explicit acknowledgement; never resumes a move.
  bool positionInRange() const {return positionKnown_ && inRange(position_);}
  State state() const { return state_; }
  bool holding() const { return state_ == State::Holding || state_ == State::TorqueTest; }
  bool torqueTesting() const {return state_==State::TorqueTest;}
  bool startTorqueTest(); // Explicit supervised current-position hold, at most 750 ms.
  bool moving() const { return state_ == State::Manual || state_ == State::Opening || state_ == State::Closing; }
  const char* fault() const { return fault_; }
  bool torqueOffConfirmed() const { return torqueOffConfirmed_; }
  uint16_t position() const { return position_; }
  uint16_t target() const { return target_; }
  MotionTrace trace() const {auto result=trace_;result.settled=settled_;return result;}
  // Fill the caller's existing snapshot without a full history temporary on
  // the motion task's stack. The controller still owns its internal history.
  void copyTrace(MotionTrace& output) const {output=trace_;output.settled=settled_;}
  void copyFault(MotionFaultEvidence& output) const {output=faultEvidence_;}
  uint32_t faultSequence() const {return faultEvidence_.sequence;}
 private:
  MotionTrace trace_;
  MotionFaultEvidence faultEvidence_;
  bool traceForAttempt_=false,positionKnown_=false;
  void recordPosition(bool valid,uint16_t position,PositionDisposition disposition=PositionDisposition::Accepted);
  bool beginMove(int value, bool absolute, State motion, bool pathClear, bool retainTorque = false, bool manualOverride=false);
  int coordinate(int raw) const { return motionArcActive_?motionArc_.coordinate(raw):manualOverride_?raw:settings_.hasTravelArc?settings_.arc.coordinate(raw,endpointRecovery_?25:10):raw; }
  int distance(int a,int b) const { return abs(coordinate(a)-coordinate(b)); }
  bool inRange(int raw) const { return raw>=settings_.minimum && raw<=settings_.maximum && (!settings_.hasTravelArc || settings_.arc.contains(raw)); }
  bool motionInRange(int raw) const {
   if(manualOverride_)return raw>=0 && raw<=4095;
   if(!endpointRecovery_ || recoveryEntered_)return inRange(raw);
   if(!settings_.arc.endpointStartAllowed(raw))return false;
   const int value=coordinate(raw);
   return value>=(recoveryStart_<-10?recoveryStart_:-10) && value<=(recoveryStart_>int(settings_.arc.length)+10?recoveryStart_:int(settings_.arc.length)+10);
  }
  bool release();
  void captureFault(const char* reason);
  void fail(const char* reason);
  bool repeatedWrongSample(PositionDisposition kind) {
    if(wrongSamples_ && wrongKind_!=kind)wrongSamples_=0;
    wrongKind_=kind;return ++wrongSamples_>=3;
  }
  ServoMotion& servo_;
  MotionSettings settings_;
  TravelArc motionArc_;
  bool motionArcActive_=false;
  bool manualOverride_=false;
  bool endpointRecovery_=false,recoveryEntered_=false;
  int recoveryStart_=0;
  bool configured_ = false, torqueOffConfirmed_ = false, holdAfterMove_ = false;
  State state_ = State::Unknown;
  const char* fault_ = "";
  const char* moveRejection_ = "Move rejected: controller state does not permit movement";
  uint16_t position_ = 0, target_ = 0, jogTolerance_ = kManualJogTolerance;
  int settleMinimum_ = 0, settleMaximum_ = 0;
  uint32_t started_ = 0, lastPoll_ = 0;
  int bestDistance_ = 0, previousDistance_ = 0;
  bool previousDistanceValid_=false;
  PositionDisposition wrongKind_=PositionDisposition::Accepted;
  uint8_t readFailures_ = 0, wrongSamples_ = 0, limitSamples_ = 0, settled_ = 0;
};
}
