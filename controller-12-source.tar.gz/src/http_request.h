#pragma once
#include <stddef.h>
#include <stdint.h>
#include <string.h>
namespace cover {
// One request per connection. No allocation, blocking I/O or logging. The
// adapter allocates this arena only while a client is being received.
class HttpRequest {
 public:
  static constexpr size_t kHeaders=2048,kBody=2048,kLine=512,kRequestLine=1024,kFields=32,kArguments=32;
  static constexpr uint32_t kDeadlineMs=2000;
  enum class Method:uint8_t {Get,Post};
  struct Field {uint16_t name=0,value=0;};
  char bytes[kHeaders+kBody+1]={};
  Field fields[kFields];
  size_t fieldCount=0,target=0,query=0,body=0,length=0;
  Method method=Method::Get;
  unsigned version=1,error=0;
  bool ready=false;
  explicit HttpRequest(uint32_t now):started_(now){}
  bool expired(uint32_t now){if(!ready && !error && uint32_t(now-started_)>=kDeadlineMs)error=408;return error!=0;}
  static bool equal(const char* a,const char* b){
   while(*a && *b){char x=*a++,y=*b++;if(x>='A'&&x<='Z')x+=32;if(y>='A'&&y<='Z')y+=32;if(x!=y)return false;}return *a==*b;
  }
  const char* header(const char* name)const{
   for(size_t i=0;i<fieldCount;++i)if(equal(bytes+fields[i].name,name))return bytes+fields[i].value;
   return "";
  }
  bool encoded()const{return equal(header("Content-Type"),"application/x-www-form-urlencoded");}
  static bool arguments(const char* data,size_t& count){
   if(!*data)return true;
   ++count;
   for(size_t i=0;data[i];++i){
    unsigned char c=data[i];if(c<33 || c>126)return false;
    if(c=='&')++count;
    if(c=='%'){
     if(!data[i+1] || !data[i+2])return false;
     int a=hex(data[i+1]),b=hex(data[i+2]);if(a<0 || b<0 || (a==0&&b==0))return false;i+=2;
    }
   }
   return count<=kArguments;
  }
  bool feed(char c,uint32_t now){
   if(expired(now))return false;
   if(ready){error=400;return false;}
   if(c==0){error=400;return false;}
   if(body_){
    bytes[used_++]=c;
    if(used_-body==length){bytes[used_]=0;finish();}
    return !error;
   }
   if(used_>=kHeaders){error=431;return false;}
   bytes[used_++]=c;
   const size_t lineSize=used_-line_;
   if(lineSize>(first_?kRequestLine:kLine)){error=first_?414:431;return false;}
   if(c!='\n'){
    if(c!='\r' && !(c=='\t' && !first_) && (uint8_t(c)<32 || uint8_t(c)>126)){error=400;return false;}
    return true;
   }
   if(lineSize<2 || bytes[used_-2]!='\r'){error=400;return false;}
   bytes[used_-2]=0;
   if(first_){first_=false;requestLine();}
   else if(lineSize==2){headersDone();}
   else {field();}
   line_=used_;return !error;
  }
 private:
  size_t used_=0,line_=0;uint32_t started_;bool first_=true,body_=false,hasLength_=false;
  static int hex(char c){return c>='0'&&c<='9'?c-'0':c>='a'&&c<='f'?c-'a'+10:c>='A'&&c<='F'?c-'A'+10:-1;}
  static bool token(char c){return (c>='a'&&c<='z') || (c>='A'&&c<='Z') || (c>='0'&&c<='9') || (c && strchr("!#$%&'*+-.^_`|~",c));}
  void requestLine(){
   char* start=bytes+line_;char* space=strchr(start,' ');
   if(!space){error=400;return;}*space++=0;
   if(!strcmp(start,"GET"))method=Method::Get;
   else if(!strcmp(start,"POST"))method=Method::Post;
   else {error=405;return;}
   target=space-bytes;char* end=strchr(space,' ');
   if(!end || space==end || *space!='/'){error=400;return;}*end++=0;
   if(!strcmp(end,"HTTP/1.1"))version=1;
   else if(!strcmp(end,"HTTP/1.0"))version=0;
   else {error=400;return;}
   // Paths are literal; avoid alternate encodings for OTA route/policy checks.
   for(char* p=space;*p && *p!='?';++p)if(*p=='%' || *p=='#' || *p=='\\' || uint8_t(*p)<=32){error=400;return;}
   char* q=strchr(space,'?');if(q){*q++=0;query=q-bytes;}
   if(!strncmp(space,"/api/ota/",9) && query){error=400;return;}
  }
  void field(){
   if(fieldCount==kFields){error=431;return;}
   char* name=bytes+line_;char* colon=strchr(name,':');
   if(!colon || colon==name){error=400;return;}
   for(char* p=name;p<colon;++p)if(!token(*p)){error=400;return;}
   *colon++=0;
   for(size_t i=0;i<fieldCount;++i)if(equal(name,bytes+fields[i].name)){error=400;return;}
   while(*colon==' ' || *colon=='\t')++colon;
   char* end=colon+strlen(colon);while(end>colon && (end[-1]==' ' || end[-1]=='\t'))*--end=0;
   for(char* p=colon;*p;++p)if(uint8_t(*p)<32 || uint8_t(*p)>126){error=400;return;}
   fields[fieldCount].name=uint16_t(name-bytes);fields[fieldCount].value=uint16_t(colon-bytes);++fieldCount;
   if(equal(name,"Transfer-Encoding")){error=400;return;}
   if(equal(name,"Expect")){error=417;return;}
   if(equal(name,"Content-Encoding")){error=415;return;}
   if(equal(name,"Content-Length")){
    hasLength_=true;
    if(!*colon || (*colon=='0' && colon[1])){error=400;return;}
    for(char* p=colon;*p;++p){if(*p<'0'||*p>'9'){error=400;return;}length=length*10+*p-'0';if(length>kBody){error=413;return;}}
   }
  }
  void headersDone(){
   if(version==1 && !*header("Host")){error=400;return;}
   if(method==Method::Get && length){error=400;return;}
   if(method==Method::Post && !hasLength_){error=411;return;}
   const bool ota=!strcmp(bytes+target,"/api/ota/prepare") || !strcmp(bytes+target,"/api/ota/cancel") ||
    !strcmp(bytes+target,"/api/ota/probe/prepare") || !strcmp(bytes+target,"/api/ota/probe/cancel");
   const char* type=header("Content-Type");
   if(ota && method==Method::Post){
    if(length>640){error=413;return;}
    if(!equal(type,"text/plain")){error=415;return;}
    if(!length){error=400;return;}
   }else if(method==Method::Post && length && !encoded()) {error=415;return;}
   body=used_;bytes[body]=0;
   if(length){body_=true;}else finish();
  }
  void finish(){
   size_t count=0;
   if((query && !arguments(bytes+query,count)) || (encoded() && length && !arguments(bytes+body,count))){error=400;return;}
   ready=true;
  }
};
static_assert(sizeof(HttpRequest)<=4352,"Keep the transient HTTP input arena bounded");
}
