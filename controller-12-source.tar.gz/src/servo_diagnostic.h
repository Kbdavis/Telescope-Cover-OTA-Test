#pragma once
namespace cover {
void beginServoDiagnostic();
void pollServoDiagnostic();
}
