#pragma once
#include <stdint.h>
namespace cover {
struct WiFiDiagnostics {
 bool connected=false,everConnected=false,hasDisconnect=false,rssiValid=false;
 uint32_t disconnects=0,reconnects=0,lastDisconnectAt=0,lastOutageMs=0;
 uint16_t reason=0;
 int rssi=0,minimumRssi=0;
 bool hasRssi=false;
 uint32_t requests=0,failures=0,timeouts=0,lastRequestMs=0,maxRequestMs=0;
};
// Caller serializes access. Passive counters only; no allocation or networking.
class WiFiDiagnosticTracker {
 public:
 WiFiDiagnostics data;
 void disconnected(uint32_t now,uint16_t reason){
  increment(data.disconnects);data.reason=reason;data.hasDisconnect=true;data.lastDisconnectAt=now;
  if(!outage_){outage_=true;outageAt_=now;}
  data.connected=false;data.rssiValid=false;
 }
 void gotIP(uint32_t now){
  if(!data.connected){if(data.everConnected)increment(data.reconnects);data.everConnected=true;}
  data.connected=true;if(outage_){data.lastOutageMs=now-outageAt_;outage_=false;}
 }
 void signal(int rssi){
  if(!data.connected || rssi>=0 || rssi< -127)return;
  data.rssi=rssi;data.rssiValid=true;
  if(!data.hasRssi || rssi<data.minimumRssi)data.minimumRssi=rssi;
  data.hasRssi=true;
 }
 void request(bool failed,bool timeout,uint32_t elapsed){
  increment(data.requests);if(failed)increment(data.failures);if(timeout)increment(data.timeouts);
  data.lastRequestMs=elapsed;if(elapsed>data.maxRequestMs)data.maxRequestMs=elapsed;
 }
 uint32_t outageMs(uint32_t now)const{return outage_?now-outageAt_:0;}
 private:
 bool outage_=false;uint32_t outageAt_=0;
 static void increment(uint32_t& value){if(value!=UINT32_MAX)++value;}
};
}
