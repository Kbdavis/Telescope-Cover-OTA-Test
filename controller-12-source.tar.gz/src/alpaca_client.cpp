#include "alpaca_client.h"
namespace cover { namespace alpaca {
const char* propertyName(Property p){
 switch(p){case Property::Connected:return "connected";case Property::CanFindHome:return "canfindhome";
 case Property::AtHome:return "athome";case Property::Slewing:return "slewing";case Property::Tracking:return "tracking";case Property::Altitude:return "altitude";case Property::Azimuth:return "azimuth";}return "";
}
const char* errorName(Error e){
 switch(e){case Error::None:return "none";case Error::Offline:return "disconnected";case Error::Timeout:return "timeout";
 case Error::Http:return "http";case Error::Oversized:return "oversized";case Error::Protocol:return "protocol";
 case Error::Unsupported:return "unsupported";case Error::Driver:return "driver";}return "unknown";
}
void Client::enable(bool enabled,bool autoConnect){
 published_=Snapshot{};published_.enabled=enabled;published_.readOnly=!autoConnect;
 stage_=0;failures_=0;immediate_=true;connectPending_=false;connectAttempted_=false;connectDue_=0;
}
Snapshot Client::status(uint32_t now) const {
 Snapshot s=published_;
 if(s.valid && !s.fresh(now)){s.valid=false;s.consecutiveStowed=0;s.error=Error::Timeout;s.failure={"status_age",0,0,now};}
 return s;
}
void Client::step(uint32_t now){
 if(!published_.enabled || (!immediate_ && int32_t(now-nextAt_)<0))return;
 immediate_=false;
 if(connectPending_){
  connectPending_=false;
  if(++transaction_==0)++transaction_;
  const Reply r=transport_.connectSession(transaction_);
  const uint32_t completed=now+r.elapsedMs;
  connectAttempted_=true;connectDue_=completed+10000;
  // Even a successful PUT is not a status observation. Re-read a complete sweep.
  published_.valid=false;published_.consecutiveStowed=0;
  published_.error=r.error==Error::None?Error::Offline:r.error;published_.driverError=r.driverError;
  published_.failure={"connected_put",transaction_,r.elapsedMs,completed};
  stage_=0;nextAt_=completed+(r.error==Error::None?100:3000);return;
 }
 if(stage_==0){pending_=Snapshot{};pending_.enabled=true;pending_.readOnly=published_.readOnly;pending_.sampledAt=now;}
 // Bracket sequential readings with logical connection checks.
 static const Property order[]={Property::Connected,Property::CanFindHome,Property::AtHome,Property::Slewing,Property::Tracking,Property::Connected};
 if(++transaction_==0)++transaction_;
 const Reply r=transport_.get(order[stage_],transaction_);
 const uint32_t completed=now+r.elapsedMs;
 if(r.error!=Error::None || ((stage_==0 || stage_==5) && !r.value)){
  published_.valid=false;published_.connected=false;published_.consecutiveStowed=0;
  published_.error=r.error==Error::None?Error::Offline:r.error;published_.driverError=r.driverError;
  published_.failure={propertyName(order[stage_]),transaction_,r.elapsedMs,completed};
  // Only a valid Connected=false reply permits a connection request, never a timeout.
  if(r.error==Error::None && !r.value && (stage_==0 || stage_==5) && !published_.readOnly &&
     (!connectAttempted_ || int32_t(completed-connectDue_)>=0)){
   connectPending_=true;stage_=0;nextAt_=completed+100;return;
  }
  if(failures_<3)++failures_;
  const uint32_t retry=published_.readOnly?(failures_==1?300:failures_==2?1000:3000):3000;
  stage_=0;nextAt_=completed+retry;return;
 }
 // Revoke the old snapshot immediately when a new observation contradicts
 // its safe state. Repeated raised/tracking/slewing readings are still valid
 // connected telemetry; they must not create a false disconnect every sweep.
 const bool contradicts=(stage_==1&&published_.canFindHome&&!r.value)||
  (stage_==2&&published_.atHome&&!r.value)||(stage_==3&&!published_.slewing&&r.value)||
  (stage_==4&&!published_.tracking&&r.value);
 if(contradicts){
  published_.valid=false;published_.consecutiveStowed=0;
 }
 switch(stage_){case 0:pending_.connected=true;break;case 1:pending_.canFindHome=r.value;break;
 case 2:pending_.atHome=r.value;break;case 3:pending_.slewing=r.value;break;case 4:pending_.tracking=r.value;break;default:break;}
 ++stage_;nextAt_=completed+100;
 if(stage_==6){
  // Age uses the oldest observation; completion includes transport latency.
  stage_=0;pending_.completedAt=completed;pending_.sequence=published_.sequence+1;
  pending_.valid=uint32_t(completed-pending_.sampledAt)<=2500;
  const bool stowed=pending_.valid && pending_.canFindHome && pending_.atHome && !pending_.slewing && !pending_.tracking;
  pending_.consecutiveStowed=stowed?(published_.fresh(completed)&&published_.consecutiveStowed?2:1):0;
  pending_.error=pending_.valid?Error::None:Error::Timeout;
  if(!pending_.valid)pending_.failure={"status_sweep",transaction_,uint32_t(completed-pending_.sampledAt),completed};
  if(pending_.valid)failures_=0;
  published_=pending_;nextAt_=completed+1000;
 }
}
const char* stowPhaseName(StowPhase p){
 switch(p){case StowPhase::Idle:return "idle";case StowPhase::Checking:return "checking";
 case StowPhase::Waiting:return "waiting";case StowPhase::Complete:return "complete";
 case StowPhase::Failed:return "failed";case StowPhase::Unknown:return "outcome_unknown";}return "unknown";
}
bool StowTest::start(uint32_t now,uint32_t timeoutMs){
 if(state_.active() || timeoutMs<10000 || timeoutMs>180000)return false;
 const uint32_t operation=state_.operation+1;state_=StowStatus{};
 state_.operation=operation;state_.phase=StowPhase::Checking;state_.startedAt=now;
 timeout_=timeoutMs;confirmations_=0;lastSequence_=0;return true;
}
void StowTest::step(uint32_t now,const Snapshot& s,Transport& transport){
 if(!state_.active())return;
 if(uint32_t(now-state_.startedAt)>=timeout_){state_.phase=StowPhase::Unknown;state_.error=Error::Timeout;return;}
 if(s.error!=Error::None){state_.phase=state_.phase==StowPhase::Checking?StowPhase::Failed:StowPhase::Unknown;state_.error=s.error;return;}
 if(!s.fresh(now)){confirmations_=0;return;}
 if(state_.phase==StowPhase::Checking){
  if(!s.connected || !s.canFindHome || s.slewing || s.tracking){state_.phase=StowPhase::Failed;state_.error=Error::Protocol;return;}
  // Poller is reset at operation start, so preflight cannot reuse old readings.
  const Reply reply=transport.findHome(0x80000000UL|state_.operation);
  sentAt_=now+reply.elapsedMs;lastSequence_=s.sequence;
  if(reply.error!=Error::None){state_.phase=StowPhase::Unknown;state_.error=reply.error;return;}
  state_.phase=StowPhase::Waiting;return;
 }
 if(s.sequence==lastSequence_)return;
 lastSequence_=s.sequence;
 if(int32_t(s.sampledAt-sentAt_)<0)return;
 if(s.connected && s.canFindHome && s.atHome && !s.slewing && !s.tracking){
  if(++confirmations_>=2)state_.phase=StowPhase::Complete;
 }else confirmations_=0;
}
}}
