#pragma once
#include "diagnostics.h"
#include <new>
#include <cstring>
namespace cover {
// Caller serializes access; storage is allocated once, never in a motion loop.
class DebugBuffer {
 public:
  explicit DebugBuffer(uint32_t initialSequence=0):sequence_(initialSequence){
   for(auto& block:blocks_){block=new(std::nothrow) DebugEntry[kBlockSize];if(!block){clear();return;}}
   available_=true;
  }
  ~DebugBuffer(){clear();}
  DebugBuffer(const DebugBuffer&)=delete;
  DebugBuffer& operator=(const DebugBuffer&)=delete;
  bool available() const {return available_;}
  void append(DebugEntry& entry){
   if(!available_)return;
   // Reuse the latest Alpaca status slot across unrelated events. Keep its
   // sequence stable: cursor readers must not see holes or duplicate events.
   if(!entry.truncated && std::strncmp(entry.message,"ALPACA ",7)==0){
    for(unsigned offset=0;offset<count_;++offset){
     auto& previous=at((head_+kDebugCapacity-1-offset)%kDebugCapacity);
     if(std::strncmp(previous.message,"ALPACA ",7)!=0)continue;
     if(!previous.truncated && previous.level==entry.level && std::strcmp(previous.message,entry.message)==0){
      entry.sequence=previous.sequence;previous=entry;return;
     }
     break; // A changed Alpaca status starts a new event, including recovery.
    }
   }
   if(sequence_==UINT32_MAX){
    // A new cursor epoch deliberately discards the previous sequence domain.
    overwrites_+=count_;count_=0;head_=0;sequence_=0;++sequenceEpoch_;
   }
   if(count_==kDebugCapacity)++overwrites_;else ++count_;
   entry.sequence=++sequence_;at(head_)=entry;head_=(head_+1)%kDebugCapacity;
  }
  DebugWindow window() const {
   DebugWindow out;out.available=available_;out.sequenceEpoch=sequenceEpoch_;out.overwrites=overwrites_;
   if(count_){out.oldest=sequence_-count_+1;out.newest=sequence_;}return out;
  }
  bool next(uint32_t after,DebugEntry& out) const {
   if(!available_)return false;
   if(!count_)return false;
   const uint32_t oldest=sequence_-count_+1;
   const uint32_t next=after<oldest?oldest:after+1;
   if(!next || next>sequence_)return false;
   out=at((head_+kDebugCapacity-count_+next-oldest)%kDebugCapacity);return true;
  }
 private:
  static constexpr unsigned kBlockSize=10;
  static_assert(kDebugCapacity%kBlockSize==0,"Whole debug blocks required");
  DebugEntry* blocks_[kDebugCapacity/kBlockSize]={};
  uint32_t sequence_=0,sequenceEpoch_=0,overwrites_=0;unsigned head_=0,count_=0;bool available_=false;
  DebugEntry& at(unsigned i){return blocks_[i/kBlockSize][i%kBlockSize];}
  const DebugEntry& at(unsigned i) const {return blocks_[i/kBlockSize][i%kBlockSize];}
  void clear(){for(auto& block:blocks_){delete[] block;block=nullptr;}available_=false;}
};
}
