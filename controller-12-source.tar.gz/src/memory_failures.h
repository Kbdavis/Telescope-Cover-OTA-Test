#pragma once
#include <atomic>
#include <stdint.h>
namespace cover {
struct AllocationFailureSample {uint32_t sequence=0,size=0,caps=0;};
// No allocation, logging, clock access or waiting in the allocator callback.
// A contended metadata slot loses detail, never the independent failure count.
struct AllocationFailures {
 static_assert(ATOMIC_INT_LOCK_FREE==2,"Failure counters must be lock free");
 std::atomic<bool> enabled{false};
 std::atomic<uint32_t> count{0},metadataLost{0};
 std::atomic_flag busy=ATOMIC_FLAG_INIT;
 AllocationFailureSample last;
 void failure(uint32_t size,uint32_t caps){
  if(!enabled.load())return;
  const uint32_t sequence=count.fetch_add(1)+1;
  if(busy.test_and_set(std::memory_order_acquire)){metadataLost.fetch_add(1);return;}
  last.sequence=sequence;last.size=size;last.caps=caps;
  busy.clear(std::memory_order_release);
 }
 bool snapshot(AllocationFailureSample& out){
  if(busy.test_and_set(std::memory_order_acquire))return false;
  out=last;busy.clear(std::memory_order_release);return true;
 }
};
inline bool usbMemoryWindow(uint32_t now,uint32_t start,uint32_t duration=180000){return uint32_t(now-start)<duration;}
}
