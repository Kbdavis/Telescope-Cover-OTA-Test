#pragma once
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <stdio.h>
namespace cover {
// Stock espota sends at most 1024 bytes then waits for an undelimited ACK.
inline size_t otaAckEnd(size_t acknowledged,size_t total){
 return total-acknowledged>1024?acknowledged+1024:total;
}
constexpr size_t kOtaPrefixBytes=352,kOtaRecordBytes=160,kOtaBodyBytes=640;
constexpr uint32_t kOtaSlotBytes=0x140000;
inline bool otaControlBodyValid(int declared,size_t actual,bool plain){return plain && declared>0 && declared<=int(kOtaBodyBytes) && size_t(declared)==actual;}
inline bool otaSlot(uint32_t value){return value==0x10000 || value==0x150000;}
inline uint32_t otaU32(const uint8_t* p){return uint32_t(p[0])|uint32_t(p[1])<<8|uint32_t(p[2])<<16|uint32_t(p[3])<<24;}
inline void otaPut32(uint8_t* p,uint32_t v){for(unsigned i=0;i<4;++i)p[i]=v>>(i*8);}
inline uint32_t otaCrc(const uint8_t* p,size_t n){uint32_t c=~0U;while(n--){c^=*p++;for(unsigned j=0;j<8;++j)c=(c>>1)^(0xedb88320U&uint32_t(-int(c&1)));}return ~c;}
inline void otaHex(const uint8_t* p,size_t n,char* out){static const char chars[]="0123456789abcdef";for(size_t i=0;i<n;++i){out[2*i]=chars[p[i]>>4];out[2*i+1]=chars[p[i]&15];}out[2*n]=0;}
inline bool otaUnhex(const char* text,size_t n,uint8_t* out){
 for(size_t i=0;i<n;++i){const char c=text[i];if(!((c>='0'&&c<='9')||(c>='a'&&c<='f')))return false;
  const unsigned v=c<='9'?c-'0':c-'a'+10;if(i%2)out[i/2]|=v;else out[i/2]=v<<4;}return true;
}
inline bool otaEqual(const uint8_t* a,const uint8_t* b,size_t n){uint8_t different=0;while(n--)different|=*a++^*b++;return different==0;}
struct OtaManifest {
 uint32_t size=0,controlGeneration=0;
 bool developmentStationary=false,developmentRecovery=false;
 uint8_t sha256[32]={},md5[16]={},elf[32]={};
};
struct OtaInvitation {uint16_t port=0;uint32_t size=0;uint8_t md5[16]={};};
inline bool parseOtaInvitation(const char* p,size_t n,OtaInvitation& out){
 if(n<39 || n>127 || p[0]!='0' || p[1]!=' ' || p[n-1]!='\n' || memchr(p,0,n))return false;
 const char* end=p+n;p+=2;
 auto number=[&](uint32_t& v){if(p==end || *p<'1'||*p>'9')return false;uint64_t value=0;
  while(p<end && *p>='0'&&*p<='9'){value=value*10+*p++-'0';if(value>UINT32_MAX)return false;}
  if(p==end || *p++!=' ')return false;
  v=uint32_t(value);return true;};
 uint32_t port=0;OtaInvitation invite;
 if(!number(port) || port>65535 || !number(invite.size) || size_t(end-p)!=33 || !otaUnhex(p,32,invite.md5))return false;
 invite.port=uint16_t(port);out=invite;return true;
}
inline bool parseOtaTransferAuth(const char* p,size_t n,char cnonce[33],uint8_t response[16]){
 if(n!=70 || memcmp(p,"200 ",4) || p[36]!=' ' || p[69]!='\n')return false;
 uint8_t parsed[16];if(!otaUnhex(p+4,32,parsed) || !otaUnhex(p+37,32,response))return false;
 memcpy(cnonce,p+4,32);cnonce[32]=0;return true;
}
// One canonical, ordered, newline-terminated body. Duplicate/unknown fields,
// alternate number encodings, embedded NULs and trailing data are rejected.
inline bool parseOtaManifest(const char* body,size_t n,OtaManifest& out){
 if(!body || !n || n>kOtaBodyBytes || memchr(body,0,n))return false;
 const char* p=body;const char* end=body+n;
 auto literal=[&](const char* s){size_t len=strlen(s);if(size_t(end-p)<len || memcmp(p,s,len))return false;p+=len;return true;};
 auto number=[&](uint32_t& value){if(p==end || *p<'1'||*p>'9')return false;uint64_t v=0;
  while(p<end && *p>='0'&&*p<='9'){v=v*10+*p++-'0';if(v>UINT32_MAX)return false;}
  if(p==end || *p++!='\n')return false;
  value=uint32_t(v);return true;};
 auto hex=[&](uint8_t* dest,size_t bytes){if(size_t(end-p)<bytes*2+1 || !otaUnhex(p,bytes*2,dest))return false;p+=bytes*2;return *p++=='\n';};
 OtaManifest m;
 auto policy=[&](){
  if(literal("policy=closed-cover\ncontrol_generation="))return true;
#ifdef COVER_OTA_DEVELOPMENT
  if(literal("policy=development-stationary\ncontrol_generation=")){m.developmentStationary=true;return true;}
  if(literal("policy=development-recovery\ncontrol_generation=")){m.developmentRecovery=true;return true;}
#endif
  return false;
 };
 if(!literal("product=telescope-cover\nprofile=web_control\nprotocol=1\nsettings=5\nhandoff=1\nsize=") || !number(m.size) ||
    !literal("sha256=") || !hex(m.sha256,32) || !literal("md5=") || !hex(m.md5,16) || !literal("elf=") || !hex(m.elf,32) ||
    !policy() || !number(m.controlGeneration) || p!=end ||
    m.size<kOtaPrefixBytes || m.size>kOtaSlotBytes || m.controlGeneration==UINT32_MAX)return false;
 out=m;return true;
}
// App descriptor follows the 24-byte ESP header and first 8-byte segment header.
// Our fixed 64-byte custom descriptor follows ESP-IDF's 256-byte app descriptor.
inline bool otaPrefixValid(const uint8_t* p,size_t n,const OtaManifest& m){
 static const uint8_t descriptor[64]={
  'T','C','O','T','A','0','0','1',
  't','e','l','e','s','c','o','p','e','-','c','o','v','e','r',0,
  'w','e','b','_','c','o','n','t','r','o','l',0,0,0,0,0,
  1,0,5,0,1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
 return n>=kOtaPrefixBytes && p[0]==0xe9 && p[1]>0 && p[1]<=16 && p[2]==2 && p[3]==0x20 && p[12]==0 && p[13]==0 && p[23]==1 &&
  otaU32(p+28)>=320 && otaU32(p+28)<=m.size-32 && otaU32(p+32)==0xabcd5432 && otaEqual(p+176,m.elf,32) && !memcmp(p+288,descriptor,64);
}
// No erase until the complete embedded descriptor has passed validation.
// The backend owns digest contexts/SDK handles; every flash boundary rechecks
// clearance. The owner must abort its backend after any false result.
template<class Backend> class OtaImageStream {
 const OtaManifest& manifest_;Backend& backend_;uint8_t prefix_[kOtaPrefixBytes]={};
 size_t prefixUsed_=0;uint32_t received_=0;bool begun_=false,failed_=false,finished_=false;
public:
 OtaImageStream(const OtaManifest& manifest,Backend& backend):manifest_(manifest),backend_(backend){}
 uint32_t received()const{return received_;}
 bool consume(const uint8_t* data,size_t n){
  if(failed_ || finished_ || !n || n>manifest_.size-received_ || !backend_.clearance()){failed_=true;return false;}
  const size_t original=n;
  if(!begun_){
   const size_t room=sizeof(prefix_)-prefixUsed_,copy=n<room?n:room;memcpy(prefix_+prefixUsed_,data,copy);prefixUsed_+=copy;data+=copy;n-=copy;
   if(prefixUsed_==sizeof(prefix_)){
    if(!otaPrefixValid(prefix_,sizeof(prefix_),manifest_) || !backend_.clearance() || !backend_.begin() ||
       !backend_.clearance() || !backend_.write(prefix_,sizeof(prefix_))){failed_=true;return false;}
    begun_=true;
   }
  }
  if(n && (!backend_.clearance() || !backend_.write(data,n))){failed_=true;return false;}
  received_+=original;return true;
 }
 bool finish(){
  if(failed_ || finished_ || !begun_ || received_!=manifest_.size || !backend_.clearance() || !backend_.finish()){failed_=true;return false;}
  finished_=true;return true;
 }
};
enum class OtaOutcome:uint8_t { Intent=1,BootCheck,Complete,Failed,RolledBack,Unconfirmed,Cancelled };
enum class OtaStartupAction { Wait,Accept,Recover };
struct OtaStartupHealth {
 bool settingsReadable=false,journalReadable=false,servicesReady=false,workersAlive=false,localRecovery=false,receiverReady=false;
};
inline OtaStartupAction otaStartupAction(uint32_t elapsed,const OtaStartupHealth& h){
 const bool healthy=h.settingsReadable&&h.journalReadable&&h.servicesReady&&h.workersAlive&&h.localRecovery&&h.receiverReady;
 if(elapsed>=4000 && healthy)return OtaStartupAction::Accept;
 return elapsed>=30000?OtaStartupAction::Recover:OtaStartupAction::Wait;
}
inline const char* otaOutcomeName(OtaOutcome v){switch(v){case OtaOutcome::Intent:return "activation_intent";case OtaOutcome::BootCheck:return "boot_check";
 case OtaOutcome::Complete:return "complete";case OtaOutcome::Failed:return "failed";case OtaOutcome::RolledBack:return "rolled_back";
 case OtaOutcome::Cancelled:return "cancelled";default:return "unconfirmed";}}
inline bool otaNeedsReconciliation(OtaOutcome v){return v==OtaOutcome::Intent||v==OtaOutcome::BootCheck||v==OtaOutcome::Unconfirmed;}
inline bool otaStartupRequiresInspection(bool pendingImage,bool unresolvedHandoff,bool journalReadable){
 return pendingImage || unresolvedHandoff || !journalReadable;
}
struct OtaRecord {
 OtaOutcome outcome=OtaOutcome::Intent;
 bool activationConfirmed=false;
 uint8_t transaction[16]={},source[32]={},target[32]={},sha256[32]={};
 uint32_t sourceSlot=0,targetSlot=0,size=0,reset=0;
};
inline void encodeOtaRecord(const OtaRecord& r,uint8_t* p){
 memset(p,0,kOtaRecordBytes);memcpy(p,"COTA",4);p[4]=1;p[5]=uint8_t(r.outcome);p[6]=1;
 memcpy(p+8,r.transaction,16);memcpy(p+24,r.source,32);memcpy(p+56,r.target,32);memcpy(p+88,r.sha256,32);
 otaPut32(p+120,r.sourceSlot);otaPut32(p+124,r.targetSlot);otaPut32(p+128,r.size);otaPut32(p+132,r.reset);
 p[136]=r.activationConfirmed?1:0;
 otaPut32(p+156,otaCrc(p,156));
}
inline bool decodeOtaRecord(const uint8_t* p,size_t n,OtaRecord& r){
 if(n!=kOtaRecordBytes || memcmp(p,"COTA",4) || p[4]!=1 || p[5]<1 || p[5]>7 || p[6]!=1 || p[7] || otaU32(p+156)!=otaCrc(p,156))return false;
 if(p[136]>1)return false;
 for(unsigned i=137;i<156;++i)if(p[i])return false;
 OtaRecord out;out.outcome=OtaOutcome(p[5]);out.activationConfirmed=p[136];memcpy(out.transaction,p+8,16);memcpy(out.source,p+24,32);memcpy(out.target,p+56,32);memcpy(out.sha256,p+88,32);
 out.sourceSlot=otaU32(p+120);out.targetSlot=otaU32(p+124);out.size=otaU32(p+128);out.reset=otaU32(p+132);
 if(!otaSlot(out.sourceSlot)||!otaSlot(out.targetSlot)||out.sourceSlot==out.targetSlot||out.size<kOtaPrefixBytes||out.size>kOtaSlotBytes)return false;
 r=out;return true;
}
// Rollback is reported only with matching source identity and invalid target evidence.
inline OtaOutcome reconcileOtaRecord(const OtaRecord& r,uint32_t slot,const uint8_t* elf,bool targetInvalid,bool healthAccepted){
 if(slot==r.targetSlot && otaEqual(elf,r.target,32))return healthAccepted?OtaOutcome::Complete:OtaOutcome::BootCheck;
 if(slot==r.sourceSlot && otaEqual(elf,r.source,32) && targetInvalid && r.activationConfirmed)return OtaOutcome::RolledBack;
 return OtaOutcome::Unconfirmed;
}
// Shared by the receiver and fault-injection tests. A durable intent precedes
// the cancellation/Stop commit boundary; failed or ambiguous selection never
// manufactures a successful activation verdict.
template<class Backend> bool commitOtaImage(Backend& b,OtaRecord& record){
 if(!b.clearance() || b.cancelled())return false;
 record.outcome=OtaOutcome::Intent;
 if(!b.persist(record) || !b.enterCommit())return false;
 return b.selectBoot();
}
}
