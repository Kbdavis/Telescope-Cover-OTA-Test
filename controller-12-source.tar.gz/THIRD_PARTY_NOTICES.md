# Dependency and third-party notice inventory

Reviewed 2026-11-12 against repository source, the pinned PlatformIO configuration,
the installed framework package metadata, and existing asset provenance.
Original project software is MIT, hardware is CERN-OHL-S-2.0, and documentation
is CC BY 4.0; see [coverage and exceptions](LICENSING.md). Third-party material
retains its own terms. This inventory is not completed binary-distribution clearance.

## Firmware and browser dependencies

| Component | Use / evidence | Terms and release action |
| --- | --- | --- |
| Arduino-ESP32 | Framework `4.20017.260907+sha.dcc1105b`, pinned in `platformio.ini`; installed `package.json` declares LGPL-2.1-or-later | Review the exact framework sources, modifications, linking and LGPL source/relinking obligations; include applicable texts and notices. The project's MIT grant does not replace these obligations. [Upstream](https://github.com/espressif/arduino-esp32) |
| ESP-IDF and bundled SDK components | Linked through the framework: FreeRTOS, lwIP, mbedTLS, cJSON and other components; prebuilt libraries may also be included | Mixed licenses. Inventory the exact selected SDK and linked components using the candidate's build records/map; include applicable component notices, source and any binary redistribution terms. Do not treat the entire SDK as having one license. [Upstream](https://github.com/espressif/esp-idf) |
| esptool-js 0.7.1 | Installer dynamically imports `https://unpkg.com/esptool-js@0.7.1/bundle.js`; requires internet access | Apache-2.0. Review bundled dependencies and any NOTICE obligations before hosting. Fetching it at runtime is not a completed dependency review. [License](https://github.com/espressif/esptool-js/blob/v0.7.1/LICENSE) |
| Xtensa toolchain/runtime | `espressif/toolchain-xtensa-esp32@8.4.0+2021r2-patch5` | Review linked runtime libraries and applicable GCC exceptions/newlib notices from the exact toolchain. The compiler executable is not bundled in the user download. |
| esptool.py | Pinned build-time image generation/merging tool, not bundled in the end-user installation package | GPL-2.0-or-later; retain tool identity in build records. [Upstream](https://github.com/espressif/esptool) |

## Assets and repository-only material

| Material | Terms / evidence | Release action |
| --- | --- | --- |
| Embedded pIqaD font, renamed Cover Warrior Display | Derived from Mike Neff / Michael Everson's font under SIL OFL 1.1; full copyright/license in [klingon-font.txt](docs/licenses/klingon-font.txt) | Font bytes are embedded in `data/ui/live.css` and therefore firmware. Include copyright and OFL text in firmware distributions; review the subset/renaming metadata. Keep the font outside the project's MIT grant. |
| Klingon UI glosses | Project best-effort mapping with consulted sources recorded in [klingon-translations.txt](docs/licenses/klingon-translations.txt) | Preserve provenance; do not describe the text as a reviewed localization or relicense consulted sources. |
| cJSON v1.7.17 in `tests/vendor/cjson/` | Upstream MIT text and Dave Gamble/contributor notices in [LICENSE](tests/vendor/cjson/LICENSE) | Keep notices in source/test distributions. These vendored files are host-test-only; firmware uses the SDK's separate cJSON copy. |
| Waveshare/Feetech servo drawings, models and images | [Manufacturer provenance](cad/servo_cradle/manufacturer/README.md); no redistribution license established | Resolve permission or remove from public distribution, including imported geometry in mixed assemblies and screenshots. |
| Waveshare controller STEP archive/model | `cad/controller_case_v1/source/provenance.json` expressly records unestablished redistribution permission | Same review applies to source archives/history and assemblies containing the model; project licensing cannot grant manufacturer rights. |

## Outstanding distribution checks

- [ ] Inventory exact linked components and their versions from the future
      production multi-turn candidate, including prebuilt SDK/runtime libraries.
- [ ] Collect complete required dependency license texts/copyright/NOTICE files;
      satisfy applicable source and relinking requirements before distributing firmware.
- [ ] Review esptool-js's pinned browser bundle and bundled dependency notices.
- [x] Update the isolated packager's explicit source/output allowlists to carry
      LICENSING.md, project LICENSES texts and font notices, with recursive hashes
      and ZIP entries. Missing required notices now reject packaging.
- [ ] Add the finalized framework/browser dependency texts and notices to that
      allowlist after reviewing the exact candidate components.
- [ ] Audit tracked manufacturer/reference assets and mixed CAD/media, including
      Git history, before making the repository public. GitHub source archives
      contain tracked content even when firmware attachments exclude it.
- [ ] Verify the actual packaged artifacts contain every required notice and
      that their release notes accurately describe unresolved restrictions.

The existing local factory-profile candidate remains unchanged and unpublished.
New project license files do not retroactively add missing notices to that ZIP.
