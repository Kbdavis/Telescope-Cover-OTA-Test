#pragma once
// Copy to wifi_local.h (ignored by Git), then enter your home Wi-Fi credentials.
#define COVER_WIFI_SSID ""
#define COVER_WIFI_PASSWORD ""
