#pragma once
// Copy to ignored ota_local.h only during the later supervised OTA release gate.
// Use a unique random ASCII secret of 32..128 bytes. Never pass it on a command line.
#define COVER_OTA_SECRET ""
// Keep disabled until memory reserves, bootstrap and failure injection are verified.
#define COVER_OTA_RECEIVER_ENABLED 0
#define COVER_OTA_MIN_INTERNAL_HEAP 0
#define COVER_OTA_MIN_LARGEST_BLOCK 0
