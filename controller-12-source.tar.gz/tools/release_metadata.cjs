#!/usr/bin/env node
// Offline preview only: no network, hardware, credentials, signing or installation.
'use strict';
const fs=require('node:fs');
const model=require('../data/ui/release_metadata.js');
function read(file){
 const fd=fs.openSync(file,'r');
 try{
  if(!fs.fstatSync(fd).isFile())throw Error('Expected a regular metadata file');
  const buffer=Buffer.alloc(model.MAX_BYTES+1);
  let size=0,count;
  while(size<buffer.length && (count=fs.readSync(fd,buffer,size,buffer.length-size,null))>0)size+=count;
  if(size>model.MAX_BYTES)throw Error('Metadata exceeds byte limit');
  return new TextDecoder('utf-8',{fatal:true}).decode(buffer.subarray(0,size));
 }finally{fs.closeSync(fd);}
}
try{
 const args=process.argv.slice(2),beta=args.at(-1)==='--include-beta';
 if(beta)args.pop();
 if(args.length<1 || args.length>2 || args.some(a=>a.startsWith('-')))throw Error('Usage: node tools/release_metadata.cjs RELEASE.json [DEVICE.json] [--include-beta]');
 const release=model.parseReleaseJson(read(args[0]));
 const assessment=args[1]?model.assessRelease(release,model.parseDeviceJson(read(args[1])),{include_beta:beta}):null;
 process.stdout.write(JSON.stringify({preview:true,authenticated:false,version:release.version,assessment})+'\n');
}catch(error){
 process.stderr.write('Release metadata rejected: '+error.message+'\n');process.exitCode=1;
}
