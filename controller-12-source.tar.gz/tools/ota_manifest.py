"""Offline production OTA artifact validation and control-protocol helpers. No uploader."""
import argparse
import hashlib
import hmac
import json
from pathlib import Path
import struct
from check_firmware import check_firmware

DEVELOPMENT_MARKER=b'TCOTA-DEV-LOCAL-1'

DESCRIPTOR = (b"TCOTA001" + b"telescope-cover\0" + b"web_control".ljust(16, b"\0")
              + struct.pack("<HHHHI", 1, 5, 1, 0, 1) + b"\0" * 12)


MULTITURN_USB_DESCRIPTOR = DESCRIPTOR[:24] + b"multiturn_usb".ljust(16, b"\0") + DESCRIPTOR[40:]


def inspect_image(image, *, allow_test_profile=False, allow_multiturn_usb=False):
    if not 352 <= len(image) <= 0x140000:
        raise ValueError("Application size outside both pinned slots")
    if image[0] != 0xE9 or not 1 <= image[1] <= 16 or image[2:4] != b"\x02\x20" or image[12:14] != b"\0\0" or image[23] != 1:
        raise ValueError("Unsupported ESP32 image header")
    if struct.unpack_from("<I", image, 28)[0] < 320 or struct.unpack_from("<I", image, 32)[0] != 0xABCD5432:
        raise ValueError("Missing first-segment app descriptor")
    descriptor = image[288:352]
    test_descriptor = DESCRIPTOR[:24] + b"test_profile".ljust(16, b"\0") + DESCRIPTOR[40:]
    if descriptor != DESCRIPTOR and not (allow_test_profile and descriptor == test_descriptor) and not (allow_multiturn_usb and descriptor == MULTITURN_USB_DESCRIPTOR):
        raise ValueError("Incompatible product/profile/settings/handoff descriptor")
    offset, checksum = 24, 0xEF
    for _ in range(image[1]):
        if offset + 8 > len(image):
            raise ValueError("Truncated segment header")
        size = struct.unpack_from("<I", image, offset + 4)[0]
        offset += 8
        if size > len(image) - offset:
            raise ValueError("Truncated segment")
        for byte in image[offset:offset + size]:
            checksum ^= byte
        offset += size
    checksum_at = (offset // 16 + 1) * 16 - 1
    if checksum_at + 33 != len(image) or image[checksum_at] != checksum:
        raise ValueError("Image checksum, length or unsupported trailer")
    if hashlib.sha256(image[:checksum_at + 1]).digest() != image[checksum_at + 1:]:
        raise ValueError("Image validation hash mismatch")
    return dict(product="telescope-cover", profile=descriptor[24:40].rstrip(b"\0").decode("ascii"), protocol=1, settings=5, handoff=1,
                size=len(image), sha256=hashlib.sha256(image).hexdigest(),
                md5=hashlib.md5(image).hexdigest(), elf=image[176:208].hex())


def manifest_for_build(build_dir, *, allow_test_profile=False, allow_development=False, allow_multiturn_usb=False, program="firmware"):
    build_dir = Path(build_dir)
    check_firmware(build_dir, program)
    image=(build_dir / (program + ".bin")).read_bytes()
    if DEVELOPMENT_MARKER in image and not allow_development:
        raise ValueError("Development image contains a local credential; excluded from production release validation")
    result = inspect_image(image, allow_test_profile=allow_test_profile, allow_multiturn_usb=allow_multiturn_usb)
    elf = (build_dir / (program + ".elf")).read_bytes()
    if hashlib.sha256(elf).hexdigest() != result["elf"]:
        raise ValueError("Binary embedded ELF identity differs from selected artifact")
    if not strong_startup_hook(elf):
        raise ValueError("Deferred startup-acceptance hook is missing or weak")
    return result


def strong_startup_hook(elf):
    """Check ELF32 symbols: a mangled C++ function cannot override Arduino's C hook."""
    if len(elf) < 52 or elf[:6] != b"\x7fELF\x01\x01":
        return False
    offset = struct.unpack_from("<I", elf, 32)[0]
    entry_size, count = struct.unpack_from("<HH", elf, 46)
    if entry_size != 40 or offset + count * 40 > len(elf):
        return False
    sections = [struct.unpack_from("<10I", elf, offset + i * 40) for i in range(count)]
    for section in sections:
        if section[1] != 2 or section[9] != 16 or section[6] >= count:
            continue
        names = sections[section[6]]
        table = elf[names[4]:names[4] + names[5]]
        if section[5] % 16 or section[4] + section[5] > len(elf) or names[4] + names[5] > len(elf):
            return False
        for pos in range(section[4], section[4] + section[5], 16):
            name, _, _, info, _, index = struct.unpack_from("<IIIBBH", elf, pos)
            end = table.find(b"\0", name)
            if end >= name and table[name:end] == b"verifyRollbackLater":
                return info >> 4 == 1 and info & 15 == 2 and index != 0
    return False


def prepare_body(manifest, generation, policy="closed-cover"):
    if policy not in ("closed-cover", "development-stationary", "development-recovery"):
        raise ValueError("Unsupported OTA position policy")
    if type(generation) is not int or not 1 <= generation < 0xFFFFFFFF:
        raise ValueError("A fresh control generation is required")
    fields = [(key, manifest[key]) for key in
              ("product", "profile", "protocol", "settings", "handoff", "size", "sha256", "md5", "elf")]
    fields += [("policy", policy), ("control_generation", generation)]
    return "".join(f"{key}={value}\n" for key, value in fields).encode("ascii")


def control_mac(secret, method, route, boot_id, nonce, transaction, body):
    """Secret remains in caller memory; never serialize it into a manifest/command."""
    if not 32 <= len(secret) <= 128 or len(body) > 640:
        raise ValueError("Invalid control credential or body length")
    key = hmac.digest(secret, b"cover-ota-control-v1", "sha256")
    message = (f"COVER-OTA-CONTROL-1\n{method}\n{route}\n{boot_id}\n{nonce}\n"
               f"{transaction}\n{hashlib.sha256(body).hexdigest()}\n").encode("ascii")
    return hmac.new(key, message, "sha256").hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("build_dir", type=Path)
    args = parser.parse_args()
    try:
        print(json.dumps(manifest_for_build(args.build_dir), indent=2))
    except (OSError, ValueError) as error:
        parser.exit(1, f"Invalid OTA artifact: {error}\n")


if __name__ == "__main__":
    main()
