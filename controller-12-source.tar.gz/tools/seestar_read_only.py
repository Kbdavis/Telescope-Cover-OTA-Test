#!/usr/bin/env python3
"""Read-only Seestar probe. No motion, settings, or cover commands.
Authentication reference: github.com/smart-underworld/seestar_alp/device/seestar_device.py
Requires Python 3 and openssl. Output deliberately excludes network credentials.
"""
import argparse
import base64
import json
import socket
import subprocess
import time

ALLOWED = {'get_verify_str', 'verify_client', 'test_connection',
           'get_device_state', 'scope_get_state', 'iscope_get_app_state'}

class Probe:
    def __init__(self, connection):
        self.connection = connection
        self.sequence = 0
        self.buffer = b''

    def request(self, method, params=None):
        if method not in ALLOWED:
            raise ValueError('Not a read-only probe method')
        self.sequence += 1
        request = {'id': self.sequence, 'method': method}
        if params is not None:
            request['params'] = params
        self.connection.sendall((json.dumps(request) + '\r\n').encode())
        deadline = time.monotonic() + 3
        while time.monotonic() < deadline:
            if b'\n' not in self.buffer:
                try:
                    data = self.connection.recv(65536)
                except socket.timeout:
                    continue
                if not data:
                    raise ConnectionError('Scope closed connection')
                self.buffer += data
                if len(self.buffer) > 1048576:
                    raise ValueError('Oversized response')
                continue
            line, self.buffer = self.buffer.split(b'\n', 1)
            response = json.loads(line)
            if response.get('id') == self.sequence:
                return response
        raise TimeoutError(method + ' response timed out')

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('host')
    parser.add_argument('--samples', type=int, default=1)
    parser.add_argument('--interop-key', help='Local interoperable RSA private PEM; never logged')
    args = parser.parse_args()
    if not 1 <= args.samples <= 300:
        parser.error('samples must be 1..300')
    with socket.create_connection((args.host, 4700), 5) as connection:
        connection.settimeout(.5)
        probe = Probe(connection)
        if args.interop_key:
            challenge = probe.request('get_verify_str')['result']['str']
            signature = subprocess.run(['openssl', 'dgst', '-sha1', '-sign', args.interop_key],
                                       input=challenge.encode(), capture_output=True, check=True).stdout
            verified = probe.request('verify_client', {'sign': base64.b64encode(signature).decode(),
                                                       'data': challenge})
            if verified.get('result', verified.get('code', -1)) != 0:
                raise RuntimeError('Client verification rejected: code=' + str(verified.get('code')))
            print('Client verified; read-only queries only.', flush=True)
        else:
            print('No interop key supplied; newer firmware may ignore status requests.', flush=True)
        for sample in range(args.samples):
            probe.request('test_connection')
            response = probe.request('get_device_state')
            result = response.get('result', {})
            device = result.get('device', {})
            # Strict selection: never print full device-state/network/auth payloads.
            selected = {'sample': sample, 'time': time.time(), 'code': response.get('code'),
                        'device': {k: device.get(k) for k in
                                   ('product_model', 'firmware_ver_string', 'firmware_ver_int')},
                        'mount': result.get('mount')}
            print(json.dumps(selected), flush=True)
            for method in ('scope_get_state', 'iscope_get_app_state'):
                reply = probe.request(method)
                print(json.dumps({'method': method, 'code': reply.get('code'),
                                  'result': reply.get('result')}), flush=True)
            if sample + 1 < args.samples:
                time.sleep(2)

if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, RuntimeError, subprocess.SubprocessError, KeyError) as error:
        raise SystemExit(str(error))
