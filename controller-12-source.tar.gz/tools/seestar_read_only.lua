-- Temporary Mac proxy filter for connection/status testing only.
-- No settings, motion, shutdown, or camera commands are allowed.
local allowed = {
    get_verify_str = true, verify_client = true, pi_is_verified = true,
    test_connection = true, get_device_state = true,
    scope_get_state = true, iscope_get_app_state = true,
    scope_get_horiz_coord = true, scope_get_equ_coord = true,
    scope_get_track_state = true, pi_get_info = true,
}
function on_request(msg)
    if type(msg) ~= 'table' or type(msg.method) ~= 'string' then
        return 'block'
    end
    if allowed[msg.method] then return 'forward' end
    log('Read-only filter blocked method: ' .. msg.method)
    return 'block'
end
