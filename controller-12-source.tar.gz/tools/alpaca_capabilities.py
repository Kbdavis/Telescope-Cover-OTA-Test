#!/usr/bin/env python3
"""Read native Alpaca capabilities; optional logical connections, never motion."""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import time
import urllib.parse
import urllib.request


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host', default='192.168.1.131')
    parser.add_argument('--port', type=int, default=32323)
    parser.add_argument('--connect', action='store_true', help='Allow only Connected=true PUTs')
    args = parser.parse_args()
    base = f'http://{args.host}:{args.port}'
    folder = Path('diagnostics') / ('alpaca-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
    folder.mkdir(parents=True)
    records = []
    transaction = 300

    def call(device, member, params=None, connect=False):
        nonlocal transaction
        assert not connect or (args.connect and member == 'connected' and params == {'Connected': 'true'})
        transaction += 1
        values = {'ClientID': 731, 'ClientTransactionID': transaction, **(params or {})}
        data = urllib.parse.urlencode(values).encode()
        url = base + '/api/v1/' + device + '/' + member
        request = urllib.request.Request(url, data=data, method='PUT', headers={'Content-Type': 'application/x-www-form-urlencoded'}) if connect else urllib.request.Request(url + '?' + data.decode())
        try:
            with urllib.request.urlopen(request, timeout=4) as response:
                raw = response.read(65537)
                if len(raw) > 65536:
                    raise ValueError('oversized response')
                result = json.loads(raw)
            if result.get('ClientTransactionID') != transaction:
                raise ValueError('transaction mismatch')
        except Exception as error:
            result = {'probe_error': str(error)}
        records.append({'device': device, 'member': member, 'method': request.get_method(), 'params': params or {}, 'response': result})
        (folder / 'responses.json').write_text(json.dumps(records, indent=2))
        print(device, member, json.dumps(result), flush=True)
        time.sleep(.15)
        return result

    members = {
        'telescope/0': ['name', 'athome', 'atpark', 'slewing', 'tracking', 'altitude', 'azimuth', 'canfindhome'],
        'camera/0': ['name', 'camerastate', 'ccdtemperature', 'percentcompleted', 'heatsinktemperature'],
        'camera/1': ['name', 'camerastate', 'ccdtemperature'],
        'switch/0': ['name', 'maxswitch', 'supportedactions'],
    }
    for device, properties in members.items():
        state = call(device, 'connected')
        if args.connect and state.get('ErrorNumber') == 0 and state.get('Value') is False:
            call(device, 'connected', {'Connected': 'true'}, connect=True)
        state = call(device, 'connected')
        if state.get('ErrorNumber') != 0 or state.get('Value') is not True:
            continue
        for member in properties:
            result = call(device, member)
            if member == 'maxswitch' and result.get('ErrorNumber') == 0 and type(result.get('Value')) is int:
                for index in range(min(result['Value'], 16)):
                    for prop in ['getswitchname', 'getswitchdescription', 'canwrite', 'minswitchvalue', 'maxswitchvalue', 'switchstep', 'getswitchvalue', 'getswitch']:
                        call(device, prop, {'Id': index})
    print('Saved:', folder / 'responses.json')


if __name__ == '__main__':
    main()
