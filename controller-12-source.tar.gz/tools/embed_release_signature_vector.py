"""Embed a public test vector only into the isolated, non-operational self-test."""
import base64
import json
import hashlib
import subprocess
import sys
from pathlib import Path


def generate(root):
    root = Path(root)
    vector = json.loads((root / 'tests/fixtures/release_signature.json').read_text())
    envelope = vector['envelope']
    if (envelope['key_id'], envelope['schema'], envelope['algorithm']) != (
        'test-only', 'telescope-cover-signature-preview/1', 'ecdsa-p256-sha256-p1363'
    ):
        raise ValueError('Self-test accepts only the public test-vector contract')
    arrays = dict(publicPoint=bytes.fromhex(vector['public_point_hex']),
                  payload=base64.b64decode(envelope['payload'], validate=True),
                  signature=base64.b64decode(envelope['signature'], validate=True))
    if len(arrays['publicPoint']) != 65 or arrays['publicPoint'][0] != 4 or len(arrays['signature']) != 64 or not 0 < len(arrays['payload']) <= 4096:
        raise ValueError('Invalid public test-vector sizes')
    lines = ['// Public test vector; never a production trust root.', '#pragma once', '#include <stdint.h>']
    for name, data in arrays.items():
        lines.append('static const uint8_t ' + name + '[]={' + ','.join(str(b) for b in data) + '};')
    output = root / 'include/generated_release_signature_vector.h'
    text = '\n'.join(lines) + '\n'
    if not output.exists() or output.read_text() != text:
        output.write_text(text)


if 'Import' in globals():
    Import('env')
    if env.subst('$PIOENV') != 'release_signature_selftest':
        raise ValueError('Public test vectors must not be embedded in operating firmware')
    generate(env.subst('$PROJECT_DIR'))
    def record(source, target, env):
        build = Path(env.subst('$BUILD_DIR'))
        roles = {'bootloader.bin': 'bootloader', 'partitions.bin': 'partitions', 'boot_app0.bin': 'boot_selection'}
        parts = [dict(offset=int(str(offset), 0), path=env.subst(str(path)), role=roles[Path(env.subst(str(path))).name])
                 for offset, path in env.get('FLASH_EXTRA_IMAGES', [])]
        parts.append(dict(offset=int(env.subst('$ESP32_APP_OFFSET'), 0), path=str(build / 'firmware.bin'), role='application'))
        if sorted((p['role'], p['offset']) for p in parts) != sorted([
            ('bootloader', 0x1000), ('partitions', 0x8000), ('boot_selection', 0xe000), ('application', 0x10000)
        ]):
            raise ValueError('Unexpected self-test USB inputs')
        board = env.BoardConfig()
        mode = board.get('build.flash_mode', 'dio')
        frequency = str(board.get('build.f_flash', '40000000L')).rstrip('Ll')
        flash = board.get('upload.flash_size', '4MB')
        if (mode, frequency, flash) != ('dio', '40000000', '4MB'):
            raise ValueError('Unexpected self-test flash configuration')
        image = build / 'selftest-factory.bin'
        esptool = Path(env.PioPlatform().get_package_dir('tool-esptoolpy')) / 'esptool.py'
        command = [sys.executable, str(esptool), '--chip', 'esp32', 'merge_bin', '--output', str(image),
                   '--flash_mode', mode, '--flash_freq', '40m', '--flash_size', flash]
        for part in sorted(parts, key=lambda p: p['offset']):
            command.extend([hex(part['offset']), part['path']])
            data = Path(part['path']).read_bytes()
            part.update(size=len(data), sha256=hashlib.sha256(data).hexdigest())
        subprocess.run(command, check=True)
        data = image.read_bytes()
        for part in parts:
            if hashlib.sha256(data[part['offset']:part['offset']+part['size']]).hexdigest() != part['sha256']:
                raise ValueError('Self-test merged component mismatch')
        metadata = dict(purpose='spare-board-crypto-selftest-only', production=False, upload_authorized=False,
                        image=dict(path=image.name, offset=0, size=len(data), sha256=hashlib.sha256(data).hexdigest()), components=parts)
        (build / 'selftest-inputs.json').write_text(json.dumps(metadata, indent=2) + '\n')
        print('Uninstalled spare-board crypto self-test image SHA-256: ' + metadata['image']['sha256'])
    env.AddPostAction('$BUILD_DIR/${PROGNAME}.bin', record)
