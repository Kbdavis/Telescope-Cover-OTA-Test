"""Build the exact bench page/script for firmware and isolated browser fixtures."""
from pathlib import Path

def assets(root):
    directory=Path(root)/'data/bench'
    html=(directory/'index.html').read_text()
    if html.count('__BENCH_STYLE__')!=1:
        raise ValueError('Expected one inline bench stylesheet marker')
    html=html.replace('__BENCH_STYLE__',(directory/'app.css').read_text())
    return {'index.html':html.encode(), 'app.js':b'\n'.join((directory/name).read_bytes() for name in ['navigation.js','app.js'])}
