"""Isolated bench metadata/assets; no production release identity or secrets."""
from pathlib import Path
import gzip,json,os,sys
Import('env')
root=Path(env.subst('$PROJECT_DIR'));build=Path(env.subst('$BUILD_DIR'));build.mkdir(parents=True,exist_ok=True)
number=int(os.environ.get('TELESCOPE_BENCH_BUILD','1'))
if not 1<=number<=9999:raise ValueError('Invalid bench build')
point=bytes.fromhex(Path(os.environ['TELESCOPE_BENCH_PUBLIC_POINT']).read_text().strip())
if len(point)!=65 or point[0]!=4:raise ValueError('Expected public SEC1 P-256 point')
header='// Generated test-only public configuration. No private/device key.\n#pragma once\n'
header+=f'#define COVER_BENCH_BUILD {number}\n#define COVER_BENCH_VERSION "0.1.0-beta.{number}"\n'
header+='static const uint8_t benchPublicPoint[65]={'+','.join(map(str,point))+'};\n'
sys.path.insert(0,str(root/'tools'))
from bench_assets import assets
page_assets=assets(root)
for name,file in [('benchHtml','index.html'),('benchJs','app.js')]:
 data=gzip.compress(page_assets[file],mtime=0)
 header+=f'static const uint8_t {name}[] PROGMEM={{'+','.join(map(str,data))+'};\n'
output=build/'bench_generated.h'
if not output.exists() or output.read_text()!=header:output.write_text(header)
env.Prepend(CPPPATH=[str(build)])
