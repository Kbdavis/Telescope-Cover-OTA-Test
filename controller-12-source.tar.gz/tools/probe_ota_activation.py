"""Explicit supervised activation/early-reset experiment; normal upload CLI stays locked.

Install the temporary source over USB first. This tool owns USB until both
attempts finish. It never sends actuator/settings commands. Restore the original
slots and native boot metadata over USB afterward; keep live application NVS.
"""
import argparse
from datetime import datetime, timezone
import ipaddress
import json
from pathlib import Path
import re
import socket
import threading
import time

from capture_diagnostics import redact
from ota_upload import Artifact, EspotaTransfer, LocalHttp, Uploader, WorkflowError, load_secret


class ResetGate:
    """One reset only after final selection ACK, reboot event and expected boot."""
    def __init__(self):
        self.expected='';self.ack=False;self.reboot_at=None;self.boot_at=None;self.fired=False
    def arm(self, expected):
        if not re.fullmatch('[0-9a-f]{64}',expected):raise ValueError('Expected ELF required')
        self.expected=expected;self.ack=False;self.reboot_at=self.boot_at=None;self.fired=False
    def observe(self, line, now):
        if not self.expected:return
        if 'OTA phase=rebooting' in line:self.reboot_at=now
        boot=re.search(r'BOOT reset=\S+ elf_sha256=([0-9a-f]{64})',line)
        if boot:
            self.boot_at=now if boot[1]==self.expected and self.reboot_at is not None else None
        if 'OTA startup=accepted' in line and self.boot_at is not None:self.expected=''
    def take(self, now):
        if (not self.expected or self.fired or not self.ack or self.boot_at is None
                or self.reboot_at is None or not 0<=now-self.reboot_at<2
                or not 0<=now-self.boot_at<2):return False
        self.fired=True;return True


class UsbMonitor:
    def __init__(self, port, directory):
        import serial
        self.serial=serial.Serial(port=None,baudrate=115200,timeout=.1)
        self.serial.dtr=False;self.serial.rts=False;self.serial.port=port
        self.log=(directory/'serial.log').open('w',buffering=1)
        self.gate=ResetGate();self.lock=threading.Lock();self.stop=threading.Event()
        self.error=False;self.thread=None
    def record(self, text):
        self.log.write(datetime.now(timezone.utc).isoformat()+' '+redact(text)+'\n')
    def start(self):
        self.serial.open();self.record('HOST USB opened; may reset board; injection unarmed')
        self.thread=threading.Thread(target=self.run,daemon=True);self.thread.start()
    def arm(self, expected):
        with self.lock:
            self.gate.arm(expected);self.record('HOST early-reset armed expected_elf='+expected)
    def acknowledged(self):
        with self.lock:self.gate.ack=True
    def progress(self,*_):
        if self.error:raise WorkflowError('USB monitor failed')
    def run(self):
        pending=b''
        try:
            while not self.stop.is_set():
                pending+=self.serial.read(min(max(self.serial.in_waiting,1),4096))
                while b'\n' in pending:
                    line,pending=pending.split(b'\n',1);line=line.decode('utf-8',errors='replace').rstrip('\r')
                    with self.lock:
                        self.record(line);self.gate.observe(line,time.monotonic())
                    self.maybe_reset()
                if len(pending)>8192:raise WorkflowError('USB frame exceeded bound')
                self.maybe_reset()
        except Exception:
            self.error=True;self.record('HOST USB monitor failed; no reconnect or additional reset')
    def maybe_reset(self):
        with self.lock:reset=self.gate.take(time.monotonic())
        if reset:
            self.record('HOST INJECT early reset after target BOOT and final selection ACK; RTS EN low 100 ms')
            self.serial.rts=True
            try:time.sleep(.1)
            finally:self.serial.rts=False
    def close(self):
        self.stop.set()
        if self.thread:
            self.thread.join(2)
            if self.thread.is_alive():raise WorkflowError('USB owner did not stop')
        self.serial.close();self.log.close()


class RecordingHttp:
    def __init__(self,http,log):self.http=http;self.log=log;self.lock=threading.Lock()
    def request(self,method,path,body=None,headers=None):
        code,value=self.http.request(method,path,body,headers)
        # Never archive authentication headers, request bodies or challenges.
        if method=='GET' and path in ('/api/status','/api/ota/status'):
            with self.lock:self.log.write(json.dumps(dict(utc=datetime.now(timezone.utc).isoformat(),path=path,data=value))+'\n')
        return code,value


class ObservedTransfer(EspotaTransfer):
    def __init__(self,host,local_ip,monitor,inject=False):
        super().__init__(host,local_ip,progress=monitor.progress)
        self.monitor=monitor;self.inject=inject
    def send(self,artifact,secret):
        super().send(artifact,secret)
        if self.inject:self.monitor.acknowledged()


def safe_status(http, expected):
    code,s=http.request('GET','/api/status')
    if (code!=200 or not isinstance(s,dict) or s.get('firmware_id')!=expected
            or s.get('ready') is not True or s.get('calibrated') is not True
            or s.get('torque') is not False or s.get('moving') is not False
            or s.get('holding') is not False or s.get('dirty') is not False
            or s.get('maintenance',{}).get('locked') is not False
            or s.get('resources',{}).get('state')!='off' or s['resources'].get('viewers')!=0
            or s.get('ota',{}).get('startup')!='accepted'):
        raise WorkflowError('Expected accepted image and stationary supported-cover/OFF state required')
    return s


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host',required=True,type=ipaddress.IPv4Address)
    parser.add_argument('--port',required=True)
    parser.add_argument('--source-build-dir',required=True,type=Path)
    parser.add_argument('--candidate-build-dir',required=True,type=Path)
    parser.add_argument('--recovery-build-dir',required=True,type=Path)
    parser.add_argument('--source-secret-file',required=True,type=Path)
    parser.add_argument('--candidate-secret-file',required=True,type=Path)
    parser.add_argument('--supported-cover-off',action='store_true')
    parser.add_argument('--run-activation-recovery-experiment',action='store_true')
    parser.add_argument('--output',required=True,type=Path)
    args=parser.parse_args()
    if not args.supported_cover_off or not args.run_activation_recovery_experiment:
        parser.error('Explicit supported-cover/OFF and activation/recovery experiment flags required')
    monitor=None
    try:
        source=Artifact.load(args.source_build_dir);candidate=Artifact.load(args.candidate_build_dir)
        recovery=Artifact.load(args.recovery_build_dir)
        identities=[a.manifest['elf'] for a in (source,candidate,recovery)]
        if len(set(identities))!=3:raise WorkflowError('Three distinct validated images required')
        secrets=[load_secret(args.source_secret_file),load_secret(args.candidate_secret_file)]
        args.output.mkdir(parents=True,exist_ok=True,mode=0o700)
        with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as route:
            route.connect((str(args.host),80));local_ip=route.getsockname()[0]
        monitor=UsbMonitor(args.port,args.output);monitor.start()
        with (args.output/'status.jsonl').open('w',buffering=1) as log:
            http=RecordingHttp(LocalHttp(str(args.host),local_ip),log)
            deadline=time.monotonic()+35
            while True:
                try:safe_status(http,identities[0]);break
                except (WorkflowError,OSError):
                    if time.monotonic()>=deadline:raise WorkflowError('Source startup unconfirmed')
                    time.sleep(1)
            results=[]
            for label,payload,key,expected,inject in [('healthy',candidate,secrets[0],'COMPLETE',False),
                                                     ('pending_reset',recovery,secrets[1],'ROLLED_BACK',True)]:
                monitor.progress()
                if inject:monitor.arm(payload.manifest['elf'])
                sender=ObservedTransfer(str(args.host),local_ip,monitor,inject)
                result=Uploader(http,sender).run(payload,key,supported_cover_off=True)
                item=dict(phase=label,outcome=result.outcome,transaction=result.transaction)
                results.append(item)
                (args.output/'results.json').write_text(json.dumps(results,indent=2)+'\n')
                print(json.dumps(item),flush=True)
                if result.outcome!=expected:raise WorkflowError('Experiment outcome unconfirmed; no automatic retry')
                final=safe_status(http,identities[1])
                record=final['ota'].get('last_update',{})
                if record.get('transaction')!=result.transaction:raise WorkflowError('Final transaction changed')
                if inject and (not monitor.gate.fired or monitor.error):raise WorkflowError('Early reset not verified')
            (args.output/'final-status.json').write_text(json.dumps(final,indent=2)+'\n')
        print('Healthy activation and pending-first-boot reset rollback verified; USB restoration required.',flush=True)
    except (OSError,ValueError,WorkflowError,KeyboardInterrupt):
        parser.exit(1,'Activation experiment stopped or unconfirmed. Preserve evidence and restore original slots/boot metadata over USB; no automatic retry.\n')
    finally:
        if monitor is not None:monitor.close()


if __name__=='__main__':main()
