"""Summarize a completed passive USB memory baseline; no device access."""
import argparse
import json
from pathlib import Path
import re
from statistics import median

FRAME=re.compile(r'\[(\d+)\] USBMEM (heap|allocation|stack|end) (.*)$')

def summarize(text,expected_duration_ms=180000):
    heaps=[];allocations=[];stacks={};end=None;links=[];changes=[];disconnects=[];last_bssid=None
    for line in text.splitlines():
        m=FRAME.search(line)
        if m:
            if end is not None:raise ValueError('USB collection continued or restarted after its end marker')
            at,kind,fields=int(m[1]),m[2],dict(part.split('=',1) for part in m[3].split())
            if kind=='stack':
                value=int(fields['min_free']);name=fields['task']
                if value>=0:stacks[name]=min(stacks.get(name,value),value)
                continue
            row={key:int(value,0) for key,value in fields.items()};row['at_ms']=at
            if kind=='heap':
                if heaps and at<=heaps[-1]['at_ms']:raise ValueError('Collection restarted or timestamps regressed')
                heaps.append(row)
            elif kind=='allocation':allocations.append(row)
            else:end=row
        link=re.search(r'\[(\d+)\] WIFI LINK bssid=([0-9a-f:]+) channel=(\d+) rssi=(-?\d+)',line)
        if link:
            at,bssid,rssi=int(link[1]),link[2],int(link[4]);links.append((at,rssi))
            if last_bssid is not None and bssid!=last_bssid:changes.append(dict(at_ms=at,source=last_bssid,target=bssid))
            last_bssid=bssid
        reason=re.search(r'\[(\d+)\].*WIFI DISCONNECT reason=(\d+) name=(\S+)',line)
        if reason:disconnects.append(dict(at_ms=int(reason[1]),reason=int(reason[2]),name=reason[3]))
    if end is None or len(heaps)<10 or not allocations:raise ValueError('Incomplete USB baseline')
    if not expected_duration_ms<=end['duration_ms']<=expected_duration_ms+2000:raise ValueError('Unexpected collection window')
    if not end['hook'] or any(row['hook']!=1 for row in allocations):raise ValueError('Allocation failure hook was unavailable')
    start=end['at_ms']-end['duration_ms'];steady=[r for r in heaps if r['at_ms']>=start+20000]
    if len(steady)<10:raise ValueError('Insufficient settled baseline samples')
    steady_links=[rssi for at,rssi in links if start+20000<=at<=end['at_ms']]
    keys=('internal_free','internal_min','internal_block','dma_free','dma_block')
    return dict(outcome='COMPLETED_USB_BASELINE',samples=len(heaps),duration_ms=end['duration_ms'],
                failures=end['failures'],failure_metadata_lost=max(r['metadata_lost'] for r in allocations),
                hook_registered=True,http_requests=end['http'],status_requests=end['status_http'],
                browser_quiet=end['http']==0,
                minimum_observed={key:min(r[key] for r in heaps) for key in keys},
                settled_minimum_observed={key:min(r[key] for r in steady) for key in keys},
                settled_first_ten_median_free=median(r['internal_free'] for r in steady[:10]),
                settled_last_ten_median_free=median(r['internal_free'] for r in steady[-10:]),
                final_internal_free=heaps[-1]['internal_free'],stack_min_free_bytes=stacks,
                queue_peak_sampled=max(r['queue_peak_sampled'] for r in heaps),
                dropped=max(r['dropped'] for r in heaps),truncated=max(r['truncated'] for r in heaps),
                settled_rssi_range=[min(steady_links),max(steady_links)] if steady_links else None,
                bssid_changes=changes,disconnects=disconnects,
                limits='Sampled instrumented baseline; BSSID changes are not proof of connected roaming; no motion, OTA or fault workload certification')

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('capture',type=Path);parser.add_argument('--output',type=Path)
    parser.add_argument('--duration',type=int,choices=(180,600),default=180,help='Expected USB collection seconds')
    args=parser.parse_args()
    try:result=summarize(args.capture.read_text(),expected_duration_ms=args.duration*1000)
    except (OSError,ValueError,KeyError):parser.exit(1,'Incomplete or invalid USB memory evidence; preserve the capture for inspection.\n')
    data=json.dumps(result,indent=2)+'\n'
    if args.output:args.output.write_text(data)
    print(data,end='')

if __name__=='__main__':main()
