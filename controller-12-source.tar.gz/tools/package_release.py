#!/usr/bin/env python3
"""Build an unpublished USB candidate from an isolated Git commit. Never flashes or publishes."""
import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
import zipfile

from check_firmware import validate_partitions
from ota_manifest import manifest_for_build, DEVELOPMENT_MARKER
from version_info import git

SOURCE_PATHS = ['VERSION', 'platformio.ini', 'src', 'include', 'data', 'tools',
                'partitions', 'installer', 'tests', 'docs/INSTALLATION.md', 'docs/RELEASE_NOTES_TEMPLATE.md']
RELEASE_PROFILE = 'web_control_multiturn_usb'
# Explicit source/output allowlist, including the font embedded in the UI.
PACKAGE_NOTICES = ['LICENSE', 'LICENSING.md', 'THIRD_PARTY_NOTICES.md',
                   'LICENSES/CC-BY-4.0.txt', 'LICENSES/CERN-OHL-S-2.0.txt',
                   'docs/licenses/klingon-font.txt', 'docs/licenses/klingon-translations.txt']
ROLES = {'bootloader.bin': 'bootloader', 'partitions.bin': 'partitions',
         'boot_app0.bin': 'boot_selection', 'firmware.bin': 'application'}
OFFSETS = {'bootloader': 0x1000, 'partitions': 0x8000, 'boot_selection': 0xe000, 'application': 0x10000}
FORBIDDEN = {'wifi_local.h', 'ota_local.h', 'ota_dev_local.h', 'seestar_local.h', 'ota_flash_probe_local.h'}


def digest(data, algorithm='sha256'):
    return hashlib.new(algorithm, data).hexdigest()


def read_inputs(build):
    spec = json.loads((build / 'install-inputs.json').read_text())
    if (spec.get('chip'), spec.get('flash_size'), spec.get('flash_mode'), spec.get('flash_freq')) != ('ESP32', '4MB', 'dio', '40m'):
        raise ValueError('Unsupported generated chip/flash configuration')
    components = []
    seen = set()
    for item in spec['components']:
        path = Path(item['path'])
        role = ROLES.get(path.name)
        if role not in OFFSETS or role in seen or item['offset'] != OFFSETS[role]:
            raise ValueError('Unexpected, duplicate or misplaced USB boot component')
        seen.add(role)
        data = path.read_bytes()
        if not data or DEVELOPMENT_MARKER in data:
            raise ValueError('Empty or development credential-bearing USB component')
        components.append(dict(role=role, offset=item['offset'], size=len(data), sha256=digest(data), path=str(path)))
    if seen != set(OFFSETS):
        raise ValueError('Incomplete first install: all boot components are required')
    components.sort(key=lambda item: item['offset'])
    end = 0
    for c in components:
        if c['offset'] < end or c['offset'] + c['size'] > 0x150000:
            raise ValueError('Boot components overlap or exceed the first application slot')
        end = c['offset'] + c['size']
    partition = Path(next(c['path'] for c in components if c['role'] == 'partitions')).read_bytes()
    validate_partitions(partition)
    if len(partition) != 0xc00:
        raise ValueError('Unexpected partition table length')
    if not spec.get('esptool') or not Path(spec['esptool']).is_file():
        raise ValueError('Missing build-selected esptool')
    return spec, components, partition


def assemble(source, build, output, *, pipeline_test=False):
    # Existing production checks reject test/development profiles and credential marker.
    app = manifest_for_build(build, allow_multiturn_usb=True)
    if app.get("profile") != "multiturn_usb":
        raise ValueError("Packaging requires the native multi-turn USB binary descriptor")
    identity = json.loads((build / 'version.json').read_text())
    if not identity.get('release') or identity.get('dirty') or identity.get('profile') != RELEASE_PROFILE:
        raise ValueError('Packaging requires a clean, versioned web_control_multiturn_usb release build')
    if pipeline_test and not re.fullmatch(r'\d+\.\d+\.\d+-(alpha|beta|rc)\.[1-9]\d*', identity.get('version','')):
        raise ValueError('Pipeline tests require an explicit prerelease version')
    for name in PACKAGE_NOTICES:
        if not (source / name).is_file():
            raise ValueError(f'Missing required license/notice: {name}')
    spec, components, partition = read_inputs(build)
    binary = (build / 'firmware.bin').read_bytes()
    encoded = json.dumps(identity, sort_keys=True, separators=(',', ':')).encode()
    if encoded not in binary:
        raise ValueError('Binary does not contain the exact build identity')
    output.mkdir(parents=True, exist_ok=False)
    image_path = output / 'factory.bin'
    command = [sys.executable, spec['esptool'], '--chip', 'esp32', 'merge_bin',
               '--output', str(image_path), '--flash_mode', spec['flash_mode'],
               '--flash_freq', spec['flash_freq'], '--flash_size', spec['flash_size']]
    for c in components:
        command += [hex(c['offset']), c['path']]
    subprocess.run(command, check=True)
    image = image_path.read_bytes()
    previous = 0
    for c in components:
        if image[previous:c['offset']] != b'\xff' * (c['offset'] - previous):
            raise ValueError('Unexpected data in factory-image padding')
        if digest(image[c['offset']:c['offset'] + c['size']]) != c['sha256']:
            raise ValueError('Merged component differs from verified input')
        previous = c['offset'] + c['size']
    if len(image) != previous or DEVELOPMENT_MARKER in image:
        raise ValueError('Unexpected merged image length or credential marker')
    (output / 'partitions.bin').write_bytes(partition)
    components = [{k: v for k, v in c.items() if k != 'path'} for c in components]
    manifest = dict(schema=1, name='Telescope Cover', version=identity['version'], commit=identity['commit'],
                    profile=identity['profile'], chipFamily=spec['chip'], flash_size=spec['flash_size'],
                    flash_size_bytes=0x400000, flash_mode=spec['flash_mode'], flash_freq=spec['flash_freq'],
                    image=dict(path='factory.bin', offset=0, size=len(image), sha256=digest(image), md5=digest(image, 'md5')),
                    partition=dict(path='partitions.bin', offset=0x8000, size=len(partition), sha256=digest(partition)),
                    components=components)
    (output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    # An ESP Web Tools manifest is supplied for interoperability; the project's
    # guarded installer uses manifest.json and esptool-js for same-session reads.
    ewt = dict(name='Telescope Cover', version=identity['version'], new_install_prompt_erase=True,
               builds=[dict(chipFamily='ESP32', parts=[dict(path='factory.bin', offset=0)])])
    (output / 'esp-web-tools-manifest.json').write_text(json.dumps(ewt, indent=2) + '\n')
    for name in ('index.html', 'style.css', 'app.mjs', 'core.mjs'):
        shutil.copyfile(source / 'installer' / name, output / name)
    guide=(source / 'docs/INSTALLATION.md').read_text().replace('(../LICENSING.md)', '(LICENSING.md)')
    (output / 'INSTALLATION.md').write_text(guide)
    notes = (source / 'docs/RELEASE_NOTES_TEMPLATE.md').read_text().replace('<VERSION>', identity['version']).replace('<COMMIT>', identity['commit'])
    if pipeline_test:
        warning = ('# Pipeline-test prerelease — NOT HARDWARE TESTED\n\n'
                   'Owner-authorized private-repository pipeline test. Hardware, browser USB installation, '
                   'servo startup/motion and recovery acceptance were intentionally not performed. '
                   'This is an official versioned build for later supervised evaluation, not a qualified '
                   'hardware release. Dependency clearance remains pending; do not redistribute publicly.\n\n')
        notes = warning + notes.replace('**Unpublished multi-turn candidate', '**Pipeline-test multi-turn prerelease')
        (output / 'PIPELINE_TEST.md').write_text(warning)
        page = output / 'index.html'
        page.write_text(page.read_text().replace('Unpublished candidate installer.', 'Pipeline-test prerelease installer.'))
    (output / 'RELEASE_NOTES.md').write_text(notes)
    for name in PACKAGE_NOTICES:
        destination = output / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source / name, destination)
    (output / 'LICENSE_STATUS.md').write_text(
        '# Candidate licensing status\n\nProject software/documentation license texts and font notices included.\nDependency clearance, framework source/relinking obligations and complete notices remain pending. Public distribution remains blocked; an explicitly authorized pipeline-test prerelease may be retained in the private repository.\n')
    record = dict(**identity, application=app, flash=dict(chip=spec['chip'], size=spec['flash_size'],
                  mode=spec['flash_mode'], frequency=spec['flash_freq']),
                  status='pipeline-test-prerelease' if pipeline_test else 'unpublished-candidate',
                  hardware_acceptance='not-performed' if pipeline_test else 'pending',
                  browser_acceptance='not-performed' if pipeline_test else 'pending',
                  licensing='dependency-review-required',
                  servo_policy='exact_multiturn_ram_startup_usb',
                  support_scope='supervised-prototype', host_qualification='macos-pending',
                  publication_allowed=False,
                  private_pipeline_publication_allowed=bool(pipeline_test),
                  intended_repository_visibility='private' if pipeline_test else 'pending',
                  components=components,
                  tools=dict(platformio=subprocess.check_output([sys.executable, '-m', 'platformio', '--version'], text=True).strip(),
                             platform='espressif32@7.1.3',packages=spec['packages'],browser_loader='esptool-js@0.7.1'))
    (output / 'release.json').write_text(json.dumps(record, indent=2) + '\n')
    # References omitted from the curated download resolve to exact source,
    # while bundled notices stay usable offline at their relative paths.
    for document in output.rglob('*.md'):
        def source_link(match):
            target=match.group(1)
            if '://' in target or target.startswith(('#', 'mailto:')):
                return match.group(0)
            path=target.split('#',1)[0]
            if not path or (document.parent/path).exists():
                return match.group(0)
            from posixpath import normpath
            relative=normpath(str(document.relative_to(output).parent/path))
            return '](' + 'https://github.com/Kbdavis/Telescope-Cover/blob/' + identity['commit'] + '/' + relative + ')'
        document.write_text(re.sub(r'\]\(([^)]+)\)', source_link, document.read_text()))
    checksums = ''.join(f'{digest(p.read_bytes())}  {p.relative_to(output).as_posix()}\n' for p in sorted(output.rglob('*')) if p.is_file())
    (output / 'SHA256SUMS').write_text(checksums)
    return record


def build_candidate(repository, commit, output, pio_python, *, pipeline_test=False):
    repository, output = Path(repository).resolve(), Path(output).resolve()
    package = output.parent / (output.name + '.zip')
    debug = output.parent / (output.name + '-maintainer')
    if any(path.exists() for path in (output, package, debug, package.with_suffix('.zip.sha256'))):
        raise ValueError('Candidate output already exists; choose a new directory')
    # A caller can deliberately package a frozen commit while working elsewhere.
    if commit is None and git(repository, 'status', '--porcelain', '--untracked-files=normal'):
        raise ValueError('Commit source changes first, or explicitly select a frozen --commit')
    commit = git(repository, 'rev-parse', '--verify', (commit or 'HEAD') + '^{commit}')
    with tempfile.TemporaryDirectory(prefix='telescope-release-') as directory:
        source = Path(directory) / 'source'
        source.mkdir()
        tracked = git(repository, 'ls-tree', '-r', '--name-only', commit).splitlines()
        if any(Path(name).name in FORBIDDEN for name in tracked):
            raise ValueError('Source commit tracks private local configuration; refusing release')
        paths = SOURCE_PATHS + PACKAGE_NOTICES
        if any(name not in tracked for name in PACKAGE_NOTICES):
            raise ValueError('Source commit is missing required project/asset license files')
        archive = subprocess.check_output(['git', '-C', str(repository), 'archive', commit, '--', *paths])
        with tarfile.open(fileobj=io.BytesIO(archive)) as bundle:
            # Git source paths only. Reject links rather than following them into
            # the host's credential-bearing include tree or arbitrary paths.
            for entry in bundle.getmembers():
                if entry.issym() or entry.islnk() or Path(entry.name).is_absolute() or '..' in Path(entry.name).parts:
                    raise ValueError('Unsupported source archive link or path')
            bundle.extractall(source, filter='data')
        (source / '.release-source.json').write_text(json.dumps(dict(commit=commit, dirty=False)))
        version = os.environ.get('TELESCOPE_RELEASE_VERSION', '')
        if not version:
            raise ValueError('Set TELESCOPE_RELEASE_VERSION, e.g. 0.1.0-beta.1')
        # Do not inherit build injection flags or local include paths.
        environment = {k: v for k, v in os.environ.items() if not k.startswith(('PLATFORMIO_', 'CPATH', 'CPLUS_INCLUDE_PATH', 'C_INCLUDE_PATH', 'LIBRARY_PATH'))}
        environment['TELESCOPE_RELEASE_VERSION'] = version
        subprocess.run([str(pio_python), str(source / 'tools/validate_release.py')], cwd=source, env=environment, check=True)
        build_result=subprocess.run([str(pio_python), '-m', 'platformio', 'run', '-e', RELEASE_PROFILE],
                                    cwd=source, env=environment, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        print(build_result.stdout)
        build_result.check_returncode()
        build = source / '.pio/build' / RELEASE_PROFILE
        # Use the selected Python for packaging's build-selected esptool as well.
        command = [str(pio_python), str(source / 'tools/package_release.py'), '--assemble', str(source), str(build), str(output)]
        if pipeline_test:
            command.append('--pipeline-test')
        subprocess.run(command, cwd=source, env=environment, check=True)
        # Private debug artifacts are separate from the end-user allowlist.
        debug.mkdir(exist_ok=False)
        (debug / 'build.log').write_text(build_result.stdout)
        (debug / 'source.tar').write_bytes(archive)
        for name in ('firmware.elf', 'firmware.map', 'version.json', 'install-inputs.json'):
            shutil.copyfile(build / name, debug / name)
        with zipfile.ZipFile(package, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
            for file in sorted(output.rglob('*')):
                if file.is_file():
                    archive.write(file, file.relative_to(output).as_posix())
        package.with_suffix('.zip.sha256').write_text(f'{digest(package.read_bytes())}  {package.name}\n')
    print(f'Unpublished candidate: {output}\nZIP: {package}\nNo hardware operation, tag, upload or publication performed.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--commit')
    parser.add_argument('--pipeline-test', action='store_true', help='Label an unqualified prerelease for explicitly authorized private-repository pipeline testing; never authorizes hardware operations')
    parser.add_argument('--output', type=Path, default=Path('dist/telescope-cover-candidate'))
    parser.add_argument('--pio-python', type=Path, default=Path(sys.executable))
    parser.add_argument('--assemble', nargs=3, metavar=('SOURCE', 'BUILD', 'OUTPUT'), help=argparse.SUPPRESS)
    args = parser.parse_args()
    try:
        if args.assemble:
            assemble(*(Path(item).resolve() for item in args.assemble), pipeline_test=args.pipeline_test)
        else:
            build_candidate(Path(__file__).resolve().parents[1], args.commit, args.output, args.pio_python, pipeline_test=args.pipeline_test)
    except (ValueError, OSError, KeyError, subprocess.CalledProcessError) as error:
        parser.exit(1, f'Release packaging failed: {error}\n')


if __name__ == '__main__':
    main()
