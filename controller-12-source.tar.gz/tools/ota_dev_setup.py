"""Provision persistent, ignored local development OTA credentials. No device access."""
import argparse
import os
from pathlib import Path
import secrets
import stat

from ota_upload import WorkflowError,load_secret

ROOT=Path(__file__).resolve().parents[1]


def header_for(secret):
    return ('#pragma once\n// Local development only; never commit or distribute this header/binary.\n'
        '#define COVER_OTA_RECEIVER_ENABLED 1\n'
        '#define COVER_OTA_SECRET "'+secret.decode('ascii')+'"\n'
        '// Provisional supervised development guards; production margin remains deferred.\n'
        '#define COVER_OTA_MIN_INTERNAL_HEAP 98304\n'
        '#define COVER_OTA_MIN_LARGEST_BLOCK 65536\n')


def provision(root):
    root=Path(root);directory=root/'.ota-dev';header=root/'include/ota_dev_local.h';credential=directory/'secret'
    if directory.is_symlink():raise WorkflowError('Development credential directory must not be a symlink')
    if directory.exists():
        info=directory.stat()
        if not stat.S_ISDIR(info.st_mode) or info.st_uid!=os.geteuid():
            raise WorkflowError('Development credential directory must be owned by this user')
    directory.mkdir(mode=0o700,exist_ok=True);directory.chmod(0o700)
    if header.exists() or header.is_symlink() or credential.exists() or credential.is_symlink():
        secret=load_secret(credential)
        info=header.lstat()
        if (not stat.S_ISREG(info.st_mode) or info.st_uid!=os.geteuid() or info.st_mode&0o077
                or info.st_nlink!=1 or header.read_text()!=header_for(secret)):
            raise WorkflowError('Existing development header/credential mismatch; nothing was overwritten')
        return False
    secret=secrets.token_hex(32).encode('ascii');created=[]
    try:
        for path,content in [(credential,secret.decode()+'\n'),(header,header_for(secret))]:
            with open(path,'x',opener=lambda name,flags:os.open(name,flags,0o600)) as f:
                created.append(path);f.write(content)
    except OSError:
        for path in reversed(created):path.unlink()
        raise WorkflowError('Could not provision private development files') from None
    return True


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.parse_args()
    try:
        created=provision(ROOT)
        print('Development OTA credential/header '+('created' if created else 'already match')+'. Secret value was not printed.')
        print('Build web_control_dev; bootstrap over USB. Keep the cover supported and torque OFF for uploads.')
    except (OSError,WorkflowError):parser.exit(1,'Development provisioning stopped; existing files were not overwritten. Check .ota-dev/secret and include/ota_dev_local.h.\n')


if __name__=='__main__':main()
