#!/usr/bin/env python3
"""Explicitly invoked, supervised ±10-count web bench checks. Moves real hardware."""
import argparse
import json
import re
import time
import urllib.request
import urllib.error

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--url', required=True)
parser.add_argument('--case', choices=['round-trip', 'stop', 'heartbeat-loss'], required=True)
parser.add_argument('--direction', choices=['plus', 'minus'], default='plus')
parser.add_argument('--mechanism-clear', action='store_true', required=True)
args = parser.parse_args()
raise SystemExit('Historical 10-count test disabled: live jog size is now 100. Update test scope and obtain clearance before use.')
base = args.url.rstrip('/')

def request(path, data=None, headers=None):
    req = urllib.request.Request(base + path, data=data, headers=headers or {})
    with urllib.request.urlopen(req, timeout=2) as response:
        return response.read().decode()

page = request('/')
token = re.search(r"const token='([a-f0-9]{32})'", page).group(1)
headers = {'X-Cover-Token': token, 'X-Cover-Client': '876543210',
           'Content-Type': 'application/x-www-form-urlencoded'}

def status():
    return json.loads(request('/api/status'))

def post(path, body=''):
    request('/api/' + path, body.encode(), headers)

def start(direction):
    s = status()
    assert s['ready'] and not s['moving'] and s['torque'] is False, s
    assert s['position'] is not None and s['age_ms'] < 1500, s
    target = s['position'] + (10 if direction == 'plus' else -10)
    assert 2015 <= target <= 2075, target
    print('START', json.dumps(s), 'target', target, flush=True)
    post('jog-' + direction, 'clear=yes')
    return target

def wait_for_end(heartbeat=True, send_stop=False):
    deadline = time.monotonic() + 7
    seen_moving = False
    stop_sent = False
    last = None
    while time.monotonic() < deadline:
        if heartbeat:
            post('heartbeat')
        s = status()
        if s != last:
            print('STATUS', json.dumps(s), flush=True)
            last = s
        seen_moving |= s['moving']
        if send_stop and s['moving'] and not stop_sent:
            post('stop')
            stop_sent = True
        if (seen_moving or s['state'] == 'FAULT') and not s['moving'] and s['torque'] is False:
            if send_stop:
                assert stop_sent, 'STOP was not sent during motion'
            return s
        time.sleep(.05)
    raise RuntimeError('Did not observe completion and torque OFF')

try:
    target = start(args.direction)
    s = wait_for_end(heartbeat=args.case != 'heartbeat-loss', send_stop=args.case == 'stop')
    if args.case == 'round-trip':
        assert s['state'] == 'STOPPED' and abs(s['position'] - target) <= 3, s
        target = start('minus' if args.direction == 'plus' else 'plus')
        s = wait_for_end()
        assert s['state'] == 'STOPPED' and abs(s['position'] - target) <= 3, s
        print('PASS: both steps settled and torque OFF')
    elif args.case == 'stop':
        assert s['state'] == 'STOPPED', s
        print('PASS: explicit Stop during motion; torque OFF')
    else:
        if s['state'] != 'FAULT':
            raise RuntimeError('INCONCLUSIVE: step completed before heartbeat expiry; no safety-fault claim')
        assert s['fault'] == 'Safety interlock' and not s['ready'], s
        time.sleep(.7)
        latched = status()
        assert latched['state'] == 'FAULT' and latched['torque'] is False, latched
        try:
            post('jog-plus', 'clear=yes')
        except urllib.error.HTTPError as error:
            assert error.code == 409, error
        else:
            raise RuntimeError('Faulted controller accepted another jog')
        post('stop')
        time.sleep(.2)
        assert status()['state'] == 'FAULT', 'Stop unexpectedly cleared fault'
        print('PASS: missing heartbeat latched FAULT and torque OFF; further jog rejected; Stop preserves fault')
finally:
    try:
        post('stop')
    except Exception as error:
        print('Could not deliver final Stop:', error, flush=True)
