"""One read-only status client during a timed USB memory experiment.

Waits for 20 seconds of device uptime, polls at most once per second for
20 seconds, then observes USB only until collection ends. Never subscribes
metrics, changes settings, commands motion or performs an OTA operation.
"""
import argparse
from datetime import datetime,timezone
import ipaddress
import json
from pathlib import Path
import re
import socket
from statistics import median
import time
from ota_manifest import manifest_for_build
from ota_upload import LocalHttp,WorkflowError,hex_id
from summarize_usb_memory import FRAME,summarize

def check_state(s,firmware,boot=None):
    ota=s.get('ota',{});resources=s.get('resources',{})
    if (ota.get('firmware_id')!=firmware or ota.get('startup')!='accepted'
            or ota.get('available') is not False or ota.get('active') is not False
            or not hex_id(ota.get('boot_id'),32) or (boot and ota['boot_id']!=boot)
            or s.get('ready') is not True or s.get('moving') is not False or s.get('torque') is not False
            or s.get('dirty') is not False or s.get('calibrated') is not True
            or type(s.get('uptime_ms')) is not int or not 0<=s['uptime_ms']<=0xffffffff
            or s.get('maintenance',{}).get('locked') is not False
            or resources.get('state')!='off' or resources.get('viewers')!=0):
        raise WorkflowError('Identity, readiness, OFF or exclusive metrics conditions changed')
    return ota['boot_id']

def compare(text,responses,attempts,quiet_seconds):
    summary=summarize(text)
    if not responses or quiet_seconds<125:raise WorkflowError('Insufficient responses or quiet recovery')
    times=[s['uptime_ms'] for s in responses];heaps=[]
    for line in text.splitlines():
        m=FRAME.search(line)
        if m and m[2]=='heap':
            fields=dict(p.split('=',1) for p in m[3].split());heaps.append((int(m[1]),int(fields['internal_free'])))
    before=[free for at,free in heaps if 10000<=at<min(times)]
    load=[free for at,free in heaps if min(times)-1000<=at<=max(times)+1000]
    if len(before)<3 or not load:raise WorkflowError('Missing baseline/load USB samples')
    recovered=[free for _,free in heaps[-10:]]
    isolated=summary['http_requests']==attempts and summary['status_requests']==attempts
    summary.pop('browser_quiet') # Intentional client traffic is expected here.
    summary.update(outcome='COMPLETED_CONTROLLED_HTTP' if isolated else 'COMPLETED_HTTP_WITH_EXTRA_TRAFFIC',
                   controlled_client_only=isolated,attempts=attempts,responses=len(responses),quiet_recovery_seconds=quiet_seconds,
                   before_median_free=median(before),load_minimum_sampled_free=min(load),
                   recovered_last_ten_median_free=median(recovered),
                   median_recovered_change=median(recovered)-median(before))
    return summary

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--host',required=True,type=ipaddress.IPv4Address)
    p.add_argument('--build-dir',required=True,type=Path)
    p.add_argument('--capture',required=True,type=Path)
    p.add_argument('--output',required=True,type=Path)
    p.add_argument('--supported-cover-off',action='store_true');args=p.parse_args()
    if not args.supported_cover_off:p.error('Supported-cover/OFF confirmation required')
    args.output.mkdir(mode=0o700,parents=True,exist_ok=True)
    try:
        manifest=manifest_for_build(args.build_dir,allow_test_profile=True)
        if manifest['profile']!='test_profile':raise WorkflowError('Expected USB test image')
        def capture():
            try:return args.capture.read_text()
            except FileNotFoundError:return ''
        deadline=time.monotonic()+45
        while time.monotonic()<deadline:
            text=capture();samples=re.findall(r'\[(\d+)\] USBMEM heap ',text)
            if samples and int(samples[-1])>=20000:break
            time.sleep(.1)
        else:raise WorkflowError('USB settled-window wait expired')
        if int(samples[-1])>25000 or ' USBMEM end ' in text:raise WorkflowError('Missed workload start; never restart automatically')
        if 'elf_sha256='+manifest['elf'] not in text:raise WorkflowError('USB firmware identity mismatch')
        with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as route:
            route.connect((str(args.host),80));local=route.getsockname()[0]
        http=LocalHttp(str(args.host),local);boot=None;responses=[];attempts=0;error=None
        with (args.output/'requests.jsonl').open('w',buffering=1) as log:
            start=time.monotonic();next_at=start
            while time.monotonic()<start+20:
                delay=next_at-time.monotonic()
                if delay>0:time.sleep(delay)
                if time.monotonic()>=start+20:break
                next_at=time.monotonic()+1;attempts+=1
                try:
                    code,s=http.request('GET','/api/status')
                    if code!=200:raise WorkflowError('Status request rejected')
                    boot=check_state(s,manifest['elf'],boot);responses.append(s)
                    log.write(json.dumps(dict(utc=datetime.now(timezone.utc).isoformat(),status=s))+'\n')
                except WorkflowError as e:
                    error=str(e);log.write(json.dumps(dict(error=error))+'\n');break
        quiet_start=time.monotonic();print('HTTP stopped; observing USB-only recovery',flush=True)
        deadline=quiet_start+170
        while time.monotonic()<deadline:
            text=capture()
            if re.search(r'\[\d+\] USBMEM end [^\n]*\n',text):break
            time.sleep(.1)
        else:raise WorkflowError('USB completion missing; no automatic retry')
        quiet=time.monotonic()-quiet_start
        result=compare(text,responses,attempts,quiet)
        if error:result.update(outcome='HTTP_STOPPED_EARLY',error=error)
        (args.output/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
        print(json.dumps(result,indent=2))
    except (OSError,ValueError,KeyError,WorkflowError,KeyboardInterrupt):
        p.exit(1,'Controlled client stopped or evidence incomplete. No automatic retry; preserve USB evidence and restore production.\n')

if __name__=='__main__':main()
