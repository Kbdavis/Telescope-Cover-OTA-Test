"""Supervised partial-stream drop, authenticated cancel and same-boot retry test.

Install a temporary receiver-enabled source over USB first. This test driver
owns USB passively. Only --stop-experiment sends an explicit Stop; it never
sends motion, settings or metrics requests. Its final
successful retry activates the payload. Restore original slots/otadata afterward.
"""
import argparse
import http.client
import ipaddress
import json
from pathlib import Path
import socket
import time

from ota_upload import Artifact, EspotaTransfer, LocalHttp, Uploader, WorkflowError, load_secret
from probe_ota_activation import UsbMonitor, RecordingHttp, safe_status


class FaultTransfer(EspotaTransfer):
    def __init__(self,host,local_ip,monitor,mode,record,stop_after=65536):
        if mode not in ('drop','cancel','stop','complete') or stop_after<=0 or stop_after%1024:
            raise ValueError('Bounded mid-stream fault configuration required')
        super().__init__(host,local_ip,progress=self.after_ack)
        self.monitor=monitor;self.mode=mode;self.record=record;self.stop_after=stop_after
        self.injected=False;self.owner=None;self.secret=b''
    def send(self,artifact,secret):
        if self.mode!='complete' and self.stop_after>=len(artifact.image):
            raise WorkflowError('Fault must precede image completion')
        self.secret=secret
        try:super().send(artifact,secret)
        finally:self.secret=b''
    def after_ack(self,sent,total):
        self.monitor.progress()
        if self.mode=='complete' or self.injected or sent<self.stop_after:return
        if sent!=self.stop_after or sent>=total:raise WorkflowError('Fault boundary changed')
        status=self.owner.get('/api/ota/status')
        if (status.get('boot_id')!=self.owner.boot or status.get('transaction')!=self.owner.transaction
                or status.get('phase')!='receiving' or status.get('active') is not True
                or status.get('received')!=sent):raise WorkflowError('Mid-stream transaction changed')
        self.injected=True
        self.record('inject',dict(mode=self.mode,acknowledged_bytes=sent,total_bytes=total,
                                  transaction=self.owner.transaction,boot_id=self.owner.boot))
        if self.mode=='stop':
            before=self.owner.get('/api/status')
            if (before.get('ota',{}).get('boot_id')!=self.owner.boot
                    or before.get('ota',{}).get('transaction')!=self.owner.transaction
                    or before.get('moving') is not False or before.get('torque') is not False):
                raise WorkflowError('Stop safety/identity changed')
            epoch=before.get('emergency',{}).get('stop_epoch')
            if type(epoch) is not int:raise WorkflowError('Stop epoch unavailable')
            self.owner.explicit_stop()
            self.record('stop_accepted',dict(transaction=self.owner.transaction,previous_stop_epoch=epoch))
            deadline=time.monotonic()+12
            while time.monotonic()<deadline:
                self.monitor.progress();s=self.owner.get('/api/status');ota=s.get('ota',{})
                if ota.get('boot_id')!=self.owner.boot or ota.get('transaction')!=self.owner.transaction:
                    raise WorkflowError('Stop transaction changed')
                if ota.get('active') is False:
                    if (ota.get('phase')!='failed' or ota.get('reason')!='maintenance_clearance_lost'
                            or s.get('torque') is not False or s.get('moving') is not False
                            or s.get('emergency',{}).get('stop_epoch')!=epoch+1):
                        raise WorkflowError('Stop cleanup/epoch evidence changed')
                    if s.get('maintenance',{}).get('locked') is False:
                        self.record('stopped_while_socket_open',dict(transaction=self.owner.transaction,
                            stop_epoch=epoch+1))
                        break
                time.sleep(.05)
            else:raise WorkflowError('Stop cleanup timed out')
        if self.mode=='cancel':
            code,_=self.owner.signed('/api/ota/cancel',
                ('transaction='+self.owner.transaction+'\n').encode('ascii'),
                self.secret,self.owner.boot,self.owner.transaction)
            if code!=202:raise WorkflowError('Explicit cancellation not accepted')
            self.record('cancel_accepted',dict(transaction=self.owner.transaction))
            # Keep the data connection open until the receiver has cancelled and
            # released maintenance. Do not make EOF the cause of cancellation.
            deadline=time.monotonic()+12
            while time.monotonic()<deadline:
                self.monitor.progress();s=self.owner.poll()
                if (s.get('boot_id')!=self.owner.boot or s.get('transaction')!=self.owner.transaction):
                    raise WorkflowError('Cancellation transaction changed')
                if s.get('active') is False:
                    if s.get('phase')!='cancelled':raise WorkflowError('Receiver did not cancel')
                    self.record('cancelled_while_socket_open',dict(transaction=self.owner.transaction))
                    break
            else:raise WorkflowError('Cancellation cleanup timed out')
        # EspotaTransfer's connection context closes here. For drop this is
        # the only injected action; no automatic signed cancellation follows.
        raise WorkflowError('Deliberate partial-stream injection')


class FaultUploader(Uploader):
    def __init__(self,http,transfer,record):
        super().__init__(http,transfer);transfer.owner=self
        self.record=record;self.boot='';self.transaction=''
    def signed(self,route,body,secret,boot,transaction=''):
        code,value=super().signed(route,body,secret,boot,transaction)
        if route=='/api/ota/prepare' and code==202 and isinstance(value,dict):
            self.boot=boot;self.transaction=value.get('transaction','')
        return code,value
    def explicit_stop(self):
        session=self.get('/api/session')
        if session.get('boot_id')!=self.boot or not isinstance(session.get('token'),str) or not session['token']:
            raise WorkflowError('Stop session changed')
        connection=http.client.HTTPConnection(self.transfer.host,80,timeout=2,
            source_address=(self.transfer.local_ip,0))
        try:
            connection.request('POST','/api/stop',body=b'',headers={
                'X-Cover-Token':session['token'],'X-Cover-Client':'731092',
                'Content-Type':'application/x-www-form-urlencoded'})
            response=connection.getresponse()
            if response.status!=202:raise WorkflowError('Explicit Stop rejected')
            if len(response.read(4097))>4096:raise WorkflowError('Oversized Stop response')
        except (OSError,http.client.HTTPException):
            raise WorkflowError('Explicit Stop delivery unconfirmed') from None
        finally:connection.close()
    def cancel_before_commit(self,transaction,secret,boot):
        if self.transfer.injected:
            self.record('automatic_cancel_suppressed',dict(mode=self.transfer.mode,transaction=transaction))
            return
        super().cancel_before_commit(transaction,secret,boot)


def verify_fault_cleanup(status,source,target,boot,transaction,expected):
    ota=status.get('ota',{});record=ota.get('last_update',{})
    if (status.get('firmware_id')!=source or ota.get('boot_id')!=boot
            or ota.get('phase')!=expected.lower() or ota.get('outcome')!=expected.lower()
            or ota.get('active') is not False or record.get('transaction')!=transaction
            or record.get('source_firmware')!=source or record.get('target_firmware')!=target
            or record.get('source_slot')!=0x10000 or record.get('target_slot')!=0x150000
            or record.get('selection_confirmed') is not False or ota.get('received')!=65536):
        raise WorkflowError('Partial transfer cleanup/identity/selection evidence changed')


def wait_cleanup(http,expected,monitor):
    # A terminal journal checkpoint can precede maintenance release. Do not
    # mistake that intermediate observation for completed cleanup.
    deadline=time.monotonic()+10
    while True:
        monitor.progress()
        try:
            status=safe_status(http,expected)
            if status['ota'].get('active') is False:return status
        except (WorkflowError,OSError):pass
        if time.monotonic()>=deadline:raise WorkflowError('Safe maintenance cleanup unconfirmed')
        time.sleep(1)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host',required=True,type=ipaddress.IPv4Address)
    parser.add_argument('--port',required=True)
    parser.add_argument('--source-build-dir',required=True,type=Path)
    parser.add_argument('--payload-build-dir',required=True,type=Path)
    parser.add_argument('--secret-file',required=True,type=Path)
    parser.add_argument('--supported-cover-off',action='store_true')
    parser.add_argument('--run-interruption-experiment',action='store_true')
    parser.add_argument('--output',required=True,type=Path)
    parser.add_argument('--stop-experiment',action='store_true',help='Explicit Stop and subsequent complete upload instead of drop/cancel')
    args=parser.parse_args()
    if not args.supported_cover_off or not args.run_interruption_experiment:
        parser.error('Explicit supported-cover/OFF and interruption experiment flags required')
    monitor=None
    try:
        source=Artifact.load(args.source_build_dir);payload=Artifact.load(args.payload_build_dir)
        source_id,target_id=source.manifest['elf'],payload.manifest['elf']
        if source_id==target_id:raise WorkflowError('Distinct source/payload required')
        secret=load_secret(args.secret_file);args.output.mkdir(parents=True,exist_ok=True,mode=0o700)
        with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as route:
            route.connect((str(args.host),80));local_ip=route.getsockname()[0]
        monitor=UsbMonitor(args.port,args.output);monitor.start() # Reset gate remains unarmed.
        with (args.output/'status.jsonl').open('w',buffering=1) as log, (args.output/'actions.jsonl').open('w',buffering=1) as events:
            def record(kind,data):
                events.write(json.dumps(dict(at=time.monotonic(),kind=kind,data=data))+'\n')
            http=RecordingHttp(LocalHttp(str(args.host),local_ip),log)
            deadline=time.monotonic()+35
            while True:
                try:initial=safe_status(http,source_id);break
                except (WorkflowError,OSError):
                    if time.monotonic()>=deadline:raise WorkflowError('Source startup unconfirmed')
                    time.sleep(1)
            boot=initial['ota']['boot_id'];results=[]
            stages=[('stop','FAILED'),('complete','COMPLETE')] if args.stop_experiment else [('drop','FAILED'),('cancel','CANCELLED'),('complete','COMPLETE')]
            for mode,expected in stages:
                monitor.progress();before=safe_status(http,source_id)
                if before['ota']['boot_id']!=boot:raise WorkflowError('Unexpected source reboot between attempts')
                sender=FaultTransfer(str(args.host),local_ip,monitor,mode,record)
                result=FaultUploader(http,sender,record).run(payload,secret,supported_cover_off=True)
                item=dict(mode=mode,outcome=result.outcome,transaction=result.transaction,injected=sender.injected)
                results.append(item);(args.output/'results.json').write_text(json.dumps(results,indent=2)+'\n')
                print(json.dumps(item),flush=True)
                if result.outcome!=expected:raise WorkflowError('Unexpected outcome; no automatic repeat')
                final=wait_cleanup(http,target_id if mode=='complete' else source_id,monitor)
                if mode!='complete':
                    if not sender.injected:raise WorkflowError('Fault not injected')
                    verify_fault_cleanup(final,source_id,target_id,boot,result.transaction,expected)
                else:
                    if final['ota']['boot_id']==boot:raise WorkflowError('Successful retry did not boot candidate')
                (args.output/(mode+'-status.json')).write_text(json.dumps(final,indent=2)+'\n')
            if len({r['transaction'] for r in results})!=len(stages):raise WorkflowError('Transactions were reused')
            if monitor.error or monitor.gate.fired:raise WorkflowError('USB failure or unexpected reset injection')
        print('Planned fault injection and subsequent same-boot update verified; USB restoration required.',flush=True)
    except (OSError,ValueError,WorkflowError,KeyboardInterrupt):
        parser.exit(1,'Interruption experiment stopped or unconfirmed. Preserve evidence and restore original slots/otadata over USB; no automatic repeat.\n')
    finally:
        if monitor is not None:monitor.close()


if __name__=='__main__':main()
