"""Secret-safe OTA workflow. Production upload is gated; upload-dev is explicit.

The engine is exercised with local fixtures. It never launches espota, accepts
raw credentials on the command line, prints remote bodies, or drives actuators.
"""
import argparse
from dataclasses import dataclass, field
import hashlib
import http.client
import ipaddress
import json
import os
from pathlib import Path
import re
import secrets
import socket
import stat
import time

from check_firmware import OTA_UPLOAD_DISABLED
from ota_manifest import DEVELOPMENT_MARKER, control_mac, inspect_image, manifest_for_build, prepare_body


class WorkflowError(Exception):
    """Fixed local messages only: never include remote bodies or credentials."""


def hex_id(value, size):
    return isinstance(value, str) and re.fullmatch('[0-9a-f]{%d}' % size, value) is not None


def load_secret(path):
    """Read an owner-only regular file; never accept a secret in argv or env.

    Provision separately. One optional terminal LF is a file terminator, not
    part of the firmware credential. Reject symlinks and shared permissions.
    """
    try:
        descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        with os.fdopen(descriptor, 'rb') as source:
            info = os.fstat(source.fileno())
            if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.geteuid()
                    or info.st_mode & 0o077 or info.st_nlink != 1 or info.st_size > 129):
                raise WorkflowError('Credential file must be private and owned by this user')
            secret = source.read(130).removesuffix(b'\n')
        if not 32 <= len(secret) <= 128 or any(byte < 33 or byte > 126 for byte in secret):
            raise WorkflowError('Credential file must contain 32..128 printable non-space ASCII bytes')
        return secret
    except OSError:
        raise WorkflowError('Cannot read private credential file') from None


@dataclass(frozen=True)
class Artifact:
    image: bytes = field(repr=False)
    def __post_init__(self):
        if type(self.image) is not bytes:
            raise WorkflowError('Artifact must contain immutable binary bytes')
    # Compute metadata from these exact immutable bytes, not a caller's manifest.
    @property
    def manifest(self):
        return inspect_image(self.image)

    @classmethod
    def load(cls, directory):
        image = (Path(directory) / 'firmware.bin').read_bytes()
        # Artifact inspection serves the explicit development client too;
        # production release validation keeps its stricter default.
        manifest = manifest_for_build(directory,allow_development=True)
        if inspect_image(image) != manifest:
            raise WorkflowError('Artifact changed during validation')
        return cls(image)


class LocalHttp:
    """Literal IPv4, no proxy/redirect/DNS, one pinned source for both protocols."""
    def __init__(self, host, local_ip, port=80):
        self.host = str(ipaddress.IPv4Address(host))
        self.local_ip = str(ipaddress.IPv4Address(local_ip))
        self.port = port

    def request(self, method, route, body=None, headers=None):
        connection = http.client.HTTPConnection(self.host, self.port, timeout=2,
                                                source_address=(self.local_ip, 0))
        try:
            connection.request(method, route, body=body, headers=headers or {})
            response = connection.getresponse()
            limit = 16384 if route == '/api/status' else (8192 if route == '/api/ota/probe/memory' else 4096)
            data = response.read(limit + 1)
            if len(data) > limit:
                raise WorkflowError('Oversized controller response')
            if response.status not in (200, 202):
                # Discard controller text, which may reflect request values.
                return response.status, None
            if route == '/api/ota/cancel':
                return response.status, None
            result = json.loads(data)
            if not isinstance(result, dict):
                raise WorkflowError('Invalid controller response')
            return response.status, result
        except (OSError, ValueError, http.client.HTTPException):
            raise WorkflowError('Controller HTTP request failed') from None
        finally:
            connection.close()


class EspotaTransfer:
    """In-process espota handshake; credential and verifiers never leave memory.

    Caller polls status before/after transfer. During transfer there is no bulk
    log or optional metrics traffic. Both transports use the HTTP source IP.
    """
    def __init__(self, host, local_ip, udp_port=3232, progress=None, final_result=b'OK'):
        if final_result not in (b'OK', b'NOACT'):
            raise WorkflowError('Unsupported transfer result contract')
        self.host = str(ipaddress.IPv4Address(host))
        self.local_ip = str(ipaddress.IPv4Address(local_ip))
        self.udp_port = udp_port
        self.listener = None
        self.progress = progress
        self.final_result = final_result

    def __enter__(self):
        self.listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            self.listener.bind((self.local_ip, 0))
            self.listener.listen(1)
            self.listener.settimeout(3)
        except OSError:
            self.listener.close()
            raise WorkflowError('Cannot open OTA callback listener') from None
        return self

    def __exit__(self, *_):
        self.listener.close()

    @staticmethod
    def exact(connection, size, deadline):
        data = bytearray()
        while len(data) < size:
            remaining = min(3, deadline - time.monotonic())
            if remaining <= 0:
                raise WorkflowError('OTA transfer deadline exceeded')
            connection.settimeout(remaining)
            part = connection.recv(size - len(data))
            if not part:
                raise WorkflowError('OTA connection closed before acknowledgement')
            data.extend(part)
        return bytes(data)

    def send(self, artifact, secret):
        manifest = artifact.manifest
        peer = (self.host, self.udp_port)
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as udp:
                udp.bind((self.local_ip, 0))
                udp.connect(peer)  # Kernel filters responses to the pinned receiver.
                udp.settimeout(3)
                invite = f'0 {self.listener.getsockname()[1]} {len(artifact.image)} {manifest["md5"]}\n'
                udp.send(invite.encode('ascii'))
                auth = udp.recv(128)
                if not re.fullmatch(rb'AUTH [0-9a-f]{32}', auth):
                    raise WorkflowError('OTA transfer authentication rejected')
                nonce = auth[5:].decode('ascii')
                cnonce = secrets.token_hex(16)
                password_md5 = hashlib.md5(secret).hexdigest()
                response = hashlib.md5(f'{password_md5}:{nonce}:{cnonce}'.encode('ascii')).hexdigest()
                udp.send(f'200 {cnonce} {response}\n'.encode('ascii'))
                if udp.recv(128) != b'OK':
                    raise WorkflowError('OTA transfer authentication rejected')
            connection, address = self.listener.accept()
            with connection:
                if address[0] != self.host:
                    raise WorkflowError('Unexpected OTA callback peer')
                deadline = time.monotonic() + 180
                for start in range(0, len(artifact.image), 1024):
                    chunk = artifact.image[start:start + 1024]
                    remaining = min(3, deadline - time.monotonic())
                    if remaining <= 0:
                        raise WorkflowError('OTA transfer deadline exceeded')
                    connection.settimeout(remaining)
                    connection.sendall(chunk)
                    expected = str(len(chunk)).encode('ascii')
                    if self.exact(connection, len(expected), deadline) != expected:
                        raise WorkflowError('Invalid OTA block acknowledgement')
                    if self.progress:
                        self.progress(start + len(chunk), len(artifact.image))
                # Selection acknowledgement is not the deployment verdict.
                if self.exact(connection, len(self.final_result), deadline) != self.final_result:
                    raise WorkflowError('OTA activation acknowledgement missing')
        except OSError:
            raise WorkflowError('OTA transfer interrupted; activation may be unconfirmed') from None


@dataclass(frozen=True)
class Result:
    outcome: str
    transaction: str = ''


class Uploader:
    """Finite workflow with injected transport/time for fault tests.

    This engine has no public live CLI until the hardware release gates pass.
    Production requires CLOSED; advertised development policy permits any
    stationary position. No actuator,
    browser-session, metrics-subscription or settings request is ever issued.
    """
    def __init__(self, http, transfer, *, clock=time.monotonic, sleep=time.sleep):
        self.http, self.transfer, self.clock, self.sleep = http, transfer, clock, sleep
        self.last_poll = float('-inf')

    def get(self, route):
        code, value = self.http.request('GET', route)
        if code != 200 or not isinstance(value, dict):
            raise WorkflowError('Controller status unavailable')
        return value

    def poll(self):
        self.sleep(max(0, 1 - (self.clock() - self.last_poll)))
        self.last_poll = self.clock()
        return self.get('/api/ota/status')

    def signed(self, route, body, secret, boot, transaction=''):
        # Bounded retry for the device's global one-per-second challenge limit.
        for attempt in range(3):
            code, challenge = self.http.request('GET', '/api/ota/challenge')
            if code != 429:
                break
            self.sleep(1)
        if (code != 200 or not isinstance(challenge, dict) or challenge.get('schema') != 1
                or challenge.get('boot_id') != boot or not hex_id(challenge.get('nonce'), 32)
                or challenge.get('expires_ms') != 10000):
            raise WorkflowError('Fresh boot-bound OTA challenge unavailable')
        nonce = challenge['nonce']
        mac = control_mac(secret, 'POST', route, boot, nonce, transaction, body)
        return self.http.request('POST', route, body,
                                 {'Content-Type': 'text/plain', 'Content-Length': str(len(body)),
                                  'X-Ota-Nonce': nonce, 'X-Ota-Mac': mac})

    @staticmethod
    def verdict(status, transaction, source, target, boot):
        record = status.get('last_update')
        if not isinstance(record, dict):
            return None
        if (record.get('schema') != 1 or record.get('transaction') != transaction
                or record.get('source_firmware') != source or record.get('target_firmware') != target
                or {record.get('source_slot'), record.get('target_slot')} != {0x10000, 0x150000}):
            return None
        outcome = record.get('outcome')
        if outcome == 'complete':
            if (record.get('selection_confirmed') is True and status.get('startup') == 'accepted'
                    and status.get('firmware_id') == target and hex_id(status.get('boot_id'), 32)
                    and status['boot_id'] != boot):
                return 'COMPLETE'
        elif outcome == 'rolled_back':
            if (record.get('selection_confirmed') is True and status.get('startup') == 'accepted'
                    and status.get('firmware_id') == source and hex_id(status.get('boot_id'), 32)
                    and status['boot_id'] != boot):
                return 'ROLLED_BACK'
        elif outcome in ('failed', 'cancelled', 'unconfirmed'):
            return outcome.upper()
        return None

    def reconcile(self, transaction, source, target, boot, duration=60):
        deadline = self.clock() + duration
        while self.clock() < deadline:
            try:
                status = self.poll()
                result = self.verdict(status, transaction, source, target, boot)
                if result:
                    return Result(result, transaction)
                if (status.get('boot_id') == boot and status.get('transaction') == transaction
                        and status.get('active') is False and status.get('phase') in ('failed', 'cancelled')):
                    return Result(status['phase'].upper(), transaction)
            except WorkflowError:
                pass
        return Result('UNCONFIRMED', transaction)

    def cancel_before_commit(self, transaction, secret, boot):
        # No guessing after connection loss/reboot or entry to the commit fence.
        try:
            state = self.poll()
            if (state.get('boot_id') == boot and state.get('transaction') == transaction
                    and state.get('active') is True and state.get('phase') in
                    ('preparing', 'armed', 'authenticating', 'connecting', 'receiving', 'verified')):
                self.signed('/api/ota/cancel', f'transaction={transaction}\n'.encode('ascii'),
                            secret, boot, transaction)
        except WorkflowError:
            pass

    def admission_policy(self, status, closed_cover):
        if closed_cover is not True:
            raise WorkflowError('Closed cover confirmation required by installed firmware')
        return 'closed-cover'

    def run(self, artifact, secret, *, closed_cover=False):
        if not isinstance(secret, bytes) or not 32 <= len(secret) <= 128:
            raise WorkflowError('Valid credential required')
        if any(byte < 33 or byte > 126 for byte in secret):
            raise WorkflowError('Credential must contain printable non-space ASCII')
        if type(self) is Uploader:
            self.admission_policy({}, closed_cover)
        manifest = artifact.manifest  # Validate before creating any network resources.
        transaction = ''
        status = self.get('/api/status')
        ota = status.get('ota', {})
        policy = self.admission_policy(status, closed_cover)
        recovery = policy == 'development-recovery'
        if (not isinstance(ota, dict) or ota.get('available') is not True
                or ota.get('startup') != 'accepted' or ota.get('active') is not False
                or ota.get('phase') not in ('idle', 'failed', 'cancelled') or status.get('moving') is not False
                or type(status.get('torque')) is not bool or (policy == 'closed-cover' and status.get('state') != 'CLOSED')
                or status.get('holding') is True
                or (recovery and (status.get('torque') is not False or status.get('holding') is not False))
                or (not recovery and (status.get('state') == 'FAULT' or status.get('dirty') is not False
                                      or status.get('calibrated') is not True or status.get('ready') is not True))
                or type(status.get('age_ms')) is not int or not 0 <= status['age_ms'] <= 1000
                or not hex_id(ota.get('boot_id'), 32) or not hex_id(ota.get('firmware_id'), 64)):
            raise WorkflowError('Controller is not ready for stationary OTA')
        boot, source = ota['boot_id'], ota['firmware_id']
        if source == manifest['elf']:
            raise WorkflowError('Selected firmware already running; choose a distinct build')
        try:
            body = prepare_body(manifest, status.get('control_generation', 0), policy)
        except ValueError:
            raise WorkflowError('Fresh controller generation unavailable') from None
        # Open listener BEFORE preparation/invitation; keep it for the whole operation.
        with self.transfer as transport:
            try:
                code, prepared = self.signed('/api/ota/prepare', body, secret, boot)
                if code in (400, 403, 409, 413, 429, 503):
                    return Result('REJECTED')
                if (code != 202 or not isinstance(prepared, dict) or prepared.get('boot_id') != boot
                        or not hex_id(prepared.get('transaction'), 32)):
                    return Result('UNCONFIRMED')  # A lost response may hide an accepted prepare.
                transaction = prepared['transaction']
                deadline = self.clock() + 10
                while self.clock() < deadline:
                    current = self.poll()
                    if current.get('boot_id') != boot or current.get('transaction') != transaction:
                        raise WorkflowError('OTA transaction changed before transfer')
                    if current.get('phase') == 'armed' and current.get('active') is True:
                        break
                    if current.get('phase') in ('failed', 'cancelled'):
                        return Result(current['phase'].upper(), transaction)
                else:
                    raise WorkflowError('OTA preparation deadline exceeded')
                transport.send(artifact, secret)
            except (WorkflowError, KeyboardInterrupt):
                if not transaction:
                    return Result('UNCONFIRMED')
                self.cancel_before_commit(transaction, secret, boot)
        return self.reconcile(transaction, source, manifest['elf'], boot)


class DevelopmentUploader(Uploader):
    def admission_policy(self, status, closed_cover):
        if status.get('ota', {}).get('admission_policy') == 'development-recovery':
            # Preserve the existing clean calibrated endpoint update path when
            # torque is retained. Recovery itself always requires torque OFF.
            if (status.get('torque') is True and status.get('ready') is True
                    and status.get('calibrated') is True and status.get('dirty') is False
                    and status.get('state') != 'FAULT'):
                return 'development-stationary'
            return 'development-recovery'
        if status.get('ota', {}).get('admission_policy') == 'development-stationary':
            return 'development-stationary'
        return super().admission_policy(status, closed_cover)

    def get(self,route):
        value=super().get(route)
        if route=='/api/status' and value.get('ota',{}).get('development') is not True:
            raise WorkflowError('Controller requires web_control_dev USB bootstrap first')
        return value

    @staticmethod
    def verdict(status,transaction,source,target,boot):
        result=Uploader.verdict(status,transaction,source,target,boot)
        if result=='COMPLETE' and status.get('development') is not True:
            return None
        return result


def upload_development(directory,host,secret_file,*,closed_cover=False):
    artifact=Artifact.load(directory)
    if DEVELOPMENT_MARKER not in artifact.image:
        raise WorkflowError('Development upload requires a web_control_dev image')
    secret=load_secret(secret_file)
    host=str(ipaddress.IPv4Address(host))
    with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as route:
        route.connect((host,80));local_ip=route.getsockname()[0]
    return DevelopmentUploader(LocalHttp(host,local_ip),EspotaTransfer(host,local_ip)).run(
        artifact,secret,closed_cover=closed_cover)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=('inspect', 'upload', 'upload-dev'))
    parser.add_argument('build_dir', type=Path)
    parser.add_argument('--host',type=ipaddress.IPv4Address,help='Controller literal LAN IPv4 for upload-dev')
    parser.add_argument('--secret-file',type=Path,default=Path(__file__).resolve().parents[1]/'.ota-dev/secret')
    parser.add_argument('--closed-cover',action='store_true',help='One-time confirmation for older receivers that still require CLOSED')
    args = parser.parse_args(argv)
    if args.command == 'upload':
        # Deliberately before artifact, credential, socket or device access.
        parser.exit(1, OTA_UPLOAD_DISABLED + '\n')
    if args.command=='upload-dev':
        if args.host is None:
            parser.error('upload-dev requires --host')
        try:
            result=upload_development(args.build_dir,args.host,args.secret_file,closed_cover=args.closed_cover)
        except WorkflowError as error:
            parser.exit(1,'Development OTA stopped: '+str(error)+'. No automatic retry.\n')
        except (OSError,ValueError):
            parser.exit(1,'Development OTA stopped or unconfirmed. Check the dev build, private credential and safe controller status; no automatic retry.\n')
        print(json.dumps(dict(outcome=result.outcome,transaction=result.transaction)))
        if result.outcome!='COMPLETE':parser.exit(1,'Development OTA did not confirm completion; inspect status before another attempt.\n')
        return
    try:
        print(json.dumps(Artifact.load(args.build_dir).manifest, indent=2))
    except (OSError, ValueError, WorkflowError):
        parser.exit(1, 'Invalid OTA artifact; rebuild and run tools/ota_manifest.py for details\n')


if __name__ == '__main__':
    main()
