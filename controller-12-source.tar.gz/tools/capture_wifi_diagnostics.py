#!/usr/bin/env python3
"""Read-only trusted-LAN event capture. Never opens a session, subscribes or sends commands."""
import argparse
from datetime import datetime, timezone
import json
import hashlib
import math
import os
from pathlib import Path
import re
import time
from urllib.error import HTTPError
from urllib.parse import urlencode, urlsplit
from urllib.request import HTTPRedirectHandler, ProxyHandler, Request, build_opener
from capture_diagnostics import ROOT, archive_build, redact, timestamp


class Busy(Exception):
    def __init__(self, seconds=1):
        self.seconds = max(1, min(30, seconds))


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


def origin(value):
    parsed = urlsplit(value if '://' in value else 'http://' + value)
    if (parsed.scheme not in ('http', 'https') or not parsed.hostname or parsed.username is not None
            or parsed.password is not None or parsed.path not in ('', '/') or parsed.query or parsed.fragment
            or len(value) > 256):
        raise ValueError('Use a controller host or HTTP(S) origin without credentials, path or query')
    if parsed.port is not None and not 1 <= parsed.port <= 65535:
        raise ValueError('Invalid controller port')
    return parsed.scheme + '://' + parsed.netloc


def sanitize(value):
    if isinstance(value, dict):
        return {key: '[redacted]' if re.search(r'(?i)password|passphrase|secret|token|verifier|authorization|credential|(?:api|auth|seestar)[_-]?key', key)
                else sanitize(item) for key, item in value.items()}
    if isinstance(value, list):
        return [sanitize(item) for item in value]
    return redact(value) if isinstance(value, str) else value


def atomic_json(path, value):
    temporary = path.with_suffix('.tmp')
    with temporary.open('w') as stream:
        json.dump(sanitize(value), stream, indent=2, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    temporary.chmod(0o600)
    temporary.replace(path)


class ReadOnlyHTTP:
    def __init__(self, base, timeout=1.2):
        self.base, self.timeout = origin(base), timeout
        self.opener = build_opener(ProxyHandler({}), NoRedirect())

    def get(self, path, query=None):
        limits = {'debug': 4096, 'status': 16384, 'ota/status': 4096}
        if path not in limits:
            raise ValueError('Request outside read-only capture allowlist')
        url = self.base + '/api/' + path + ('?' + urlencode(query) if query else '')
        try:
            with self.opener.open(Request(url, headers={'Accept': 'application/json'}, method='GET'), timeout=self.timeout) as response:
                data = response.read(limits[path] + 1)
                if len(data) > limits[path]:
                    raise ValueError('Response exceeds capture limit')
                return json.loads(data.decode('utf-8'), parse_constant=lambda _: (_ for _ in ()).throw(ValueError('Nonfinite JSON')))
        except HTTPError as error:
            if error.code in (429, 503):
                try:
                    seconds = int(error.headers.get('Retry-After', '1'))
                except ValueError:
                    seconds = 1
                error.close()
                raise Busy(seconds) from None
            error.close()
            raise


def integer(value):
    return type(value) is int and 0 <= value <= 0xffffffff


def validate_batch(batch):
    if not isinstance(batch, dict) or type(batch.get('schema_version')) is not int or batch['schema_version'] != 1:
        raise ValueError('Unsupported event schema')
    for field in ('boot_id', 'firmware'):
        if not isinstance(batch.get(field), str) or not 1 <= len(batch[field]) <= 128:
            raise ValueError('Missing event identity')
    for field in ('sequence_epoch', 'oldest_sequence', 'newest_sequence', 'next_after'):
        if not integer(batch.get(field)):
            raise ValueError('Invalid event cursor')
    for field in ('available', 'cursor_reset', 'gap', 'more', 'metrics_active'):
        if type(batch.get(field)) is not bool:
            raise ValueError('Invalid event state')
    entries = batch.get('entries')
    if not isinstance(entries, list) or len(entries) > 16:
        raise ValueError('Invalid batch count')
    previous = 0
    for entry in entries:
        if (not isinstance(entry, dict) or not integer(entry.get('sequence')) or entry['sequence'] <= previous
                or not batch['oldest_sequence'] <= entry['sequence'] <= batch['newest_sequence']
                or not integer(entry.get('ms')) or entry.get('level') not in ('info', 'warn', 'error')
                or not isinstance(entry.get('message'), str) or len(entry['message']) > 111
                or type(entry.get('truncated')) is not bool):
            raise ValueError('Invalid event entry')
        previous = entry['sequence']
    if entries and batch['next_after'] != entries[-1]['sequence']:
        raise ValueError('Continuation does not match returned entries')
    if batch['next_after'] > batch['newest_sequence']:
        raise ValueError('Continuation exceeds event window')
    return batch


class Capture:
    def __init__(self, directory, http, artifacts=None, resume=False):
        self.directory, self.http = directory, http
        self.manifest_path = directory / 'manifest.json'
        self.cursor_path = directory / 'cursor.json'
        self.boot, self.epoch, self.after = '', 0, 0
        self.snapshot_at, self.ota_at = float('-inf'), float('-inf')
        self.transfer = False
        if resume:
            self.manifest = json.loads(self.manifest_path.read_text())
            if self.manifest['controller_origin'] != http.base:
                raise ValueError('Resume origin differs from saved capture')
            for name, expected in self.manifest['artifacts_sha256'].items():
                if name not in ('firmware.elf', 'firmware.bin') or hashlib.sha256((directory / name).read_bytes()).hexdigest() != expected:
                    raise ValueError('Archived artifact changed since capture')
            cursor = json.loads(self.cursor_path.read_text())
            if not isinstance(cursor.get('boot_id'), str) or not integer(cursor.get('sequence_epoch')) or not integer(cursor.get('after')):
                raise ValueError('Invalid saved cursor')
            self.boot, self.epoch, self.after = cursor['boot_id'], cursor['sequence_epoch'], cursor['after']
        else:
            self.manifest = dict(created_utc=timestamp(), controller_origin=http.base, transport='wifi_read_only',
                                 artifacts_sha256=artifacts or {}, last_device=None,
                                 note='Local artifacts are sensitive. Identity matching compares reported ELF identity with archived ELF SHA256, never binary SHA256.')
            atomic_json(self.manifest_path, self.manifest)
            self.save_cursor()
        self.log = (directory / 'events.jsonl').open('a', buffering=1)
        (directory / 'events.jsonl').chmod(0o600)
        self.record('capture_start', resumed=resume)

    def record(self, kind, **fields):
        self.log.write(json.dumps(sanitize(dict(host_utc=timestamp(), kind=kind, **fields)), allow_nan=False) + '\n')

    def save_cursor(self):
        atomic_json(self.cursor_path, dict(boot_id=self.boot, sequence_epoch=self.epoch, after=self.after))

    def observe(self, batch):
        changed = self.boot != batch['boot_id'] or self.epoch != batch['sequence_epoch']
        reset = changed or batch['cursor_reset']
        if reset:
            self.record('boot' if changed else 'cursor_reset', previous_boot_id=self.boot or None,
                        boot_id=batch['boot_id'], sequence_epoch=batch['sequence_epoch'], firmware=batch['firmware'])
            self.after = 0
        elif batch['entries'] and batch['entries'][0]['sequence'] <= self.after:
            raise ValueError('Repeated/out-of-order event batch')
        if not batch['entries'] and batch['next_after'] != self.after:
            raise ValueError('Empty batch advanced cursor')
        self.boot, self.epoch = batch['boot_id'], batch['sequence_epoch']
        local = self.manifest['artifacts_sha256'].get('firmware.elf')
        self.manifest['last_device'] = dict(boot_id=self.boot, firmware=batch['firmware'],
                                           matches_selected_elf=None if local is None else batch['firmware'] == local)
        self.record('batch', **{key: value for key, value in batch.items() if key != 'entries'})
        if not batch['available']:
            self.record('unavailable', boot_id=self.boot, source='event_ring')
        for entry in batch['entries']:
            if entry['sequence'] != self.after + 1:
                self.record('gap', boot_id=self.boot, expected_sequence=self.after + 1, next_sequence=entry['sequence'])
            self.record('event', boot_id=self.boot, firmware=batch['firmware'], sequence_epoch=self.epoch, **entry)
            self.after = entry['sequence']
        self.log.flush()
        os.fsync(self.log.fileno())
        self.save_cursor()
        atomic_json(self.manifest_path, self.manifest)

    def step(self, now):
        # OTA snapshot remains lightweight and cannot enable optional collection.
        if now - self.ota_at >= (1 if self.transfer else 5):
            ota = self.http.get('ota/status')
            if not isinstance(ota, dict):
                raise ValueError('Invalid OTA snapshot')
            self.ota_at = now
            phase = str(ota.get('phase', '')).lower()
            self.transfer = ota.get('active') is True or (ota.get('available') is True and phase not in
                ('idle', 'complete', 'completed', 'accepted', 'failed', 'fault', 'cancelled', 'unavailable'))
            self.record('ota', boot_id=ota.get('boot_id'), snapshot=ota)
        if self.transfer:
            self.record('bulk_paused', boot_id=self.boot or None, reason='ota')
            return
        query = dict(after=self.after)
        if self.boot:
            query.update(boot_id=self.boot, sequence_epoch=self.epoch)
        batch = validate_batch(self.http.get('debug', query))
        self.observe(batch)
        if batch['metrics_active'] and now - self.snapshot_at >= 5:
            status = self.http.get('status')
            if not isinstance(status, dict):
                raise ValueError('Invalid controller snapshot')
            boot = status.get('resources', {}).get('boot_id')
            if boot != self.boot or status.get('firmware_id') != batch['firmware']:
                self.record('gap', boot_id=self.boot, reason='boot_changed_between_requests', observed_boot_id=boot)
                return
            self.snapshot_at = now
            self.record('snapshot', boot_id=self.boot, uptime_ms=status.get('uptime_ms'), snapshot=status)

    def close(self):
        self.record('capture_finished', boot_id=self.boot or None)
        self.log.close()


def run(capture, duration=0, clock=time.monotonic, sleep=time.sleep):
    deadline = clock() + duration if duration else float('inf')
    backoff = 1
    reconnecting = False
    try:
        while clock() < deadline:
            began = clock()
            try:
                capture.step(began)
                if reconnecting:
                    capture.record('reconnected')
                    reconnecting = False
                backoff = 1
                sleep(max(0, 1 - (clock() - began)))
            except Busy as error:
                capture.record('busy', retry_after_seconds=error.seconds)
                sleep(error.seconds)
            except (OSError, ValueError) as error:
                # Never record raw URLs, headers or response bodies from exceptions.
                capture.record('gap', reason='request_failed', error_type=type(error).__name__,
                               http_status=getattr(error, 'code', None), retry_after_seconds=backoff)
                reconnecting = True
                sleep(backoff)
                backoff = min(30, backoff * 2)
    except KeyboardInterrupt:
        capture.record('operator_stop')
    finally:
        capture.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host', required=True, help='Controller host/IP, optionally with port')
    parser.add_argument('--duration', type=float, default=0, help='Seconds; 0 until Ctrl-C')
    parser.add_argument('--output', type=Path, default=ROOT / 'diagnostics')
    parser.add_argument('--build-dir', type=Path, help='Optional local build to archive and compare')
    parser.add_argument('--resume', type=Path, help='Resume an existing capture directory and cursor')
    args = parser.parse_args()
    if not math.isfinite(args.duration) or args.duration < 0 or args.resume and args.build_dir:
        parser.error('Use a finite nonnegative duration; resume cannot change selected artifacts')
    try:
        http = ReadOnlyHTTP(args.host)
        directory = args.resume or args.output / datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
        if not args.resume:
            directory.mkdir(parents=True, mode=0o700)
        artifacts = archive_build(directory, args.build_dir) if args.build_dir else None
        capture = Capture(directory, http, artifacts, resume=bool(args.resume))
    except (OSError, ValueError, KeyError) as error:
        parser.exit(1, 'Capture setup failed: ' + type(error).__name__ + '\n')
    print(f'Capture folder: {directory}', flush=True)
    print('Read-only GET requests only; optional metrics stay under the browser panel lifecycle.', flush=True)
    run(capture, args.duration)


if __name__ == '__main__':
    main()
