#!/usr/bin/env python3
"""Freeze an unpublished complete-controller candidate. No flashing or publication."""
from pathlib import Path
import argparse,hashlib,json,shutil,subprocess,sys,zipfile
from ota_manifest import manifest_for_build
from check_firmware import validate_partitions

def package(root,output):
 root=Path(root).resolve();output=Path(output).resolve();build=root/'.pio/build/web_control_multiturn_ota'
 if output.exists():raise ValueError('Never overwrite a frozen candidate')
 if subprocess.check_output(['git','-C',str(root),'status','--porcelain'],text=True).strip():raise ValueError('Candidate source must be clean')
 identity=json.loads((build/'version.json').read_text());release=json.loads((root/'controller-release.json').read_text())
 if identity['dirty'] or not identity['release'] or identity['profile']!='web_control_multiturn_ota' or identity['version']!=release['version']:raise ValueError('Release identity mismatch')
 header=(build/'browser_generated.h').read_text()
 if f"#define COVER_BROWSER_BUILD {release['build']}\n" not in header:raise ValueError('Monotonic build differs from source')
 image=manifest_for_build(build);validate_partitions((build/'partitions.bin').read_bytes())
 output.mkdir(parents=True);(output/'maintainer').mkdir()
 for name in ['firmware.bin','bootloader.bin','partitions.bin']:
  shutil.copyfile(build/name,output/name)
 for name in ['firmware.elf','firmware.map','version.json','ota-manifest.json','install-inputs.json','browser_generated.h']:
  shutil.copyfile(build/name,output/'maintainer'/name)
 inputs=json.loads((build/'install-inputs.json').read_text())
 components=[]
 for item in inputs['components']:
  source=Path(item['path']);name=source.name
  if name=='boot_app0.bin':shutil.copyfile(source,output/name)
  if name not in ['bootloader.bin','partitions.bin','boot_app0.bin','firmware.bin']:raise ValueError('Unexpected install input')
  if (output/name).read_bytes()!=source.read_bytes():raise ValueError('Frozen input mismatch')
  components.append(dict(offset=item['offset'],file=name,sha256=hashlib.sha256(source.read_bytes()).hexdigest()))
 if {c['offset'] for c in components}!={0x1000,0x8000,0xe000,0x10000}:raise ValueError('Unexpected offsets')
 subprocess.run([sys.executable,inputs['esptool'],'--chip','esp32','merge_bin','--flash_mode',inputs['flash_mode'],'--flash_freq',inputs['flash_freq'],'--flash_size',inputs['flash_size'],'-o',str(output/'factory.bin'),*[value for c in components for value in (hex(c['offset']),str(output/c['file']))]],check=True,stdout=subprocess.DEVNULL)
 for name in ['LICENSE','LICENSING.md','THIRD_PARTY_NOTICES.md','controller-release.json']:
  shutil.copyfile(root/name,output/name)
 for folder in ['LICENSES','docs/licenses','keys']:
  shutil.copytree(root/folder,output/folder)
 commit=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()
 with open(output/'source.tar','wb') as stream:subprocess.run(['git','-C',str(root),'archive','--format=tar',commit],stdout=stream,check=True)
 record=dict(**identity,build=release['build'],application=image,components=components,source_commit=commit,
  qualification='candidate-pending-hardware',publication_allowed=False,production_installation_allowed=False,
  startup_policy='inspect-only-v1',motion='native-multiturn-v1',chunk_bytes=768,chunk_ack='consumed-offset-v1',
  includes=['cover motion and safety controller','calibration and settings','network setup and recovery','telescope monitoring and interlocks','diagnostics','configuration firmware updater','shared update badge'],
  pending=['powered-spare full-workload OTA and rollback tests','production installation authorization','dependency distribution review'],
  note='No servo register writes are authorized by this package. Factory-profile servo requires separately approved commissioning. USB recovery and factory.bin erase existing settings; production bootstrap must use its existing authenticated development OTA receiver after admission passes.')
 (output/'release.json').write_text(json.dumps(record,indent=2)+'\n')
 (output/'README.md').write_text('# Complete controller candidate '+identity['version']+'\n\nUnpublished and not approved for production installation. Includes the complete application, 768-byte browser updates, worker-completed acknowledgements, automatic authorization, update discovery and the shared blue update badge.\n\nStartup and update inspect the existing native servo profile without programming it. Current factory-profile or unpowered servos cannot pass motion/update admission. No motion is commanded by installation.\n\n`firmware.bin` is the settings-preserving application input for the established authenticated desktop bootstrap. `factory.bin` and the separate boot components are USB recovery inputs; a factory install is destructive. Never flash a production controller using an unqualified package.\n\nSee release.json for exact source, hashes, pending acceptance and publication gates. Maintainer ELF/map and exact curated software source are retained. Private signing keys and personal credential headers are excluded.\n')
 (output/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(output))+'\n' for p in sorted(output.rglob('*')) if p.is_file()))
 return record
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('source');parser.add_argument('output');args=parser.parse_args()
 try:print(json.dumps(package(args.source,args.output),indent=2))
 except (ValueError,OSError) as e:parser.exit(1,str(e)+'\n')
