"""Supervised manual power-cut window during a capped, paced OTA upload.

Never sends a complete image. Operator must remove every ESP32 power source,
observe it off, then restore power. Evidence remains UNCONFIRMED until operator,
first recovered HTTP status and native/partial-slot USB checks are reconciled.
No host reset injection or USB reconnect occurs during the transfer experiment.
"""
import argparse
import ipaddress
import json
from pathlib import Path
import socket
import time
from types import SimpleNamespace

from ota_upload import Artifact,EspotaTransfer,LocalHttp,Result,WorkflowError,load_secret
from probe_ota_activation import UsbMonitor,RecordingHttp,safe_status
from probe_ota_interruption import FaultUploader

CUE_BYTES=65536
CAP_BYTES=524288
PACE_SECONDS=.08


class NetworkOnlyMonitor:
    """No serial port is opened when USB was physically removed before arming."""
    def __init__(self):self.error=False;self.gate=SimpleNamespace(fired=False)
    def start(self):pass
    def progress(self):pass
    def close(self):pass


class PowerCutTransfer(EspotaTransfer):
    def __init__(self,host,local_ip,monitor,record):
        super().__init__(host,local_ip,progress=self.after_ack)
        self.monitor=monitor;self.record=record;self.owner=None;self.injected=False;self.mode='manual_power_loss'
        self.last_ack=0;self.last_ack_at=None;self.window_expired=False;self.transport_interrupted=False
    def send(self,artifact,secret):
        if len(artifact.image)<=CAP_BYTES:raise WorkflowError('Payload must exceed the hard partial-image cap')
        try:super().send(artifact,secret)
        except WorkflowError:
            self.transport_interrupted=self.injected and not self.window_expired
            raise
    def after_ack(self,sent,total):
        self.last_ack=sent;self.last_ack_at=time.monotonic()
        if sent%16384==0:self.record('ack_progress',dict(received=sent))
        if not self.injected:self.monitor.progress()
        if sent==CUE_BYTES:
            status=self.owner.get('/api/status');ota=status.get('ota',{})
            if (ota.get('boot_id')!=self.owner.boot or ota.get('transaction')!=self.owner.transaction
                    or ota.get('phase')!='receiving' or ota.get('active') is not True or ota.get('received')!=sent
                    or status.get('moving') is not False or status.get('torque') is not False
                    or status.get('resources',{}).get('state')!='off'):
                raise WorkflowError('Power-cut cue identity/safety changed')
            self.monitor.progress();self.injected=True
            self.record('power_cut_cue',dict(boot_id=self.owner.boot,transaction=self.owner.transaction,
                received=sent,cap_bytes=CAP_BYTES))
            print('POWER_CUT_WINDOW_OPEN: disconnect all confirmed ESP32 power inputs now. Partial upload only; never activates.',flush=True)
        if sent>=CAP_BYTES:
            self.window_expired=True
            self.record('window_expired',dict(last_ack=sent))
            raise WorkflowError('Manual power-cut window expired; partial image cap reached')
        # Keep sending within the receiver's 3 s idle timeout, while giving the
        # operator a useful window. Hard cap independently prevents activation.
        time.sleep(PACE_SECONDS)


class ManualPowerUploader(FaultUploader):
    def reconcile(self,transaction,source,target,boot,duration=60):
        # No per-attempt durable record exists before commit in current firmware.
        # Do not turn an unrelated historical terminal record into this verdict.
        return Result('UNCONFIRMED',transaction)


def verify_recovered_status(before,recovered,transaction,target=None):
    if (recovered.get('firmware_id')!=before.get('firmware_id')
            or recovered.get('resources',{}).get('boot_id')==before.get('resources',{}).get('boot_id')
            or recovered.get('reset_reason')!='POWERON'
            or recovered.get('ota',{}).get('startup')!='accepted'
            or recovered.get('ready') is not True or recovered.get('calibrated') is not True
            or recovered.get('moving') is not False or recovered.get('torque') is not False
            or recovered.get('dirty') is not False or recovered.get('fault')
            or recovered.get('maintenance',{}).get('locked') is not False
            or recovered.get('resources',{}).get('state')!='off'
            or recovered.get('resources',{}).get('viewers')!=0
            or recovered.get('ota',{}).get('active') is not False):
        raise WorkflowError('First recovered source boot/safety evidence changed')
    for key in ['minimum','maximum','open','closed','saved_minimum','saved_maximum','saved_profile']:
        if recovered.get(key)!=before.get(key):raise WorkflowError('Saved setting changed after power loss')
    old=before.get('ota',{}).get('last_update');record=recovered.get('ota',{}).get('last_update')
    if record==old:
        if isinstance(record,dict) and record.get('transaction')==transaction:
            raise WorkflowError('Interrupted transaction already present before experiment')
        return 'historical_journal_unchanged'
    if (not isinstance(record,dict) or record.get('transaction')!=transaction
            or record.get('outcome')!='failed' or record.get('selection_confirmed') is not False
            or record.get('source_firmware')!=before.get('firmware_id')
            or not target or record.get('target_firmware')!=target
            or record.get('source_slot')!=0x10000 or record.get('target_slot')!=0x150000):
        raise WorkflowError('Power-loss journal identity/outcome unexpectedly changed')
    # A supply path can fail before all stored energy is gone. A matching FAILED
    # record in the first boot proves cleanup persisted before complete shutdown;
    # it is safe recovery evidence, not a cut inside an uncheckpointed flash write.
    return 'matching_failure_persisted_before_power_off'



def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host',required=True,type=ipaddress.IPv4Address)
    parser.add_argument('--port')
    parser.add_argument('--without-usb',action='store_true',help='Operator removed USB before arming; use network-only observation')
    parser.add_argument('--source-build-dir',required=True,type=Path)
    parser.add_argument('--payload-build-dir',required=True,type=Path)
    parser.add_argument('--secret-file',required=True,type=Path)
    parser.add_argument('--supported-cover-off',action='store_true')
    parser.add_argument('--operator-power-paths-confirmed',action='store_true')
    parser.add_argument('--run-manual-power-loss-experiment',action='store_true')
    parser.add_argument('--output',required=True,type=Path)
    args=parser.parse_args();monitor=None
    if not args.supported_cover_off or not args.operator_power_paths_confirmed or not args.run_manual_power_loss_experiment:
        parser.error('Explicit supported-cover/OFF, confirmed power paths and manual power-loss flags required')
    if not args.without_usb and not args.port:parser.error('USB port or explicit --without-usb required')
    try:
        source=Artifact.load(args.source_build_dir);payload=Artifact.load(args.payload_build_dir)
        if source.manifest['elf']==payload.manifest['elf']:raise WorkflowError('Distinct source/payload required')
        secret=load_secret(args.secret_file);args.output.mkdir(mode=0o700,parents=True,exist_ok=True)
        with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as route:
            route.connect((str(args.host),80));local_ip=route.getsockname()[0]
        monitor=NetworkOnlyMonitor() if args.without_usb else UsbMonitor(args.port,args.output);monitor.start()
        with (args.output/'status.jsonl').open('w',buffering=1) as log,(args.output/'actions.jsonl').open('w',buffering=1) as actions:
            def record(kind,data):actions.write(json.dumps(dict(at=time.monotonic(),kind=kind,data=data))+'\n')
            http=RecordingHttp(LocalHttp(str(args.host),local_ip),log);deadline=time.monotonic()+35
            while True:
                try:before=safe_status(http,source.manifest['elf']);break
                except (WorkflowError,OSError):
                    if time.monotonic()>=deadline:raise WorkflowError('Safe source startup unconfirmed')
                    time.sleep(1)
            (args.output/'source-before-status.json').write_text(json.dumps(before,indent=2)+'\n')
            sender=PowerCutTransfer(str(args.host),local_ip,monitor,record)
            result=ManualPowerUploader(http,sender,record).run(payload,secret,supported_cover_off=True)
            evidence=dict(outcome='UNCONFIRMED',transaction=result.transaction,cue_opened=sender.injected,
                last_ack=sender.last_ack,last_ack_at=sender.last_ack_at,window_expired=sender.window_expired,
                transport_interrupted=sender.transport_interrupted,usb_disconnected_or_failed=monitor.error,
                host_reset_injected=monitor.gate.fired,usb_opened=not args.without_usb,operator_off_observation_required=True,
                first_recovered_status_required_before_usb_reopen=True)
            (args.output/'pending-evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
            if not sender.injected or sender.window_expired or not sender.transport_interrupted or monitor.gate.fired:
                raise WorkflowError('Manual power-loss attempt not established; no automatic repeat')
            print('TRANSFER_INTERRUPTED: operator confirmation, first recovered HTTP status and independent USB verification still required.',flush=True)
    except (OSError,ValueError,WorkflowError,KeyboardInterrupt):
        parser.exit(1,'Manual power-loss test stopped/unconfirmed. Keep evidence; no automatic repeat. Verify physical power state before USB recovery.\n')
    finally:
        if monitor is not None:monitor.close()


if __name__=='__main__':main()
