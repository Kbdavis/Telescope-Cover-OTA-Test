"""Public signing trust and monotonic identity for the complete controller."""
from pathlib import Path
import os,json
Import('env')
build=Path(env.subst('$BUILD_DIR'));build.mkdir(parents=True,exist_ok=True)
root=Path(env.subst('$PROJECT_DIR'))
release=json.loads((root/'controller-release.json').read_text())
number=int(os.environ.get('TELESCOPE_BROWSER_BUILD',release['build']))
if not 1<=number<=9999:raise ValueError('Invalid controller build')
point=bytes.fromhex(Path(os.environ.get('TELESCOPE_BROWSER_PUBLIC_POINT',root/'keys/controller-signing-public-point.hex')).read_text().strip())
if len(point)!=65 or point[0]!=4:raise ValueError('Expected public SEC1 P-256 point')
text='// Generated public trust only. No private or device credential.\n#pragma once\n'
text+=f'#define COVER_BROWSER_BUILD {number}\n'
text+='static const uint8_t browserPublicPoint[65]={'+','.join(map(str,point))+'};\n'
output=build/'browser_generated.h'
if not output.exists() or output.read_text()!=text:output.write_text(text)
env.Prepend(CPPPATH=[str(build)])
