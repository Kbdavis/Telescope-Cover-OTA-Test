#!/usr/bin/env python3
"""Serve the current controller UI with simulated debug events on localhost."""
import argparse
from datetime import datetime
import runpy
import time
from pathlib import Path
from urllib.parse import parse_qs


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port', type=int, default=8083)
    args = parser.parse_args()
    if not 1 <= args.port <= 65535:
        parser.error('port must be between 1 and 65535')
    fixture = runpy.run_path(str(Path(__file__).resolve().parents[1] / 'tests/web/live_ui_server.py'))
    fixture['network']['enable_debug_tab'] = True
    fixture['controls']['beta'] = True
    fixture['cover']['firmware_id'] = 'LOCAL SIMULATION'
    started = time.monotonic()
    started_wall = time.time()

    class DebugHandler(fixture['Handler']):
        def send(self, value, code=200, kind='application/json', gzip_asset=False):
            if kind == 'text/html' and isinstance(value, bytes):
                value = value.replace(b'<body>', b'<body><div style="padding:12px;text-align:center;background:#ffe08a;color:#211900;font-weight:bold">LOCAL DEBUG SIMULATION &mdash; NO HARDWARE CONNECTION <button id="simulate-fault" type="button" style="background:#211900;color:#fff;border:1px solid #211900;padding:6px 12px;margin-left:12px;border-radius:6px;font:inherit;cursor:pointer">Trigger cover fault</button><span id="simulate-result" role="status"></span></div><script src="/test/debug.js" defer></script>')
            return super().send(value, code, kind, gzip_asset)

        def do_POST(self):
            if self.path != '/test/fault':
                return super().do_POST()
            self.rfile.read(int(self.headers.get('Content-Length', 0)))
            with fixture['lock']:
                state = fixture['Handler'].do_POST.__globals__
                state['motion'] = None
                fixture['cover'].update(state='FAULT', fault='Simulated movement timeout; inspect the cover.',
                    ready=False, moving=False, holding=False, torque=False, owner=0,
                    notice='Simulated fault triggered; no hardware connected')
            return self.send({'ok': True})

        def do_GET(self):
            if self.path.split('?')[0].startswith('/favicon.'):
                print('Favicon request: ' + self.path + ' user-agent=' + self.headers.get('User-Agent', 'unknown'), flush=True)
            if self.path.split('?')[0] == '/test/debug.js':
                return self.send("document.getElementById('simulate-fault').onclick=async()=>{const r=await fetch('/test/fault',{method:'POST'});document.getElementById('simulate-result').textContent=r.ok?' Simulated fault triggered.':' Fault trigger failed.';};", kind='application/javascript')
            if self.path.split('?')[0] != '/api/debug':
                return super().do_GET()
            with fixture['lock']:
                query = parse_qs(self.path.partition('?')[2])
                try:
                    after = max(0, int(query.get('after', ['0'])[0]))
                    epoch = int(query.get('sequence_epoch', ['0'])[0])
                except ValueError:
                    return self.send('Invalid debug cursor', 400, 'text/plain')
                newest = int(time.monotonic() - started) + 1
                oldest = max(1, newest - 999)
                boot = 'public-' + fixture['controls']['token']
                reset = query.get('boot_id', [boot])[0] != boot or epoch != 0 or after > newest
                if reset:
                    after = 0
                gap = after < oldest - 1
                entries = []
                for sequence in range(max(oldest, after + 1), min(newest + 1, max(oldest, after + 1) + 16)):
                    phase = (sequence - 1) % 15
                    if phase < 10:
                        level, message = 'warn', 'SIMULATED: telescope connection retry timed out'
                    elif phase < 14:
                        level, message = 'info', 'SIMULATED: telescope connection recovered'
                    else:
                        level, message = 'error', 'SIMULATED: cover movement inhibited by interlock'
                    event_time = datetime.fromtimestamp(started_wall + sequence - 1).astimezone().isoformat(timespec="seconds")
                    entries.append(dict(sequence=sequence, ms=sequence * 1000, local_time=event_time, level=level, message=message, truncated=False))
                next_after = entries[-1]['sequence'] if entries else after
                return self.send(dict(schema_version=1, firmware='local-debug-simulation', boot_id=boot,
                    sequence_epoch=0, oldest_sequence=oldest, newest_sequence=newest,
                    entries=entries, available=True, capacity=1000,
                    loss=dict(ring_overwrites=max(0, newest-1000), serial_dropped=0, truncated=0, suppressed_trace=0),
                    cursor_reset=reset, gap=gap, more=next_after < newest, next_after=next_after,
                    metrics_active=fixture['cover']['resources'].get('available', False)))

    server = fixture['ThreadingHTTPServer'](('127.0.0.1', args.port), DebugHandler)
    print(f'Local debug simulation: http://127.0.0.1:{args.port}/#debug', flush=True)
    print('No hardware connection. Repeated sample events arrive once per second. Ctrl+C stops the server.', flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == '__main__':
    main()
