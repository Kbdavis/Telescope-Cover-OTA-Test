#!/usr/bin/env python3
"""Verify a private pipeline-test package and optionally promote its exact bytes.

No build, serial access, hardware operation or repository visibility change.
Public/qualified releases require a separate acceptance process.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile
import zipfile

from check_firmware import validate_partitions
from ota_manifest import inspect_image, DEVELOPMENT_MARKER
from package_release import PACKAGE_NOTICES, RELEASE_PROFILE, OFFSETS


def sha(data):
    return hashlib.sha256(data).hexdigest()


def verify_candidate(candidate, version, commit):
    candidate=Path(candidate)
    if not re.fullmatch(r'\d+\.\d+\.\d+-(alpha|beta|rc)\.[1-9]\d*',version):
        raise ValueError('Pipeline publication requires a prerelease version')
    if not re.fullmatch(r'[a-f0-9]{40}',commit):
        raise ValueError('Expected source must be a full commit SHA')
    record=json.loads((candidate/'release.json').read_text())
    required=dict(version=version,commit=commit,profile=RELEASE_PROFILE,dirty=False,release=True,
                  status='pipeline-test-prerelease',hardware_acceptance='not-performed',
                  browser_acceptance='not-performed',publication_allowed=False,
                  private_pipeline_publication_allowed=True,intended_repository_visibility='private')
    for key,value in required.items():
        if type(record.get(key)) is not type(value) or record[key]!=value:
            raise ValueError(f'Pipeline release metadata mismatch: {key}')
    expected={'factory.bin','partitions.bin','manifest.json','esp-web-tools-manifest.json',
              'index.html','style.css','app.mjs','core.mjs','INSTALLATION.md',
              'RELEASE_NOTES.md','LICENSE_STATUS.md','release.json','SHA256SUMS','PIPELINE_TEST.md'}|set(PACKAGE_NOTICES)
    actual={p.relative_to(candidate).as_posix() for p in candidate.rglob('*') if p.is_file()}
    if actual!=expected or any(p.is_symlink() for p in candidate.rglob('*')):
        raise ValueError('Unexpected package files or links')
    checks={}
    for line in (candidate/'SHA256SUMS').read_text().splitlines():
        digest,name=line.split('  ',1)
        if name not in expected-{'SHA256SUMS'} or name in checks or sha((candidate/name).read_bytes())!=digest:
            raise ValueError('Package checksum mismatch')
        checks[name]=digest
    if set(checks)!=expected-{'SHA256SUMS'}:
        raise ValueError('Incomplete package checksums')
    manifest=json.loads((candidate/'manifest.json').read_text())
    if any(manifest.get(key)!=value for key,value in dict(version=version,commit=commit,profile=RELEASE_PROFILE).items()):
        raise ValueError('Installer source/version mismatch')
    image=(candidate/'factory.bin').read_bytes()
    if sha(image)!=manifest['image']['sha256'] or len(image)!=manifest['image']['size'] or manifest['image']['offset']!=0:
        raise ValueError('Factory image mismatch')
    if DEVELOPMENT_MARKER in image:
        raise ValueError('Development credential marker present')
    partition=(candidate/'partitions.bin').read_bytes();validate_partitions(partition)
    if image[0x8000:0x8000+len(partition)]!=partition:
        raise ValueError('Embedded partition table mismatch')
    if len(manifest['components'])!=4 or {c['role'] for c in manifest['components']}!=set(OFFSETS):
        raise ValueError('Incomplete boot components')
    for component in manifest['components']:
        start=component['offset'];end=start+component['size']
        if start!=OFFSETS[component['role']] or end>len(image) or sha(image[start:end])!=component['sha256']:
            raise ValueError('Boot component mismatch')
    app=next(c for c in manifest['components'] if c['role']=='application')
    application=image[app['offset']:app['offset']+app['size']]
    if inspect_image(application,allow_multiturn_usb=True)!=record['application'] or record['application']['profile']!='multiturn_usb':
        raise ValueError('Application descriptor/identity mismatch')
    if any('NOT HARDWARE TESTED' not in (candidate/name).read_text() for name in ('PIPELINE_TEST.md','RELEASE_NOTES.md')):
        raise ValueError('Missing untested-release warning')
    archive=Path(str(candidate)+'.zip')
    sumfile=Path(str(archive)+'.sha256')
    if sumfile.read_text().strip()!=f'{sha(archive.read_bytes())}  {archive.name}':
        raise ValueError('ZIP checksum mismatch')
    with zipfile.ZipFile(archive) as package:
        if len(package.namelist())!=len(expected) or set(package.namelist())!=expected:
            raise ValueError('ZIP contents differ from verified package')
        for name in expected:
            if package.read(name)!=(candidate/name).read_bytes():
                raise ValueError('ZIP entry differs from verified package')
    return record


def run(*args):
    return subprocess.check_output(list(args),text=True).strip()


def publish(candidate,version,commit,repository):
    record=verify_candidate(candidate,version,commit)
    if run('git','rev-parse','HEAD')!=commit:
        raise ValueError('Publisher checkout is not the built source commit')
    repo=json.loads(run('gh','repo','view',repository,'--json','visibility,nameWithOwner'))
    if repo['visibility']!='PRIVATE':
        raise ValueError('Pipeline-only publication requires a PRIVATE repository; no visibility change will be made')
    tag='v'+version
    remote=subprocess.run(['git','ls-remote','--exit-code','--tags','origin','refs/tags/'+tag],capture_output=True,text=True)
    if remote.returncode!=2:
        raise ValueError('Tag already exists or remote tag check failed; never replacing a tag')
    if run('git','tag','--list',tag):
        raise ValueError('Local tag already exists; never replacing a tag')
    candidate=Path(candidate).resolve()
    # GitHub attachments are a subset of the verified package, with a separate
    # checksum list for exactly those loose downloads. The ZIP is unchanged.
    with tempfile.TemporaryDirectory(prefix='telescope-release-assets-') as directory:
        temporary=Path(directory)
        assets=temporary/'assets';assets.mkdir()
        import shutil
        for name in ('factory.bin','manifest.json','release.json','INSTALLATION.md','RELEASE_NOTES.md','PIPELINE_TEST.md'):
            shutil.copyfile(candidate/name,assets/name)
        archive=Path(str(candidate)+'.zip')
        shutil.copyfile(archive,assets/archive.name)
        (assets/'SHA256SUMS').write_text(''.join(f'{sha(p.read_bytes())}  {p.name}\n' for p in sorted(assets.iterdir())))
        body=(candidate/'RELEASE_NOTES.md').read_text()
        body+='\n\n## Downloads\n\nUse the USB ZIP for the complete installer, instructions and notices. '
        body+='`factory.bin` is the complete clean-install image at address **0x0**; installation erases Wi-Fi and calibration. '
        body+='This is not an OTA update. Keep the arm detached and external servo power disconnected during installation. '
        body+='No hardware has been flashed or tested by this pipeline.\n\n'
        body+=f'Source: `{commit}`.\n'
        server=os.environ.get('GITHUB_SERVER_URL','https://github.com')
        if os.environ.get('GITHUB_RUN_ID'):
            body+=f'Build/publish run: {server}/{repository}/actions/runs/{os.environ["GITHUB_RUN_ID"]}\n'
        bodyfile=temporary/'release-body.md';bodyfile.write_text(body)
        run('git','-c','tag.gpgsign=false','-c','user.name=github-actions[bot]','-c','user.email=41898282+github-actions[bot]@users.noreply.github.com',
            'tag','-a',tag,commit,'-m',f'Telescope Cover {version}: private pipeline test; not hardware tested')
        run('git','push','origin','refs/tags/'+tag)
        url=run('gh','release','create',tag,'--repo',repository,'--verify-tag','--draft','--prerelease','--latest=false',
                '--title',f'{tag} — Pipeline test (not hardware tested)','--notes-file',str(bodyfile),
                *[str(p) for p in sorted(assets.iterdir())])
        # Draft downloads must match before publication. No rebuilding here.
        downloaded=temporary/'downloaded';downloaded.mkdir()
        run('gh','release','download',tag,'--repo',repository,'--dir',str(downloaded))
        for source in assets.iterdir():
            if not (downloaded/source.name).is_file() or sha(source.read_bytes())!=sha((downloaded/source.name).read_bytes()):
                raise ValueError('Draft asset verification failed; draft remains unpublished')
        run('gh','release','edit',tag,'--repo',repository,'--draft=false','--prerelease','--latest=false')
        release=json.loads(run('gh','release','view',tag,'--repo',repository,'--json','url,isDraft,isPrerelease,tagName'))
        if release['isDraft'] or not release['isPrerelease'] or release['tagName']!=tag:
            raise ValueError('Published release state mismatch')
        print(json.dumps(release,indent=2))
    return record


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('candidate',type=Path)
    parser.add_argument('--version',required=True)
    parser.add_argument('--commit',required=True)
    parser.add_argument('--repo',default='Kbdavis/Telescope-Cover')
    parser.add_argument('--publish',action='store_true')
    args=parser.parse_args()
    if args.publish:
        publish(args.candidate,args.version,args.commit,args.repo)
    else:
        record=verify_candidate(args.candidate,args.version,args.commit)
        print(f'Verified private pipeline-test package {record["version"]} at {record["commit"]}; no publication performed')


if __name__=='__main__':
    main()
