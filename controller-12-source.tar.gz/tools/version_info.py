"""One firmware identity for the binary, API and release metadata. No device access."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess


def git(root, *args):
    return subprocess.check_output(["git", "-C", str(root), *args], text=True).strip()


def version_info(root, profile, environ=None):
    root = Path(root)
    values = os.environ if environ is None else environ
    base = (root / "VERSION").read_text().strip()
    if not re.fullmatch(r"\d+\.\d+\.\d+", base):
        raise ValueError("VERSION must contain major.minor.patch")
    provenance = root / ".release-source.json"
    if provenance.exists():
        source = json.loads(provenance.read_text())
        commit, dirty = source["commit"], source["dirty"]
    else:
        commit = git(root, "rev-parse", "HEAD")
        dirty = bool(git(root, "status", "--porcelain", "--untracked-files=normal"))
    if not re.fullmatch(r"[0-9a-f]{40}", commit) or type(dirty) is not bool:
        raise ValueError("Invalid source identity")
    release = values.get("TELESCOPE_RELEASE_VERSION", "")
    if release:
        if not re.fullmatch(re.escape(base) + r"(?:-(?:alpha|beta|rc)\.[1-9]\d*)?", release):
            raise ValueError("Release version must match VERSION, optionally with alpha/beta/rc.N")
        if dirty or profile not in ("web_control_multiturn_usb", "web_control_multiturn_ota"):
            raise ValueError("Release identity requires clean source and a supported multi-turn release profile")
    version = release or f"{base}-dev+{commit[:7]}" + (".dirty" if dirty else "")
    # Preserve one timestamp for an incremental build. A source/profile change
    # changes metadata and invalidates object dependencies through the header.
    info = dict(version=version, commit=commit, profile=profile, dirty=dirty,
                release=bool(release))
    if dirty and not provenance.exists():
        fingerprint = hashlib.sha256(subprocess.check_output(['git', '-C', str(root), 'diff', 'HEAD', '--binary']))
        for name in git(root, 'ls-files', '--others', '--exclude-standard').splitlines():
            path = root / name
            if path.is_file():
                fingerprint.update(name.encode())
                with path.open('rb') as stream:
                    for chunk in iter(lambda: stream.read(65536), b''):
                        fingerprint.update(chunk)
        info['worktree_sha256'] = fingerprint.hexdigest()
    return info


def generate(root, build_dir, profile):
    info = version_info(root, profile)
    build_dir = Path(build_dir)
    build_dir.mkdir(parents=True, exist_ok=True)
    metadata = build_dir / "version.json"
    previous = json.loads(metadata.read_text()) if metadata.exists() else {}
    same = all(previous.get(key) == value for key, value in info.items())
    info["built_at"] = previous["built_at"] if same and "built_at" in previous else datetime.now(timezone.utc).isoformat(timespec="seconds")
    body = json.dumps(info, sort_keys=True, separators=(",", ":"))
    metadata.write_text(json.dumps(info, indent=2) + "\n")
    header = "// Generated build identity; do not edit.\n#pragma once\n"
    for name, value in (("VERSION", info["version"]), ("SOURCE_COMMIT", info["commit"]),
                        ("BUILD_PROFILE", profile), ("VERSION_JSON", body)):
        header += f"#define COVER_{name} {json.dumps(value)}\n"
    output = build_dir / "generated_version.h"
    if not output.exists() or output.read_text() != header:
        output.write_text(header)
    return info


if "Import" in globals():
    Import("env")
    root = Path(env.subst("$PROJECT_DIR"))
    build_dir = Path(env.subst("$BUILD_DIR"))
    generate(root, build_dir, env.subst("$PIOENV"))
    env.Prepend(CPPPATH=[str(build_dir)])
