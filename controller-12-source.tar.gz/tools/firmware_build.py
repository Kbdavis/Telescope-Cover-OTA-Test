"""PlatformIO production build checks. No device or network access."""
from pathlib import Path
import json
import sys

from SCons.Errors import UserError
from SCons.Script import COMMAND_LINE_TARGETS

Import("env")

sys.path.insert(0, str(Path(env.subst("$PROJECT_DIR")) / "tools"))
from check_firmware import OTA_UPLOAD_DISABLED, report_firmware, upload_blocked
from ota_manifest import manifest_for_build

if upload_blocked(env.subst("$PIOENV"), COMMAND_LINE_TARGETS):
    raise UserError(OTA_UPLOAD_DISABLED)
if "nobuild" in COMMAND_LINE_TARGETS and any(str(target).startswith("upload") for target in COMMAND_LINE_TARGETS):
    raise UserError("Application-only nobuild uploads are disabled: use the complete USB candidate image or a full build/upload with all boot components")

if env.subst("$PIOENV") in ("web_control_dev", "web_control_rollover_bench", "web_control_reference_probe", "web_control_multiturn_probe", "web_control_multiturn_startup"):
    # Development artifacts contain the local OTA credential.
    private_build = Path(env.subst("$BUILD_DIR"))
    private_build.mkdir(parents=True, exist_ok=True)
    private_build.chmod(0o700)


def verify_firmware(source, target, env):
    try:
        report_firmware(env.subst("$BUILD_DIR"), env.subst("$PROGNAME"))
        manifest=manifest_for_build(env.subst("$BUILD_DIR"),program=env.subst("$PROGNAME"),
                                    allow_multiturn_usb=env.subst("$PIOENV")=="web_control_multiturn_usb",allow_test_profile=True,
                                    allow_development=env.subst("$PIOENV")in ("web_control_dev", "web_control_rollover_bench", "web_control_reference_probe", "web_control_multiturn_probe", "web_control_multiturn_startup"))
        (Path(env.subst("$BUILD_DIR"))/"ota-manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")
        # Capture PlatformIO's actual USB inputs, not copied tutorial offsets.
        build_dir=Path(env.subst("$BUILD_DIR"))
        flags=[env.subst(str(value)) for value in env.get("UPLOADERFLAGS", [])]
        def flag(name):
            return flags[flags.index(name)+1]
        components=[dict(offset=int(str(offset),0),path=env.subst(str(path)))
                    for offset,path in env.get("FLASH_EXTRA_IMAGES", [])]
        components.append(dict(offset=int(env.subst("$ESP32_APP_OFFSET"),0),
                               path=str(build_dir / (env.subst("$PROGNAME")+".bin"))))
        if "--flash_mode" in flags:
            packages={}
            for name in ("framework-arduinoespressif32","tool-esptoolpy","toolchain-xtensa-esp32"):
                package=Path(env.PioPlatform().get_package_dir(name)) / "package.json"
                packages[name]=json.loads(package.read_text())["version"]
            inputs=dict(components=components,chip="ESP32",flash_mode=flag("--flash_mode"),
                        flash_freq=flag("--flash_freq"),flash_size=flag("--flash_size"),
                        esptool=env.subst("$UPLOADER"),packages=packages)
            (build_dir / "install-inputs.json").write_text(json.dumps(inputs,indent=2)+"\n")
        print("Bootstrap descriptor/ELF identity/strong deferred-acceptance hook verified; profile: "+manifest["profile"])
    except (OSError, ValueError) as error:
        raise UserError(f"Firmware check failed: {error}") from error


binary = str(Path(env.subst("$BUILD_DIR")) / (env.subst("$PROGNAME") + ".bin"))
env.Depends(binary, [env.subst("$BUILD_DIR/partitions.bin"),
                     str(Path(env.subst("$PROJECT_DIR")) / "tools/check_firmware.py")])
env.Depends(binary, str(Path(env.subst("$PROJECT_DIR")) / "tools/ota_manifest.py"))
env.AddPostAction(binary, verify_firmware)
# Revalidate the selected binary before a full USB build/upload.
env.AddPreAction("upload", verify_firmware)
