"""Explicit supervised startup-hang experiment; no host reset injection.

Install a private receiver-enabled source in app0 first. Build the candidate
from an isolated source snapshot using make_hang_source(), never the live src/.
Restore original slots and native otadata afterward, preserving live NVS.
"""
import argparse
import ipaddress
import json
from pathlib import Path
import re
import shutil
import socket
import time

from ota_upload import Artifact,LocalHttp,Uploader,WorkflowError,load_secret
from probe_ota_activation import UsbMonitor,RecordingHttp,ObservedTransfer,safe_status


def make_hang_source(source,destination,stage):
    if stage not in ('before_setup','setup'):raise ValueError('Explicit hang stage required')
    source=Path(source).resolve();destination=Path(destination).resolve()
    if destination==source or source in destination.parents or destination in source.parents:
        raise ValueError('An isolated destination outside the live source tree is required')
    if destination.exists():raise ValueError('Fresh private destination required')
    service=(source/'ota_service.cpp').read_text();main=(source/'main.cpp').read_text()
    # UART is already initialized by the bootloader; ROM output works before
    # Arduino setup/Serial.begin. Print the actual runtime ELF, never a secret.
    marker='''\n ets_printf("OTA TEST HANG stage=STAGE elf=");
 const auto* hangDesc=esp_ota_get_app_description();
 for(unsigned i=0;i<32;++i)ets_printf("%02x",hangDesc->app_elf_sha256[i]);
 ets_printf("\\n");
 for(;;)vTaskDelay(pdMS_TO_TICKS(10));\n'''.replace('STAGE',stage)
    if stage=='before_setup':
        anchor='rtc_wdt_set_time(RTC_WDT_STAGE0,45000);rtc_wdt_enable();rtc_wdt_protect_on();return true;'
        if service.count(anchor)!=1:raise ValueError('Watchdog arm anchor changed')
        service=service.replace(anchor,anchor.replace('return true;',marker))
    else:
        anchor='  cover::beginDiagnostics();'
        if main.count(anchor)!=1:raise ValueError('Setup diagnostics anchor changed')
        main=main.replace('#include <Arduino.h>','#include <Arduino.h>\n#include <esp_ota_ops.h>\n#include <rom/ets_sys.h>')
        main=main.replace(anchor,anchor+marker)
    if '#include <rom/ets_sys.h>' not in service:service=service.replace('#include <soc/rtc_wdt.h>','#include <soc/rtc_wdt.h>\n#include <rom/ets_sys.h>')
    shutil.copytree(source,destination);destination.chmod(0o700)
    (destination/'ota_service.cpp').write_text(service);(destination/'main.cpp').write_text(main)


class WatchdogUploader(Uploader):
    def reconcile(self,transaction,source,target,boot,duration=90):
        # 45 s independent RTC watchdog plus boot/network recovery. A timeout
        # is unconfirmed, never permission for a host reset/repeat.
        return super().reconcile(transaction,source,target,boot,duration)


def verify_watchdog_evidence(serial,stage,target,source,transaction,final,initial_boot):
    marker='OTA TEST HANG stage='+stage+' elf='+target
    if serial.count(marker)!=1:raise WorkflowError('Expected candidate hang marker missing or repeated')
    after=serial.split(marker,1)[1]
    reset=re.search(r'rst:0x[0-9a-f]+[^\n]*RTCWDT[^\n]*',after)
    if not reset or 'BOOT reset=' not in after[reset.end():] or 'elf_sha256='+source not in after[reset.end():]:
        raise WorkflowError('Autonomous RTC watchdog reset/source recovery not proved')
    if ('HOST INJECT' in serial or 'HOST early-reset armed' in serial
            or (stage=='before_setup' and 'elf_sha256='+target in serial)
            or 'OTA startup=accepted' in after[:reset.start()]
            or 'OTA startup health failed; requesting rollback' in after):
        raise WorkflowError('Unexpected reset, target acceptance or cooperative rollback evidence')
    record=final.get('ota',{}).get('last_update',{})
    if (final.get('firmware_id')!=source or final.get('ota',{}).get('boot_id')==initial_boot
            or final.get('ota',{}).get('startup')!='accepted'
            or record.get('transaction')!=transaction or record.get('outcome')!='rolled_back'
            or record.get('source_firmware')!=source or record.get('target_firmware')!=target
            or record.get('source_slot')!=0x10000 or record.get('target_slot')!=0x150000
            or record.get('selection_confirmed') is not True):
        raise WorkflowError('Watchdog rollback durable identity changed')
    return dict(stage=stage,candidate_hang_markers=1,rtc_watchdog_reset=reset.group(),
                host_reset_injected=False,transaction=transaction,outcome='ROLLED_BACK')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host',required=True,type=ipaddress.IPv4Address)
    parser.add_argument('--port',required=True)
    parser.add_argument('--source-build-dir',required=True,type=Path)
    parser.add_argument('--candidate-build-dir',required=True,type=Path)
    parser.add_argument('--source-secret-file',required=True,type=Path)
    parser.add_argument('--stage',required=True,choices=('before_setup','setup'))
    parser.add_argument('--supported-cover-off',action='store_true')
    parser.add_argument('--run-watchdog-experiment',action='store_true')
    parser.add_argument('--output',required=True,type=Path)
    args=parser.parse_args();monitor=None
    if not args.supported_cover_off or not args.run_watchdog_experiment:
        parser.error('Explicit supported-cover/OFF and watchdog experiment flags required')
    try:
        source=Artifact.load(args.source_build_dir);candidate=Artifact.load(args.candidate_build_dir)
        source_id=source.manifest['elf'];target_id=candidate.manifest['elf']
        if source_id==target_id:raise WorkflowError('Distinct hang candidate required')
        marker=('OTA TEST HANG stage='+args.stage+' elf=').encode()
        if marker not in candidate.image:raise WorkflowError('Candidate hang marker missing')
        secret=load_secret(args.source_secret_file);args.output.mkdir(mode=0o700,parents=True,exist_ok=True)
        with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as route:
            route.connect((str(args.host),80));local_ip=route.getsockname()[0]
        monitor=UsbMonitor(args.port,args.output);monitor.start() # Gate stays unarmed.
        with (args.output/'status.jsonl').open('w',buffering=1) as log:
            http=RecordingHttp(LocalHttp(str(args.host),local_ip),log);deadline=time.monotonic()+35
            while True:
                try:before=safe_status(http,source_id);break
                except (WorkflowError,OSError):
                    if time.monotonic()>=deadline:raise WorkflowError('Safe source startup unconfirmed')
                    time.sleep(1)
            boot=before['ota']['boot_id']
            result=WatchdogUploader(http,ObservedTransfer(str(args.host),local_ip,monitor)).run(candidate,secret,supported_cover_off=True)
            (args.output/'result.json').write_text(json.dumps(dict(outcome=result.outcome,transaction=result.transaction),indent=2)+'\n')
            if result.outcome!='ROLLED_BACK':raise WorkflowError('Autonomous watchdog rollback unconfirmed; no repeat/reset')
            final=safe_status(http,source_id)
            if monitor.error or monitor.gate.fired:raise WorkflowError('USB failure or host reset')
            monitor.close();monitor=None
            proof=verify_watchdog_evidence((args.output/'serial.log').read_text(),args.stage,target_id,source_id,result.transaction,final,boot)
            (args.output/'final-status.json').write_text(json.dumps(final,indent=2)+'\n')
            (args.output/'proof.json').write_text(json.dumps(proof,indent=2)+'\n')
            print(json.dumps(proof),flush=True)
    except (OSError,ValueError,WorkflowError,KeyboardInterrupt):
        parser.exit(1,'Watchdog experiment unconfirmed/stopped. Preserve evidence; restore normal slots/otadata over USB. No automatic repeat or host reset.\n')
    finally:
        if monitor is not None:monitor.close()


if __name__=='__main__':main()
