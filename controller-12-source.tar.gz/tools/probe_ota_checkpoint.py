"""Explicit power loss after durable intent, before boot-slot selection.

Use make_checkpoint_source() to build an isolated private receiver snapshot.
Its bounded post-persist barrier always rejects commit if no power cut occurs.
The live firmware source/defaults are unchanged. USB must be physically removed
before arming; this driver opens no serial port and injects no reset.
"""
import argparse
import ipaddress
import json
from pathlib import Path
import shutil
import socket
import time

from ota_upload import Artifact,EspotaTransfer,LocalHttp,WorkflowError,load_secret
from probe_ota_activation import RecordingHttp,safe_status
from probe_ota_power_loss import ManualPowerUploader

REASON='test_journal_checkpoint_waiting_power_cut'


def make_checkpoint_source(source,destination):
    source=Path(source).resolve();destination=Path(destination).resolve()
    if destination==source or source in destination.parents or destination in source.parents or destination.exists():
        raise ValueError('Fresh isolated snapshot outside live source required')
    text=(source/'ota_service.cpp').read_text()
    anchor='bool persist(OtaRecord& r){return saveRecord(r);}'
    if text.count(anchor)!=1:raise ValueError('Commit persist anchor changed')
    replacement='''bool persist(OtaRecord& r){
     const bool saved=saveRecord(r);
     if(saved){
      setPhase(Phase::Verified,"test_journal_checkpoint_waiting_power_cut");
      const uint32_t started=millis();
      while(uint32_t(millis()-started)<90000)vTaskDelay(pdMS_TO_TICKS(10));
     }
     return false; // Test barrier never permits selection, including on timeout.
    }'''
    shutil.copytree(source,destination);destination.chmod(0o700)
    (destination/'ota_service.cpp').write_text(text.replace(anchor,replacement))


def verify_checkpoint(status,boot,transaction,source,target,total):
    ota=status.get('ota',{});record=ota.get('last_update',{})
    if (status.get('firmware_id')!=source or ota.get('boot_id')!=boot
            or ota.get('transaction')!=transaction or ota.get('phase')!='verified'
            or ota.get('reason')!=REASON or ota.get('received')!=total or ota.get('active') is not True
            or record.get('schema')!=1 or record.get('transaction')!=transaction
            or record.get('outcome')!='activation_intent' or record.get('selection_confirmed') is not False
            or record.get('source_firmware')!=source or record.get('target_firmware')!=target
            or record.get('source_slot')!=0x10000 or record.get('target_slot')!=0x150000
            or status.get('ready') is not True or status.get('calibrated') is not True
            or status.get('dirty') is not False or status.get('holding') is not False
            or ota.get('startup')!='accepted'
            or status.get('maintenance',{}).get('owner')!='ota'
            or status['maintenance'].get('phase')!='ready' or status['maintenance'].get('locked') is not True
            or status.get('moving') is not False or status.get('torque') is not False
            or status.get('resources',{}).get('state')!='off' or status['resources'].get('viewers')!=0):
        raise WorkflowError('Durable checkpoint identity/safety not established')


class CheckpointTransfer(EspotaTransfer):
    def __init__(self,host,local_ip,record,source,target):
        super().__init__(host,local_ip,progress=self.after_ack)
        self.record=record;self.source=source;self.target=target;self.owner=None
        self.mode='journal_checkpoint';self.injected=False;self.window_expired=False;self.network_lost=False
        self.checkpoint=None;self.last_ack=0
    def after_ack(self,sent,total):
        self.last_ack=sent
        if sent!=total:return
        deadline=time.monotonic()+10
        while True:
            status=self.owner.get('/api/status');ota=status.get('ota',{})
            if ota.get('reason')==REASON:
                verify_checkpoint(status,self.owner.boot,self.owner.transaction,self.source,self.target,total)
                break
            if (ota.get('boot_id')!=self.owner.boot or ota.get('transaction')!=self.owner.transaction
                    or ota.get('active') is not True):raise WorkflowError('Checkpoint transaction changed')
            if time.monotonic()>=deadline:raise WorkflowError('Checkpoint did not arrive')
            time.sleep(.1)
        self.checkpoint=status;self.injected=True
        self.record('power_cut_cue',dict(transaction=self.owner.transaction,boot_id=self.owner.boot,
            received=sent,checkpoint=status))
        print('JOURNAL_CHECKPOINT_POWER_CUT_WINDOW_OPEN: durable intent verified, boot selection blocked. Remove confirmed sole power input now.',flush=True)
        deadline=time.monotonic()+70 # Leaves margin before private 90 s barrier ends.
        while time.monotonic()<deadline:
            time.sleep(.5)
            try:current=self.owner.get('/api/status')
            except WorkflowError:
                self.network_lost=True
                self.record('network_unreachable_after_cue',dict(transaction=self.owner.transaction))
                raise WorkflowError('Manual checkpoint power interruption; await first recovered boot')
            verify_checkpoint(current,self.owner.boot,self.owner.transaction,self.source,self.target,total)
        self.window_expired=True;self.record('window_expired',dict(transaction=self.owner.transaction))
        raise WorkflowError('Checkpoint window expired; private barrier cannot activate')


def verify_recovery(before,recovered,transaction,target):
    ota=recovered.get('ota',{});r=ota.get('last_update',{})
    if (recovered.get('firmware_id')!=before.get('firmware_id')
            or recovered.get('resources',{}).get('boot_id')==before.get('resources',{}).get('boot_id')
            or recovered.get('reset_reason')!='POWERON' or ota.get('startup')!='accepted'
            or recovered.get('ready') is not True or recovered.get('calibrated') is not True
            or recovered.get('moving') is not False or recovered.get('torque') is not False
            or recovered.get('dirty') is not False or recovered.get('fault')
            or recovered.get('maintenance',{}).get('locked') is not False
            or recovered.get('resources',{}).get('state')!='off' or recovered['resources'].get('viewers')!=0
            or ota.get('active') is not False or r.get('schema')!=1
            or r.get('transaction')!=transaction or r.get('outcome')!='unconfirmed'
            or r.get('selection_confirmed') is not False or r.get('source_firmware')!=before.get('firmware_id')
            or r.get('target_firmware')!=target or r.get('source_slot')!=0x10000 or r.get('target_slot')!=0x150000):
        raise WorkflowError('Checkpoint recovery identity/safety/journal evidence changed')
    for key in ['minimum','maximum','open','closed','saved_minimum','saved_maximum','saved_profile']:
        if before.get(key)!=recovered.get(key):raise WorkflowError('Saved setting changed')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host',required=True,type=ipaddress.IPv4Address)
    parser.add_argument('--source-build-dir',required=True,type=Path)
    parser.add_argument('--payload-build-dir',required=True,type=Path)
    parser.add_argument('--secret-file',required=True,type=Path)
    parser.add_argument('--supported-cover-off',action='store_true')
    parser.add_argument('--usb-removed-power-path-confirmed',action='store_true')
    parser.add_argument('--run-checkpoint-experiment',action='store_true')
    parser.add_argument('--output',required=True,type=Path)
    args=parser.parse_args()
    if not args.supported_cover_off or not args.usb_removed_power_path_confirmed or not args.run_checkpoint_experiment:
        parser.error('Explicit supported-cover/OFF, USB isolation and checkpoint experiment flags required')
    try:
        source=Artifact.load(args.source_build_dir);payload=Artifact.load(args.payload_build_dir)
        source_id=source.manifest['elf'];target=payload.manifest['elf']
        if source_id==target or REASON.encode() not in source.image:raise WorkflowError('Private checkpoint source required')
        secret=load_secret(args.secret_file);args.output.mkdir(mode=0o700,parents=True,exist_ok=True)
        with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as route:
            route.connect((str(args.host),80));local_ip=route.getsockname()[0]
        with (args.output/'status.jsonl').open('w',buffering=1) as log,(args.output/'actions.jsonl').open('w',buffering=1) as events:
            def record(kind,data):events.write(json.dumps(dict(at=time.monotonic(),kind=kind,data=data))+'\n')
            http=RecordingHttp(LocalHttp(str(args.host),local_ip),log);before=safe_status(http,source_id)
            (args.output/'source-before-status.json').write_text(json.dumps(before,indent=2)+'\n')
            sender=CheckpointTransfer(str(args.host),local_ip,record,source_id,target)
            result=ManualPowerUploader(http,sender,record).run(payload,secret,supported_cover_off=True)
            evidence=dict(outcome='UNCONFIRMED',transaction=result.transaction,checkpoint_reached=sender.injected,
                last_ack=sender.last_ack,window_expired=sender.window_expired,network_lost=sender.network_lost,checkpoint=sender.checkpoint,
                usb_opened=False,host_reset_injected=False,operator_off_confirmation_required=True)
            (args.output/'pending-evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
            if not sender.injected or sender.window_expired or not sender.network_lost:raise WorkflowError('Checkpoint cut not established')
            print('CHECKPOINT_INTERRUPTED: verify operator off-state, first recovered boot, image digests and native metadata.',flush=True)
    except (OSError,ValueError,WorkflowError,KeyboardInterrupt):
        parser.exit(1,'Checkpoint experiment stopped/unconfirmed. No automatic repeat. Preserve evidence and verify power state before recovery.\n')


if __name__=='__main__':main()
