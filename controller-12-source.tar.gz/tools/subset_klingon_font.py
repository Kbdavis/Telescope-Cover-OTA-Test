"""Regenerate the embedded pIqaD font from Evertype's klingon-piqad-hasta.zip.
Usage: python tools/subset_klingon_font.py /path/to/klingon-piqad-hasta.zip
Requires fonttools and brotli; not needed for normal firmware builds.
Source: https://www.evertype.com/fonts/tlh/klingon-piqad-hasta.zip
"""
from pathlib import Path
from zipfile import ZipFile
from io import BytesIO
import base64
import re
import sys
from fontTools.ttLib import TTFont
from fontTools import subset

with ZipFile(sys.argv[1]) as archive:
    font = TTFont(BytesIO(archive.read('klingon-piqad-hasta-203/Klingon-pIqaD-HaSta.ttf')))
    license_text = archive.read('klingon-piqad-hasta-203/pIqaD-HaSta-licence.txt').decode()
options = subset.Options()
options.name_IDs = ['*']
options.name_legacy = True
subsetter = subset.Subsetter(options=options)
subsetter.populate(unicodes=[32, *range(0xf8d0, 0xf8ea)])
subsetter.subset(font)
for name in font['name'].names:
    if name.nameID in (1, 3, 4, 6, 16):
        name.string = 'Cover Warrior Display'.encode(name.getEncoding())
font['name'].setName(license_text, 13, 3, 1, 0x409)
font.flavor = 'woff2'
output = BytesIO()
font.save(output)
css = Path(__file__).resolve().parents[1] / 'data/ui/live.css'
css.write_text(re.sub(r'data:font/woff2;base64,[A-Za-z0-9+/=]+',
                     'data:font/woff2;base64,' + base64.b64encode(output.getvalue()).decode(),
                     css.read_text()).replace('The five pIqaD glyphs spell tlhIngan.', 'The pIqaD alphabet supports the bundled translations.'))
print('Embedded WOFF2 bytes:', len(output.getvalue()))
