#!/usr/bin/env python3
"""Timestamp passive ESP32 USB logs and preserve the matching local build artifacts."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shutil
import time

ROOT = Path(__file__).resolve().parents[1]


def timestamp():
    return datetime.now(timezone.utc).isoformat(timespec='milliseconds')


def redact(line):
    line = re.sub(r'(?i)(\bauthorization\s*[=:]\s*)[^\r\n]+', r'\1[redacted]', line)
    return re.sub(r'''(?ix)(\b(?:[\w-]*(?:password|passphrase|secret|token|verifier|credential)|(?:api|auth|seestar)[_-]?key)\s*[=:]\s*)
                  (?:"[^"\r\n]*"|'[^'\r\n]*'|[^\s,;}]+)''', r'\1[redacted]', line)


def archive_build(destination, build_dir):
    artifacts = {}
    for name in ('firmware.elf', 'firmware.bin'):
        source = build_dir / name
        if not source.is_file():
            raise FileNotFoundError(f'Build first: missing {source}')
        target = destination / name
        shutil.copy2(source, target)
        target.chmod(0o600)
        artifacts[name] = hashlib.sha256(target.read_bytes()).hexdigest()
    return artifacts


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port', default='/dev/cu.usbserial-0001')
    parser.add_argument('--baud', type=int, default=115200)
    parser.add_argument('--duration', type=float, default=0, help='Seconds; 0 captures until Ctrl-C')
    parser.add_argument('--output', type=Path, default=ROOT / 'diagnostics')
    parser.add_argument('--build-dir', type=Path, default=ROOT / '.pio/build/web_control')
    args = parser.parse_args()
    if args.duration < 0:
        parser.error('Duration must be nonnegative')
    import serial
    directory = args.output / datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    directory.mkdir(parents=True)
    artifacts = archive_build(directory, args.build_dir)
    manifest = dict(created_utc=timestamp(), port=args.port, baud=args.baud,
                    artifacts_sha256=artifacts,
                    note='Compare boot elf_sha256 with firmware.elf hash to confirm running build. Artifacts may contain compiled Wi-Fi credentials.')
    (directory / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(f'Capture folder: {directory}', flush=True)
    print('No serial commands or reset pulses are sent. Opening/reconnecting USB may still reset some boards.', flush=True)
    deadline = time.monotonic() + args.duration if args.duration else float('inf')
    port = None
    pending = b''
    with (directory / 'serial.log').open('w', buffering=1) as log:
        def record(line):
            text = f'{timestamp()} {redact(line)}'
            print(text, flush=True)
            log.write(text + '\n')
        try:
            while time.monotonic() < deadline:
                try:
                    if port is None:
                        port = serial.Serial(port=None, baudrate=args.baud, timeout=.25)
                        port.dtr = False
                        port.rts = False
                        port.port = args.port
                        port.open()
                        record('CAPTURE USB opened; possible open-induced reset; no writes')
                    chunk = port.read(min(max(port.in_waiting, 1), 4096))
                    pending += chunk
                    while b'\n' in pending:
                        line, pending = pending.split(b'\n', 1)
                        record(line.decode('utf-8', errors='replace').rstrip('\r'))
                    if len(pending) > 8192:
                        record(pending.decode('utf-8', errors='replace') + ' [partial]')
                        pending = b''
                except (serial.SerialException, OSError) as error:
                    record(f'CAPTURE USB error: {error}; reconnecting in 1 second')
                    if pending:
                        record(pending.decode('utf-8', errors='replace') + ' [partial before disconnect]')
                        pending = b''
                    if port is not None:
                        try:
                            port.close()
                        except (serial.SerialException, OSError):
                            pass
                        port = None
                    time.sleep(1)
        except KeyboardInterrupt:
            record('CAPTURE stopped by operator')
        finally:
            if pending:
                record(pending.decode('utf-8', errors='replace') + ' [partial]')
            if port is not None:
                port.close()
            record('CAPTURE finished')


if __name__ == '__main__':
    main()
