"""Supervised USB test-profile receiver: verify inactive flash, NEVER activate.

Production OTA commands remain disabled. Requires a current all-erased app1
backup, a distinct USB test build, an owner-only secret file and explicit cover
support confirmation. NOACT and post-cleanup evidence are not deployment success.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import ipaddress
import json
from pathlib import Path
import socket
import threading
import time

from capture_diagnostics import archive_build
from measure_ota_resources import Measurement
from ota_manifest import control_mac, manifest_for_build, prepare_body
from ota_upload import Artifact, EspotaTransfer, LocalHttp, WorkflowError, hex_id, load_secret

PREFIX='/api/ota/probe'
MODE='inactive_flash_no_activation'


def validate_slot_backup(data):
    if len(data)!=0x140000 or data!=b'\xff'*len(data):
        raise WorkflowError('Inactive slot must be fully backed up and entirely erased')
    return hashlib.sha256(data).hexdigest()


def check_state(s, expected, boot=None):
    ota=s.get('ota',{});probe=ota.get('probe',{})
    if (ota.get('firmware_id')!=expected or ota.get('startup')!='accepted' or ota.get('available') is not False
            or probe.get('mode')!=MODE or s.get('moving') is not False or s.get('torque') is not False
            or s.get('ready') is not True or s.get('dirty') is not False or s.get('calibrated') is not True
            or not hex_id(ota.get('boot_id'),32) or (boot and ota['boot_id']!=boot)):
        raise WorkflowError('Test image, boot or stationary OFF conditions changed')
    return ota


def verified_result(s, transaction, manifest, source, boot):
    ota=check_state(s,source,boot);probe=ota['probe']
    return (ota.get('transaction')==transaction and ota.get('active') is False
            and ota.get('phase')=='verified' and ota.get('reason')=='probe_verified_not_activated'
            and probe.get('verified') is True and probe.get('source_slot')==0x10000
            and probe.get('target_slot')==0x150000 and probe.get('target_firmware')==manifest['elf']
            and probe.get('sha256')==manifest['sha256'] and ota.get('received')==manifest['size']
            and s.get('maintenance',{}).get('locked') is False)


class Observer:
    """One root/OTA snapshot per second; no bulk events during transfer."""
    def __init__(self,http,source,boot,viewer,record):
        self.http,self.source,self.boot,self.viewer,self.record=http,source,boot,viewer,record
        self.stop=threading.Event();self.thread=None;self.latest=None;self.error=False;self.samples=[]
    def start(self):
        self.thread=threading.Thread(target=self.run,daemon=True);self.thread.start()
    def run(self):
        renew_at=time.monotonic()+2
        try:
            while not self.stop.is_set():
                at=time.monotonic()
                if self.viewer is not None and at>=renew_at:
                    self.viewer.metrics('renew');renew_at=time.monotonic()+2
                code,s=self.http.request('GET','/api/status')
                if code!=200 or not isinstance(s,dict):raise WorkflowError('Status failed')
                check_state(s,self.source,self.boot)
                if self.viewer is None and (s.get('resources',{}).get('state')!='off' or s['resources'].get('viewers')!=0):
                    raise WorkflowError('Passive USB measurement requires metrics OFF')
                self.latest=s;self.record('status',s)
                if s.get('resources',{}).get('available') is True:self.samples.append(s['resources'])
                self.stop.wait(max(0,1-(time.monotonic()-at)))
        except (WorkflowError,ValueError,OSError) as error:
            # Only fixed local classifications are retained, never HTTP bodies.
            self.record('observer_failure',{'category':type(error).__name__,
                                           'reason':str(error) if isinstance(error,WorkflowError) else 'local observation failed'})
            self.error=True;self.stop.set()
    def close(self):
        self.stop.set()
        if self.thread:
            self.thread.join(6)
            if self.thread.is_alive():raise WorkflowError('Observer did not stop')
    def progress(self,*_):
        if self.error:raise WorkflowError('Resource observer failed')


class FlashProbe:
    def __init__(self,http,transport,source,secret,record=lambda *_:None,*,memory_evidence=False,passive_usb=False):
        if memory_evidence and passive_usb:raise WorkflowError('Choose USB or metrics boundary measurement')
        self.http,self.transport,self.source,self.secret,self.record=http,transport,source,secret,record
        self.boot='';self.memory_evidence=memory_evidence;self.memory=None;self.memory_epoch=0
        self.passive_usb=passive_usb
    def capture_memory(self):
        s=self.get(PREFIX+'/memory')
        stages={'request_arena','request_released','status_start','status_built','status_sent','tcp_connected',
                'begin_before','begin_after','write_before','write_after','end_before','end_after'}
        if (s.get('schema')!=1 or s.get('scope')!='boundary_samples' or s.get('boot_id')!=self.boot
                or type(s.get('epoch')) is not int or not 0<s['epoch']<=0xffffffff
                or (self.memory_epoch and s['epoch']!=self.memory_epoch)
                or s.get('storage_bytes')!=484 or not isinstance(s.get('rows'),list) or not 0<len(s['rows'])<=24):
            raise WorkflowError('Invalid memory evidence envelope')
        seen=set();rows=[]
        for row in s['rows']:
            if (not isinstance(row,dict) or type(row.get('stage')) is not str or row['stage'] not in stages or type(row.get('ota_active')) is not bool
                    or any(type(row.get(k)) is not int or not 0<=row[k]<=0xffffffff
                           for k in ('count','min_free','min_block','at_ms','max_bytes')) or row['count']==0):
                raise WorkflowError('Invalid memory evidence row')
            key=(row['stage'],row['ota_active'])
            if key in seen:raise WorkflowError('Duplicate memory evidence row')
            seen.add(key);rows.append({k:row[k] for k in ('stage','ota_active','count','min_free','min_block','at_ms','max_bytes')})
        self.memory=dict(schema=1,scope='boundary_samples',boot_id=self.boot,epoch=s['epoch'],storage_bytes=484,rows=rows)
        self.record('memory_boundaries',self.memory)
    def get(self,path):
        code,s=self.http.request('GET',path)
        if code!=200 or not isinstance(s,dict):raise WorkflowError('Probe read unavailable')
        return s
    def signed(self,path,body,transaction=''):
        for _ in range(3):
            code,c=self.http.request('GET',PREFIX+'/challenge')
            if code!=429:break
            time.sleep(1)
        if (code!=200 or not isinstance(c,dict) or c.get('schema')!=1 or c.get('boot_id')!=self.boot
                or not hex_id(c.get('nonce'),32) or c.get('expires_ms')!=10000):
            raise WorkflowError('Fresh probe challenge unavailable')
        mac=control_mac(self.secret,'POST',path,self.boot,c['nonce'],transaction,body)
        return self.http.request('POST',path,body,{'Content-Type':'text/plain','Content-Length':str(len(body)),
                                                'X-Ota-Nonce':c['nonce'],'X-Ota-Mac':mac})
    def cancel(self,transaction):
        if not transaction:return
        try:
            s=self.get('/api/status');ota=check_state(s,self.source,self.boot)
            if ota.get('transaction')==transaction and ota.get('active') is True:
                self.signed(PREFIX+'/cancel',f'transaction={transaction}\n'.encode('ascii'),transaction)
        except WorkflowError:pass
    def run(self,artifact,*,supported_cover_off=False):
        if supported_cover_off is not True:raise WorkflowError('Explicit supported-cover/OFF confirmation required')
        manifest=artifact.manifest;s=self.get('/api/status');ota=check_state(s,self.source)
        if (ota['probe'].get('available') is not True or ota['probe'].get('attempted') is not False
                or s.get('maintenance',{}).get('locked') is not False or s.get('resources',{}).get('state')!='off'
                or s['resources'].get('viewers')!=0 or self.source==manifest['elf']):
            raise WorkflowError('Fresh one-shot probe and exclusive metrics access required')
        self.boot=ota['boot_id'];self.record('before',s)
        viewer=None
        if not self.passive_usb:
            session=self.get('/api/session')
            if session.get('boot_id')!=self.boot or session.get('beta_accepted') is not True or session.get('setup_only') is not False:
                raise WorkflowError('Metrics session unavailable')
            viewer=Measurement(self.http,self.source);viewer.boot=self.boot;viewer.token=session.get('token','');viewer.client=791390177
            if not viewer.token:raise WorkflowError('Metrics credential unavailable')
        observer=Observer(self.http,self.source,self.boot,viewer,self.record);transaction='';done=False
        try:
            if viewer is not None:
                viewer.subscribed=True;viewer.metrics('subscribe',s)
            observer.start()
            # Wait for a usable metrics snapshot before preparation.
            deadline=time.monotonic()+5
            while not (observer.latest if self.passive_usb else observer.samples) and time.monotonic()<deadline and not observer.error:time.sleep(.05)
            if observer.error or not observer.latest or (not self.passive_usb and not observer.samples):raise WorkflowError('No resource snapshot before transfer')
            with self.transport as sender:
                sender.progress=observer.progress
                fresh=observer.latest
                if self.memory_evidence:
                    self.memory_epoch=fresh.get('resources',{}).get('epoch')
                    if type(self.memory_epoch) is not int or not 0<self.memory_epoch<=0xffffffff:
                        raise WorkflowError('Fresh memory measurement epoch unavailable')
                body=prepare_body(manifest,fresh['control_generation'])
                code,prepared=self.signed(PREFIX+'/prepare',body)
                if (code!=202 or not isinstance(prepared,dict) or prepared.get('boot_id')!=self.boot
                        or not hex_id(prepared.get('transaction'),32)):
                    raise WorkflowError('Probe rejected or preparation outcome unknown; never retry automatically')
                transaction=prepared['transaction'];deadline=time.monotonic()+10
                while time.monotonic()<deadline:
                    observer.progress();current=observer.latest or {};state=current.get('ota',{})
                    if state.get('transaction')==transaction and state.get('phase')=='armed':break
                    if state.get('transaction')==transaction and state.get('phase') in ('failed','cancelled'):
                        raise WorkflowError('Probe admission/arming failed')
                    time.sleep(.05)
                else:raise WorkflowError('Probe arming timed out')
                sender.send(artifact,self.secret)
            deadline=time.monotonic()+10
            while time.monotonic()<deadline:
                observer.progress()
                if observer.latest and verified_result(observer.latest,transaction,manifest,self.source,self.boot):
                    done=True;break
                time.sleep(.05)
            if not done:raise WorkflowError('Inactive verification/cleanup unconfirmed')
            # Allow a post-transfer OTA self-scan before ending the metrics epoch.
            time.sleep(6);observer.progress()
        except (WorkflowError,KeyboardInterrupt) as error:
            self.record('failure',{'category':type(error).__name__,
                                  'reason':str(error) if isinstance(error,WorkflowError) else 'interrupted'})
            self.cancel(transaction);raise
        finally:
            try:
                observer.close()
                if self.memory_evidence and transaction:
                    try:self.capture_memory()
                    except WorkflowError:
                        self.record('memory_unavailable',{'reason':'Completed test evidence unavailable'})
                        if done:raise
            finally:
                if viewer is not None and viewer.subscribed:
                    try:viewer.metrics('unsubscribe')
                    finally:viewer.token=''
                self.secret=b''
        # Return only after OFF and maintenance cleanup are independently seen.
        deadline=time.monotonic()+6
        while time.monotonic()<deadline:
            s=self.get('/api/status');check_state(s,self.source,self.boot)
            if s.get('resources',{}).get('state')=='off' and s['resources'].get('viewers')==0:break
            time.sleep(.25)
        else:raise WorkflowError('Metrics OFF not confirmed')
        self.record('after',s)
        if not verified_result(s,transaction,manifest,self.source,self.boot):raise WorkflowError('Final probe result changed')
        keys=('internal_free_heap_bytes','internal_min_free_heap_bytes','internal_largest_free_block_bytes')
        summary={} if self.passive_usb else {key:min(r[key] for r in observer.samples) for key in keys}
        stacks={}
        for r in observer.samples:
            for name,value in r.get('task_stacks',{}).items():
                if isinstance(value,dict) and value.get('sample_age_ms',10001)<=10000:
                    stacks[name]=min(stacks.get(name,value['min_free_bytes']),value['min_free_bytes'])
        summary.update(outcome='VERIFIED_NOT_ACTIVATED',transaction=transaction,source_firmware=self.source,
                       target=manifest,stack_min_free_bytes=stacks,samples=len(observer.samples),metrics_cleanup='off',
                       selected_slot=0x10000,target_slot=0x150000)
        summary['measurement']='passive_usb' if self.passive_usb else 'metrics_viewer'
        if self.memory_evidence:summary['memory_boundaries']=self.memory
        return summary


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host',required=True,type=ipaddress.IPv4Address)
    parser.add_argument('--build-dir',required=True,type=Path,help='Production payload')
    parser.add_argument('--probe-build-dir',required=True,type=Path)
    parser.add_argument('--blank-slot-backup',required=True,type=Path)
    parser.add_argument('--secret-file',required=True,type=Path)
    parser.add_argument('--supported-cover-off',action='store_true')
    parser.add_argument('--memory-evidence',action='store_true',help='Fetch test-only boundary evidence after transfer, before metrics cleanup')
    parser.add_argument('--passive-usb',action='store_true',help='Keep metrics OFF; memory evidence must be captured independently over USB')
    parser.add_argument('--output',type=Path,default=Path('diagnostics'))
    args=parser.parse_args()
    if not args.supported_cover_off:parser.error('Confirm supported cover and torque OFF')
    if args.passive_usb and args.memory_evidence:parser.error('Choose passive USB or metrics boundary evidence')
    try:
        backup_hash=validate_slot_backup(args.blank_slot_backup.read_bytes())
        artifact=Artifact.load(args.build_dir);probe=manifest_for_build(args.probe_build_dir,allow_test_profile=True)
        if probe['profile']!='test_profile':raise WorkflowError('Expected incompatible USB test image')
        secret=load_secret(args.secret_file)
        with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as route:
            route.connect((str(args.host),80));local_ip=route.getsockname()[0]
        directory=args.output/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ');directory.mkdir(parents=True,mode=0o700)
        archive_build(directory,args.build_dir)
        (directory/'manifest.json').write_text(json.dumps(dict(payload=artifact.manifest,probe=probe,blank_slot_backup_sha256=backup_hash),indent=2)+'\n')
        print('Nonactivating flash-probe folder:',directory,flush=True)
        with (directory/'samples.jsonl').open('w',buffering=1) as log:
            def record(kind,value):log.write(json.dumps(dict(utc=datetime.now(timezone.utc).isoformat(),kind=kind,data=value))+'\n')
            transfer=EspotaTransfer(str(args.host),local_ip,final_result=b'NOACT')
            result=FlashProbe(LocalHttp(str(args.host),local_ip),transfer,probe['elf'],secret,record,
                              memory_evidence=args.memory_evidence,passive_usb=args.passive_usb).run(artifact,supported_cover_off=True)
        (directory/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
        print(json.dumps(result,indent=2))
    except (OSError,ValueError,WorkflowError,KeyboardInterrupt) as error:
        # WorkflowError messages are fixed local classifications; never echo
        # OS errors, controller bodies, credentials or arbitrary parser values.
        reason=str(error) if isinstance(error,WorkflowError) else 'local validation, I/O or interruption'
        cleanup='No metrics subscription was requested.' if args.passive_usb else 'Metrics cleanup was attempted; lost leases expire.'
        parser.exit(1,'Flash probe stopped or unconfirmed: '+reason+'. No automatic retry or activation is supported; inspect private evidence and restore production over USB. '+cleanup+'\n')


if __name__=='__main__':main()
