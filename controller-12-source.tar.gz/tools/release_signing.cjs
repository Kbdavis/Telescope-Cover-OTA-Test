/* Offline signing preview only. No CLI, production key provisioning or firmware
   integration. Callers supply keys; envelopes never supply their own trust root. */
'use strict';
const crypto=require('node:crypto');
const metadata=require('../data/ui/release_metadata.js');
const SCHEMA='telescope-cover-signature-preview/1';
const ALGORITHM='ecdsa-p256-sha256-p1363';
const MAX_PAYLOAD=4096;
function fail(reason){throw Error(reason);}
function keyId(id){if(typeof id!=='string' || !/^[a-z][a-z0-9-]{0,47}$/.test(id) || id.endsWith('\n'))fail('Invalid key ID');}
function keyObject(key,type){
 const value=key instanceof crypto.KeyObject?key:type==='private'?crypto.createPrivateKey(key):crypto.createPublicKey(key);
 if(value.type!==type || value.asymmetricKeyType!=='ec' || value.asymmetricKeyDetails.namedCurve!=='prime256v1')fail('Expected a P-256 '+type+' key');
 return value;
}
function payloadBytes(text){
 if(typeof text!=='string')fail('Expected exact UTF-8 manifest text');
 const bytes=Buffer.from(text,'utf8');
 if(bytes.length>MAX_PAYLOAD || bytes.toString('utf8')!==text)fail('Manifest payload exceeds signing limit or contains invalid Unicode');
 metadata.parseReleaseJson(text);return bytes;
}
function signPreview(text,id,privateKey){
 keyId(id);const bytes=payloadBytes(text),key=keyObject(privateKey,'private');
 const signature=crypto.sign('sha256',bytes,{key,dsaEncoding:'ieee-p1363'});
 return {schema:SCHEMA,key_id:id,algorithm:ALGORITHM,payload:bytes.toString('base64'),signature:signature.toString('base64')};
}
function decode64(value,maxBytes){
 if(typeof value!=='string' || value.length>4*Math.ceil(maxBytes/3) || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(value) || value.endsWith('\n'))fail('Invalid canonical base64');
 const bytes=Buffer.from(value,'base64');if(bytes.length>maxBytes || bytes.toString('base64')!==value)fail('Invalid base64 bytes');return bytes;
}
function verifyPreview(envelope,trustedKeys,revokedIds=new Set()){
 const keys=['schema','key_id','algorithm','payload','signature'];
 if(!envelope || typeof envelope!=='object' || Array.isArray(envelope) || Object.keys(envelope).length!==keys.length || keys.some(k=>!Object.prototype.hasOwnProperty.call(envelope,k)))fail('Invalid signature envelope');
 if(envelope.schema!==SCHEMA || envelope.algorithm!==ALGORITHM)fail('Unsupported signature contract');
 keyId(envelope.key_id);
 if(!(trustedKeys instanceof Map) || !(revokedIds instanceof Set) || revokedIds.has(envelope.key_id) || !trustedKeys.has(envelope.key_id))fail('Unknown or revoked signing key');
 if(trustedKeys.size>4)fail('Too many trusted keys');
 const points=new Set();
 for(const [id,value] of trustedKeys){
  keyId(id);const point=keyObject(value,'public').export({type:'spki',format:'der'}).toString('hex');
  if(points.has(point))fail('Duplicate public key alias');points.add(point);
 }
 const key=keyObject(trustedKeys.get(envelope.key_id),'public');
 const bytes=decode64(envelope.payload,MAX_PAYLOAD),signature=decode64(envelope.signature,64);
 if(signature.length!==64 || !crypto.verify('sha256',bytes,{key,dsaEncoding:'ieee-p1363'},signature))fail('Signature verification failed');
 const text=new TextDecoder('utf-8',{fatal:true}).decode(bytes);
 const release=metadata.parseReleaseJson(text);
 // Authentication here means only this supplied local trust map verified the
 // exact preview payload. It does not attest publication or hardware acceptance.
 return {preview:true,signature_valid:true,key_id:envelope.key_id,release,installable:false};
}
module.exports=Object.freeze({SCHEMA,ALGORITHM,MAX_PAYLOAD,signPreview,verifyPreview});
