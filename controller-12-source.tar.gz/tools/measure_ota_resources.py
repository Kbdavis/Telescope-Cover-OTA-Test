"""Stationary OTA resource measurements; only explicit metrics-viewer POSTs.

No actuator, settings, OTA control, invitations or flash requests are issued.
Credentials from /api/session remain in process memory, never in evidence.
"""
import argparse
from datetime import datetime, timezone
import ipaddress
import json
from pathlib import Path
import socket
import time
import urllib.parse

from capture_diagnostics import archive_build
from ota_manifest import manifest_for_build
from ota_upload import LocalHttp, WorkflowError


class Measurement:
    def __init__(self, http, expected_elf, probe=False, *, clock=time.monotonic, sleep=time.sleep, record=lambda *_: None):
        self.http, self.expected, self.probe = http, expected_elf, probe
        self.clock, self.sleep, self.record = clock, sleep, record
        self.client, self.generation = 731820401, 1
        self.token, self.boot = '', ''
        self.subscribed = False
        self.samples = []

    def get(self, route):
        code, value = self.http.request('GET', route)
        if code != 200 or not isinstance(value, dict):
            raise WorkflowError('Measurement read failed')
        return value

    def status(self):
        value = self.get('/api/status')
        ota = value.get('ota', {})
        if (ota.get('firmware_id') != self.expected or ota.get('startup') != 'accepted'
                or ota.get('available') is not False or value.get('moving') is not False
                or value.get('torque') is not False or value.get('ready') is not True
                or value.get('dirty') is not False or value.get('calibrated') is not True
                or value.get('maintenance', {}).get('locked') is not False):
            raise WorkflowError('Measurement stopped: identity/startup/OFF conditions changed')
        if self.boot and ota.get('boot_id') != self.boot:
            raise WorkflowError('Measurement stopped: controller rebooted')
        if self.probe and ota.get('reason') != 'resource_probe_no_admission':
            raise WorkflowError('Expected resource-only firmware is not running')
        return value

    def metrics(self, action, status=None):
        fields = dict(boot_id=self.boot, generation=self.generation)
        if action == 'subscribe':
            fields['observed_uptime_ms'] = status['uptime_ms']
        body = urllib.parse.urlencode(fields).encode('ascii')
        code, reply = self.http.request('POST', '/api/diagnostics/metrics/' + action, body,
                                      {'X-Cover-Token': self.token, 'X-Cover-Client': str(self.client),
                                       'Content-Type': 'application/x-www-form-urlencoded'})
        if code != 200 or not isinstance(reply, dict) or reply.get('accepted') is not True:
            raise WorkflowError('Metrics lease rejected')

    def run(self, duration=25, off_duration=8):
        initial = self.status()
        resources = initial.get('resources', {})
        if resources.get('state') != 'off' or resources.get('viewers') != 0:
            raise WorkflowError('Close other metrics viewers before an isolated measurement')
        self.boot = initial['ota']['boot_id']
        self.record('off_before', initial)
        # Baseline polling must not subscribe or start the synthetic workload.
        deadline = self.clock() + off_duration
        while self.clock() < deadline:
            s = self.status()
            if s.get('resources', {}).get('state') != 'off':
                raise WorkflowError('Another metrics viewer changed the isolated baseline')
            self.record('off_before', s)
            self.sleep(1)
        session = self.get('/api/session')
        if session.get('boot_id') != self.boot or session.get('setup_only') is not False or session.get('beta_accepted') is not True:
            raise WorkflowError('Metrics session unavailable')
        self.token = session.get('token', '')
        if not self.token:
            raise WorkflowError('Metrics credential unavailable')
        try:
            # Set cleanup intent first: a lost subscribe response may hide success.
            self.subscribed = True
            self.metrics('subscribe', self.status())
            deadline, renew_at = self.clock() + duration, self.clock() + 2
            while self.clock() < deadline:
                if self.clock() >= renew_at:
                    self.metrics('renew'); renew_at = self.clock() + 2
                s = self.status()
                self.record('active', s)
                r = s.get('resources', {})
                if r.get('state') not in ('starting', 'active') or r.get('viewers') != 1:
                    raise WorkflowError('Metrics viewer changed or lease expired')
                if r.get('available') is True:
                    if r.get('debug_log_capacity') != 20 or r.get('debug_log_available') is not True:
                        raise WorkflowError('Expected controller log allocation missing')
                    self.samples.append(r)
                self.record('alpaca', self.get('/api/alpaca/status'))
                code, debug = self.http.request('GET', '/api/debug?after=0')
                # Two shared log batches/second; another reader can consume one.
                if code == 200:
                    self.record('debug', debug)
                elif code != 503:
                    raise WorkflowError('Bounded event read failed')
                self.sleep(1)
        finally:
            if self.subscribed:
                try:
                    self.metrics('unsubscribe')
                finally:
                    self.token = ''
        # Never close or modify somebody else's viewer. Only verify our cleanup.
        deadline = self.clock() + 4
        while True:
            s = self.status();r = s.get('resources', {})
            if r.get('state') == 'off' and r.get('viewers') == 0:
                break
            if self.clock() >= deadline:
                raise WorkflowError('Metrics cleanup not confirmed; lease expiry is the fallback')
            self.sleep(.25)
        self.record('off_after', s)
        deadline = self.clock() + off_duration
        while self.clock() < deadline:
            s = self.status()
            if s.get('resources', {}).get('state') != 'off' or s['resources'].get('viewers') != 0:
                raise WorkflowError('Another metrics viewer changed the final OFF observation')
            self.record('off_after', s);self.sleep(1)
        if not self.samples:
            raise WorkflowError('No fresh resource sample collected')
        keys = ('internal_free_heap_bytes', 'internal_min_free_heap_bytes', 'internal_largest_free_block_bytes')
        summary = {key: min(r[key] for r in self.samples) for key in keys}
        tasks = {}
        for r in self.samples:
            for name, sample in r.get('task_stacks', {}).items():
                if isinstance(sample, dict) and sample.get('sample_age_ms', 10001) <= 10000:
                    tasks[name] = min(tasks.get(name, sample['min_free_bytes']), sample['min_free_bytes'])
        if self.probe and 'ota' not in tasks:
            raise WorkflowError('Resource worker produced no OTA stack sample')
        summary.update(firmware_id=self.expected, resource_probe=self.probe, samples=len(self.samples),
                       stack_min_free_bytes=tasks, metrics_cleanup='off', ota_admission=False,
                       scope='current-workload; synthetic-no-flash-no-transfer' if self.probe else 'current-workload; receiver-disabled')
        return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host', required=True, type=ipaddress.IPv4Address)
    parser.add_argument('--build-dir', required=True, type=Path)
    parser.add_argument('--probe', action='store_true')
    parser.add_argument('--duration', type=int, default=25)
    parser.add_argument('--off-duration', type=int, default=8)
    parser.add_argument('--output', type=Path, default=Path('diagnostics'))
    args = parser.parse_args()
    if not 20 <= args.duration <= 600 or not 5 <= args.off_duration <= 120:
        parser.error('Duration must be 20..600 seconds; OFF windows 5..120 seconds')
    try:
        manifest = manifest_for_build(args.build_dir, allow_test_profile=args.probe)
        if args.probe and manifest['profile'] != 'test_profile':
            raise WorkflowError('Probe requires the incompatible test image profile')
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as route:
            route.connect((str(args.host), 80)); local_ip = route.getsockname()[0]
        directory = args.output / datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
        directory.mkdir(parents=True, mode=0o700)
        hashes = archive_build(directory, args.build_dir)
        (directory / 'manifest.json').write_text(json.dumps(dict(artifact=manifest, hashes=hashes), indent=2) + '\n')
        print('Measurement folder:', directory, flush=True)
        with (directory / 'samples.jsonl').open('w', buffering=1) as log:
            def record(phase, data):
                log.write(json.dumps(dict(utc=datetime.now(timezone.utc).isoformat(), phase=phase, data=data)) + '\n')
            measurement = Measurement(LocalHttp(str(args.host), local_ip), manifest['elf'], args.probe, record=record)
            result = measurement.run(args.duration, args.off_duration)
        (directory / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps(result, indent=2))
    except (OSError, ValueError, WorkflowError):
        parser.exit(1, 'Resource measurement failed; verify stationary torque OFF, image identity and exclusive metrics access. Cleanup was attempted; any lost lease expires in five seconds.\n')


if __name__ == '__main__':
    main()
