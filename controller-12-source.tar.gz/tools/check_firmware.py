"""Offline size/layout check. This is not an OTA image or publisher validator."""
import argparse
import hashlib
from pathlib import Path
import struct


# Frozen deployment layout, independent of the framework's future defaults.
# label, type, subtype, offset, size, flags
EXPECTED_PARTITIONS = (
    ("nvs", 1, 2, 0x9000, 0x5000, 0),
    ("otadata", 1, 0, 0xE000, 0x2000, 0),
    ("app0", 0, 0x10, 0x10000, 0x140000, 0),
    ("app1", 0, 0x11, 0x150000, 0x140000, 0),
    ("spiffs", 1, 0x82, 0x290000, 0x160000, 0),
    ("coredump", 1, 3, 0x3F0000, 0x10000, 0),
)
OTA_UPLOAD_DISABLED = (
    "OTA upload is disabled for production builds. "
    "Use web_control_ota for local builds only; supervised local development "
    "uses web_control_dev and tools/ota_upload.py upload-dev."
)


def upload_blocked(environment, targets):
    """Reject device operations in the reserved OTA environment before actions run."""
    device_targets = {"program", "erase", "__test", "__debug"}
    return environment == "web_control_ota" and any(
        str(target).startswith("upload") or str(target) in device_targets
        for target in targets
    )


def validate_partitions(data):
    if not data or len(data) % 32:
        raise ValueError("Partition table must contain whole 32-byte records")
    records = []
    checksum_found = False
    for offset in range(0, len(data), 32):
        entry = data[offset:offset + 32]
        if entry[:2] == b"\xeb\xeb":
            if entry[2:16] != b"\xff" * 14 or entry[16:] != hashlib.md5(data[:offset]).digest():
                raise ValueError("Partition table checksum mismatch")
            if data[offset + 32:] != b"\xff" * (len(data) - offset - 32):
                raise ValueError("Unexpected records after partition table checksum")
            checksum_found = True
            break
        magic, kind, subtype, address, size, label, flags = struct.unpack("<HBBII16sI", entry)
        if magic != 0x50AA:
            raise ValueError("Invalid partition table record")
        records.append((label.rstrip(b"\0").decode("ascii"), kind, subtype, address, size, flags))
    if not checksum_found:
        raise ValueError("Missing partition table checksum")
    if tuple(records) != EXPECTED_PARTITIONS:
        raise ValueError("Generated partition table differs from the pinned cover 4 MB layout")
    return min(record[4] for record in records if record[1] == 0)


def check_firmware(build_dir, program="firmware"):
    build_dir = Path(build_dir)
    capacity = validate_partitions((build_dir / "partitions.bin").read_bytes())
    size = (build_dir / (program + ".bin")).stat().st_size
    if size == 0 or size > capacity:
        raise ValueError(f"Application binary is {size:,} bytes; both OTA slots require 1..{capacity:,} bytes")
    return size, capacity


def report_firmware(build_dir, program="firmware"):
    size, capacity = check_firmware(build_dir, program)
    print(f"Application binary: {size:,} bytes; each OTA slot: {capacity:,} bytes; "
          f"headroom: {capacity - size:,} bytes ({100 * (capacity - size) / capacity:.2f}%)")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("build_dir", nargs="?", type=Path)
    parser.add_argument("--deny-upload", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.deny_upload:
        parser.exit(1, OTA_UPLOAD_DISABLED + "\n")
    if args.build_dir is None:
        parser.error("provide a local build directory")
    try:
        report_firmware(args.build_dir)
    except (OSError, ValueError) as error:
        parser.exit(1, f"Firmware check failed: {error}\n")


if __name__ == "__main__":
    main()
